#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT/'work/Momotarou Katsugeki (Japan) - latin_full_test_v2.pce'
OUT = ROOT/'work/Momotarou Katsugeki (Japan) - latin_charset_test.pce'
IPS = ROOT/'work/momotaro_latin_charset_test.ips'
PREVIEW = ROOT/'images/latin_charset_test_preview.png'
REPORT = ROOT/'reports/prueba_repertorio_latino.md'
TBL_SRC = ROOT/'work/charset_latin_full_v2.tbl'
TBL_OUT = ROOT/'work/charset_latin_charset_test.tbl'

if not BASE.exists():
    raise SystemExit(f'Falta la ROM base v2: {BASE}')

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())

# Tabla de codificación de prueba basada en charset_latin_full_v2.tbl.
char_to_code = {}
# ASCII original: mayúsculas, números, cierre ? !, espacio.
char_to_code[' '] = 0x20
for i in range(10): char_to_code[str(i)] = 0x30 + i
for i in range(26): char_to_code[chr(ord('A')+i)] = 0x41 + i
char_to_code['!'] = 0x21
char_to_code['?'] = 0x3F
char_to_code['$'] = 0x24
# Minúsculas. La c se evita en A3 y se codifica como DB, confirmado por prueba v2.
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    char_to_code[ch] = 0xA1 + i
char_to_code['c'] = 0xDB
# Acentos y signos altos.
extra = {
    'á':0xBB, 'é':0xBC, 'í':0xBD, 'ó':0xBE, 'ú':0xBF, 'ü':0xC0, 'ñ':0xC1,
    'Á':0xC2, 'É':0xC3, 'Í':0xC4, 'Ó':0xC5, 'Ú':0xC6, 'Ü':0xC7, 'Ñ':0xC8,
    '¿':0xC9, '¡':0xCA, '.':0xCB, ',':0xCC, ':':0xCD, ';':0xCE, '…':0xCF,
    "'":0xD0, '"':0xD1, '-':0xD2, '/':0xD3, '(':0xD4, ')':0xD5, '%':0xD6,
    '&':0xD7, '+':0xD8, '¤':0xD9, 'ç':0xDA, 'Ç':0xDB, 'º':0xDC, 'ª':0xDD,
}
# Nota: DB queda sobrecargado en la tabla textual de prueba; para esta ROM de test se usa DB como c.
# La Ç no se incluye en el texto de prueba para no pisar la c validada. Se resolverá al fijar tabla definitiva.
extra.pop('Ç')
char_to_code.update(extra)

def enc_line(s: str) -> bytes:
    out = []
    for ch in s:
        if ch not in char_to_code:
            raise ValueError(f'Carácter sin código: {ch!r}')
        out.append(char_to_code[ch])
    return bytes(out)

pages = [
    [
        'abcdefghijklmn',
        'opqrstuvwxyz',
        'áéíóú ü ñ ç',
    ],
    [
        'ABCDEFGHIJKLM',
        'NOPQRSTUVWXYZ',
        'ÁÉÍÓÚ Ü Ñ',
    ],
    [
        '¿? ¡! 012345',
        '6789 200¤',
        '.,:;… \'-/()% ',
    ],
    [
        '&+ ºª',
    ],
]

payload = bytearray()
for pi,page in enumerate(pages):
    for li,line in enumerate(page):
        payload += enc_line(line)
        if li != len(page)-1:
            payload.append(0x00)
    payload.append(0xFC if pi != len(pages)-1 else 0xFF)

start = 0x1F078
end_ff = 0x1F10B  # FF original del primer bloque del abuelo.
if len(payload) > (end_ff - start + 1):
    raise SystemExit(f'Payload demasiado largo: {len(payload)} > {end_ff-start+1}')
rom[start:start+len(payload)] = payload
# Rellenar hasta el FF original con espacios; asegurar fin en end_ff.
if start + len(payload) <= end_ff:
    rom[start+len(payload):end_ff] = bytes([0x20]) * (end_ff - (start+len(payload)))
    rom[end_ff] = 0xFF

OUT.write_bytes(rom)

# IPS contra ROM original, no contra la v2.
new = bytes(rom)
records=[]; i=0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s=i; buf=bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i]); i += 1
    records.append((s, bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big') + len(buf).to_bytes(2,'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# Copia de tabla usada.
if TBL_SRC.exists():
    txt = TBL_SRC.read_text(encoding='utf-8')
else:
    txt = ''
txt += '\n# Tabla de test de repertorio: c=DB validada; A3 reservado.\n'
txt += '# Nota temporal: Ç queda pendiente de slot definitivo para no pisar c=DB.\n'
TBL_OUT.write_text(txt, encoding='utf-8')

# Preview renderizado desde los glyphs de la ROM parcheada.
FONT_BASE = 0x3D660
ascii_map = new[0x42B5B:0x42B5B+0x36]
def source_to_gid(c):
    if c in (0x20, 0xA0): return 0x00
    if 0xA1 <= c <= 0xDF: return c
    if 0x30 <= c < 0x30 + len(ascii_map): return ascii_map[c-0x30]
    # Aproximaciones para los signos originales, sólo para preview. En juego pasan por AB34.
    if c == 0x21: return 0x9C
    if c == 0x3F: return 0x9D
    if c == 0x24: return 0x3E
    return 0x00

scale=3
page_imgs=[]
for pi,page in enumerate(pages):
    cols=max(len(line) for line in page)
    w=cols*8*scale + 8
    h=len(page)*10*scale + 8
    img=Image.new('RGB',(w,h),(0,0,0))
    for row,line in enumerate(page):
        codes=enc_line(line)
        for col,c in enumerate(codes):
            gid=source_to_gid(c)
            data=new[FONT_BASE+gid*8:FONT_BASE+gid*8+8]
            for y,b in enumerate(data):
                for x in range(8):
                    if (b>>(7-x))&1:
                        for yy in range(scale):
                            for xx in range(scale):
                                img.putpixel((4+col*8*scale+x*scale+xx,4+row*10*scale+y*scale+yy),(255,255,255))
    page_imgs.append(img)

sheet_w=max(im.width for im in page_imgs)
sheet_h=sum(im.height+18 for im in page_imgs)+8
sheet=Image.new('RGB',(sheet_w,sheet_h),(240,240,240))
d=ImageDraw.Draw(sheet)
y=4
for i,img in enumerate(page_imgs):
    d.text((2,y),f'Página {i+1}',fill=(0,0,0))
    y += 16
    sheet.paste(img,(0,y))
    y += img.height + 2
sheet.save(PREVIEW)

REPORT.write_text(f'''# Prueba de repertorio latino completo\n\nROM generada: `{OUT.name}`\n\nIPS generado: `{IPS.name}`\n\nTabla asociada: `{TBL_OUT.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Objetivo\n\nComprobar en emulador si todos los códigos latinos propuestos son seguros antes de fijar tabla definitiva.\n\n## Texto incluido\n\nPágina 1:\n\n```text\n{pages[0][0]}\n{pages[0][1]}\n{pages[0][2]}\n```\n\nPágina 2:\n\n```text\n{pages[1][0]}\n{pages[1][1]}\n{pages[1][2]}\n```\n\nPágina 3:\n\n```text\n{pages[2][0]}\n{pages[2][1]}\n{pages[2][2]}\n```\n\nPágina 4:\n\n```text\n{pages[3][0]}\n```\n\n## Notas\n\n- La `c` minúscula usa `$DB`, no `$A3`.\n- `$A3` queda reservado/no seguro.\n- `DE` y `DF` no se usan porque el motor los trata como marcas de dakuten/handakuten.\n- `Ç` queda pendiente de slot definitivo porque `$DB` se está usando provisionalmente para `c`.\n- El símbolo `¤` sigue siendo provisional para moneda/icono.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''', encoding='utf-8')

print('ROM:', OUT)
print('IPS:', IPS)
print('Preview:', PREVIEW)
print('Report:', REPORT)
print('Payload length:', len(payload), 'available:', end_ff-start+1)
print('Records:', len(records), 'bytes:', sum(len(b) for _,b in records))
