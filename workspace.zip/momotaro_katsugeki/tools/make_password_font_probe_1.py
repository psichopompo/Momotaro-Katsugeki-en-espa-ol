#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists(): BASE=ORIG
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - password_font_probe_1.pce'
IPS=ROOT/'Parches/momotaro_password_font_probe_1.ips'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
FONT_BASE=0x3D660
# 5x7 uppercase/digits glyphs in 8x8 bytes.
FONT={
 'A':["01110","10001","10001","11111","10001","10001","10001"], 'B':["11110","10001","10001","11110","10001","10001","11110"],
 'C':["01111","10000","10000","10000","10000","10000","01111"], 'D':["11110","10001","10001","10001","10001","10001","11110"],
 'E':["11111","10000","10000","11110","10000","10000","11111"], 'F':["11111","10000","10000","11110","10000","10000","10000"],
 'G':["01111","10000","10000","10011","10001","10001","01111"], 'H':["10001","10001","10001","11111","10001","10001","10001"],
 'I':["11111","00100","00100","00100","00100","00100","11111"], 'J':["00111","00010","00010","00010","00010","10010","01100"],
 'K':["10001","10010","10100","11000","10100","10010","10001"], 'L':["10000","10000","10000","10000","10000","10000","11111"],
 'M':["10001","11011","10101","10101","10001","10001","10001"], 'N':["10001","11001","10101","10011","10001","10001","10001"],
 'O':["01110","10001","10001","10001","10001","10001","01110"], 'P':["11110","10001","10001","11110","10000","10000","10000"],
 'Q':["01110","10001","10001","10001","10101","10010","01101"], 'R':["11110","10001","10001","11110","10100","10010","10001"],
 'S':["01111","10000","10000","01110","00001","00001","11110"], 'T':["11111","00100","00100","00100","00100","00100","00100"],
 'U':["10001","10001","10001","10001","10001","10001","01110"], 'V':["10001","10001","10001","10001","01010","01010","00100"],
 'W':["10001","10001","10001","10101","10101","11011","10001"], 'X':["10001","01010","00100","00100","01010","10001","10001"],
 'Y':["10001","01010","00100","00100","00100","00100","00100"], 'Z':["11111","00001","00010","00100","01000","10000","11111"],
 '0':["01110","10001","10011","10101","11001","10001","01110"], '1':["00100","01100","00100","00100","00100","00100","01110"],
 '2':["01110","10001","00001","00010","00100","01000","11111"], '3':["11110","00001","00001","01110","00001","00001","11110"],
 '4':["00010","00110","01010","10010","11111","00010","00010"], '5':["11111","10000","10000","11110","00001","00001","11110"],
 '6':["01110","10000","10000","11110","10001","10001","01110"], '7':["11111","00001","00010","00100","01000","01000","01000"],
 '8':["01110","10001","10001","01110","10001","10001","01110"], '9':["01110","10001","10001","01111","00001","00001","01110"],
 '?':["01110","10001","00001","00010","00100","00000","00100"], '!':["00100","00100","00100","00100","00100","00000","00100"],
 ' ':["00000"]*7
}
def glyph(ch):
    rows=FONT[ch]
    out=[]
    for row in ['00000']+rows:  # top blank, then 7 rows
        b=0
        for x in range(8):
            bit = 1 if x<5 and row[x]=='1' else 0
            b=(b<<1)|bit
        out.append(b)
    return bytes(out)
chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!?'
# lower case use uppercase shape for probe.
for idx,ch in enumerate(chars, start=1):
    gch=ch.upper() if ch.isalpha() else ch
    rom[FONT_BASE+idx*8:FONT_BASE+idx*8+8]=glyph(gch)
# Also blank dakuten/handakuten marks for probe? Avoid removing for now. Patch glyph IDs 0x6D/0x6E to blank maybe to avoid marks clutter.
rom[FONT_BASE+0x6D*8:FONT_BASE+0x6D*8+8]=bytes(8)
rom[FONT_BASE+0x6E*8:FONT_BASE+0x6E*8+8]=bytes(8)
OUT.write_bytes(rom)
# IPS
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
(ROOT/'reports/test_password_font_probe_1.md').write_text(f'''# Password font probe 1\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\n## Objetivo\n\nComprobar si la pantalla de password carga la fuente 1bpp general situada en `0x3D660`.\n\nSe reemplazan los glyph IDs `0x01-0x40` por letras/números latinos visibles y se vacían los glyphs `0x6D/0x6E` de dakuten/handakuten.\n\n## Resultado esperado\n\nSi la pantalla de password usa esta fuente, la parrilla de hiragana y/o los textos de la columna derecha cambiarán visualmente.\n\nSi no cambia, la pantalla usa otra fuente o gráficos prerenderizados.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in rec)}\n''',encoding='utf-8')
print('OUT',OUT)
print('records',len(rec),sum(len(b) for _,b in rec))
