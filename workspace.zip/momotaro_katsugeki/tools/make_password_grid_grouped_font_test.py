#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists():
    BASE = ORIG
LATIN = ROOT / 'Roms/Anteriores/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
USER_SHEET = Path('/home/user/uploads/IMG_4535.PNG')
OUT = ROOT / 'Roms/Momotarou Katsugeki (Japan) - password_grid_grouped_font_test.pce'
IPS = ROOT / 'Parches/momotaro_password_grid_grouped_font_test.ips'
REPORT = ROOT / 'reports/test_password_grid_grouped_font.md'
PREVIEW = ROOT / 'images/password_grid_grouped_font_preview.png'
USER_SHEET_COPY = ROOT / 'font_edit/password_alphabet_user_fixed_1x.png'
USER_SHEET_REF = ROOT / 'font_edit/password_alphabet_user_fixed_8x_grid.png'
USER_SHEET_MAP = ROOT / 'font_edit/password_alphabet_user_fixed_mapping.txt'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())
latin = LATIN.read_bytes()

# ---------------------------------------------------------------------------
# Helpers.
# ---------------------------------------------------------------------------
def glyph(rows):
    out = []
    for r in rows:
        r = r.ljust(8, '.')[:8]
        b = 0
        for ch in r:
            b = (b << 1) | (1 if ch not in '. 0' else 0)
        out.append(b)
    return bytes(out)

def rle_encode(vals):
    out = bytearray()
    i = 0
    while i < len(vals):
        v = vals[i]
        j = i + 1
        while j < len(vals) and vals[j] == v and j - i < 256:
            j += 1
        L = j - i
        if L >= 3 or v == 0xFF:
            out += bytes([0xFF, L - 1, v])
        else:
            out += bytes([v]) * L
        i = j
    return bytes(out)

def cell_to_glyph_bytes(img, col, row):
    # Any bright pixel becomes 1. Exact attached sheet is two-color RGBA.
    out = []
    pix = img.convert('RGBA').load()
    for y in range(8):
        b = 0
        for x in range(8):
            r, g, bl, a = pix[col * 8 + x, row * 8 + y]
            on = a > 0 and (r + g + bl) >= 384
            b = (b << 1) | (1 if on else 0)
        out.append(b)
    return bytes(out)

# ---------------------------------------------------------------------------
# Encoding used by the validated latin font test.
# ---------------------------------------------------------------------------
enc = {' ': 0x20}
for i in range(10):
    enc[str(i)] = 0x30 + i
for i, ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    enc[ch] = 0x41 + i
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    enc[ch] = 0xA1 + i
# validated source-code exceptions in this engine/text path
enc['b'] = 0x5B
enc['c'] = 0x5D
enc['p'] = 0x5E
enc.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

FONT_BASE = 0x3D660
FONT_LEN = 0xE0 * 8
ASCII_MAP = 0x42B5B

# ---------------------------------------------------------------------------
# 1) Copy validated latin font/conversion tables.
# ---------------------------------------------------------------------------
rom[FONT_BASE:FONT_BASE + FONT_LEN] = latin[FONT_BASE:FONT_BASE + FONT_LEN]
latin_table_regions = [(0x41CB3, 0x40), (0x41CF3, 0x40), (ASCII_MAP, 0x36)]
for off, length in latin_table_regions:
    rom[off:off + length] = latin[off:off + length]

# Helper after ASCII map has been copied.
def source_to_gid(c):
    ascii_map = rom[ASCII_MAP:ASCII_MAP + 0x36]
    if c in (0x20, 0xA0):
        return 0
    if 0xA1 <= c <= 0xDF:
        return c
    if 0x30 <= c < 0x30 + len(ascii_map):
        return ascii_map[c - 0x30]
    if c == 0x21:
        return 0x9E
    if c == 0x3F:
        return 0x9D
    if c == 0x24:
        return 0x3E
    return 0

# ---------------------------------------------------------------------------
# 2) Import user-fixed alphabet sheet into actual font glyph IDs.
#    The sheet follows the previous 14-col order:
#      row0 A..N
#      row1 Ñ..Z
#      row2 a..n
#      row3 ñ..z
#      row4 0..9
# ---------------------------------------------------------------------------
assert USER_SHEET.exists(), USER_SHEET
user_img = Image.open(USER_SHEET).convert('RGBA')
assert user_img.size == (112, 40), user_img.size
USER_SHEET_COPY.parent.mkdir(parents=True, exist_ok=True)
user_img.save(USER_SHEET_COPY)

sheet_rows = [
    list('ABCDEFGHIJKLMN'),
    ['Ñ', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
    list('abcdefghijklmn'),
    ['ñ', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
    list('0123456789'),
]
patched_glyphs = []
for rr, row in enumerate(sheet_rows):
    for cc, ch in enumerate(row):
        src = enc[ch]
        gid = source_to_gid(src)
        data = cell_to_glyph_bytes(user_img, cc, rr)
        rom[FONT_BASE + gid * 8:FONT_BASE + gid * 8 + 8] = data
        patched_glyphs.append((ch, src, gid, rr, cc, data))

# ---------------------------------------------------------------------------
# 3) Dedicated placeholder glyphs for the input buffer.
# ---------------------------------------------------------------------------
DOT_GID = 0xDB
SLASH_GID = 0xDF
rom[FONT_BASE + DOT_GID * 8:FONT_BASE + DOT_GID * 8 + 8] = glyph([
    '........',
    '........',
    '........',
    '...##...',
    '...##...',
    '........',
    '........',
    '........',
])
rom[FONT_BASE + SLASH_GID * 8:FONT_BASE + SLASH_GID * 8 + 8] = glyph([
    '........',
    '.....#..',
    '....#...',
    '...#....',
    '..#.....',
    '.#......',
    '........',
    '........',
])
# source $60 -> dot, source $61 -> slash
rom[ASCII_MAP + (0x60 - 0x30)] = DOT_GID
rom[ASCII_MAP + (0x61 - 0x30)] = SLASH_GID
PLACEHOLDER_DOT_SOURCE = 0x60
PLACEHOLDER_SLASH_SOURCE = 0x61

# ---------------------------------------------------------------------------
# 4) Grouped visual/password order.
# ---------------------------------------------------------------------------
# 14 logical columns. Columns 0..6 are uppercase block, columns 7..13 are
# lowercase block. The x table contains a semantic gap between both blocks.
# Rows with fewer symbols are zero-filled in CC82 so original navigation skips.
visual_rows = [
    ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'a', 'b', 'c', 'd', 'e', 'f', 'g'],
    ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'h', 'i', 'j', 'k', 'l', 'm', 'n'],
    ['Ñ', 'O', 'P', 'Q', 'R', 'S', 'T', 'ñ', 'o', 'p', 'q', 'r', 's', 't'],
    ['U', 'V', 'W', 'X', 'Y', 'Z', None, 'u', 'v', 'w', 'x', 'y', 'z', None],
    [None, None, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', None, None],
]
assert len(visual_rows) == 5 and all(len(r) == 14 for r in visual_rows)
symbols = [ch for row in visual_rows for ch in row if ch is not None]
assert len(symbols) == 64, len(symbols)
source = bytes([enc[ch] for ch in symbols])

# Runtime alphabet source. Generated pattern IDs:
#   1..64 = symbols in visual order
#   65    = dot placeholder
#   66    = slash placeholder
new_off = 0x1BBB9
new_cpu = 0xDBB9
DOT_PATTERN_ID = 0x41
SLASH_PATTERN_ID = 0x42
table = bytes([0x01]) + source + bytes([PLACEHOLDER_DOT_SOURCE, PLACEHOLDER_SLASH_SOURCE, 0xFF])
rom[new_off:new_off + len(table)] = table
rom[0x1A85E] = new_cpu & 0xFF
rom[0x1A862] = new_cpu >> 8

# ---------------------------------------------------------------------------
# 5) Buffer renderer fixes.
# ---------------------------------------------------------------------------
# Original CB90 treats buffer values >= $2D as voiced/semivoiced kana and
# remaps them through CBD1 while drawing $2E/$2F above the slot. Our Latin
# alphabet uses direct generated patterns 1..64, so the threshold must be
# moved above $40. This is what caused the wrong output from lowercase q onward.
rom[0x1AB98] = 0x41  # CB97: CMP #$2D -> CMP #$41
# Original empty/separator placeholders used generated patterns $30/$31; those
# are real Latin symbols now. Redirect to the two generated placeholder tiles.
rom[0x1AB87] = SLASH_PATTERN_ID  # CB86 LDA #$30, branch for $FF
rom[0x1AB8C] = DOT_PATTERN_ID    # CB8B LDA #$31, branch for $00

# ---------------------------------------------------------------------------
# 6) RLE tilemap streams for visual grid.
# ---------------------------------------------------------------------------
tile_cols = [2, 4, 6, 8, 10, 12, 14, 17, 19, 21, 23, 25, 27, 29]
tile_rows = [7, 9, 11, 13, 17]

tm = [[0x100 for _ in range(32)] for __ in range(32)]
value = 1
values = []
for rr, row in enumerate(visual_rows):
    row_values = []
    for cc, ch in enumerate(row):
        if ch is None:
            row_values.append(0)
            continue
        tm[tile_rows[rr]][tile_cols[cc]] = 0x100 + value
        row_values.append(value)
        value += 1
    values.extend(row_values)
assert value == 65
assert len(values) == 70

low = []
high = []
for r in range(32):
    for c in range(32):
        w = tm[r][c]
        low.append(w & 0xFF)
        high.append(((w >> 8) - 1) & 0xFF)
low_stream = rle_encode(low)
high_stream = rle_encode(high)
low_region_len = 0x1E290 - 0x1E18C
high_region_len = 0x1E29C - 0x1E290
assert len(low_stream) <= low_region_len, (len(low_stream), low_region_len)
assert len(high_stream) <= high_region_len, (len(high_stream), high_region_len)
rom[0x1E18C:0x1E290] = low_stream + bytes([0xFF]) * (low_region_len - len(low_stream))
rom[0x1E290:0x1E29C] = high_stream + bytes([0xFF]) * (high_region_len - len(high_stream))

# ---------------------------------------------------------------------------
# 7) Cursor/selection logic. Tables relocated to free same-bank space.
# ---------------------------------------------------------------------------
sel_base_off = 0x1BC00
sel_base_cpu = 0xDC00
row_offsets_cpu = sel_base_cpu
x_table_cpu = row_offsets_cpu + 5
y_table_cpu = x_table_cpu + 14
values_cpu = y_table_cpu + 5

row_offsets = [0, 14, 28, 42, 56]
x_table = [(c * 8) - 8 for c in tile_cols]
y_table = [r * 8 for r in tile_rows]
sel_blob = bytes(row_offsets) + bytes(x_table) + bytes(y_table) + bytes(values)
assert len(sel_blob) == 94
assert sel_base_off >= new_off + len(table)  # no overlap with runtime table
assert orig[sel_base_off:sel_base_off + len(sel_blob)] == bytes([0xFF]) * len(sel_blob)
rom[sel_base_off:sel_base_off + len(sel_blob)] = sel_blob

# Patch absolute operand addresses:
#   C955: LDA $CC61,Y -> row offsets
#   C961: LDX $CC6B,Y -> X table
#   C967: LDA $CC78,Y -> Y table
#   CC5D: LDA $CC82,X -> values table
addr_patches = {
    0x1AC56: row_offsets_cpu,
    0x1A962: x_table_cpu,
    0x1A968: y_table_cpu,
    0x1AC5E: values_cpu,
}
for off, addr in addr_patches.items():
    rom[off] = addr & 0xFF
    rom[off + 1] = addr >> 8

# Navigation bounds: rows 0..4, columns 0..13.
nav_patches = {
    0x1AA56: 0x04,  # row wrap up = 4
    0x1AA6A: 0x05,  # row max exclusive = 5
    0x1AA80: 0x0E,  # column max exclusive = 14
    0x1AA95: 0x0D,  # column wrap left = 13
}
for off, val in nav_patches.items():
    rom[off] = val

# Horizontal directions corrected for ascending X table:
# input $20 (right) -> increment column; input $80 (left) -> decrement column.
rom[0x1AA47] = 0x2E  # CA46 BNE $CA76
rom[0x1AA4B] = 0x40  # CA4A BNE $CA8C

# ---------------------------------------------------------------------------
# Output ROM + IPS against original clean ROM.
# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
IPS.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
PREVIEW.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(rom)
new = bytes(rom)
records = []
i = 0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s = i
    buf = bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i])
        i += 1
    records.append((s, bytes(buf)))
ips = bytearray(b'PATCH')
for off, buf in records:
    ips += off.to_bytes(3, 'big') + len(buf).to_bytes(2, 'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# ---------------------------------------------------------------------------
# Static layout preview.
# ---------------------------------------------------------------------------
scale = 3
img = Image.new('RGB', (256 * scale, 240 * scale), (0, 0, 220))
d = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 8 * scale)
except Exception:
    font = ImageFont.load_default()
for rr, row in enumerate(visual_rows):
    for cc, ch in enumerate(row):
        if ch is None:
            continue
        x = tile_cols[cc] * 8 * scale
        y = tile_rows[rr] * 8 * scale
        d.text((x, y), ch, fill=(255, 255, 255), font=font)
# cursor anchors only for valid cells
for rr, row in enumerate(visual_rows):
    for cc, ch in enumerate(row):
        if ch is None:
            continue
        cx = x_table[cc] * scale
        cy = y_table[rr] * scale
        d.polygon([(cx, cy + 2 * scale), (cx, cy + 6 * scale), (cx + 5 * scale, cy + 4 * scale)], fill=(255, 60, 60))
img.save(PREVIEW)

# ---------------------------------------------------------------------------
# Save enlarged version of the user-fixed sheet for documentation.
# ---------------------------------------------------------------------------
cell = 8 * 8
label_h = 14
ref = Image.new('RGB', (14 * cell, 5 * (cell + label_h)), (230, 230, 230))
dr = ImageDraw.Draw(ref)
for rr, row in enumerate(sheet_rows):
    for cc in range(14):
        x0 = cc * cell
        y0 = rr * (cell + label_h)
        dr.rectangle([x0, y0 + label_h, x0 + cell - 1, y0 + label_h + cell - 1], outline=(120, 120, 120), fill=(0, 0, 0))
        if cc < len(row):
            ch = row[cc]
            dr.text((x0 + 2, y0), ch, fill=(220, 0, 0))
            data = cell_to_glyph_bytes(user_img, cc, rr)
            for y, b in enumerate(data):
                for x in range(8):
                    if (b >> (7 - x)) & 1:
                        dr.rectangle([
                            x0 + x * 8,
                            y0 + label_h + y * 8,
                            x0 + x * 8 + 7,
                            y0 + label_h + y * 8 + 7,
                        ], fill=(255, 255, 255))
ref.save(USER_SHEET_REF)

with USER_SHEET_MAP.open('w', encoding='utf-8') as f:
    f.write('Momotarou Katsugeki — user fixed password alphabet sheet\n')
    f.write(f'Original upload: {USER_SHEET}\n')
    f.write('Imported into font glyphs before generating the password runtime patterns.\n\n')
    for ch, src, gid, rr, cc, _data in patched_glyphs:
        f.write(f'row={rr:02d} col={cc:02d} char={ch} source=${src:02X} glyph=${gid:02X}\n')

layout_text = '\n'.join(' '.join(ch if ch is not None else '·' for ch in row) for row in visual_rows)
source_order_text = ''.join(symbols)
changed_relevant = [
    ('Fuente latina 1bpp + fuente usuario + placeholders', FONT_BASE, FONT_LEN),
    ('Tabla conversión latina 1', 0x41CB3, 0x40),
    ('Tabla conversión latina 2', 0x41CF3, 0x40),
    ('Tabla ASCII latina + $60/$61', ASCII_MAP, 0x36),
    ('Puntero tabla runtime low', 0x1A85E, 1),
    ('Puntero tabla runtime high', 0x1A862, 1),
    ('Tabla runtime 64 símbolos + dot/slash', new_off, len(table)),
    ('CB90 threshold de marcas', 0x1AB98, 1),
    ('CB7E placeholder $FF -> slash', 0x1AB87, 1),
    ('CB7E placeholder $00 -> dot', 0x1AB8C, 1),
    ('Tilemap RLE low', 0x1E18C, low_region_len),
    ('Tilemap RLE high', 0x1E290, high_region_len),
    ('Branch input derecha $20', 0x1AA47, 1),
    ('Branch input izquierda $80', 0x1AA4B, 1),
    ('Nav row wrap up', 0x1AA56, 1),
    ('Nav row max', 0x1AA6A, 1),
    ('Nav col max', 0x1AA80, 1),
    ('Nav col wrap left', 0x1AA95, 1),
    ('Operand row offsets', 0x1AC56, 2),
    ('Operand X table', 0x1A962, 2),
    ('Operand Y table', 0x1A968, 2),
    ('Operand valores selección', 0x1AC5E, 2),
    ('Tablas selección relocalizadas', sel_base_off, len(sel_blob)),
]
changed_relevant_md = '\n'.join(f'- {name}: `0x{off:05X}` len `{length}`' for name, off, length in changed_relevant)
REPORT.write_text(f'''# Password grid grouped + user font test

ROM: `Roms/{OUT.name}`

IPS: `Parches/{IPS.name}`

Preview estático: `images/{PREVIEW.name}`

Fuente de usuario importada: `font_edit/{USER_SHEET_COPY.name}`

Referencia ampliada: `font_edit/{USER_SHEET_REF.name}`

Mapa de importación: `font_edit/{USER_SHEET_MAP.name}`

## Objetivo

Prueba con la distribución agrupada propuesta y con la fuente corregida enviada por el usuario.

Prefiero esta distribución porque el hueco central deja de ser una anomalía dentro del abecedario y pasa a separar dos bloques con sentido: mayúsculas a la izquierda y minúsculas a la derecha. Además conserva el centrado bueno que sólo era posible introduciendo un hueco.

## Parrilla visual/lógica esperada

`·` significa celda vacía que la navegación debe saltar.

```text
{layout_text}
```

## Orden de valores generado internamente

```text
{source_order_text}
```

La tabla `CC82` usa valores `1..64` en ese orden. Los huecos visuales son `0` para que la rutina original los salte.

## Corrección del fallo desde la q minúscula

Confirmado por código: el buffer original trata cualquier valor `>= $2D` como kana con dakuten/handakuten. Entonces lo remapea por `CBD1` y dibuja un patrón encima del carácter. Por eso desde la `q` minúscula en el orden anterior salían caracteres equivocados y aparecían `r/s` arriba.

Parche aplicado:

```asm
CB97: CMP #$2D  ; original
CB97: CMP #$41  ; nuevo: sólo valores >64 entrarían en esa ruta
```

Así los valores `1..64` del alfabeto latino se dibujan directos.

## Placeholder del buffer inferior

Se mantiene el arreglo de slots vacíos:

- `$00` -> punto medio grueso,
- `$FF` -> slash.

## Validación estática hecha antes de generar

- Fuente enviada: `{user_img.size[0]}x{user_img.size[1]}` px, dos colores.
- Glifos importados desde fuente usuario: `{len(patched_glyphs)}`.
- Símbolos seleccionables: `{len(symbols)}`.
- Tabla runtime total: `{len(table)}` bytes en `0x{new_off:05X}`; termina en `0x{new_off + len(table):05X}`.
- Tablas selección relocalizadas: `{len(sel_blob)}` bytes en `0x{sel_base_off:05X}`, zona original `FF` libre.
- Low stream RLE: `{len(low_stream)}` / `{low_region_len}` bytes.
- High stream RLE: `{len(high_stream)}` / `{high_region_len}` bytes.
- X table: `{len(x_table)}` bytes.
- Y table: `{len(y_table)}` bytes.
- Valores selección: `{len(values)}` bytes.

## Regiones relevantes cambiadas

{changed_relevant_md}

## Qué comprobar en emulador

1. Si esta distribución agrupada resulta más natural que la de 14 columnas lineales con hueco central.
2. Que derecha/izquierda siguen correctas.
3. Que todos los caracteres insertan exactamente el mismo carácter, especialmente desde `q` hasta `9`.
4. Que no aparecen `r/s` o marcas encima de los caracteres insertados.
5. Que los huecos se saltan bien en navegación.
6. Que el buffer inferior muestra puntos/slashes en vacío.
7. Que la fuente corregida se ve como en el PNG enviado.
''', encoding='utf-8')

print('OUT', OUT)
print('IPS', IPS)
print('REPORT', REPORT)
print('PREVIEW', PREVIEW)
print('USER_SHEET_COPY', USER_SHEET_COPY)
print('USER_SHEET_REF', USER_SHEET_REF)
print('layout:')
print(layout_text)
print('source order:', source_order_text)
print('tile_cols', tile_cols)
print('tile_rows', tile_rows)
print('low/high', len(low_stream), '/', low_region_len, len(high_stream), '/', high_region_len)
print('runtime table len', len(table), 'ends', hex(new_off + len(table)))
print('sel blob', hex(sel_base_off), len(sel_blob))
print('x_table', [f'{x:02X}' for x in x_table])
print('y_table', [f'{y:02X}' for y in y_table])
print('values', values)
print('records', len(records), 'changed bytes', sum(len(b) for _, b in records))
