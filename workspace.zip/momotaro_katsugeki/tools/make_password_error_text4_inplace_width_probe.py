#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_inplace_width_probe.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v03_error_text4_inplace_width_probe.ips'
REPORT=ROOT/'reports/test_password_error_text4_inplace_width_probe.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)
# Encoder
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i in range(26): enc[chr(65+i)]=0x41+i
enc.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s):
    out=bytearray()
    for ch in s:
        if ch=='\n': out.append(0)
        else: out.append(enc[ch])
    return bytes(out)
def cpu0f(off): return 0x4000+(off-0x1E000)
# Text exactly fixed.
text='¡El canto de Jizo\nno es correcto!\nRevísalo bien e\ninténtalo de nuevo.'
error_off=0x1F838; error_cpu=cpu0f(error_off)
data=bytes([1])+enc_text(text)+bytes([0xFF])
assert orig[error_off:error_off+len(data)]==bytes([0xFF])*len(data)
rom[error_off:error_off+len(data)]=data
rom[0x1AE60]=error_cpu&0xff; rom[0x1AE64]=error_cpu>>8
# Line starts chosen to avoid line2 overwriting char17 of line1.
# line1 $7008, line2 $7288 (after 5 chunks), line3 $7488, line4 $7688
lt_off=0x1BDB0; lt_cpu=0xDDB0
lt=bytes([0x08,0x70, 0x88,0x72, 0x88,0x74, 0x88,0x76])
assert orig[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
assert base[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
rom[lt_off:lt_off+len(lt)]=lt
for off,cpu in [(0x1AE68,lt_cpu),(0x1AE70,lt_cpu+1),(0x1AEF4,lt_cpu),(0x1AEF9,lt_cpu+1)]:
    rom[off]=cpu&0xff; rom[off+1]=cpu>>8
# Diagnostic: edit original viewport list in-place, no relocation and no free bank.
# It still has 12 sprite slots. Use them as 5 chunks for line1, 4 for line2, 3 for line3.
vp_off=0x2EC10
entries=[]
# line 1: offsets 0,2,4,6,8 y=0 x=0..80
for col,pat in enumerate([0x00,0x02,0x04,0x06,0x08]): entries.append([pat,0x0E,0x01,col*0x20,0x00])
# line 2: offsets A,C,E,10 y=10
for col,pat in enumerate([0x0A,0x0C,0x0E,0x10]): entries.append([pat,0x0E,0x01,col*0x20,0x10])
# line 3: offsets 12,14,16 y=20
for col,pat in enumerate([0x12,0x14,0x16]): entries.append([pat,0x0E,0x01,col*0x20,0x20])
vp=bytearray()
for e in entries: vp += bytes(e)
vp.append(0xFF)
assert len(vp)==61
# Keep same length/terminator position as original $4C10 list.
rom[vp_off:vp_off+len(vp)]=vp
# Anti-corruption: no writes to previous problematic padding/free area.
assert rom[0x2F8B5:0x30000] == base[0x2F8B5:0x30000]
assert rom[0x1E29C:0x1E2DF] == base[0x1E29C:0x1E2DF]
# Output
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
REPORT.write_text(f'''# Prueba v03 — ancho diagnóstico in-place

ROM:
`Roms/Pruebas/{OUT.name}`

IPS:
`Parches/Pruebas/{IPS.name}`

## Objetivo

Intentar mostrar sólo la `o` de `Jizo` sin relocalizar listas ni tocar zonas libres problemáticas.

Texto fijo:

```text
{text}
```

## Cambio técnico

La lista original del viewport en `0x2EC10` tiene 12 sprites: 4 columnas x 3 filas. En esta prueba se mantiene exactamente el mismo tamaño de lista y se redistribuyen esos 12 sprites como:

- línea 1: 5 chunks/sprites, para llegar al carácter 17.
- línea 2: 4 chunks/sprites.
- línea 3: 3 chunks/sprites.

Esto es diagnóstico: si aparece la `o`, sabemos que la forma correcta de ampliar el ancho pasa por añadir más sprites/chunks reales a la lista, no por moverla a otro banco.

También se separan las líneas en VRAM:

- `$7008`
- `$7288`
- `$7488`
- `$7688`

para que la línea 2 no pise el carácter 17 de la línea 1.

## Validación

- No se escribe en `0x2F8B5-0x30000`, la zona que corrompió título/opciones.
- No se toca el tilemap del bocadillo central (`0x1E29C-0x1E2DF`).
- La modificación in-place de `0x2EC10` mantiene el mismo largo (`61` bytes) y el mismo terminador.

## Cambios contra v02

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Si aparece `¡El canto de Jizo` completo.
3. No evaluar todavía la tercera línea si se recorta: hemos sacrificado ancho de línea 3 para diagnosticar la primera.
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('changed',changed)
print('records',len(rec),'bytes',sum(len(b) for _,b in rec))
