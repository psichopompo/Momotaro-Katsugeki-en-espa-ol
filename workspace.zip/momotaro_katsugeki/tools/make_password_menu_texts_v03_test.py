#!/usr/bin/env python3
from pathlib import Path

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT = ROOT / 'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_password_texts_test.pce'
IPS = ROOT / 'Parches/Pruebas/momotaro_traduccion_v03_password_texts_test.ips'
REPORT = ROOT / 'reports/test_password_menu_texts_v03.md'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())

# ---------------------------------------------------------------------------
# Latin encoder validated in the project.
# ---------------------------------------------------------------------------
CHAR_TO_CODE = {' ': 0x20}
for i in range(10):
    CHAR_TO_CODE[str(i)] = 0x30 + i
for i in range(26):
    CHAR_TO_CODE[chr(ord('A') + i)] = 0x41 + i
CHAR_TO_CODE.update({'!': 0x21, '?': 0x3F, '$': 0x24})
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    CHAR_TO_CODE[ch] = 0xA1 + i
# Unsafe direct bytes, use ASCII-map aliases.
CHAR_TO_CODE['b'] = 0x5B
CHAR_TO_CODE['c'] = 0x5D
CHAR_TO_CODE['p'] = 0x5E
CHAR_TO_CODE.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

def enc_text(s: str) -> bytes:
    out = bytearray()
    i = 0
    while i < len(s):
        if s[i] == '\n':
            out.append(0x00)
            i += 1
            continue
        if s.startswith('<WAIT>', i):
            out.append(0xFD)
            i += len('<WAIT>')
            continue
        if s.startswith('<PAGE>', i):
            out.append(0xFC)
            i += len('<PAGE>')
            continue
        if s.startswith('<MODE>', i):
            out.append(0xFE)
            i += len('<MODE>')
            continue
        ch = s[i]
        if ch not in CHAR_TO_CODE:
            raise ValueError(f'Carácter no soportado: {ch!r} en {s!r}')
        out.append(CHAR_TO_CODE[ch])
        i += 1
    return bytes(out)

def vis_len(s: str) -> int:
    # Approximate: controls do not count; newline splits elsewhere.
    n = 0
    i = 0
    while i < len(s):
        if s[i] == '\n':
            i += 1
            continue
        matched = False
        for tok in ('<WAIT>', '<PAGE>', '<MODE>'):
            if s.startswith(tok, i):
                i += len(tok)
                matched = True
                break
        if matched:
            continue
        n += 1
        i += 1
    return n

def cpu_from_rom(off: int) -> int:
    # These text blocks are in physical bank $0F at CPU $4000-$5FFF.
    assert 0x1E000 <= off < 0x20000
    return 0x4000 + (off - 0x1E000)

def ptr_bytes(cpu: int) -> bytes:
    return bytes([cpu & 0xFF, cpu >> 8])

# ---------------------------------------------------------------------------
# Allocate translated strings in free space 0x1F838+.
# ---------------------------------------------------------------------------
alloc_start = 0x1F838
alloc_end = 0x20000
assert orig[alloc_start:alloc_end] == bytes([0xFF]) * (alloc_end - alloc_start)
alloc = alloc_start
allocations = {}

def put_string(name: str, payload: bytes, terminator: int = 0x00) -> int:
    global alloc
    off = alloc
    data = payload + bytes([terminator])
    if off + len(data) > alloc_end:
        raise RuntimeError('No queda espacio libre para textos')
    # Avoid accidental overlap with existing non-FF in original free area.
    assert orig[off:off + len(data)] == bytes([0xFF]) * len(data)
    rom[off:off + len(data)] = data
    allocations[name] = (off, cpu_from_rom(off), len(data), data)
    alloc += len(data)
    return cpu_from_rom(off)

# Menu/list strings. Preserve the original per-entry prefix: $01/$02 + $3C.
# $3C works as the original menu/list spacing marker in this context.
PFX1 = bytes([0x01, 0x3C])
PFX2 = bytes([0x02, 0x3C])

diff_facil = put_string('diff_facil', PFX1 + enc_text('FÁCIL'), 0x00)
diff_normal = put_string('diff_normal', PFX1 + enc_text('NORMAL'), 0x00)
diff_dificil = put_string('diff_dificil', PFX1 + enc_text('DIFÍCIL'), 0x00)
diff_muy_dificil = put_string('diff_muy_dificil', PFX2 + enc_text('MUY DIFÍCIL'), 0x00)
empty = put_string('empty', b'', 0x00)
menu_jizo = put_string('menu_jizo', PFX1 + enc_text('CANTO DE JIZO'), 0x00)
menu_cargar = put_string('menu_cargar', PFX2 + enc_text('CARGAR'), 0x00)
load_question = put_string('load_question', bytes([0x01]) + enc_text('¿Cuál quieres cargar?'), 0x00)
backup_error = put_string(
    'backup_error',
    bytes([0x01]) + enc_text('Los datos guardados\nno son válidos.\nSe borrará el archivo.'),
    0xFF,
)
jizo_prompt = put_string('jizo_prompt', bytes([0x01]) + enc_text('¡Introduce el canto de Jizo!'), 0xFF)
jizo_error = put_string(
    'jizo_error',
    bytes([0x01]) + enc_text('¡El canto de Jizo no es correcto!<WAIT><WAIT>\nCompruébalo bien<WAIT>\ne inténtalo otra vez.'),
    0xFF,
)

# ---------------------------------------------------------------------------
# Patch original pointer tables.
# ---------------------------------------------------------------------------
# Main selector difficulty pointers at CPU $54AE.
rom[0x1F4AE:0x1F4AE + 10] = b''.join(ptr_bytes(p) for p in [
    diff_facil, diff_normal, diff_dificil, diff_muy_dificil, empty,
])
# Main selector options at CPU $54EB: CANTO DE JIZO / CARGAR.
rom[0x1F4EB:0x1F4EB + 4] = ptr_bytes(menu_jizo) + ptr_bytes(menu_cargar)
# Load selector table at CPU $5501: question + difficulty pointers + empty.
rom[0x1F501:0x1F501 + 12] = b''.join(ptr_bytes(p) for p in [
    load_question, diff_facil, diff_normal, diff_dificil, diff_muy_dificil, empty,
])

# Direct code references for Jizo password prompt/error in bank $0D.
# CD10/CD47 -> prompt $555A, CE5F -> error $556E.
for off, cpu in [(0x1AD11, jizo_prompt), (0x1AD48, jizo_prompt), (0x1AE60, jizo_error)]:
    rom[off] = cpu & 0xFF
for off, cpu in [(0x1AD15, jizo_prompt), (0x1AD4C, jizo_prompt), (0x1AE64, jizo_error)]:
    rom[off] = cpu >> 8
# Direct backup-RAM error string reference in C583: LDA #$1D / #$55 -> new backup_error.
rom[0x1A58E] = backup_error & 0xFF
rom[0x1A592] = backup_error >> 8

# ---------------------------------------------------------------------------
# Static validation.
# ---------------------------------------------------------------------------
# Ensure the old table bytes are only pointer tables; translated text lives in free space.
assert alloc <= alloc_end
assert alloc - alloc_start < 0x800
# Ensure v02 password tables remain untouched.
assert rom[0x1BBB9] == BASE.read_bytes()[0x1BBB9]

# ---------------------------------------------------------------------------
# Write ROM and IPS against original clean ROM.
# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
IPS.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(rom)
new = bytes(rom)
records = []
i = 0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s = i
    buf = bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i])
        i += 1
    records.append((s, bytes(buf)))
ips = bytearray(b'PATCH')
for off, buf in records:
    ips += off.to_bytes(3, 'big') + len(buf).to_bytes(2, 'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# Report.
texts_for_lengths = {
    'FÁCIL': 'FÁCIL',
    'NORMAL': 'NORMAL',
    'DIFÍCIL': 'DIFÍCIL',
    'MUY DIFÍCIL': 'MUY DIFÍCIL',
    'CANTO DE JIZO': 'CANTO DE JIZO',
    'CARGAR': 'CARGAR',
    '¿Cuál quieres cargar?': '¿Cuál quieres cargar?',
    'backup_error': 'Los datos guardados\nno son válidos.\nSe borrará el archivo.',
    'jizo_prompt': '¡Introduce el canto de Jizo!',
    'jizo_error': '¡El canto de Jizo no es correcto!\nCompruébalo bien\ne inténtalo otra vez.',
}
length_lines = []
for k, v in texts_for_lengths.items():
    lines = v.split('\n')
    length_lines.append(f'- `{k}`: ' + ', '.join(str(vis_len(line)) for line in lines))
alloc_lines = []
for name, (off, cpu, length, data) in allocations.items():
    alloc_lines.append(f'- `{name}`: ROM `0x{off:05X}`, CPU `${cpu:04X}`, len `{length}`, bytes `{data.hex(" ")}`')
rec_lines = '\n'.join(f'- `0x{off:06X}` len `{len(buf)}`' for off, buf in records)
REPORT.write_text(f'''# Prueba v03 — textos del menú/password con repointing

ROM de prueba:

`Roms/Pruebas/{OUT.name}`

IPS de prueba acumulativo contra ROM limpia:

`Parches/Pruebas/{IPS.name}`

## Base

Parte de `traduccion_v02`, ya confirmada.

## Objetivo

Primera prueba para quitar la limitación de espacio de los textos del menú/password. Los textos españoles se escriben en la zona libre `0x1F838-0x20000` y se parchean punteros/tablas para apuntar allí.

## Textos insertados

### Selector principal

```text
FÁCIL
NORMAL
DIFÍCIL
MUY DIFÍCIL

CANTO DE JIZO
CARGAR
```

### Selector de carga

```text
¿Cuál quieres cargar?
```

### Error de backup RAM

```text
Los datos guardados
no son válidos.
Se borrará el archivo.
```

### Password / Jizo

```text
¡Introduce el canto de Jizo!

¡El canto de Jizo no es correcto!
Compruébalo bien
e inténtalo otra vez.
```

## Longitudes visibles aproximadas por línea

{chr(10).join(length_lines)}

Nota: el prompt `¡Introduce el canto de Jizo!` y la primera línea del error son deliberadamente largos. Esta prueba sirve también para confirmar si la caja superior/error necesita ampliación visual.

## Asignaciones nuevas

{chr(10).join(alloc_lines)}

Espacio usado en zona libre: `{alloc - alloc_start}` bytes de `{alloc_end - alloc_start}` disponibles.

## Punteros/código parcheados

- Tabla dificultad `$54AE`: apunta a `FÁCIL/NORMAL/DIFÍCIL/MUY DIFÍCIL`.
- Tabla opciones `$54EB`: apunta a `CANTO DE JIZO/CARGAR`.
- Tabla carga `$5501`: apunta a pregunta de carga + dificultad.
- Código password `CD10` y `CD47`: prompt Jizo relocalizado.
- Código error `CE5F`: error Jizo relocalizado.
- Código error backup `C58D/C591`: error de backup relocalizado.

## Validación estática

- Zona libre original comprobada como `FF` antes de escribir.
- Texto nuevo total: `{alloc - alloc_start}` bytes.
- No se pisa la tabla runtime/password de v02.
- IPS acumulativo generado contra ROM limpia.

## Regiones cambiadas en IPS

{rec_lines}

## Qué comprobar

1. Pantalla/selector anterior al password: que se lean `CANTO DE JIZO` y `CARGAR`.
2. Selector de carga: que se lea la pregunta y las dificultades.
3. Mensaje de backup inválido si puedes forzarlo/verlo.
4. Pantalla de password: si `¡Introduce el canto de Jizo!` aparece completo o se sale de la caja.
5. Password incorrecto: si el mensaje largo aparece, dónde se corta/desborda y si hay que ampliar caja.
6. Confirmar que v02 no se ha roto: parrilla, opciones y navegación.
''', encoding='utf-8')

print('OUT', OUT)
print('IPS', IPS)
print('REPORT', REPORT)
print('alloc used', alloc - alloc_start, 'next', hex(alloc))
for line in alloc_lines:
    print(line)
print('records', len(records), 'changed bytes', sum(len(b) for _, b in records))
