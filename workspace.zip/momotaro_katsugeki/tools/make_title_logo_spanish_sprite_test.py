#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
ASSET=ROOT/'title_assets/title_logo_es_fullscreen.png'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_sprite_test.pce'
IPS=ROOT/'Parches/momotaro_title_logo_spanish_sprite_test.ips'
PREVIEW=ROOT/'images/title_logo_spanish_sprite_test_preview.png'
REPORT=ROOT/'reports/test_rotulo_titulo_sprite.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
asset=Image.open(ASSET).convert('RGBA')
# Sprite canvas for full screen top logo: 256 x 64, using the user's absolute placement.
# Existing title logo sprite area begins at approximately y=27; user logo bbox is y=35..90.
Y0=27
canvas=Image.new('P',(256,64),0)
# Map user RGBA colors to sprite color indices. This is provisional; structure test first.
color_map={
    (0,0,0):8,          # black/dark
    (0,36,182):5,       # deep blue
    (0,146,219):7,      # cyan/highlight
    (219,182,0):10,     # yellow/gold
    (146,73,36):2,      # brown/shadow
    (219,36,109):14,
    (255,109,255):15,
    (255,73,146):14,
    (255,146,109):11,
    (219,182,219):13,
    (73,109,36):12,
}
# nearest fallback to color_map keys
def nearest_idx(rgb):
    if rgb in color_map: return color_map[rgb]
    best=min(color_map, key=lambda c: sum((rgb[i]-c[i])**2 for i in range(3)))
    return color_map[best]
for y in range(64):
    sy=Y0+y
    if sy<0 or sy>=asset.height: continue
    for x in range(256):
        r,g,b,a=asset.getpixel((x,sy))
        if a==0: continue
        canvas.putpixel((x,y), nearest_idx((r,g,b)))

def encode_bg_tile_8(pix8):
    # PCE 8x8 4bpp BG/tile format used by the game's sprite stream compressor chunks.
    out1=[]; out2=[]
    for y in range(8):
        b=[0,0,0,0]
        for x in range(8):
            c=pix8[y][x]; bit=7-x
            for p in range(4): b[p]|=((c>>p)&1)<<bit
        out1.extend([b[0],b[1]]); out2.extend([b[2],b[3]])
    return bytes(out1+out2)

def encode_pattern_16_from_canvas(img,x0,y0):
    # 16x16 pattern as four 8x8 BG tiles: TL, TR, BL, BR.
    data=bytearray()
    for ty,tx in [(0,0),(0,8),(8,0),(8,8)]:
        pix=[]
        for y in range(8):
            pix.append([img.getpixel((x0+tx+x,y0+ty+y)) for x in range(8)])
        data += encode_bg_tile_8(pix)
    return bytes(data)

def compress_pattern(raw128):
    # Inverse of the game's C861F style stream: four 8x8 chunks, substreams at 0,1,16,17.
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw128[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v!=0:
                        mask|=1<<bit; payload.append(v)
                else:
                    if v!=prev:
                        mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out += bytes(payload)
    return bytes(out)
# Pattern order matches custom list: 8 columns, each column has 2x4 patterns (row*2+col).
patterns=[None]*64
for col in range(8):
    base=col*8
    for row in range(4):
        patterns[base+row*2+0]=encode_pattern_16_from_canvas(canvas,col*32,row*16)
        patterns[base+row*2+1]=encode_pattern_16_from_canvas(canvas,col*32+16,row*16)
stream=bytearray([64]); lens=[]
for pat in patterns:
    c=compress_pattern(pat); lens.append(len(c)); stream+=c
# Original title logo stream is at 0x252C8 and next stream starts 0x2617B, max 3763 bytes.
orig_stream_start=0x252C8; orig_stream_end=0x2617B; max_len=orig_stream_end-orig_stream_start
if len(stream)>max_len:
    # Relocate if needed to bank17 free area and patch C7D7 loader would be required.
    raise SystemExit(f'Stream too large {len(stream)} > {max_len}. Need relocation.')
rom[orig_stream_start:orig_stream_start+len(stream)]=stream
rom[orig_stream_start+len(stream):orig_stream_end]=bytes([0xFF])*(max_len-len(stream))
# Patch the logo metasprite list at bank17 CPU $42B0 (ROM 0x2E2B0) to 8 32x64 sprites covering x 0..255.
list_off=0x2E2B0
entries=bytearray()
# visible x = base_x(128)+dx; use x=0,32...224; dy=-61 like original large entries => y around top region.
for col,tile in enumerate([0,8,16,24,32,40,48,56]):
    dx=-128+col*32
    dy=0xC3  # -61, original main logo vertical offset
    entries += bytes([tile,0x04,0x31,dx&0xFF,dy])
entries += b'\xFF'
# Pad old 51-byte list area with FF.
rom[list_off:list_off+51]=entries+bytes([0xFF])*(51-len(entries))
OUT.write_bytes(rom)
# IPS vs original clean.
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xFFFF:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
# Preview with approximate palette.
pal=[(0,0,80),(255,255,255),(146,73,36),(0,0,0),(0,36,182),(0,36,182),(0,146,219),(0,146,219),(0,0,0),(80,80,80),(219,182,0),(255,146,109),(73,109,36),(219,182,219),(219,36,109),(255,109,255)]
prev=Image.new('RGB',(256,64),(0,0,80))
for y in range(64):
    for x in range(256):
        prev.putpixel((x,y),pal[canvas.getpixel((x,y))])
PREVIEW.parent.mkdir(exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Test del rótulo principal del título como sprites\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Qué hace\n\nSustituye el stream gráfico del logo japonés principal por el rótulo español `MOMOTARO EN ACCIÓN` entregado por el usuario.\n\n## Datos\n\n- Asset fuente: `title_assets/title_logo_es_fullscreen.png`.\n- Región tomada del asset: pantalla completa, filas `{Y0}..{Y0+63}`.\n- Stream original: `0x{orig_stream_start:05X}-0x{orig_stream_end-1:05X}` ({max_len} bytes).\n- Stream nuevo: `{len(stream)}` bytes.\n- Patrones: 64 de 16x16.\n- Metasprite list parcheada: ROM `0x{list_off:05X}`, 8 sprites de 32x64.\n\n## Notas\n\nLa posición y estructura deberían ser razonables. Los colores son provisionales porque aún no hemos volcado la paleta real de sprites del título; el mapeo de índices se ajustará tras ver captura.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream len',len(stream),'max',max_len,'lens minmax',min(lens),max(lens),'sum',sum(lens)+1)
print('records',len(records),sum(len(b) for _,b in records))
print('OUT',OUT)
