#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_test.pce'
if not BASE.exists():
    BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_main_selector_box_probe.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v04_main_selector_box_probe.ips'
REPORT=ROOT/'reports/test_v04_main_selector_box_probe.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)
# Relocalizar sólo la lista de sprites del selector principal (estado 1) desde $4AEE.
# La tabla $4AB9 tiene punteros por estado: estado 0=$4ADF, estado 1=$4AEE, estado2/3=$4AC1.
# Esta prueba NO toca generación de texto ni strings; sólo amplia el marco/ventana del selector inicial.
new_cpu=0x5A59
new_off=0x2E000+(new_cpu-0x4000)
# Estado 1 original (dos filas). Se amplía horizontalmente con un segmento extra.
# Orden original: fila baja/superior según el motor. Se preserva orden relativo.
# Original:
# 05 0E 00 00 10 / 06 0E 01 10 10 / 08 0E 01 30 10
# 00 0E 01 00 00 / 02 0E 01 20 00 / 04 0E 00 40 00
# Nuevo: más ancho a la derecha, sin mover X base.
new_list=bytes.fromhex(
    '05 0E 00 00 10 '
    '06 0E 01 10 10 '
    '06 0E 01 30 10 '
    '08 0E 01 60 10 '
    '00 0E 01 00 00 '
    '02 0E 01 20 00 '
    '02 0E 01 40 00 '
    '04 0E 00 60 00 '
    'FF'
)
assert base[new_off:new_off+len(new_list)] == bytes([0xFF])*len(new_list), (hex(new_off), base[new_off:new_off+len(new_list)].hex())
rom[new_off:new_off+len(new_list)] = new_list
# Parchar puntero estado 1 en tabla $4AB9: ROM 0x2EABB/0x2EABC.
assert rom[0x2EABB:0x2EABD] in (bytes.fromhex('EE 4A'), bytes.fromhex('59 5A'))
rom[0x2EABB:0x2EABD] = bytes([new_cpu&0xff, new_cpu>>8])
# Validar que no se toca estado 0 ni estado 2/3.
assert rom[0x2EAB9:0x2EABB] == base[0x2EAB9:0x2EABB]
assert rom[0x2EABD:0x2EAC1] == base[0x2EABD:0x2EAC1]
# Output IPS contra original.
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
# Diff contra base.
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
REPORT.write_text(f'''# v04 main selector box probe

ROM:
`Roms/Pruebas/{OUT.name}`

IPS:
`Parches/Pruebas/{IPS.name}`

## Objetivo

Primera prueba cautelosa: tocar sólo el selector inicial `CANTO DE JIZO / CARGAR`.

No se toca la pantalla de carga ni la dificultad. No se cambian los strings. Sólo se amplia horizontalmente la lista de sprites del marco/ventana del estado 1.

## Cambios

- Lista original estado 1: CPU `$4AEE`.
- Nueva lista: CPU `${new_cpu:04X}`, ROM `0x{new_off:05X}`, len `{len(new_list)}`.
- Puntero en tabla `$4AB9` estado 1: `0x2EABB-0x2EABC` -> `${new_cpu:04X}`.

## Qué comprobar

1. En el selector inicial, si la caja de `CANTO DE JIZO / CARGAR` se ensancha.
2. Si aparece más texto de `CANTO DE JIZO` o sigue cortado igual.
3. Que la pantalla de dificultad sigue igual.
4. Que la pantalla de carga no cambia todavía.
5. Que no hay corrupción en título ni password.

## Cambios contra base de prueba

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('new list',hex(new_off),new_list.hex(' '))
print('changed vs base',changed)
print('records',len(rec),'bytes',sum(len(b) for _,b in rec))
