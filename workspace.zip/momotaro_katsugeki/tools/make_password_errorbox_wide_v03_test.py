#!/usr/bin/env python3
from pathlib import Path

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT = ROOT / 'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_errorbox_wide_test.pce'
IPS = ROOT / 'Parches/Pruebas/momotaro_traduccion_v03_errorbox_wide_test.ips'
REPORT = ROOT / 'reports/test_password_errorbox_wide_v03.md'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())
base_bytes = BASE.read_bytes()

# --- Latin encoder ---------------------------------------------------------
CHAR_TO_CODE = {' ': 0x20}
for i in range(10): CHAR_TO_CODE[str(i)] = 0x30 + i
for i in range(26): CHAR_TO_CODE[chr(ord('A') + i)] = 0x41 + i
CHAR_TO_CODE.update({'!': 0x21, '?': 0x3F, '$': 0x24})
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'): CHAR_TO_CODE[ch] = 0xA1 + i
CHAR_TO_CODE['b'] = 0x5B; CHAR_TO_CODE['c'] = 0x5D; CHAR_TO_CODE['p'] = 0x5E
CHAR_TO_CODE.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

def enc_text(s: str) -> bytes:
    out = bytearray(); i = 0
    while i < len(s):
        if s[i] == '\n': out.append(0x00); i += 1; continue
        if s.startswith('<WAIT>', i): out.append(0xFD); i += 6; continue
        if s.startswith('<MODE>', i): out.append(0xFE); i += 6; continue
        ch = s[i]
        if ch not in CHAR_TO_CODE:
            raise ValueError(f'Carácter no soportado: {ch!r}')
        out.append(CHAR_TO_CODE[ch]); i += 1
    return bytes(out)

def cpu_from_rom_bank0f(off:int)->int:
    assert 0x1E000 <= off < 0x20000
    return 0x4000 + (off - 0x1E000)

def ptr_bytes(cpu:int)->bytes:
    return bytes([cpu & 0xff, cpu >> 8])

def rle_encode(vals):
    out=bytearray(); i=0
    while i<len(vals):
        v=vals[i]; j=i+1
        while j<len(vals) and vals[j]==v and j-i<256: j+=1
        L=j-i
        if L>=3 or v==0xff: out += bytes([0xff,L-1,v])
        else: out += bytes([v])*L
        i=j
    return bytes(out)

# --- Allocate translated texts in bank $0F free area -----------------------
alloc_start=0x1F838; alloc_end=0x20000
assert orig[alloc_start:alloc_end] == bytes([0xFF])*(alloc_end-alloc_start)
alloc=alloc_start; allocations={}

def put_string(name,payload,term=0x00):
    global alloc
    off=alloc; data=payload+bytes([term])
    assert off+len(data)<=alloc_end
    assert orig[off:off+len(data)] == bytes([0xFF])*len(data)
    rom[off:off+len(data)] = data
    allocations[name]=(off,cpu_from_rom_bank0f(off),len(data),data)
    alloc += len(data)
    return cpu_from_rom_bank0f(off)

PFX1=bytes([0x01,0x3C]); PFX2=bytes([0x02,0x3C])
diff_facil=put_string('diff_facil',PFX1+enc_text('FÁCIL'),0x00)
diff_normal=put_string('diff_normal',PFX1+enc_text('NORMAL'),0x00)
diff_dificil=put_string('diff_dificil',PFX1+enc_text('DIFÍCIL'),0x00)
diff_muy_dificil=put_string('diff_muy_dificil',PFX2+enc_text('MUY DIFÍCIL'),0x00)
empty=put_string('empty',b'',0x00)
menu_jizo=put_string('menu_jizo',PFX1+enc_text('CANTO DE JIZO'),0x00)
menu_cargar=put_string('menu_cargar',PFX2+enc_text('CARGAR'),0x00)
load_question=put_string('load_question',bytes([0x01])+enc_text('¿Cuál quieres cargar?'),0x00)
backup_error=put_string('backup_error', bytes([0x01])+enc_text('Los datos guardados\nno son válidos.\nSe borrará el archivo.'), 0xFF)
# Prompt still needs top-box work; keep final full text in one line for this test.
jizo_prompt=put_string('jizo_prompt', bytes([0x01])+enc_text('¡Introduce el canto de Jizo!'), 0xFF)
# Error text wrapped for the wider 4-line box, no scroll/pagination.
jizo_error=put_string('jizo_error', bytes([0x01])+enc_text('¡El canto de Jizo no\nes correcto!\nCompruébalo bien\ne inténtalo otra vez.'), 0xFF)

# --- Repoint menu/load/Jizo texts -----------------------------------------
rom[0x1F4AE:0x1F4AE+10] = b''.join(ptr_bytes(p) for p in [diff_facil,diff_normal,diff_dificil,diff_muy_dificil,empty])
rom[0x1F4EB:0x1F4EB+4] = ptr_bytes(menu_jizo)+ptr_bytes(menu_cargar)
rom[0x1F501:0x1F501+12] = b''.join(ptr_bytes(p) for p in [load_question,diff_facil,diff_normal,diff_dificil,diff_muy_dificil,empty])
# Direct code refs.
for off,cpu in [(0x1AD11,jizo_prompt),(0x1AD48,jizo_prompt),(0x1AE60,jizo_error)]: rom[off]=cpu&0xff
for off,cpu in [(0x1AD15,jizo_prompt),(0x1AD4C,jizo_prompt),(0x1AE64,jizo_error)]: rom[off]=cpu>>8
rom[0x1A58E]=backup_error&0xff; rom[0x1A592]=backup_error>>8

# --- Widen central Jizo error box tilemap stream ---------------------------
# Original central box stream at $429C draws rows 13..19 cols 9..25.
# New box: rows 11..20, cols 7..30, with the same left speech tail.
tm=[[0 for _ in range(32)] for __ in range(32)]
left,right,top,bottom=7,30,11,20
# Top/bottom
for c in range(left,right+1):
    tm[top][c] = 2
    tm[bottom][c] = 7
tm[top][left]=1; tm[top][right]=3; tm[bottom][left]=6; tm[bottom][right]=8
# Sides/fill
for r in range(top+1,bottom):
    tm[r][left]=4; tm[r][right]=5
    for c in range(left+1,right): tm[r][c]=9
# Speech tail moved to vertical center.
tm[15][left-1]=10; tm[15][left]=11
# Preserve fill after the tail connector.
for c in range(left+1,right): tm[15][c]=9
tm[15][right]=5
tm[16][left-1]=12; tm[16][left]=13
for c in range(left+1,right): tm[16][c]=9
tm[16][right]=5
low=[]
for r in range(32):
    for c in range(32): low.append(tm[r][c])
errbox_stream=rle_encode(low)
# Put stream after translated strings, aligned minimally.
if alloc < 0x1F940: alloc = 0x1F940
errbox_off=alloc; errbox_cpu=cpu_from_rom_bank0f(errbox_off)
assert errbox_off+len(errbox_stream)<=alloc_end
assert orig[errbox_off:errbox_off+len(errbox_stream)] == bytes([0xFF])*len(errbox_stream)
rom[errbox_off:errbox_off+len(errbox_stream)] = errbox_stream
alloc = errbox_off+len(errbox_stream)
# Patch CE14 low stream pointer; keep original high stream $42DF (all-zero high bits).
rom[0x1AE1C]=errbox_cpu&0xff; rom[0x1AE20]=errbox_cpu>>8

# --- Add 4-line text address table for the error text engine ---------------
# Original CE90 has three starts: $7008, $7208, $7408; there is no room for a 4th.
# Relocate table to free bank $0D space after v02 data.
line_table_off=0x1BDB0; line_table_cpu=0xDDB0
line_table=bytes([0x08,0x70, 0x08,0x72, 0x08,0x74, 0x08,0x76])
assert orig[line_table_off:line_table_off+len(line_table)] == bytes([0xFF])*len(line_table)
# In v02 this area should still be free.
assert base_bytes[line_table_off:line_table_off+len(line_table)] == bytes([0xFF])*len(line_table)
rom[line_table_off:line_table_off+len(line_table)] = line_table
# Patch references: CE67 LDA table, CE6F LDA table+1, CEF3/CEF8 newline loader.
refs=[(0x1AE68,line_table_cpu),(0x1AE70,line_table_cpu+1),(0x1AEF4,line_table_cpu),(0x1AEF9,line_table_cpu+1)]
for off,cpu in refs:
    rom[off]=cpu&0xff; rom[off+1]=cpu>>8
# Try clearing a slightly wider/taller dynamic text area when FE is used.
rom[0x1AF40]=0x0C  # CF3F CPX #$08 -> #$0C
rom[0x1AF55]=0x18  # CF54 CPY #$10 -> #$18

# --- Output ----------------------------------------------------------------
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)

alloc_lines='\n'.join(f'- `{name}`: ROM `0x{off:05X}`, CPU `${cpu:04X}`, len `{ln}`' for name,(off,cpu,ln,data) in allocations.items())
REPORT.write_text(f'''# Prueba v03 — bocadillo de error de Jizo ampliado

ROM de prueba:

`Roms/Pruebas/{OUT.name}`

IPS:

`Parches/Pruebas/{IPS.name}`

## Objetivo

Probar el enfoque nuevo: ampliar caja/área real antes de depender de scroll. Esta prueba se centra en el bocadillo central del error de canto de Jizo.

## Cambios

- Repointing de textos a zona libre, como en la prueba anterior.
- Caja central del error redibujada por tilemap: de `17x7` tiles aprox. a `24x10` tiles aprox.
- Área útil buscada: unas 21-22 columnas, dejando margen derecho.
- Tabla de líneas del texto de error relocalizada y ampliada a 4 líneas (`$7008,$7208,$7408,$7608`).
- Texto de error sin scroll, repartido en 4 líneas:

```text
¡El canto de Jizo no
es correcto!
Compruébalo bien
e inténtalo otra vez.
```

El prompt superior `¡Introduce el canto de Jizo!` sigue pendiente de ampliación de caja superior; en esta prueba se mantiene en una línea para confirmar que sólo se arregla el error central.

## Asignaciones de texto

{alloc_lines}

## Datos nuevos

- Stream RLE de caja central: ROM `0x{errbox_off:05X}`, CPU `${errbox_cpu:04X}`, len `{len(errbox_stream)}`.
- Tabla de 4 líneas: ROM `0x{line_table_off:05X}`, CPU `${line_table_cpu:04X}`, len `{len(line_table)}`.
- Espacio total usado en zona libre de bank `$0F`: hasta `0x{alloc:05X}`.

## Qué comprobar

1. Que la caja central del error es más ancha/alta.
2. Que el mensaje de error completo cabe sin sobrescrituras.
3. Que queda margen derecho y no pasa lo de `bien` pegado al borde.
4. Si la cola/bocadillo no pisa mal a Momotarou.
5. El prompt superior probablemente seguirá cortándose: es conocido y será el siguiente objetivo.
6. Que v02 sigue intacta en parrilla/opciones.
''',encoding='utf-8')

print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('errbox stream',hex(errbox_off),errbox_cpu,len(errbox_stream))
print('line table',hex(line_table_off),hex(line_table_cpu),line_table.hex(' '))
print('alloc next',hex(alloc),'used bank0F',alloc-alloc_start)
print('records',len(records),'changed',sum(len(b) for _,b in records))
