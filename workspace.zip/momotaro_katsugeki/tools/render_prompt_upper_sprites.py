#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0, '/home/user/momotaro_katsugeki')
from PIL import Image, ImageDraw, ImageFont
from tools.libretro_pce_runner import Runner

ROOT=Path('/home/user/momotaro_katsugeki')
ROM=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_prep_ba8a_test.pce'
OUTDIR=ROOT/'images/prompt_upper_sprites'
REPORT=ROOT/'reports/prompt_upper_sprites_4b33.md'
OUTDIR.mkdir(parents=True,exist_ok=True)

def s8(b): return b-256 if b>=128 else b

def render16(vram, pat, hflip=False, vflip=False, scale=1, transparent=(32,36,255)):
    im=Image.new('RGBA',(16,16),(0,0,0,0))
    pix=im.load(); base=pat*0x40
    for y in range(16):
        yy=15-y if vflip else y
        p0=vram[base+yy]; p1=vram[base+16+yy]; p2=vram[base+32+yy]; p3=vram[base+48+yy]
        for x in range(16):
            xx=15-x if hflip else x
            bit=15-xx
            c=((p0>>bit)&1)|(((p1>>bit)&1)<<1)|(((p2>>bit)&1)<<2)|(((p3>>bit)&1)<<3)
            if c==0:
                pix[x,y]=(0,0,0,0)
            elif c==15:
                pix[x,y]=(255,255,255,255)
            else:
                # Use grayscale index so nontransparent black/fill remains visible against checker.
                val=20+c*12
                pix[x,y]=(val,val,val,255)
    if scale!=1:
        im=im.resize((16*scale,16*scale),Image.Resampling.NEAREST)
    return im

def render_sprite(vram, pat, flags, scale=1):
    width32 = bool(flags & 0x0100)
    hflip = bool(flags & 0x0800)
    vflip = bool(flags & 0x8000)
    # All relevant prompt pieces are 16px high.
    w=32 if width32 else 16
    out=Image.new('RGBA',(w,16),(0,0,0,0))
    if width32:
        # PCE order for 32-wide sprites: left half pattern even/no|0, right half no|1; flipped swaps.
        base=pat & ~1
        left_pat = base ^ (1 if hflip else 0)
        right_pat = (base | 1) ^ (1 if hflip else 0)
        out.paste(render16(vram,left_pat,hflip=hflip,vflip=vflip),(0,0),render16(vram,left_pat,hflip=hflip,vflip=vflip))
        r=render16(vram,right_pat,hflip=hflip,vflip=vflip)
        out.paste(r,(16,0),r)
    else:
        r=render16(vram,pat,hflip=hflip,vflip=vflip)
        out.paste(r,(0,0),r)
    if scale!=1:
        out=out.resize((w*scale,16*scale),Image.Resampling.NEAREST)
    return out

def checker(w,h,scale=8):
    im=Image.new('RGB',(w,h),(40,40,180)); p=im.load()
    for y in range(h):
        for x in range(w):
            if ((x//scale)+(y//scale))&1:
                p[x,y]=(32,36,255)
            else:
                p[x,y]=(20,24,160)
    return im.convert('RGBA')

# Run to password screen and capture VRAM/SAT.
ev={60:[3],64:[],100:[7],104:[],140:[3],144:[]}
r=Runner(ROM, OUTDIR/'run')
r.run(360, ev)
vram=r.vram_words(); sat=r.sat_words(); r.close()

# Relocated $4B33 list from current ROM.
rom=ROM.read_bytes()
list_off=0x1FA00
entries=[]; pos=list_off; idx=0
while rom[pos] != 0xFF and idx < 80:
    b=rom[pos:pos+5]
    pat=0x1A4 + b[0]
    flags=b[1] | (b[2]<<8)
    xoff=s8(b[3]); yoff=s8(b[4])
    raw_x=0x58+xoff; raw_y=0x80+yoff
    screen_x=raw_x-0x20; screen_y=raw_y-0x40
    width=32 if (flags&0x0100) else 16
    hflip=bool(flags&0x0800); vflip=bool(flags&0x8000)
    entries.append(dict(idx=idx, off=pos, bytes=b, pat=pat, flags=flags, xoff=xoff, yoff=yoff, raw_x=raw_x, raw_y=raw_y, screen_x=screen_x, screen_y=screen_y, width=width, hflip=hflip, vflip=vflip))
    pos+=5; idx+=1
# Top prompt section in our relocated list: 0-6 text, 7-22 frame.
top_entries=entries[:23]
text_entries=entries[:7]
frame_entries=entries[7:23]

# Individual sheet all top entries.
scale=4; cell_w=42*scale; cell_h=36*scale; label_h=26
sheet=Image.new('RGB',(len(top_entries)*cell_w, cell_h+label_h),(225,225,225)); d=ImageDraw.Draw(sheet)
for i,e in enumerate(top_entries):
    spr=render_sprite(vram,e['pat'],e['flags'],scale=scale)
    bg=checker(cell_w,cell_h,scale=8)
    x=i*cell_w
    sheet.paste(bg,(x,label_h))
    sheet.alpha_composite(spr,(x+4*scale,label_h+8*scale)) if sheet.mode=='RGBA' else None
# Need RGBA compose then convert
sheet_rgba=Image.new('RGBA',sheet.size,(225,225,225,255)); d=ImageDraw.Draw(sheet_rgba)
for i,e in enumerate(top_entries):
    x=i*cell_w
    sheet_rgba.paste(checker(cell_w,cell_h,scale=8),(x,label_h))
    spr=render_sprite(vram,e['pat'],e['flags'],scale=scale)
    sheet_rgba.alpha_composite(spr,(x+4*scale,label_h+8*scale))
    kind='TXT' if i<7 else 'BOX'
    d.text((x+2,2),f"{i:02d} {kind} pat {e['pat']:03X}",fill=(0,0,0))
    d.text((x+2,13),f"x={e['screen_x']} y={e['screen_y']} w={e['width']}",fill=(0,0,0))
all_sheet=OUTDIR/'all_top_entries_order.png'
sheet_rgba.convert('RGB').save(all_sheet)

# Frame-only pieces sheet.
cols=8; cell_w=48*scale; cell_h=36*scale; rows=(len(frame_entries)+cols-1)//cols
fs=Image.new('RGBA',(cols*cell_w,rows*(cell_h+label_h)),(225,225,225,255)); df=ImageDraw.Draw(fs)
for j,e in enumerate(frame_entries):
    c=j%cols; rr=j//cols; x=c*cell_w; y=rr*(cell_h+label_h)
    fs.paste(checker(cell_w,cell_h,scale=8),(x,y+label_h))
    spr=render_sprite(vram,e['pat'],e['flags'],scale=scale)
    fs.alpha_composite(spr,(x+8*scale,y+8*scale+label_h))
    df.text((x+2,y+2),f"{e['idx']:02d} pat {e['pat']:03X}",fill=(0,0,0))
    df.text((x+2,y+13),f"x={e['screen_x']} y={e['screen_y']} flags={e['flags']:04X}",fill=(0,0,0))
frame_sheet=OUTDIR/'frame_pieces_order.png'
fs.convert('RGB').save(frame_sheet)

# Compose montage: actual top entries at screen positions, plus enlarged crop.
minx=min(e['screen_x'] for e in top_entries); maxx=max(e['screen_x']+e['width'] for e in top_entries)
miny=min(e['screen_y'] for e in top_entries); maxy=max(e['screen_y']+16 for e in top_entries)
pad=12
mont=Image.new('RGBA',(maxx-minx+2*pad,maxy-miny+2*pad),(32,36,255,255))
for e in top_entries:
    spr=render_sprite(vram,e['pat'],e['flags'],scale=1)
    mont.alpha_composite(spr,(e['screen_x']-minx+pad,e['screen_y']-miny+pad))
mont_scaled=mont.resize((mont.width*4,mont.height*4),Image.Resampling.NEAREST)
dm=ImageDraw.Draw(mont_scaled)
# draw grid bbox around entries scaled
for e in top_entries:
    x=(e['screen_x']-minx+pad)*4; y=(e['screen_y']-miny+pad)*4; w=e['width']*4; h=16*4
    color=(255,0,0) if e['idx']<7 else (0,255,0)
    dm.rectangle([x,y,x+w-1,y+h-1],outline=color,width=1)
    dm.text((x+1,y+1),str(e['idx']),fill=color)
montage=OUTDIR/'assembled_prompt_box_and_text.png'
mont_scaled.convert('RGB').save(montage)

# Frame-only montage.
montf=Image.new('RGBA',(maxx-minx+2*pad,maxy-miny+2*pad),(32,36,255,255))
for e in frame_entries:
    spr=render_sprite(vram,e['pat'],e['flags'],scale=1)
    montf.alpha_composite(spr,(e['screen_x']-minx+pad,e['screen_y']-miny+pad))
montf_scaled=montf.resize((montf.width*4,montf.height*4),Image.Resampling.NEAREST)
frame_montage=OUTDIR/'assembled_frame_only.png'
montf_scaled.convert('RGB').save(frame_montage)

# Write CSV/MD report.
md=[]
md.append('# Prompt superior — sprites/lista $4B33 renderizados\n')
md.append(f'ROM analizada: `{ROM}`\n')
md.append(f'Lista relocalizada: ROM `0x{list_off:05X}`; entradas hasta FF: `{len(entries)}`.\n')
md.append('## Imágenes\n')
md.append(f'- Todas las entradas superiores en orden: `images/prompt_upper_sprites/{all_sheet.name}`\n')
md.append(f'- Sólo piezas de marco en orden: `images/prompt_upper_sprites/{frame_sheet.name}`\n')
md.append(f'- Montaje completo texto+marco: `images/prompt_upper_sprites/{montage.name}`\n')
md.append(f'- Montaje sólo marco: `images/prompt_upper_sprites/{frame_montage.name}`\n')
md.append('## Formato de entrada\n')
md.append('Cada entrada son 5 bytes: `[pattern offset][attr/palette][flags hi][x offset][y offset]`. Los offsets X/Y son con signo. En esta lista, el patrón base usado es aproximadamente `$1A4`; por tanto `0A -> 1AE`, etc.\n')
md.append('## Entradas superiores\n')
md.append('| idx | tipo | bytes | patrón | flags | xoff | yoff | screen X | screen Y | tamaño | flip |\n')
md.append('|---:|---|---|---:|---:|---:|---:|---:|---:|---|---|\n')
for e in top_entries:
    kind='texto' if e['idx']<7 else 'marco'
    flip=('H' if e['hflip'] else '')+('V' if e['vflip'] else '') or '-'
    md.append(f"| {e['idx']} | {kind} | `{e['bytes'].hex(' ')}` | `{e['pat']:03X}` | `{e['flags']:04X}` | {e['xoff']} | {e['yoff']} | {e['screen_x']} | {e['screen_y']} | {e['width']}x16 | {flip} |\n")
REPORT.write_text(''.join(md),encoding='utf-8')
print('wrote')
print(all_sheet)
print(frame_sheet)
print(montage)
print(frame_montage)
print(REPORT)
