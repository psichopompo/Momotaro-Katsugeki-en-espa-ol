#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_nav_test.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v03_prompt_nav_test.ips'
REPORT=ROOT/'reports/test_password_prompt_nav_v03.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)
# Encoder latino validado
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i in range(26): enc[chr(65+i)]=0x41+i
enc.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s):
    out=bytearray()
    for ch in s:
        if ch=='\n': out.append(0)
        else: out.append(enc[ch])
    return bytes(out)
def cpu0f(off):
    assert 0x1E000 <= off < 0x20000
    return 0x4000+(off-0x1E000)
def rle_encode(vals):
    out=bytearray(); i=0
    while i<len(vals):
        v=vals[i]; j=i+1
        while j<len(vals) and vals[j]==v and j-i<256: j+=1
        L=j-i
        if L>=3 or v==0xff: out += bytes([0xff,L-1,v])
        else: out += bytes([v])*L
        i=j
    return bytes(out)
# Fixed text proven visible with viewport20.
text='¡El canto de Jizo\nno es correcto!\nRevísalo bien e\ninténtalo de nuevo.'
line_lengths=[len(x) for x in text.split('\n')]
error_off=0x1F838; error_cpu=cpu0f(error_off)
data=bytes([1])+enc_text(text)+bytes([0xFF])
assert orig[error_off:error_off+len(data)]==bytes([0xFF])*len(data)
rom[error_off:error_off+len(data)]=data
rom[0x1AE60]=error_cpu&0xff; rom[0x1AE64]=error_cpu>>8
# Four line starts with 5 chunks / 20 char stride.
lt_off=0x1BDB0; lt_cpu=0xDDB0
lt=bytes([0x08,0x70, 0x88,0x72, 0x08,0x75, 0x88,0x77])
assert orig[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
assert base[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
rom[lt_off:lt_off+len(lt)]=lt
for off,cpu in [(0x1AE68,lt_cpu),(0x1AE70,lt_cpu+1),(0x1AEF4,lt_cpu),(0x1AEF9,lt_cpu+1)]:
    rom[off]=cpu&0xff; rom[off+1]=cpu>>8
# Viewport 5 columns x 4 lines, safe bank $0F.
vp_off=0x1F900; vp_cpu=cpu0f(vp_off)
vp=bytearray(); xoffs=[0x00,0x20,0x40,0x60,0x7F]
for row in range(4):
    for col,xoff in enumerate(xoffs):
        vp += bytes([(row*5+col)*2,0x0E,0x01,xoff,row*0x10])
vp.append(0xFF)
assert len(vp)==101
assert orig[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
assert base[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
rom[vp_off:vp_off+len(vp)]=vp
# CF59: use bank $0F and viewport pointer. Move text with the whole block:
# X $48 -> $43 (-5 px more), Y stays $58.
rom[0x1AF5A]=0x0F
rom[0x1AF61]=0x46
rom[0x1AF63]=0x58
rom[0x1AF68]=vp_cpu&0xff
rom[0x1AF6C]=vp_cpu>>8
# Move the Jizo statue/Momotaro sprite block with the bubble/text.
# CE2E originally uses X=$2C, Y=$78. Previous test used X=$24/Y=$68; now X=$1F (-5 px more).
rom[0x1AE2F]=0x1D
rom[0x1AE31]=0x68
# Bubble expansion: keep original left/top/tail, expand right +3 tiles and bottom +2 tiles.
# Original central bubble: left=9, right=25, top=13, bottom=19.
# New: left=9, right=28, top=13, bottom=21.
tm=[[0 for _ in range(32)] for __ in range(32)]
left,right,top,bottom=8,27,11,19
for c in range(left,right+1):
    tm[top][c]=2; tm[bottom][c]=7
tm[top][left]=1; tm[top][right]=3; tm[bottom][left]=6; tm[bottom][right]=8
for r in range(top+1,bottom):
    tm[r][left]=4; tm[r][right]=5
    for c in range(left+1,right): tm[r][c]=9
# Tail/rabillo, now correctly relative to the shifted top.
# In the original box it was at top+3/top+4; the previous shift test left it
# at absolute rows 16/17 by mistake.
tail1 = top + 3
tail2 = top + 4
tm[tail1][left-1]=10; tm[tail1][left]=11
for c in range(left+1,right): tm[tail1][c]=9
tm[tail1][right]=5
tm[tail2][left-1]=12; tm[tail2][left]=13
for c in range(left+1,right): tm[tail2][c]=9
tm[tail2][right]=5
low=[]
for r in range(32):
    for c in range(32): low.append(tm[r][c])
bubble_stream=rle_encode(low)
bubble_off=0x1F970; bubble_cpu=cpu0f(bubble_off)
assert orig[bubble_off:bubble_off+len(bubble_stream)]==bytes([0xFF])*len(bubble_stream)
assert base[bubble_off:bubble_off+len(bubble_stream)]==bytes([0xFF])*len(bubble_stream)
rom[bubble_off:bubble_off+len(bubble_stream)]=bubble_stream
# CE14 pointer to low-stream; keep original high-stream all-zero.
rom[0x1AE1C]=bubble_cpu&0xff; rom[0x1AE20]=bubble_cpu>>8
# --- Prompt superior de password ------------------------------------------
# Texto final del prompt, para que la rutina genere todos los glifos.
prompt_text = '¡Introduce el canto de Jizo!'
prompt_off = 0x1F880
prompt_cpu = cpu0f(prompt_off)
prompt_data = bytes([1]) + enc_text(prompt_text) + bytes([0xFF])
assert orig[prompt_off:prompt_off+len(prompt_data)] == bytes([0xFF])*len(prompt_data)
assert base[prompt_off:prompt_off+len(prompt_data)] == bytes([0xFF])*len(prompt_data)
rom[prompt_off:prompt_off+len(prompt_data)] = prompt_data
# CD04/CD40 prompt pointers.
rom[0x1AD11] = prompt_cpu & 0xFF
rom[0x1AD15] = prompt_cpu >> 8
rom[0x1AD48] = prompt_cpu & 0xFF
rom[0x1AD4C] = prompt_cpu >> 8

# Viewport extra para el prompt superior. La línea se genera en patrones de
# sprite en torno a $6B84, cuyo raw pattern base es $035C.
# Usamos 7 chunks de 32 px para 28 caracteres. Los offsets X son con signo;
# para cubrir casi toda la pantalla se usa base X=$58 y offsets negativos/positivos.
prompt_wrapper_off = 0x1BC80
prompt_wrapper_cpu = 0xDC80
prompt_list_off = 0x1BCC0
prompt_list_cpu = 0xDCC0
prompt_list = bytearray()
for pat, xoff in zip([0x00,0x02,0x04,0x06,0x08,0x0A,0x0C], [0xC0,0xE0,0x00,0x20,0x40,0x60,0x7F]):
    prompt_list += bytes([pat, 0x0E, 0x01, xoff, 0x00])
prompt_list.append(0xFF)
# Wrapper de CD98: dibuja primero el sprite original de Momotaro/estatua inferior
# y después dibuja el viewport del prompt.
prompt_wrapper = bytearray([
    0x20, 0xEB, 0xE3,             # JSR $E3EB, original
    0xA2, 0x58,                   # LDX #$58, base X
    0xA0, 0x14,                   # LDY #$14, base Y
    0x20, 0x86, 0xEE,             # JSR $EE86
    0xA9, prompt_list_cpu & 0xFF, 0x85, 0x53,
    0xA9, prompt_list_cpu >> 8,   0x85, 0x54,
    0xA9, 0x5C,                   0x85, 0x55, # raw pattern base low $035C
    0xA9, 0x03,                   0x85, 0x56,
    0x64, 0x52,                   # STZ <$52
    0x4C, 0xEB, 0xE3,             # JMP $E3EB
])
assert prompt_wrapper_off + len(prompt_wrapper) <= prompt_list_off
assert prompt_list_off + len(prompt_list) < 0x1BD00
assert base[prompt_wrapper_off:prompt_list_off+len(prompt_list)] == bytes([0xFF])*(prompt_list_off+len(prompt_list)-prompt_wrapper_off)
rom[prompt_wrapper_off:prompt_wrapper_off+len(prompt_wrapper)] = prompt_wrapper
rom[prompt_list_off:prompt_list_off+len(prompt_list)] = prompt_list
# CD98 ends with JMP $E3EB at 0x1ADB1. Redirect to wrapper.
rom[0x1ADB1:0x1ADB4] = bytes([0x4C, prompt_wrapper_cpu & 0xFF, prompt_wrapper_cpu >> 8])

# --- Navegación especial en la parrilla de password ------------------------
# Sustituye el wrapper DOWN de $DC30 con más casos especiales:
# U/V -> 0, T -> Z, t -> z, z -> 9.
def assemble_nav_stub():
    code=[]; labels={}; fix=[]
    def label(n): labels[n]=len(code)
    def emit(*bs): code.extend(bs)
    def bne(lbl): fix.append((len(code)+1,lbl)); emit(0xD0,0)
    def beq(lbl): fix.append((len(code)+1,lbl)); emit(0xF0,0)
    def bra(lbl): fix.append((len(code)+1,lbl)); emit(0x80,0)
    def lda_abs(addr): emit(0xAD,addr&255,addr>>8)
    def sta_abs(addr): emit(0x8D,addr&255,addr>>8)
    def cmp_imm(v): emit(0xC9,v)
    def lda_imm(v): emit(0xA9,v)
    def set_col(v): lda_imm(v); sta_abs(0x3C91); bra('call')
    lda_abs(0x3C92); cmp_imm(0x03); bne('check_row4')
    lda_abs(0x3C91); cmp_imm(0x06); beq('set5'); cmp_imm(0x0D); beq('set12'); bra('call')
    label('set5'); set_col(0x05)       # T -> Z
    label('set12'); set_col(0x0C)      # t -> z
    label('check_row4')
    cmp_imm(0x04); bne('call')
    lda_abs(0x3C91); cmp_imm(0x00); beq('set2'); cmp_imm(0x01); beq('set2'); cmp_imm(0x0C); beq('set11'); bra('call')
    label('set2'); set_col(0x02)       # U/V -> 0
    label('set11'); lda_imm(0x0B); sta_abs(0x3C91)  # z -> 9
    label('call'); emit(0x20,0x52,0xCC,0x60)
    for pos,lbl in fix:
        rel=labels[lbl]-(pos+1)
        if not -128 <= rel <= 127: raise ValueError((lbl,rel))
        code[pos]=rel & 0xFF
    return bytes(code)
nav_stub = assemble_nav_stub()
nav_off = 0x1BC30
assert nav_off + len(nav_stub) <= prompt_wrapper_off
rom[nav_off:nav_off+len(nav_stub)] = nav_stub

# Fine background scroll: move only the BG/bocadillo 2 px left.
# The previous request needs a sub-tile shift. Background scroll is the safest
# way to move the tilemap by pixels without redrawing half-shifted border tiles.
# Patch the error-screen CE14 call through a small same-bank stub:
#   LDA #$02 / STA <$35 / JSR $CE14 / RTS
# BXR +2 moves BG left by 2 px, while sprite/text positions compensate for
# <$35 in E3EB and remain controlled by their own X coordinates.
bg_scroll_stub_off = 0x1BDC0
bg_scroll_stub_cpu = 0xDDC0
bg_scroll_stub = bytes([0xA9,0x02,0x85,0x35,0x20,0x14,0xCE,0x60])
assert orig[bg_scroll_stub_off:bg_scroll_stub_off+len(bg_scroll_stub)] == bytes([0xFF])*len(bg_scroll_stub)
assert base[bg_scroll_stub_off:bg_scroll_stub_off+len(bg_scroll_stub)] == bytes([0xFF])*len(bg_scroll_stub)
rom[bg_scroll_stub_off:bg_scroll_stub_off+len(bg_scroll_stub)] = bg_scroll_stub
# CDC9 sequence: JSR $CE14 at ROM 0x1ADCC.
rom[0x1ADCC:0x1ADCF] = bytes([0x20, bg_scroll_stub_cpu & 0xFF, bg_scroll_stub_cpu >> 8])

# Clear the full expanded text-pattern area before drawing the error. Original
# CE35 clears only 0x18 rows/chunks, enough for 3 lines x 4 sprites. Our
# viewport uses 4 lines x 5 sprites, so old sprite-pattern data remains on
# repeated errors or after endings unless we clear more.
rom[0x1AE54] = 0x28  # CE53: CPY #$18 -> #$28

# Guards
assert rom[0x2EC10:0x2EC4D] == base[0x2EC10:0x2EC4D]
assert rom[0x2F8B5:0x30000] == base[0x2F8B5:0x30000]
# This one intentionally changes only via pointer, original stream remains intact in-place.
assert rom[0x1E29C:0x1E2DF] == base[0x1E29C:0x1E2DF]
# Output
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
REPORT.write_text(f'''# Prueba v03 — prompt superior + navegación password

ROM:
`Roms/Pruebas/{OUT.name}`

IPS:
`Parches/Pruebas/{IPS.name}`

## Base

Parte de `traduccion_v02` y conserva el viewport 5x4 que ya permitió ver las cuatro líneas completas.

## Texto fijo

```text
{text}
```

## Cambios

- Ventanilla de texto: 5 columnas x 4 líneas en bank `$0F`, como la prueba exitosa.
- Quinta columna con offset `$7F`.
- Rabillo corregido: ahora sube con el bocadillo (`top+3/top+4`) y no queda en la posición vertical antigua.
- Ajuste fino respecto a shift3:
  - estatua 2 px a la izquierda (`X #$1F -> #$1D`).
  - texto 3 px a la derecha (`X #$43 -> #$46`).
  - bocadillo 2 px a la izquierda mediante scroll de fondo (`<$35 = #$02`).
- Bocadillo original no se modifica in-place, pero se usa un stream relocalizado con el mismo tamaño que la prueba buena.
  - left = 8, right = 27.
  - top = 11, bottom = 19.
  - rabillo en la misma posición relativa del bocadillo.
  - Esto mueve el bocadillo 1 tile a la derecha respecto a shift2. El tilemap trabaja en pasos de 8 px; si necesitamos exactamente 4 px, habrá que hacer tiles de borde desplazados medio tile.
- Estatua/Momotaro: `X #$1D`, `Y #$68`.

## Prompt superior y navegación

Añadido en esta prueba:

- Prompt superior relocalizado: `¡Introduce el canto de Jizo!`.
- Viewport adicional de 7 chunks para intentar proyectar la línea completa antes de redibujar la caja superior.
- Wrapper en `0x{prompt_wrapper_off:05X}` / CPU `${prompt_wrapper_cpu:04X}` y lista en `0x{prompt_list_off:05X}` / CPU `${prompt_list_cpu:04X}`.
- Stub DOWN ampliado en `0x{nav_off:05X}` con `{len(nav_stub)}` bytes.

Casos de navegación añadidos:

```text
U/V + abajo -> 0
T   + abajo -> Z
t   + abajo -> z
z   + abajo -> 9
```

## Limpieza de residuos

La prueba aceptada visualmente podía dejar residuos al repetir un password erróneo. Causa probable: la rutina original `CE35` sólo limpia el área de patrones de texto suficiente para 3 líneas x 4 sprites. Nuestra ventanilla usa 4 líneas x 5 sprites.

Parche aplicado:

```asm
CE53: CPY #$18  ; original
CE53: CPY #$28  ; nuevo, limpia 40 bloques/patrones
```

Esto debe limpiar la zona expandida antes de redibujar el mensaje, tanto tras repetir error como tras volver de endings.

## Validación

- Bank `$17` no se toca: `0x2F8B5-0x30000` idéntico a v02.
- Lista original `0x2EC10-0x2EC4D` intacta.
- Stream original de bocadillo `0x1E29C-0x1E2DF` intacto; se usa una copia ampliada en `0x{bubble_off:05X}`.
- Viewport seguro en `0x{vp_off:05X}`.
- Stub de scroll BG: ROM `0x{bg_scroll_stub_off:05X}` / CPU `${bg_scroll_stub_cpu:04X}`.
- Limpieza expandida de patrones de texto: ROM `0x1AE54`, valor `$28`.
- Prompt superior: ROM `0x{prompt_off:05X}`, CPU `${prompt_cpu:04X}`, len `{len(prompt_data)}`.
- Wrapper/lista prompt en zona libre antes de la tabla de selección.
- Texto/línea stride en zona libre segura.

## Medidas buscadas

- La prueba anterior ya cubría las cuatro líneas y el usuario la dio como bastante buena.
- Esta prueba sólo refina composición: desplazar todo el conjunto a la izquierda y hacia arriba sin cambiar el texto.
- El bocadillo necesitaba 2 px a la izquierda; como el tilemap va en tiles, se usa scroll BG local de 2 px para esta pantalla.

## Cambios contra v02

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Que las cuatro líneas siguen completas.
3. Que el conjunto estatua+bocadillo+texto queda mejor centrado horizontalmente.
4. Que subirlo 16 px no lo deja demasiado alto.
5. Que los márgenes internos del texto siguen correctos.
6. Que el rabillo ya está alineado verticalmente con el bocadillo.
7. Que el bocadillo queda 2 px más a la izquierda que en shift3.
8. Que el mensaje de error sigue limpio y completo.
9. Que el prompt superior `¡Introduce el canto de Jizo!` se ve entero o, si hay doble imagen/solapamiento, medir dónde.
10. Navegación DOWN: U->0, V->0, T->Z, t->z, z->9.
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('viewport',hex(vp_off),hex(vp_cpu),len(vp))
print('bubble',hex(bubble_off),hex(bubble_cpu),len(bubble_stream))
print('bg scroll stub',hex(bg_scroll_stub_off),hex(bg_scroll_stub_cpu),len(bg_scroll_stub))
print('clear patch 0x1AE54=0x28')
print('prompt',hex(prompt_off),hex(prompt_cpu),len(prompt_data))
print('prompt wrapper/list',hex(prompt_wrapper_off),hex(prompt_list_off),len(prompt_wrapper),len(prompt_list))
print('nav stub',hex(nav_off),len(nav_stub),nav_stub.hex(' '))
print('line lengths',line_lengths)
print('changed',changed)
print('records',len(rec),'bytes',sum(len(b) for _,b in rec))
