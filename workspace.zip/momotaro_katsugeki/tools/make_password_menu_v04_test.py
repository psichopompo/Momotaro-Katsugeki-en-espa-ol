#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_test.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v04_password_menu_test.ips'
REPORT=ROOT/'reports/test_password_menu_v04.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)

# Encoder latino validado.
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i in range(26): enc[chr(65+i)]=0x41+i
enc.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,
            'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,
            '¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,
            "'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,
            '&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s:str)->bytes:
    out=bytearray()
    i=0
    while i < len(s):
        if s[i]=='\n': out.append(0); i+=1; continue
        if s.startswith('<WAIT>',i): out.append(0xFD); i+=6; continue
        if s.startswith('<MODE>',i): out.append(0xFE); i+=6; continue
        ch=s[i]
        if ch not in enc: raise ValueError(f'Carácter no soportado {ch!r} en {s!r}')
        out.append(enc[ch]); i+=1
    return bytes(out)
def cpu0f(off:int)->int:
    assert 0x1E000 <= off < 0x20000
    return 0x4000+(off-0x1E000)
def ptr(cpu:int)->bytes: return bytes([cpu&0xff,cpu>>8])

# Ubicación libre en v03. Evita zonas ya usadas por prompt/error/viewport/bocadillo/listas.
alloc=0x1FB10
alloc_end=0x20000
assert orig[alloc:alloc_end] == bytes([0xFF])*(alloc_end-alloc)
assert base[alloc:alloc_end] == bytes([0xFF])*(alloc_end-alloc)
allocations={}
def put(name:str, payload:bytes, term:int=0x00)->int:
    global alloc
    off=alloc; data=payload+bytes([term])
    assert off+len(data)<=alloc_end
    assert orig[off:off+len(data)] == bytes([0xFF])*len(data)
    assert base[off:off+len(data)] == bytes([0xFF])*len(data)
    rom[off:off+len(data)] = data
    cpu=cpu0f(off)
    allocations[name]=(off,cpu,len(data),data)
    alloc += len(data)
    return cpu

# Los prefijos 01/02 + 3C se conservan de las listas japonesas para mantener
# modo/posicionamiento/selección del menú.
PFX1=bytes([0x01,0x3C])
PFX2=bytes([0x02,0x3C])

diff_facil=put('diff_facil', PFX1+enc_text('FÁCIL'))
diff_normal=put('diff_normal', PFX1+enc_text('NORMAL'))
diff_dificil=put('diff_dificil', PFX1+enc_text('DIFÍCIL'))
diff_muy_dificil=put('diff_muy_dificil', PFX2+enc_text('MUY DIFÍCIL'))
empty=put('empty', b'')
menu_jizo=put('menu_jizo', PFX1+enc_text('CANTO DE JIZO'))
menu_cargar=put('menu_cargar', PFX2+enc_text('CARGAR'))
load_question=put('load_question', bytes([0x01])+enc_text('¿Cuál quieres cargar?'))
backup_error=put('backup_error', bytes([0x01])+enc_text('Los datos guardados\nno son válidos.\nSe borrará el archivo.'), 0xFF)

# Punteros originales en bank $0F.
# Main selector difficulty pointers at CPU $54AE.
rom[0x1F4AE:0x1F4AE+10]=b''.join(ptr(p) for p in [diff_facil,diff_normal,diff_dificil,diff_muy_dificil,empty])
# Main selector options at CPU $54EB.
rom[0x1F4EB:0x1F4EB+4]=ptr(menu_jizo)+ptr(menu_cargar)
# Load selector table at CPU $5501: question + difficulties + empty.
rom[0x1F501:0x1F501+12]=b''.join(ptr(p) for p in [load_question,diff_facil,diff_normal,diff_dificil,diff_muy_dificil,empty])
# Direct backup-RAM error pointer in C583: LDA #$1D / #$55.
rom[0x1A58E]=backup_error&0xff; rom[0x1A592]=backup_error>>8

# Validar que no tocamos las partes sensibles recién cerradas.
# Prompt/error pointers and runtime lists should remain exactly v03 except menu patches/backup pointer.
assert rom[0x1AD11] == base[0x1AD11] and rom[0x1AD15] == base[0x1AD15]
assert rom[0x1AE60] == base[0x1AE60] and rom[0x1AE64] == base[0x1AE64]
assert rom[0x1FA00:0x1FB09] == base[0x1FA00:0x1FB09]
assert rom[0x43A8B] == base[0x43A8B]

OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
alloc_lines='\n'.join(f'- `{name}`: ROM `0x{off:05X}`, CPU `${cpu:04X}`, len `{ln}`, bytes `{data.hex(" ")}`' for name,(off,cpu,ln,data) in allocations.items())
REPORT.write_text(f'''# Prueba v04 — textos restantes del menú password/load

ROM de prueba:

`Roms/Pruebas/{OUT.name}`

IPS:

`Parches/Pruebas/{IPS.name}`

## Base

Parte de `traduccion_v03`, ya confirmada para parrilla, prompt superior, error de Jizo y navegación.

## Objetivo

Traducir los textos pendientes del menú de password/load sin tocar el prompt ni el error ya cerrados.

## Textos insertados

Selector principal:

```text
CANTO DE JIZO
CARGAR
```

Dificultades / slots:

```text
FÁCIL
NORMAL
DIFÍCIL
MUY DIFÍCIL
```

Selector de carga:

```text
¿Cuál quieres cargar?
```

Error backup RAM:

```text
Los datos guardados
no son válidos.
Se borrará el archivo.
```

## Asignaciones

{alloc_lines}

## Punteros parcheados

- `$54AE`: tabla de dificultades.
- `$54EB`: opciones `CANTO DE JIZO` / `CARGAR`.
- `$5501`: selector de carga.
- `C583`: puntero directo del error de backup RAM.

## Validación estática

- Textos nuevos en zona libre de v03: `0x1FB10+`.
- No se toca la lista del prompt en `0x1FA00`.
- No se toca `BA8A` ni la preparación del prompt.
- No se tocan los punteros del prompt superior ni del error de Jizo.

## Cambios contra v03

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}

## Qué comprobar

1. Selector inicial con guardado: que se lea `CANTO DE JIZO` / `CARGAR`.
2. Entrar en CARGAR: pregunta y slots/dificultades.
3. Cargar la partida guardada para confirmar que sigue funcionando.
4. Si puedes provocar error de backup, revisar el mensaje.
5. Confirmar que prompt superior y error de Jizo siguen bien.
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('alloc used', alloc-0x1FB10, 'next', hex(alloc))
for line in alloc_lines.split('\n'): print(line)
print('changed vs v03', changed)
print('records vs orig', len(rec), 'bytes', sum(len(b) for _,b in rec))
