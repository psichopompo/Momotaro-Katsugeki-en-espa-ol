#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_viewport20_test.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v03_error_text4_viewport20_test.ips'
REPORT=ROOT/'reports/test_password_error_text4_viewport20_v03.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)
# Encoder
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i in range(26): enc[chr(65+i)]=0x41+i
enc.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s):
    out=bytearray()
    for ch in s:
        if ch=='\n': out.append(0)
        else: out.append(enc[ch])
    return bytes(out)
def cpu0f(off): return 0x4000+(off-0x1E000)
# Fixed text.
text='¡El canto de Jizo\nno es correcto!\nRevísalo bien e\ninténtalo de nuevo.'
line_lengths=[len(x) for x in text.split('\n')]
error_off=0x1F838; error_cpu=cpu0f(error_off)
data=bytes([1])+enc_text(text)+bytes([0xFF])
assert orig[error_off:error_off+len(data)]==bytes([0xFF])*len(data)
rom[error_off:error_off+len(data)]=data
rom[0x1AE60]=error_cpu&0xff; rom[0x1AE64]=error_cpu>>8
# Four line starts with 5 chunks / 20 chars stride.
lt_off=0x1BDB0; lt_cpu=0xDDB0
lt=bytes([0x08,0x70, 0x88,0x72, 0x08,0x75, 0x88,0x77])
assert orig[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
assert base[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
rom[lt_off:lt_off+len(lt)]=lt
for off,cpu in [(0x1AE68,lt_cpu),(0x1AE70,lt_cpu+1),(0x1AEF4,lt_cpu),(0x1AEF9,lt_cpu+1)]:
    rom[off]=cpu&0xff; rom[off+1]=cpu>>8
# New full viewport list: 5 columns x 4 lines, stored in bank $0F safe free area.
# x offsets are signed; use $7F for the fifth column.
vp_off=0x1F900; vp_cpu=cpu0f(vp_off)
vp=bytearray()
xoffs=[0x00,0x20,0x40,0x60,0x7F]
for row in range(4):
    for col,xoff in enumerate(xoffs):
        pat=(row*5+col)*2
        vp += bytes([pat,0x0E,0x01,xoff,row*0x10])
vp.append(0xFF)
assert len(vp)==101
assert orig[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
assert base[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
rom[vp_off:vp_off+len(vp)]=vp
# Patch CF59: read list from bank $0F, pointer $5900. Keep original X/Y origin and bocadillo.
rom[0x1AF5A]=0x0F
rom[0x1AF68]=vp_cpu&0xff
rom[0x1AF6C]=vp_cpu>>8
# Guards: original bocadillo and bank17 untouched.
assert rom[0x1E29C:0x1E2DF] == base[0x1E29C:0x1E2DF]
assert rom[0x2EC10:0x2EC4D] == base[0x2EC10:0x2EC4D]
assert rom[0x2F8B5:0x30000] == base[0x2F8B5:0x30000]
# Output
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
REPORT.write_text(f'''# Prueba v03 — error de Jizo 4 líneas con viewport 5x4 seguro

ROM:
`Roms/Pruebas/{OUT.name}`

IPS:
`Parches/Pruebas/{IPS.name}`

## Objetivo

Ahora que la prueba in-place v2 demostró que la quinta columna aparece si usamos offset `$7F`, esta prueba intenta mostrar las cuatro líneas completas.

Texto fijo:

```text
{text}
```

## Cambio técnico

- Bocadillo original intacto.
- Bank `$17` intacto.
- Nueva lista de sprites/ventanilla en bank `$0F` zona libre:
  - ROM `0x{vp_off:05X}` / CPU `${vp_cpu:04X}` / len `{len(vp)}`.
- Lista de viewport: 5 columnas x 4 filas = 20 sprites.
- Quinta columna usa x offset `$7F`, porque `$80` se interpreta como negativo.
- Líneas en VRAM con stride de 5 chunks / 20 caracteres:
  - `$7008`
  - `$7288`
  - `$7508`
  - `$7788`

## Validación anti-corrupción

- `0x1E29C-0x1E2DF` idéntico a v02: bocadillo original.
- `0x2EC10-0x2EC4D` idéntico a v02: lista original preservada.
- `0x2F8B5-0x30000` idéntico a v02: bank `$17` no se toca.

## Longitudes

`{line_lengths}`

## Cambios contra v02

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Que se ve `Jizo` completo.
3. Que la tercera línea muestra `Revísalo bien e` completa.
4. Que aparece la cuarta línea `inténtalo de nuevo.`.
5. El bocadillo se mantiene original; si el texto se sale visualmente, eso ahora mismo es aceptable.
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('line lengths',line_lengths,'data',len(data))
print('viewport',hex(vp_off),hex(vp_cpu),len(vp))
print('changed',changed)
print('records',len(rec),'bytes',sum(len(b) for _,b in rec))
