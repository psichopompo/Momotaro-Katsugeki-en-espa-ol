#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_bubblefit_test.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v03_error_text4_bubblefit_test.ips'
REPORT=ROOT/'reports/test_password_error_text4_bubblefit_v03.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)
# Encoder latino validado
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i in range(26): enc[chr(65+i)]=0x41+i
enc.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s):
    out=bytearray()
    for ch in s:
        if ch=='\n': out.append(0)
        else: out.append(enc[ch])
    return bytes(out)
def cpu0f(off):
    assert 0x1E000 <= off < 0x20000
    return 0x4000+(off-0x1E000)
def rle_encode(vals):
    out=bytearray(); i=0
    while i<len(vals):
        v=vals[i]; j=i+1
        while j<len(vals) and vals[j]==v and j-i<256: j+=1
        L=j-i
        if L>=3 or v==0xff: out += bytes([0xff,L-1,v])
        else: out += bytes([v])*L
        i=j
    return bytes(out)
# Fixed text proven visible with viewport20.
text='¡El canto de Jizo\nno es correcto!\nRevísalo bien e\ninténtalo de nuevo.'
line_lengths=[len(x) for x in text.split('\n')]
error_off=0x1F838; error_cpu=cpu0f(error_off)
data=bytes([1])+enc_text(text)+bytes([0xFF])
assert orig[error_off:error_off+len(data)]==bytes([0xFF])*len(data)
rom[error_off:error_off+len(data)]=data
rom[0x1AE60]=error_cpu&0xff; rom[0x1AE64]=error_cpu>>8
# Four line starts with 5 chunks / 20 char stride.
lt_off=0x1BDB0; lt_cpu=0xDDB0
lt=bytes([0x08,0x70, 0x88,0x72, 0x08,0x75, 0x88,0x77])
assert orig[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
assert base[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
rom[lt_off:lt_off+len(lt)]=lt
for off,cpu in [(0x1AE68,lt_cpu),(0x1AE70,lt_cpu+1),(0x1AEF4,lt_cpu),(0x1AEF9,lt_cpu+1)]:
    rom[off]=cpu&0xff; rom[off+1]=cpu>>8
# Viewport 5 columns x 4 lines, safe bank $0F.
vp_off=0x1F900; vp_cpu=cpu0f(vp_off)
vp=bytearray(); xoffs=[0x00,0x20,0x40,0x60,0x7F]
for row in range(4):
    for col,xoff in enumerate(xoffs):
        vp += bytes([(row*5+col)*2,0x0E,0x01,xoff,row*0x10])
vp.append(0xFF)
assert len(vp)==101
assert orig[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
assert base[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
rom[vp_off:vp_off+len(vp)]=vp
# CF59: use bank $0F and viewport pointer; move text origin up 2 px (Y $6A -> $68), as calculated.
rom[0x1AF5A]=0x0F
rom[0x1AF63]=0x68
rom[0x1AF68]=vp_cpu&0xff
rom[0x1AF6C]=vp_cpu>>8
# Bubble expansion: keep original left/top/tail, expand right +3 tiles and bottom +2 tiles.
# Original central bubble: left=9, right=25, top=13, bottom=19.
# New: left=9, right=28, top=13, bottom=21.
tm=[[0 for _ in range(32)] for __ in range(32)]
left,right,top,bottom=9,28,13,21
for c in range(left,right+1):
    tm[top][c]=2; tm[bottom][c]=7
tm[top][left]=1; tm[top][right]=3; tm[bottom][left]=6; tm[bottom][right]=8
for r in range(top+1,bottom):
    tm[r][left]=4; tm[r][right]=5
    for c in range(left+1,right): tm[r][c]=9
# Original tail, unchanged relative to top/left.
tm[16][left-1]=10; tm[16][left]=11
for c in range(left+1,right): tm[16][c]=9
tm[16][right]=5
tm[17][left-1]=12; tm[17][left]=13
for c in range(left+1,right): tm[17][c]=9
tm[17][right]=5
low=[]
for r in range(32):
    for c in range(32): low.append(tm[r][c])
bubble_stream=rle_encode(low)
bubble_off=0x1F970; bubble_cpu=cpu0f(bubble_off)
assert orig[bubble_off:bubble_off+len(bubble_stream)]==bytes([0xFF])*len(bubble_stream)
assert base[bubble_off:bubble_off+len(bubble_stream)]==bytes([0xFF])*len(bubble_stream)
rom[bubble_off:bubble_off+len(bubble_stream)]=bubble_stream
# CE14 pointer to low-stream; keep original high-stream all-zero.
rom[0x1AE1C]=bubble_cpu&0xff; rom[0x1AE20]=bubble_cpu>>8
# Guards
assert rom[0x2EC10:0x2EC4D] == base[0x2EC10:0x2EC4D]
assert rom[0x2F8B5:0x30000] == base[0x2F8B5:0x30000]
# This one intentionally changes only via pointer, original stream remains intact in-place.
assert rom[0x1E29C:0x1E2DF] == base[0x1E29C:0x1E2DF]
# Output
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
REPORT.write_text(f'''# Prueba v03 — error de Jizo con viewport 20 y bocadillo ajustado

ROM:
`Roms/Pruebas/{OUT.name}`

IPS:
`Parches/Pruebas/{IPS.name}`

## Base

Parte de `traduccion_v02` y conserva el viewport 5x4 que ya permitió ver las cuatro líneas completas.

## Texto fijo

```text
{text}
```

## Cambios

- Ventanilla de texto: 5 columnas x 4 líneas en bank `$0F`, como la prueba exitosa.
- Quinta columna con offset `$7F`.
- Texto subido 2 px: `LDY #$6A -> #$68`.
- Bocadillo original no se modifica in-place, pero se usa un stream relocalizado con:
  - left = 9, top = 13, igual que original.
  - right = 28, tres tiles más a la derecha.
  - bottom = 21, dos tiles más abajo.
  - rabillo en la misma posición relativa original.

## Validación

- Bank `$17` no se toca: `0x2F8B5-0x30000` idéntico a v02.
- Lista original `0x2EC10-0x2EC4D` intacta.
- Stream original de bocadillo `0x1E29C-0x1E2DF` intacto; se usa una copia ampliada en `0x{bubble_off:05X}`.
- Viewport seguro en `0x{vp_off:05X}`.
- Texto/línea stride en zona libre segura.

## Medidas buscadas

- El bloque de texto completo ya se veía: 146 x 55 px aprox. según captura del usuario.
- Se sube 2 px para acercar margen superior a 8 px.
- Se amplía el bocadillo aproximadamente +24 px a la derecha y +16 px abajo, aproximación por tiles a los +26/+15 px calculados.

## Cambios contra v02

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Que las cuatro líneas siguen completas.
3. Que el bocadillo cubre la cuarta línea.
4. Que el margen derecho mejora sin quedar exagerado.
5. Que al subir el texto 2 px no se pega arriba.
6. Que la estatua/rabillo quedan aceptables o qué habría que ajustar después.
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('viewport',hex(vp_off),hex(vp_cpu),len(vp))
print('bubble',hex(bubble_off),hex(bubble_cpu),len(bubble_stream))
print('line lengths',line_lengths)
print('changed',changed)
print('records',len(rec),'bytes',sum(len(b) for _,b in rec))
