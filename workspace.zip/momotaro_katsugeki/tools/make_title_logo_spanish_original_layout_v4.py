#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Anteriores/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
ASSET=ROOT/'title_assets/title_logo_es_fullscreen.png'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v4.pce'
IPS=ROOT/'Parches/momotaro_title_logo_spanish_original_layout_test_v4.ips'
PREVIEW=ROOT/'images/title_logo_spanish_original_layout_v4_preview.png'
REPORT=ROOT/'reports/test_rotulo_titulo_original_layout_v4.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
asset=Image.open(ASSET).convert('RGBA')
# Provisional palette-index mapping. Structure first; palette later.
color_map={
    (0,0,0):8,
    (0,36,182):5,
    (0,146,219):7,
    (219,182,0):10,
    (146,73,36):2,
    (219,36,109):14,
    (255,109,255):15,
    (255,73,146):14,
    (255,146,109):11,
    (219,182,219):13,
    (73,109,36):12,
}
def nearest_idx(rgb):
    if rgb in color_map: return color_map[rgb]
    best=min(color_map, key=lambda c: sum((rgb[i]-c[i])**2 for i in range(3)))
    return color_map[best]
# Original logo metasprite list at bank17 CPU $42B0, ROM 0x2E2B0.
list_off=0x2E2B0
entries=[]; i=list_off
while orig[i]!=0xFF:
    tile,a1,a2,dx,dy=orig[i:i+5]
    dx=dx-256 if dx>=128 else dx
    dy=dy-256 if dy>=128 else dy
    entries.append((tile,a1,a2,dx,dy))
    i+=5
# Base visible from SAT/log: X=$80, Y=$58 (88). The main logo entries at dy=$C3 (-61) -> y=27.
BASE_X=128; BASE_Y=88
patterns=[[[0 for _ in range(16)] for _ in range(16)] for _ in range(64)]
def dims(a2):
    w=2 if (a2 & 1) else 1
    hcode=(a2>>4)&3
    h={0:1,1:2,3:4}.get(hcode,1)
    return w,h
# Fill each actual sprite pattern from the user's full-screen asset according to the ORIGINAL layout.
for tile,a1,a2,dx,dy in entries:
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile + row*2 + col
            if not (0<=pidx<64): continue
            sx0=BASE_X+dx+col*16
            sy0=BASE_Y+dy+row*16
            arr=patterns[pidx]
            for y in range(16):
                sy=sy0+y
                if sy<0 or sy>=asset.height: continue
                for x in range(16):
                    sx=sx0+x
                    if sx<0 or sx>=asset.width: continue
                    r,g,b,a=asset.getpixel((sx,sy))
                    if a:
                        arr[y][x]=nearest_idx((r,g,b))
# IMPORTANT: the stream must contain PCE SPRITE pattern data in VRAM order, not four BG 8x8 tiles.
def encode_sprite_pattern_16(arr):
    # PCE sprite: 4 planes; each plane has 16 lines of 16 pixels = 2 bytes per line.
    # This matches the F1B9/C1CC decompressed raw stream format.
    out=[]
    for plane in range(4):
        for y in range(16):
            b0=b1=0
            # La ROM/VDC usa los dos bytes de cada fila de sprite en orden little-endian:
            # byte 0 = mitad derecha, byte 1 = mitad izquierda.
            # Por eso escribimos los píxeles 0..7 en b1 y 8..15 en b0.
            for x in range(8,16):
                c=arr[y][x]
                b0=(b0<<1)|((c>>plane)&1)
            for x in range(0,8):
                c=arr[y][x]
                b1=(b1<<1)|((c>>plane)&1)
            out.extend([b0,b1])
    return bytes(out)
def compress_pattern(raw128):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw128[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v!=0:
                        mask|=1<<bit; payload.append(v)
                elif v!=prev:
                    mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out += bytes(payload)
    return bytes(out)
stream=bytearray([64]); lens=[]
for arr in patterns:
    c=compress_pattern(encode_sprite_pattern_16(arr)); lens.append(len(c)); stream+=c
start=0x252C8; end=0x2617B; max_len=end-start
if len(stream)>max_len:
    raise SystemExit(f'Stream too large {len(stream)} > {max_len}')
rom[start:start+len(stream)] = stream
rom[start+len(stream):end] = bytes([0xFF])*(max_len-len(stream))
# Keep original logo metasprite list unchanged.
OUT.write_bytes(rom)
# IPS
new=bytes(rom); records=[]; j=0
while j<len(orig):
    if orig[j]==new[j]: j+=1; continue
    s=j; buf=bytearray()
    while j<len(orig) and orig[j]!=new[j] and len(buf)<0xffff:
        buf.append(new[j]); j+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
# Preview recomposed with same original layout.
pal=[(0,0,80),(255,255,255),(146,73,36),(0,0,0),(0,36,182),(0,36,182),(0,146,219),(0,146,219),(0,0,0),(80,80,80),(219,182,0),(255,146,109),(73,109,36),(219,182,219),(219,36,109),(255,109,255)]
prev=Image.new('RGB',(256,120),(0,0,80))
for tile,a1,a2,dx,dy in entries:
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile+row*2+col
            if not (0<=pidx<64): continue
            sx0=BASE_X+dx+col*16; sy0=BASE_Y+dy+row*16
            arr=patterns[pidx]
            for y in range(16):
                for x in range(16):
                    c=arr[y][x]
                    if c:
                        px=sx0+x; py=sy0+y
                        if 0<=px<256 and 0<=py<120: prev.putpixel((px,py),pal[c])
PREVIEW.parent.mkdir(exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Test rótulo español con layout original del logo — v4\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Cambio respecto a v1\n\nLa v1 codificaba los patrones como cuatro tiles BG 8x8. Eso era incorrecto para este stream.\n\nLa v4 corrige el orden de bytes de cada fila de sprite: en la VRAM/SAT real el primer byte de la palabra corresponde a la mitad derecha y el segundo a la mitad izquierda.

Codifica cada patrón como **sprite PCE 16x16 en orden VRAM real**:\n\n```text\n4 planos; cada plano = 16 filas x 2 bytes\n```\n\nSe mantiene intacta la lista original del logo japonés en ROM `0x{list_off:05X}`.\n\n## Datos\n\n- Asset: `title_assets/title_logo_es_fullscreen.png`.\n- Base visible usada: X={BASE_X}, Y={BASE_Y}.\n- Stream original: `0x{start:05X}-0x{end-1:05X}` ({max_len} bytes).\n- Stream nuevo: `{len(stream)}` bytes.\n- Patrones: 64.\n- Longitudes por patrón: min `{min(lens)}`, max `{max(lens)}`.\n\n## Nota\n\nSi la estructura sale bien, quedará ajustar paleta y quizá la cobertura de los extremos izquierdo/derecho, porque el layout original cubre aproximadamente x=7..246.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream',len(stream),'max',max_len,'minmax',min(lens),max(lens))
print('records',len(records),sum(len(b) for _,b in records))
