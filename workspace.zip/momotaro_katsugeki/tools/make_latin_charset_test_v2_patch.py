#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT/'work/Momotarou Katsugeki (Japan) - latin_full_test_v2.pce'
OUT = ROOT/'work/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
IPS = ROOT/'work/momotaro_latin_charset_test_v2.ips'
PREVIEW = ROOT/'images/latin_charset_test_v2_preview.png'
REPORT = ROOT/'reports/prueba_repertorio_latino_v2.md'
TBL_OUT = ROOT/'work/charset_latin_charset_test_v2.tbl'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())
FONT_BASE = 0x3D660
ASCII_MAP = 0x42B5B

# Helper para glyphs 1bpp.
def glyph(rows):
    out=[]
    for r in rows:
        r=r.ljust(8,'.')[:8]
        b=0
        for ch in r:
            b=(b<<1)|(1 if ch not in '. 0' else 0)
        out.append(b)
    return bytes(out)

# Añadimos Ç en un glyph slot que NO se usará como byte de texto directo.
# Fuente/glyph $DE es utilizable si se llega por la tabla ASCII, aunque el byte de texto $DE está reservado por dakuten.
rom[FONT_BASE+0xDE*8:FONT_BASE+0xDE*8+8] = glyph([
    '.####...',
    '#.......',
    '#.......',
    '#.......',
    '#.......',
    '.####...',
    '..#.....',
    '.##.....',
])

# Parchar mapa ASCII de slots seguros de texto fuente 5B/5D/5E/5F.
# Evitamos los bytes directos A2, A3 y B0 porque AB34 los remapea antes de dibujar.
# 5C se reserva: en el juego original actúa como conmutador/escape de tabla.
rom[ASCII_MAP + (0x5B-0x30)] = 0xA2  # source 5B -> glyph b
rom[ASCII_MAP + (0x5D-0x30)] = 0xA3  # source 5D -> glyph c
rom[ASCII_MAP + (0x5E-0x30)] = 0xB0  # source 5E -> glyph p
rom[ASCII_MAP + (0x5F-0x30)] = 0xDE  # source 5F -> glyph Ç

# Encoder v2.
char_to_code={' ':0x20}
for i in range(10): char_to_code[str(i)] = 0x30+i
for i in range(26): char_to_code[chr(ord('A')+i)] = 0x41+i
char_to_code.update({'!':0x21,'?':0x3F,'$':0x24})
# minúsculas directas, con excepciones para los bytes no seguros.
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    char_to_code[ch]=0xA1+i
char_to_code['b']=0x5B
char_to_code['c']=0x5D
char_to_code['p']=0x5E
char_to_code.update({
    'á':0xBB, 'é':0xBC, 'í':0xBD, 'ó':0xBE, 'ú':0xBF, 'ü':0xC0, 'ñ':0xC1,
    'Á':0xC2, 'É':0xC3, 'Í':0xC4, 'Ó':0xC5, 'Ú':0xC6, 'Ü':0xC7, 'Ñ':0xC8,
    '¿':0xC9, '¡':0xCA, '.':0xCB, ',':0xCC, ':':0xCD, ';':0xCE, '…':0xCF,
    "'":0xD0, '"':0xD1, '-':0xD2, '/':0xD3, '(':0xD4, ')':0xD5, '%':0xD6,
    '&':0xD7, '+':0xD8, '¤':0xD9, 'ç':0xDA, 'º':0xDC, 'ª':0xDD, 'Ç':0x5F,
})

def enc(s):
    out=[]
    for ch in s:
        if ch not in char_to_code:
            raise ValueError(f'Sin código: {ch!r}')
        out.append(char_to_code[ch])
    return bytes(out)

pages = [
    ['abcdefghijklmn','opqrstuvwxyz','áéíóú ü ñ ç'],
    ['ABCDEFGHIJKLM','NOPQRSTUVWXYZ','ÁÉÍÓÚ Ü Ñ Ç'],
    ['¿? ¡! 012345','6789 200¤',".,:;… '-/()% "],
    ['&+ ºª'],
]

payload=bytearray()
for pi,page in enumerate(pages):
    for li,line in enumerate(page):
        payload += enc(line)
        if li != len(page)-1:
            payload.append(0x00)
    payload.append(0xFC if pi != len(pages)-1 else 0xFF)

start=0x1F078; end_ff=0x1F10B
assert len(payload)<=end_ff-start+1
rom[start:start+len(payload)] = payload
if start+len(payload)<=end_ff:
    rom[start+len(payload):end_ff] = bytes([0x20])*(end_ff-(start+len(payload)))
    rom[end_ff]=0xFF

OUT.write_bytes(rom)
new=bytes(rom)

# IPS contra original.
records=[]; i=0
while i < len(orig):
    if orig[i]==new[i]:
        i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xFFFF:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big') + len(buf).to_bytes(2,'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# Tabla v2 para inserción.
entries={}
entries.update({0x00:'<NL>',0xFC:'<PAGE>',0xFD:'<WAIT>',0xFE:'<MODE>',0xFF:'<END>'})
entries[0x20]=' '
for i in range(10): entries[0x30+i]=str(i)
for i in range(26): entries[0x41+i]=chr(ord('A')+i)
entries[0x21]='!'; entries[0x3F]='?'; entries[0x24]='$'
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    entries[0xA1+i]=ch
entries[0xA2]='<reservado:no usar b>'
entries[0xA3]='<reservado:no usar c>'
entries[0xB0]='<reservado:no usar p>'
entries[0x5B]='b'; entries[0x5D]='c'; entries[0x5E]='p'; entries[0x5F]='Ç'
for k,v in {'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'º':0xDC,'ª':0xDD}.items():
    entries[v]=k
with TBL_OUT.open('w',encoding='utf-8') as f:
    f.write('# Momotarou Katsugeki — tabla latina de test v2\n')
    f.write('# Bytes directos NO seguros detectados: A2, A3, B0. 5C reservado. DE/DF reservados por dakuten.\n')
    for code in sorted(entries):
        f.write(f'{code:02X}={entries[code]}\n')

# Preview.
ascii_map = new[ASCII_MAP:ASCII_MAP+0x36]
def source_to_gid(c):
    if c in (0x20,0xA0): return 0
    if 0xA1<=c<=0xDF: return c
    if 0x30<=c<0x30+len(ascii_map): return ascii_map[c-0x30]
    if c==0x21: return 0x9E # signo exclamación original observado
    if c==0x3F: return 0x9D
    if c==0x24: return 0x3E
    return 0
scale=3; page_imgs=[]
for page in pages:
    cols=max(len(l) for l in page); w=cols*8*scale+8; h=len(page)*10*scale+8
    img=Image.new('RGB',(w,h),(0,0,0))
    for row,line in enumerate(page):
        for col,c in enumerate(enc(line)):
            gid=source_to_gid(c)
            data=new[FONT_BASE+gid*8:FONT_BASE+gid*8+8]
            for y,b in enumerate(data):
                for x in range(8):
                    if (b>>(7-x))&1:
                        for yy in range(scale):
                            for xx in range(scale):
                                img.putpixel((4+col*8*scale+x*scale+xx,4+row*10*scale+y*scale+yy),(255,255,255))
    page_imgs.append(img)
sheet_w=max(i.width for i in page_imgs); sheet_h=sum(i.height+18 for i in page_imgs)+8
sheet=Image.new('RGB',(sheet_w,sheet_h),(240,240,240)); d=ImageDraw.Draw(sheet); y=4
for i,img in enumerate(page_imgs):
    d.text((2,y),f'Página {i+1} v2',fill=(0,0,0)); y+=16; sheet.paste(img,(0,y)); y+=img.height+2
sheet.save(PREVIEW)

REPORT.write_text(f'''# Prueba de repertorio latino completo v2\n\nROM: `{OUT.name}`\n\nIPS: `{IPS.name}`\n\nTabla: `{TBL_OUT.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Cambios respecto a v1\n\nLa prueba v1 reveló que estos bytes de texto directos no son seguros:\n\n- `$A2` — usado como `b` en v1, se remapea internamente.\n- `$A3` — usado como `c` en la primera prueba, se remapea internamente.\n- `$B0` — usado como `p` en v1, se remapea internamente.\n\nEn v2 se prueban códigos alternativos mediante la tabla ASCII:\n\n- `$5B = b` → glyph `$A2`\n- `$5D = c` → glyph `$A3`\n- `$5E = p` → glyph `$B0`\n- `$5F = Ç` → glyph `$DE`\n\n`$5C` queda reservado porque el juego lo usa como conmutador/escape de tabla. `$DE/$DF` quedan reservados como bytes de texto por dakuten/handakuten, aunque sus glyphs pueden reutilizarse si se accede mediante tabla.\n\n## Texto incluido\n\n```text\n{chr(10).join(' / '.join(page) for page in pages)}\n```\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')

print('ROM:', OUT)
print('IPS:', IPS)
print('TBL:', TBL_OUT)
print('Preview:', PREVIEW)
print('Report:', REPORT)
print('Payload len:', len(payload))
print('Records:', len(records), 'bytes:', sum(len(b) for _,b in records))
