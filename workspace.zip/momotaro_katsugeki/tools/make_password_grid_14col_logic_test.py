#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists():
    BASE = ORIG
LATIN = ROOT / 'Roms/Anteriores/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
OUT = ROOT / 'Roms/Momotarou Katsugeki (Japan) - password_grid_14col_logic_test.pce'
IPS = ROOT / 'Parches/momotaro_password_grid_14col_logic_test.ips'
REPORT = ROOT / 'reports/test_password_grid_14col_logic.md'
PREVIEW = ROOT / 'images/password_grid_14col_logic_preview.png'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())
latin = LATIN.read_bytes()

# ---------------------------------------------------------------------------
# Encoding used by the validated latin font test.
# ---------------------------------------------------------------------------
enc = {' ': 0x20}
for i in range(10):
    enc[str(i)] = 0x30 + i
for i, ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    enc[ch] = 0x41 + i
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    enc[ch] = 0xA1 + i
# validated source-code exceptions in this engine/text path
enc['b'] = 0x5B
enc['c'] = 0x5D
enc['p'] = 0x5E
enc.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

grid_rows = [
    list('ABCDEFGHIJKLMN'),
    ['Ñ', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
    list('abcdefghijklmn'),
    ['ñ', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
    list('0123456789'),
]
symbols = [ch for row in grid_rows for ch in row]
assert len(symbols) == 64, len(symbols)
source = bytes([enc[ch] for ch in symbols])

# ---------------------------------------------------------------------------
# 1) Copy validated latin font/conversion tables.
# ---------------------------------------------------------------------------
FONT_BASE = 0x3D660
FONT_LEN = 0xE0 * 8
rom[FONT_BASE:FONT_BASE + FONT_LEN] = latin[FONT_BASE:FONT_BASE + FONT_LEN]
latin_table_regions = [(0x41CB3, 0x40), (0x41CF3, 0x40), (0x42B5B, 0x36)]
for off, length in latin_table_regions:
    rom[off:off + length] = latin[off:off + length]

# ---------------------------------------------------------------------------
# 2) Relocate runtime alphabet source.
# ---------------------------------------------------------------------------
new_off = 0x1BBB9
new_cpu = 0xDBB9
table = bytes([0x01]) + source + bytes([0xFF])
rom[new_off:new_off + len(table)] = table
# Pointer low/high in C844 source reader.
rom[0x1A85E] = new_cpu & 0xFF
rom[0x1A862] = new_cpu >> 8

# ---------------------------------------------------------------------------
# 3) RLE tilemap streams.
# ---------------------------------------------------------------------------
def rle_encode(vals):
    out = bytearray()
    i = 0
    while i < len(vals):
        v = vals[i]
        j = i + 1
        while j < len(vals) and vals[j] == v and j - i < 256:
            j += 1
        L = j - i
        if L >= 3 or v == 0xFF:
            out += bytes([0xFF, L - 1, v])
        else:
            out += bytes([v]) * L
        i = j
    return bytes(out)

# 14 columns using the original 13-column area plus the original separator gap.
# Original first/last useful columns were roughly 3..28; with 14 fixed slots we
# use 3,5,7,...,29.
tile_rows = [7, 9, 11, 13, 15]
tile_cols = [3 + 2 * i for i in range(14)]
assert tile_cols == [3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29]

tm = [[0x100 for _ in range(32)] for __ in range(32)]
value = 1
for rr, row in enumerate(grid_rows):
    for cc, _ch in enumerate(row):
        tm[tile_rows[rr]][tile_cols[cc]] = 0x100 + value
        value += 1
assert value == 65

low = []
high = []
for r in range(32):
    for c in range(32):
        w = tm[r][c]
        low.append(w & 0xFF)
        high.append(((w >> 8) - 1) & 0xFF)
low_stream = rle_encode(low)
high_stream = rle_encode(high)
low_region_len = 0x1E290 - 0x1E18C
high_region_len = 0x1E29C - 0x1E290
assert len(low_stream) <= low_region_len, (len(low_stream), low_region_len)
assert len(high_stream) <= high_region_len, (len(high_stream), high_region_len)
rom[0x1E18C:0x1E290] = low_stream + bytes([0xFF]) * (low_region_len - len(low_stream))
rom[0x1E290:0x1E29C] = high_stream + bytes([0xFF]) * (high_region_len - len(high_stream))

# ---------------------------------------------------------------------------
# 4) Cursor/selection logic.
#
# Original has only 13 bytes for X table at CC6B..CC77. For 14 columns we
# relocate all lookup tables to free space in the same bank ($DC00+), then patch
# the absolute operands that read them.
# ---------------------------------------------------------------------------
sel_base_off = 0x1BC00
sel_base_cpu = 0xDC00
row_offsets_cpu = sel_base_cpu
x_table_cpu = row_offsets_cpu + 5
y_table_cpu = x_table_cpu + 14
values_cpu = y_table_cpu + 5
row_offsets_off = sel_base_off
x_table_off = row_offsets_off + 5
y_table_off = x_table_off + 14
values_off = y_table_off + 5

row_offsets = [0, 14, 28, 42, 56]
x_table = [(c * 8) - 8 for c in tile_cols]  # triangle anchor, glyph is 8px to the right
# y coordinate aligns to original 5-row grid
# row 7 -> $38, row 9 -> $48, ..., row 15 -> $78
y_table = [r * 8 for r in tile_rows]
values = []
value = 1
for row in grid_rows:
    row_values = []
    for _ch in row:
        row_values.append(value)
        value += 1
    while len(row_values) < 14:
        row_values.append(0)
    values.extend(row_values)
assert value == 65
assert len(values) == 5 * 14

sel_blob = bytes(row_offsets) + bytes(x_table) + bytes(y_table) + bytes(values)
assert len(sel_blob) == 94
# Ensure we stay in the free FF area and do not collide with the runtime table.
assert sel_base_off >= new_off + len(table)
assert orig[sel_base_off:sel_base_off + len(sel_blob)] == bytes([0xFF]) * len(sel_blob)
rom[sel_base_off:sel_base_off + len(sel_blob)] = sel_blob

# Patch absolute operand addresses:
#   C955: LDA $CC61,Y -> row offsets
#   C961: LDX $CC6B,Y -> X table
#   C967: LDA $CC78,Y -> Y table
#   CC5D: LDA $CC82,X -> values table
addr_patches = {
    0x1AC56: row_offsets_cpu,
    0x1A962: x_table_cpu,
    0x1A968: y_table_cpu,
    0x1AC5E: values_cpu,
}
for off, addr in addr_patches.items():
    rom[off] = addr & 0xFF
    rom[off + 1] = addr >> 8

# Navigation bounds: rows 0..4, columns 0..13.
nav_patches = {
    0x1AA56: 0x04,  # CA55 LDA #$09 -> row wrap up = 4
    0x1AA6A: 0x05,  # CA69 CMP #$0A -> row max exclusive = 5
    0x1AA80: 0x0E,  # CA7F CMP #$0D -> column max exclusive = 14
    0x1AA95: 0x0D,  # CA94 LDA #$0C -> column wrap left = 13
}
for off, val in nav_patches.items():
    rom[off] = val

# Horizontal directions were reversed once X table became left-to-right.
# In this game input bit $20 is D-pad right and bit $80 is D-pad left:
#   old $20 -> DEC X, old $80 -> INC X.
# Swap branch targets so right increments and left decrements.
# CA46 BNE $CA8C -> BNE $CA76 ; offset from CA48 to CA76 = $2E
# CA4A BNE $CA76 -> BNE $CA8C ; offset from CA4C to CA8C = $40
rom[0x1AA47] = 0x2E
rom[0x1AA4B] = 0x40

# ---------------------------------------------------------------------------
# Output ROM + IPS against original clean ROM.
# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
IPS.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
PREVIEW.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(rom)
new = bytes(rom)
records = []
i = 0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s = i
    buf = bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i])
        i += 1
    records.append((s, bytes(buf)))
ips = bytearray(b'PATCH')
for off, buf in records:
    ips += off.to_bytes(3, 'big') + len(buf).to_bytes(2, 'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# Static preview of intended geometry.
scale = 3
img = Image.new('RGB', (256 * scale, 240 * scale), (0, 0, 220))
d = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 8 * scale)
except Exception:
    font = ImageFont.load_default()
for rr, row in enumerate(grid_rows):
    for cc, ch in enumerate(row):
        x = tile_cols[cc] * 8 * scale
        y = tile_rows[rr] * 8 * scale
        d.text((x, y), ch, fill=(255, 255, 255), font=font)
# cursor anchors
for rr, row in enumerate(grid_rows):
    for cc, _ch in enumerate(row):
        cx = x_table[cc] * scale
        cy = y_table[rr] * scale
        d.polygon([(cx, cy + 2 * scale), (cx, cy + 6 * scale), (cx + 5 * scale, cy + 4 * scale)], fill=(255, 60, 60))
img.save(PREVIEW)

layout_text = '\n'.join(' '.join(row) for row in grid_rows)
changed_relevant = [
    ('Fuente latina 1bpp', FONT_BASE, FONT_LEN),
    ('Tabla conversión latina 1', 0x41CB3, 0x40),
    ('Tabla conversión latina 2', 0x41CF3, 0x40),
    ('Tabla conversión latina 3', 0x42B5B, 0x36),
    ('Puntero tabla runtime low', 0x1A85E, 1),
    ('Puntero tabla runtime high', 0x1A862, 1),
    ('Tabla runtime 64 símbolos', new_off, len(table)),
    ('Tilemap RLE low', 0x1E18C, low_region_len),
    ('Tilemap RLE high', 0x1E290, high_region_len),
    ('Branch input derecha $20', 0x1AA47, 1),
    ('Branch input izquierda $80', 0x1AA4B, 1),
    ('Nav row wrap up', 0x1AA56, 1),
    ('Nav row max', 0x1AA6A, 1),
    ('Nav col max', 0x1AA80, 1),
    ('Nav col wrap left', 0x1AA95, 1),
    ('Operand row offsets', 0x1AC56, 2),
    ('Operand X table', 0x1A962, 2),
    ('Operand Y table', 0x1A968, 2),
    ('Operand valores selección', 0x1AC5E, 2),
    ('Tablas selección relocalizadas', sel_base_off, len(sel_blob)),
]
changed_relevant_md = '\n'.join(f'- {name}: `0x{off:05X}` len `{length}`' for name, off, length in changed_relevant)
REPORT.write_text(f'''# Password grid 14-column logic test

ROM: `Roms/{OUT.name}`

IPS: `Parches/{IPS.name}`

Preview estático: `images/{PREVIEW.name}`

## Objetivo

Nueva prueba según la propuesta de 14 columnas / 5 filas, corrigiendo además la inversión izquierda-derecha del cursor.

## Parrilla esperada

```text
{layout_text}
```

## Cambios importantes frente al test de 10 columnas

1. **Parrilla 14 columnas / 5 filas**, ocupando la zona japonesa original más el hueco entre bloques.
2. **Direcciones horizontales corregidas**: el input `$20` era derecha y `$80` izquierda, pero la tabla X latina es ascendente; se han intercambiado los branch targets.
3. **Tablas de selección relocalizadas** a `$DC00`, porque la tabla X original sólo tenía 13 bytes (`CC6B..CC77`) y no caben 14 columnas sin pisar la tabla Y.
4. Las celdas inexistentes en filas cortas son `0`, para que la rutina original las salte:
   - fila `Ñ..Z`: columna 14 vacía,
   - fila `ñ..z`: columna 14 vacía,
   - fila `0..9`: columnas 11..14 vacías.

## Validación estática hecha antes de generar

- Símbolos codificados: `{len(symbols)}`.
- Tabla runtime: `{len(table)}` bytes en `0x{new_off:05X}`.
- Tablas selección relocalizadas: `{len(sel_blob)}` bytes en `0x{sel_base_off:05X}`, zona original `FF` libre.
- Low stream RLE: `{len(low_stream)}` / `{low_region_len}` bytes.
- High stream RLE: `{len(high_stream)}` / `{high_region_len}` bytes.
- X table: `{len(x_table)}` bytes.
- Y table: `{len(y_table)}` bytes.
- Valores selección: `{len(values)}` bytes.

## Regiones relevantes cambiadas

{changed_relevant_md}

## Qué comprobar en emulador

1. Que el bloque ya no invade la caja de inserción.
2. Que se ven 14 columnas en la primera fila.
3. Que derecha mueve el puntero a la derecha e izquierda a la izquierda.
4. Que la esquina superior izquierda introduce `A` y hacia la derecha `B C D...`.
5. Que al bajar desde `A` se pasa a `Ñ`, luego `a`, luego `ñ`, luego `0`.
6. Que las filas cortas saltan las celdas vacías sin quedarse bloqueadas.

Nota: la columna de opciones de la derecha sigue pendiente; primero cerramos parrilla visual/lógica.
''', encoding='utf-8')

print('OUT', OUT)
print('IPS', IPS)
print('REPORT', REPORT)
print('PREVIEW', PREVIEW)
print('layout:')
print(layout_text)
print('low/high', len(low_stream), '/', low_region_len, len(high_stream), '/', high_region_len)
print('sel blob', hex(sel_base_off), len(sel_blob))
print('row_offsets', row_offsets)
print('x_table', [f'{x:02X}' for x in x_table])
print('y_table', [f'{y:02X}' for y in y_table])
print('values len', len(values))
print('records', len(records), 'changed bytes', sum(len(b) for _, b in records))
