#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists():
    BASE = ORIG
LATIN = ROOT / 'Roms/Anteriores/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
OUT = ROOT / 'Roms/Momotarou Katsugeki (Japan) - password_grid_10col_logic_test.pce'
IPS = ROOT / 'Parches/momotaro_password_grid_10col_logic_test.ips'
REPORT = ROOT / 'reports/test_password_grid_10col_logic.md'
PREVIEW = ROOT / 'images/password_grid_10col_logic_preview.png'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())
latin = LATIN.read_bytes()

# ---------------------------------------------------------------------------
# Encoding used by the validated latin font test.
# ---------------------------------------------------------------------------
enc = {' ': 0x20}
for i in range(10):
    enc[str(i)] = 0x30 + i
for i, ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    enc[ch] = 0x41 + i
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    enc[ch] = 0xA1 + i
# validated source-code exceptions in this engine/text path
enc['b'] = 0x5B
enc['c'] = 0x5D
enc['p'] = 0x5E
enc.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

# 64 symbols: 27 uppercase incl. Ñ + 27 lowercase incl. ñ + 10 digits.
# User asked for 10 columns; 64 symbols become 6 full rows + final row of 4.
grid_rows = [
    list('ABCDEFGHIJ'),
    ['K', 'L', 'M', 'N', 'Ñ', 'O', 'P', 'Q', 'R', 'S'],
    list('TUVWXYZ') + ['a', 'b', 'c'],
    list('defghijklm'),
    ['n', 'ñ', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v'],
    list('wxyz012345'),
    list('6789'),
]
symbols = [ch for row in grid_rows for ch in row]
assert len(symbols) == 64, len(symbols)
source = bytes([enc[ch] for ch in symbols])

# ---------------------------------------------------------------------------
# 1) Copy validated latin font/conversion tables.
# ---------------------------------------------------------------------------
FONT_BASE = 0x3D660
FONT_LEN = 0xE0 * 8
rom[FONT_BASE:FONT_BASE + FONT_LEN] = latin[FONT_BASE:FONT_BASE + FONT_LEN]
latin_table_regions = [(0x41CB3, 0x40), (0x41CF3, 0x40), (0x42B5B, 0x36)]
for off, length in latin_table_regions:
    rom[off:off + length] = latin[off:off + length]

# ---------------------------------------------------------------------------
# 2) Relocate runtime alphabet source.
#    Important: drawn tile/pattern IDs start at 1. The previous test placed
#    IDs 0..63 in the tilemap, so A was blank/shifted and 9 never appeared.
# ---------------------------------------------------------------------------
new_off = 0x1BBB9
new_cpu = 0xDBB9
table = bytes([0x01]) + source + bytes([0xFF])
rom[new_off:new_off + len(table)] = table
# Pointer low/high in C844 source reader.
rom[0x1A85E] = new_cpu & 0xFF
rom[0x1A862] = new_cpu >> 8

# ---------------------------------------------------------------------------
# 3) RLE tilemap streams.
#    Decoded plane is 32x32. Original stream is sparse and fits exactly in
#    low: 0x1E18C-0x1E28F and high: 0x1E290-0x1E29B.
# ---------------------------------------------------------------------------
def rle_encode(vals):
    out = bytearray()
    i = 0
    while i < len(vals):
        v = vals[i]
        j = i + 1
        while j < len(vals) and vals[j] == v and j - i < 256:
            j += 1
        L = j - i
        if L >= 3 or v == 0xFF:
            out += bytes([0xFF, L - 1, v])
        else:
            out += bytes([v]) * L
        i = j
    return bytes(out)

# Character tile positions. Columns are 16 px apart (not 24 px like the 8x8
# test), rows are 16 px apart (not glued every 8 px).
tile_rows = [6, 8, 10, 12, 14, 16, 18]
tile_cols = [3, 5, 7, 9, 11, 13, 15, 17, 19, 21]

tm = [[0x100 for _ in range(32)] for __ in range(32)]
value = 1
for rr, row in enumerate(grid_rows):
    for cc, _ch in enumerate(row):
        tm[tile_rows[rr]][tile_cols[cc]] = 0x100 + value
        value += 1
assert value == 65

low = []
high = []
for r in range(32):
    for c in range(32):
        w = tm[r][c]
        low.append(w & 0xFF)
        # Existing high stream is 0 for tile words 0x100..0x1FF.
        high.append(((w >> 8) - 1) & 0xFF)
low_stream = rle_encode(low)
high_stream = rle_encode(high)
low_region_len = 0x1E290 - 0x1E18C
high_region_len = 0x1E29C - 0x1E290
assert len(low_stream) <= low_region_len, (len(low_stream), low_region_len)
assert len(high_stream) <= high_region_len, (len(high_stream), high_region_len)
rom[0x1E18C:0x1E290] = low_stream + bytes([0xFF]) * (low_region_len - len(low_stream))
rom[0x1E290:0x1E29C] = high_stream + bytes([0xFF]) * (high_region_len - len(high_stream))

# ---------------------------------------------------------------------------
# 4) Cursor/selection logic: previous test forgot x/y coordinate tables.
#    CC61 = row offsets, CC6B = cursor x table, CC78 = cursor y table,
#    CC82 = selected values.
# ---------------------------------------------------------------------------
# Logical 10 columns x 7 rows. Last row has only 4 valid symbols; the rest are
# zeros so the original "skip invalid cell" loops skip/wrap them.
row_offsets = [0, 10, 20, 30, 40, 50, 60, 0, 0, 0]
rom[0x1AC61:0x1AC61 + 10] = bytes(row_offsets)

# Cursor sprite coordinate is approximately 8 px to the left of the glyph tile,
# matching the original table (tile c28 x=224 -> cursor x=216).
x_table = [(c * 8) - 8 for c in tile_cols] + [0, 0, 0]
y_table = [r * 8 for r in tile_rows] + [0, 0, 0]
assert len(x_table) == 13
assert len(y_table) == 10
rom[0x1AC6B:0x1AC6B + 13] = bytes(x_table)
rom[0x1AC78:0x1AC78 + 10] = bytes(y_table)

values = []
value = 1
for row in grid_rows:
    row_values = []
    for _ch in row:
        row_values.append(value)
        value += 1
    while len(row_values) < 10:
        row_values.append(0)
    values.extend(row_values)
assert value == 65
values += [0] * (130 - len(values))
assert len(values) == 130
rom[0x1AC82:0x1AC82 + 130] = bytes(values)

# Navigation bounds: rows 0..6, columns 0..9.
nav_patches = {
    0x1AA56: 0x06,  # CA55 LDA #$09 -> row wrap up = 6
    0x1AA6A: 0x07,  # CA69 CMP #$0A -> row max exclusive = 7
    0x1AA80: 0x0A,  # CA7F CMP #$0D -> column max exclusive = 10
    0x1AA95: 0x09,  # CA94 LDA #$0C -> column wrap left = 9
}
for off, val in nav_patches.items():
    rom[off] = val

# ---------------------------------------------------------------------------
# Output ROM + IPS against original clean ROM.
# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
IPS.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
PREVIEW.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(rom)
new = bytes(rom)
records = []
i = 0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s = i
    buf = bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i])
        i += 1
    records.append((s, bytes(buf)))
ips = bytearray(b'PATCH')
for off, buf in records:
    ips += off.to_bytes(3, 'big') + len(buf).to_bytes(2, 'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# Simple static preview of intended logical layout (not emulator rendering).
scale = 3
img = Image.new('RGB', (256 * scale, 240 * scale), (0, 0, 220))
d = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 8 * scale)
except Exception:
    font = ImageFont.load_default()
for rr, row in enumerate(grid_rows):
    for cc, ch in enumerate(row):
        x = tile_cols[cc] * 8 * scale
        y = tile_rows[rr] * 8 * scale
        d.text((x, y), ch, fill=(255, 255, 255), font=font)
# mark cursor anchor positions in red for x/y table sanity
for rr, row in enumerate(grid_rows):
    for cc, _ch in enumerate(row):
        cx = x_table[cc] * scale
        cy = y_table[rr] * scale
        d.polygon([(cx, cy + 2 * scale), (cx, cy + 6 * scale), (cx + 5 * scale, cy + 4 * scale)], fill=(255, 60, 60))
img.save(PREVIEW)

layout_text = '\n'.join(''.join(row) for row in grid_rows)
changed_relevant = [
    ('Fuente latina 1bpp', FONT_BASE, FONT_LEN),
    ('Tabla conversión latina 1', 0x41CB3, 0x40),
    ('Tabla conversión latina 2', 0x41CF3, 0x40),
    ('Tabla conversión latina 3', 0x42B5B, 0x36),
    ('Puntero tabla runtime low', 0x1A85E, 1),
    ('Puntero tabla runtime high', 0x1A862, 1),
    ('Tabla runtime 64 símbolos', new_off, len(table)),
    ('Tilemap RLE low', 0x1E18C, low_region_len),
    ('Tilemap RLE high', 0x1E290, high_region_len),
    ('Nav row wrap up', 0x1AA56, 1),
    ('Nav row max', 0x1AA6A, 1),
    ('Nav col max', 0x1AA80, 1),
    ('Nav col wrap left', 0x1AA95, 1),
    ('CC61 offsets fila', 0x1AC61, 10),
    ('CC6B tabla X cursor', 0x1AC6B, 13),
    ('CC78 tabla Y cursor', 0x1AC78, 10),
    ('CC82 valores selección', 0x1AC82, 130),
]
changed_relevant_md = '\n'.join(f'- {name}: `0x{off:05X}` len `{length}`' for name, off, length in changed_relevant)
REPORT.write_text(f'''# Password grid 10-column logic test

ROM: `Roms/{OUT.name}`

IPS: `Parches/{IPS.name}`

Preview estático: `images/{PREVIEW.name}`

## Objetivo

Nueva prueba centrada en alinear visual y lógica de la parrilla del password:

- 64 símbolos latinos.
- 10 columnas, como se pidió.
- Separación horizontal de 16 px.
- Separación vertical de 16 px.
- Cursor con tablas X/Y parcheadas, no heredadas del layout japonés.
- Tile IDs empezando en `1`, no en `0`, para que no desaparezcan `A`/`9` por desplazamiento.

## Parrilla esperada

```text
{layout_text}
```

El último renglón tiene sólo `6789`; las seis celdas restantes son inválidas y la rutina original debería saltarlas.

## Correcciones respecto al test anterior

1. **Off-by-one visual**: el test anterior colocaba `0..63` en tilemap. En esta pantalla el patrón 0 queda en blanco y los glifos generados empiezan en 1. Por eso la parrilla se desplazaba y faltaba el `9`. Ahora se colocan `1..64`.
2. **Tablas X/Y del cursor**: el test anterior cambiaba valores y límites, pero dejaba la tabla X japonesa (`D8 C8 B8...`). Por eso el puntero sólo podía moverse por una franja y el orden físico salía invertido. Ahora `CC6B` y `CC78` se parchean para el layout latino.
3. **Geometría**: pasa de 8x8 a 10 columnas; las filas se separan una tile-row en blanco para no quedar pegadas.

## Validación estática hecha antes de generar

- Símbolos codificados: `{len(symbols)}`.
- Tabla runtime: `{len(table)}` bytes en `0x{new_off:05X}`.
- Low stream RLE: `{len(low_stream)}` / `{low_region_len}` bytes.
- High stream RLE: `{len(high_stream)}` / `{high_region_len}` bytes.
- X table: `{len(x_table)}` bytes, navegación limitada a las 10 primeras columnas.
- Y table: `{len(y_table)}` bytes, navegación limitada a las 7 primeras filas.
- Valores `CC82`: `{len(values)}` / 130 bytes.

## Regiones relevantes cambiadas

{changed_relevant_md}

## Qué comprobar en emulador

1. Que se ven 10 columnas y el `9` aparece.
2. Que el cursor llega a la primera columna real y a la décima columna real.
3. Que la esquina superior izquierda introduce `A`.
4. Que hacia la derecha se introducen `B`, `C`, `D`...
5. Que al bajar desde `A` se llega a `K`, luego `T`, etc.
6. Que la última fila sólo contiene `6 7 8 9` y el cursor salta las celdas vacías.

Nota: las opciones de la derecha (`ADELANTE`, `ATRÁS`, `ESPACIO`, `BORRAR`, `FIN`) todavía no son el objetivo de esta ROM. Primero hay que dejar cuadrada la parrilla visual/lógica.
''', encoding='utf-8')

print('OUT', OUT)
print('IPS', IPS)
print('REPORT', REPORT)
print('PREVIEW', PREVIEW)
print('layout:')
print(layout_text)
print('low/high', len(low_stream), '/', low_region_len, len(high_stream), '/', high_region_len)
print('x_table', [f'{x:02X}' for x in x_table])
print('y_table', [f'{y:02X}' for y in y_table])
print('records', len(records), 'changed bytes', sum(len(b) for _, b in records))
