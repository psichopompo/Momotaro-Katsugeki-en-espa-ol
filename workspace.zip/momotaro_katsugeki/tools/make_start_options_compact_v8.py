#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_options_compact_test_v8.pce'
IPS=ROOT/'Parches/momotaro_start_options_compact_test_v8.ips'
PREVIEW=ROOT/'images/start_options_compact_v8_preview.png'
REPORT=ROOT/'reports/test_empezar_continuar_compact_v8.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
FONT={
 'A':["0110","1001","1001","1111","1001","1001","1001"],
 'C':["0111","1000","1000","1000","1000","1000","0111"],
 'E':["1111","1000","1000","1110","1000","1000","1111"],
 'I':["1110","0100","0100","0100","0100","0100","1110"],
 'M':["1001","1111","1111","1001","1001","1001","1001"],
 'N':["1001","1101","1011","1001","1001","1001","1001"],
 'O':["0110","1001","1001","1001","1001","1001","0110"],
 'P':["1110","1001","1001","1110","1000","1000","1000"],
 'R':["1110","1001","1001","1110","1010","1001","1001"],
 'T':["1111","0100","0100","0100","0100","0100","0100"],
 'U':["1001","1001","1001","1001","1001","1001","0110"],
 'Z':["1111","0001","0010","0100","1000","1000","1111"],
 ' ': ["0000"]*7,
}
def draw(img,text,x,y,fill=1,shadow=2):
 p=img.load(); cx=x
 for ch in text:
  pat=FONT[ch]
  if shadow:
   for yy,row in enumerate(pat):
    for xx,b in enumerate(row):
     if b=='1':
      sx=cx+xx+1; sy=y+yy+1
      if 0<=sx<img.width and 0<=sy<img.height and p[sx,sy]==0: p[sx,sy]=shadow
  for yy,row in enumerate(pat):
   for xx,b in enumerate(row):
    if b=='1':
     px=cx+xx; py=y+yy
     if 0<=px<img.width and 0<=py<img.height: p[px,py]=fill
  cx+=4
def enc_sprite16(img,x0):
 out=[]
 for plane in range(4):
  for y in range(16):
   b0=b1=0
   for x in range(8):
    c=img.getpixel((x0+x,y)); b0=(b0<<1)|((c>>plane)&1)
   for x in range(8,16):
    c=img.getpixel((x0+x,y)); b1=(b1<<1)|((c>>plane)&1)
   out.extend([b0,b1])
 return bytes(out)
def comp(raw):
 out=bytearray()
 for base in [0,0x20,0x40,0x60]:
  for y0 in [0,1,0x10,0x11]:
   vals=[raw[base+y0+i*2] for i in range(8)]
   mask=0; payload=[]; prev=0
   for i,v in enumerate(vals):
    bit=7-i
    if i==0:
     if v: mask|=1<<bit; payload.append(v)
    elif v!=prev:
     mask|=1<<bit; payload.append(v)
    prev=v
   out.append(mask); out+=bytes(payload)
 return bytes(out)
canvas=Image.new('P',(80,16),0)
draw(canvas,'EMPEZAR',0,4,1,2)
draw(canvas,'CONTINUAR',40,4,1,2)
patterns=[enc_sprite16(canvas,x) for x in range(0,80,16)]
stream=bytearray([len(patterns)]); lens=[]
for p in patterns:
 c=comp(p); lens.append(len(c)); stream+=c
old_start=0x272DE; old_end=0x273F9; max_len=old_end-old_start
assert len(stream)<=max_len
rom[old_start:old_start+len(stream)]=stream
rom[old_start+len(stream):old_end]=bytes([0xFF])*(max_len-len(stream))
# New 3-sprite metasprite lists, like original; 2 wide sprites + 1 narrow.
list1_off=0x2F8B5; list2_off=list1_off+3*5+1
list1_cpu=0x4000+(list1_off-0x2E000); list2_cpu=0x4000+(list2_off-0x2E000)
def rec(tile,attr,attr2,dx,dy): return bytes([tile,attr,attr2,dx&0xff,dy&0xff])
# entry1 chunks 0-1 (EMPEZAR) selected/unselected; entry2 chunks 2-3 (start CONTINUAR); entry3 chunk4.
list1=b''.join([rec(0x00,0x07,0x01,-45,-16), rec(0x02,0x06,0x01,-13,-16), rec(0x04,0x06,0x00,19,-16)])+b'\xff'
list2=b''.join([rec(0x00,0x06,0x01,-45,-16), rec(0x02,0x07,0x01,-13,-16), rec(0x04,0x07,0x00,19,-16)])+b'\xff'
rom[list1_off:list1_off+len(list1)]=list1
rom[list2_off:list2_off+len(list2)]=list2
rom[0x2E6B1:0x2E6B5]=bytes([list1_cpu&0xff,list1_cpu>>8,list2_cpu&0xff,list2_cpu>>8])
OUT.write_bytes(rom)
new=bytes(rom); records=[]; i=0
while i<len(orig):
 if orig[i]==new[i]: i+=1; continue
 s=i; buf=bytearray()
 while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
  buf.append(new[i]); i+=1
 records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
pal=[(0,0,80),(255,109,33),(33,36,33)]; scale=5
prev=Image.new('RGB',(80*scale,16*scale),pal[0])
for y in range(16):
 for x in range(80):
  c=canvas.getpixel((x,y))
  if c:
   for yy in range(scale):
    for xx in range(scale): prev.putpixel((x*scale+xx,y*scale+yy),pal[c])
PREVIEW.parent.mkdir(parents=True,exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Test v8 compacto `EMPEZAR / CONTINUAR`\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Cambio v8\n\nLa v7 usaba 5 sprites de 16 px y probablemente superaba el presupuesto/lógica de sprites de la pantalla. V8 usa la misma estructura que el original: 3 entradas de metasprite.\n\n- Entrada 1: sprite 32 px, patrones 0-1.\n- Entrada 2: sprite 32 px, patrones 2-3.\n- Entrada 3: sprite 16 px, patrón 4.\n\nEsto cubre 80 px con sólo 3 sprites, como el original.\n\n## Datos\n\n- Stream original reutilizado: `0x272DE-0x273F8`.\n- Stream nuevo: `{len(stream)}` bytes de {max_len}.\n- Lens: `{lens}`.\n- Lista 1: CPU `${list1_cpu:04X}`, ROM `0x{list1_off:05X}`.\n- Lista 2: CPU `${list2_cpu:04X}`, ROM `0x{list2_off:05X}`.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream',len(stream),'lens',lens)
print('list1',hex(list1_cpu),list1.hex(' '))
print('records',len(records),sum(len(b) for _,b in records))
