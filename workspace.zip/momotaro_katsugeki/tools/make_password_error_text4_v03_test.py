#!/usr/bin/env python3
from pathlib import Path

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT = ROOT / 'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_vanilla_test.pce'
IPS = ROOT / 'Parches/Pruebas/momotaro_traduccion_v03_error_text4_vanilla_test.ips'
REPORT = ROOT / 'reports/test_password_error_text4_vanilla_v03.md'

orig = ORIG.read_bytes()
base = BASE.read_bytes()
rom = bytearray(base)

# Encoder latino validado.
CHAR_TO_CODE = {' ': 0x20}
for i in range(10): CHAR_TO_CODE[str(i)] = 0x30 + i
for i in range(26): CHAR_TO_CODE[chr(ord('A') + i)] = 0x41 + i
CHAR_TO_CODE.update({'!': 0x21, '?': 0x3F, '$': 0x24})
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'): CHAR_TO_CODE[ch] = 0xA1 + i
CHAR_TO_CODE['b'] = 0x5B; CHAR_TO_CODE['c'] = 0x5D; CHAR_TO_CODE['p'] = 0x5E
CHAR_TO_CODE.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

def enc_text(s: str) -> bytes:
    out = bytearray()
    for ch in s:
        if ch == '\n':
            out.append(0x00)
        else:
            if ch not in CHAR_TO_CODE:
                raise ValueError(f'Carácter no soportado: {ch!r}')
            out.append(CHAR_TO_CODE[ch])
    return bytes(out)

def cpu_from_bank0f(off: int) -> int:
    assert 0x1E000 <= off < 0x20000
    return 0x4000 + (off - 0x1E000)

def ptr_patch_abs(off_low: int, off_high: int, cpu: int) -> None:
    rom[off_low] = cpu & 0xFF
    rom[off_high] = cpu >> 8

# ---------------------------------------------------------------------------
# 1) Revertir pantalla de error a la de v02/original para este contexto.
# ---------------------------------------------------------------------------
# Al partir de traduccion_v02 ya NO hay cambios de bocadillo/viewport/metasprite
# de las pruebas v03 fallidas. Para validarlo, dejamos intactas las regiones
# que corrompieron COMENZAR/CONTINUAR en la prueba anterior (bank $17).

# ---------------------------------------------------------------------------
# 2) Insertar SOLO el mensaje de error de Jizo en 4 líneas, sin tocar bocadillo.
# ---------------------------------------------------------------------------
text = '¡El canto de Jizo\nno es correcto!\nRevísalo bien e\ninténtalo de nuevo.'
line_lengths = [len(line) for line in text.split('\n')]
error_off = 0x1F838
error_cpu = cpu_from_bank0f(error_off)
error_data = bytes([0x01]) + enc_text(text) + bytes([0xFF])
assert orig[error_off:error_off+len(error_data)] == bytes([0xFF]) * len(error_data)
rom[error_off:error_off+len(error_data)] = error_data
# CE5F/CE63 load the error string pointer.
ptr_patch_abs(0x1AE60, 0x1AE64, error_cpu)

# ---------------------------------------------------------------------------
# 3) Dar una 4.ª dirección de línea válida, sin cambiar viewport ni bocadillo.
# ---------------------------------------------------------------------------
# Esto NO amplía lo visible; sólo evita que la cuarta línea se escriba en una
# dirección basura del código. La ventanilla/proyección sigue siendo la original.
line_table_off = 0x1BDB0
line_table_cpu = 0xDDB0
line_table = bytes([0x08,0x70, 0x08,0x72, 0x08,0x74, 0x08,0x76])
assert orig[line_table_off:line_table_off+len(line_table)] == bytes([0xFF]) * len(line_table)
assert base[line_table_off:line_table_off+len(line_table)] == bytes([0xFF]) * len(line_table)
rom[line_table_off:line_table_off+len(line_table)] = line_table
# CE67/CE6F initial line; CEF3/CEF8 newline table lookup.
for off, cpu in [(0x1AE68,line_table_cpu), (0x1AE70,line_table_cpu+1), (0x1AEF4,line_table_cpu), (0x1AEF9,line_table_cpu+1)]:
    rom[off] = cpu & 0xFF
    rom[off+1] = cpu >> 8

# Guardas estáticas: no tocar las zonas de bocadillo/viewport fallidas.
# - stream caja central original en bank $0F cerca de 0x1E29C queda como v02/base
# - viewport/metasprite bank $17 cerca de 0x2EC10/0x2F8B5 queda como v02/base
for start, end, name in [
    (0x1E29C, 0x1E2DF, 'tilemap caja error original'),
    (0x2EC10, 0x2EC4D, 'viewport original $4C10'),
    (0x2F8B5, 0x2F930, 'zona libre bank17 no usada'),
]:
    assert rom[start:end] == base[start:end], name

# ---------------------------------------------------------------------------
# Output ROM + IPS acumulativo contra original limpio.
# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
IPS.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(rom)
new = bytes(rom)
records = []
i = 0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s = i
    buf = bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i])
        i += 1
    records.append((s, bytes(buf)))
ips = bytearray(b'PATCH')
for off, buf in records:
    ips += off.to_bytes(3, 'big') + len(buf).to_bytes(2, 'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# Diff contra v02 para verificar que esta prueba sólo toca error/texto.
changed_vs_base = []
i = 0
while i < len(base):
    if base[i] == new[i]:
        i += 1; continue
    s = i
    while i < len(base) and base[i] != new[i]:
        i += 1
    changed_vs_base.append((s, i-s))

REPORT.write_text(f'''# Prueba v03 — error de Jizo 4 líneas con pantalla original

ROM de prueba:

`Roms/Pruebas/{OUT.name}`

IPS:

`Parches/Pruebas/{IPS.name}`

## Objetivo

Revertir completamente los cambios de bocadillo/viewport/metasprite del mensaje de error y volver al estado de `traduccion_v02` para esa pantalla.

Después se inserta **sólo** el texto de error en las cuatro líneas fijadas por el usuario:

```text
{text}
```

No se toca el bocadillo. No se toca el viewport/proyección. No se cambia el texto después de esta prueba.

## Detalle técnico

- Base: `traduccion_v02` confirmada.
- Texto nuevo: ROM `0x{error_off:05X}`, CPU `${error_cpu:04X}`, len `{len(error_data)}`.
- Se parchea sólo el puntero de error `CE5F/CE63` hacia el texto nuevo.
- Se añade una 4.ª entrada válida a la tabla de líneas en ROM `0x{line_table_off:05X}` / CPU `${line_table_cpu:04X}`:
  - `$7008`
  - `$7208`
  - `$7408`
  - `$7608`
- La tabla de líneas sólo define dónde está el paisaje/texto en VRAM; **no amplía la ventanilla visible**.

## Longitudes de línea

```text
{line_lengths}
```

## Validación anti-corrupción

Se ha comprobado antes de escribir que estas regiones quedan idénticas a `traduccion_v02`:

- `0x1E29C-0x1E2DF`: tilemap original de la caja central de error.
- `0x2EC10-0x2EC4D`: viewport/metasprite original usado por la pantalla.
- `0x2F8B5-0x2F930`: zona libre bank17; no se escribe nada ahí.

Cambios contra `traduccion_v02`:

{chr(10).join(f'- `0x{off:05X}` len `{ln}`' for off, ln in changed_vs_base)}

## Qué comprobar

1. Que EMPEZAR/CONTINUAR ya no se corrompen.
2. Que la caja/bocadillo del error vuelve al estado original.
3. Qué parte exacta de las cuatro líneas se ve.
4. Dónde se corta el texto: horizontalmente, verticalmente o por la ventanilla.
5. No evaluar todavía si el bocadillo es bonito: esta prueba es sólo para medir la ventanilla real.
''', encoding='utf-8')

print('OUT', OUT)
print('IPS', IPS)
print('REPORT', REPORT)
print('error text len', len(error_data), 'cpu', hex(error_cpu), 'line lengths', line_lengths)
print('line table', hex(line_table_off), hex(line_table_cpu), line_table.hex(' '))
print('changed vs base', changed_vs_base)
print('records vs orig', len(records), 'changed bytes', sum(len(b) for _, b in records))
