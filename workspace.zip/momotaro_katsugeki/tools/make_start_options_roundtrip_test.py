#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.append('/home/user/momotaro_katsugeki/tools')
from decompress_f1b9_sprites import decomp_stream

ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_options_roundtrip_test.pce'
IPS=ROOT/'Parches/momotaro_start_options_roundtrip_test.ips'
REPORT=ROOT/'reports/test_roundtrip_stream_opciones.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())

def compress_sprite(raw128):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw128[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v!=0:
                        mask |= 1<<bit; payload.append(v)
                else:
                    if v!=prev:
                        mask |= 1<<bit; payload.append(v)
                prev=v
            out.append(mask); out += bytes(payload)
    return bytes(out)

start=0x272DE; end=0x273F9; max_len=end-start
sprites, end_dec = decomp_stream(orig,start)
stream=bytearray([len(sprites)])
lens=[]
for s in sprites:
    c=compress_sprite(s); lens.append(len(c)); stream+=c
if len(stream)>max_len:
    raise SystemExit(f'roundtrip stream too long {len(stream)} > {max_len}')
rom[start:start+len(stream)] = stream
rom[start+len(stream):end] = bytes([0xFF])*(max_len-len(stream))
# Do not touch original metasprite lists. Prompt is still final title prompt from BASE.
OUT.write_bytes(rom)
# IPS vs original clean.
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]:
        i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big') + len(buf).to_bytes(2,'big') + buf
ips += b'EOF'; IPS.write_bytes(ips)
REPORT.write_text(f'''# Test roundtrip del stream gráfico original de `HAJIMETE / TSUZUGI`\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\n## Objetivo\n\nValidar si nuestro descompresor+recompresor del stream de opciones es correcto.\n\nSe hace:\n\n1. Descomprimir el stream original `0x272DE`.\n2. Recomprírmirlo con nuestro compresor.\n3. Reinsertarlo en la ubicación original.\n4. Dejar intactas las listas de metasprite originales.\n\n## Resultado esperado\n\nAl pulsar RUN deberían verse los rótulos japoneses originales perfectamente, igual que en la ROM limpia, pero con el prompt ya traducido `PULSA BOTÓN RUN`.\n\n- Si se ven bien: el compresor es correcto y el problema está en cómo generamos/ordenamos los patrones nuevos o sus listas.\n- Si se ven mal: el compresor/descompresor todavía no reproduce el formato real.\n\n## Datos\n\n- Patrones descomprimidos: `{len(sprites)}`.\n- Fin de descompresión original: `0x{end_dec:05X}`.\n- Espacio original: `{max_len}` bytes.\n- Stream recomprimido: `{len(stream)}` bytes.\n- Longitudes por patrón: `{lens}`.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('sprites',len(sprites),'end_dec',hex(end_dec),'stream_len',len(stream),'lens',lens)
print('OUT',OUT)
print('records',records)
