#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Anteriores/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
ASSET=ROOT/'title_assets/title_logo_es_fullscreen.png'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_fit_layout_test_v8.pce'
IPS=ROOT/'Parches/momotaro_title_logo_spanish_fit_layout_test_v8.ips'
PREVIEW=ROOT/'images/title_logo_spanish_fit_layout_v8_preview.png'
FITPNG=ROOT/'title_assets/title_logo_es_fullscreen_fit_original_layout.png'
REPORT=ROOT/'reports/test_rotulo_titulo_fit_layout_v8.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
asset0=Image.open(ASSET).convert('RGBA')
# Make a fitted version: original user logo bbox 251x56 at (2,35) => resize horizontally to original sprite coverage 240 px at x=7.
bbox=asset0.getbbox()  # alpha bbox
crop=asset0.crop(bbox)
fit=Image.new('RGBA',asset0.size,(0,0,0,0))
fit_crop=crop.resize((240,crop.height),Image.Resampling.NEAREST)
fit.alpha_composite(fit_crop,(7,bbox[1]))
FITPNG.parent.mkdir(exist_ok=True); fit.save(FITPNG)
asset=fit
main_map={(0,0,0):4,(0,36,182):2,(0,146,219):3,(219,182,0):5,(146,73,36):1}
peach_map={(0,0,0):4,(255,146,109):1,(73,109,36):2,(219,182,219):3,(219,36,109):5,(255,73,146):6,(255,109,255):7}
peach_seed_colors={(219,36,109),(255,109,255),(255,73,146),(255,146,109),(219,182,219),(73,109,36)}
def nearest_idx(rgb,mp):
    if rgb in mp: return mp[rgb]
    best=min(mp, key=lambda c: sum((rgb[i]-c[i])**2 for i in range(3)))
    return mp[best]
# Original logo list.
list_off=0x2E2B0
entries=[]; i=list_off
while orig[i]!=0xFF:
    tile,a1,a2,dx,dy=orig[i:i+5]
    dx=dx-256 if dx>=128 else dx; dy=dy-256 if dy>=128 else dy
    entries.append((tile,a1,a2,dx,dy)); i+=5
BASE_X=128; BASE_Y=88
# precise peach mask from fitted asset
seed=set()
for y in range(asset.height):
    for x in range(asset.width):
        r,g,b,a=asset.getpixel((x,y))
        if a and (r,g,b) in peach_seed_colors:
            seed.add((x,y))
peach_mask=set(seed)
for x,y in list(seed):
    for yy in range(y-1,y+2):
        for xx in range(x-1,x+2):
            if 0<=xx<asset.width and 0<=yy<asset.height:
                r,g,b,a=asset.getpixel((xx,yy))
                if a and (r,g,b)==(0,0,0): peach_mask.add((xx,yy))
# Limit central region based on seed bbox expanded.
mx0,my0,mx1,my1=min(x for x,y in seed),min(y for x,y in seed),max(x for x,y in seed),max(y for x,y in seed)
peach_mask={p for p in peach_mask if mx0-2 <= p[0] <= mx1+2 and my0-2 <= p[1] <= my1+2}
mx0,my0,mx1,my1=min(x for x,y in peach_mask),min(y for x,y in peach_mask),max(x for x,y in peach_mask),max(y for x,y in peach_mask)
SPECIAL_X=mx1-15; SPECIAL_Y=my1-15
SPECIAL_X=max(0,min(SPECIAL_X,mx0)); SPECIAL_Y=max(0,min(SPECIAL_Y,my0))
patterns=[[[0 for _ in range(16)] for _ in range(16)] for _ in range(64)]
def dims(a2): return (2 if a2&1 else 1), {0:1,1:2,3:4}.get((a2>>4)&3,1)
for tile,a1,a2,dx,dy in entries:
    if tile==0x3C: continue
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile+row*2+col
            if not (0<=pidx<64): continue
            sx0=BASE_X+dx+col*16; sy0=BASE_Y+dy+row*16; arr=patterns[pidx]
            for y in range(16):
                sy=sy0+y
                if sy<0 or sy>=asset.height: continue
                for x in range(16):
                    sx=sx0+x
                    if sx<0 or sx>=asset.width: continue
                    if (sx,sy) in peach_mask: continue
                    r,g,b,a=asset.getpixel((sx,sy))
                    if a: arr[y][x]=nearest_idx((r,g,b),main_map)
# peach pattern
arr=patterns[0x3C]
for y in range(16):
    sy=SPECIAL_Y+y
    for x in range(16):
        sx=SPECIAL_X+x
        if (sx,sy) in peach_mask:
            r,g,b,a=asset.getpixel((sx,sy))
            if a: arr[y][x]=nearest_idx((r,g,b),peach_map)
# Encode swapped bytes per row.
def encode(arr):
    out=[]
    for plane in range(4):
        for y in range(16):
            b0=b1=0
            for x in range(8,16):
                c=arr[y][x]; b0=(b0<<1)|((c>>plane)&1)
            for x in range(0,8):
                c=arr[y][x]; b1=(b1<<1)|((c>>plane)&1)
            out.extend([b0,b1])
    return bytes(out)
def comp(raw):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v: mask|=1<<bit; payload.append(v)
                elif v!=prev:
                    mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out+=bytes(payload)
    return bytes(out)
stream=bytearray([64]); lens=[]
for arr in patterns:
    c=comp(encode(arr)); lens.append(len(c)); stream+=c
start=0x252C8; end=0x2617B; max_len=end-start
if len(stream)>max_len: raise SystemExit(f'stream {len(stream)} > {max_len}')
rom[start:start+len(stream)]=stream
rom[start+len(stream):end]=bytes([0xFF])*(max_len-len(stream))
# patch peach sprite entry position
rom[list_off+3]=(SPECIAL_X-BASE_X)&0xff
rom[list_off+4]=(SPECIAL_Y-BASE_Y)&0xff
OUT.write_bytes(rom)
# IPS
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
# Preview
pal=[(0,0,80),(146,73,36),(0,36,182),(0,146,219),(0,0,0),(219,182,0),(255,73,146),(255,109,255),(0,0,0),(80,80,80),(219,182,0),(255,146,109),(73,109,36),(219,182,219),(219,36,109),(255,109,255)]
prev=Image.new('RGB',(256,120),(0,0,80))
entries2=entries.copy(); entries2[0]=(0x3C,5,0,SPECIAL_X-BASE_X,SPECIAL_Y-BASE_Y)
for tile,a1,a2,dx,dy in entries2:
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile+row*2+col
            if 0<=pidx<64:
                sx0=BASE_X+dx+col*16; sy0=BASE_Y+dy+row*16; arr=patterns[pidx]
                for y in range(16):
                    for x in range(16):
                        c=arr[y][x]
                        if c:
                            px=sx0+x; py=sy0+y
                            if 0<=px<256 and 0<=py<120: prev.putpixel((px,py),pal[c])
PREVIEW.parent.mkdir(exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Test rótulo español — v8 encajado al layout original\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\nPNG intermedio: `title_assets/{FITPNG.name}`\n\n## Cambio v8\n\nEl layout original de sprites cubre aproximadamente 240 px de ancho. El asset entregado cubre 251 px y por eso se cortaba a ambos lados.\n\nEsta prueba ajusta horizontalmente el rótulo de 251 px a 240 px, manteniendo altura, colores, posición vertical y máscara de melocotón.\n\nNo modifica la lista original salvo la posición del sprite separado del melocotón.\n\n## Datos\n\n- BBox original del asset: {bbox}.\n- Nuevo ancho: 240 px, pegado en x=7.\n- Stream: {len(stream)} bytes de {max_len}.\n- Peach bbox: ({mx0},{my0})-({mx1},{my1}), sprite ({SPECIAL_X},{SPECIAL_Y}).\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('bbox',bbox,'stream',len(stream),'max',max_len,'peach',mx0,my0,mx1,my1,SPECIAL_X,SPECIAL_Y)
print('records',len(records),sum(len(b) for _,b in records))
