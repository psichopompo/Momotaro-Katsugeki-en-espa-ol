#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_safe_table_test.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v04_password_menu_safe_table_test.ips'
REPORT=ROOT/'reports/test_v04_password_menu_safe_table.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)
# Encoder latino validado.
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i in range(26): enc[chr(65+i)]=0x41+i
enc.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s:str)->bytes:
    out=bytearray(); i=0
    while i<len(s):
        if s[i]=='\n': out.append(0); i+=1; continue
        ch=s[i]
        if ch not in enc: raise ValueError(f'No soportado {ch!r}')
        out.append(enc[ch]); i+=1
    return bytes(out)
def cpu0f(off:int)->int:
    assert 0x1E000<=off<0x20000
    return 0x4000+(off-0x1E000)
def ptr(cpu:int)->bytes: return bytes([cpu&0xff,cpu>>8])
# Allocator in v03 free area after prompt/error structures.
alloc=0x1FB10; alloc_end=0x20000
assert orig[alloc:alloc_end]==bytes([0xFF])*(alloc_end-alloc)
assert base[alloc:alloc_end]==bytes([0xFF])*(alloc_end-alloc)
allocs={}
def put(name,payload,term=0):
    global alloc
    off=alloc; data=payload+bytes([term])
    assert off+len(data)<=alloc_end
    assert orig[off:off+len(data)]==bytes([0xFF])*len(data)
    assert base[off:off+len(data)]==bytes([0xFF])*len(data)
    rom[off:off+len(data)]=data
    cpu=cpu0f(off); allocs[name]=(off,cpu,len(data),data); alloc+=len(data)
    return cpu
PFX1=bytes([1,0x3C]); PFX2=bytes([2,0x3C])
diff_facil=put('diff_facil',PFX1+enc_text('FÁCIL'))
diff_normal=put('diff_normal',PFX1+enc_text('NORMAL'))
diff_dificil=put('diff_dificil',PFX1+enc_text('DIFÍCIL'))
diff_muy=put('diff_muy_dificil',PFX2+enc_text('MUY DIFÍCIL'))
empty=put('empty',b'')
menu_jizo=put('menu_jizo',PFX1+enc_text('CANTO DE JIZO'))
menu_cargar=put('menu_cargar',PFX2+enc_text('CARGAR'))
load_question=put('load_question',bytes([1])+enc_text('¿Cuál quieres cargar?'))
backup_error=put('backup_error',bytes([1])+enc_text('Los datos guardados\nno son válidos.\nSe borrará el archivo.'),0xFF)
# Patch text pointer tables in bank0F original area.
rom[0x1F4AE:0x1F4AE+10]=b''.join(ptr(p) for p in [diff_facil,diff_normal,diff_dificil,diff_muy,empty])
rom[0x1F4EB:0x1F4EB+4]=ptr(menu_jizo)+ptr(menu_cargar)
rom[0x1F501:0x1F501+12]=b''.join(ptr(p) for p in [load_question,diff_facil,diff_normal,diff_dificil,diff_muy,empty])
rom[0x1A58E]=backup_error&0xff; rom[0x1A592]=backup_error>>8
# Relocate C5B6's metasprite pointer table/list to bank0F safe space.
# Original table in bank17 CPU $4AB9: [4ADF,4AEE,4AC1,4AC1].
def list_from_bank17(cpu):
    off=0x2E000+(cpu-0x4000)
    end=off
    while orig[end]!=0xFF: end+=5
    return bytes(orig[off:end+1])
list_state0=list_from_bank17(0x4ADF)
list_state2=list_from_bank17(0x4AC1)
# New state1 list: widen selector initial (CANTO DE JIZO/CARGAR) horizontally.
list_state1=bytes.fromhex(
    '05 0E 00 00 10 '
    '06 0E 01 10 10 '
    '06 0E 01 30 10 '
    '08 0E 01 60 10 '
    '00 0E 01 00 00 '
    '02 0E 01 20 00 '
    '02 0E 01 40 00 '
    '04 0E 00 60 00 '
    'FF'
)
# Align list table at current alloc.
if alloc & 1: alloc+=1
meta_table_off=alloc; meta_table_cpu=cpu0f(meta_table_off); alloc+=8
state0_off=alloc; state0_cpu=cpu0f(state0_off); rom[state0_off:state0_off+len(list_state0)]=list_state0; alloc+=len(list_state0)
state1_off=alloc; state1_cpu=cpu0f(state1_off); rom[state1_off:state1_off+len(list_state1)]=list_state1; alloc+=len(list_state1)
state2_off=alloc; state2_cpu=cpu0f(state2_off); rom[state2_off:state2_off+len(list_state2)]=list_state2; alloc+=len(list_state2)
# verify areas were free before we wrote: allocations after text are also in orig/base FF.
for off,ln in [(meta_table_off,8),(state0_off,len(list_state0)),(state1_off,len(list_state1)),(state2_off,len(list_state2))]:
    assert orig[off:off+ln]==bytes([0xFF])*ln, (hex(off),ln)
    assert base[off:off+ln]==bytes([0xFF])*ln, (hex(off),ln)
rom[meta_table_off:meta_table_off+8]=ptr(state0_cpu)+ptr(state1_cpu)+ptr(state2_cpu)+ptr(state2_cpu)
# Patch C5B6 to read the pointer table from bank0F instead of bank17.
# C5B6 LDA #$17; C5CD/C5D2 load $4AB9/$4ABA,X.
rom[0x1A5B7]=0x0F
rom[0x1A5CE]=meta_table_cpu&0xff; rom[0x1A5CF]=meta_table_cpu>>8
rom[0x1A5D3]=(meta_table_cpu+1)&0xff; rom[0x1A5D4]=(meta_table_cpu+1)>>8
# Anti-regression: prompt/error v03 sensitive areas untouched.
assert rom[0x1FA00:0x1FB09]==base[0x1FA00:0x1FB09]
assert rom[0x43A8B]==base[0x43A8B]
assert rom[0x1AD11]==base[0x1AD11] and rom[0x1AE60]==base[0x1AE60]
# Output
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
alloc_lines='\n'.join(f'- `{name}`: ROM `0x{off:05X}`, CPU `${cpu:04X}`, len `{ln}`' for name,(off,cpu,ln,data) in allocs.items())
REPORT.write_text(f'''# v04 password/menu — tabla C5B6 relocalizada segura

ROM:
`Roms/Pruebas/{OUT.name}`

IPS:
`Parches/Pruebas/{IPS.name}`

## Base

Parte de `traduccion_v03` confirmada.

## Objetivo

Traducir textos de menú password/load y ensanchar sólo el selector inicial sin escribir en bank17 aparentemente libre.

La prueba anterior escribió una lista en `0x2FA59` y rompió el título. Esta prueba relocaliza la tabla/listas que usa `C5B6` a bank `$0F` seguro.

## Textos

{alloc_lines}

## Metasprite C5B6 relocalizado

- Tabla nueva: ROM `0x{meta_table_off:05X}`, CPU `${meta_table_cpu:04X}`.
- Estado 0 copiado de `$4ADF`: ROM `0x{state0_off:05X}`, CPU `${state0_cpu:04X}`, len `{len(list_state0)}`.
- Estado 1 ampliado: ROM `0x{state1_off:05X}`, CPU `${state1_cpu:04X}`, len `{len(list_state1)}`.
- Estado 2/3 copiado de `$4AC1`: ROM `0x{state2_off:05X}`, CPU `${state2_cpu:04X}`, len `{len(list_state2)}`.

## Código parcheado

- `C5B6`: bank `$17 -> $0F`.
- `C5CD/C5D2`: tabla `$4AB9/$4ABA` -> `${meta_table_cpu:04X}`.

## Qué comprobar

1. Título: no debe haber duplicados/artefactos de EMPEZAR/CONTINUAR.
2. Selector inicial: `CANTO DE JIZO` / `CARGAR` y si la caja se ensancha.
3. Pantalla de dificultad: sigue bien.
4. Pantalla de carga: texto aún puede estar cortado; no se ha ensanchado todavía.
5. Cargar partida funciona.
6. Prompt y error Jizo de v03 siguen bien.

## Cambios contra v03

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('alloc next',hex(alloc),'used',alloc-0x1FB10)
print('meta table',hex(meta_table_off),hex(meta_table_cpu))
print('lists',hex(state0_off),hex(state1_off),hex(state2_off))
print('changed',changed)
print('records',len(rec),'bytes',sum(len(b) for _,b in rec))
