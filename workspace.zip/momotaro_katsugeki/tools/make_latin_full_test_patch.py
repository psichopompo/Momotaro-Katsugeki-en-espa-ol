#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT/'work/Momotarou Katsugeki (Japan).pce'
OUT = ROOT/'work/Momotarou Katsugeki (Japan) - latin_full_test.pce'
IPS = ROOT/'work/momotaro_latin_full_test.ips'
PREVIEW = ROOT/'images/latin_full_preview.png'
TBL = ROOT/'work/charset_latin_full.tbl'

rom = bytearray(ORIG.read_bytes())
orig = ORIG.read_bytes()
FONT_BASE = 0x3D660
TABLES = (0x41CF3, 0x41CB3)

# Fuente 1bpp 8x8. '#' = tinta.
def glyph(rows):
    rows = list(rows)
    assert len(rows) == 8, rows
    out=[]
    for r in rows:
        r = r.ljust(8,'.')[:8]
        b=0
        for ch in r:
            b = (b << 1) | (1 if ch not in '. 0' else 0)
        out.append(b)
    return bytes(out)

# Minúsculas gruesas, intentando mantener grosor parecido a la fuente japonesa.
G = {}
def add(code, rows): G[code] = glyph(rows)

# A0 queda como espacio/blank por tabla; no hace falta glyph.
# A1-BA = a-z
add(0xA1,["........","........",".####...","....#...",".####...","#...#...",".####...","........"]) # a
add(0xA2,["#.......","#.......","#.###...","##..#...","#...#...","##..#...","#.###...","........"]) # b
add(0xA3,["........","........",".####...","#.......","#.......","#.......",".####...","........"]) # c
add(0xA4,["....#...","....#...",".###.#..","#...##..","#...#...","#...##..",".###.#..","........"]) # d
add(0xA5,["........","........",".###....","#...#...","#####...","#.......",".####...","........"]) # e
add(0xA6,["..###...",".#......",".###....",".#......",".#......",".#......",".#......","........"]) # f
add(0xA7,["........","........",".####...","#...#...","#...#...",".####...","....#...",".###...."]) # g
add(0xA8,["#.......","#.......","#.##....","##..#...","#...#...","#...#...","#...#...","........"]) # h
add(0xA9,["..#.....","........",".##.....","..#.....","..#.....","..#.....",".###....","........"]) # i
add(0xAA,["...#....","........","..##....","...#....","...#....","#..#....",".##.....","........"]) # j
add(0xAB,["#.......","#...#...","#..#....","###.....","#..#....","#...#...","#...#...","........"]) # k
add(0xAC,[".##.....","..#.....","..#.....","..#.....","..#.....","..#.....",".###....","........"]) # l
add(0xAD,["........","........","##.#....","#.#.#...","#.#.#...","#...#...","#...#...","........"]) # m
add(0xAE,["........","........","#.##....","##..#...","#...#...","#...#...","#...#...","........"]) # n
add(0xAF,["........","........",".###....","#...#...","#...#...","#...#...",".###....","........"]) # o
add(0xB0,["........","........","#.###...","##..#...","#...#...","##..#...","#.###...","#......."]) # p
add(0xB1,["........","........",".###.#..","#...##..","#...#...","#...##..",".###.#..","....#..."]) # q
add(0xB2,["........","........","#.##....","##..#...","#.......","#.......","#.......","........"]) # r
add(0xB3,["........","........",".####...","#.......",".###....","....#...","####....","........"]) # s
add(0xB4,[".#......",".###....",".#......",".#......",".#......",".#..#...","..##....","........"]) # t
add(0xB5,["........","........","#...#...","#...#...","#...#...","#..##...",".##.#...","........"]) # u
add(0xB6,["........","........","#...#...","#...#...","#...#...",".#.#....","..#.....","........"]) # v
add(0xB7,["........","........","#...#...","#...#...","#.#.#...","#.#.#...",".#.#....","........"]) # w
add(0xB8,["........","........","#...#...",".#.#....","..#.....",".#.#....","#...#...","........"]) # x
add(0xB9,["........","........","#...#...","#...#...","#...#...",".####...","....#...",".###...."]) # y
add(0xBA,["........","........","#####...","...#....","..#.....",".#......","#####...","........"]) # z

# Acentos minúsculas y eñe/diéresis.
add(0xBB,["..##....",".#......",".####...","....#...",".####...","#...#...",".####...","........"]) # á
add(0xBC,["..##....",".#......",".###....","#...#...","#####...","#.......",".####...","........"]) # é
add(0xBD,["..##....",".#......",".##.....","..#.....","..#.....","..#.....",".###....","........"]) # í
add(0xBE,["..##....",".#......",".###....","#...#...","#...#...","#...#...",".###....","........"]) # ó
add(0xBF,["..##....",".#......","#...#...","#...#...","#...#...","#..##...",".##.#...","........"]) # ú
add(0xC0,["#...#...","........","#...#...","#...#...","#...#...","#..##...",".##.#...","........"]) # ü
add(0xC1,[".##.#...","#..#....","#.##....","##..#...","#...#...","#...#...","#...#...","........"]) # ñ

# Acentos mayúsculas y Ñ/Ü. Diseñadas con tilde/acento visible, sacrificando 1 fila.
add(0xC2,["..##....",".#......",".###....","#...#...","#####...","#...#...","#...#...","........"]) # Á
add(0xC3,["..##....",".#......","#####...","#.......","####....","#.......","#####...","........"]) # É
add(0xC4,["..##....",".#......",".###....","..#.....","..#.....","..#.....",".###....","........"]) # Í
add(0xC5,["..##....",".#......",".###....","#...#...","#...#...","#...#...",".###....","........"]) # Ó
add(0xC6,["..##....",".#......","#...#...","#...#...","#...#...","#...#...",".###....","........"]) # Ú
add(0xC7,["#...#...","........","#...#...","#...#...","#...#...","#...#...",".###....","........"]) # Ü
add(0xC8,[".##.#...","#..#....","#...#...","##..#...","#.#.#...","#..##...","#...#...","........"]) # Ñ
add(0xC9,["..#.....","........","..#.....",".#......","#.......","#...#...",".###....","........"]) # ¿
add(0xCA,["..#.....","........","..#.....","..#.....","..#.....","..#.....","..#.....","........"]) # ¡

# Puntuación y símbolo de moneda/coin.
add(0xCB,["........","........","........","........","........","........",".##.....",".##....."]) # .
add(0xCC,["........","........","........","........","........",".##.....",".##.....",".#......"]) # ,
add(0xCD,["........",".##.....",".##.....","........","........",".##.....",".##.....","........"]) # :
add(0xCE,["........",".##.....",".##.....","........",".##.....",".##.....",".#......","........"]) # ;
add(0xCF,["........","........",".##.....",".##.....","........",".##.....",".##.....","........"]) # … aproximado / dos puntos susp.
add(0xD0,["..##....","..##....","..#.....","........","........","........","........","........"]) # '
add(0xD1,[".#.#....",".#.#....","#.#.....","........","........","........","........","........"]) # "
add(0xD2,["........","........","........",".####...","........","........","........","........"]) # -
add(0xD3,["....#...","...#....","...#....","..#.....",".#......",".#......","#.......","........"]) # /
add(0xD4,["...#....","..#.....",".#......",".#......",".#......","..#.....","...#....","........"]) # (
add(0xD5,[".#......","..#.....","...#....","...#....","...#....","..#.....",".#......","........"]) # )
add(0xD6,["##..#...","##.#....","..#.....",".#......","#..##...","...##...","........","........"]) # %
add(0xD7,[".##.....","#..#....","#.#.....",".#......","#.#.#...","#..#....",".##.#...","........"]) # &
add(0xD8,["........","..#.....","..#.....","#####...","..#.....","..#.....","........","........"]) # +
add(0xD9,[".###....","#...#...","#.###...","#.#.#...","#.###...","#...#...",".###....","........"]) # símbolo moneda/icono
add(0xDA,["........",".####...","#.......","#.......","#.......","#.......",".####...","..#....."]) # ç
add(0xDB,[".####...","#.......","#.......","#.......","#.......",".####...","..#.....","........"]) # Ç
add(0xDC,[".##.....","#..#....","#..#....",".##.....","........","........","........","........"]) # º
add(0xDD,[".###....","...#....",".###....","#..#....",".####...","........","........","........"]) # ª
add(0xDE,["........","........","........","........","........","........","........","........"]) # libre
add(0xDF,["........","........","........","........","........","........","........","........"]) # libre

# Aplicar glyphs.
for gid,data in G.items():
    rom[FONT_BASE+gid*8:FONT_BASE+gid*8+8] = data

# Mapas de kana -> latin directos en ambas tablas, para que el antiguo toggle \ no cambie los latinos.
for table in TABLES:
    rom[table + 0x00] = 0x00  # A0 = espacio/blank
    for code in range(0xA1,0xE0):
        rom[table + (code-0xA0)] = code

# Tabla de inserción preliminar.
entries = {
    0x20:' ', 0x21:'!', 0x24:'$', 0x30:'0',0x31:'1',0x32:'2',0x33:'3',0x34:'4',0x35:'5',0x36:'6',0x37:'7',0x38:'8',0x39:'9',0x3F:'?',
    **{0x41+i:chr(ord('A')+i) for i in range(26)},
    0xA0:' ',
    **{0xA1+i:chr(ord('a')+i) for i in range(26)},
    0xBB:'á',0xBC:'é',0xBD:'í',0xBE:'ó',0xBF:'ú',0xC0:'ü',0xC1:'ñ',
    0xC2:'Á',0xC3:'É',0xC4:'Í',0xC5:'Ó',0xC6:'Ú',0xC7:'Ü',0xC8:'Ñ',
    0xC9:'¿',0xCA:'¡',0xCB:'.',0xCC:',',0xCD:':',0xCE:';',0xCF:'…',0xD0:"'",0xD1:'"',0xD2:'-',0xD3:'/',0xD4:'(',0xD5:')',0xD6:'%',0xD7:'&',0xD8:'+',0xD9:'¤',0xDA:'ç',0xDB:'Ç',0xDC:'º',0xDD:'ª'
}
with TBL.open('w', encoding='utf-8') as f:
    f.write('# Momotarou Katsugeki — tabla latina completa preliminar\n')
    f.write('# ¤ = símbolo/icono de moneda provisional para HUD/tiendas.\n')
    f.write('00=<NL>\nFC=<PAGE>\nFD=<WAIT>\nFE=<MODE>\nFF=<END>\n')
    for k in sorted(entries):
        f.write(f'{k:02X}={entries[k]}\n')

# Encoder simple para muestra. Preferimos ASCII para mayúsculas/dígitos, tabla alta para minúsculas/español/puntuación especial.
char_to_code = {v:k for k,v in entries.items() if v not in (' ',)}
char_to_code[' '] = 0x20
# Fuerza minúsculas a tabla alta; mayúsculas a ASCII original.
for i in range(26): char_to_code[chr(ord('a')+i)] = 0xA1+i
for i in range(26): char_to_code[chr(ord('A')+i)] = 0x41+i
for i in range(10): char_to_code[str(i)] = 0x30+i

def enc(s):
    out=[]
    for ch in s:
        if ch=='\n': out.append(0x00)
        else: out.append(char_to_code[ch])
    return bytes(out)

# Prueba en casa inicial, sin repunteo.
start=0x1F078; end=0x1F09E
payload = enc('¿Acción?\n Pingüino Ñ\n 200¤ ¡olé!')
assert len(payload) <= end-start, (len(payload), end-start)
rom[start:end] = payload + bytes([0x20])*(end-start-len(payload))
assert rom[end] == 0xFC

OUT.write_bytes(rom)

# IPS
records=[]; i=0; new=bytes(rom)
while i < len(orig):
    if orig[i] == new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xFFFF:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big') + len(buf).to_bytes(2,'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# Preview con el mismo font/mapeo aproximado.
def source_to_gid(c):
    if c == 0x20 or c == 0xA0: return 0x00
    if 0xA1 <= c <= 0xDF: return c
    # ASCII map original para mayúsculas/dígitos/puntuación básica.
    if 0x30 <= c <= 0x65:
        return new[0x42B5B + (c-0x30)]
    if c == 0x21: return 0x9C
    if c == 0x3F: return 0x9D
    return 0x00

lines=[]; cur=[]
for b in payload:
    if b==0:
        lines.append(cur); cur=[]
    else:
        cur.append(b)
if cur: lines.append(cur)
scale=4; cols=max(len(l) for l in lines)
w=cols*8*scale+8; h=len(lines)*10*scale+8
img=Image.new('RGB',(w,h),(0,0,0))
for row,line in enumerate(lines):
    for col,c in enumerate(line):
        gid=source_to_gid(c)
        data=new[FONT_BASE+gid*8:FONT_BASE+gid*8+8]
        for y,b in enumerate(data):
            for x in range(8):
                if (b>>(7-x))&1:
                    for yy in range(scale):
                        for xx in range(scale):
                            img.putpixel((4+col*8*scale+x*scale+xx, 4+row*10*scale+y*scale+yy),(255,255,255))
canvas=Image.new('RGB',(w,max(h+18,70)),(240,240,240))
canvas.paste(img,(0,18))
ImageDraw.Draw(canvas).text((2,2),'Prueba: ¿Acción? / Pingüino Ñ / 200¤ ¡olé!',fill=(0,0,0))
canvas.save(PREVIEW)

print('ROM:', OUT)
print('IPS:', IPS)
print('TBL:', TBL)
print('Preview:', PREVIEW)
print('records',len(records),'bytes',sum(len(b) for _,b in records))
for off,buf in records:
    print(f'{off:06X} len {len(buf)}')
