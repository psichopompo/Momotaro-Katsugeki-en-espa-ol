from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import argparse, math
ap=argparse.ArgumentParser(); ap.add_argument('rom'); ap.add_argument('out'); ap.add_argument('--offset',type=lambda x:int(x,0),default=0x3D660); ap.add_argument('--count',type=lambda x:int(x,0),default=0xC0); ap.add_argument('--scale',type=int,default=4); args=ap.parse_args()
D=Path(args.rom).read_bytes(); scale=args.scale; cell=8*scale; label=12; cols=16; rows=math.ceil(args.count/cols)
out=Image.new('RGB',(cols*cell, rows*(cell+label)),(240,240,240)); d=ImageDraw.Draw(out)
for i in range(args.count):
 off=args.offset+i*8; bs=D[off:off+8]
 im=Image.new('RGB',(8,8),(255,255,255)); p=im.load()
 for y,b in enumerate(bs):
  for x in range(8):
   if (b>>(7-x))&1: p[x,y]=(0,0,0)
 im=im.resize((cell,cell),Image.Resampling.NEAREST)
 x=(i%cols)*cell; y=(i//cols)*(cell+label)
 out.paste(im,(x,y+label)); d.text((x+1,y),f'{i:02X}',fill=(255,0,0))
Path(args.out).parent.mkdir(parents=True,exist_ok=True); out.save(args.out)
