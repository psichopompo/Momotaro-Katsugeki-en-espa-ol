#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_options_spanish_test_v3.pce'
IPS=ROOT/'Parches/momotaro_start_options_spanish_test_v3.ips'
PREVIEW=ROOT/'images/start_options_spanish_v3_preview.png'
REPORT=ROOT/'reports/test_empezar_continuar_metasprite_v3.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())

FONT={
 'A':["01110","10001","10001","11111","10001","10001","10001"],
 'B':["11110","10001","10001","11110","10001","10001","11110"],
 'C':["01111","10000","10000","10000","10000","10000","01111"],
 'D':["11110","10001","10001","10001","10001","10001","11110"],
 'E':["11111","10000","10000","11110","10000","10000","11111"],
 'F':["11111","10000","10000","11110","10000","10000","10000"],
 'G':["01111","10000","10000","10011","10001","10001","01111"],
 'H':["10001","10001","10001","11111","10001","10001","10001"],
 'I':["11111","00100","00100","00100","00100","00100","11111"],
 'J':["00111","00010","00010","00010","00010","10010","01100"],
 'L':["10000","10000","10000","10000","10000","10000","11111"],
 'M':["10001","11011","10101","10101","10001","10001","10001"],
 'N':["10001","11001","10101","10011","10001","10001","10001"],
 'O':["01110","10001","10001","10001","10001","10001","01110"],
 'P':["11110","10001","10001","11110","10000","10000","10000"],
 'R':["11110","10001","10001","11110","10100","10010","10001"],
 'S':["01111","10000","10000","01110","00001","00001","11110"],
 'T':["11111","00100","00100","00100","00100","00100","00100"],
 'U':["10001","10001","10001","10001","10001","10001","01110"],
 'V':["10001","10001","10001","10001","01010","01010","00100"],
 'Z':["11111","00001","00010","00100","01000","10000","11111"],
 ' ': ["00000"]*7,
}

def draw_word(img, word, x, y, fill=1, shadow=2):
    pix=img.load(); cx=x
    for ch in word:
        pat=FONT[ch]
        if shadow:
            for yy,row in enumerate(pat):
                for xx,b in enumerate(row):
                    if b=='1':
                        sx=cx+xx+1; sy=y+yy+1
                        if 0<=sx<img.width and 0<=sy<img.height and pix[sx,sy]==0:
                            pix[sx,sy]=shadow
        for yy,row in enumerate(pat):
            for xx,b in enumerate(row):
                if b=='1':
                    px=cx+xx; py=y+yy
                    if 0<=px<img.width and 0<=py<img.height:
                        pix[px,py]=fill
        cx += 6

def encode_sprite_pattern_16(img, x0):
    # PCE sprite 16x16 4bpp format: 4 planes, each plane = 16 rows * 2 bytes.
    out=[]
    for plane in range(4):
        for y in range(16):
            b0=b1=0
            for x in range(8):
                c=img.getpixel((x0+x,y))
                b0=(b0<<1)|((c>>plane)&1)
            for x in range(8,16):
                c=img.getpixel((x0+x,y))
                b1=(b1<<1)|((c>>plane)&1)
            out.extend([b0,b1])
    return bytes(out)

def compress_sprite(raw128):
    # Inverse of F1B9/861F decompressor.
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw128[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v!=0:
                        mask |= 1<<bit; payload.append(v)
                else:
                    if v!=prev:
                        mask |= 1<<bit; payload.append(v)
                prev=v
            out.append(mask); out += bytes(payload)
    return bytes(out)

# 4 sprite objects * 32 px = 128x16. This time with shadow, stored in free space.
canvas=Image.new('P',(128,16),0)
draw_word(canvas,'EMPEZAR',11,4,fill=1,shadow=2)
draw_word(canvas,'CONTINUAR',69,4,fill=1,shadow=2)
patterns=[encode_sprite_pattern_16(canvas,x) for x in range(0,128,16)]
stream=bytearray([len(patterns)]); lens=[]
for pat in patterns:
    c=compress_sprite(pat); lens.append(len(c)); stream += c

# Place stream in free run in bank $17: ROM 0x2F8B5 == CPU $78B5 when bank $17 is in MPR3.
stream_off=0x2F8B5
stream_cpu=0x78B5
free_end=0x30000
if stream_off+len(stream)>free_end:
    raise SystemExit('stream too large for free bank17 area')
rom[stream_off:stream_off+len(stream)]=stream

# Patch loader at CPU $CEE7 to map banks $16/$17 and read source $78B5 instead of $72DE.
# ROM offsets: CPU $CEEA => ROM $18EEA, operand at +1. Source low/high at $CEFE/$CF02 operands.
rom[0x18EEB]=0x16  # LDA #$16, TAM #2; INC A -> bank $17 in MPR3
rom[0x18EFF]=stream_cpu & 0xFF
rom[0x18F03]=stream_cpu >> 8

# New metasprite lists after stream, aligned.
list1_off=(stream_off+len(stream)+0x0F)&~0x0F
list2_off=list1_off+4*5+1
list1_cpu=0x4000+(list1_off-0x2E000) # bank17 in MPR2 for list pointers
list2_cpu=0x4000+(list2_off-0x2E000)
def rec(tile, attr, attr2, dx, dy): return bytes([tile,attr,attr2,dx&0xFF,dy&0xFF])
# Four 32x16 hardware sprite entries, each uses two 16x16 patterns.
list1=b''.join([
    rec(0x00,0x07,0x01,-64,-16), rec(0x02,0x07,0x00,-32,-16),
    rec(0x04,0x06,0x01,  0,-16), rec(0x06,0x06,0x00, 32,-16),
])+b'\xFF'
list2=b''.join([
    rec(0x00,0x06,0x01,-64,-16), rec(0x02,0x06,0x00,-32,-16),
    rec(0x04,0x07,0x01,  0,-16), rec(0x06,0x07,0x00, 32,-16),
])+b'\xFF'
rom[list1_off:list1_off+len(list1)]=list1
rom[list2_off:list2_off+len(list2)]=list2
# Pointer table at ROM 0x2E6B1.
rom[0x2E6B1:0x2E6B5]=bytes([list1_cpu&0xFF,list1_cpu>>8,list2_cpu&0xFF,list2_cpu>>8])

OUT.write_bytes(rom)
# IPS vs original.
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xFFFF:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)

# Preview.
pal=[(0,0,80),(255,109,33),(33,36,33)]
scale=4
prev=Image.new('RGB',(128*scale,16*scale),(0,0,80))
for y in range(16):
    for x in range(128):
        c=canvas.getpixel((x,y))
        if c:
            for yy in range(scale):
                for xx in range(scale): prev.putpixel((x*scale+xx,y*scale+yy),pal[c])
PREVIEW.parent.mkdir(parents=True,exist_ok=True); prev.save(PREVIEW)

REPORT.write_text(f'''# Test v3 `EMPEZAR / CONTINUAR` como metasprites\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Cambio respecto a v2\n\nLa v2 corrigió el formato de sprite 16x16 y ya produjo rótulos reconocibles, pero sin sombra y con aspecto pobre.\n\nLa v3 relocaliza el stream gráfico al hueco libre del banco `$17` para que quepa con sombra.\n\n## Parches de carga\n\nLa rutina original cargaba el stream desde banco `$13`, CPU `$72DE`.\n\nAhora:\n\n- MPR2/MPR3 se cambian a `$16/$17`.\n- Fuente del stream: CPU `$78B5`, banco `$17`, ROM `0x{stream_off:05X}`.\n\n## Datos\n\n- Stream nuevo: `{len(stream)}` bytes.\n- Longitudes por patrón: `{lens}`.\n- Lista 1: CPU `${list1_cpu:04X}`, ROM `0x{list1_off:05X}`.\n- Lista 2: CPU `${list2_cpu:04X}`, ROM `0x{list2_off:05X}`.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')

print('stream len',len(stream),'lens',lens,'stream_off',hex(stream_off))
print('list1',hex(list1_off),hex(list1_cpu),list1.hex(' '))
print('list2',hex(list2_off),hex(list2_cpu),list2.hex(' '))
print('records',len(records),sum(len(b) for _,b in records))
print('OUT',OUT)
