#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - traduccion_v01.pce'
OUT = ROOT / 'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v02_opciones_test.pce'
IPS = ROOT / 'Parches/Pruebas/momotaro_traduccion_v02_opciones_test.ips'
REPORT = ROOT / 'reports/test_password_options_v02.md'
PREVIEW = ROOT / 'images/password_options_v02_preview.png'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())

FONT_BASE = 0x3D660
ASCII_MAP = 0x42B5B

# ---------------------------------------------------------------------------
# Helpers.
# ---------------------------------------------------------------------------
def glyph(rows):
    out = []
    for r in rows:
        r = r.ljust(8, '.')[:8]
        b = 0
        for ch in r:
            b = (b << 1) | (1 if ch not in '. 0' else 0)
        out.append(b)
    return bytes(out)

def rle_encode(vals):
    out = bytearray()
    i = 0
    while i < len(vals):
        v = vals[i]
        j = i + 1
        while j < len(vals) and vals[j] == v and j - i < 256:
            j += 1
        L = j - i
        if L >= 3 or v == 0xFF:
            out += bytes([0xFF, L - 1, v])
        else:
            out += bytes([v]) * L
        i = j
    return bytes(out)

# 3x5 font for compact two-letter option chunks. Two glyphs fit in one 8x8 tile:
# first at x=0..2, second at x=4..6, rows y=2..6. Accents use row 0/1.
SMALL = {
    'A': ['010', '101', '111', '101', '101'],
    'B': ['110', '101', '110', '101', '110'],
    'C': ['011', '100', '100', '100', '011'],
    'D': ['110', '101', '101', '101', '110'],
    'E': ['111', '100', '110', '100', '111'],
    'F': ['111', '100', '110', '100', '100'],
    'I': ['111', '010', '010', '010', '111'],
    'L': ['100', '100', '100', '100', '111'],
    'N': ['101', '111', '111', '111', '101'],
    'O': ['111', '101', '101', '101', '111'],
    'P': ['110', '101', '110', '100', '100'],
    'R': ['110', '101', '110', '101', '101'],
    'S': ['011', '100', '010', '001', '110'],
    'T': ['111', '010', '010', '010', '010'],
    'Á': ['010', '101', '111', '101', '101'],
}
ACCENTS = {
    'Á': [(1, 0), (0, 1)],
}

def option_chunk_tile(chunk: str) -> bytes:
    canvas = [[0 for _ in range(8)] for __ in range(8)]
    letters = list(chunk)
    if len(letters) == 1:
        xs = [2]
    elif len(letters) == 2:
        xs = [0, 4]
    else:
        raise ValueError(chunk)
    for ch, x0 in zip(letters, xs):
        pat = SMALL[ch]
        for y, row in enumerate(pat):
            for x, bit in enumerate(row):
                if bit == '1':
                    canvas[2 + y][x0 + x] = 1
        for ax, ay in ACCENTS.get(ch, []):
            canvas[ay][x0 + ax] = 1
    return bytes(sum((canvas[y][x] << (7 - x)) for x in range(8)) for y in range(8))

# ---------------------------------------------------------------------------
# Existing Spanish/password encoding from v01.
# ---------------------------------------------------------------------------
enc = {' ': 0x20}
for i in range(10):
    enc[str(i)] = 0x30 + i
for i, ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    enc[ch] = 0x41 + i
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    enc[ch] = 0xA1 + i
enc['b'] = 0x5B
enc['c'] = 0x5D
enc['p'] = 0x5E
enc.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

# ---------------------------------------------------------------------------
# 1) Compact option glyphs.
# ---------------------------------------------------------------------------
# Five option labels encoded as compact chunks. Pattern IDs after runtime generation:
#   1..64  password symbols
#   65     dot placeholder
#   66     slash placeholder
#   67..82 option chunks
option_chunks = ['AD', 'EL', 'AN', 'TE', 'AT', 'RÁ', 'S', 'ES', 'PA', 'CI', 'O', 'BO', 'RR', 'AR', 'FI', 'N']
assert len(option_chunks) == 16
chunk_source_start = 0x66
chunk_gid_start = 0xE0
chunk_sources = [chunk_source_start + i for i in range(len(option_chunks))]
chunk_gids = [chunk_gid_start + i for i in range(len(option_chunks))]
for gid, chunk in zip(chunk_gids, option_chunks):
    rom[FONT_BASE + gid * 8:FONT_BASE + gid * 8 + 8] = option_chunk_tile(chunk)

# Extend AAB4's ASCII-map path so source bytes $66..$75 can map to glyph IDs
# $E0..$EF. To avoid overwriting code after the original AB5B table, relocate
# the whole ASCII map to the free FF area at bank21 CPU $BF9B.
# Original code in bank21_A000:
#   AB1D: SBC #$30
#   AB1F: CMP #$36
#   AB23: LDA $AB5B,X
ascii_ext_cpu = 0xBF9B
ascii_ext_off = 0x42000 + (ascii_ext_cpu - 0xA000)
ascii_len = (chunk_source_start + len(option_chunks)) - 0x30  # support $30..$75 inclusive
assert ascii_len == 0x46
assert orig[ascii_ext_off:ascii_ext_off + ascii_len] == bytes([0xFF]) * ascii_len
new_ascii = bytearray([0] * ascii_len)
# Start from current v01 map, preserving Latin letters, dot/slash, exceptions.
cur_ascii = rom[ASCII_MAP:ASCII_MAP + 0x36]
new_ascii[:len(cur_ascii)] = cur_ascii
for src, gid in zip(chunk_sources, chunk_gids):
    new_ascii[src - 0x30] = gid
rom[ascii_ext_off:ascii_ext_off + ascii_len] = new_ascii
rom[0x42B1F] = ascii_len          # CMP #$46
rom[0x42B24] = ascii_ext_cpu & 0xFF
rom[0x42B25] = ascii_ext_cpu >> 8

# ---------------------------------------------------------------------------
# 2) Runtime password alphabet table, extended with option chunk sources.
# ---------------------------------------------------------------------------
visual_rows = [
    ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'a', 'b', 'c', 'd', 'e', 'f', 'g'],
    ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'h', 'i', 'j', 'k', 'l', 'm', 'n'],
    ['Ñ', 'O', 'P', 'Q', 'R', 'S', 'T', 'ñ', 'o', 'p', 'q', 'r', 's', 't'],
    ['U', 'V', 'W', 'X', 'Y', 'Z', None, 'u', 'v', 'w', 'x', 'y', 'z', None],
    [None, None, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', None, None],
]
symbols = [ch for row in visual_rows for ch in row if ch is not None]
assert len(symbols) == 64
source = bytes([enc[ch] for ch in symbols])
new_off = 0x1BBB9
new_cpu = 0xDBB9
DOT_SOURCE = 0x60
SLASH_SOURCE = 0x61
DOT_PATTERN_ID = 0x41
SLASH_PATTERN_ID = 0x42
option_pattern_start = 0x43
table = bytes([0x01]) + source + bytes([DOT_SOURCE, SLASH_SOURCE]) + bytes(chunk_sources) + bytes([0xFF])
assert len(table) == 84
# Clear old free area up to new selection table for tidiness.
rom[0x1BBB9:0x1BD00] = bytes([0xFF]) * (0x1BD00 - 0x1BBB9)
rom[new_off:new_off + len(table)] = table
rom[0x1A85E] = new_cpu & 0xFF
rom[0x1A862] = new_cpu >> 8

# Buffer renderer patches from v01 retained/ensured.
rom[0x1AB98] = 0x41  # kana mark threshold -> after 64
rom[0x1AB87] = SLASH_PATTERN_ID
rom[0x1AB8C] = DOT_PATTERN_ID

# ---------------------------------------------------------------------------
# 3) Rebuild password tilemap: grid + buffer slashes + compact option labels.
# ---------------------------------------------------------------------------
tile_cols = [2, 4, 6, 8, 10, 12, 14, 17, 19, 21, 23, 25, 27, 29]
tile_rows = [7, 9, 11, 13, 17]

tm = [[0x100 for _ in range(32)] for __ in range(32)]
value = 1
values_grid = []
for rr, row in enumerate(visual_rows):
    row_values = []
    for cc, ch in enumerate(row):
        if ch is None:
            row_values.append(0)
            continue
        tm[tile_rows[rr]][tile_cols[cc]] = 0x100 + value
        row_values.append(value)
        value += 1
    values_grid.extend(row_values)
assert value == 65
assert len(values_grid) == 70

# Static slash separators in the input buffer, matching original tilemap positions.
STATIC_SLASH_CELLS = [(20, 13), (20, 18), (22, 13), (22, 18), (24, 13)]
for sr, sc in STATIC_SLASH_CELLS:
    tm[sr][sc] = 0x100 + SLASH_PATTERN_ID

# Option labels at right, compact 2-letter tiles.
option_words = [
    ('ADELANTE', ['AD', 'EL', 'AN', 'TE'], 0xF0),
    ('ATRÁS',    ['AT', 'RÁ', 'S'],       0xF1),
    ('ESPACIO',  ['ES', 'PA', 'CI', 'O'], 0xF2),
    ('BORRAR',   ['BO', 'RR', 'AR'],      0xF3),
    ('FIN',      ['FI', 'N'],             0xF4),
]
chunk_to_pattern = {chunk: option_pattern_start + i for i, chunk in enumerate(option_chunks)}
option_tile_rows = [15, 17, 19, 21, 23]
option_tile_col = 27  # x=216; leaves a small gap after the digit 9 and still fits ADELANTE
for (word, chunks, _val), rr in zip(option_words, option_tile_rows):
    for i, chunk in enumerate(chunks):
        tm[rr][option_tile_col + i] = 0x100 + chunk_to_pattern[chunk]

low = []
high = []
for r in range(32):
    for c in range(32):
        w = tm[r][c]
        low.append(w & 0xFF)
        high.append(((w >> 8) - 1) & 0xFF)
low_stream = rle_encode(low)
high_stream = rle_encode(high)
low_region_len = 0x1E290 - 0x1E18C
high_region_len = 0x1E29C - 0x1E290
assert len(low_stream) <= low_region_len, (len(low_stream), low_region_len)
assert len(high_stream) <= high_region_len, (len(high_stream), high_region_len)
rom[0x1E18C:0x1E290] = low_stream + bytes([0xFF]) * (low_region_len - len(low_stream))
rom[0x1E290:0x1E29C] = high_stream + bytes([0xFF]) * (high_region_len - len(high_stream))

# ---------------------------------------------------------------------------
# 4) Cursor/selection logic: grid rows 0..4 + option rows 5..9.
# ---------------------------------------------------------------------------
sel_base_off = 0x1BD00
sel_base_cpu = 0xDD00
row_offsets_cpu = sel_base_cpu
x_table_cpu = row_offsets_cpu + 10
y_table_cpu = x_table_cpu + 14
values_cpu = y_table_cpu + 10
row_offsets = [i * 14 for i in range(10)]
x_table = [(c * 8) - 8 for c in tile_cols]
y_table = [r * 8 for r in tile_rows + option_tile_rows]
assert len(x_table) == 14
assert len(y_table) == 10
values = list(values_grid)
for _word, _chunks, opt_val in option_words:
    row = [0] * 14
    row[11] = opt_val
    row[12] = opt_val
    values.extend(row)
assert len(values) == 140
sel_blob = bytes(row_offsets) + bytes(x_table) + bytes(y_table) + bytes(values)
assert len(sel_blob) == 174
assert orig[sel_base_off:sel_base_off + len(sel_blob)] == bytes([0xFF]) * len(sel_blob)
rom[sel_base_off:sel_base_off + len(sel_blob)] = sel_blob

# Patch absolute operand addresses:
#   C955: LDA row_offsets,Y
#   C961: LDX x_table,Y
#   C967: LDA y_table,Y
#   CC5D: LDA values,X
addr_patches = {
    0x1AC56: row_offsets_cpu,
    0x1A962: x_table_cpu,
    0x1A968: y_table_cpu,
    0x1AC5E: values_cpu,
}
for off, addr in addr_patches.items():
    rom[off] = addr & 0xFF
    rom[off + 1] = addr >> 8

# Navigation bounds: rows 0..9, columns 0..13.
rom[0x1AA56] = 0x09  # row wrap up
rom[0x1AA6A] = 0x0A  # row max exclusive
rom[0x1AA80] = 0x0E  # col max exclusive
rom[0x1AA95] = 0x0D  # col wrap left
# Horizontal directions corrected for ascending X table.
rom[0x1AA47] = 0x2E  # right -> increment
rom[0x1AA4B] = 0x40  # left -> decrement

# ---------------------------------------------------------------------------
# Output ROM + cumulative IPS against original clean ROM.
# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
IPS.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
PREVIEW.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(rom)
new = bytes(rom)
records = []
i = 0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s = i
    buf = bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i])
        i += 1
    records.append((s, bytes(buf)))
ips = bytearray(b'PATCH')
for off, buf in records:
    ips += off.to_bytes(3, 'big') + len(buf).to_bytes(2, 'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# ---------------------------------------------------------------------------
# Static preview, approximate only.
# ---------------------------------------------------------------------------
scale = 3
img = Image.new('RGB', (256 * scale, 240 * scale), (0, 0, 220))
d = ImageDraw.Draw(img)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 8 * scale)
    small_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 5 * scale)
except Exception:
    font = ImageFont.load_default()
    small_font = ImageFont.load_default()
for rr, row in enumerate(visual_rows):
    for cc, ch in enumerate(row):
        if ch is None:
            continue
        d.text((tile_cols[cc] * 8 * scale, tile_rows[rr] * 8 * scale), ch, fill=(255, 255, 255), font=font)
for (word, _chunks, _val), rr in zip(option_words, option_tile_rows):
    d.text((option_tile_col * 8 * scale, rr * 8 * scale), word, fill=(255, 255, 255), font=small_font)
# show selectable option cursor anchors
for rr in option_tile_rows:
    cx = x_table[12] * scale
    cy = rr * 8 * scale
    d.polygon([(cx, cy + 2 * scale), (cx, cy + 6 * scale), (cx + 5 * scale, cy + 4 * scale)], fill=(255, 60, 60))
img.save(PREVIEW)

layout_text = '\n'.join(' '.join(ch if ch is not None else '·' for ch in row) for row in visual_rows)
option_text = '\n'.join(f'{word}: {chunks} -> ${val:02X}' for word, chunks, val in option_words)
REPORT.write_text(f'''# Prueba v02 — columna de opciones del password

ROM de prueba:

`Roms/Pruebas/{OUT.name}`

IPS de prueba acumulativo contra ROM limpia:

`Parches/Pruebas/{IPS.name}`

Preview estático:

`images/{PREVIEW.name}`

## Criterio de organización

`traduccion_v01` queda como única versión confirmada en `Roms/` y `Parches/`. Esta v02 está en `Pruebas`; si se confirma, se promocionará a:

```text
Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce
Parches/momotaro_traduccion_v02.ips
```

## Objetivo

Añadir la columna de opciones del password:

```text
ADELANTE
ATRÁS
ESPACIO
BORRAR
FIN
```

Como no caben con letras 8x8 normales en la zona derecha, esta prueba usa tiles compactos de dos letras por tile, dibujados con una mini fuente 3x5.

## Layout de la parrilla preservado

```text
{layout_text}
```

## Opciones visuales/lógicas

```text
{option_text}
```

Valores de lógica original:

- `$F0` = ADELANTE.
- `$F1` = ATRÁS.
- `$F2` = ESPACIO / insertar espacio (`$FF`) desplazando caracteres.
- `$F3` = BORRAR.
- `$F4` = FIN.

## Cambios técnicos

- La tabla runtime de la pantalla se amplía: alfabeto `1..64`, punto `$41`, slash `$42`, opciones compactas `$43..$52`.
- La tabla de selección se relocaliza de `$DC00` a `$DD00` porque ahora hay 10 filas lógicas.
- Se restauran filas lógicas 5..9 para opciones con valores `$F0..$F4`.
- Se amplía de forma controlada la ruta ASCII de `AAB4` para que los source bytes `$66..$75` puedan mapearse a glyphs compactos `$E0..$EF`.
- Los slashes estáticos del buffer se mantienen.
- El parche `CB97: CMP #$41` se mantiene para evitar la ruta dakuten/handakuten con valores latinos.

## Validación estática

- Option chunks: `{len(option_chunks)}`.
- Tabla ASCII extendida: `{ascii_len}` bytes en ROM `0x{ascii_ext_off:05X}` / CPU `${ascii_ext_cpu:04X}`.
- Runtime table: `{len(table)}` bytes en `0x{new_off:05X}`, termina en `0x{new_off + len(table):05X}`.
- Selection table: `{len(sel_blob)}` bytes en `0x{sel_base_off:05X}` / CPU `${sel_base_cpu:04X}`.
- Low stream RLE: `{len(low_stream)}` / `{low_region_len}` bytes.
- High stream RLE: `{len(high_stream)}` / `{high_region_len}` bytes.
- Values table: `{len(values)}` bytes.

## Qué comprobar

1. Que las cinco opciones se ven a la derecha y son legibles.
2. Que el cursor puede llegar a ellas.
3. Que ADELANTE mueve el cursor del buffer a la derecha.
4. Que ATRÁS mueve el cursor del buffer a la izquierda.
5. Que ESPACIO inserta el espacio/separador como antes.
6. Que BORRAR borra.
7. Que FIN intenta validar el password.
8. Que la parrilla aceptada no se ha roto.
''', encoding='utf-8')

print('OUT', OUT)
print('IPS', IPS)
print('REPORT', REPORT)
print('PREVIEW', PREVIEW)
print('option chunks', option_chunks)
print('ascii ext', hex(ascii_ext_off), ascii_len)
print('runtime table len', len(table), 'ends', hex(new_off + len(table)))
print('selection', hex(sel_base_off), len(sel_blob))
print('low/high', len(low_stream), '/', low_region_len, len(high_stream), '/', high_region_len)
print('records', len(records), 'changed bytes', sum(len(b) for _, b in records))
