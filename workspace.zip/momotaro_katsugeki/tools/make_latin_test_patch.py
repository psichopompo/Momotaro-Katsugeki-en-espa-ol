#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT/'work/Momotarou Katsugeki (Japan).pce'
OUT = ROOT/'work/Momotarou Katsugeki (Japan) - latin_test.pce'
IPS = ROOT/'work/momotaro_latin_test.ips'
PREVIEW = ROOT/'images/latin_test_preview.png'

rom = bytearray(ORIG.read_bytes())

# 1bpp glyph helper: each row is 8 chars, # = ink.
def glyph(rows):
    assert len(rows) == 8
    out=[]
    for r in rows:
        r = r.ljust(8,'.')[:8]
        b=0
        for ch in r:
            b = (b << 1) | (1 if ch not in '. 0' else 0)
        out.append(b)
    return bytes(out)

glyphs = {
    0xB0: glyph([  # á
        '..#.....',
        '.#......',
        '........',
        '.###....',
        '....#...',
        '.####...',
        '#...#...',
        '.####...',
    ]),
    0xB1: glyph([  # é
        '..#.....',
        '.#......',
        '........',
        '.###....',
        '#...#...',
        '#####...',
        '#.......',
        '.####...',
    ]),
    0xB2: glyph([  # í
        '..#.....',
        '.#......',
        '........',
        '.##.....',
        '..#.....',
        '..#.....',
        '..#.....',
        '.###....',
    ]),
    0xB3: glyph([  # ó
        '..#.....',
        '.#......',
        '........',
        '.###....',
        '#...#...',
        '#...#...',
        '#...#...',
        '.###....',
    ]),
    0xB4: glyph([  # ú
        '..#.....',
        '.#......',
        '........',
        '#...#...',
        '#...#...',
        '#...#...',
        '#..##...',
        '.##.#...',
    ]),
    0xB5: glyph([  # ü
        '#...#...',
        '........',
        '........',
        '#...#...',
        '#...#...',
        '#...#...',
        '#..##...',
        '.##.#...',
    ]),
    0xB6: glyph([  # ñ
        '.##.#...',
        '#..#....',
        '........',
        '####....',
        '#...#...',
        '#...#...',
        '#...#...',
        '#...#...',
    ]),
    0xB7: glyph([  # Á
        '..#.....',
        '.#......',
        '.###....',
        '#...#...',
        '#####...',
        '#...#...',
        '#...#...',
        '........',
    ]),
    0xB8: glyph([  # É
        '..#.....',
        '.#......',
        '#####...',
        '#.......',
        '####....',
        '#.......',
        '#####...',
        '........',
    ]),
    0xB9: glyph([  # Í
        '..#.....',
        '.#......',
        '.###....',
        '..#.....',
        '..#.....',
        '..#.....',
        '.###....',
        '........',
    ]),
    0xBA: glyph([  # Ó
        '..#.....',
        '.#......',
        '.###....',
        '#...#...',
        '#...#...',
        '#...#...',
        '.###....',
        '........',
    ]),
    0xBB: glyph([  # Ú
        '..#.....',
        '.#......',
        '#...#...',
        '#...#...',
        '#...#...',
        '#...#...',
        '.###....',
        '........',
    ]),
    0xBC: glyph([  # Ü
        '#...#...',
        '........',
        '#...#...',
        '#...#...',
        '#...#...',
        '#...#...',
        '.###....',
        '........',
    ]),
    0xBD: glyph([  # Ñ
        '.##.#...',
        '#..#....',
        '#...#...',
        '##..#...',
        '#.#.#...',
        '#..##...',
        '#...#...',
        '........',
    ]),
    0xBE: glyph([  # ¿
        '..#.....',
        '........',
        '..#.....',
        '.#......',
        '#.......',
        '#...#...',
        '.###....',
        '........',
    ]),
    0xBF: glyph([  # ¡
        '..#.....',
        '........',
        '..#.....',
        '..#.....',
        '..#.....',
        '..#.....',
        '..#.....',
        '........',
    ]),
}

# Font base discovered by renderer: physical bank $1E mapped at CPU $4000, font starts at CPU $5600.
FONT_BASE = 0x3D660
for gid, data in glyphs.items():
    rom[FONT_BASE + gid*8: FONT_BASE + gid*8 + 8] = data

# Map source codes $B0-$BF directly to glyph IDs $B0-$BF in both kana maps.
# Table 0: physical $20:$1CF3 == ROM 0x41CF3. Table 1: physical $20:$1CB3 == ROM 0x41CB3.
for table in (0x41CF3, 0x41CB3):
    for code in range(0xB0, 0xC0):
        rom[table + (code - 0xA0)] = code

# Replace the first old-lady/grandpa message block used in the house.
# Keep the original $FC page delimiter at 0x1F09E and pad the rest with spaces.
# Source codes used here after remap:
# B0 á, B1 é, B2 í, B3 ó, B4 ú, B5 ü, B6 ñ,
# B7 Á, B8 É, B9 Í, BA Ó, BB Ú, BC Ü, BD Ñ, BE ¿, BF ¡
start = 0x1F078
end_before_fc = 0x1F09E
payload = bytes([
    0xBE, ord('C'), ord('A'), 0xBD, ord('A'), ord('?'), 0x00,
    0x20, 0xB7, 0xB8, 0xB9, 0xBA, 0xBB, 0x20, 0xBC, 0x20, 0xBD, 0x00,
    0x20, 0xB0, 0xB1, 0xB2, 0xB3, 0xB4, 0x20, 0xB5, 0x20, 0xB6, 0x20, 0xBF, ord('!'),
])
assert len(payload) <= end_before_fc-start
rom[start:end_before_fc] = payload + bytes([0x20])*(end_before_fc-start-len(payload))
assert rom[end_before_fc] == 0xFC

OUT.write_bytes(rom)

# Create simple IPS patch.
orig = ORIG.read_bytes()
new = bytes(rom)
records=[]
i=0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s=i
    buf=bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i]); i += 1
    records.append((s, bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big')
    ips += len(buf).to_bytes(2,'big')
    ips += buf
ips += b'EOF'
IPS.write_bytes(ips)

# Preview using patched font and same source -> glyph mapping for the test payload.
# Reconstruct glyph ID for test bytes: ASCII A-Z/digits through known engine table, B0-BF direct.
ascii_map = list(new[0x42B5B:0x42B5B+0x36])
def source_to_gid(c):
    if 0xB0 <= c <= 0xBF:
        return c
    if 0x30 <= c < 0x30+len(ascii_map):
        return ascii_map[c-0x30]
    if c == 0x20:
        return 0x00
    return 0x00
lines=[]; cur=[]
for c in payload:
    if c==0:
        lines.append(cur); cur=[]
    else:
        cur.append(c)
if cur: lines.append(cur)
scale=4
w=18*8*scale; h=len(lines)*10*scale+8
img=Image.new('RGB',(w,h),(0,0,0))
for row,line in enumerate(lines):
    for col,c in enumerate(line):
        gid=source_to_gid(c)
        data=new[FONT_BASE+gid*8:FONT_BASE+gid*8+8]
        for y,b in enumerate(data):
            for x in range(8):
                if (b>>(7-x))&1:
                    for yy in range(scale):
                        for xx in range(scale):
                            img.putpixel((col*8*scale+x*scale+xx+4, row*10*scale+y*scale+yy+4),(255,255,255))
# Add label strip.
canvas=Image.new('RGB',(w,h+18),(240,240,240))
canvas.paste(img,(0,18))
ImageDraw.Draw(canvas).text((2,2),'Vista previa fuente/test: ¿CAÑA? / ÁÉÍÓÚ Ü Ñ / áéíóú ü ñ ¡!',fill=(0,0,0))
canvas.save(PREVIEW)

print('Patched ROM:', OUT)
print('IPS patch:', IPS)
print('Preview:', PREVIEW)
print('Changed records:', len(records), 'bytes changed:', sum(len(b) for _,b in records))
for off,buf in records:
    print(f'  {off:06X} len {len(buf)}')
