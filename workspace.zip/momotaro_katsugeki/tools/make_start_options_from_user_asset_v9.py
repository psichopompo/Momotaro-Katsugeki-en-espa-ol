#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_final.pce'
ASSET=ROOT/'title_assets/start_options_es.png'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_options_spanish_asset_test_v9.pce'
IPS=ROOT/'Parches/momotaro_start_options_spanish_asset_test_v9.ips'
PREVIEW=ROOT/'images/start_options_spanish_asset_v9_preview.png'
REPORT=ROOT/'reports/test_empezar_continuar_asset_usuario_v9.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
# Canvas 128x16 from user's 125x19 option graphic. Crop vertical to fit sprite height.
src=Image.open(ASSET).convert('RGBA')
crop=src.crop((0,2,125,18))
canvas=Image.new('P',(128,16),0)
for y in range(crop.height):
    for x in range(crop.width):
        r,g,b,a=crop.getpixel((x,y))
        if not a: continue
        xx=x+1; yy=y
        if 0<=xx<128 and 0<=yy<16:
            # index 2 for black shadow/outline, index 1 for color. Real pal selected/unselected via attr.
            canvas.putpixel((xx,yy), 2 if (r<40 and g<40 and b<40) else 1)

def encode_sprite_pattern_16(img,x0):
    # PCE sprite pattern in the game's expected byte order.
    # Each row is two bytes little-endian: byte0 is right half, byte1 is left half.
    out=[]
    for plane in range(4):
        for y in range(16):
            b0=b1=0
            for x in range(8,16):
                c=img.getpixel((x0+x,y)); b0=(b0<<1)|((c>>plane)&1)
            for x in range(0,8):
                c=img.getpixel((x0+x,y)); b1=(b1<<1)|((c>>plane)&1)
            out.extend([b0,b1])
    return bytes(out)

def compress_sprite(raw128):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw128[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v:
                        mask|=1<<bit; payload.append(v)
                elif v!=prev:
                    mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out+=bytes(payload)
    return bytes(out)
patterns=[encode_sprite_pattern_16(canvas,x) for x in range(0,128,16)]
stream=bytearray([len(patterns)]); lens=[]
for p in patterns:
    c=compress_sprite(p); lens.append(len(c)); stream+=c
# Use bank17 free space and patch loader to bank16/17, as relocation control was validated.
stream_off=0x2F8B5; stream_cpu=0x78B5
if stream_off+len(stream)>0x30000: raise SystemExit('stream too large')
rom[stream_off:stream_off+len(stream)]=stream
# Patch CEE7 loader operands: MPR2/3=$16/$17, source CPU $78B5.
rom[0x18EEB]=0x16
rom[0x18EFF]=stream_cpu&0xFF
rom[0x18F03]=stream_cpu>>8
# Lists after stream. 4 sprites of 32px; tile bytes 00,02,04,06 (each wide sprite uses no+1).
list1_off=(stream_off+len(stream)+0x0F)&~0x0F
list2_off=list1_off+4*5+1
list1_cpu=0x4000+(list1_off-0x2E000); list2_cpu=0x4000+(list2_off-0x2E000)
def rec(tile,attr,attr2,dx,dy): return bytes([tile,attr,attr2,dx&0xff,dy&0xff])
# Place across original visual area. x visible = 64,96,128,160 approximates 128px width centred.
# base visible from metasprite function is X=$80 plus dx.
list1=b''.join([rec(0x00,0x07,0x01,-64,-16),rec(0x02,0x07,0x01,-32,-16),rec(0x04,0x06,0x01,0,-16),rec(0x06,0x06,0x01,32,-16)])+b'\xff'
list2=b''.join([rec(0x00,0x06,0x01,-64,-16),rec(0x02,0x06,0x01,-32,-16),rec(0x04,0x07,0x01,0,-16),rec(0x06,0x07,0x01,32,-16)])+b'\xff'
rom[list1_off:list1_off+len(list1)]=list1
rom[list2_off:list2_off+len(list2)]=list2
rom[0x2E6B1:0x2E6B5]=bytes([list1_cpu&0xFF,list1_cpu>>8,list2_cpu&0xFF,list2_cpu>>8])
OUT.write_bytes(rom)
# IPS vs original.
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
# Preview.
pal=[(0,0,80),(255,109,33),(33,36,33)]; scale=4
prev=Image.new('RGB',(128*scale,16*scale),pal[0])
for y in range(16):
    for x in range(128):
        c=canvas.getpixel((x,y))
        if c:
            for yy in range(scale):
                for xx in range(scale): prev.putpixel((x*scale+xx,y*scale+yy),pal[c])
PREVIEW.parent.mkdir(exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Test v9 `EMPEZAR / CONTINUAR` usando asset del usuario\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Cambio v9\n\nUsa el asset del usuario, pero corrige el orden de bytes de cada fila de patrón sprite igual que en el rótulo principal:\n\n```text\nbyte0 = mitad derecha\nbyte1 = mitad izquierda\n```\n\nLas versiones anteriores de estos botones se generaron con el orden contrario, provocando letras fusionadas/invertidas.\n\n## Datos\n\n- Stream relocalizado: ROM `0x{stream_off:05X}`, CPU `$78B5`.\n- Stream nuevo: `{len(stream)}` bytes.\n- Longitudes por patrón: `{lens}`.\n- Lista 1: CPU `${list1_cpu:04X}`, ROM `0x{list1_off:05X}`.\n- Lista 2: CPU `${list2_cpu:04X}`, ROM `0x{list2_off:05X}`.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream',len(stream),'lens',lens)
print('list1',hex(list1_cpu),list1.hex(' '))
print('records',len(records),sum(len(b) for _,b in records))
