#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists(): BASE=ORIG
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - password_font_id_probe.pce'
IPS=ROOT/'Parches/momotaro_password_font_id_probe.ips'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
FONT_BASE=0x3D660
# 3x5 hexadecimal mini-font, two digits per 8x8 tile (x=0..2 and x=4..6, y=1..5)
HEX={
 '0':["111","101","101","101","111"],
 '1':["010","110","010","010","111"],
 '2':["111","001","111","100","111"],
 '3':["111","001","111","001","111"],
 '4':["101","101","111","001","001"],
 '5':["111","100","111","001","111"],
 '6':["111","100","111","101","111"],
 '7':["111","001","010","010","010"],
 '8':["111","101","111","101","111"],
 '9':["111","101","111","001","111"],
 'A':["111","101","111","101","101"],
 'B':["110","101","110","101","110"],
 'C':["111","100","100","100","111"],
 'D':["110","101","101","101","110"],
 'E':["111","100","110","100","111"],
 'F':["111","100","110","100","100"],
}
def glyph_hex(n):
    s=f'{n:02X}'[-2:]
    grid=[[0]*8 for _ in range(8)]
    for digit,ox in [(s[0],0),(s[1],4)]:
        pat=HEX[digit]
        for y,row in enumerate(pat, start=1):
            for x,ch in enumerate(row):
                if ch=='1': grid[y][ox+x]=1
    out=[]
    for row in grid:
        b=0
        for bit in row:
            b=(b<<1)|bit
        out.append(b)
    return bytes(out)
# Patch a wide range of glyphs so every visible kana cell reveals its glyph ID.
for gid in range(0x01,0xA0):
    rom[FONT_BASE+gid*8:FONT_BASE+gid*8+8]=glyph_hex(gid)
OUT.write_bytes(rom)
# IPS vs original clean ROM.
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
(ROOT/'reports/test_password_font_id_probe.md').write_text(f'''# Password font ID probe\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\n## Objetivo\n\nIdentificar exactamente qué glyph ID usa cada casilla de la parrilla de password.\n\nLa prueba sustituye los glyphs `0x01-0x9F` de la fuente 1bpp por su número hexadecimal de dos dígitos dentro del propio tile.\n\nEjemplos:\n\n- glyph `0x01` se verá como `01`\n- glyph `0x2A` se verá como `2A`\n- glyph `0x6D` se verá como `6D`\n\n## Qué necesitamos de la captura\n\nUna captura de la pantalla de password. Con ella podremos leer la parrilla como una tabla de IDs y reconstruir el orden visual/lógico de las 64 casillas.\n\nEsto también resolverá si los caracteres con dakuten/handakuten son glyphs compuestos o secuencias base+marca.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in rec)}\n''',encoding='utf-8')
print('OUT',OUT)
print('records',len(rec),sum(len(b) for _,b in rec))
