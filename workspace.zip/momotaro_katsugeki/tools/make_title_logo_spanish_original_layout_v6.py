#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Anteriores/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
ASSET=ROOT/'title_assets/title_logo_es_fullscreen.png'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v6.pce'
IPS=ROOT/'Parches/momotaro_title_logo_spanish_original_layout_test_v6.ips'
PREVIEW=ROOT/'images/title_logo_spanish_original_layout_v6_preview.png'
REPORT=ROOT/'reports/test_rotulo_titulo_original_layout_v6.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
asset=Image.open(ASSET).convert('RGBA')
# main palette 4 indices deduced from original
main_map={(0,0,0):4,(0,36,182):2,(0,146,219):3,(219,182,0):5,(146,73,36):1}
# peach palette 5 indices deduced from original separate peach sprite
peach_map={(0,0,0):4,(255,146,109):1,(73,109,36):2,(219,182,219):3,(219,36,109):5,(255,73,146):6,(255,109,255):7}
# add fallback minor colors
all_map={**main_map,**peach_map}
def nearest_idx(rgb,mp):
    if rgb in mp: return mp[rgb]
    best=min(mp, key=lambda c: sum((rgb[i]-c[i])**2 for i in range(3)))
    return mp[best]
# original list
list_off=0x2E2B0
entries=[]; i=list_off
while orig[i]!=0xFF:
    tile,a1,a2,dx,dy=orig[i:i+5]
    dx=dx-256 if dx>=128 else dx; dy=dy-256 if dy>=128 else dy
    entries.append((tile,a1,a2,dx,dy))
    i+=5
BASE_X=128; BASE_Y=88
SPECIAL_X=130; SPECIAL_Y=68; SPECIAL_RECT=(130,68,146,84)
patterns=[[[0 for _ in range(16)] for _ in range(16)] for _ in range(64)]
def dims(a2):
    return (2 if a2&1 else 1), {0:1,1:2,3:4}.get((a2>>4)&3,1)
# Fill main entries, skipping the peach rectangle so the dedicated palette-5 sprite can render it.
for tile,a1,a2,dx,dy in entries:
    if tile==0x3C:
        continue
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile+row*2+col
            if not (0<=pidx<64): continue
            sx0=BASE_X+dx+col*16; sy0=BASE_Y+dy+row*16
            arr=patterns[pidx]
            for y in range(16):
                sy=sy0+y
                if sy<0 or sy>=asset.height: continue
                for x in range(16):
                    sx=sx0+x
                    if sx<0 or sx>=asset.width: continue
                    if SPECIAL_RECT[0] <= sx < SPECIAL_RECT[2] and SPECIAL_RECT[1] <= sy < SPECIAL_RECT[3]:
                        continue
                    r,g,b,a=asset.getpixel((sx,sy))
                    if a:
                        arr[y][x]=nearest_idx((r,g,b),main_map)
# Fill special peach pattern p60 from its intended position and palette 5.
arr=patterns[0x3C]
for y in range(16):
    sy=SPECIAL_Y+y
    for x in range(16):
        sx=SPECIAL_X+x
        r,g,b,a=asset.getpixel((sx,sy))
        if a:
            arr[y][x]=nearest_idx((r,g,b),peach_map)
# Encode with swapped bytes per row, as v4/v5.
def encode_sprite_pattern(arr):
    out=[]
    for plane in range(4):
        for y in range(16):
            b0=b1=0
            for x in range(8,16):
                c=arr[y][x]; b0=(b0<<1)|((c>>plane)&1)
            for x in range(0,8):
                c=arr[y][x]; b1=(b1<<1)|((c>>plane)&1)
            out.extend([b0,b1])
    return bytes(out)
def comp(raw):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v: mask|=1<<bit; payload.append(v)
                elif v!=prev:
                    mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out+=bytes(payload)
    return bytes(out)
stream=bytearray([64]); lens=[]
for arr in patterns:
    c=comp(encode_sprite_pattern(arr)); lens.append(len(c)); stream+=c
start=0x252C8; end=0x2617B; max_len=end-start
if len(stream)>max_len: raise SystemExit(f'stream {len(stream)} > {max_len}')
rom[start:start+len(stream)]=stream
rom[start+len(stream):end]=bytes([0xFF])*(max_len-len(stream))
# Patch original first entry (separate peach sprite) to new position x=130 y=68.
# original entry: 3C 05 00 C9 E9
rom[list_off+3]= (SPECIAL_X-BASE_X) & 0xFF
rom[list_off+4]= (SPECIAL_Y-BASE_Y) & 0xFF
OUT.write_bytes(rom)
# IPS
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
# preview recomposed
pal=[(0,0,80),(146,73,36),(0,36,182),(0,146,219),(0,0,0),(219,182,0),(255,73,146),(255,109,255),(0,0,0),(80,80,80),(219,182,0),(255,146,109),(73,109,36),(219,182,219),(219,36,109),(255,109,255)]
prev=Image.new('RGB',(256,120),(0,0,80))
# patched entries for preview
entries2=entries.copy(); entries2[0]=(0x3C,5,0,SPECIAL_X-BASE_X,SPECIAL_Y-BASE_Y)
for tile,a1,a2,dx,dy in entries2:
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile+row*2+col
            if 0<=pidx<64:
                sx0=BASE_X+dx+col*16; sy0=BASE_Y+dy+row*16
                arr=patterns[pidx]
                for y in range(16):
                    for x in range(16):
                        c=arr[y][x]
                        if c:
                            px=sx0+x; py=sy0+y
                            if 0<=px<256 and 0<=py<120: prev.putpixel((px,py),pal[c])
PREVIEW.parent.mkdir(exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Test rótulo español — v6 con melocotón separado\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Cambio v6\n\nEl logo original usa un sprite pequeño separado para el melocotón, con paleta 5, en la posición japonesa original. Al mantener la lista original, ese sprite pintaba parte de `MOMOTARO` con colores rosas.\n\nV6 mueve ese sprite separado al melocotón del rótulo español y excluye la zona del melocotón de los sprites principales.\n\n- Nuevo melocotón: x={SPECIAL_X}, y={SPECIAL_Y}.\n- Patrón usado: `$3C` (p60).\n- Paleta del sprite: se mantiene la original `$05`.\n\n## Colores principales\n\n- Main palette: 1=marrón, 2=azul, 3=cian, 4=negro, 5=amarillo.\n- Peach palette: 1=piel, 2=hoja, 3=brillo, 4=negro, 5/6/7=rosas.\n\n## Datos\n\n- Stream: `{len(stream)}` bytes de {max_len}.\n- Longitudes por patrón: min {min(lens)}, max {max(lens)}.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream',len(stream),'max',max_len,'minmax',min(lens),max(lens))
print('records',len(records),sum(len(b) for _,b in records))
