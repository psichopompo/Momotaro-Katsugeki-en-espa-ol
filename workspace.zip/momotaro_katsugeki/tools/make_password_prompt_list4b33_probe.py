#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT=ROOT/'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_list4b33_probe.pce'
IPS=ROOT/'Parches/Pruebas/momotaro_traduccion_v03_prompt_list4b33_probe.ips'
REPORT=ROOT/'reports/test_password_prompt_list4b33_probe.md'
orig=ORIG.read_bytes(); base=BASE.read_bytes(); rom=bytearray(base)
# Encoder
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i in range(26): enc[chr(65+i)]=0x41+i
enc.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s):
    out=bytearray()
    for ch in s:
        if ch=='\n': out.append(0)
        else: out.append(enc[ch])
    return bytes(out)
def cpu0f(off):
    assert 0x1E000 <= off < 0x20000
    return 0x4000+(off-0x1E000)
def rle_encode(vals):
    out=bytearray(); i=0
    while i<len(vals):
        v=vals[i]; j=i+1
        while j<len(vals) and vals[j]==v and j-i<256: j+=1
        L=j-i
        if L>=3 or v==0xff: out += bytes([0xff,L-1,v])
        else: out += bytes([v])*L
        i=j
    return bytes(out)
# ---------------- Error de Jizo bueno + limpieza ----------------
text='¡El canto de Jizo\nno es correcto!\nRevísalo bien e\ninténtalo de nuevo.'
error_off=0x1F838; error_cpu=cpu0f(error_off)
data=bytes([1])+enc_text(text)+bytes([0xFF])
assert orig[error_off:error_off+len(data)]==bytes([0xFF])*len(data)
rom[error_off:error_off+len(data)]=data
rom[0x1AE60]=error_cpu&0xff; rom[0x1AE64]=error_cpu>>8
# line table error
lt_off=0x1BDB0; lt_cpu=0xDDB0
lt=bytes([0x08,0x70, 0x88,0x72, 0x08,0x75, 0x88,0x77])
assert orig[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
assert base[lt_off:lt_off+len(lt)]==bytes([0xFF])*len(lt)
rom[lt_off:lt_off+len(lt)]=lt
for off,cpu in [(0x1AE68,lt_cpu),(0x1AE70,lt_cpu+1),(0x1AEF4,lt_cpu),(0x1AEF9,lt_cpu+1)]:
    rom[off]=cpu&0xff; rom[off+1]=cpu>>8
# error viewport 5x4
vp_off=0x1F900; vp_cpu=cpu0f(vp_off)
vp=bytearray(); xoffs=[0,0x20,0x40,0x60,0x7F]
for row in range(4):
    for col,xoff in enumerate(xoffs): vp += bytes([(row*5+col)*2,0x0E,0x01,xoff,row*0x10])
vp.append(0xFF)
assert len(vp)==101
assert orig[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
assert base[vp_off:vp_off+len(vp)]==bytes([0xFF])*len(vp)
rom[vp_off:vp_off+len(vp)]=vp
rom[0x1AF5A]=0x0F; rom[0x1AF61]=0x46; rom[0x1AF63]=0x58; rom[0x1AF68]=vp_cpu&255; rom[0x1AF6C]=vp_cpu>>8
# statue
rom[0x1AE2F]=0x1D; rom[0x1AE31]=0x68
# bubble stream good
left,right,top,bottom=8,27,11,19
tm=[[0 for _ in range(32)] for __ in range(32)]
for c in range(left,right+1): tm[top][c]=2; tm[bottom][c]=7
tm[top][left]=1; tm[top][right]=3; tm[bottom][left]=6; tm[bottom][right]=8
for r in range(top+1,bottom):
    tm[r][left]=4; tm[r][right]=5
    for c in range(left+1,right): tm[r][c]=9
tail1=top+3; tail2=top+4
tm[tail1][left-1]=10; tm[tail1][left]=11
for c in range(left+1,right): tm[tail1][c]=9
tm[tail1][right]=5
tm[tail2][left-1]=12; tm[tail2][left]=13
for c in range(left+1,right): tm[tail2][c]=9
tm[tail2][right]=5
low=[tm[r][c] for r in range(32) for c in range(32)]
bubble_stream=rle_encode(low)
bubble_off=0x1F970; bubble_cpu=cpu0f(bubble_off)
assert orig[bubble_off:bubble_off+len(bubble_stream)]==bytes([0xFF])*len(bubble_stream)
assert base[bubble_off:bubble_off+len(bubble_stream)]==bytes([0xFF])*len(bubble_stream)
rom[bubble_off:bubble_off+len(bubble_stream)]=bubble_stream
rom[0x1AE1C]=bubble_cpu&255; rom[0x1AE20]=bubble_cpu>>8
# BG scroll stub for bubble good
bg_scroll_stub_off=0x1BDC0; bg_scroll_stub_cpu=0xDDC0
bg_scroll_stub=bytes([0xA9,0x02,0x85,0x35,0x20,0x14,0xCE,0x60])
assert orig[bg_scroll_stub_off:bg_scroll_stub_off+len(bg_scroll_stub)]==bytes([0xFF])*len(bg_scroll_stub)
assert base[bg_scroll_stub_off:bg_scroll_stub_off+len(bg_scroll_stub)]==bytes([0xFF])*len(bg_scroll_stub)
rom[bg_scroll_stub_off:bg_scroll_stub_off+len(bg_scroll_stub)]=bg_scroll_stub
rom[0x1ADCC:0x1ADCF]=bytes([0x20,bg_scroll_stub_cpu&255,bg_scroll_stub_cpu>>8])
# clear expanded error area
rom[0x1AE54]=0x28
# ---------------- Prompt superior limpio ----------------
prompt_text='¡Introduce el canto de Jizo!'
prompt_off=0x1F880; prompt_cpu=cpu0f(prompt_off)
prompt_data=bytes([1])+enc_text(prompt_text)+bytes([0xFF])
assert orig[prompt_off:prompt_off+len(prompt_data)]==bytes([0xFF])*len(prompt_data)
assert base[prompt_off:prompt_off+len(prompt_data)]==bytes([0xFF])*len(prompt_data)
rom[prompt_off:prompt_off+len(prompt_data)]=prompt_data
# CD04 prompt pointers
rom[0x1AD11]=prompt_cpu&255; rom[0x1AD15]=prompt_cpu>>8
rom[0x1AD48]=prompt_cpu&255; rom[0x1AD4C]=prompt_cpu>>8
# Probe $4B33: this is another list that starts with the four text chunks
# 0A/0C/0E/10. It is a plausible real projection list for one text row.
# Diagnostic only: we overwrite the beginning with 7 text chunks and an FF.
prompt_list_off=0x2EB33
prompt_list=bytearray()
# Keep original Y offset ($98), but shift X offsets left so 7 chunks fit within
# signed-byte range. If this is the real list, the prompt should visibly change.
for pat,xoff in zip([0x0A,0x0C,0x0E,0x10,0x12,0x14,0x16],[0x98,0xB8,0xD8,0xF8,0x18,0x38,0x58]):
    prompt_list += bytes([pat,0x0E,0x01,xoff,0x98])
prompt_list.append(0xFF)
rom[prompt_list_off:prompt_list_off+len(prompt_list)] = prompt_list
# ---------------- Navigation DOWN especial ----------------
def assemble_nav_stub():
    code=[]; labels={}; fix=[]
    def label(n): labels[n]=len(code)
    def emit(*bs): code.extend(bs)
    def bne(lbl): fix.append((len(code)+1,lbl)); emit(0xD0,0)
    def beq(lbl): fix.append((len(code)+1,lbl)); emit(0xF0,0)
    def bra(lbl): fix.append((len(code)+1,lbl)); emit(0x80,0)
    def lda_abs(addr): emit(0xAD,addr&255,addr>>8)
    def sta_abs(addr): emit(0x8D,addr&255,addr>>8)
    def cmp_imm(v): emit(0xC9,v)
    def lda_imm(v): emit(0xA9,v)
    def set_col(v): lda_imm(v); sta_abs(0x3C91); bra('call')
    lda_abs(0x3C92); cmp_imm(0x03); bne('check_row4')
    lda_abs(0x3C91); cmp_imm(0x06); beq('set5'); cmp_imm(0x0D); beq('set12'); bra('call')
    label('set5'); set_col(0x05)
    label('set12'); set_col(0x0C)
    label('check_row4'); cmp_imm(0x04); bne('call')
    lda_abs(0x3C91); cmp_imm(0x00); beq('set2'); cmp_imm(0x01); beq('set2'); cmp_imm(0x0C); beq('set11'); bra('call')
    label('set2'); set_col(0x02)
    label('set11'); lda_imm(0x0B); sta_abs(0x3C91)
    label('call'); emit(0x20,0x52,0xCC,0x60)
    for pos,lbl in fix:
        rel=labels[lbl]-(pos+1)
        code[pos]=rel&255
    return bytes(code)
nav_stub=assemble_nav_stub(); nav_off=0x1BC30
rom[nav_off:nav_off+len(nav_stub)]=nav_stub
# Guards: no overlay wrapper/list, no prompt residues in CD98
assert rom[0x1BC80:0x1BC9F] == base[0x1BC80:0x1BC9F] or base[0x1BC80:0x1BC9F]==bytes([0xFF])*0x1F
# Ensure CD98 original JMP remains not wrapper (unless base v02 already original)
assert rom[0x1ADB1:0x1ADB4] == base[0x1ADB1:0x1ADB4]
assert rom[0x2F8B5:0x30000] == base[0x2F8B5:0x30000]
# Output
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
REPORT.write_text(f'''# Prueba v03 — prompt superior probe lista $4B33

ROM:
`Roms/Pruebas/{OUT.name}`

IPS:
`Parches/Pruebas/{IPS.name}`

## Objetivo

Descartar el overlay/duplicado del prompt superior. Esta prueba NO añade sprites nuevos en CD98. En su lugar modifica otra lista candidata que empieza con los mismos cuatro chunks, CPU `$4B33`, ROM `0x2EB33`.

Texto:

```text
{prompt_text}
```

## Cambio prompt

- Texto del prompt relocalizado en ROM `0x{prompt_off:05X}`, CPU `${prompt_cpu:04X}`.
- Lista candidata `$4B33` modificada para 7 chunks en una sola línea:
  - patrones offset `$0A,$0C,$0E,$10,$12,$14,$16`.
  - X offsets `$98,$B8,$D8,$F8,$18,$38,$58`.
- No se toca `CD98` ni se crea overlay. Esta prueba es diagnóstica: si desaparece/rompe parte del marco, es aceptable para saber si la lista interviene.
- Bank `$17` padding `0x2F8B5-0x30000` intacto.

## Incluye de base

- Error de Jizo bueno + limpieza expandida.
- Navegación DOWN corregida:
  - U/V -> 0
  - T -> Z
  - t -> z
  - z -> 9

## Qué comprobar

1. Si el prompt se ve como una sola frase o sigue duplicado.
2. Si se ve completo o dónde se corta.
3. Si al pasar a la pantalla de error ya no queda residuo del prompt.
4. Que el error de Jizo sigue limpio/completo.
5. Que la navegación especial sigue bien.

## Cambios contra v02

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('prompt list $4B33 patched',hex(prompt_list_off),prompt_list.hex(' '))
print('changed',changed)
print('records',len(rec),'bytes',sum(len(b) for _,b in rec))
