#!/usr/bin/env python3
from pathlib import Path
import argparse

def s8(v): return v-256 if v>=128 else v

def parse_list(data, bank, cpu, base=0x4000):
    off=bank*0x2000+(cpu-base)
    recs=[]; i=off
    while i < len(data):
        if data[i]==0xFF:
            return recs, i+1
        rec=data[i:i+5]
        if len(rec)<5: break
        tile, a1, a2, dx, dy=rec
        recs.append({
            'rom_off': i,
            'cpu': cpu+(i-off),
            'tile_byte': tile,
            'tile_vram_word_if_base_03a0': 0x03A0 + tile*2,
            'attr1': a1,
            'attr2': a2,
            'dx': s8(dx),
            'dy': s8(dy),
            'raw': rec.hex(' '),
        })
        i+=5
    return recs,i

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--rom',default='/home/user/momotaro_katsugeki/work/Momotarou Katsugeki (Japan).pce')
    ap.add_argument('--bank',type=lambda x:int(x,0),default=0x17)
    ap.add_argument('cpu', nargs='+', type=lambda x:int(x,0))
    ap.add_argument('--base',type=lambda x:int(x,0),default=0x4000)
    ap.add_argument('--screen-x',type=lambda x:int(x,0),default=0x80)
    ap.add_argument('--screen-y',type=lambda x:int(x,0),default=0xC8)
    args=ap.parse_args()
    data=Path(args.rom).read_bytes()
    for cpu in args.cpu:
        recs,end=parse_list(data,args.bank,cpu,args.base)
        print(f'List CPU ${cpu:04X} bank ${args.bank:02X} ROM ${args.bank*0x2000+(cpu-args.base):05X}, records {len(recs)}, end ${end:05X}')
        for j,r in enumerate(recs):
            print(f" {j:02d} CPU ${r['cpu']:04X} ROM ${r['rom_off']:05X} raw {r['raw']} tile ${r['tile_byte']:02X}->${r['tile_vram_word_if_base_03a0']:04X} attr {r['attr1']:02X} {r['attr2']:02X} dx {r['dx']:4d} dy {r['dy']:4d} screen approx ({args.screen_x+r['dx']},{args.screen_y+r['dy']})")
