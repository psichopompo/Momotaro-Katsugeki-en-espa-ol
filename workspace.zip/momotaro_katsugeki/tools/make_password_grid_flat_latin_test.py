#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists(): BASE=ORIG
LATIN=ROOT/'Roms/Anteriores/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - password_grid_flat_latin_test.pce'
IPS=ROOT/'Parches/momotaro_password_grid_flat_latin_test.ips'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes()); latin=LATIN.read_bytes()
# 1) Copy validated latin font and conversion tables.
FONT_BASE=0x3D660; FONT_LEN=0xE0*8
rom[FONT_BASE:FONT_BASE+FONT_LEN]=latin[FONT_BASE:FONT_BASE+FONT_LEN]
for off,length in [(0x41CB3,0x40),(0x41CF3,0x40),(0x42B5B,0x36)]:
    rom[off:off+length]=latin[off:off+length]
# 2) Relocate runtime source alphabet table: <01> + 64 latin source bytes + FF.
rows=[
 list('ABCDEFGH'),
 list('IJKLMN')+['Ñ','O'],
 list('PQRSTUVW'),
 list('XYZabcde'),
 list('fghijklm'),
 ['n','ñ','o','p','q','r','s','t'],
 list('uvwxyz01'),
 list('23456789'),
]
symbols=[ch for row in rows for ch in row]
assert len(symbols)==64
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i,ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'): enc[ch]=0x41+i
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
# validated source-code exceptions
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,
            'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,
            '¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,
            "'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,
            '&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
source=bytes([enc[ch] for ch in symbols])
new_off=0x1BBB9; new_cpu=0xDBB9
table=bytes([0x01])+source+bytes([0xFF])
rom[new_off:new_off+len(table)]=table
rom[0x1A85E]=new_cpu&0xff
rom[0x1A862]=new_cpu>>8
# 3) Patch tilemap RLE streams used by C909/C63B to display a flat 8x8 grid.
def rle_encode(vals):
    out=bytearray(); i=0
    while i<len(vals):
        v=vals[i]; j=i+1
        while j<len(vals) and vals[j]==v and j-i<256:
            j+=1
        L=j-i
        if L>=3 or v==0xff:
            out += bytes([0xff,L-1,v])
        else:
            out += bytes([v])*L
        i=j
    return bytes(out)
# The decoded tilemap is 32 rows x 32 streamed cols (+32 blank cols written by routine).
tm=[[0x100 for _ in range(32)] for __ in range(32)]
start_r=7
cols=[5,8,11,14,17,20,23,26]
idx=0
for rr in range(8):
    for cc,c in enumerate(cols):
        tm[start_r+rr][c]=0x100+idx
        idx+=1
low=[]; high=[]
for r in range(32):
    for c in range(32):
        w=tm[r][c]
        low.append(w&0xff)
        high.append(((w>>8)-1)&0xff)
low_stream=rle_encode(low)
high_stream=rle_encode(high)
assert len(low_stream)<=0x1E290-0x1E18C, len(low_stream)
assert len(high_stream)<=12, len(high_stream)
rom[0x1E18C:0x1E290]=low_stream + bytes([0xFF])*(0x1E290-0x1E18C-len(low_stream))
rom[0x1E290:0x1E29C]=high_stream + bytes([0xFF])*(12-len(high_stream))
# 4) Write output and IPS.
OUT.write_bytes(rom)
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]:
        i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec:
    ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
(ROOT/'reports/test_password_grid_flat_latin.md').write_text(f'''# Password grid flat latin test\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\n## Objetivo\n\nPrimera prueba de la Vía A: parchear el layout/tilemap de la pantalla de password para que muestre una parrilla plana de 64 símbolos latinos.\n\n## Cambios\n\n1. Se copia la fuente latina validada.\n2. Se relocaliza la tabla runtime de símbolos a `0x{new_off:05X}` / CPU `${new_cpu:04X}`.\n3. Se reemplazan los streams RLE de tilemap usados por la pantalla (`0x1E18C` y `0x1E290`) para colocar `0x100+index` en una parrilla 8x8.\n\n## Parrilla esperada\n\n```text\n{''.join(rows[0])}\n{''.join(rows[1])}\n{''.join(rows[2])}\n{''.join(rows[3])}\n{''.join(rows[4])}\n{''.join(rows[5])}\n{''.join(rows[6])}\n{''.join(rows[7])}\n```\n\n## Streams\n\n- Low stream: {len(low_stream)} bytes de {0x1E290-0x1E18C} disponibles.\n- High stream: {len(high_stream)} bytes de 12 disponibles.\n\n## Posición\n\n- Filas tilemap: {start_r}..{start_r+7}.\n- Columnas tilemap: {cols}.\n\n## Qué comprobar\n\n1. Que la parrilla aparece como 8x8 latina.\n2. Que `Ñ` y `ñ` salen correctamente.\n3. Que no quedan marcas de dakuten/handakuten.\n4. Que el cursor puede moverse por la parrilla.\n5. Que al introducir caracteres, el buffer inferior muestra el carácter elegido o al menos no se rompe.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in rec)}\n''',encoding='utf-8')
print('OUT',OUT)
print('low/high',len(low_stream),len(high_stream))
print('records',len(rec),sum(len(b) for _,b in rec))
