from pathlib import Path
from PIL import Image, ImageDraw
import argparse, math
ap=argparse.ArgumentParser(); ap.add_argument('rom'); ap.add_argument('out'); ap.add_argument('--bank',type=lambda x:int(x,0)); ap.add_argument('--scale',type=int,default=3); ap.add_argument('--stride',type=int,default=8); args=ap.parse_args()
data=Path(args.rom).read_bytes(); start=args.bank*0x2000 if args.bank is not None else 0; buf=data[start:start+0x2000]
stride=args.stride; tiles=[buf[i:i+stride] for i in range(0,len(buf)-stride+1,stride)]
cols=32; rows=math.ceil(len(tiles)/cols); cell=8*args.scale; top=14
img=Image.new('RGB',(cols*cell, rows*cell+top),(240,240,240)); d=ImageDraw.Draw(img); d.text((2,1),f'bank {args.bank:02X} off ${start:05X} 1bpp stride {stride}',(0,0,0))
for n,t in enumerate(tiles):
    im=Image.new('RGB',(8,8),(255,255,255)); pix=im.load()
    for y in range(8):
        b=t[y] if y<len(t) else 0
        for x in range(8):
            if (b>>(7-x))&1: pix[x,y]=(0,0,0)
    im=im.resize((cell,cell),Image.Resampling.NEAREST); img.paste(im,((n%cols)*cell, top+(n//cols)*cell))
Path(args.out).parent.mkdir(parents=True,exist_ok=True); img.save(args.out)
