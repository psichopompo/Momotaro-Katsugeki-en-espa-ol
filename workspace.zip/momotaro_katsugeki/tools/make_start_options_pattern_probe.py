#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_options_pattern_probe.pce'
IPS=ROOT/'Parches/momotaro_start_options_pattern_probe.ips'
PREVIEW=ROOT/'images/start_options_pattern_probe_preview.png'
REPORT=ROOT/'reports/test_pattern_probe_opciones.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
DIG={
'0':["01110","10001","10011","10101","11001","10001","01110"],
'1':["00100","01100","00100","00100","00100","00100","01110"],
'2':["01110","10001","00001","00010","00100","01000","11111"],
'3':["11110","00001","00001","01110","00001","00001","11110"],
'4':["00010","00110","01010","10010","11111","00010","00010"],
'5':["11111","10000","10000","11110","00001","00001","11110"],
}
def marker(n):
    img=Image.new('P',(16,16),0); p=img.load()
    # border style unique: top/bottom/left/right with index1
    for x in range(16): p[x,0]=1; p[x,15]=1
    for y in range(16): p[0,y]=1; p[15,y]=1
    # digit 0..5 big, index1 with shadow 2
    pat=DIG[str(n)]
    ox,oy=5,4
    for yy,row in enumerate(pat):
        for xx,b in enumerate(row):
            if b=='1':
                if p[ox+xx+1,oy+yy+1]==0: p[ox+xx+1,oy+yy+1]=2
    for yy,row in enumerate(pat):
        for xx,b in enumerate(row):
            if b=='1': p[ox+xx,oy+yy]=1
    # unique small stripe at bottom perhaps color2 count n
    for x in range(1,n+2): p[x,14]=2
    return img
def encode_sprite16(img):
    out=[]
    for plane in range(4):
        for y in range(16):
            b0=b1=0
            for x in range(8):
                c=img.getpixel((x,y)); b0=(b0<<1)|((c>>plane)&1)
            for x in range(8,16):
                c=img.getpixel((x,y)); b1=(b1<<1)|((c>>plane)&1)
            out.extend([b0,b1])
    return bytes(out)
def comp(raw):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v: mask|=1<<bit; payload.append(v)
                elif v!=prev:
                    mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out+=bytes(payload)
    return bytes(out)
patterns=[marker(i) for i in range(6)]
stream=bytearray([6]); lens=[]
for im in patterns:
    c=comp(encode_sprite16(im)); lens.append(len(c)); stream+=c
start=0x272DE; end=0x273F9; max_len=end-start
if len(stream)>max_len: raise SystemExit(f'probe stream too long {len(stream)} > {max_len}; {lens}')
rom[start:start+len(stream)]=stream
rom[start+len(stream):end]=bytes([0xFF])*(max_len-len(stream))
OUT.write_bytes(rom)
# IPS
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
# preview
pal=[(0,0,80),(255,109,33),(33,36,33)]; scale=4
prev=Image.new('RGB',(6*16*scale,16*scale),pal[0])
for i,im in enumerate(patterns):
    for y in range(16):
        for x in range(16):
            c=im.getpixel((x,y)); col=pal[c]
            if c:
                for yy in range(scale):
                    for xx in range(scale): prev.putpixel((i*16*scale+x*scale+xx,y*scale+yy),col)
PREVIEW.parent.mkdir(exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Pattern probe para opciones de inicio\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Objetivo\n\nDejar intactas las listas originales `$46B5/$46C5`, pero sustituir el stream gráfico original por 6 patrones marcados con números `0-5`.\n\nEsto sirve para ver en el emulador exactamente qué patrón usa cada sprite y cómo se combinan los patrones cuando un sprite es ancho.\n\n## Resultado esperado\n\nAl pulsar RUN, donde antes salían `HAJIMETE / TSUZUGI` deberían verse bloques numerados. La posición/secuencia de esos números nos dirá cómo mapear correctamente los gráficos españoles.\n\n## Datos\n\n- Stream nuevo: `{len(stream)}` bytes de {max_len}.\n- Lens: `{lens}`.\n- Listas de metasprite: originales, sin tocar.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream',len(stream),'lens',lens)
print('records',len(records),sum(len(b) for _,b in records))
