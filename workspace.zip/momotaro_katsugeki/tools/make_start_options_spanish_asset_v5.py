#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
ASSET=ROOT/'title_assets/start_options_es.png'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_options_spanish_asset_test_v5.pce'
IPS=ROOT/'Parches/momotaro_start_options_spanish_asset_test_v5.ips'
PREVIEW=ROOT/'images/start_options_spanish_asset_v5_preview.png'
REPORT=ROOT/'reports/test_empezar_continuar_asset_usuario_v5.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
# canvas 128x16 from asset
src=Image.open(ASSET).convert('RGBA')
crop=src.crop((0,2,125,18))
canvas=Image.new('P',(128,16),0)
for y in range(crop.height):
    for x in range(crop.width):
        r,g,b,a=crop.getpixel((x,y))
        if a==0: continue
        xx=x+1; yy=y
        if 0<=xx<128 and 0<=yy<16:
            canvas.putpixel((xx,yy), 2 if (r<40 and g<40 and b<40) else 1)

def encode_sprite_pattern_16(img,x0):
    out=[]
    for plane in range(4):
        for y in range(16):
            b0=b1=0
            for x in range(8):
                c=img.getpixel((x0+x,y)); b0=(b0<<1)|((c>>plane)&1)
            for x in range(8,16):
                c=img.getpixel((x0+x,y)); b1=(b1<<1)|((c>>plane)&1)
            out.extend([b0,b1])
    return bytes(out)
def compress(raw):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v: mask|=1<<bit; payload.append(v)
                elif v!=prev:
                    mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out+=bytes(payload)
    return bytes(out)
patterns=[encode_sprite_pattern_16(canvas,x) for x in range(0,128,16)]
stream=bytearray([len(patterns)]); lens=[]
for p in patterns:
    c=compress(p); lens.append(len(c)); stream+=c
stream_off=0x2F8B5; stream_cpu=0x78B5
rom[stream_off:stream_off+len(stream)]=stream
# patch loader to bank16/17 and source $78B5
rom[0x18EEB]=0x16
rom[0x18EFF]=stream_cpu&0xFF
rom[0x18F03]=stream_cpu>>8
# lists after stream
list1_off=(stream_off+len(stream)+0x0F)&~0x0F
list2_off=list1_off+8*5+1
list1_cpu=0x4000+(list1_off-0x2E000); list2_cpu=0x4000+(list2_off-0x2E000)
def rec(tile,attr,attr2,dx,dy): return bytes([tile,attr,attr2,dx&0xff,dy&0xff])
# V5: 8 narrow 16px entries. Tile bytes separated by $20 to point to next 16x16 pattern.
tiles=[0x00,0x20,0x40,0x60,0x80,0xA0,0xC0,0xE0]
dxs=[-64,-48,-32,-16,0,16,32,48]
list1=b''.join(rec(t,0x07 if i<4 else 0x06,0x00,dx,-16) for i,(t,dx) in enumerate(zip(tiles,dxs)))+b'\xff'
list2=b''.join(rec(t,0x06 if i<4 else 0x07,0x00,dx,-16) for i,(t,dx) in enumerate(zip(tiles,dxs)))+b'\xff'
rom[list1_off:list1_off+len(list1)]=list1
rom[list2_off:list2_off+len(list2)]=list2
rom[0x2E6B1:0x2E6B5]=bytes([list1_cpu&0xff,list1_cpu>>8,list2_cpu&0xff,list2_cpu>>8])
OUT.write_bytes(rom)
# IPS
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
# preview
pal=[(0,0,80),(255,109,33),(33,36,33)]; scale=4
prev=Image.new('RGB',(512,64),pal[0])
for y in range(16):
 for x in range(128):
  c=canvas.getpixel((x,y))
  if c:
   for yy in range(scale):
    for xx in range(scale): prev.putpixel((x*scale+xx,y*scale+yy),pal[c])
prev.save(PREVIEW)
REPORT.write_text(f'''# Test v5 `EMPEZAR / CONTINUAR` usando asset del usuario\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\n## Cambio v5\n\nLa v4 seguía reordenando/fusionando partes. La hipótesis es que los valores de tile de la SAT necesitan saltar `$20` para apuntar al siguiente patrón de 16x16.\n\nV5 usa 8 entradas estrechas de 16 px, con tile bytes:\n\n```text\n00 20 40 60 80 A0 C0 E0\n```\n\n## Datos\n\n- Stream: ROM `0x{stream_off:05X}`, CPU `$78B5`, len `{len(stream)}`.\n- Lens: `{lens}`.\n- Lista 1: CPU `${list1_cpu:04X}`, ROM `0x{list1_off:05X}`.\n- Lista 2: CPU `${list2_cpu:04X}`, ROM `0x{list2_off:05X}`.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream',len(stream),'lens',lens)
print('list1',hex(list1_cpu),list1.hex(' '))
print('list2',hex(list2_cpu),list2.hex(' '))
print('records',len(records),sum(len(b) for _,b in records))
