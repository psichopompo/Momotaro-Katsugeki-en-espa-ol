#!/usr/bin/env python3
from pathlib import Path

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce'
OUT = ROOT / 'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_width_bank0f_test.pce'
IPS = ROOT / 'Parches/Pruebas/momotaro_traduccion_v03_error_text4_width_bank0f_test.ips'
REPORT = ROOT / 'reports/test_password_error_text4_width_bank0f_v03.md'

orig = ORIG.read_bytes(); base = BASE.read_bytes(); rom = bytearray(base)
# Encoder
CHAR_TO_CODE={' ':0x20}
for i in range(10): CHAR_TO_CODE[str(i)]=0x30+i
for i in range(26): CHAR_TO_CODE[chr(ord('A')+i)]=0x41+i
CHAR_TO_CODE.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): CHAR_TO_CODE[ch]=0xA1+i
CHAR_TO_CODE['b']=0x5B; CHAR_TO_CODE['c']=0x5D; CHAR_TO_CODE['p']=0x5E
CHAR_TO_CODE.update({'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
def enc_text(s):
    out=bytearray()
    for ch in s:
        if ch=='\n': out.append(0x00)
        else:
            if ch not in CHAR_TO_CODE: raise ValueError(ch)
            out.append(CHAR_TO_CODE[ch])
    return bytes(out)
def cpu0f(off): return 0x4000+(off-0x1E000)
def ptr_abs(low_off, high_off, cpu): rom[low_off]=cpu&0xff; rom[high_off]=cpu>>8
# Text exactly as requested.
text='¡El canto de Jizo\nno es correcto!\nRevísalo bien e\ninténtalo de nuevo.'
line_lengths=[len(x) for x in text.split('\n')]
error_off=0x1F838; error_cpu=cpu0f(error_off)
error_data=bytes([0x01])+enc_text(text)+bytes([0xFF])
assert orig[error_off:error_off+len(error_data)] == bytes([0xFF])*len(error_data)
rom[error_off:error_off+len(error_data)] = error_data
ptr_abs(0x1AE60,0x1AE64,error_cpu)
# Line storage stride for 5-column viewport: 20 chars per line.
line_table_off=0x1BDB0; line_table_cpu=0xDDB0
# $7008, $7288, $7508, $7788.  This gives each line 5 chunks (20 chars)
# instead of the original 4 chunks (16 chars), so the 17th char is not
# overwritten by the next line.
line_table=bytes([0x08,0x70, 0x88,0x72, 0x08,0x75, 0x88,0x77])
assert orig[line_table_off:line_table_off+len(line_table)] == bytes([0xFF])*len(line_table)
assert base[line_table_off:line_table_off+len(line_table)] == bytes([0xFF])*len(line_table)
rom[line_table_off:line_table_off+len(line_table)] = line_table
for off,cpu in [(0x1AE68,line_table_cpu),(0x1AE70,line_table_cpu+1),(0x1AEF4,line_table_cpu),(0x1AEF9,line_table_cpu+1)]:
    rom[off]=cpu&0xff; rom[off+1]=cpu>>8
# New 5-column x 3-row viewport/metasprite list. Do NOT use bank $17:
# the previous test wrote into apparently-free bank17 padding and corrupted the
# title/options. Store the list in the text bank $0F free area and patch CF59's
# bank constant from $17 to $0F.
viewport_off=0x1F900; viewport_cpu=0x5900
viewport=bytearray()
for row in range(3):
    for col in range(5):
        # source chunks are contiguous: row*5+col, each chunk uses pattern offset +2
        viewport += bytes([(row*5+col)*2, 0x0E, 0x01, col*0x20, row*0x10])
viewport.append(0xFF)
assert orig[viewport_off:viewport_off+len(viewport)] == bytes([0xFF])*len(viewport)
assert base[viewport_off:viewport_off+len(viewport)] == bytes([0xFF])*len(viewport)
rom[viewport_off:viewport_off+len(viewport)] = viewport
# Patch CF59: use bank $0F and new pointer. Keep original origin X/Y and bocadillo.
rom[0x1AF5A] = 0x0F
rom[0x1AF68] = viewport_cpu & 0xFF
rom[0x1AF6C] = viewport_cpu >> 8
# Anti-corruption guards: bocadillo and all bank17 title/viewport data stay v02.
assert rom[0x1E29C:0x1E2DF] == base[0x1E29C:0x1E2DF]
assert rom[0x2EC10:0x2EC4D] == base[0x2EC10:0x2EC4D]
assert rom[0x2F8B5:0x30000] == base[0x2F8B5:0x30000]
# Output
OUT.parent.mkdir(parents=True,exist_ok=True); IPS.parent.mkdir(parents=True,exist_ok=True); REPORT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_bytes(rom)
new=bytes(rom)
records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)
changed=[]; i=0
while i<len(base):
    if base[i]==new[i]: i+=1; continue
    s=i
    while i<len(base) and base[i]!=new[i]: i+=1
    changed.append((s,i-s))
REPORT.write_text(f'''# Prueba v03 — error de Jizo 4 líneas, ancho +1 chunk en bank $0F

ROM:

`Roms/Pruebas/{OUT.name}`

IPS:

`Parches/Pruebas/{IPS.name}`

## Objetivo

Mantener el bocadillo original y el texto exactamente en estas 4 líneas:

```text
{text}
```

La prueba anterior mostraba sólo 16 caracteres de la primera línea (`¡El canto de Jiz`). Esta prueba intenta que aparezca la `o` de `Jizo` sin tocar el bocadillo.

## Cambio técnico mínimo

- No se toca el tilemap/bocadillo de error.
- Se añade una ventanilla/metasprite de 5 columnas x 3 filas en la zona libre del bank `$0F`, no en bank `$17`:
  - ROM `0x{viewport_off:05X}` / CPU `${viewport_cpu:04X}` / len `{len(viewport)}`.
- Se parchea `CF59` para mapear bank `$0F` en vez de `$17` sólo al leer esta lista.
- Se separan las líneas en VRAM con stride de 5 chunks / 20 caracteres:
  - `$7008`, `$7288`, `$7508`, `$7788`.

Esto es para comprobar si el problema horizontal era que el 17.º carácter se pisaba con la siguiente línea o no se proyectaba.

## Validación anti-corrupción

- `0x1E29C-0x1E2DF` idéntico a v02: bocadillo original.
- `0x2EC10-0x2EC4D` idéntico a v02: lista original preservada.
- `0x2F8B5-0x30000` idéntico a v02: bank `$17` completo desde esa zona no se toca.
- Nuevo viewport escrito en bank `$0F`, `0x1F900`, zona FF libre en v02.

## Longitudes

`{line_lengths}`

## Cambios contra v02

{chr(10).join(f'- `0x{{off:05X}}` len `{{ln}}`' for off,ln in changed)}

## Qué comprobar

1. Que EMPEZAR/CONTINUAR no se corrompen; ésta es la comprobación principal frente al test anterior.
2. Que el bocadillo sigue exactamente como en la prueba vanilla/original.
3. Si ahora se ve `Jizo` completo en la primera línea.
4. Qué pasa con las líneas 2 y 3 tras cambiar el stride.
5. No evaluar todavía la cuarta línea: seguimos midiendo ancho de ventanilla.
''',encoding='utf-8')
print('OUT',OUT)
print('IPS',IPS)
print('REPORT',REPORT)
print('line lengths',line_lengths,'error len',len(error_data))
print('line table',hex(line_table_off),line_table.hex(' '))
print('viewport',hex(viewport_off),hex(viewport_cpu),len(viewport))
print('changed vs base',changed)
print('records',len(records),'changed',sum(len(b) for _,b in records))
