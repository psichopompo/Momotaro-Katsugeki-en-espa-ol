#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
ASSET=ROOT/'title_assets/title_logo_es_fullscreen.png'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test.pce'
IPS=ROOT/'Parches/momotaro_title_logo_spanish_original_layout_test.ips'
PREVIEW=ROOT/'images/title_logo_spanish_original_layout_preview.png'
REPORT=ROOT/'reports/test_rotulo_titulo_original_layout.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
asset=Image.open(ASSET).convert('RGBA')
# Color index mapping for sprite palette. Provisional but using indices used by original logo stream.
# Main goal is structure; palette can be adjusted later.
color_map={
    (0,0,0):8,
    (0,36,182):5,
    (0,146,219):7,
    (219,182,0):10,
    (146,73,36):2,
    (219,36,109):14,
    (255,109,255):15,
    (255,73,146):14,
    (255,146,109):11,
    (219,182,219):13,
    (73,109,36):12,
}
def nearest_idx(rgb):
    if rgb in color_map: return color_map[rgb]
    best=min(color_map, key=lambda c: sum((rgb[i]-c[i])**2 for i in range(3)))
    return color_map[best]
# Original title logo metasprite list at bank17 CPU $42B0 / ROM $2E2B0.
list_off=0x2E2B0
entries=[]; i=list_off
while orig[i]!=0xFF:
    tile,a1,a2,dx,dy=orig[i:i+5]
    dx=dx-256 if dx>=128 else dx
    dy=dy-256 if dy>=128 else dy
    entries.append((tile,a1,a2,dx,dy))
    i+=5
# Base visible coords inferred from real SAT and list math: x=128, y=88.
BASE_X=128; BASE_Y=88
# Pattern array 64 patterns. Each pattern is a 16x16 array of color indices.
patterns=[[[0 for _ in range(16)] for _ in range(16)] for _ in range(64)]
def dims(a2):
    w=2 if (a2 & 1) else 1
    hcode=(a2>>4)&3
    h={0:1,1:2,3:4}.get(hcode,1)
    return w,h
# For each original sprite, sample the final fullscreen Spanish logo at the screen pixels that this pattern will cover.
for tile,a1,a2,dx,dy in entries:
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile + row*2 + col
            if not (0<=pidx<64):
                continue
            sx0=BASE_X + dx + col*16
            sy0=BASE_Y + dy + row*16
            arr=patterns[pidx]
            for y in range(16):
                sy=sy0+y
                if sy<0 or sy>=asset.height: continue
                for x in range(16):
                    sx=sx0+x
                    if sx<0 or sx>=asset.width: continue
                    r,g,b,a=asset.getpixel((sx,sy))
                    if a==0:
                        continue
                    arr[y][x]=nearest_idx((r,g,b))

def encode_bg_tile_8(pix8):
    # Same raw layout expected by the game's stream decompressor: four 8x8 PCE tiles per 16x16 pattern.
    out1=[]; out2=[]
    for y in range(8):
        b=[0,0,0,0]
        for x in range(8):
            c=pix8[y][x]; bit=7-x
            for p in range(4): b[p]|=((c>>p)&1)<<bit
        out1.extend([b[0],b[1]]); out2.extend([b[2],b[3]])
    return bytes(out1+out2)
def encode_pattern_16(arr):
    data=bytearray()
    for ty,tx in [(0,0),(0,8),(8,0),(8,8)]:
        pix=[]
        for y in range(8):
            pix.append([arr[ty+y][tx+x] for x in range(8)])
        data += encode_bg_tile_8(pix)
    return bytes(data)
def compress_pattern(raw128):
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw128[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v!=0:
                        mask|=1<<bit; payload.append(v)
                elif v!=prev:
                    mask|=1<<bit; payload.append(v)
                prev=v
            out.append(mask); out += bytes(payload)
    return bytes(out)
stream=bytearray([64]); lens=[]
for arr in patterns:
    c=compress_pattern(encode_pattern_16(arr)); lens.append(len(c)); stream+=c
start=0x252C8; end=0x2617B; max_len=end-start
if len(stream)>max_len:
    raise SystemExit(f'Stream too large {len(stream)} > {max_len}')
rom[start:start+len(stream)] = stream
rom[start+len(stream):end] = bytes([0xFF])*(max_len-len(stream))
# Keep original logo metasprite list unchanged! Only stream is replaced.
OUT.write_bytes(rom)
# IPS
new=bytes(rom); records=[]; j=0
while j<len(orig):
    if orig[j]==new[j]: j+=1; continue
    s=j; buf=bytearray()
    while j<len(orig) and orig[j]!=new[j] and len(buf)<0xffff:
        buf.append(new[j]); j+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
# Preview recomposed through original list positions using approximate colors.
pal=[(0,0,80),(255,255,255),(146,73,36),(0,0,0),(0,36,182),(0,36,182),(0,146,219),(0,146,219),(0,0,0),(80,80,80),(219,182,0),(255,146,109),(73,109,36),(219,182,219),(219,36,109),(255,109,255)]
prev=Image.new('RGB',(256,120),(0,0,80))
# draw background transparent as blue, patterns via list
for tile,a1,a2,dx,dy in entries:
    w,h=dims(a2)
    for row in range(h):
        for col in range(w):
            pidx=tile+row*2+col
            if not (0<=pidx<64): continue
            sx0=BASE_X+dx+col*16; sy0=BASE_Y+dy+row*16
            arr=patterns[pidx]
            for y in range(16):
                for x in range(16):
                    c=arr[y][x]
                    if c:
                        px=sx0+x; py=sy0+y
                        if 0<=px<256 and 0<=py<120: prev.putpixel((px,py),pal[c])
PREVIEW.parent.mkdir(exist_ok=True); prev.save(PREVIEW)
REPORT.write_text(f'''# Test rótulo español con layout original del logo\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa: `images/{PREVIEW.name}`\n\n## Cambio respecto al test anterior\n\nEl test anterior reemplazaba la lista de metasprites por 8 sprites uniformes. Eso no respeta el layout real del logo.\n\nEste test mantiene **intacta la lista original** del logo japonés y sólo sustituye el stream gráfico `0x252C8-0x2617A`.\n\nEl rótulo español se corta en patrones siguiendo exactamente las posiciones y tamaños del layout original:\n\n- base visible X: `{BASE_X}`\n- base visible Y: `{BASE_Y}`\n- patrones calculados a partir de la lista original en ROM `0x{list_off:05X}`\n\n## Datos\n\n- Stream original: `0x{start:05X}-0x{end-1:05X}` ({max_len} bytes).\n- Stream nuevo: `{len(stream)}` bytes.\n- Patrones: 64.\n- Longitudes por patrón: min `{min(lens)}`, max `{max(lens)}`.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('stream',len(stream),'max',max_len,'minmax',min(lens),max(lens))
print('entries',len(entries),entries)
print('records',len(records),sum(len(b) for _,b in records))
