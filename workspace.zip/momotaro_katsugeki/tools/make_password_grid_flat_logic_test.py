#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists(): BASE=ORIG
LATIN=ROOT/'Roms/Anteriores/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - password_grid_flat_logic_test.pce'
IPS=ROOT/'Parches/momotaro_password_grid_flat_logic_test.ips'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes()); latin=LATIN.read_bytes()
# Copy latin font/maps
FONT_BASE=0x3D660; FONT_LEN=0xE0*8
rom[FONT_BASE:FONT_BASE+FONT_LEN]=latin[FONT_BASE:FONT_BASE+FONT_LEN]
for off,length in [(0x41CB3,0x40),(0x41CF3,0x40),(0x42B5B,0x36)]:
    rom[off:off+length]=latin[off:off+length]
# 64 symbol table
rows=[list('ABCDEFGH'), list('IJKLMN')+['Ñ','O'], list('PQRSTUVW'), list('XYZabcde'), list('fghijklm'), ['n','ñ','o','p','q','r','s','t'], list('uvwxyz01'), list('23456789')]
symbols=[ch for row in rows for ch in row]
enc={' ':0x20}
for i in range(10): enc[str(i)]=0x30+i
for i,ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'): enc[ch]=0x41+i
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): enc[ch]=0xA1+i
enc['b']=0x5B; enc['c']=0x5D; enc['p']=0x5E
enc.update({'ñ':0xC1,'Ñ':0xC8,'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,"'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,'&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'Ç':0x5F,'º':0xDC,'ª':0xDD})
source=bytes([enc[ch] for ch in symbols])
new_off=0x1BBB9; new_cpu=0xDBB9
rom[new_off:new_off+66]=bytes([0x01])+source+bytes([0xFF])
rom[0x1A85E]=new_cpu&0xff; rom[0x1A862]=new_cpu>>8
# RLE tilemap: 8x8 visual grid, shifted slightly left vs previous to remove invisible left region.
def rle_encode(vals):
    out=bytearray(); i=0
    while i<len(vals):
        v=vals[i]; j=i+1
        while j<len(vals) and vals[j]==v and j-i<256: j+=1
        L=j-i
        if L>=3 or v==0xff: out += bytes([0xff,L-1,v])
        else: out += bytes([v])*L
        i=j
    return bytes(out)
tm=[[0x100 for _ in range(32)] for __ in range(32)]
start_r=7
cols=[3,6,9,12,15,18,21,24]
idx=0
for rr in range(8):
    for c in cols:
        tm[start_r+rr][c]=0x100+idx; idx+=1
low=[]; high=[]
for r in range(32):
    for c in range(32):
        w=tm[r][c]
        low.append(w&0xff); high.append(((w>>8)-1)&0xff)
low_stream=rle_encode(low); high_stream=rle_encode(high)
assert len(low_stream)<=0x1E290-0x1E18C, len(low_stream)
assert len(high_stream)<=12, len(high_stream)
rom[0x1E18C:0x1E290]=low_stream+bytes([0xff])*(0x1E290-0x1E18C-len(low_stream))
rom[0x1E290:0x1E29C]=high_stream+bytes([0xff])*(12-len(high_stream))
# Patch logical grid layout tables: 8 columns x 8 rows, row-major returns indices 1..64.
# Row offsets at CC61, x/y tables kept old-ish but first 8 slots. Values table at CC82.
rom[0x1AC61:0x1AC61+10]=bytes([0,8,16,24,32,40,48,56,0,0])
values=[]
for r in range(8):
    values += list(range(1+r*8,1+(r+1)*8))
# Fill rest with 0; keep F0-F4 not reachable in this test.
values += [0]*(130-len(values))
rom[0x1AC82:0x1AC82+130]=bytes(values)
# Patch navigation bounds for grid mode: rows 0..7, cols 0..7.
# CPU C? addresses in bank0D mapped C000; ROM = 0x1A000+(addr-C000)
patches={
    0x1AA56:0x07, # CA55 LDA #$09 -> #$07 for row wrap up
    0x1AA6A:0x08, # CA69 CMP #$0A -> #$08 row max
    0x1AA80:0x08, # CA7F CMP #$0D -> #$08 col max
    0x1AA95:0x07, # CA94 LDA #$0C -> #$07 col wrap left
}
for off,val in patches.items(): rom[off]=val
OUT.write_bytes(rom)
# IPS
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
(ROOT/'reports/test_password_grid_flat_logic.md').write_text(f'''# Password grid flat logic test\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\n## Objetivo\n\nSegundo paso de la Vía A. Además de cambiar visualmente el tilemap, se parchea la lógica de navegación/selección para que use una parrilla 8x8 plana.\n\n## Cambios\n\n- Fuente latina validada.\n- Tabla runtime de 64 símbolos en `0x{new_off:05X}`.\n- Tilemap plano 8x8.\n- Tabla de offsets `CC61`: `00 08 10 18 20 28 30 38`.\n- Tabla de valores `CC82`: `01..40` en orden row-major.\n- Límites de navegación: filas `0..7`, columnas `0..7`.\n\n## Parrilla esperada\n\n```text\n{''.join(rows[0])}\n{''.join(rows[1])}\n{''.join(rows[2])}\n{''.join(rows[3])}\n{''.join(rows[4])}\n{''.join(rows[5])}\n{''.join(rows[6])}\n{''.join(rows[7])}\n```\n\n## Qué comprobar\n\n1. Si el cursor ya se mueve sólo por las 64 letras visibles.\n2. Si al seleccionar A/B/C... se insertan los caracteres correctos.\n3. Si desaparece la columna invisible de la izquierda.\n4. Si el buffer inferior deja de mostrar caracteres basura arriba.\n\nNota: en esta prueba la columna derecha (`ADELANTE/ATRÁS/...`) queda inalcanzable o rota; se arreglará después. El objetivo es sólo alinear parrilla visual y lógica.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{{off:06X}}` len `{{len(buf)}}`' for off,buf in rec)}\n''',encoding='utf-8')
print('OUT',OUT)
print('low/high',len(low_stream),len(high_stream),'records',len(rec),sum(len(b) for _,b in rec))
