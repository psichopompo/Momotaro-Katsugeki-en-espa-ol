#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path('/home/user/momotaro_katsugeki')
ORIG = ROOT / 'work/Momotarou Katsugeki (Japan).pce'
BASE = ROOT / 'Roms/Momotarou Katsugeki (Japan) - traduccion_v01.pce'
USER_OPTIONS = Path('/home/user/uploads/IMG_4537.PNG')
OUT = ROOT / 'Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v02_opciones_gfx_test.pce'
IPS = ROOT / 'Parches/Pruebas/momotaro_traduccion_v02_opciones_gfx_test.ips'
REPORT = ROOT / 'reports/test_password_options_gfx_v02.md'
PREVIEW = ROOT / 'images/password_options_gfx_v02_actual_tilemap_preview.png'
OPTIONS_COPY = ROOT / 'font_edit/password_options_user_gfx.png'
OPTIONS_TILES_REF = ROOT / 'font_edit/password_options_user_gfx_tiles_8x.png'

orig = ORIG.read_bytes()
rom = bytearray(BASE.read_bytes())

FONT_BASE = 0x3D660
ASCII_MAP = 0x42B5B

# ---------------------------------------------------------------------------
# Helpers.
# ---------------------------------------------------------------------------
def rle_encode(vals):
    out = bytearray()
    i = 0
    while i < len(vals):
        v = vals[i]
        j = i + 1
        while j < len(vals) and vals[j] == v and j - i < 256:
            j += 1
        L = j - i
        if L >= 3 or v == 0xFF:
            out += bytes([0xFF, L - 1, v])
        else:
            out += bytes([v]) * L
        i = j
    return bytes(out)

def glyph_from_tile(img, tx, ty):
    pix = img.load()
    out = []
    for y in range(8):
        b = 0
        for x in range(8):
            px = tx * 8 + x
            py = ty * 8 + y
            if px < img.width and py < img.height:
                r, g, bl, a = pix[px, py]
                on = a > 0 and (r + g + bl) >= 384
            else:
                on = False
            b = (b << 1) | (1 if on else 0)
        out.append(b)
    return bytes(out)

def rle_decode(data, n=1024):
    out = []
    i = 0
    while i < len(data) and len(out) < n:
        b = data[i]
        i += 1
        if b == 0xFF:
            count = data[i] + 1
            val = data[i + 1]
            i += 2
            out += [val] * count
        else:
            out.append(b)
    return out

# Existing password encoding from v01.
enc = {' ': 0x20}
for i in range(10):
    enc[str(i)] = 0x30 + i
for i, ch in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    enc[ch] = 0x41 + i
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    enc[ch] = 0xA1 + i
enc['b'] = 0x5B
enc['c'] = 0x5D
enc['p'] = 0x5E
enc.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

# ---------------------------------------------------------------------------
# 1) Convert user's options PNG into 5x6 custom 8x8 tiles.
# ---------------------------------------------------------------------------
assert USER_OPTIONS.exists(), USER_OPTIONS
opt_img_full = Image.open(USER_OPTIONS).convert('RGBA')
assert opt_img_full.size == (44, 55), opt_img_full.size
OPTIONS_COPY.parent.mkdir(parents=True, exist_ok=True)
opt_img_full.save(OPTIONS_COPY)
# Crop only the visible white-letter bbox. The original image contains padding;
# preserving the padding would waste tiles and make placement less precise.
bbox = opt_img_full.getbbox()
# getbbox on RGBA includes black opaque background, so compute white bbox.
pix = opt_img_full.load()
xs = []
ys = []
for y in range(opt_img_full.height):
    for x in range(opt_img_full.width):
        r, g, b, a = pix[x, y]
        if a > 0 and (r + g + b) >= 384:
            xs.append(x)
            ys.append(y)
white_bbox = (min(xs), min(ys), max(xs) + 1, max(ys) + 1)
# Expected: x 4..38, y 5..49 -> 35x45.
opt_crop = opt_img_full.crop(white_bbox)
TILES_W = 5
TILES_H = 6
opt_tiles_img = Image.new('RGBA', (TILES_W * 8, TILES_H * 8), (0, 0, 0, 0))
opt_tiles_img.paste(opt_crop, (0, 0))
option_tile_count = TILES_W * TILES_H
custom_gid_start = 0xE0
custom_src_start = 0x66
custom_gids = [custom_gid_start + i for i in range(option_tile_count)]
custom_sources = [custom_src_start + i for i in range(option_tile_count)]
assert custom_gids[-1] <= 0xFD
assert custom_sources[-1] == 0x83
for i, gid in enumerate(custom_gids):
    tx = i % TILES_W
    ty = i // TILES_W
    rom[FONT_BASE + gid * 8:FONT_BASE + gid * 8 + 8] = glyph_from_tile(opt_tiles_img, tx, ty)

# Reference image of tile slicing.
ref = Image.new('RGB', (TILES_W * 8 * 8, TILES_H * 8 * 8), (0, 0, 0))
dref = ImageDraw.Draw(ref)
for ty in range(TILES_H):
    for tx in range(TILES_W):
        tile = opt_tiles_img.crop((tx * 8, ty * 8, tx * 8 + 8, ty * 8 + 8)).convert('RGB')
        tile = tile.resize((64, 64), Image.Resampling.NEAREST)
        ref.paste(tile, (tx * 64, ty * 64))
        dref.rectangle([tx * 64, ty * 64, tx * 64 + 63, ty * 64 + 63], outline=(80, 80, 80))
        dref.text((tx * 64 + 2, ty * 64 + 2), f'{custom_gids[ty*TILES_W+tx]:02X}', fill=(255, 0, 0))
ref.save(OPTIONS_TILES_REF)

# ---------------------------------------------------------------------------
# 2) Extend AAB4 ASCII-map path for custom option graphic tiles.
# ---------------------------------------------------------------------------
# Original AAB4 ASCII path supports source $30..$65 with table at $AB5B.
# Relocate an extended table to free FF area in bank21 CPU $BF9B.
ascii_ext_cpu = 0xBF9B
ascii_ext_off = 0x42000 + (ascii_ext_cpu - 0xA000)
ascii_len = (custom_sources[-1] + 1) - 0x30  # support $30..$83
assert ascii_len == 0x54
assert orig[ascii_ext_off:ascii_ext_off + ascii_len] == bytes([0xFF]) * ascii_len
new_ascii = bytearray([0] * ascii_len)
cur_ascii = rom[ASCII_MAP:ASCII_MAP + 0x36]
new_ascii[:len(cur_ascii)] = cur_ascii
for src, gid in zip(custom_sources, custom_gids):
    new_ascii[src - 0x30] = gid
rom[ascii_ext_off:ascii_ext_off + ascii_len] = new_ascii
# Patch AAB4's CMP immediate and table operand.
rom[0x42B1F] = ascii_len
rom[0x42B24] = ascii_ext_cpu & 0xFF
rom[0x42B25] = ascii_ext_cpu >> 8

# ---------------------------------------------------------------------------
# 3) Runtime password alphabet table, extended with option image tile sources.
# ---------------------------------------------------------------------------
visual_rows = [
    ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'a', 'b', 'c', 'd', 'e', 'f', 'g'],
    ['H', 'I', 'J', 'K', 'L', 'M', 'N', 'h', 'i', 'j', 'k', 'l', 'm', 'n'],
    ['Ñ', 'O', 'P', 'Q', 'R', 'S', 'T', 'ñ', 'o', 'p', 'q', 'r', 's', 't'],
    ['U', 'V', 'W', 'X', 'Y', 'Z', None, 'u', 'v', 'w', 'x', 'y', 'z', None],
    [None, None, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', None, None],
]
symbols = [ch for row in visual_rows for ch in row if ch is not None]
assert len(symbols) == 64
source = bytes([enc[ch] for ch in symbols])
new_off = 0x1BBB9
new_cpu = 0xDBB9
DOT_SOURCE = 0x60
SLASH_SOURCE = 0x61
DOT_PATTERN_ID = 0x41
SLASH_PATTERN_ID = 0x42
option_pattern_start = 0x43
table = bytes([0x01]) + source + bytes([DOT_SOURCE, SLASH_SOURCE]) + bytes(custom_sources) + bytes([0xFF])
assert len(table) == 98
# Clear the old v01 runtime/selection free area before rewriting.
rom[0x1BBB9:0x1BD00] = bytes([0xFF]) * (0x1BD00 - 0x1BBB9)
rom[new_off:new_off + len(table)] = table
rom[0x1A85E] = new_cpu & 0xFF
rom[0x1A862] = new_cpu >> 8

# Buffer renderer patches retained/ensured.
rom[0x1AB98] = 0x41  # avoid kana dakuten route for values 1..64
rom[0x1AB87] = SLASH_PATTERN_ID
rom[0x1AB8C] = DOT_PATTERN_ID

# ---------------------------------------------------------------------------
# 4) Rebuild password tilemap: accepted grid + buffer slashes + option graphic.
# ---------------------------------------------------------------------------
tile_cols = [2, 4, 6, 8, 10, 12, 14, 17, 19, 21, 23, 25, 27, 29]
tile_rows = [7, 9, 11, 13, 17]

tm = [[0x100 for _ in range(32)] for __ in range(32)]
value = 1
values_grid = []
for rr, row in enumerate(visual_rows):
    row_values = []
    for cc, ch in enumerate(row):
        if ch is None:
            row_values.append(0)
            continue
        tm[tile_rows[rr]][tile_cols[cc]] = 0x100 + value
        row_values.append(value)
        value += 1
    values_grid.extend(row_values)
assert value == 65
assert len(values_grid) == 70

# Static slash separators in the input buffer.
STATIC_SLASH_CELLS = [(20, 13), (20, 18), (22, 13), (22, 18), (24, 13)]
for sr, sc in STATIC_SLASH_CELLS:
    tm[sr][sc] = 0x100 + SLASH_PATTERN_ID

# User option graphic: place below the numbers, with its top aligned with the
# password input box top in the current screen composition.
option_tile_col = 26  # visible left x ≈ 208 after crop
option_tile_row = 19  # visible top y ≈ 152
for ty in range(TILES_H):
    for tx in range(TILES_W):
        pid = option_pattern_start + ty * TILES_W + tx
        # Empty graphic tiles can remain blank to avoid unnecessary pixels.
        data = rom[FONT_BASE + custom_gids[ty*TILES_W+tx] * 8:FONT_BASE + custom_gids[ty*TILES_W+tx] * 8 + 8]
        if any(data):
            tm[option_tile_row + ty][option_tile_col + tx] = 0x100 + pid

low = []
high = []
for r in range(32):
    for c in range(32):
        w = tm[r][c]
        low.append(w & 0xFF)
        high.append(((w >> 8) - 1) & 0xFF)
low_stream = rle_encode(low)
high_stream = rle_encode(high)
low_region_len = 0x1E290 - 0x1E18C
high_region_len = 0x1E29C - 0x1E290
assert len(low_stream) <= low_region_len, (len(low_stream), low_region_len)
assert len(high_stream) <= high_region_len, (len(high_stream), high_region_len)
rom[0x1E18C:0x1E290] = low_stream + bytes([0xFF]) * (low_region_len - len(low_stream))
rom[0x1E290:0x1E29C] = high_stream + bytes([0xFF]) * (high_region_len - len(high_stream))

# ---------------------------------------------------------------------------
# 5) Cursor/selection logic: grid rows 0..4 + option rows 5..9.
# ---------------------------------------------------------------------------
sel_base_off = 0x1BD00
sel_base_cpu = 0xDD00
row_offsets_cpu = sel_base_cpu
x_table_cpu = row_offsets_cpu + 10
# 14 grid x entries + 1 special option x entry.
y_table_cpu = x_table_cpu + 15
values_cpu = y_table_cpu + 10
row_offsets = [i * 14 for i in range(10)]
x_table_grid = [(c * 8) - 8 for c in tile_cols]
option_cursor_x = 200
x_table = x_table_grid + [option_cursor_x]
# Grid y entries from accepted v01; option y entries follow each word in the image.
option_word_tops = [option_tile_row * 8 + off for off in (0, 8, 20, 30, 40)]
option_cursor_y = [y + 2 for y in option_word_tops]  # user noted the previous pointer was slightly high
# Keep accepted grid y positions based on tile rows.
y_table = [r * 8 for r in tile_rows] + option_cursor_y
assert len(x_table) == 15
assert len(y_table) == 10
values = list(values_grid)
option_values = [0xF0, 0xF1, 0xF2, 0xF3, 0xF4]
for opt_val in option_values:
    row = [0] * 14
    # reachable from digit 9 below/above; negative cursor branch uses fixed x.
    row[11] = opt_val
    row[12] = opt_val
    values.extend(row)
assert len(values) == 140
sel_blob = bytes(row_offsets) + bytes(x_table) + bytes(y_table) + bytes(values)
assert len(sel_blob) == 175
assert orig[sel_base_off:sel_base_off + len(sel_blob)] == bytes([0xFF]) * len(sel_blob)
rom[sel_base_off:sel_base_off + len(sel_blob)] = sel_blob

# Patch absolute operand addresses:
#   C955: LDA row_offsets,Y
#   C961: LDX x_table,Y
#   C967: LDA y_table,Y
#   CC5D: LDA values,X
addr_patches = {
    0x1AC56: row_offsets_cpu,
    0x1A962: x_table_cpu,
    0x1A968: y_table_cpu,
    0x1AC5E: values_cpu,
}
for off, addr in addr_patches.items():
    rom[off] = addr & 0xFF
    rom[off + 1] = addr >> 8

# Cursor x for negative option values: use extra x_table entry 14, instead of
# $3C91 OR #$01. This avoids using grid columns and lets us align the pointer.
# C956..C95D original: LDA $3C91 / ORA #$01 / TAY / BRA $C961
rom[0x1A956:0x1A95E] = bytes([0xA0, 0x0E, 0x80, 0x07, 0xEA, 0xEA, 0xEA, 0xEA])

# Navigation bounds: rows 0..9, columns 0..13.
rom[0x1AA56] = 0x09  # row wrap up
rom[0x1AA6A] = 0x0A  # row max exclusive
rom[0x1AA80] = 0x0E  # col max exclusive
rom[0x1AA95] = 0x0D  # col wrap left
# Horizontal directions corrected for ascending X table.
rom[0x1AA47] = 0x2E  # right -> increment
rom[0x1AA4B] = 0x40  # left -> decrement

# ---------------------------------------------------------------------------
# Output ROM + cumulative IPS against original clean ROM.
# ---------------------------------------------------------------------------
OUT.parent.mkdir(parents=True, exist_ok=True)
IPS.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
PREVIEW.parent.mkdir(parents=True, exist_ok=True)
OUT.write_bytes(rom)
new = bytes(rom)
records = []
i = 0
while i < len(orig):
    if orig[i] == new[i]:
        i += 1
        continue
    s = i
    buf = bytearray()
    while i < len(orig) and orig[i] != new[i] and len(buf) < 0xFFFF:
        buf.append(new[i])
        i += 1
    records.append((s, bytes(buf)))
ips = bytearray(b'PATCH')
for off, buf in records:
    ips += off.to_bytes(3, 'big') + len(buf).to_bytes(2, 'big') + buf
ips += b'EOF'
IPS.write_bytes(ips)

# ---------------------------------------------------------------------------
# Actual tilemap preview using generated patterns.
# ---------------------------------------------------------------------------
# Build pattern-id -> glyph bytes by simulating C844/AAB4 enough for this table.
ascii_ext = rom[ascii_ext_off:ascii_ext_off + ascii_len]
def source_to_gid(c):
    if c in (0x20, 0xA0):
        return 0
    if 0xA1 <= c <= 0xDF:
        return c
    if 0x30 <= c < 0x30 + len(ascii_ext):
        return ascii_ext[c - 0x30]
    if c == 0x21:
        return 0x9E
    if c == 0x3F:
        return 0x9D
    if c == 0x24:
        return 0x3E
    return 0
runtime = rom[new_off:rom.index(0xFF, new_off) + 1]
patterns = {0: bytes(8)}
pid = 1
for b in runtime[:-1]:
    if b in (0x01, 0x02, 0x5C):
        continue
    gid = source_to_gid(b)
    patterns[pid] = rom[FONT_BASE + gid * 8:FONT_BASE + gid * 8 + 8]
    pid += 1
low_dec = rle_decode(rom[0x1E18C:0x1E290])
img = Image.new('RGB', (256, 240), (33, 36, 255))
for r in range(32):
    for c in range(32):
        ptn = low_dec[r * 32 + c]
        if not ptn:
            continue
        bs = patterns.get(ptn, bytes(8))
        for y, b in enumerate(bs):
            for x in range(8):
                if (b >> (7 - x)) & 1:
                    xx = c * 8 + x
                    yy = r * 8 + y
                    if 0 <= xx < 256 and 0 <= yy < 240:
                        img.putpixel((xx, yy), (255, 255, 255))
# show the fixed option cursor anchors in red, only for preview.
d = ImageDraw.Draw(img)
for yy in option_cursor_y:
    d.polygon([(option_cursor_x, yy + 2), (option_cursor_x, yy + 6), (option_cursor_x + 5, yy + 4)], fill=(255, 50, 50))
img.resize((512, 480), Image.Resampling.NEAREST).save(PREVIEW)

layout_text = '\n'.join(' '.join(ch if ch is not None else '·' for ch in row) for row in visual_rows)
REPORT.write_text(f'''# Prueba v02 — opciones de password como gráfico

ROM de prueba:

`Roms/Pruebas/{OUT.name}`

IPS de prueba acumulativo contra ROM limpia:

`Parches/Pruebas/{IPS.name}`

Preview real de tilemap:

`images/{PREVIEW.name}`

Gráfico fuente de opciones copiado:

`font_edit/{OPTIONS_COPY.name}`

Referencia de tiles:

`font_edit/{OPTIONS_TILES_REF.name}`

## Cambios respecto al test mini-fuente

- Se descarta la mini-fuente 3x5.
- Las opciones se insertan como gráfico a partir de `IMG_4537.PNG`, usando la letra ajustada por el usuario.
- La columna baja hasta la zona del recuadro de inserción.
- La parte superior visible de `ADELANTE` queda aproximadamente en `y={option_tile_row*8}`.
- El cursor de opciones ya no usa las X de la parrilla: se añade una X especial `x={option_cursor_x}`.
- El cursor de opciones se baja 2 px respecto al top de cada palabra.

## Parrilla preservada

```text
{layout_text}
```

## Opciones

```text
ADELANTE = $F0
ATRÁS    = $F1
ESPACIO  = $F2
BORRAR   = $F3
FIN      = $F4
```

## Validación estática

- Imagen fuente opciones: `{opt_img_full.size[0]}x{opt_img_full.size[1]}` px, dos colores.
- BBox blanca usada: `{white_bbox}` -> crop `{opt_crop.size[0]}x{opt_crop.size[1]}`.
- Tiles de opciones: `{TILES_W}x{TILES_H}` = `{option_tile_count}`.
- Glyph IDs opciones: `$E0..${custom_gids[-1]:02X}`.
- Source bytes opciones: `$66..${custom_sources[-1]:02X}`.
- Tabla ASCII extendida: `{ascii_len}` bytes en `0x{ascii_ext_off:05X}` / CPU `${ascii_ext_cpu:04X}`.
- Runtime table: `{len(table)}` bytes en `0x{new_off:05X}`, termina en `0x{new_off + len(table):05X}`.
- Selection table: `{len(sel_blob)}` bytes en `0x{sel_base_off:05X}` / CPU `${sel_base_cpu:04X}`.
- Low stream RLE: `{len(low_stream)}` / `{low_region_len}` bytes.
- High stream RLE: `{len(high_stream)}` / `{high_region_len}` bytes.
- Values table: `{len(values)}` bytes.

## Qué comprobar

1. Que las opciones se ven con la fuente del PNG enviado.
2. Que la columna está más baja y no invade visualmente la parrilla.
3. Que el puntero queda a la izquierda de la palabra, no encima de letras.
4. Que el puntero queda alineado verticalmente con cada palabra.
5. Que ADELANTE / ATRÁS / ESPACIO / BORRAR / FIN siguen funcionando.
6. Que la parrilla aceptada y el buffer no se han roto.
''', encoding='utf-8')

print('OUT', OUT)
print('IPS', IPS)
print('REPORT', REPORT)
print('PREVIEW', PREVIEW)
print('OPTIONS_COPY', OPTIONS_COPY)
print('OPTIONS_TILES_REF', OPTIONS_TILES_REF)
print('white bbox', white_bbox, 'crop', opt_crop.size)
print('option tiles', TILES_W, TILES_H, option_tile_count)
print('ascii ext', hex(ascii_ext_off), ascii_len)
print('runtime table len', len(table), 'ends', hex(new_off + len(table)))
print('selection', hex(sel_base_off), len(sel_blob))
print('option cursor x/y', option_cursor_x, option_cursor_y)
print('low/high', len(low_stream), '/', low_region_len, len(high_stream), '/', high_region_len)
print('records', len(records), 'changed bytes', sum(len(b) for _, b in records))
