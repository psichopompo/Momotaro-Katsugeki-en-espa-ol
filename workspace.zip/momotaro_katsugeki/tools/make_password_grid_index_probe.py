#!/usr/bin/env python3
from pathlib import Path
ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - title_menu_es_current.pce'
if not BASE.exists(): BASE=ORIG
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - password_grid_index_probe.pce'
IPS=ROOT/'Parches/momotaro_password_grid_index_probe.ips'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())
FONT_BASE=0x3D660
# Choose 64 source bytes that should map to 64 unique glyph IDs in table mode 0.
# High bytes A1-DF via table0, skipping duplicate mappings AA/AB; add ASCII A/B/C.
source=[]
for b in range(0xA1,0xE0):
    if b in (0xAA,0xAB):
        continue
    source.append(b)
source += [0x41,0x42,0x43]
assert len(source)==64, len(source)
# Mapping source->glyph id approximated from known tables.
D=orig
src_to_gid={}
for b in range(0xA1,0xE0):
    src_to_gid[b]=D[0x41CF3+b-0xA0]
ascii_map=D[0x42B5B:0x42B5B+0x36]
for code in range(0x30,0x30+len(ascii_map)):
    if ascii_map[code-0x30]:
        src_to_gid[code]=ascii_map[code-0x30]
# Mini hex digits in 8x8 glyph.
HEX={
 '0':["111","101","101","101","111"], '1':["010","110","010","010","111"],
 '2':["111","001","111","100","111"], '3':["111","001","111","001","111"],
 '4':["101","101","111","001","001"], '5':["111","100","111","001","111"],
 '6':["111","100","111","101","111"], '7':["111","001","010","010","010"],
 '8':["111","101","111","101","111"], '9':["111","101","111","001","111"],
 'A':["111","101","111","101","101"], 'B':["110","101","110","101","110"],
 'C':["111","100","100","100","111"], 'D':["110","101","101","101","110"],
 'E':["111","100","110","100","111"], 'F':["111","100","110","100","100"],
}
def glyph_hex(n):
    s=f'{n:02X}'
    grid=[[0]*8 for _ in range(8)]
    for digit,ox in [(s[0],0),(s[1],4)]:
        pat=HEX[digit]
        for y,row in enumerate(pat, start=1):
            for x,ch in enumerate(row):
                if ch=='1': grid[y][ox+x]=1
    out=[]
    for row in grid:
        b=0
        for bit in row: b=(b<<1)|bit
        out.append(b)
    return bytes(out)
# Patch each glyph ID to show the source-table index 00..3F.
used={}
for idx,b in enumerate(source):
    gid=src_to_gid[b]
    if gid in used:
        raise SystemExit(f'duplicate glyph {gid:02X} for source {b:02X} and {used[gid]:02X}')
    used[gid]=b
    rom[FONT_BASE+gid*8:FONT_BASE+gid*8+8]=glyph_hex(idx)
# Relocate table to free space.
new_off=0x1BBB9
new_cpu=0xDBB9
table=bytes([0x01])+bytes(source)+bytes([0xFF])
rom[new_off:new_off+len(table)]=table
rom[0x1A85E]=new_cpu&0xFF
rom[0x1A862]=new_cpu>>8
OUT.write_bytes(rom)
# IPS
new=bytes(rom); rec=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xffff:
        buf.append(new[i]); i+=1
    rec.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in rec: ips+=off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips+=b'EOF'; IPS.write_bytes(ips)
# Save mapping report as TSV too.
map_path=ROOT/'reports/password_grid_index_probe_mapping.tsv'
with map_path.open('w',encoding='utf-8') as f:
    f.write('index_hex\tsource_byte\tglyph_id\n')
    for idx,b in enumerate(source):
        f.write(f'{idx:02X}\t{b:02X}\t{src_to_gid[b]:02X}\n')
(ROOT/'reports/test_password_grid_index_probe.md').write_text(f'''# Password grid index probe\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nMapping: `reports/{map_path.name}`\n\n## Objetivo\n\nDeterminar el orden exacto en que la rutina de password coloca los 64 símbolos de su tabla runtime.\n\n## Método\n\n1. Se relocaliza la tabla runtime a `0x{new_off:05X}` / CPU `${new_cpu:04X}`.\n2. La tabla contiene `<01>` + 64 source bytes + `<FF>`.\n3. Cada source byte se eligió para mapear a un glyph ID único.\n4. Cada glyph ID se reemplaza por el número hexadecimal del índice de tabla (`00`-`3F`).\n\n## Resultado esperado\n\nLa parrilla mostrará números hex `00..3F`. Con una captura podremos leer qué índice de tabla cae en cada posición visual.\n\nEsto nos permitirá construir una tabla final ordenada para que visualmente aparezca:\n\n```text\nABCDEFGH\nIJKLMNÑO\nPQRSTUVW\nXYZabcde\nfghijklm\nnñopqrst\nuvwxyz01\n23456789\n```\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in rec)}\n''',encoding='utf-8')
print('OUT',OUT)
print('source',bytes(source).hex())
print('records',len(rec),sum(len(b) for _,b in rec))
