#!/usr/bin/env python3
from __future__ import annotations
import ctypes as C
from pathlib import Path

# Minimal libretro frontend for beetle-pce-fast-libretro instrumentation.
RETRO_ENVIRONMENT_SET_PIXEL_FORMAT = 10
RETRO_ENVIRONMENT_GET_CAN_DUPE = 3
RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS = 11
RETRO_ENVIRONMENT_SET_VARIABLES = 16
RETRO_ENVIRONMENT_GET_VARIABLE = 15
RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME = 18
RETRO_ENVIRONMENT_SET_CONTROLLER_INFO = 35
RETRO_ENVIRONMENT_SET_GEOMETRY = 37
RETRO_ENVIRONMENT_GET_LOG_INTERFACE = 27
RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY = 9
RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY = 31
RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION = 52
RETRO_ENVIRONMENT_SET_CORE_OPTIONS = 53
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL = 54
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2 = 67
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL = 68
RETRO_ENVIRONMENT_GET_RUMBLE_INTERFACE = 23
RETRO_PIXEL_FORMAT_RGB565 = 2
RETRO_DEVICE_JOYPAD = 1

class RetroGameInfo(C.Structure):
    _fields_ = [
        ("path", C.c_char_p),
        ("data", C.c_void_p),
        ("size", C.c_size_t),
        ("meta", C.c_char_p),
    ]

class RetroSystemInfo(C.Structure):
    _fields_ = [
        ("library_name", C.c_char_p),
        ("library_version", C.c_char_p),
        ("valid_extensions", C.c_char_p),
        ("need_fullpath", C.c_bool),
        ("block_extract", C.c_bool),
    ]

class RetroSystemAVInfo(C.Structure):
    pass

class Geometry(C.Structure):
    _fields_ = [("base_width", C.c_uint), ("base_height", C.c_uint), ("max_width", C.c_uint), ("max_height", C.c_uint), ("aspect_ratio", C.c_float)]
class Timing(C.Structure):
    _fields_ = [("fps", C.c_double), ("sample_rate", C.c_double)]
RetroSystemAVInfo._fields_ = [("geometry", Geometry), ("timing", Timing)]

ENV_CB = C.CFUNCTYPE(C.c_bool, C.c_uint, C.c_void_p)
VIDEO_CB = C.CFUNCTYPE(None, C.c_void_p, C.c_uint, C.c_uint, C.c_size_t)
AUDIO_CB = C.CFUNCTYPE(None, C.c_int16, C.c_int16)
AUDIO_BATCH_CB = C.CFUNCTYPE(C.c_size_t, C.POINTER(C.c_int16), C.c_size_t)
INPUT_POLL_CB = C.CFUNCTYPE(None)
INPUT_STATE_CB = C.CFUNCTYPE(C.c_int16, C.c_uint, C.c_uint, C.c_uint, C.c_uint)

class Runner:
    def __init__(self, rom_path: str | Path, out_dir: str | Path | None = None, core_path: str | Path = "/home/user/emutools/beetle-pce-fast-libretro/mednafen_pce_fast_libretro.so"):
        self.rom_path = Path(rom_path).resolve()
        self.out_dir = Path(out_dir) if out_dir else None
        if self.out_dir: self.out_dir.mkdir(parents=True, exist_ok=True)
        self.core = C.CDLL(str(core_path))
        self.buttons: set[int] = set()
        self.frame = 0
        self.last_frame = None
        self.last_w = 0; self.last_h = 0; self.last_pitch = 0
        self._keepalive = []
        self._setup_api()
        self._setup_callbacks()
        self.core.retro_init()
        info = RetroSystemInfo(); self.core.retro_get_system_info(C.byref(info))
        self.system_info = info
        # Load by full path; core advertises need_fullpath.
        game = RetroGameInfo(str(self.rom_path).encode(), None, 0, None)
        ok = self.core.retro_load_game(C.byref(game))
        if not ok:
            raise RuntimeError(f"retro_load_game failed for {self.rom_path}")
        av = RetroSystemAVInfo(); self.core.retro_get_system_av_info(C.byref(av)); self.av = av

    def _setup_api(self):
        c=self.core
        c.retro_set_environment.argtypes=[ENV_CB]
        c.retro_set_video_refresh.argtypes=[VIDEO_CB]
        c.retro_set_audio_sample.argtypes=[AUDIO_CB]
        c.retro_set_audio_sample_batch.argtypes=[AUDIO_BATCH_CB]
        c.retro_set_input_poll.argtypes=[INPUT_POLL_CB]
        c.retro_set_input_state.argtypes=[INPUT_STATE_CB]
        c.retro_get_system_info.argtypes=[C.POINTER(RetroSystemInfo)]
        c.retro_get_system_av_info.argtypes=[C.POINTER(RetroSystemAVInfo)]
        c.retro_load_game.argtypes=[C.POINTER(RetroGameInfo)]; c.retro_load_game.restype=C.c_bool
        c.retro_run.argtypes=[]
        # instrumentation exports
        c.arena_vramlog_set_enabled.argtypes=[C.c_int]
        c.arena_vramlog_set_frame.argtypes=[C.c_uint]
        c.arena_vramlog_set_range.argtypes=[C.c_uint,C.c_uint]
        c.arena_vramlog_reset.argtypes=[]
        c.arena_vramlog_count_get.restype=C.c_uint
        c.arena_vramlog_ptr.restype=C.c_void_p
        c.arena_pce_get_vram.restype=C.POINTER(C.c_uint16)
        c.arena_pce_get_sat.restype=C.POINTER(C.c_uint16)
        c.arena_pce_get_satb.restype=C.c_uint16
        c.arena_pce_get_mpr_ptr.restype=C.POINTER(C.c_uint8)
        c.arena_pce_get_pc.restype=C.c_uint
        c.arena_jsrlog_set_enabled.argtypes=[C.c_int]
        c.arena_jsrlog_set_frame.argtypes=[C.c_uint]
        c.arena_jsrlog_set_target.argtypes=[C.c_uint]
        c.arena_jsrlog_reset.argtypes=[]
        c.arena_jsrlog_count_get.restype=C.c_uint
        c.arena_jsrlog_ptr.restype=C.c_void_p

    def _setup_callbacks(self):
        # Need stable storage for returned strings/vars.
        self._pixel_format = C.c_uint(RETRO_PIXEL_FORMAT_RGB565)
        self._can_dupe = C.c_bool(True)
        self._sysdir = C.c_char_p(str((self.out_dir or Path('/tmp')).resolve()).encode())
        self._savedir = self._sysdir

        def environ(cmd, data):
            if cmd == RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
                # core asks for RGB565/XRGB8888 etc.; accept.
                return True
            if cmd == RETRO_ENVIRONMENT_GET_CAN_DUPE:
                C.cast(data, C.POINTER(C.c_bool))[0] = True; return True
            if cmd in (RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY, RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY):
                C.cast(data, C.POINTER(C.c_char_p))[0] = self._sysdir.value; return True
            if cmd == RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
                C.cast(data, C.POINTER(C.c_uint))[0] = 2; return True
            if cmd == RETRO_ENVIRONMENT_GET_VARIABLE:
                return False
            # Accept setters by default.
            if cmd in (RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS, RETRO_ENVIRONMENT_SET_VARIABLES, RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME, RETRO_ENVIRONMENT_SET_CONTROLLER_INFO, RETRO_ENVIRONMENT_SET_GEOMETRY, RETRO_ENVIRONMENT_SET_CORE_OPTIONS, RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL, RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2, RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL):
                return True
            return False

        def video(data, w, h, pitch):
            self.last_w=int(w); self.last_h=int(h); self.last_pitch=int(pitch)
            if data:
                # RGB565 copy
                size = int(pitch)*int(h)
                self.last_frame = C.string_at(data, size)

        def audio(l, r):
            return None
        def audio_batch(data, frames):
            return frames
        def input_poll():
            return None
        def input_state(port, device, index, id):
            if port == 0 and device == RETRO_DEVICE_JOYPAD and int(id) in self.buttons:
                return 1
            return 0
        self._env_cb=ENV_CB(environ); self._video_cb=VIDEO_CB(video); self._audio_cb=AUDIO_CB(audio); self._audio_batch_cb=AUDIO_BATCH_CB(audio_batch); self._poll_cb=INPUT_POLL_CB(input_poll); self._state_cb=INPUT_STATE_CB(input_state)
        self._keepalive=[self._env_cb,self._video_cb,self._audio_cb,self._audio_batch_cb,self._poll_cb,self._state_cb]
        self.core.retro_set_environment(self._env_cb)
        self.core.retro_set_video_refresh(self._video_cb)
        self.core.retro_set_audio_sample(self._audio_cb)
        self.core.retro_set_audio_sample_batch(self._audio_batch_cb)
        self.core.retro_set_input_poll(self._poll_cb)
        self.core.retro_set_input_state(self._state_cb)

    def run(self, frames:int, events:dict[int, list[int]]|None=None, log_range:tuple[int,int]|None=None):
        events = events or {}
        if log_range:
            self.core.arena_vramlog_set_range(log_range[0], log_range[1])
            self.core.arena_vramlog_reset(); self.core.arena_vramlog_set_enabled(1)
        for _ in range(frames):
            if self.frame in events:
                self.buttons = set(events[self.frame])
            self.core.arena_vramlog_set_frame(self.frame)
            self.core.arena_jsrlog_set_frame(self.frame)
            self.core.retro_run()
            self.frame += 1
        if log_range:
            self.core.arena_vramlog_set_enabled(0)

    def vram_words(self):
        ptr=self.core.arena_pce_get_vram()
        return [ptr[i] for i in range(65536)]
    def sat_words(self):
        ptr=self.core.arena_pce_get_sat(); return [ptr[i] for i in range(256)]
    def mpr(self):
        ptr=self.core.arena_pce_get_mpr_ptr(); return [ptr[i] for i in range(8)]
    def pc(self): return int(self.core.arena_pce_get_pc())
    def vramlog(self):
        cnt=int(self.core.arena_vramlog_count_get())
        ptr=self.core.arena_vramlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*7))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*7+j]) for j in range(7)))
        return out
    def jsrlog(self):
        cnt=int(self.core.arena_jsrlog_count_get())
        ptr=self.core.arena_jsrlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*5))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*5+j]) for j in range(5)))
        return out

    def close(self):
        try: self.core.retro_unload_game(); self.core.retro_deinit()
        except Exception: pass

if __name__ == '__main__':
    import sys
    r=Runner(sys.argv[1], '/tmp/pce_runner_test')
    r.run(10)
    print('ok', r.last_w, r.last_h, r.mpr(), hex(r.pc()))
    r.close()
