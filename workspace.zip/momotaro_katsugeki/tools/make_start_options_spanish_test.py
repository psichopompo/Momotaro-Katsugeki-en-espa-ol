#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw
import shutil

ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce'
OUT=ROOT/'Roms/Momotarou Katsugeki (Japan) - start_options_spanish_test.pce'
IPS=ROOT/'Parches/momotaro_start_options_spanish_test.ips'
PREVIEW=ROOT/'images/start_options_spanish_preview.png'
REPORT=ROOT/'reports/test_empezar_continuar_metasprite.md'
orig=ORIG.read_bytes(); rom=bytearray(BASE.read_bytes())

# 5x7-ish font, drawn in a 6 px cell (5 px + 1 space). Values are binary; shadow added separately.
FONT={
 'A':["01110","10001","10001","11111","10001","10001","10001"],
 'B':["11110","10001","10001","11110","10001","10001","11110"],
 'C':["01111","10000","10000","10000","10000","10000","01111"],
 'D':["11110","10001","10001","10001","10001","10001","11110"],
 'E':["11111","10000","10000","11110","10000","10000","11111"],
 'F':["11111","10000","10000","11110","10000","10000","10000"],
 'G':["01111","10000","10000","10011","10001","10001","01111"],
 'H':["10001","10001","10001","11111","10001","10001","10001"],
 'I':["11111","00100","00100","00100","00100","00100","11111"],
 'J':["00111","00010","00010","00010","00010","10010","01100"],
 'L':["10000","10000","10000","10000","10000","10000","11111"],
 'M':["10001","11011","10101","10101","10001","10001","10001"],
 'N':["10001","11001","10101","10011","10001","10001","10001"],
 'O':["01110","10001","10001","10001","10001","10001","01110"],
 'P':["11110","10001","10001","11110","10000","10000","10000"],
 'R':["11110","10001","10001","11110","10100","10010","10001"],
 'S':["01111","10000","10000","01110","00001","00001","11110"],
 'T':["11111","00100","00100","00100","00100","00100","00100"],
 'U':["10001","10001","10001","10001","10001","10001","01110"],
 'V':["10001","10001","10001","10001","01010","01010","00100"],
 'Z':["11111","00001","00010","00100","01000","10000","11111"],
 ' ': ["00000"]*7,
}

def draw_word(img, word, x, y, fill=1, shadow=2):
    pix=img.load()
    cx=x
    for ch in word:
        pat=FONT[ch]
        # shadow first, one pixel down-right
        for yy,row in enumerate(pat):
            for xx,b in enumerate(row):
                if b=='1':
                    sx=cx+xx+1; sy=y+yy+1
                    if 0<=sx<img.width and 0<=sy<img.height and pix[sx,sy]==0:
                        pix[sx,sy]=shadow
        for yy,row in enumerate(pat):
            for xx,b in enumerate(row):
                if b=='1':
                    px=cx+xx; py=y+yy
                    if 0<=px<img.width and 0<=py<img.height:
                        pix[px,py]=fill
        cx+=6

def encode_tile_4bpp(pix8):
    # pix8[y][x] 0..15 -> PCE 4bpp tile 32 bytes, planes 0/1 interleaved then 2/3.
    out1=[]; out2=[]
    for y in range(8):
        b=[0,0,0,0]
        for x in range(8):
            c=pix8[y][x]; bit=7-x
            for p in range(4): b[p] |= ((c>>p)&1)<<bit
        out1.extend([b[0],b[1]]); out2.extend([b[2],b[3]])
    return bytes(out1+out2)

def encode_chunk_16(img, x0):
    # Four tiles TL,TR,BL,BR.
    data=bytearray()
    for ty,tx in [(0,0),(0,8),(8,0),(8,8)]:
        pix=[]
        for y in range(8):
            row=[]
            for x in range(8):
                row.append(img.getpixel((x0+tx+x,ty+y)))
            pix.append(row)
        data += encode_tile_4bpp(pix)
    return bytes(data)

def compress_sprite(raw128):
    # Inverse of F1B9/861F format for one 16x16 chunk.
    out=bytearray()
    for base in [0,0x20,0x40,0x60]:
        for y0 in [0,1,0x10,0x11]:
            vals=[raw128[base+y0+i*2] for i in range(8)]
            mask=0; payload=[]; prev=0
            for i,v in enumerate(vals):
                bit=7-i
                if i==0:
                    if v!=0:
                        mask |= 1<<bit; payload.append(v)
                else:
                    if v!=prev:
                        mask |= 1<<bit; payload.append(v)
                prev=v
            out.append(mask); out += bytes(payload)
    return bytes(out)

# Canvas of 4 sprite objects * 32 px = 128x16. First 64 = EMPEZAR, second 64 = CONTINUAR.
canvas=Image.new('P',(128,16),0)
# EMPEZAR width 7*6-1=41, centered in 64 => x 11
# CONTINUAR width 9*6-1=53, centered in second 64 => x 64+5
# Put y=4 so 7px glyph + shadow fits rows 4..11.
draw_word(canvas,'EMPEZAR',11,4,fill=1,shadow=0)
draw_word(canvas,'CONTINUAR',69,4,fill=1,shadow=0)
chunks=[encode_chunk_16(canvas,x) for x in range(0,128,16)]
stream=bytearray([len(chunks)])
for ch in chunks:
    stream += compress_sprite(ch)
# Original stream at 0x272DE had length 0x273F9-0x272DE=283. Our stream should fit.
old_stream_start=0x272DE; old_stream_end=0x273F9
if len(stream)>old_stream_end-old_stream_start:
    raise SystemExit(f'stream too large {len(stream)} > {old_stream_end-old_stream_start}')
rom[old_stream_start:old_stream_start+len(stream)]=stream
rom[old_stream_start+len(stream):old_stream_end]=bytes([0xFF])*(old_stream_end-old_stream_start-len(stream))

# New metasprite lists in free space at bank17 CPU $58B5+.
list1_cpu=0x58B5; list2_cpu=0x58B5+4*5+1
list1_off=0x17*0x2000+(list1_cpu-0x4000)
list2_off=0x17*0x2000+(list2_cpu-0x4000)
# Four 32x16 sprite objects. Use old attr style: selected=07, unselected=06; byte2 alternate 01/00 as before.
# Base screen x=128 y=200. Objects x: 64,96,128,160 => dx -64,-32,0,+32. y=184 => dy -16.
def rec(tile, attr, attr2, dx, dy):
    return bytes([tile, attr, attr2, dx & 0xFF, dy & 0xFF])
# state 0: EMPEZAR selected, CONTINUAR unselected
list1 = b''.join([
    rec(0x00,0x07,0x01,-64,-16),
    rec(0x02,0x07,0x00,-32,-16),
    rec(0x04,0x06,0x01,  0,-16),
    rec(0x06,0x06,0x00, 32,-16),
]) + b'\xFF'
# state 1: EMPEZAR unselected, CONTINUAR selected
list2 = b''.join([
    rec(0x00,0x06,0x01,-64,-16),
    rec(0x02,0x06,0x00,-32,-16),
    rec(0x04,0x07,0x01,  0,-16),
    rec(0x06,0x07,0x00, 32,-16),
]) + b'\xFF'
rom[list1_off:list1_off+len(list1)]=list1
rom[list2_off:list2_off+len(list2)]=list2
# Pointer table at ROM 0x2E6B1: B5 46 C5 46 -> new lists.
rom[0x2E6B1:0x2E6B5]=bytes([list1_cpu&0xff,list1_cpu>>8,list2_cpu&0xff,list2_cpu>>8])

OUT.write_bytes(rom)
# IPS vs original.
orig_bytes=orig; new=bytes(rom); records=[]; i=0
while i<len(orig_bytes):
    if orig_bytes[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig_bytes) and orig_bytes[i]!=new[i] and len(buf)<0xFFFF:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'; IPS.write_bytes(ips)

# Preview using tentative palette similar to screen.
pal=[(0,0,80),(255,109,33),(33,36,33),(255,255,0),(148,109,0)]
prev=Image.new('RGB',(128*4,16*4),(0,0,80))
for y in range(16):
    for x in range(128):
        c=canvas.getpixel((x,y))
        col=pal[c]
        for yy in range(4):
            for xx in range(4): prev.putpixel((x*4+xx,y*4+yy),col)
PREVIEW.parent.mkdir(parents=True,exist_ok=True); prev.save(PREVIEW)

REPORT.write_text(f'''# Test `EMPEZAR / CONTINUAR` como metasprites\n\nROM: `Roms/{OUT.name}`\n\nIPS: `Parches/{IPS.name}`\n\nVista previa del diseño gráfico: `images/{PREVIEW.name}`\n\n## Qué hace\n\n- Reemplaza el stream comprimido de los rótulos por 8 chunks de sprite nuevos.\n- Mueve las listas de metasprite a una zona libre del banco `$17` (`$58B5` y `$58CA`).\n- Actualiza la tabla de punteros de `0x2E6B1` para apuntar a esas listas nuevas.\n- Dibuja `EMPEZAR` y `CONTINUAR` con una fuente compacta 5x7 + sombra.\n\n## Importante\n\nEs una prueba técnica. En esta primera versión los rótulos se dibujan sin sombra para que el stream comprimido quepa en el espacio original. Todavía hay incertidumbre en bits de atributos/tamaño/paleta de los sprites. Si se ve mal, la captura nos dirá qué ajustar.\n\n## Stream gráfico\n\n- Offset original usado: `0x272DE-0x273F8`.\n- Longitud máxima original ocupada: `{old_stream_end-old_stream_start}` bytes.\n- Longitud nueva comprimida: `{len(stream)}` bytes.\n\n## Listas nuevas\n\n- Lista 1 CPU `$58B5`, ROM `0x{list1_off:05X}`.\n- Lista 2 CPU `$58CA`, ROM `0x{list2_off:05X}`.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')

print('stream len',len(stream),'max',old_stream_end-old_stream_start)
print('list1',hex(list1_off),list1.hex(' '))
print('list2',hex(list2_off),list2.hex(' '))
print('records',len(records),sum(len(b) for _,b in records))
print('OUT',OUT)
