#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import argparse, math

def decode_tile_4bpp_pce(tile):
    pix=[]
    for y in range(8):
        b0=tile[y*2]
        b1=tile[y*2+1]
        b2=tile[16+y*2]
        b3=tile[16+y*2+1]
        row=[]
        for x in range(8):
            bit=7-x
            c=((b0>>bit)&1)|(((b1>>bit)&1)<<1)|(((b2>>bit)&1)<<2)|(((b3>>bit)&1)<<3)
            row.append(c)
        pix.append(row)
    return pix

# Alternative layout observed in some planar dumps: all plane0 rows, plane1, plane2, plane3.
def decode_tile_4plane(tile):
    pix=[]
    for y in range(8):
        b0=tile[y]
        b1=tile[8+y]
        b2=tile[16+y]
        b3=tile[24+y]
        row=[]
        for x in range(8):
            bit=7-x
            c=((b0>>bit)&1)|(((b1>>bit)&1)<<1)|(((b2>>bit)&1)<<2)|(((b3>>bit)&1)<<3)
            row.append(c)
        pix.append(row)
    return pix

def make_tile_img(tile, mode='pce', scale=2):
    dec=decode_tile_4bpp_pce if mode=='pce' else decode_tile_4plane
    p=dec(tile)
    # high contrast palette: transparent/0 as white, then dark greys/colours
    pal=[(255,255,255),(0,0,0),(80,80,80),(150,150,150),(220,80,80),(80,160,80),(80,80,220),(200,160,0),(0,180,180),(180,0,180),(120,80,0),(0,120,80),(120,0,80),(80,0,120),(0,80,120),(40,40,40)]
    img=Image.new('RGB',(8,8),(255,255,255))
    px=img.load()
    for y,row in enumerate(p):
        for x,c in enumerate(row):
            px[x,y]=pal[c]
    if scale!=1:
        img=img.resize((8*scale,8*scale), Image.Resampling.NEAREST)
    return img

def bank_sheet(data, bank, mode='pce', scale=2, cols=16, label=True):
    start=bank*0x2000
    bankdata=data[start:start+0x2000]
    tiles=[bankdata[i:i+32] for i in range(0,len(bankdata)-31,32)]
    rows=math.ceil(len(tiles)/cols)
    cell=8*scale
    top=14 if label else 0
    left=0
    img=Image.new('RGB',(cols*cell, rows*cell+top),(240,240,240))
    draw=ImageDraw.Draw(img)
    if label:
        draw.text((2,1), f'bank {bank:02X} off ${start:05X} mode {mode}', fill=(0,0,0))
    for i,t in enumerate(tiles):
        im=make_tile_img(t,mode,scale)
        x=(i%cols)*cell
        y=top+(i//cols)*cell
        img.paste(im,(x,y))
    return img

def mega_sheet(data, mode='pce', scale=1, bank_cols=4):
    # each bank is 16x16 tiles, at scale 1 =128x128 + label strip
    bank_imgs=[]
    for b in range(len(data)//0x2000):
        bank_imgs.append(bank_sheet(data,b,mode,scale,16,True))
    bw,bh=bank_imgs[0].size
    rows=math.ceil(len(bank_imgs)/bank_cols)
    out=Image.new('RGB',(bw*bank_cols,bh*rows),(210,210,210))
    for i,im in enumerate(bank_imgs):
        out.paste(im,((i%bank_cols)*bw,(i//bank_cols)*bh))
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('rom')
    ap.add_argument('out')
    ap.add_argument('--mode',choices=['pce','4plane'],default='pce')
    ap.add_argument('--bank',type=lambda x:int(x,0))
    ap.add_argument('--scale',type=int,default=2)
    ap.add_argument('--bank-cols',type=int,default=4)
    args=ap.parse_args()
    data=Path(args.rom).read_bytes()
    if args.bank is None:
        img=mega_sheet(data,args.mode,args.scale,args.bank_cols)
    else:
        img=bank_sheet(data,args.bank,args.mode,args.scale)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    img.save(args.out)
