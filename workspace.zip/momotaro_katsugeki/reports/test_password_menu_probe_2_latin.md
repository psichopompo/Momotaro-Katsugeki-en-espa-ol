# Password menu probe 2 — glyph IDs latinos

ROM: `Roms/Momotarou Katsugeki (Japan) - password_menu_probe_2_latin.pce`

IPS: `Parches/momotaro_password_menu_probe_2_latin.ips`

## Objetivo

El probe 1 confirmó que la zona de datos por glyph ID sí afecta a la columna derecha del menú de password.

Ahora probamos si esa misma fuente/rutina puede mostrar glyphs latinos existentes (`A-Z`) usando los IDs observados en la fuente (`A=0x70`, `B=0x71`, etc.).

## Cambios

- `0x1E256`: `ABC` sobre `すすむ`.
- `0x1E260`: `DEF` sobre el candidato de `もどる`.
- `0x1E26E`: `GHI` sobre el candidato de `いれる`.
- `0x1E280`: `JKL` sobre el candidato de borrar.
- `0x1E28A`: `MNO` sobre `おわり`.

## Resultado esperado

Si la columna derecha muestra `ABC / DEF / GHI / JKL / MNO`, podemos usar glyph IDs latinos directamente en esa pantalla.

Si no, habrá que cargar/parchear también la fuente usada en este modo.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x018EEB` len `1`
- `0x018EFF` len `1`
- `0x018F03` len `1`
- `0x01E256` len `3`
- `0x01E260` len `3`
- `0x01E26E` len `3`
- `0x01E280` len `3`
- `0x01E28A` len `3`
- `0x0252C9` len `10`
- `0x0252D6` len `8`
- `0x0252DF` len `10`
- `0x0252EC` len `41`
- `0x025316` len `90`
- `0x025371` len `100`
- `0x0253D7` len `69`
- `0x02541E` len `4`
- `0x025424` len `2`
- `0x025427` len `16`
- `0x025438` len `21`
- `0x02544E` len `5`
- `0x025454` len `4`
- `0x025459` len `5`
- `0x025461` len `46`
- `0x025490` len `46`
- `0x0254BF` len `20`
- `0x0254D4` len `57`
- `0x02550E` len `7`
- `0x025516` len `21`
- `0x02552C` len `15`
- `0x02553C` len `81`
- `0x02558E` len `3`
- `0x025592` len `62`
- `0x0255D1` len `3`
- `0x0255D8` len `20`
- `0x0255ED` len `56`
- `0x025626` len `57`
- `0x025660` len `166`
- `0x025707` len `13`
- `0x025715` len `14`
- `0x025724` len `47`
- `0x025754` len `1`
- `0x025756` len `19`
- `0x02576A` len `115`
- `0x0257DE` len `72`
- `0x025827` len `58`
- `0x025863` len `24`
- `0x02587C` len `21`
- `0x025892` len `25`
- `0x0258AC` len `1`
- `0x0258AE` len `2`
- `0x0258B2` len `25`
- `0x0258CC` len `2`
- `0x0258CF` len `144`
- `0x025960` len `19`
- `0x025974` len `23`
- `0x02598C` len `18`
- `0x02599F` len `12`
- `0x0259AC` len `25`
- `0x0259C6` len `3`
- `0x0259CA` len `39`
- `0x0259F2` len `3`
- `0x0259F6` len `25`
- `0x025A10` len `2`
- `0x025A13` len `19`
- `0x025A2C` len `19`
- `0x025A41` len `11`
- `0x025A4E` len `12`
- `0x025A5B` len `2`
- `0x025A5F` len `12`
- `0x025A6C` len `15`
- `0x025A7C` len `55`
- `0x025AB5` len `36`
- `0x025ADA` len `25`
- `0x025AF4` len `73`
- `0x025B3E` len `51`
- `0x025B72` len `59`
- `0x025BB2` len `16`
- `0x025BC3` len `10`
- `0x025BCE` len `5`
- `0x025BD4` len `9`
- `0x025BDE` len `14`
- `0x025BED` len `17`
- `0x025BFF` len `12`
- `0x025C0C` len `18`
- `0x025C1F` len `10`
- `0x025C2B` len `18`
- `0x025C3F` len `2`
- `0x025C42` len `5`
- `0x025C48` len `53`
- `0x025C7E` len `25`
- `0x025C98` len `43`
- `0x025CC4` len `145`
- `0x025D56` len `97`
- `0x025DB8` len `8`
- `0x025DC1` len `5`
- `0x025DC7` len `13`
- `0x025DD6` len `37`
- `0x025DFC` len `54`
- `0x025E33` len `15`
- `0x025E43` len `5`
- `0x025E49` len `85`
- `0x025E9F` len `38`
- `0x025EC6` len `83`
- `0x025F1A` len `25`
- `0x025F34` len `54`
- `0x025F6B` len `16`
- `0x025F7C` len `59`
- `0x025FB8` len `11`
- `0x025FC4` len `15`
- `0x025FD4` len `16`
- `0x025FE5` len `23`
- `0x025FFD` len `12`
- `0x02600A` len `26`
- `0x026025` len `28`
- `0x026042` len `4`
- `0x026047` len `138`
- `0x0260D2` len `17`
- `0x0260E4` len `78`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
- `0x02E2B3` len `2`
- `0x02E6B1` len `4`
- `0x02F8B5` len `125`
- `0x02F933` len `5`
- `0x02F939` len `16`
- `0x02F94A` len `102`
- `0x02F9B1` len `65`
- `0x02F9F3` len `35`
- `0x02FA17` len `23`
- `0x02FA30` len `20`
- `0x02FA45` len `20`
