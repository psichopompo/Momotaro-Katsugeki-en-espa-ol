# Prueba v04 — textos restantes del menú password/load

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_test.pce`

IPS:

`Parches/Pruebas/momotaro_traduccion_v04_password_menu_test.ips`

## Base

Parte de `traduccion_v03`, ya confirmada para parrilla, prompt superior, error de Jizo y navegación.

## Objetivo

Traducir los textos pendientes del menú de password/load sin tocar el prompt ni el error ya cerrados.

## Textos insertados

Selector principal:

```text
CANTO DE JIZO
CARGAR
```

Dificultades / slots:

```text
FÁCIL
NORMAL
DIFÍCIL
MUY DIFÍCIL
```

Selector de carga:

```text
¿Cuál quieres cargar?
```

Error backup RAM:

```text
Los datos guardados
no son válidos.
Se borrará el archivo.
```

## Asignaciones

- `diff_facil`: ROM `0x1FB10`, CPU `$5B10`, len `8`, bytes `01 3c 46 c2 43 49 4c 00`
- `diff_normal`: ROM `0x1FB18`, CPU `$5B18`, len `9`, bytes `01 3c 4e 4f 52 4d 41 4c 00`
- `diff_dificil`: ROM `0x1FB21`, CPU `$5B21`, len `10`, bytes `01 3c 44 49 46 c4 43 49 4c 00`
- `diff_muy_dificil`: ROM `0x1FB2B`, CPU `$5B2B`, len `14`, bytes `02 3c 4d 55 59 20 44 49 46 c4 43 49 4c 00`
- `empty`: ROM `0x1FB39`, CPU `$5B39`, len `1`, bytes `00`
- `menu_jizo`: ROM `0x1FB3A`, CPU `$5B3A`, len `16`, bytes `01 3c 43 41 4e 54 4f 20 44 45 20 4a 49 5a 4f 00`
- `menu_cargar`: ROM `0x1FB4A`, CPU `$5B4A`, len `9`, bytes `02 3c 43 41 52 47 41 52 00`
- `load_question`: ROM `0x1FB53`, CPU `$5B53`, len `23`, bytes `01 c9 43 b5 bb ac 20 b1 b5 a9 a5 b2 a5 b3 20 5d a1 b2 a7 a1 b2 3f 00`
- `backup_error`: ROM `0x1FB6A`, CPU `$5B6A`, len `60`, bytes `01 4c af b3 20 a4 a1 b4 af b3 20 a7 b5 a1 b2 a4 a1 a4 af b3 00 ae af 20 b3 af ae 20 b6 bb ac a9 a4 af b3 cb 00 53 a5 20 5b af b2 b2 a1 b2 bb 20 a5 ac 20 a1 b2 5d a8 a9 b6 af cb ff`

## Punteros parcheados

- `$54AE`: tabla de dificultades.
- `$54EB`: opciones `CANTO DE JIZO` / `CARGAR`.
- `$5501`: selector de carga.
- `C583`: puntero directo del error de backup RAM.

## Validación estática

- Textos nuevos en zona libre de v03: `0x1FB10+`.
- No se toca la lista del prompt en `0x1FA00`.
- No se toca `BA8A` ni la preparación del prompt.
- No se tocan los punteros del prompt superior ni del error de Jizo.

## Cambios contra v03

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`

## Qué comprobar

1. Selector inicial con guardado: que se lea `CANTO DE JIZO` / `CARGAR`.
2. Entrar en CARGAR: pregunta y slots/dificultades.
3. Cargar la partida guardada para confirmar que sigue funcionando.
4. Si puedes provocar error de backup, revisar el mensaje.
5. Confirmar que prompt superior y error de Jizo siguen bien.
