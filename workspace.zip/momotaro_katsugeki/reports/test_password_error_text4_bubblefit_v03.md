# Prueba v03 — error de Jizo con viewport 20 y bocadillo ajustado

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_bubblefit_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_error_text4_bubblefit_test.ips`

## Base

Parte de `traduccion_v02` y conserva el viewport 5x4 que ya permitió ver las cuatro líneas completas.

## Texto fijo

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

## Cambios

- Ventanilla de texto: 5 columnas x 4 líneas en bank `$0F`, como la prueba exitosa.
- Quinta columna con offset `$7F`.
- Texto subido 2 px: `LDY #$6A -> #$68`.
- Bocadillo original no se modifica in-place, pero se usa un stream relocalizado con:
  - left = 9, top = 13, igual que original.
  - right = 28, tres tiles más a la derecha.
  - bottom = 21, dos tiles más abajo.
  - rabillo en la misma posición relativa original.

## Validación

- Bank `$17` no se toca: `0x2F8B5-0x30000` idéntico a v02.
- Lista original `0x2EC10-0x2EC4D` intacta.
- Stream original de bocadillo `0x1E29C-0x1E2DF` intacto; se usa una copia ampliada en `0x1F970`.
- Viewport seguro en `0x1F900`.
- Texto/línea stride en zona libre segura.

## Medidas buscadas

- El bloque de texto completo ya se veía: 146 x 55 px aprox. según captura del usuario.
- Se sube 2 px para acercar margen superior a 8 px.
- Se amplía el bocadillo aproximadamente +24 px a la derecha y +16 px abajo, aproximación por tiles a los +26/+15 px calculados.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Que las cuatro líneas siguen completas.
3. Que el bocadillo cubre la cuarta línea.
4. Que el margen derecho mejora sin quedar exagerado.
5. Que al subir el texto 2 px no se pega arriba.
6. Que la estatua/rabillo quedan aceptables o qué habría que ajustar después.
