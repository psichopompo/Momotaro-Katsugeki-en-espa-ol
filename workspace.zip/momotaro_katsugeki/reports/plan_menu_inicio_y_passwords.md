# Menú de inicio y sistema de passwords — plan técnico

## Pantalla de título

Texto localizado en ROM:

- Offset `0x18E85`: `PUSH<RUN<BUTTON<`
- Banco físico: `$0C`
- Dirección CPU probable cuando está mapeado en `$C000`: `$CE85`
- Terminador en `0x18E95`: `$FF`

El carácter `<` (`$3C`) funciona aquí como espacio/separador visual.

### Prueba generada

Se ha creado una primera prueba simple:

- ROM: `work/Momotarou Katsugeki (Japan) - start_prompt_test.pce`
- IPS: `work/momotaro_start_prompt_test.ips`

Cambio aplicado:

```text
PUSH RUN BUTTON
→
PULSA BOTON RUN
```

Sin tilde en `BOTON`, porque esta rutina de título usa una ruta/fuente distinta a la fuente de diálogo ya parcheada. Más adelante se puede investigar si admite glyphs con tilde o si conviene dejarlo como texto en mayúsculas sin acento.

## Opciones HAJIMETE / TSUZUGI

Todavía no están localizadas como texto normal. La rutina de título parece usar datos de objeto/sprite/tilemap en el banco físico `$17`.

Pista localizada desde el código del banco `$0C`:

- En torno a `0x18F20`, el juego usa una tabla en CPU `$46B1/$46B2` con el banco `$17` mapeado.
- ROM aproximada de esa tabla: `0x2E6B1`.

La zona contiene secuencias compactas terminadas en `$FF`, por ejemplo:

```hex
B5 46 C5 46 ...
02 06 01 08 F0 04 07 00 F3 F0 00 07 01 D3 F0 FF
02 07 01 08 F0 04 06 00 F3 F0 00 06 01 D3 F0 FF
```

Esto parece más una lista de piezas gráficas/sprites que una cadena de texto. Próxima tarea: documentar ese formato para reemplazar `HAJIMETE` / `TSUZUGI` por opciones españolas.

Opciones candidatas:

```text
NUEVA
CLAVE
```

o bien:

```text
EMPEZAR
CONTINUAR
```

La primera pareja es más corta y seguramente más fácil de encajar en sprites/tiles existentes.

## Pantalla de passwords

El sistema de passwords puede ser una de las partes más delicadas.

Opciones técnicas posibles:

### Opción A — mantener algoritmo, cambiar apariencia de símbolos

La opción más segura inicialmente.

El juego seguiría generando los mismos valores internos, pero sustituimos la parrilla de hiragana y los glyphs de password por caracteres latinos/dígitos/símbolos.

Ventajas:

- No hay que cambiar el algoritmo.
- Las passwords generadas y validadas siguen siendo consistentes.
- Menos riesgo de romper partidas.

Desventajas:

- Hay que mapear más símbolos de los que caben en A-Z si el sistema usa todo el silabario.
- Puede requerir A-Z + 0-9 + algunos signos.

### Opción B — cambiar el alfabeto lógico de passwords

Modificar el generador y verificador para usar realmente un alfabeto romano.

Ventajas:

- Passwords más limpias para el jugador occidental.

Desventajas:

- Mucho más riesgo.
- Hay que entender completamente codificación, checksum y validación.

### Recomendación

Empezar con opción A:

1. Localizar glyphs/parrilla hiragana de password.
2. Ver cuántos símbolos reales usa el sistema.
3. Mapearlos a un alfabeto romano amplio, por ejemplo:

```text
A-Z 0-9 ? ! + -
```

4. Confirmar que una password generada puede volver a introducirse.
5. Sólo si queda poco natural, estudiar opción B.

## Próximo paso concreto

1. Probar `start_prompt_test` para confirmar que `PULSA BOTON RUN` aparece correctamente.
2. Reversar el formato de datos en `0x2E6B1` para cambiar `HAJIMETE` / `TSUZUGI`.
3. Empezar a localizar la parrilla de hiragana/password y su tabla de símbolos.
