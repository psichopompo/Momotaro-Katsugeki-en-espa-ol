# Passwords secretos probados con la parrilla latina

Base de prueba: `traduccion_v03_error_text4_bubblefit_shift4_test`.

El usuario confirmó que todos estos passwords funcionan con la equivalencia de la parrilla latina:

| Función | Original japonés romanizado | Entrada latina en nuestra parrilla | Resultado |
|---|---|---|---|
| Ending muy difícil | Ji U Yo Shi Ta Su Ma | `wCpeIfP` | OK |
| Ending normal | Ko Chi Mi Ta Shi Yo | `cJQIep` | OK, pero escena con errores gráficos/texto por traducir |
| Ending difícil | Ki Yu Ka Ta I To | `GoFIBM` | OK |
| Ending fácil | Ra Ki A Ma Ku Sa | `rGAPad` | OK |
| Sound test | I Wa Sa Ki Ha U Ta Ga He Ta | `BqdGlCIWÑI` | OK |
| Graphics test | I Wa Sa Ki Ha E Ga He Ta | `BqdGlDWÑI` | OK |

## Observación importante

El mensaje de error de password se veía bien la primera vez tras reset, pero podía quedar con residuos al repetir error o tras volver de ciertos endings. Esto apunta a limpieza insuficiente del área de patrones/sprites de texto expandida.

Prueba generada para corregirlo:

```text
Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_bubblefit_shift4_clear_test.pce
Parches/Pruebas/momotaro_traduccion_v03_error_text4_bubblefit_shift4_clear_test.ips
```
