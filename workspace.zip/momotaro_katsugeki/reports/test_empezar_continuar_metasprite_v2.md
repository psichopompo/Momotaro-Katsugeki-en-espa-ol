# Test v2 `EMPEZAR / CONTINUAR` como metasprites

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_spanish_test_v2.pce`

IPS: `Parches/momotaro_start_options_spanish_test_v2.ips`

Vista previa: `images/start_options_spanish_v2_preview.png`

## Cambio respecto a v1

La v1 usaba erróneamente formato de tile BG 8x8. Esta v2 codifica los gráficos como patrones de sprite 16x16 de PC Engine:

```text
4 planos; cada plano = 16 filas x 2 bytes
```

Esto debería corregir los fragmentos diminutos que aparecían en pantalla.

## Datos

- Stream original usado: `0x272DE-0x273F8` (283 bytes).
- Stream nuevo: `211` bytes.
- Sombra usada: `False`.
- Longitudes por patrón: `[22, 27, 29, 23, 26, 27, 28, 28]`.

## Listas nuevas

- Lista 1 CPU `$58B5`, ROM `0x2F8B5`.
- Lista 2 CPU `$58CA`, ROM `0x2F8CA`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0272DE` len `13`
- `0x0272EC` len `5`
- `0x0272F2` len `27`
- `0x027310` len `20`
- `0x027325` len `7`
- `0x02732D` len `32`
- `0x02734E` len `13`
- `0x02735C` len `40`
- `0x027385` len `15`
- `0x027395` len `12`
- `0x0273A2` len `18`
- `0x0273B5` len `35`
- `0x0273D9` len `32`
- `0x02E6B2` len `3`
- `0x02F8B5` len `20`
- `0x02F8CA` len `20`
