# Test v8 compacto `EMPEZAR / CONTINUAR`

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_compact_test_v8.pce`

IPS: `Parches/momotaro_start_options_compact_test_v8.ips`

Vista previa: `images/start_options_compact_v8_preview.png`

## Cambio v8

La v7 usaba 5 sprites de 16 px y probablemente superaba el presupuesto/lógica de sprites de la pantalla. V8 usa la misma estructura que el original: 3 entradas de metasprite.

- Entrada 1: sprite 32 px, patrones 0-1.
- Entrada 2: sprite 32 px, patrones 2-3.
- Entrada 3: sprite 16 px, patrón 4.

Esto cubre 80 px con sólo 3 sprites, como el original.

## Datos

- Stream original reutilizado: `0x272DE-0x273F8`.
- Stream nuevo: `200` bytes de 283.
- Lens: `[44, 45, 27, 39, 44]`.
- Lista 1: CPU `$58B5`, ROM `0x2F8B5`.
- Lista 2: CPU `$58C5`, ROM `0x2F8C5`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0272DE` len `106`
- `0x027349` len `1`
- `0x027350` len `3`
- `0x027354` len `38`
- `0x02737B` len `31`
- `0x02739B` len `3`
- `0x02739F` len `12`
- `0x0273AC` len `8`
- `0x0273B5` len `35`
- `0x0273D9` len `32`
- `0x02E6B2` len `1`
- `0x02E6B4` len `1`
- `0x02F8B5` len `15`
- `0x02F8C5` len `15`
