# Test de control — relocalización del stream original de opciones

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_reloc_control.pce`

IPS: `Parches/momotaro_start_options_reloc_control.ips`

## Objetivo

Comprobar si la relocalización del stream gráfico de `HAJIMETE / TSUZUGI` funciona.

Se copia el stream original `0x272DE-0x273F8` al hueco libre `0x2F8B5` y se parchea el loader para leer desde banco `$17`, CPU `$78B5`.

Las listas de metasprite originales se dejan intactas.

## Resultado esperado

Al pulsar RUN deberían verse de nuevo los rótulos japoneses originales, con el prompt ya traducido como `PULSA BOTÓN RUN`.

- Si se ven bien: la relocalización funciona; el fallo está en cómo construimos/comprimimos los nuevos gráficos.
- Si se ven mal: el fallo está en el parche de loader/banco/fuente.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x018EEB` len `1`
- `0x018EFF` len `1`
- `0x018F03` len `1`
- `0x02F8B5` len `38`
- `0x02F8DC` len `58`
- `0x02F917` len `28`
- `0x02F934` len `14`
- `0x02F943` len `8`
- `0x02F94C` len `54`
- `0x02F983` len `8`
- `0x02F98C` len `35`
- `0x02F9B0` len `32`
