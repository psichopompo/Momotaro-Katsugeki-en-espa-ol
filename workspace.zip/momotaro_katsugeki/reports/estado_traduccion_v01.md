# Traducción acumulativa v01

ROM:

`Roms/Momotarou Katsugeki (Japan) - traduccion_v01.pce`

IPS:

`Parches/momotaro_traduccion_v01.ips`

## Contenido confirmado

- Título principal: `MOMOTARO EN ACCIÓN`.
- Prompt de título: `PULSA BOTÓN RUN`.
- Menú principal: `EMPEZAR` / `CONTINUAR`.
- Parrilla de password latina agrupada aceptada.
- Cursor y lógica de inserción de password corregidos.
- Fuente de password corregida por el usuario.
- Buffer de password con puntos/slashes restaurados.

## Criterio a partir de v01

La ROM principal será acumulativa y numerada. Sólo se dejarán en `Roms/` y `Parches/` las versiones confirmadas como éxito; las pruebas viejas irán a `Anteriores`.
