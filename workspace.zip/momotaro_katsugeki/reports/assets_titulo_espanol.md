# Assets del título en español

Versión actual/final entregada por el usuario:

- `title_assets/title_logo_es_fullscreen_final.png`
- `title_assets/title_logo_es_cropped_final.png`

También se han actualizado los alias de trabajo:

- `title_assets/title_logo_es_fullscreen.png`
- `title_assets/title_logo_es_cropped.png`

## Datos técnicos de la versión actual

### Pantalla completa

- Archivo original adjunto: `IMG_4531.PNG`
- Tamaño: `256 x 239 px`
- BBox no transparente: `(8, 32, 248, 92)`
- Colores: 12 incluyendo transparencia.

### Recortada

- Archivo original adjunto: `IMG_4532.PNG`
- Tamaño: `240 x 60 px`
- BBox no transparente: `(0, 0, 240, 60)`
- Colores: 12 incluyendo transparencia.

## ROM/IPS generado

- ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_final.pce`
- IPS: `Parches/momotaro_title_logo_spanish_final.ips`
- Vista previa: `images/title_logo_spanish_final_preview.png`
- Máscara del melocotón: `images/title_logo_spanish_peach_mask_final.png`
