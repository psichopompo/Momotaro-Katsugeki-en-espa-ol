# Test rótulo español con layout original del logo — v5

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v5.pce`

IPS: `Parches/momotaro_title_logo_spanish_original_layout_test_v5.ips`

Vista previa: `images/title_logo_spanish_original_layout_v5_preview.png`

## Cambio respecto a v1

La v1 codificaba los patrones como cuatro tiles BG 8x8. Eso era incorrecto para este stream.

La v5 corrige los colores principales y mantiene. La v4 corrige el orden de bytes de cada fila de sprite: en la VRAM/SAT real el primer byte de la palabra corresponde a la mitad derecha y el segundo a la mitad izquierda.

Codifica cada patrón como **sprite PCE 16x16 en orden VRAM real**:

```text
4 planos; cada plano = 16 filas x 2 bytes
```

Se mantiene intacta la lista original del logo japonés en ROM `0x2E2B0`.

## Datos

- Asset: `title_assets/title_logo_es_fullscreen.png`.
- Base visible usada: X=128, Y=88.
- Stream original: `0x252C8-0x2617A` (3763 bytes).
- Stream nuevo: `3172` bytes.
- Patrones: 64.
- Longitudes por patrón: min `16`, max `84`.

## Nota

Si la estructura sale bien, quedará ajustar paleta y quizá la cobertura de los extremos izquierdo/derecho, porque el layout original cubre aproximadamente x=7..246.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `10`
- `0x0252D6` len `20`
- `0x0252EC` len `3`
- `0x0252F0` len `26`
- `0x02530B` len `41`
- `0x025335` len `42`
- `0x025360` len `171`
- `0x02540C` len `16`
- `0x02541D` len `9`
- `0x025427` len `5`
- `0x02542D` len `6`
- `0x025434` len `2`
- `0x025438` len `27`
- `0x025454` len `4`
- `0x025459` len `5`
- `0x025461` len `61`
- `0x02549F` len `28`
- `0x0254BD` len `23`
- `0x0254D5` len `125`
- `0x025553` len `17`
- `0x025565` len `5`
- `0x02556B` len `86`
- `0x0255C2` len `1`
- `0x0255C4` len `13`
- `0x0255D2` len `5`
- `0x0255D8` len `79`
- `0x025628` len `7`
- `0x025630` len `120`
- `0x0256A9` len `2`
- `0x0256AC` len `86`
- `0x025703` len `7`
- `0x02570B` len `31`
- `0x02572C` len `21`
- `0x025742` len `21`
- `0x025758` len `2`
- `0x02575B` len `24`
- `0x025776` len `59`
- `0x0257B2` len `95`
- `0x025812` len `157`
- `0x0258B0` len `12`
- `0x0258BD` len `2`
- `0x0258C0` len `21`
- `0x0258D6` len `60`
- `0x025916` len `32`
- `0x025937` len `77`
- `0x025985` len `9`
- `0x02598F` len `26`
- `0x0259AA` len `5`
- `0x0259B0` len `21`
- `0x0259C7` len `47`
- `0x0259F9` len `92`
- `0x025A56` len `16`
- `0x025A6C` len `5`
- `0x025A72` len `20`
- `0x025A87` len `11`
- `0x025A93` len `14`
- `0x025AA2` len `3`
- `0x025AA6` len `4`
- `0x025AAB` len `45`
- `0x025ADA` len `57`
- `0x025B14` len `18`
- `0x025B27` len `106`
- `0x025B92` len `55`
- `0x025BCA` len `7`
- `0x025BD2` len `30`
- `0x025BF1` len `19`
- `0x025C06` len `20`
- `0x025C1C` len `9`
- `0x025C26` len `23`
- `0x025C3F` len `30`
- `0x025C61` len `5`
- `0x025C67` len `8`
- `0x025C70` len `4`
- `0x025C75` len `8`
- `0x025C7E` len `100`
- `0x025CE4` len `72`
- `0x025D2D` len `25`
- `0x025D47` len `60`
- `0x025D84` len `81`
- `0x025DD6` len `6`
- `0x025DDD` len `8`
- `0x025DE6` len `15`
- `0x025DF6` len `5`
- `0x025DFC` len `18`
- `0x025E0F` len `6`
- `0x025E16` len `7`
- `0x025E1E` len `42`
- `0x025E49` len `1`
- `0x025E4B` len `26`
- `0x025E66` len `7`
- `0x025E6E` len `48`
- `0x025E9F` len `105`
- `0x025F0C` len `39`
- `0x025F34` len `54`
- `0x025F6B` len `16`
- `0x025F7C` len `59`
- `0x025FB8` len `11`
- `0x025FC4` len `15`
- `0x025FD4` len `16`
- `0x025FE5` len `23`
- `0x025FFD` len `12`
- `0x02600A` len `26`
- `0x026025` len `28`
- `0x026042` len `4`
- `0x026047` len `138`
- `0x0260D2` len `17`
- `0x0260E4` len `78`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
