# Password grid 14-column logic test

ROM: `Roms/Momotarou Katsugeki (Japan) - password_grid_14col_logic_test.pce`

IPS: `Parches/momotaro_password_grid_14col_logic_test.ips`

Preview estático: `images/password_grid_14col_logic_preview.png`

## Objetivo

Nueva prueba según la propuesta de 14 columnas / 5 filas, corrigiendo además la inversión izquierda-derecha del cursor.

## Parrilla esperada

```text
A B C D E F G H I J K L M N
Ñ O P Q R S T U V W X Y Z
a b c d e f g h i j k l m n
ñ o p q r s t u v w x y z
0 1 2 3 4 5 6 7 8 9
```

## Cambios importantes frente al test de 10 columnas

1. **Parrilla 14 columnas / 5 filas**, ocupando la zona japonesa original más el hueco entre bloques.
2. **Direcciones horizontales corregidas**: el input `$20` era derecha y `$80` izquierda, pero la tabla X latina es ascendente; se han intercambiado los branch targets.
3. **Tablas de selección relocalizadas** a `$DC00`, porque la tabla X original sólo tenía 13 bytes (`CC6B..CC77`) y no caben 14 columnas sin pisar la tabla Y.
4. Las celdas inexistentes en filas cortas son `0`, para que la rutina original las salte:
   - fila `Ñ..Z`: columna 14 vacía,
   - fila `ñ..z`: columna 14 vacía,
   - fila `0..9`: columnas 11..14 vacías.

## Validación estática hecha antes de generar

- Símbolos codificados: `64`.
- Tabla runtime: `66` bytes en `0x1BBB9`.
- Tablas selección relocalizadas: `94` bytes en `0x1BC00`, zona original `FF` libre.
- Low stream RLE: `147` / `260` bytes.
- High stream RLE: `12` / `12` bytes.
- X table: `14` bytes.
- Y table: `5` bytes.
- Valores selección: `70` bytes.

## Regiones relevantes cambiadas

- Fuente latina 1bpp: `0x3D660` len `1792`
- Tabla conversión latina 1: `0x41CB3` len `64`
- Tabla conversión latina 2: `0x41CF3` len `64`
- Tabla conversión latina 3: `0x42B5B` len `54`
- Puntero tabla runtime low: `0x1A85E` len `1`
- Puntero tabla runtime high: `0x1A862` len `1`
- Tabla runtime 64 símbolos: `0x1BBB9` len `66`
- Tilemap RLE low: `0x1E18C` len `260`
- Tilemap RLE high: `0x1E290` len `12`
- Branch input derecha $20: `0x1AA47` len `1`
- Branch input izquierda $80: `0x1AA4B` len `1`
- Nav row wrap up: `0x1AA56` len `1`
- Nav row max: `0x1AA6A` len `1`
- Nav col max: `0x1AA80` len `1`
- Nav col wrap left: `0x1AA95` len `1`
- Operand row offsets: `0x1AC56` len `2`
- Operand X table: `0x1A962` len `2`
- Operand Y table: `0x1A968` len `2`
- Operand valores selección: `0x1AC5E` len `2`
- Tablas selección relocalizadas: `0x1BC00` len `94`

## Qué comprobar en emulador

1. Que el bloque ya no invade la caja de inserción.
2. Que se ven 14 columnas en la primera fila.
3. Que derecha mueve el puntero a la derecha e izquierda a la izquierda.
4. Que la esquina superior izquierda introduce `A` y hacia la derecha `B C D...`.
5. Que al bajar desde `A` se pasa a `Ñ`, luego `a`, luego `ñ`, luego `0`.
6. Que las filas cortas saltan las celdas vacías sin quedarse bloqueadas.

Nota: la columna de opciones de la derecha sigue pendiente; primero cerramos parrilla visual/lógica.
