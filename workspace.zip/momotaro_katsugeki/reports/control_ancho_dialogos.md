# Control de ancho para inserción de diálogos

Se añade la herramienta:

`tools/latin_text_tools.py`

Sirve para:

- codificar texto español usando la tabla latina validada;
- convertir saltos de línea a `$00`;
- aceptar tokens `<PAGE>`, `<WAIT>`, `<MODE>`, `<END>`;
- medir longitud visible por línea;
- avisar si una línea excede el ancho máximo de una caja;
- avisar si el texto codificado excede un límite de bytes.

Ejemplo:

```bash
python3 tools/latin_text_tools.py '¡Canto erróneo!\nRevísalo bien.\nReinténtalo.' --max-cols 15 --max-bytes 54 --end
```

Resultado esperado:

```text
Line lengths: [15, 14, 12]
Bytes: 44
```

Para el bocadillo pequeño de Jizo/password, el ancho seguro observado es de unas **15 letras visibles** por línea. Si una línea supera ese valor, el motor hace auto-wrap y puede solaparse con la línea siguiente si hemos insertado saltos manuales.

## Regla provisional

Para cajas pequeñas:

- máximo recomendado: 15 caracteres visibles;
- partir manualmente las líneas;
- si hay que cortar palabra, hacerlo con guion de forma consciente;
- evitar confiar en el auto-wrap del motor.

Esta herramienta será la base del futuro reinserter con repunteo.
