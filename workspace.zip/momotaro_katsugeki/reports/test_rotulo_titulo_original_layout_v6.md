# Test rótulo español — v6 con melocotón separado

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v6.pce`

IPS: `Parches/momotaro_title_logo_spanish_original_layout_test_v6.ips`

Vista previa: `images/title_logo_spanish_original_layout_v6_preview.png`

## Cambio v6

El logo original usa un sprite pequeño separado para el melocotón, con paleta 5, en la posición japonesa original. Al mantener la lista original, ese sprite pintaba parte de `MOMOTARO` con colores rosas.

V6 mueve ese sprite separado al melocotón del rótulo español y excluye la zona del melocotón de los sprites principales.

- Nuevo melocotón: x=130, y=68.
- Patrón usado: `$3C` (p60).
- Paleta del sprite: se mantiene la original `$05`.

## Colores principales

- Main palette: 1=marrón, 2=azul, 3=cian, 4=negro, 5=amarillo.
- Peach palette: 1=piel, 2=hoja, 3=brillo, 4=negro, 5/6/7=rosas.

## Datos

- Stream: `3160` bytes de 3763.
- Longitudes por patrón: min 16, max 100.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `10`
- `0x0252D6` len `20`
- `0x0252EC` len `3`
- `0x0252F0` len `26`
- `0x02530B` len `41`
- `0x025335` len `42`
- `0x025360` len `171`
- `0x02540C` len `16`
- `0x02541D` len `9`
- `0x025427` len `5`
- `0x02542D` len `6`
- `0x025434` len `2`
- `0x025438` len `27`
- `0x025454` len `4`
- `0x025459` len `5`
- `0x025461` len `61`
- `0x02549F` len `28`
- `0x0254BD` len `23`
- `0x0254D5` len `16`
- `0x0254E6` len `3`
- `0x0254EA` len `31`
- `0x02550A` len `131`
- `0x02558E` len `4`
- `0x025593` len `28`
- `0x0255B0` len `33`
- `0x0255D2` len `22`
- `0x0255EA` len `59`
- `0x025626` len `36`
- `0x02564C` len `47`
- `0x02567C` len `7`
- `0x025684` len `55`
- `0x0256BE` len `17`
- `0x0256D0` len `15`
- `0x0256E0` len `29`
- `0x0256FE` len `13`
- `0x02570C` len `31`
- `0x02572D` len `41`
- `0x025757` len `11`
- `0x025763` len `176`
- `0x025814` len `8`
- `0x02581D` len `22`
- `0x025834` len `68`
- `0x025879` len `1`
- `0x02587E` len `18`
- `0x025891` len `27`
- `0x0258B1` len `51`
- `0x0258E5` len `11`
- `0x0258F1` len `17`
- `0x025903` len `2`
- `0x025906` len `9`
- `0x025910` len `37`
- `0x025936` len `9`
- `0x025940` len `22`
- `0x025957` len `39`
- `0x02597F` len `78`
- `0x0259CE` len `58`
- `0x025A09` len `26`
- `0x025A24` len `3`
- `0x025A29` len `22`
- `0x025A41` len `11`
- `0x025A4D` len `10`
- `0x025A58` len `1`
- `0x025A5A` len `3`
- `0x025A5F` len `21`
- `0x025A75` len `2`
- `0x025A78` len `3`
- `0x025A7C` len `4`
- `0x025A81` len `5`
- `0x025A87` len `40`
- `0x025AB0` len `1`
- `0x025AB5` len `35`
- `0x025AD9` len `2`
- `0x025ADC` len `111`
- `0x025B4C` len `67`
- `0x025B90` len `2`
- `0x025B95` len `52`
- `0x025BCA` len `8`
- `0x025BD3` len `26`
- `0x025BEE` len `7`
- `0x025BF6` len `15`
- `0x025C06` len `6`
- `0x025C0D` len `26`
- `0x025C2B` len `30`
- `0x025C4A` len `44`
- `0x025C77` len `12`
- `0x025C84` len `59`
- `0x025CC0` len `155`
- `0x025D5F` len `71`
- `0x025DA7` len `2`
- `0x025DAA` len `35`
- `0x025DCE` len `5`
- `0x025DD4` len `69`
- `0x025E1A` len `44`
- `0x025E47` len `13`
- `0x025E56` len `131`
- `0x025EDA` len `9`
- `0x025EE4` len `36`
- `0x025F0C` len `39`
- `0x025F34` len `54`
- `0x025F6B` len `16`
- `0x025F7C` len `59`
- `0x025FB8` len `11`
- `0x025FC4` len `15`
- `0x025FD4` len `16`
- `0x025FE5` len `23`
- `0x025FFD` len `12`
- `0x02600A` len `26`
- `0x026025` len `28`
- `0x026042` len `4`
- `0x026047` len `138`
- `0x0260D2` len `17`
- `0x0260E4` len `78`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
- `0x02E2B3` len `2`
