# Plan de instrumentación PC Engine — prompt password

## Objetivo

Dejar de hacer pruebas visuales/parches a ciegas y observar en ejecución:

- quién escribe los patrones de sprite `0x1AE..0x1BA`,
- cuándo los escribe,
- qué contienen antes de proyectarse,
- si los chunks extra `0x1B6/0x1B8/0x1BA` se generan realmente o sólo contienen restos.

## Estado del entorno Arena

Se ha clonado y compilado correctamente el core:

```text
/home/user/emutools/beetle-pce-fast-libretro/mednafen_pce_fast_libretro.so
```

No había emulador PCE instalado previamente en el workspace. Se usará `beetle-pce-fast-libretro` como base de instrumentación.

## Pregunta técnica correcta

No es sólo:

```text
¿Por qué 1B6 está mal?
```

sino:

```text
¿Quién escribe 1B6?
```

Si nadie escribe `1B6/1B8/1BA`, el misterio queda resuelto: los estamos proyectando sin que la rutina los haya generado.

Si alguien los escribe, hay que seguir esa rutina.

## Patrones/rangos VRAM a vigilar

Cada patrón sprite 16x16 ocupa `0x40` words en VRAM.

Patrones del prompt ampliado:

```text
1AE -> VRAM word 0x6B80
1B0 -> VRAM word 0x6C00
1B2 -> VRAM word 0x6C80
1B4 -> VRAM word 0x6D00
1B6 -> VRAM word 0x6D80
1B8 -> VRAM word 0x6E00
1BA -> VRAM word 0x6E80
```

Como cada chunk de texto 32x16 usa dos patrones 16x16 consecutivos, vigilar por chunk:

```text
1AE chunk -> 0x6B80..0x6BFF
1B0 chunk -> 0x6C00..0x6C7F
1B2 chunk -> 0x6C80..0x6CFF
1B4 chunk -> 0x6D00..0x6D7F
1B6 chunk -> 0x6D80..0x6DFF
1B8 chunk -> 0x6E00..0x6E7F
1BA chunk -> 0x6E80..0x6EFF
```

Rango total útil:

```text
VRAM words 0x6B80..0x6EFF
```

## Instrumentación a añadir

### 1. Getter de VRAM/SAT/MPR

Exponer desde el core funciones tipo:

```c
uint16_t *arena_pce_get_vram(void);
uint16_t *arena_pce_get_sat(void);
uint16_t arena_pce_get_satb(void);
uint8_t *arena_pce_get_mpr(void);
```

### 2. Log de escrituras VRAM

Hook en `VDC_Write` o en el punto donde se ejecuta:

```c
vdc->VRAM[vdc->MAWR] = value;
```

y en DMA VRAM→VRAM si procede.

Registrar sólo escrituras cuyo destino esté en:

```text
0x6B80..0x6EFF
```

Campos mínimos:

```text
frame
PC HuC6280
VRAM address
value written
MPR map at the time
```

### 3. Watch de PC/call trace

Añadir trazas de JSR/RTS o un PC watch para rutinas candidatas:

```text
CD04/CD40  prompt setup
CD5E       posible generador de texto a VRAM
AA16/AA38  escritura de texto/glyphs
D720/D6BF  rutinas de copia de glyphs
E3EB       proyección/metasprites
E55A       SAT update
```

### 4. Runner Python mínimo

Implementar un frontend libretro por `ctypes` para:

- cargar ROM,
- mandar inputs,
- avanzar frames,
- capturar framebuffer,
- extraer VRAM y logs.

Secuencia mínima para llegar al password:

```text
RUN/selección en título -> CONTINUAR/password
```

## Pruebas a ejecutar

### A. ROM v02 limpia confirmada

Volcar rango `1AE..1BA` en pantalla password japonesa/latina base antes de tocar prompt.

### B. ROM con prompt ampliado `$4B33`

Volcar el mismo rango y comparar:

```text
1AE..1B4 deberían estar generados correctamente.
1B6..1BA dirán si hay escritura real o restos.
```

### C. Log de escrituras

Responder para cada patrón:

```text
1AE: escrito por PC xxxx, N writes
1B0: escrito por PC xxxx, N writes
...
1B6: escrito por PC ? / no escrito
1B8: escrito por PC ? / no escrito
1BA: escrito por PC ? / no escrito
```

## Criterio de decisión

### Si `1B6/1B8/1BA` no se escriben

El arreglo es ampliar la rutina generadora/limpiadora de patrones, no mover la lista.

### Si se escriben pero ya están corruptos

Seguir la rutina que los escribe y comprobar:

- contador de chunks,
- origen de texto,
- limpieza previa,
- stride/direcciones VRAM,
- límite de 4 chunks.

### Si se escriben correctamente en VRAM pero salen mal en pantalla

El problema está en:

- lista `$4B33`,
- atributos/flags,
- orden de mitades,
- clipping/sprite width,
- patrón base usado por `E3EB`.
