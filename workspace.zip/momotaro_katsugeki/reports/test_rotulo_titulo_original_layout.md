# Test rótulo español con layout original del logo

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test.pce`

IPS: `Parches/momotaro_title_logo_spanish_original_layout_test.ips`

Vista previa: `images/title_logo_spanish_original_layout_preview.png`

## Cambio respecto al test anterior

El test anterior reemplazaba la lista de metasprites por 8 sprites uniformes. Eso no respeta el layout real del logo.

Este test mantiene **intacta la lista original** del logo japonés y sólo sustituye el stream gráfico `0x252C8-0x2617A`.

El rótulo español se corta en patrones siguiendo exactamente las posiciones y tamaños del layout original:

- base visible X: `128`
- base visible Y: `88`
- patrones calculados a partir de la lista original en ROM `0x2E2B0`

## Datos

- Stream original: `0x252C8-0x2617A` (3763 bytes).
- Stream nuevo: `3636` bytes.
- Patrones: 64.
- Longitudes por patrón: min `16`, max `100`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `2`
- `0x0252CC` len `9`
- `0x0252D6` len `4`
- `0x0252DC` len `2`
- `0x0252DF` len `8`
- `0x0252ED` len `2`
- `0x0252F0` len `111`
- `0x025360` len `25`
- `0x02537A` len `177`
- `0x02542C` len `33`
- `0x02544E` len `5`
- `0x025454` len `2`
- `0x025457` len `65`
- `0x02549A` len `34`
- `0x0254BD` len `202`
- `0x025588` len `39`
- `0x0255B1` len `58`
- `0x0255ED` len `62`
- `0x025630` len `23`
- `0x02564C` len `220`
- `0x025729` len `7`
- `0x025731` len `115`
- `0x0257A5` len `6`
- `0x0257AC` len `26`
- `0x0257C7` len `7`
- `0x0257CF` len `52`
- `0x025806` len `3`
- `0x02580A` len `17`
- `0x02581C` len `39`
- `0x025844` len `10`
- `0x02584F` len `8`
- `0x025858` len `22`
- `0x02586F` len `9`
- `0x025879` len `105`
- `0x0258E3` len `112`
- `0x025954` len `11`
- `0x025960` len `7`
- `0x025968` len `35`
- `0x02598C` len `55`
- `0x0259C4` len `9`
- `0x0259CE` len `19`
- `0x0259E4` len `2`
- `0x0259E7` len `6`
- `0x0259EE` len `2`
- `0x0259F1` len `3`
- `0x0259F5` len `3`
- `0x0259F9` len `22`
- `0x025A10` len `2`
- `0x025A13` len `78`
- `0x025A62` len `20`
- `0x025A77` len `96`
- `0x025AD8` len `13`
- `0x025AE6` len `24`
- `0x025AFF` len `33`
- `0x025B21` len `26`
- `0x025B3C` len `53`
- `0x025B72` len `36`
- `0x025B97` len `47`
- `0x025BC7` len `2`
- `0x025BCA` len `3`
- `0x025BCE` len `1`
- `0x025BD0` len `3`
- `0x025BD4` len `371`
- `0x025D48` len `19`
- `0x025D5C` len `2`
- `0x025D5F` len `38`
- `0x025D86` len `16`
- `0x025D98` len `16`
- `0x025DA9` len `23`
- `0x025DC1` len `19`
- `0x025DD7` len `18`
- `0x025DEA` len `84`
- `0x025E3F` len `82`
- `0x025E92` len `31`
- `0x025EB2` len `96`
- `0x025F13` len `60`
- `0x025F50` len `98`
- `0x025FB3` len `11`
- `0x025FBF` len `9`
- `0x025FC9` len `4`
- `0x025FCE` len `28`
- `0x025FEB` len `69`
- `0x026031` len `2`
- `0x026034` len `10`
- `0x02603F` len `22`
- `0x026056` len `3`
- `0x02605A` len `38`
- `0x026083` len `19`
- `0x026097` len `1`
- `0x026099` len `1`
- `0x02609B` len `16`
- `0x0260AC` len `35`
- `0x0260D0` len `4`
- `0x0260D6` len `3`
- `0x0260DC` len `15`
- `0x0260EC` len `4`
- `0x0260F5` len `61`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
