# Password grid 14-column layout2 test

ROM: `Roms/Momotarou Katsugeki (Japan) - password_grid_14col_layout2_test.pce`

IPS: `Parches/momotaro_password_grid_14col_layout2_test.ips`

Preview estático: `images/password_grid_14col_layout2_preview.png`

Spritesheet editable: `font_edit/password_alphabet_edit_1x.png`

Referencia ampliada: `font_edit/password_alphabet_edit_8x_grid.png`

Mapa: `font_edit/password_alphabet_edit_mapping.txt`

## Objetivo

Ajuste posterior al test de 14 columnas:

- bloque más centrado a nivel visual,
- más separación entre mayúsculas / minúsculas / números,
- placeholders del buffer inferior como punto medio grueso y slash, en vez de letras `u/v`,
- se mantiene la corrección de izquierda/derecha.

## Medición del test anterior

En la captura del test anterior, la primera fila completa ocupaba aproximadamente:

- borde izquierdo: `x=24`,
- borde derecho: `x=238`,
- margen izquierdo: `24 px`,
- margen derecho: `17 px`.

El centro matemático pedía mover el bloque unos `3.5 px` a la izquierda. Como el tilemap de fondo trabaja en pasos de 8 px, este test usa una solución de compromiso: empieza en `x≈16` y mantiene el borde derecho cerca de `x≈238`, con un pequeño hueco extra entre la 7.ª y 8.ª columna.

## Parrilla esperada

```text
A B C D E F G H I J K L M N
Ñ O P Q R S T U V W X Y Z
a b c d e f g h i j k l m n
ñ o p q r s t u v w x y z
0 1 2 3 4 5 6 7 8 9
```

## Placeholder del buffer inferior

La rutina original convierte:

- valor `$00` del buffer -> patrón placeholder,
- valor `$FF` del buffer -> separador.

En el test anterior esos patrones coincidían con letras del nuevo alfabeto, por eso salían `u/v`. Ahora se generan dos patrones adicionales:

- patrón `$41` = punto medio grueso,
- patrón `$42` = slash.

Y se parchea `CB7E` para usarlos.

## Validación estática hecha antes de generar

- Símbolos seleccionables: `64`.
- Tabla runtime total: `68` bytes en `0x1BBB9`.
- Patrones generados: `1..64` alfabeto, `$41/$42` placeholders.
- Tablas selección relocalizadas: `94` bytes en `0x1BC00`, zona original `FF` libre.
- Low stream RLE: `149` / `260` bytes.
- High stream RLE: `12` / `12` bytes.
- X table: `14` bytes.
- Y table: `5` bytes.
- Valores selección: `70` bytes.

## Regiones relevantes cambiadas

- Fuente latina 1bpp + placeholders: `0x3D660` len `1792`
- Tabla conversión latina 1: `0x41CB3` len `64`
- Tabla conversión latina 2: `0x41CF3` len `64`
- Tabla ASCII latina + $60/$61: `0x42B5B` len `54`
- Puntero tabla runtime low: `0x1A85E` len `1`
- Puntero tabla runtime high: `0x1A862` len `1`
- Tabla runtime 64 símbolos + dot/slash: `0x1BBB9` len `68`
- CB7E placeholder $FF -> slash: `0x1AB87` len `1`
- CB7E placeholder $00 -> dot: `0x1AB8C` len `1`
- Tilemap RLE low: `0x1E18C` len `260`
- Tilemap RLE high: `0x1E290` len `12`
- Branch input derecha $20: `0x1AA47` len `1`
- Branch input izquierda $80: `0x1AA4B` len `1`
- Nav row wrap up: `0x1AA56` len `1`
- Nav row max: `0x1AA6A` len `1`
- Nav col max: `0x1AA80` len `1`
- Nav col wrap left: `0x1AA95` len `1`
- Operand row offsets: `0x1AC56` len `2`
- Operand X table: `0x1A962` len `2`
- Operand Y table: `0x1A968` len `2`
- Operand valores selección: `0x1AC5E` len `2`
- Tablas selección relocalizadas: `0x1BC00` len `94`

## Qué comprobar en emulador

1. Si el bloque se ve mejor centrado o si el hueco horizontal extra molesta.
2. Si la separación vertical entre mayúsculas, minúsculas y números queda mejor.
3. Si derecha/izquierda siguen correctas.
4. Si las filas cortas siguen saltando los huecos vacíos.
5. Si el buffer inferior vuelve a mostrar puntos/slashes en slots vacíos.

## Nota de fuente

Se han generado spritesheets para retocar las letras problemáticas (`d`, `q`, `b`, `p`, `Ñ`, etc.). El archivo editable 1x debe mantenerse exactamente en `112x40 px`, con celdas de `8x8`.
