# Revert prompt superior — vuelve a frame240_punct

ROM activa restaurada:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_frame240_punct_revert_test.pce`

IPS:

`Parches/Pruebas/momotaro_traduccion_v03_prompt_frame240_punct_revert_test.ips`

## Motivo

La prueba `prompt_frame240_punct_side_test` intentó adelantar el sprite del lateral derecho para evitar que lo tapara el fondo del último chunk, pero el resultado fue incorrecto:

- el lateral apareció como una línea blanca dentro del texto;
- desapareció la `o` de `Jizo`;
- el borde derecho seguía sin quedar en su posición correcta.

Se revierte a la prueba inmediatamente anterior: `prompt_frame240_punct_test`.

## Estado al que se vuelve

- Prompt completo y limpio.
- `¡` y `¿` corregidos.
- Sin duplicado ni residuos.
- Marco superior con el lateral derecho aún pendiente de ajuste fino.
- Error de Jizo y navegación especial conservados.
