# Momotarou Katsugeki (PC Engine) — informe inicial de romhacking

Fecha: 2026-07-28

## ROM analizada

Archivo de trabajo: `work/Momotarou Katsugeki (Japan).pce`

- Tamaño: `0x80000` bytes, 512 KiB.
- No parece tener cabecera de copión de 512 bytes: el tamaño ya está alineado a `0x2000` y el código de arranque empieza en el offset `0x000000`.
- MD5: `ec7358edb3672a8aa8850623eec72a71`
- SHA1: `b63aa8ae29b4d06dea7f5b795c4192285fc3c43b`
- SHA256: `548f41efee5b0b5dfed041766cd83aa54ba68f573b82733c81979d50ea65c1ad`
- Identificador ASCII interno en `0x001FE0`: `MOMOKATSU   1.07900518`.

## Herramientas creadas en el workspace

- `tools/render_pce_tiles.py`: visor rápido de tiles PC Engine 4bpp para bancos de 8 KiB.
- `tools/render_1bpp.py`: visor rápido 1bpp para comprobar fuentes o gráficos monocromos.
- `tools/decode_text.py`: decodificador preliminar de texto japonés de 1 byte.
- `tools/dis6280_bin`: desensamblador HuC6280 compilado desde `dis6280`.

## Primeras conclusiones técnicas

### 1. El texto principal NO está comprimido de forma global

Una parte muy grande del texto visible del juego aparece en claro, en una codificación japonesa de 1 byte basada en katakana de anchura media:

- Rango principal de kana: `$A1-$DF`.
- Al normalizar los kana de CP932 se puede leer bastante bien como hiragana.
- También se usan bytes ASCII visibles para símbolos y pseudo-controles: `\`, `<`, `;`, `=`, `$`, etc.
- `$A0` se usa mucho como espacio de anchura fija / relleno.

Esto es una buena noticia: el primer volcado de guion puede hacerse sin resolver aún toda la compresión gráfica.

### 2. Controles de texto observados, todavía pendientes de confirmar al 100 %

| Byte/símbolo | Observación preliminar |
|---|---|
| `$00` | Separador / fin de línea / salto según contexto. |
| `$FF` | Fin de mensaje o fin de bloque. |
| `$FC` | Cambio de página/bocadillo en bloques de diálogo largos. |
| `$FD` | Espera/pausa o separador de pantallas de explicación. |
| `$FE` | Cambio de modo/tipo de mensaje en tutoriales. |
| `$F0` | Fin de texto de resultado/objeto en ciertos bloques. |
| `$FB` | Relleno o marcador relacionado con cantidades/variables. |
| `$A0` | Espacio fijo/relleno en bocadillos horizontales. |
| `;` | Muy importante: separador de columnas en textos verticales de NPC. |
| `=` | Fin/pausa de frase en textos verticales de aldea; probablemente cierre o espera. |

### 3. Bancos de texto localizados

| Zona | Offset ROM | Contenido |
|---|---:|---|
| Banco `$0F` | `0x1ED6E` / `0x1EF72` | Tablas de punteros/descriptoras para textos de casa, intro, tutorial y menús debug/test. |
| Banco `$0F` | `0x1F079` aprox. | Diálogos iniciales: abuelo/abuela, casa, sala de música, tutorial. |
| Banco `$1D` | `0x3B800` aprox. | Texto de final/créditos, en claro. |
| Bancos `$24-$25` | `0x48000-0x4B5xx` aprox. | Tiendas, objetos, mensajes de fase, NPC de aldea, apuestas, ermitaño, quiz y mucho texto jugable. |
| Banco `$0B` | `0x16969` aprox. | Tabla de punteros a mensajes de obtención de objetos/dinero en banco `$24`. |

Nota de mapeado: en una rutina del banco `$0B` se ve que el juego mapea los bancos físicos `$24` y `$25` en MPR2/MPR3, es decir, como rangos CPU `$4000-$5FFF` y `$6000-$7FFF`. Por tanto, un texto en `0x48E40` corresponde a dirección CPU aproximada `$4E40` cuando el banco `$24` está mapeado.

### 4. Ejemplos encontrados usando tus capturas

| Captura / caso | Texto japonés de referencia | Offset aproximado |
|---|---|---:|
| Bocadillo horizontal de victoria | `もえる とうこん! ももたろう! / ねくすとすてーじ れっつごー!` | `0x481E2` |
| Arma “びゃっこのけん” | `びゃっこのけん: たまが 2れんしゃに なるだど!` | `0x48AE8` |
| Texto vertical de tutorial/NPC | `おお!;ももたろう!;;\おに\たいじに;...` | `0x48E40` |
| Texto vertical de NPC | `おや?おぬし;\さる\を;つれとるのか;...` | `0x4968A` |
| Apuestas | `さあ あたれば いっかくせんきん / どうだい やっていくかい?` | `0x4AC8B` |
| Ermitaño / quiz | `\くいず\に ぜんぶ せいかいすれば じゅつを さずけてやろう!` | `0x4AE38` |
| Créditos/final | `おめでとう! ありがとう!` | `0x3B800` |

### 5. Textos verticales: formato probable

Los textos verticales no parecen ser gráficos: son cadenas normales con separadores. El patrón más claro es:

```text
おお!;ももたろう!;;\おに\たいじに;たびだつ;そうじゃな!;...
```

La hipótesis de trabajo es:

- `;` avanza a la siguiente columna vertical.
- Las columnas se dibujan de derecha a izquierda.
- Cada columna se dibuja de arriba abajo.
- `;;` deja una columna en blanco o separa grupos.
- `=` puede actuar como pausa/final en textos de aldea.

Esto confirma el problema que comentabas: traducir tal cual al castellano sería muy restrictivo, porque una columna vertical admite poquísimas letras latinas.

Opciones técnicas para estos textos:

1. **Mantener verticalidad**: viable sólo con traducciones extremadamente cortas, poco natural.
2. **Parchear el renderizador vertical para modo horizontal**: opción ideal, pero requiere localizar rutina de dibujo, avance X/Y, tamaño de bocadillo y reglas de salto.
3. **Solución híbrida**: convertir `;` a salto horizontal dentro del mismo bocadillo y usar fuente latina estrecha. Probablemente será el mejor primer prototipo antes de redimensionar bocadillos.

### 6. Gráficos y compresión

El visor raw de tiles PC Engine muestra que muchos gráficos grandes no están en 4bpp lineal simple en ROM. La pantalla de título y bastantes assets parecen comprimidos o empaquetados.

Pista importante localizada:

- En el banco `$2F`, offset `0x5F000`, hay un módulo de código/datos con la cadena ASCII `!BM FORMAT!`.
- En esa zona aparecen rutinas alrededor de `$D000-$DAxx` que probablemente manejan un formato gráfico/bitmap propietario o un cargador de assets comprimidos.

Esta zona será prioritaria para editar el título y assets gráficos con texto.

## Próximos pasos recomendados

1. Extraer automáticamente los textos de bancos `$0F`, `$1D`, `$24` y `$25` a un TSV/CSV editable.
2. Confirmar todos los control codes con trazas sobre la rutina de render de texto.
3. Localizar la tabla de punteros completa de los textos de `$24/$25`.
4. Hacer una prueba mínima de inserción: cambiar un texto corto horizontal por ASCII/latino y ver qué glyphs usa.
5. Diseñar o insertar una fuente latina compacta.
6. Prototipar la reconversión de texto vertical a horizontal en una escena NPC concreta.
7. Reversar `!BM FORMAT!` para poder extraer/reinsertar gráficos comprimidos, especialmente pantalla de título.
