# Sistema de passwords — propuesta de alfabeto latino de 64 símbolos

## Idea base

La pantalla japonesa parece usar 64 símbolos seleccionables. Si el sistema interno trata cada símbolo como un índice independiente `0-63`, podemos sustituir visualmente el silabario por un alfabeto latino de 64 signos sin tocar inicialmente el algoritmo.

La propuesta encaja perfectamente:

- 27 letras españolas mayúsculas: `A-Z` + `Ñ`
- 27 letras españolas minúsculas: `a-z` + `ñ`
- 10 dígitos: `0-9`

Total: `27 + 27 + 10 = 64`.

## Propuesta de parrilla 8x8

```text
A B C D E F G H
I J K L M N Ñ O
P Q R S T U V W
X Y Z a b c d e
f g h i j k l m
n ñ o p q r s t
u v w x y z 0 1
2 3 4 5 6 7 8 9
```

Ventajas:

- Usa sólo caracteres reconocibles para público hispanohablante.
- No hay símbolos extraños ni restos japoneses.
- Mantiene exactamente 64 entradas.
- Permite conservar el algoritmo original si cada carácter japonés era un índice de 6 bits o equivalente.

## Riesgos/precauciones

### 1. Passwords sensibles a mayúsculas/minúsculas

El jugador tendrá que distinguir `A` de `a`, `O` de `o`, etc. Como se introducen desde una parrilla visual, no es tan problemático como en teclado, pero hay que cuidar mucho la fuente.

Caracteres especialmente delicados:

- `I`, `l`, `1`
- `O`, `o`, `0`
- `S`, `s`, `5`
- `Z`, `z`, `2`

Conviene redibujar algunos glyphs para maximizar legibilidad en pantalla de password.

### 2. Confirmar que son 64 símbolos lógicos

Aunque visualmente haya 64 hiragana, hay que comprobar que el juego no trate dakuten/handakuten como modificadores o casos especiales. Si cada casilla es un índice independiente, la sustitución es directa.

### 3. Orden interno

Hay que identificar el orden real de los 64 símbolos en memoria. El orden visual no siempre coincide con el orden interno usado por generador/verificador.

## Estrategia recomendada

### Fase A — sustitución visual, sin tocar algoritmo

1. Localizar la tabla/parrilla de 64 símbolos.
2. Reemplazar sus glyphs/tilemap por la parrilla latina propuesta.
3. Generar una password japonesa original y comprobar su equivalente latino.
4. Introducir la misma secuencia latina y verificar que carga correctamente.

Si esto funciona, tenemos el sistema de passwords occidentalizado sin tocar checksum ni generador.

### Fase B — sólo si fuera necesario

Modificar algoritmo/generador/verificador para generar passwords nuevas con otra distribución. No recomendable al principio por riesgo alto.

## Labels de la pantalla de password

Opciones japonesas vistas en la columna derecha:

```text
すすむ
もどる
いれる
けす
おわり
```

Candidatas en castellano, intentando caber en poco espacio:

```text
SIGUE
ATRÁS
METE
BORRA
FIN
```

o más natural si hay espacio:

```text
AVANZA
VUELVE
ENTRAR
BORRAR
SALIR
```

Habrá que ver si esas opciones son texto normal, sprites o tilemap gráfico.

## Textos del bocadillo de password localizados

Zona de texto en claro localizada alrededor de `0x1F500`:

```text
じぞうのうたを いれるのじゃ!
じぞうのうたが ちがっとるぞ!
ちゃんと かくにんして
もういちど いれなおすのじゃ!
```

Traducción funcional propuesta:

```text
¡Introduce la clave!
¡Clave incorrecta!
Compruébala bien
e inténtalo otra vez.
```

También podría conservarse el sabor japonés con `canción del Jizō`, pero para claridad de menú es mejor `clave`.
