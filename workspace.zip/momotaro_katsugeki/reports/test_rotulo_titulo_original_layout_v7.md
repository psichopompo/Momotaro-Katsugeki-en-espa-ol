# Test rótulo español con melocotón separado — v7

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v7.pce`

IPS: `Parches/momotaro_title_logo_spanish_original_layout_test_v7.ips`

Vista previa: `images/title_logo_spanish_original_layout_v7_preview.png`

Máscara del melocotón: `images/title_logo_spanish_peach_mask_v7.png`

## Cambio v7

La v6 movía el sprite separado del melocotón, pero excluía/dibujaba una región rectangular completa. Eso hacía que colores de las letras alrededor del melocotón se remapearan con la paleta del melocotón.

La v7 usa una máscara precisa:

- semillas: colores rosas/brillo/hoja del melocotón;
- se añade sólo el negro adyacente como contorno;
- no se incluyen amarillos/marrones/azules de las letras alrededor.

## Posición del sprite separado

- BBox máscara: (131,70)-(146,84)
- Sprite 16x16 en: x=131, y=69

## Datos

- Stream: `3162` bytes de 3763.
- Longitudes por patrón: min 16, max 87.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `10`
- `0x0252D6` len `20`
- `0x0252EC` len `3`
- `0x0252F0` len `26`
- `0x02530B` len `41`
- `0x025335` len `42`
- `0x025360` len `171`
- `0x02540C` len `16`
- `0x02541D` len `9`
- `0x025427` len `5`
- `0x02542D` len `6`
- `0x025434` len `2`
- `0x025438` len `27`
- `0x025454` len `4`
- `0x025459` len `5`
- `0x025461` len `61`
- `0x02549F` len `28`
- `0x0254BD` len `23`
- `0x0254D5` len `64`
- `0x025516` len `36`
- `0x02553B` len `94`
- `0x02559D` len `18`
- `0x0255B0` len `17`
- `0x0255C2` len `18`
- `0x0255D8` len `60`
- `0x025615` len `65`
- `0x025657` len `56`
- `0x025690` len `57`
- `0x0256CC` len `17`
- `0x0256DE` len `77`
- `0x02572C` len `43`
- `0x025758` len `81`
- `0x0257AA` len `24`
- `0x0257C3` len `123`
- `0x025841` len `39`
- `0x025869` len `33`
- `0x02588B` len `10`
- `0x025896` len `36`
- `0x0258BF` len `10`
- `0x0258CA` len `52`
- `0x0258FF` len `6`
- `0x025906` len `9`
- `0x025910` len `2`
- `0x025914` len `120`
- `0x02598D` len `28`
- `0x0259AA` len `51`
- `0x0259DE` len `77`
- `0x025A2C` len `6`
- `0x025A33` len `8`
- `0x025A3C` len `13`
- `0x025A4A` len `14`
- `0x025A59` len `14`
- `0x025A68` len `3`
- `0x025A6C` len `26`
- `0x025A87` len `35`
- `0x025AAB` len `6`
- `0x025AB3` len `49`
- `0x025AE5` len `16`
- `0x025AF6` len `25`
- `0x025B10` len `29`
- `0x025B2E` len `106`
- `0x025B99` len `21`
- `0x025BAF` len `57`
- `0x025BE9` len `4`
- `0x025BEE` len `2`
- `0x025BF1` len `19`
- `0x025C06` len `5`
- `0x025C0C` len `38`
- `0x025C33` len `10`
- `0x025C3E` len `34`
- `0x025C61` len `2`
- `0x025C64` len `4`
- `0x025C69` len `72`
- `0x025CB2` len `85`
- `0x025D08` len `125`
- `0x025D86` len `40`
- `0x025DAF` len `62`
- `0x025DEE` len `10`
- `0x025DF9` len `2`
- `0x025DFC` len `42`
- `0x025E27` len `18`
- `0x025E3A` len `31`
- `0x025E5A` len `20`
- `0x025E6F` len `8`
- `0x025E7A` len `47`
- `0x025EAA` len `47`
- `0x025EDA` len `46`
- `0x025F0C` len `39`
- `0x025F34` len `54`
- `0x025F6B` len `16`
- `0x025F7C` len `59`
- `0x025FB8` len `11`
- `0x025FC4` len `15`
- `0x025FD4` len `16`
- `0x025FE5` len `23`
- `0x025FFD` len `12`
- `0x02600A` len `26`
- `0x026025` len `28`
- `0x026042` len `4`
- `0x026047` len `138`
- `0x0260D2` len `17`
- `0x0260E4` len `78`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
- `0x02E2B3` len `2`
