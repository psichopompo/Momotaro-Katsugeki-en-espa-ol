# Password grid grouped + user font test

ROM: `Roms/Momotarou Katsugeki (Japan) - password_grid_grouped_font_test.pce`

IPS: `Parches/momotaro_password_grid_grouped_font_test.ips`

Preview estático: `images/password_grid_grouped_font_preview.png`

Fuente de usuario importada: `font_edit/password_alphabet_user_fixed_1x.png`

Referencia ampliada: `font_edit/password_alphabet_user_fixed_8x_grid.png`

Mapa de importación: `font_edit/password_alphabet_user_fixed_mapping.txt`

## Objetivo

Prueba con la distribución agrupada propuesta y con la fuente corregida enviada por el usuario.

Prefiero esta distribución porque el hueco central deja de ser una anomalía dentro del abecedario y pasa a separar dos bloques con sentido: mayúsculas a la izquierda y minúsculas a la derecha. Además conserva el centrado bueno que sólo era posible introduciendo un hueco.

## Parrilla visual/lógica esperada

`·` significa celda vacía que la navegación debe saltar.

```text
A B C D E F G a b c d e f g
H I J K L M N h i j k l m n
Ñ O P Q R S T ñ o p q r s t
U V W X Y Z · u v w x y z ·
· · 0 1 2 3 4 5 6 7 8 9 · ·
```

## Orden de valores generado internamente

```text
ABCDEFGabcdefgHIJKLMNhijklmnÑOPQRSTñopqrstUVWXYZuvwxyz0123456789
```

La tabla `CC82` usa valores `1..64` en ese orden. Los huecos visuales son `0` para que la rutina original los salte.

## Corrección del fallo desde la q minúscula

Confirmado por código: el buffer original trata cualquier valor `>= $2D` como kana con dakuten/handakuten. Entonces lo remapea por `CBD1` y dibuja un patrón encima del carácter. Por eso desde la `q` minúscula en el orden anterior salían caracteres equivocados y aparecían `r/s` arriba.

Parche aplicado:

```asm
CB97: CMP #$2D  ; original
CB97: CMP #$41  ; nuevo: sólo valores >64 entrarían en esa ruta
```

Así los valores `1..64` del alfabeto latino se dibujan directos.

## Placeholder del buffer inferior

Se mantiene el arreglo de slots vacíos:

- `$00` -> punto medio grueso,
- `$FF` -> slash.

## Validación estática hecha antes de generar

- Fuente enviada: `112x40` px, dos colores.
- Glifos importados desde fuente usuario: `64`.
- Símbolos seleccionables: `64`.
- Tabla runtime total: `68` bytes en `0x1BBB9`; termina en `0x1BBFD`.
- Tablas selección relocalizadas: `94` bytes en `0x1BC00`, zona original `FF` libre.
- Low stream RLE: `150` / `260` bytes.
- High stream RLE: `12` / `12` bytes.
- X table: `14` bytes.
- Y table: `5` bytes.
- Valores selección: `70` bytes.

## Regiones relevantes cambiadas

- Fuente latina 1bpp + fuente usuario + placeholders: `0x3D660` len `1792`
- Tabla conversión latina 1: `0x41CB3` len `64`
- Tabla conversión latina 2: `0x41CF3` len `64`
- Tabla ASCII latina + $60/$61: `0x42B5B` len `54`
- Puntero tabla runtime low: `0x1A85E` len `1`
- Puntero tabla runtime high: `0x1A862` len `1`
- Tabla runtime 64 símbolos + dot/slash: `0x1BBB9` len `68`
- CB90 threshold de marcas: `0x1AB98` len `1`
- CB7E placeholder $FF -> slash: `0x1AB87` len `1`
- CB7E placeholder $00 -> dot: `0x1AB8C` len `1`
- Tilemap RLE low: `0x1E18C` len `260`
- Tilemap RLE high: `0x1E290` len `12`
- Branch input derecha $20: `0x1AA47` len `1`
- Branch input izquierda $80: `0x1AA4B` len `1`
- Nav row wrap up: `0x1AA56` len `1`
- Nav row max: `0x1AA6A` len `1`
- Nav col max: `0x1AA80` len `1`
- Nav col wrap left: `0x1AA95` len `1`
- Operand row offsets: `0x1AC56` len `2`
- Operand X table: `0x1A962` len `2`
- Operand Y table: `0x1A968` len `2`
- Operand valores selección: `0x1AC5E` len `2`
- Tablas selección relocalizadas: `0x1BC00` len `94`

## Qué comprobar en emulador

1. Si esta distribución agrupada resulta más natural que la de 14 columnas lineales con hueco central.
2. Que derecha/izquierda siguen correctas.
3. Que todos los caracteres insertan exactamente el mismo carácter, especialmente desde `q` hasta `9`.
4. Que no aparecen `r/s` o marcas encima de los caracteres insertados.
5. Que los huecos se saltan bien en navegación.
6. Que el buffer inferior muestra puntos/slashes en vacío.
7. Que la fuente corregida se ve como en el PNG enviado.
