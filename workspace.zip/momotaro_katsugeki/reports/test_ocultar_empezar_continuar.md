# Test para confirmar metasprites de `HAJIMETE / TSUZUGI`

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_hide_test.pce`

IPS: `Parches/momotaro_start_options_hide_test.ips`

## Qué hace

Parte de la ROM aceptada con `PULSA BOTÓN RUN` y además cambia el primer byte de las dos listas de metasprite de opciones a `$FF`, para que se consideren listas vacías:

- Lista `$46B5`, ROM `0x2E6B5` → `$FF`
- Lista `$46C5`, ROM `0x2E6C5` → `$FF`

## Resultado esperado

Al pulsar RUN en el título, deberían desaparecer/no dibujarse los rótulos japoneses `HAJIMETE / TSUZUGI`.

Si desaparecen, confirmamos al 100% que esas listas son las que colocan los rótulos.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x02E6B5` len `1`
- `0x02E6C5` len `1`
