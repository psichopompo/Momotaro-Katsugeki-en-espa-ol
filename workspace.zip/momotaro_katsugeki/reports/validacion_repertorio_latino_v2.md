# Validación de repertorio latino v2

El usuario probó `latin_charset_test_v2` en emulador y envió capturas de las 4 pantallas.

Se compararon automáticamente las capturas contra los glyphs esperados de la ROM parcheada. Resultado:

- Página 1: coincidencia exacta píxel a píxel.
- Página 2: coincidencia exacta píxel a píxel.
- Página 3: coincidencia exacta píxel a píxel.
- Página 4: coincidencia exacta píxel a píxel para lo mostrado.

## Repertorio validado

```text
abcdefghijklmn
opqrstuvwxyz
áéíóú ü ñ ç

ABCDEFGHIJKLM
NOPQRSTUVWXYZ
ÁÉÍÓÚ Ü Ñ Ç

¿? ¡! 012345
6789 200¤
.,:;… '-/()%
&+ ºª
```

## Códigos problemáticos confirmados

Los siguientes bytes NO deben usarse directamente como texto normal:

- `$A2` — el motor lo remapea; falló como `b`.
- `$A3` — el motor lo remapea; falló como `c`.
- `$B0` — el motor lo remapea; falló como `p`.
- `$5C` — reservado por el juego como conmutador/escape de tabla.
- `$DE` / `$DF` — reservados como dakuten/handakuten en texto japonés.

## Solución v2 validada

- `$5B = b` → glyph `$A2`
- `$5D = c` → glyph `$A3`
- `$5E = p` → glyph `$B0`
- `$5F = Ç` → glyph `$DE`

Esto permite reutilizar glyphs conflictivos mediante una tabla intermedia sin usar los bytes conflictivos directamente.

## Observación sobre limpieza de caja

En la captura de la cuarta página, al ser una página de una sola línea, el juego conserva visualmente líneas de la página anterior. No es un problema de fuente; indica que el motor no limpia automáticamente todas las líneas del bocadillo al pasar a una página con menos líneas.

Para inserción real conviene que cada página de texto rellene/limpie las líneas restantes, o bien que el script de inserción genere espacios/saltos adecuados para evitar restos de la página previa.

## Estado

La tabla `work/charset_latin_charset_test_v2.tbl` queda como base válida para la siguiente fase: refinado visual de glyphs y prueba de reinserción con texto real repunteado.
