# Prueba v03 — textos del menú/password con repointing

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_password_texts_wrap_test.pce`

IPS de prueba acumulativo contra ROM limpia:

`Parches/Pruebas/momotaro_traduccion_v03_password_texts_wrap_test.ips`

## Base

Parte de `traduccion_v02`, ya confirmada.

## Objetivo

Segunda prueba de los textos del menú/password. Además del repointing a zona libre, esta versión prueba el ajuste que necesitamos para bocadillos pequeños: salto por palabras y paginación/limpieza con `<MODE>` para evitar que una línea larga sobrescriba la siguiente.

## Textos insertados

### Selector principal

```text
FÁCIL
NORMAL
DIFÍCIL
MUY DIFÍCIL

CANTO DE JIZO
CARGAR
```

### Selector de carga

```text
¿Cuál quieres cargar?
```

### Error de backup RAM

```text
Los datos guardados
no son válidos.
Se borrará el archivo.
```

### Password / Jizo

```text
¡Introduce el
canto de Jizo!

¡El canto de
Jizo no es
correcto!
--- scroll/clear ---
Compruébalo bien
e inténtalo
otra vez.
```

## Longitudes visibles aproximadas por línea

- `FÁCIL`: 5
- `NORMAL`: 6
- `DIFÍCIL`: 7
- `MUY DIFÍCIL`: 11
- `CANTO DE JIZO`: 13
- `CARGAR`: 6
- `¿Cuál quieres cargar?`: 21
- `backup_error`: 19, 15, 22
- `jizo_prompt`: 13, 14
- `jizo_error`: 12, 10, 9, 16, 11, 9

Nota: esta versión prueba wrap manual y paginación con `<MODE>` en el error. Sirve para confirmar si la rutina puede usarse como base de scroll/cambio de página.

## Asignaciones nuevas

- `diff_facil`: ROM `0x1F838`, CPU `$5838`, len `8`, bytes `01 3c 46 c2 43 49 4c 00`
- `diff_normal`: ROM `0x1F840`, CPU `$5840`, len `9`, bytes `01 3c 4e 4f 52 4d 41 4c 00`
- `diff_dificil`: ROM `0x1F849`, CPU `$5849`, len `10`, bytes `01 3c 44 49 46 c4 43 49 4c 00`
- `diff_muy_dificil`: ROM `0x1F853`, CPU `$5853`, len `14`, bytes `02 3c 4d 55 59 20 44 49 46 c4 43 49 4c 00`
- `empty`: ROM `0x1F861`, CPU `$5861`, len `1`, bytes `00`
- `menu_jizo`: ROM `0x1F862`, CPU `$5862`, len `16`, bytes `01 3c 43 41 4e 54 4f 20 44 45 20 4a 49 5a 4f 00`
- `menu_cargar`: ROM `0x1F872`, CPU `$5872`, len `9`, bytes `02 3c 43 41 52 47 41 52 00`
- `load_question`: ROM `0x1F87B`, CPU `$587B`, len `23`, bytes `01 c9 43 b5 bb ac 20 b1 b5 a9 a5 b2 a5 b3 20 5d a1 b2 a7 a1 b2 3f 00`
- `backup_error`: ROM `0x1F892`, CPU `$5892`, len `60`, bytes `01 4c af b3 20 a4 a1 b4 af b3 20 a7 b5 a1 b2 a4 a1 a4 af b3 00 ae af 20 b3 af ae 20 b6 bb ac a9 a4 af b3 cb 00 53 a5 20 5b af b2 b2 a1 b2 bb 20 a5 ac 20 a1 b2 5d a8 a9 b6 af cb ff`
- `jizo_prompt`: ROM `0x1F8CE`, CPU `$58CE`, len `30`, bytes `01 ca 49 ae b4 b2 af a4 b5 5d a5 20 a5 ac 00 5d a1 ae b4 af 20 a4 a5 20 4a a9 ba af 21 ff`
- `jizo_error`: ROM `0x1F8EC`, CPU `$58EC`, len `76`, bytes `01 ca 45 ac 20 5d a1 ae b4 af 20 a4 a5 00 4a a9 ba af 20 ae af 20 a5 b3 00 5d af b2 b2 a5 5d b4 af 21 fd fd fe 43 af ad 5e b2 b5 bc 5b a1 ac af 20 5b a9 a5 ae 00 a5 20 a9 ae b4 bc ae b4 a1 ac af 00 af b4 b2 a1 20 b6 a5 ba cb ff`

Espacio usado en zona libre: `256` bytes de `1992` disponibles.

## Punteros/código parcheados

- Tabla dificultad `$54AE`: apunta a `FÁCIL/NORMAL/DIFÍCIL/MUY DIFÍCIL`.
- Tabla opciones `$54EB`: apunta a `CANTO DE JIZO/CARGAR`.
- Tabla carga `$5501`: apunta a pregunta de carga + dificultad.
- Código password `CD10` y `CD47`: prompt Jizo relocalizado.
- Código error `CE5F`: error Jizo relocalizado.
- Código error backup `C58D/C591`: error de backup relocalizado.

## Validación estática

- Zona libre original comprobada como `FF` antes de escribir.
- Texto nuevo total: `256` bytes.
- No se pisa la tabla runtime/password de v02.
- IPS acumulativo generado contra ROM limpia.

## Regiones cambiadas en IPS

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x018EEB` len `1`
- `0x018EFF` len `1`
- `0x018F03` len `1`
- `0x01A58E` len `1`
- `0x01A592` len `1`
- `0x01A85E` len `1`
- `0x01A862` len `1`
- `0x01A956` len `8`
- `0x01A962` len `2`
- `0x01A968` len `2`
- `0x01AA47` len `1`
- `0x01AA4B` len `1`
- `0x01AA71` len `2`
- `0x01AA80` len `1`
- `0x01AA95` len `1`
- `0x01AB87` len `1`
- `0x01AB8C` len `1`
- `0x01AB98` len `1`
- `0x01AC56` len `2`
- `0x01AC5E` len `2`
- `0x01AD11` len `1`
- `0x01AD15` len `1`
- `0x01AD48` len `1`
- `0x01AD4C` len `1`
- `0x01AE60` len `1`
- `0x01AE64` len `1`
- `0x01BBB9` len `97`
- `0x01BC30` len `23`
- `0x01BD00` len `175`
- `0x01E18D` len `1`
- `0x01E18F` len `1`
- `0x01E191` len `1`
- `0x01E193` len `1`
- `0x01E195` len `3`
- `0x01E199` len `1`
- `0x01E19B` len `1`
- `0x01E19D` len `4`
- `0x01E1A2` len `1`
- `0x01E1A4` len `1`
- `0x01E1A6` len `1`
- `0x01E1A8` len `1`
- `0x01E1AA` len `3`
- `0x01E1AE` len `1`
- `0x01E1B0` len `1`
- `0x01E1B2` len `3`
- `0x01E1B6` len `1`
- `0x01E1B8` len `1`
- `0x01E1BA` len `1`
- `0x01E1BC` len `12`
- `0x01E1C9` len `3`
- `0x01E1CD` len `1`
- `0x01E1CF` len `1`
- `0x01E1D1` len `1`
- `0x01E1D3` len `1`
- `0x01E1D5` len `1`
- `0x01E1D7` len `1`
- `0x01E1D9` len `22`
- `0x01E1F0` len `1`
- `0x01E1F2` len `1`
- `0x01E1F4` len `1`
- `0x01E1F6` len `3`
- `0x01E1FA` len `1`
- `0x01E1FC` len `1`
- `0x01E1FE` len `1`
- `0x01E200` len `3`
- `0x01E204` len `3`
- `0x01E208` len `1`
- `0x01E20A` len `3`
- `0x01E20E` len `1`
- `0x01E210` len `1`
- `0x01E212` len `4`
- `0x01E217` len `3`
- `0x01E21B` len `3`
- `0x01E21F` len `7`
- `0x01E227` len `1`
- `0x01E229` len `1`
- `0x01E22B` len `3`
- `0x01E22F` len `3`
- `0x01E233` len `1`
- `0x01E235` len `10`
- `0x01E240` len `3`
- `0x01E244` len `11`
- `0x01E250` len `1`
- `0x01E252` len `1`
- `0x01E254` len `1`
- `0x01E256` len `7`
- `0x01E25E` len `5`
- `0x01E264` len `3`
- `0x01E268` len `3`
- `0x01E26C` len `5`
- `0x01E272` len `3`
- `0x01E276` len `3`
- `0x01E27A` len `3`
- `0x01E27E` len `5`
- `0x01E284` len `3`
- `0x01E288` len `5`
- `0x01E28E` len `2`
- `0x01F4AE` len `10`
- `0x01F4EB` len `4`
- `0x01F501` len `12`
- `0x01F838` len `149`
- `0x01F8CE` len `29`
- `0x01F8EC` len `75`
- `0x0252C9` len `10`
- `0x0252D6` len `8`
- `0x0252DF` len `10`
- `0x0252EC` len `41`
- `0x025316` len `90`
- `0x025371` len `100`
- `0x0253D7` len `69`
- `0x02541E` len `4`
- `0x025424` len `2`
- `0x025427` len `16`
- `0x025438` len `21`
- `0x02544E` len `5`
- `0x025454` len `4`
- `0x025459` len `5`
- `0x025461` len `46`
- `0x025490` len `46`
- `0x0254BF` len `20`
- `0x0254D4` len `57`
- `0x02550E` len `7`
- `0x025516` len `21`
- `0x02552C` len `15`
- `0x02553C` len `81`
- `0x02558E` len `3`
- `0x025592` len `62`
- `0x0255D1` len `3`
- `0x0255D8` len `20`
- `0x0255ED` len `56`
- `0x025626` len `57`
- `0x025660` len `166`
- `0x025707` len `13`
- `0x025715` len `14`
- `0x025724` len `47`
- `0x025754` len `1`
- `0x025756` len `19`
- `0x02576A` len `115`
- `0x0257DE` len `72`
- `0x025827` len `58`
- `0x025863` len `24`
- `0x02587C` len `21`
- `0x025892` len `25`
- `0x0258AC` len `1`
- `0x0258AE` len `2`
- `0x0258B2` len `25`
- `0x0258CC` len `2`
- `0x0258CF` len `144`
- `0x025960` len `19`
- `0x025974` len `23`
- `0x02598C` len `18`
- `0x02599F` len `12`
- `0x0259AC` len `25`
- `0x0259C6` len `3`
- `0x0259CA` len `39`
- `0x0259F2` len `3`
- `0x0259F6` len `25`
- `0x025A10` len `2`
- `0x025A13` len `19`
- `0x025A2C` len `19`
- `0x025A41` len `11`
- `0x025A4E` len `12`
- `0x025A5B` len `2`
- `0x025A5F` len `12`
- `0x025A6C` len `15`
- `0x025A7C` len `55`
- `0x025AB5` len `36`
- `0x025ADA` len `25`
- `0x025AF4` len `73`
- `0x025B3E` len `51`
- `0x025B72` len `59`
- `0x025BB2` len `16`
- `0x025BC3` len `10`
- `0x025BCE` len `5`
- `0x025BD4` len `9`
- `0x025BDE` len `14`
- `0x025BED` len `17`
- `0x025BFF` len `12`
- `0x025C0C` len `18`
- `0x025C1F` len `10`
- `0x025C2B` len `18`
- `0x025C3F` len `2`
- `0x025C42` len `5`
- `0x025C48` len `53`
- `0x025C7E` len `25`
- `0x025C98` len `43`
- `0x025CC4` len `145`
- `0x025D56` len `97`
- `0x025DB8` len `8`
- `0x025DC1` len `5`
- `0x025DC7` len `13`
- `0x025DD6` len `37`
- `0x025DFC` len `54`
- `0x025E33` len `15`
- `0x025E43` len `5`
- `0x025E49` len `85`
- `0x025E9F` len `38`
- `0x025EC6` len `83`
- `0x025F1A` len `25`
- `0x025F34` len `54`
- `0x025F6B` len `16`
- `0x025F7C` len `59`
- `0x025FB8` len `11`
- `0x025FC4` len `15`
- `0x025FD4` len `16`
- `0x025FE5` len `23`
- `0x025FFD` len `12`
- `0x02600A` len `26`
- `0x026025` len `28`
- `0x026042` len `4`
- `0x026047` len `138`
- `0x0260D2` len `17`
- `0x0260E4` len `78`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
- `0x02E2B3` len `2`
- `0x02E6B1` len `4`
- `0x02F8B5` len `125`
- `0x02F933` len `5`
- `0x02F939` len `16`
- `0x02F94A` len `102`
- `0x02F9B1` len `65`
- `0x02F9F3` len `35`
- `0x02FA17` len `23`
- `0x02FA30` len `20`
- `0x02FA45` len `20`
- `0x03DB6A` len `5`
- `0x03DB70` len `7`
- `0x03DB7A` len `13`
- `0x03DB8A` len `5`
- `0x03DB90` len `8`
- `0x03DB9A` len `15`
- `0x03DBAA` len `7`
- `0x03DBB2` len `22`
- `0x03DBCA` len `1`
- `0x03DBCD` len `3`
- `0x03DBD1` len `7`
- `0x03DBD9` len `7`
- `0x03DBE1` len `20`
- `0x03DBF6` len `41`
- `0x03DC21` len `36`
- `0x03DC46` len `17`
- `0x03DC58` len `35`
- `0x03DC7C` len `19`
- `0x03DC90` len `25`
- `0x03DCAA` len `30`
- `0x03DCC9` len `26`
- `0x03DCE5` len `26`
- `0x03DD00` len `51`
- `0x03DD34` len `4`
- `0x03DD39` len `36`
- `0x03DD5E` len `18`
- `0x03DD71` len `24`
- `0x03DD8D` len `24`
- `0x03DDA9` len `4`
- `0x03DDB0` len `6`
- `0x03DDB7` len `11`
- `0x03DDC7` len `2`
- `0x03DDCA` len `2`
- `0x03DDCF` len `2`
- `0x03DDD2` len `2`
- `0x03DDD7` len `5`
- `0x03DDE0` len `5`
- `0x03DDE6` len `7`
- `0x03DDEE` len `7`
- `0x03DDF6` len `2`
- `0x03DDFF` len `7`
- `0x03DE07` len `7`
- `0x03DE0F` len `7`
- `0x03DE19` len `7`
- `0x03DE21` len `2`
- `0x03DE24` len `6`
- `0x03DE2B` len `13`
- `0x03DE3C` len `6`
- `0x03DE43` len `2`
- `0x03DE48` len `5`
- `0x03DE4E` len `2`
- `0x041CB4` len `4`
- `0x041CB9` len `58`
- `0x041CF4` len `4`
- `0x041CF9` len `58`
- `0x042B1F` len `1`
- `0x042B24` len `2`
- `0x042B86` len `1`
- `0x042B88` len `5`
- `0x043F9B` len `84`

## Qué comprobar

1. Pantalla/selector anterior al password: que se lean `CANTO DE JIZO` y `CARGAR`.
2. Selector de carga: que se lea la pregunta y las dificultades.
3. Mensaje de backup inválido si puedes forzarlo/verlo.
4. Pantalla de password: si `¡Introduce el
canto de Jizo!` aparece completo o se sale de la caja.
5. Password incorrecto: si la primera página aparece como 3 líneas, espera/limpia y muestra la segunda página sin sobrescribir.
6. Confirmar que v02 no se ha roto: parrilla, opciones y navegación.
