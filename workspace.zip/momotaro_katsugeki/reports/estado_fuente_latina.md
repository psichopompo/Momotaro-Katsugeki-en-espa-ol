# Estado de la fuente latina

## Prueba v2 confirmada

La prueba `latin_full_test_v2` ha sido validada en emulador: la palabra `Acción` ya se visualiza correctamente.

Archivos de referencia actuales:

- ROM: `work/Momotarou Katsugeki (Japan) - latin_full_test_v2.pce`
- IPS: `work/momotaro_latin_full_test_v2.ips`
- Tabla: `work/charset_latin_full_v2.tbl`
- Vista previa: `images/latin_full_preview_v2.png`

## Hallazgo importante

El código `$A3`, usado inicialmente para la `c` minúscula, no es seguro en la rutina real del juego. En la prueba v1 el glyph estaba bien definido, pero en pantalla se dibujaba mal/desplazado.

Solución provisional validada:

- `$DB = c`
- `$A3 = reservado / no usar`

## Decisión de estilo provisional

- Mantener mayúsculas, números y signos originales del juego, porque son más gruesos y probablemente están diseñados así para mejorar la lectura.
- Adaptar las minúsculas nuevas a ese estilo: algo más gruesas y con línea base compatible con las mayúsculas originales.
- Mantener tildes visibles, no reducidas a un único píxel.

## Siguiente tarea

Preparar una prueba de set completo con:

```text
abcdefghijklmnopqrstuvwxyz
áéíóú ü ñ ç
ABCDEFGHIJKLMNOPQRSTUVWXYZ
ÁÉÍÓÚ Ü Ñ Ç
¿? ¡! 0123456789 200¤
.,:;… '-/()%&+ ºª
```

Objetivo: detectar otros códigos problemáticos antes de fijar la tabla definitiva.
