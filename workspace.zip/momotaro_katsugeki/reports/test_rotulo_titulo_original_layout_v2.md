# Test rótulo español con layout original del logo — v2

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v2.pce`

IPS: `Parches/momotaro_title_logo_spanish_original_layout_test_v2.ips`

Vista previa: `images/title_logo_spanish_original_layout_v2_preview.png`

## Cambio respecto a v1

La v1 codificaba los patrones como cuatro tiles BG 8x8. Eso era incorrecto para este stream.

La v2 codifica cada patrón como **sprite PCE 16x16 en orden VRAM real**:

```text
4 planos; cada plano = 16 filas x 2 bytes
```

Se mantiene intacta la lista original del logo japonés en ROM `0x2E2B0`.

## Datos

- Asset: `title_assets/title_logo_es_fullscreen.png`.
- Base visible usada: X=128, Y=88.
- Stream original: `0x252C8-0x2617A` (3763 bytes).
- Stream nuevo: `3636` bytes.
- Patrones: 64.
- Longitudes por patrón: min `16`, max `100`.

## Nota

Si la estructura sale bien, quedará ajustar paleta y quizá la cobertura de los extremos izquierdo/derecho, porque el layout original cubre aproximadamente x=7..246.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `2`
- `0x0252CC` len `9`
- `0x0252D6` len `4`
- `0x0252DB` len `12`
- `0x0252E9` len `6`
- `0x0252F0` len `127`
- `0x025370` len `57`
- `0x0253AA` len `121`
- `0x025424` len `2`
- `0x025427` len `5`
- `0x02542D` len `7`
- `0x025437` len `28`
- `0x025454` len `2`
- `0x025457` len `31`
- `0x025477` len `33`
- `0x02549A` len `51`
- `0x0254CF` len `225`
- `0x0255B1` len `37`
- `0x0255D7` len `20`
- `0x0255ED` len `56`
- `0x025626` len `6`
- `0x025630` len `13`
- `0x02563E` len `9`
- `0x02564B` len `117`
- `0x0256C1` len `80`
- `0x025712` len `30`
- `0x025731` len `75`
- `0x02577D` len `30`
- `0x02579C` len `15`
- `0x0257AC` len `34`
- `0x0257CF` len `31`
- `0x0257EF` len `20`
- `0x025807` len `97`
- `0x025869` len `61`
- `0x0258A7` len `82`
- `0x0258FA` len `6`
- `0x025901` len `84`
- `0x025956` len `17`
- `0x025968` len `5`
- `0x02596E` len `31`
- `0x02598E` len `8`
- `0x025997` len `44`
- `0x0259C4` len `9`
- `0x0259CE` len `6`
- `0x0259D5` len `2`
- `0x0259D8` len `21`
- `0x0259EE` len `6`
- `0x0259F9` len `19`
- `0x025A0D` len `2`
- `0x025A10` len `86`
- `0x025A67` len `15`
- `0x025A77` len `3`
- `0x025A7B` len `11`
- `0x025A87` len `26`
- `0x025AA2` len `7`
- `0x025AAA` len `45`
- `0x025AD8` len `38`
- `0x025AFF` len `28`
- `0x025B1C` len `141`
- `0x025BAA` len `28`
- `0x025BC7` len `2`
- `0x025BCA` len `3`
- `0x025BCE` len `30`
- `0x025BED` len `27`
- `0x025C09` len `55`
- `0x025C41` len `13`
- `0x025C4F` len `22`
- `0x025C66` len `20`
- `0x025C7B` len `87`
- `0x025CD3` len `56`
- `0x025D0C` len `76`
- `0x025D59` len `2`
- `0x025D5C` len `74`
- `0x025DA9` len `1`
- `0x025DAB` len `21`
- `0x025DC1` len `19`
- `0x025DD7` len `18`
- `0x025DEA` len `63`
- `0x025E2A` len `10`
- `0x025E35` len `9`
- `0x025E3F` len `113`
- `0x025EB1` len `130`
- `0x025F34` len `65`
- `0x025F76` len `16`
- `0x025F87` len `10`
- `0x025F92` len `33`
- `0x025FB4` len `25`
- `0x025FCE` len `129`
- `0x026050` len `25`
- `0x02606A` len `23`
- `0x026083` len `19`
- `0x026097` len `35`
- `0x0260BB` len `20`
- `0x0260D0` len `4`
- `0x0260D6` len `3`
- `0x0260DC` len `15`
- `0x0260EC` len `4`
- `0x0260F5` len `61`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
