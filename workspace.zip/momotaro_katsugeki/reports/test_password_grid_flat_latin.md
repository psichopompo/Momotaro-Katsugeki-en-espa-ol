# Password grid flat latin test

ROM: `Roms/Momotarou Katsugeki (Japan) - password_grid_flat_latin_test.pce`

IPS: `Parches/momotaro_password_grid_flat_latin_test.ips`

## Objetivo

Primera prueba de la Vía A: parchear el layout/tilemap de la pantalla de password para que muestre una parrilla plana de 64 símbolos latinos.

## Cambios

1. Se copia la fuente latina validada.
2. Se relocaliza la tabla runtime de símbolos a `0x1BBB9` / CPU `$DBB9`.
3. Se reemplazan los streams RLE de tilemap usados por la pantalla (`0x1E18C` y `0x1E290`) para colocar `0x100+index` en una parrilla 8x8.

## Parrilla esperada

```text
ABCDEFGH
IJKLMNÑO
PQRSTUVW
XYZabcde
fghijklm
nñopqrst
uvwxyz01
23456789
```

## Streams

- Low stream: 206 bytes de 260 disponibles.
- High stream: 12 bytes de 12 disponibles.

## Posición

- Filas tilemap: 7..14.
- Columnas tilemap: [5, 8, 11, 14, 17, 20, 23, 26].

## Qué comprobar

1. Que la parrilla aparece como 8x8 latina.
2. Que `Ñ` y `ñ` salen correctamente.
3. Que no quedan marcas de dakuten/handakuten.
4. Que el cursor puede moverse por la parrilla.
5. Que al introducir caracteres, el buffer inferior muestra el carácter elegido o al menos no se rompe.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x018EEB` len `1`
- `0x018EFF` len `1`
- `0x018F03` len `1`
- `0x01A85E` len `1`
- `0x01A862` len `1`
- `0x01BBB9` len `65`
- `0x01E18D` len `1`
- `0x01E18F` len `1`
- `0x01E191` len `3`
- `0x01E195` len `5`
- `0x01E19B` len `1`
- `0x01E19D` len `3`
- `0x01E1A1` len `6`
- `0x01E1A8` len `1`
- `0x01E1AA` len `3`
- `0x01E1B0` len `5`
- `0x01E1B6` len `3`
- `0x01E1BA` len `5`
- `0x01E1C0` len `3`
- `0x01E1C4` len `1`
- `0x01E1C6` len `2`
- `0x01E1C9` len `3`
- `0x01E1CD` len `1`
- `0x01E1CF` len `3`
- `0x01E1D3` len `3`
- `0x01E1D7` len `1`
- `0x01E1D9` len `3`
- `0x01E1DD` len `1`
- `0x01E1DF` len `3`
- `0x01E1E3` len `5`
- `0x01E1E9` len `1`
- `0x01E1EB` len `4`
- `0x01E1F0` len `1`
- `0x01E1F2` len `3`
- `0x01E1F6` len `1`
- `0x01E1F8` len `3`
- `0x01E1FC` len `1`
- `0x01E1FE` len `5`
- `0x01E204` len `9`
- `0x01E20E` len `3`
- `0x01E212` len `1`
- `0x01E214` len `2`
- `0x01E217` len `3`
- `0x01E21B` len `1`
- `0x01E21D` len `7`
- `0x01E225` len `1`
- `0x01E227` len `3`
- `0x01E22B` len `1`
- `0x01E22D` len `3`
- `0x01E231` len `5`
- `0x01E237` len `3`
- `0x01E23B` len `1`
- `0x01E23E` len `1`
- `0x01E240` len `3`
- `0x01E244` len `1`
- `0x01E246` len `3`
- `0x01E24A` len `1`
- `0x01E24C` len `17`
- `0x01E25E` len `5`
- `0x01E264` len `3`
- `0x01E268` len `3`
- `0x01E26C` len `5`
- `0x01E272` len `3`
- `0x01E276` len `3`
- `0x01E27A` len `3`
- `0x01E27E` len `5`
- `0x01E284` len `3`
- `0x01E288` len `5`
- `0x01E28E` len `2`
- `0x0252C9` len `10`
- `0x0252D6` len `8`
- `0x0252DF` len `10`
- `0x0252EC` len `41`
- `0x025316` len `90`
- `0x025371` len `100`
- `0x0253D7` len `69`
- `0x02541E` len `4`
- `0x025424` len `2`
- `0x025427` len `16`
- `0x025438` len `21`
- `0x02544E` len `5`
- `0x025454` len `4`
- `0x025459` len `5`
- `0x025461` len `46`
- `0x025490` len `46`
- `0x0254BF` len `20`
- `0x0254D4` len `57`
- `0x02550E` len `7`
- `0x025516` len `21`
- `0x02552C` len `15`
- `0x02553C` len `81`
- `0x02558E` len `3`
- `0x025592` len `62`
- `0x0255D1` len `3`
- `0x0255D8` len `20`
- `0x0255ED` len `56`
- `0x025626` len `57`
- `0x025660` len `166`
- `0x025707` len `13`
- `0x025715` len `14`
- `0x025724` len `47`
- `0x025754` len `1`
- `0x025756` len `19`
- `0x02576A` len `115`
- `0x0257DE` len `72`
- `0x025827` len `58`
- `0x025863` len `24`
- `0x02587C` len `21`
- `0x025892` len `25`
- `0x0258AC` len `1`
- `0x0258AE` len `2`
- `0x0258B2` len `25`
- `0x0258CC` len `2`
- `0x0258CF` len `144`
- `0x025960` len `19`
- `0x025974` len `23`
- `0x02598C` len `18`
- `0x02599F` len `12`
- `0x0259AC` len `25`
- `0x0259C6` len `3`
- `0x0259CA` len `39`
- `0x0259F2` len `3`
- `0x0259F6` len `25`
- `0x025A10` len `2`
- `0x025A13` len `19`
- `0x025A2C` len `19`
- `0x025A41` len `11`
- `0x025A4E` len `12`
- `0x025A5B` len `2`
- `0x025A5F` len `12`
- `0x025A6C` len `15`
- `0x025A7C` len `55`
- `0x025AB5` len `36`
- `0x025ADA` len `25`
- `0x025AF4` len `73`
- `0x025B3E` len `51`
- `0x025B72` len `59`
- `0x025BB2` len `16`
- `0x025BC3` len `10`
- `0x025BCE` len `5`
- `0x025BD4` len `9`
- `0x025BDE` len `14`
- `0x025BED` len `17`
- `0x025BFF` len `12`
- `0x025C0C` len `18`
- `0x025C1F` len `10`
- `0x025C2B` len `18`
- `0x025C3F` len `2`
- `0x025C42` len `5`
- `0x025C48` len `53`
- `0x025C7E` len `25`
- `0x025C98` len `43`
- `0x025CC4` len `145`
- `0x025D56` len `97`
- `0x025DB8` len `8`
- `0x025DC1` len `5`
- `0x025DC7` len `13`
- `0x025DD6` len `37`
- `0x025DFC` len `54`
- `0x025E33` len `15`
- `0x025E43` len `5`
- `0x025E49` len `85`
- `0x025E9F` len `38`
- `0x025EC6` len `83`
- `0x025F1A` len `25`
- `0x025F34` len `54`
- `0x025F6B` len `16`
- `0x025F7C` len `59`
- `0x025FB8` len `11`
- `0x025FC4` len `15`
- `0x025FD4` len `16`
- `0x025FE5` len `23`
- `0x025FFD` len `12`
- `0x02600A` len `26`
- `0x026025` len `28`
- `0x026042` len `4`
- `0x026047` len `138`
- `0x0260D2` len `17`
- `0x0260E4` len `78`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
- `0x02E2B3` len `2`
- `0x02E6B1` len `4`
- `0x02F8B5` len `125`
- `0x02F933` len `5`
- `0x02F939` len `16`
- `0x02F94A` len `102`
- `0x02F9B1` len `65`
- `0x02F9F3` len `35`
- `0x02FA17` len `23`
- `0x02FA30` len `20`
- `0x02FA45` len `20`
- `0x03DB6A` len `5`
- `0x03DB70` len `7`
- `0x03DB7A` len `13`
- `0x03DB8A` len `5`
- `0x03DB90` len `8`
- `0x03DB9A` len `15`
- `0x03DBAA` len `7`
- `0x03DBB2` len `22`
- `0x03DBCA` len `1`
- `0x03DBCD` len `3`
- `0x03DBD1` len `7`
- `0x03DBD9` len `7`
- `0x03DBE1` len `20`
- `0x03DBF6` len `41`
- `0x03DC21` len `36`
- `0x03DC46` len `17`
- `0x03DC58` len `35`
- `0x03DC7C` len `19`
- `0x03DC90` len `25`
- `0x03DCAA` len `30`
- `0x03DCC9` len `26`
- `0x03DCE5` len `26`
- `0x03DD00` len `51`
- `0x03DD34` len `4`
- `0x03DD39` len `4`
- `0x03DD3E` len `34`
- `0x041CB4` len `4`
- `0x041CB9` len `58`
- `0x041CF4` len `4`
- `0x041CF9` len `58`
- `0x042B86` len `1`
- `0x042B88` len `3`
