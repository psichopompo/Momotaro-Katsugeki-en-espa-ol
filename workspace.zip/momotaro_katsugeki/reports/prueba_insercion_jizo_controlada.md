# Prueba de inserción controlada — pantalla de Jizo/password

ROM: `Momotarou Katsugeki (Japan) - jizo_text_test.pce`

IPS: `momotaro_jizo_text_test.ips`

## Objetivo

Primera prueba de inserción de diálogo real usando la fuente latina validada, sin repunteo todavía.

Se han respetado los límites originales de los dos mensajes para no alterar posibles secuencias/punteros. Por eso se usa una adaptación más corta que la traducción final ideal.

## Mensajes parcheados

Original 1:

```text
じぞうのうたを いれるのじゃ!
```

Test español:

```text
Canto de Jizo!
```

Offset: `0x1F55A-0x1F56D`, longitud original 20 bytes.

Original 2:

```text
じぞうのうたが ちがっとるぞ!
ちゃんと かくにんして
もういちど いれなおすのじゃ!
```

Test español:

```text
¡Canto incorrecto!
Revísalo bien
Prueba otra vez.
```

Offset: `0x1F56E-0x1F5A4`, longitud original 55 bytes.

## Traducción final deseada

La versión final preferida sigue siendo:

```text
¡Introduce el canto de Jizo!
¡El canto de Jizo no es correcto!
Compruébalo bien
e inténtalo otra vez.
```

Esa versión no cabe en los espacios originales. Requerirá repunteo/reubicación cuando tengamos documentado el sistema de punteros de este bloque.

## Regiones cambiadas

- `0x01F55B` len `18`
- `0x01F56F` len `34`
- `0x01F593` len `6`
- `0x01F59A` len `10`
- `0x03DB6A` len `5`
- `0x03DB70` len `7`
- `0x03DB7A` len `13`
- `0x03DB8A` len `5`
- `0x03DB90` len `8`
- `0x03DB9A` len `15`
- `0x03DBAA` len `7`
- `0x03DBB2` len `22`
- `0x03DBCA` len `1`
- `0x03DBCD` len `3`
- `0x03DBD1` len `7`
- `0x03DBD9` len `7`
- `0x03DBE1` len `20`
- `0x03DBF6` len `41`
- `0x03DC21` len `36`
- `0x03DC46` len `17`
- `0x03DC58` len `35`
- `0x03DC7C` len `19`
- `0x03DC90` len `25`
- `0x03DCAA` len `30`
- `0x03DCC9` len `26`
- `0x03DCE5` len `26`
- `0x03DD00` len `51`
- `0x03DD34` len `4`
- `0x03DD39` len `4`
- `0x03DD3E` len `34`
- `0x041CB4` len `4`
- `0x041CB9` len `58`
- `0x041CF4` len `4`
- `0x041CF9` len `58`
- `0x042B86` len `1`
- `0x042B88` len `3`
