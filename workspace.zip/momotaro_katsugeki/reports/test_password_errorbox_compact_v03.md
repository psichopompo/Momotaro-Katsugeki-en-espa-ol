# Prueba v03 — bocadillo de error de Jizo compacto/ampliado

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_errorbox_compact_test.pce`

IPS:

`Parches/Pruebas/momotaro_traduccion_v03_errorbox_compact_test.ips`

## Objetivo

Ajustar el bocadillo central tras la prueba wide: menos ancho, más centrado visualmente, texto más alto y líneas compactas de 8 px para que quepa el mensaje completo sin scroll.

## Cambios

- Repointing de textos a zona libre, como en la prueba anterior.
- Caja central del error redibujada por tilemap: más estrecha que la prueba anterior (`left=7`, `right=27`).
- Se quitan 3 tiles por la derecha respecto a la prueba wide.
- Tabla de líneas del texto de error relocalizada y ampliada a 6 líneas con separación de 8 px (`$6E08,$6F08,$7008,$7108,$7208,$7308`).
- Texto de error sin scroll, repartido en líneas de 16 caracteres o menos:

```text
¡El canto de
Jizo no es
correcto!
Compruébalo bien
e inténtalo
otra vez.
```

El prompt superior `¡Introduce el canto de Jizo!` sigue pendiente de ampliación de caja superior; en esta prueba se mantiene en una línea para confirmar que sólo se arregla el error central.

## Asignaciones de texto

- `diff_facil`: ROM `0x1F838`, CPU `$5838`, len `8`
- `diff_normal`: ROM `0x1F840`, CPU `$5840`, len `9`
- `diff_dificil`: ROM `0x1F849`, CPU `$5849`, len `10`
- `diff_muy_dificil`: ROM `0x1F853`, CPU `$5853`, len `14`
- `empty`: ROM `0x1F861`, CPU `$5861`, len `1`
- `menu_jizo`: ROM `0x1F862`, CPU `$5862`, len `16`
- `menu_cargar`: ROM `0x1F872`, CPU `$5872`, len `9`
- `load_question`: ROM `0x1F87B`, CPU `$587B`, len `23`
- `backup_error`: ROM `0x1F892`, CPU `$5892`, len `60`
- `jizo_prompt`: ROM `0x1F8CE`, CPU `$58CE`, len `30`
- `jizo_error`: ROM `0x1F8EC`, CPU `$58EC`, len `74`

## Datos nuevos

- Stream RLE de caja central: ROM `0x1F940`, CPU `$5940`, len `91`.
- Tabla de 6 líneas compactas: ROM `0x1BDB0`, CPU `$DDB0`, len `12`.
- Espacio total usado en zona libre de bank `$0F`: hasta `0x1F99B`.

## Qué comprobar

1. Que la caja central ya no queda tan pegada al límite derecho.
2. Que el mensaje completo aparece en 6 líneas sin perder la última.
3. Que `Jizo` aparece completo.
4. Que `Compruébalo bien` respira mejor y no queda pegado al borde.
5. Que la cola/bocadillo sigue pendiente de ajuste con la estatua, pero no empeora demasiado.
6. El prompt superior probablemente seguirá cortándose: es conocido y será el siguiente objetivo.
7. Que v02 sigue intacta en parrilla/opciones.
