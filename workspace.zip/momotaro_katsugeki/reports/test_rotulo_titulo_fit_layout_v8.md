# Test rótulo español — v8 encajado al layout original

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_fit_layout_test_v8.pce`

IPS: `Parches/momotaro_title_logo_spanish_fit_layout_test_v8.ips`

Vista previa: `images/title_logo_spanish_fit_layout_v8_preview.png`

PNG intermedio: `title_assets/title_logo_es_fullscreen_fit_original_layout.png`

## Cambio v8

El layout original de sprites cubre aproximadamente 240 px de ancho. El asset entregado cubre 251 px y por eso se cortaba a ambos lados.

Esta prueba ajusta horizontalmente el rótulo de 251 px a 240 px, manteniendo altura, colores, posición vertical y máscara de melocotón.

No modifica la lista original salvo la posición del sprite separado del melocotón.

## Datos

- BBox original del asset: (2, 35, 253, 91).
- Nuevo ancho: 240 px, pegado en x=7.
- Stream: 3096 bytes de 3763.
- Peach bbox: (130,70)-(145,84), sprite (130,69).

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `10`
- `0x0252D5` len `9`
- `0x0252DF` len `8`
- `0x0252ED` len `58`
- `0x025328` len `20`
- `0x02533D` len `103`
- `0x0253A5` len `43`
- `0x0253D1` len `69`
- `0x025417` len `27`
- `0x025433` len `26`
- `0x02544E` len `5`
- `0x025454` len `4`
- `0x025459` len `5`
- `0x025461` len `29`
- `0x025480` len `7`
- `0x025488` len `150`
- `0x02551F` len `4`
- `0x025524` len `12`
- `0x025531` len `9`
- `0x02553C` len `94`
- `0x02559D` len `36`
- `0x0255C2` len `91`
- `0x02561E` len `19`
- `0x025632` len `21`
- `0x025649` len `61`
- `0x025688` len `51`
- `0x0256BE` len `17`
- `0x0256D0` len `10`
- `0x0256DC` len `47`
- `0x02570C` len `28`
- `0x025729` len `2`
- `0x02572D` len `173`
- `0x0257DB` len `63`
- `0x02581B` len `6`
- `0x025822` len `27`
- `0x02583E` len `59`
- `0x02587A` len `16`
- `0x02588B` len `47`
- `0x0258BC` len `16`
- `0x0258CF` len `15`
- `0x0258DF` len `5`
- `0x0258E5` len `21`
- `0x0258FB` len `39`
- `0x025923` len `14`
- `0x025932` len `1`
- `0x025934` len `97`
- `0x025996` len `94`
- `0x0259F5` len `4`
- `0x0259FA` len `14`
- `0x025A09` len `3`
- `0x025A0D` len `2`
- `0x025A10` len `13`
- `0x025A1E` len `9`
- `0x025A2C` len `19`
- `0x025A40` len `27`
- `0x025A5C` len `2`
- `0x025A5F` len `8`
- `0x025A6C` len `8`
- `0x025A78` len `12`
- `0x025A85` len `32`
- `0x025AA6` len `60`
- `0x025AE3` len `42`
- `0x025B0E` len `161`
- `0x025BB0` len `25`
- `0x025BCA` len `8`
- `0x025BD5` len `23`
- `0x025BED` len `3`
- `0x025BF1` len `11`
- `0x025BFD` len `34`
- `0x025C20` len `5`
- `0x025C2B` len `61`
- `0x025C69` len `20`
- `0x025C7E` len `48`
- `0x025CAF` len `65`
- `0x025CF1` len `14`
- `0x025D02` len `36`
- `0x025D27` len `11`
- `0x025D33` len `59`
- `0x025D6F` len `27`
- `0x025D8B` len `24`
- `0x025DA5` len `122`
- `0x025E20` len `26`
- `0x025E3B` len `25`
- `0x025E56` len `42`
- `0x025E81` len `45`
- `0x025EB2` len `19`
- `0x025EC6` len `29`
- `0x025EE4` len `53`
- `0x025F1A` len `25`
- `0x025F34` len `54`
- `0x025F6B` len `16`
- `0x025F7C` len `59`
- `0x025FB8` len `11`
- `0x025FC4` len `15`
- `0x025FD4` len `16`
- `0x025FE5` len `23`
- `0x025FFD` len `12`
- `0x02600A` len `26`
- `0x026025` len `28`
- `0x026042` len `4`
- `0x026047` len `138`
- `0x0260D2` len `17`
- `0x0260E4` len `78`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
- `0x02E2B3` len `2`
