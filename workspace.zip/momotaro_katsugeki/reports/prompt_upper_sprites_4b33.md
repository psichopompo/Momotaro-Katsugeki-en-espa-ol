# Prompt superior — sprites/lista $4B33 renderizados
ROM analizada: `/home/user/momotaro_katsugeki/Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_prep_ba8a_test.pce`
Lista relocalizada: ROM `0x1FA00`; entradas hasta FF: `51`.
## Imágenes
- Todas las entradas superiores en orden: `images/prompt_upper_sprites/all_top_entries_order.png`
- Sólo piezas de marco en orden: `images/prompt_upper_sprites/frame_pieces_order.png`
- Montaje completo texto+marco: `images/prompt_upper_sprites/assembled_prompt_box_and_text.png`
- Montaje sólo marco: `images/prompt_upper_sprites/assembled_frame_only.png`
## Formato de entrada
Cada entrada son 5 bytes: `[pattern offset][attr/palette][flags hi][x offset][y offset]`. Los offsets X/Y son con signo. En esta lista, el patrón base usado es aproximadamente `$1A4`; por tanto `0A -> 1AE`, etc.
## Entradas superiores
| idx | tipo | bytes | patrón | flags | xoff | yoff | screen X | screen Y | tamaño | flip |
|---:|---|---|---:|---:|---:|---:|---:|---:|---|---|
| 0 | texto | `0a 0e 01 b8 98` | `1AE` | `010E` | -72 | -104 | -16 | -40 | 32x16 | - |
| 1 | texto | `0c 0e 01 d8 98` | `1B0` | `010E` | -40 | -104 | 16 | -40 | 32x16 | - |
| 2 | texto | `0e 0e 01 f8 98` | `1B2` | `010E` | -8 | -104 | 48 | -40 | 32x16 | - |
| 3 | texto | `10 0e 01 18 98` | `1B4` | `010E` | 24 | -104 | 80 | -40 | 32x16 | - |
| 4 | texto | `12 0e 01 38 98` | `1B6` | `010E` | 56 | -104 | 112 | -40 | 32x16 | - |
| 5 | texto | `14 0e 01 58 98` | `1B8` | `010E` | 88 | -104 | 144 | -40 | 32x16 | - |
| 6 | texto | `16 0e 01 78 98` | `1BA` | `010E` | 120 | -104 | 176 | -40 | 32x16 | - |
| 7 | marco | `00 0e 01 b8 88` | `1A4` | `010E` | -72 | -120 | -16 | -56 | 32x16 | - |
| 8 | marco | `02 0e 01 d8 88` | `1A6` | `010E` | -40 | -120 | 16 | -56 | 32x16 | - |
| 9 | marco | `02 0e 01 f8 88` | `1A6` | `010E` | -8 | -120 | 48 | -56 | 32x16 | - |
| 10 | marco | `02 0e 01 18 88` | `1A6` | `010E` | 24 | -120 | 80 | -56 | 32x16 | - |
| 11 | marco | `02 0e 01 38 88` | `1A6` | `010E` | 56 | -120 | 112 | -56 | 32x16 | - |
| 12 | marco | `02 0e 01 58 88` | `1A6` | `010E` | 88 | -120 | 144 | -56 | 32x16 | - |
| 13 | marco | `00 0e 09 7f 88` | `1A4` | `090E` | 127 | -120 | 183 | -56 | 32x16 | H |
| 14 | marco | `04 0e 00 b8 98` | `1A8` | `000E` | -72 | -104 | -16 | -40 | 16x16 | - |
| 15 | marco | `04 0e 08 7f 98` | `1A8` | `080E` | 127 | -104 | 183 | -40 | 16x16 | H |
| 16 | marco | `00 0e 81 b8 a8` | `1A4` | `810E` | -72 | -88 | -16 | -24 | 32x16 | V |
| 17 | marco | `02 0e 81 d8 a8` | `1A6` | `810E` | -40 | -88 | 16 | -24 | 32x16 | V |
| 18 | marco | `02 0e 81 f8 a8` | `1A6` | `810E` | -8 | -88 | 48 | -24 | 32x16 | V |
| 19 | marco | `02 0e 81 18 a8` | `1A6` | `810E` | 24 | -88 | 80 | -24 | 32x16 | V |
| 20 | marco | `02 0e 81 38 a8` | `1A6` | `810E` | 56 | -88 | 112 | -24 | 32x16 | V |
| 21 | marco | `02 0e 81 58 a8` | `1A6` | `810E` | 88 | -88 | 144 | -24 | 32x16 | V |
| 22 | marco | `00 0e 89 7f a8` | `1A4` | `890E` | 127 | -88 | 183 | -24 | 32x16 | HV |
