# Prompt superior — pruebas descartadas

Objetivo: mostrar `¡Introduce el canto de Jizo!` sin duplicados ni residuos.

## Pruebas que NO funcionaron

- **Overlay CD98 / prompt_nav_test**: mostraba una segunda frase encima/detrás de la caja. Duplicaba el texto y dejaba residuos en la pantalla de error.
- **Overlay alineado / prompt_nav_align/overlay**: sólo movía el duplicado en Y; seguía habiendo doble texto y residuos.
- **Modificar lista `$402F` / `0x2E02F`**: no cambió el corte real del prompt (`¡Introduce el ca`).
- **Modificar lista `$426C` / `0x2E26C`**: no arregló el prompt y además corrompió la pantalla de título; descartada.
- **Modificar lista `$4A45` / `0x2EA45`**: sin cambios visibles en el prompt; sigue cortado en `ca`.
- **Relocalizar lista de prompt nueva**: no sirve si no sustituye a la lista real; sólo genera sprites adicionales y residuos.

## Pista válida

El método que funcionó para el error de Jizo fue localizar la lista real de sprites/chunks y ampliarla. Para el prompt todavía estamos buscando esa lista real.
