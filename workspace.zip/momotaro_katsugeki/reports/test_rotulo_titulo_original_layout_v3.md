# Test rótulo español con layout original del logo — v3

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v3.pce`

IPS: `Parches/momotaro_title_logo_spanish_original_layout_test_v3.ips`

Vista previa: `images/title_logo_spanish_original_layout_v3_preview.png`

## Cambio respecto a v1

La v1 codificaba los patrones como cuatro tiles BG 8x8. Eso era incorrecto para este stream.

La v3 corrige el orden de bits dentro de cada byte de patrón sprite. La comparación contra el logo japonés original indica que el pixel izquierdo corresponde al bit 0, no al bit 7.

Codifica cada patrón como **sprite PCE 16x16 en orden VRAM real**, con bit order invertido:

```text
4 planos; cada plano = 16 filas x 2 bytes
```

Se mantiene intacta la lista original del logo japonés en ROM `0x2E2B0`.

## Datos

- Asset: `title_assets/title_logo_es_fullscreen.png`.
- Base visible usada: X=128, Y=88.
- Stream original: `0x252C8-0x2617A` (3763 bytes).
- Stream nuevo: `3636` bytes.
- Patrones: 64.
- Longitudes por patrón: min `16`, max `100`.

## Nota

Si la estructura sale bien, quedará ajustar paleta y quizá la cobertura de los extremos izquierdo/derecho, porque el layout original cubre aproximadamente x=7..246.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `2`
- `0x0252CC` len `9`
- `0x0252D6` len `4`
- `0x0252DB` len `12`
- `0x0252E9` len `6`
- `0x0252F0` len `19`
- `0x025304` len `51`
- `0x025339` len `9`
- `0x025343` len `44`
- `0x025370` len `33`
- `0x025392` len `50`
- `0x0253C5` len `94`
- `0x025424` len `2`
- `0x025427` len `13`
- `0x025437` len `28`
- `0x025454` len `15`
- `0x025464` len `3`
- `0x025468` len `4`
- `0x02546D` len `9`
- `0x025477` len `33`
- `0x02549A` len `51`
- `0x0254CF` len `17`
- `0x0254E1` len `78`
- `0x025530` len `43`
- `0x02555C` len `84`
- `0x0255B1` len `37`
- `0x0255D7` len `20`
- `0x0255ED` len `56`
- `0x025626` len `6`
- `0x025630` len `13`
- `0x02563E` len `9`
- `0x02564B` len `22`
- `0x025662` len `94`
- `0x0256C1` len `80`
- `0x025712` len `106`
- `0x02577D` len `46`
- `0x0257AC` len `32`
- `0x0257CD` len `1`
- `0x0257CF` len `52`
- `0x025807` len `19`
- `0x02581B` len `32`
- `0x02583C` len `94`
- `0x02589B` len `54`
- `0x0258D2` len `94`
- `0x025931` len `51`
- `0x025965` len `40`
- `0x02598E` len `8`
- `0x025997` len `44`
- `0x0259C4` len `9`
- `0x0259CE` len `6`
- `0x0259D5` len `2`
- `0x0259D8` len `21`
- `0x0259EE` len `6`
- `0x0259F9` len `19`
- `0x025A0D` len `2`
- `0x025A10` len `61`
- `0x025A4E` len `24`
- `0x025A67` len `15`
- `0x025A77` len `3`
- `0x025A7B` len `11`
- `0x025A88` len `25`
- `0x025AA2` len `53`
- `0x025AD8` len `38`
- `0x025AFF` len `28`
- `0x025B1C` len `11`
- `0x025B28` len `48`
- `0x025B59` len `45`
- `0x025B87` len `34`
- `0x025BAA` len `28`
- `0x025BC7` len `2`
- `0x025BCA` len `3`
- `0x025BCE` len `13`
- `0x025BDC` len `16`
- `0x025BED` len `7`
- `0x025BF6` len `28`
- `0x025C13` len `82`
- `0x025C66` len `1`
- `0x025C68` len `91`
- `0x025CC4` len `7`
- `0x025CCC` len `63`
- `0x025D0C` len `65`
- `0x025D4E` len `13`
- `0x025D5C` len `74`
- `0x025DA9` len `1`
- `0x025DAB` len `21`
- `0x025DC1` len `19`
- `0x025DD7` len `93`
- `0x025E35` len `123`
- `0x025EB1` len `130`
- `0x025F34` len `93`
- `0x025F92` len `155`
- `0x02602E` len `33`
- `0x026050` len `25`
- `0x02606A` len `23`
- `0x026083` len `19`
- `0x026097` len `35`
- `0x0260BB` len `20`
- `0x0260D0` len `4`
- `0x0260D6` len `3`
- `0x0260DC` len `15`
- `0x0260EC` len `4`
- `0x0260F5` len `61`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
