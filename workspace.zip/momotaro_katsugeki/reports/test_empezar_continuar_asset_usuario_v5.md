# Test v5 `EMPEZAR / CONTINUAR` usando asset del usuario

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_spanish_asset_test_v5.pce`

IPS: `Parches/momotaro_start_options_spanish_asset_test_v5.ips`

## Cambio v5

La v4 seguía reordenando/fusionando partes. La hipótesis es que los valores de tile de la SAT necesitan saltar `$20` para apuntar al siguiente patrón de 16x16.

V5 usa 8 entradas estrechas de 16 px, con tile bytes:

```text
00 20 40 60 80 A0 C0 E0
```

## Datos

- Stream: ROM `0x2F8B5`, CPU `$78B5`, len `377`.
- Lens: `[50, 53, 54, 25, 50, 49, 52, 43]`.
- Lista 1: CPU `$5A30`, ROM `0x2FA30`.
- Lista 2: CPU `$5A59`, ROM `0x2FA59`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x018EEB` len `1`
- `0x018EFF` len `1`
- `0x018F03` len `1`
- `0x02E6B1` len `4`
- `0x02F8B5` len `125`
- `0x02F933` len `6`
- `0x02F93A` len `9`
- `0x02F944` len `115`
- `0x02F9B8` len `65`
- `0x02F9FA` len `25`
- `0x02FA14` len `26`
- `0x02FA30` len `40`
- `0x02FA59` len `40`
