# Prueba v03 — bocadillo de error de Jizo calculado a 5 líneas

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_errorbox_calc5_test.pce`

IPS:

`Parches/Pruebas/momotaro_traduccion_v03_errorbox_calc5_test.ips`

## Objetivo

Revertir la prueba compacta de 8 px entre líneas y volver al espaciado real del motor. Esta prueba usa una caja menos ancha que la wide, un tile más alta y texto repartido en 5 líneas calculadas por palabras.

## Cambios

- Repointing de textos a zona libre, como en la prueba anterior.
- Caja central redibujada con `left=7`, `right=28`, `top=11`, `bottom=21`.
- Es bastante menos ancha que la prueba wide y un tile más alta que la compacta anterior.
- Se mantiene el espaciado vertical real del motor: 16 px entre líneas.
- Tabla de líneas: `$6E08,$7008,$7208,$7408,$7608`.
- Texto de error sin scroll, repartido en 5 líneas:

```text
¡El canto de Jizo
no es correcto!
Compruébalo bien
e inténtalo
otra vez.
```

El prompt superior `¡Introduce el canto de Jizo!` sigue pendiente de ampliación de caja superior; en esta prueba se mantiene en una línea para confirmar que sólo se arregla el error central.

Nota técnica: reducir visualmente el dibujo de los glifos no aumenta por sí solo el número de caracteres por línea, porque esta rutina sigue avanzando 8 px por carácter. Para meter más texto en 4 líneas haría falta un renderer compacto/proporcional o convertir el mensaje en gráfico; esta prueba evita eso y usa 5 líneas normales.

## Asignaciones de texto

- `diff_facil`: ROM `0x1F838`, CPU `$5838`, len `8`
- `diff_normal`: ROM `0x1F840`, CPU `$5840`, len `9`
- `diff_dificil`: ROM `0x1F849`, CPU `$5849`, len `10`
- `diff_muy_dificil`: ROM `0x1F853`, CPU `$5853`, len `14`
- `empty`: ROM `0x1F861`, CPU `$5861`, len `1`
- `menu_jizo`: ROM `0x1F862`, CPU `$5862`, len `16`
- `menu_cargar`: ROM `0x1F872`, CPU `$5872`, len `9`
- `load_question`: ROM `0x1F87B`, CPU `$587B`, len `23`
- `backup_error`: ROM `0x1F892`, CPU `$5892`, len `60`
- `jizo_prompt`: ROM `0x1F8CE`, CPU `$58CE`, len `30`
- `jizo_error`: ROM `0x1F8EC`, CPU `$58EC`, len `74`

## Datos nuevos

- Stream RLE de caja central: ROM `0x1F940`, CPU `$5940`, len `99`.
- Tabla de 5 líneas: ROM `0x1BDB0`, CPU `$DDB0`, len `10`.
- Espacio total usado en zona libre de bank `$0F`: hasta `0x1F9A3`.

## Qué comprobar

1. Que ya no se sobrescribe el texto.
2. Que aparecen las 5 líneas completas, incluida `otra vez.`.
3. Que `Jizo` aparece completo.
4. Que el bocadillo ya no se va tanto a la derecha como el wide.
5. Que el margen derecho de `Compruébalo bien` queda aceptable.
6. Que la estatua sigue pendiente de ajuste, pero el bocadillo/texto ya se pueden evaluar.
7. El prompt superior probablemente seguirá cortándose: es conocido y será el siguiente objetivo.
8. Que v02 sigue intacta en parrilla/opciones.
