# Prueba v03 — prompt superior preparación extendida

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_prep_extend_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_prompt_prep_extend_test.ips`

## Objetivo

Usar la lista real que sí afectó al prompt (`$4B33`), pero correctamente: sin cortarla, sin overlay y relocalizándola completa a bank `$0F` para no pisar datos contiguos.

Texto:

```text
¡Introduce el canto de Jizo!
```

## Cambio prompt

- Texto del prompt relocalizado en ROM `0x1F880`, CPU `$5880`.
- Lista original `$4B33` parseada completa.
- Parte superior ampliada a 7 chunks de texto y marco ancho, manteniendo la alineación de v2. Además se amplía la preparación/limpieza de patrones: `C355 LDY #$08 -> #$0C`, para intentar preparar también `1B8..1BB`.
- Resto de la lista preservado.
- Lista relocalizada en ROM `0x1FA00`, CPU `$5A00`, len `256`.
- `CC2D` apunta ahora a bank `$0F` / `$5A00`.
- Preparación de patrones ampliada: ROM `0x1A356`, `$08 -> $0C`.
- No se toca `CD98` ni se crea overlay.
- Bank `$17` padding `0x2F8B5-0x30000` intacto.

## Incluye de base

- Error de Jizo bueno + limpieza expandida.
- Navegación DOWN corregida:
  - U/V -> 0
  - T -> Z
  - t -> z
  - z -> 9

## Qué comprobar

1. Si el prompt se ve como una sola frase o sigue duplicado.
2. Si se ve completo o dónde se corta.
3. Si al pasar a la pantalla de error ya no queda residuo del prompt.
4. Que el error de Jizo sigue limpio/completo.
5. Que la navegación especial sigue bien.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
