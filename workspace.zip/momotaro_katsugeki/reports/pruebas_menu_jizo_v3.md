# Pruebas v3 — prompt de título y texto de Jizo

## Prompt de título v3

ROM: `work/Momotarou Katsugeki (Japan) - start_prompt_tilde_test_v3.pce`

IPS: `work/momotaro_start_prompt_tilde_test_v3.ips`

Texto:

```text
PULSA BOTÓN RUN
```

Cambios frente a v2:

- La `O` acentuada se reduce ligeramente.
- La tilde se baja a filas visibles y se dibuja con color de letra/sombra normal en vez de color 3.

Si sigue sin verse, habrá que aceptar `BOTON`, usar `PULSA RUN`, o rediseñar el tile con una `O` aún más baja/pequeña.

Regiones cambiadas:

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`

## Texto Jizo/password v3

ROM: `work/Momotarou Katsugeki (Japan) - jizo_text_test_v3.pce`

IPS: `work/momotaro_jizo_text_test_v3.ips`

Textos de prueba:

```text
¡Canto de Jizo!

¡Canto erróneo!
Revísalo bien.
Reinténtalo.
```

Cambios frente a v2:

- Se añade puntuación final donde cabe.
- Se sustituye `Prueba de nuevo` por `Reinténtalo.` para que quepa con punto en una línea segura.

Regiones cambiadas:

- `0x01F55B` len `9`
- `0x01F565` len `8`
- `0x01F56F` len `53`
- `0x03DB6A` len `5`
- `0x03DB70` len `7`
- `0x03DB7A` len `13`
- `0x03DB8A` len `5`
- `0x03DB90` len `8`
- `0x03DB9A` len `15`
- `0x03DBAA` len `7`
- `0x03DBB2` len `22`
- `0x03DBCA` len `1`
- `0x03DBCD` len `3`
- `0x03DBD1` len `7`
- `0x03DBD9` len `7`
- `0x03DBE1` len `20`
- `0x03DBF6` len `41`
- `0x03DC21` len `36`
- `0x03DC46` len `17`
- `0x03DC58` len `35`
- `0x03DC7C` len `19`
- `0x03DC90` len `25`
- `0x03DCAA` len `30`
- `0x03DCC9` len `26`
- `0x03DCE5` len `26`
- `0x03DD00` len `51`
- `0x03DD34` len `4`
- `0x03DD39` len `4`
- `0x03DD3E` len `34`
- `0x041CB4` len `4`
- `0x041CB9` len `58`
- `0x041CF4` len `4`
- `0x041CF9` len `58`
- `0x042B86` len `1`
- `0x042B88` len `3`
