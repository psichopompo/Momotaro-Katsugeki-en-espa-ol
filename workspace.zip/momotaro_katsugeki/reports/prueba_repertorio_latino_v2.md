# Prueba de repertorio latino completo v2

ROM: `Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce`

IPS: `momotaro_latin_charset_test_v2.ips`

Tabla: `charset_latin_charset_test_v2.tbl`

Vista previa: `images/latin_charset_test_v2_preview.png`

## Cambios respecto a v1

La prueba v1 reveló que estos bytes de texto directos no son seguros:

- `$A2` — usado como `b` en v1, se remapea internamente.
- `$A3` — usado como `c` en la primera prueba, se remapea internamente.
- `$B0` — usado como `p` en v1, se remapea internamente.

En v2 se prueban códigos alternativos mediante la tabla ASCII:

- `$5B = b` → glyph `$A2`
- `$5D = c` → glyph `$A3`
- `$5E = p` → glyph `$B0`
- `$5F = Ç` → glyph `$DE`

`$5C` queda reservado porque el juego lo usa como conmutador/escape de tabla. `$DE/$DF` quedan reservados como bytes de texto por dakuten/handakuten, aunque sus glyphs pueden reutilizarse si se accede mediante tabla.

## Texto incluido

```text
abcdefghijklmn / opqrstuvwxyz / áéíóú ü ñ ç
ABCDEFGHIJKLM / NOPQRSTUVWXYZ / ÁÉÍÓÚ Ü Ñ Ç
¿? ¡! 012345 / 6789 200¤ / .,:;… '-/()% 
&+ ºª
```

## Regiones cambiadas

- `0x01F078` len `124`
- `0x01F0F5` len `11`
- `0x01F101` len `10`
- `0x03DB6A` len `5`
- `0x03DB70` len `7`
- `0x03DB7A` len `13`
- `0x03DB8A` len `5`
- `0x03DB90` len `8`
- `0x03DB9A` len `15`
- `0x03DBAA` len `7`
- `0x03DBB2` len `22`
- `0x03DBCA` len `1`
- `0x03DBCD` len `3`
- `0x03DBD1` len `7`
- `0x03DBD9` len `7`
- `0x03DBE1` len `20`
- `0x03DBF6` len `41`
- `0x03DC21` len `36`
- `0x03DC46` len `17`
- `0x03DC58` len `35`
- `0x03DC7C` len `19`
- `0x03DC90` len `25`
- `0x03DCAA` len `30`
- `0x03DCC9` len `26`
- `0x03DCE5` len `26`
- `0x03DD00` len `51`
- `0x03DD34` len `4`
- `0x03DD39` len `4`
- `0x03DD3E` len `34`
- `0x041CB4` len `4`
- `0x041CB9` len `58`
- `0x041CF4` len `4`
- `0x041CF9` len `58`
- `0x042B86` len `1`
- `0x042B88` len `3`
