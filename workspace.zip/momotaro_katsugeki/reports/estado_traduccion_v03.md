# Traducción acumulativa v03

ROM:

`Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce`

IPS:

`Parches/momotaro_traduccion_v03.ips`

## Base

Incluye todo lo confirmado en `v02`:

- Título: `MOMOTARO EN ACCIÓN`.
- Prompt de título: `PULSA BOTÓN RUN`.
- Menú: `EMPEZAR` / `CONTINUAR`.
- Parrilla latina de password.
- Opciones del password:
  - `ADELANTE`
  - `ATRÁS`
  - `ESPACIO`
  - `BORRAR`
  - `FIN`
- Buffer con puntos/slashes.
- Corrección de inserción desde `q` en adelante.

## Añadido/confirmado en v03

### Error de canto de Jizo

Mensaje confirmado:

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

Cambios técnicos confirmados:

- Viewport de texto ampliado a 5 columnas x 4 líneas.
- Limpieza ampliada para evitar residuos al repetir errores o volver desde endings.
- Bocadillo central ampliado/centrado y limpio.
- Rabillo correctamente alineado.

### Prompt superior de password

Texto confirmado:

```text
¡Introduce el canto de Jizo!
```

Cambios técnicos confirmados:

- Lista `$4B33` relocalizada y ampliada.
- Preparación/limpieza real de patrones del prompt ampliada:
  - `BA8A: LDY #$09 -> LDY #$0D`.
- Marco superior reconstruido y cerrado.
- Signos `¡` y `¿` corregidos por inversión de `!` y `?`.

### Navegación password

Ajustes confirmados:

```text
U/V + abajo -> 0
T   + abajo -> Z
t   + abajo -> z
z   + abajo -> 9
```

### Passwords secretos probados

Confirmados como funcionales con la parrilla latina:

```text
wCpeIfP     -> Ending muy difícil
cJQIep      -> Ending normal
GoFIBM      -> Ending difícil
rGAPad      -> Ending fácil
BqdGlCIWÑI  -> Sound test
BqdGlDWÑI   -> Graphics test
```

## Confirmación

El usuario confirmó la última prueba (`traduccion_v03_prompt_frame_close_corners_fix_test`) con:

> ¡Sííííí! Por fin. Buen trabajo. Además está perfectamente centrado todo.
