# v04 main selector box probe

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_main_selector_box_probe.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v04_main_selector_box_probe.ips`

## Objetivo

Primera prueba cautelosa: tocar sólo el selector inicial `CANTO DE JIZO / CARGAR`.

No se toca la pantalla de carga ni la dificultad. No se cambian los strings. Sólo se amplia horizontalmente la lista de sprites del marco/ventana del estado 1.

## Cambios

- Lista original estado 1: CPU `$4AEE`.
- Nueva lista: CPU `$5A59`, ROM `0x2FA59`, len `41`.
- Puntero en tabla `$4AB9` estado 1: `0x2EABB-0x2EABC` -> `$5A59`.

## Qué comprobar

1. En el selector inicial, si la caja de `CANTO DE JIZO / CARGAR` se ensancha.
2. Si aparece más texto de `CANTO DE JIZO` o sigue cortado igual.
3. Que la pantalla de dificultad sigue igual.
4. Que la pantalla de carga no cambia todavía.
5. Que no hay corrupción en título ni password.

## Cambios contra base de prueba

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
