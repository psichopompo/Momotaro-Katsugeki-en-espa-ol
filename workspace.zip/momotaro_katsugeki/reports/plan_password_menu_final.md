# Plan para finalizar menú/pantallas de password

Estado base acumulativo confirmado: `traduccion_v02`.

## Criterio

No vamos a traducir estos textos “como quepan”. La limitación de espacio se arreglará mediante relocalización/repointing de textos y, si hace falta, ampliando/recolocando cajas de texto.

## Bloques localizados

### Selector principal de password / load

ROM original: `0x1F4AE-0x1F501` (`83` bytes)

Este bloque contiene punteros internos y textos:

- tabla de punteros a modos/dificultades en CPU `$54AE`:
  - `$54B8` = `かんたん\もーど`
  - `$54C4` = `ふつう \もーど`
  - `$54D0` = `むずかし\もーど`
  - `$54DD` = `げろげろもーど`
  - `$54EA` = entrada vacía/auxiliar
- tabla de punteros a opciones principales en CPU `$54EB`:
  - `$54EF` = `じぞうのうた`
  - `$54FA` = `ろーど`

Traducciones previstas:

```text
FÁCIL
NORMAL
DIFÍCIL
MUY DIFÍCIL

CANTO DE JIZO
CARGAR
```

### Selector de partida guardada / load

ROM original: `0x1F501-0x1F55A` (`89` bytes)

Contiene:

- pointer `$550D` = `どれを ろーど しますか`
- punteros reutilizados a modos/dificultades
- texto de error de backup RAM desde `$551D`:
  - `\ばっくあっぷらむ\の ないようが ただしく ありません \ふぁいる\を さくじょ します!`

Traducciones previstas:

```text
¿Qué partida quieres cargar?

Los datos guardados no son válidos.
Se borrará el archivo.
```

Podría ajustarse a:

```text
El archivo de guardado no es válido.
Se borrará.
```

si la caja/pantalla concreta necesita menos líneas, pero la prioridad es ampliar/repointar antes de recortar.

### Prompt de canto de Jizo

ROM original: `0x1F55A-0x1F56E` (`20` bytes)

Original:

```text
じぞうのうたを いれるのじゃ!
```

Traducción final deseada:

```text
¡Introduce el canto de Jizo!
```

Problema: el texto español no cabe ni en bytes ni visualmente en la caja superior japonesa actual. Requiere repointing y probablemente ampliar/recolocar la caja superior.

### Error de canto de Jizo

ROM original: `0x1F56E-0x1F5A5` (`55` bytes)

Original:

```text
じぞうのうたが ちがっとるぞ!
ちゃんと かくにんして
もういちど いれなおすのじゃ!
```

Traducción final deseada:

```text
¡El canto de Jizo no es correcto!
Compruébalo bien
e inténtalo otra vez.
```

Problema: excede el espacio original. Requiere repointing; quizá también ajustar caja/lineado si se desborda visualmente.

## Espacio libre útil

En el mismo banco donde están estos textos hay una zona libre larga:

```text
0x1F838-0x20000  = 1992 bytes FF libres aprox.
```

Es la candidata principal para relocalizar textos sin cambiar bancos.

## Referencias de código/punteros ya vistas

### Selector principal

La rutina alrededor de `C4E2` lee punteros desde `$54AE,X` para los modos/dificultades.

La rutina alrededor de `C4FA` lee punteros desde `$54EB,X` para las opciones principales.

### Selector load

La rutina alrededor de `C52D` lee punteros desde `$5501,X` para textos de load/slots.

La rutina alrededor de `C583` usa directo `$551D` para el mensaje de error de backup RAM.

## Próximo trabajo técnico

1. Crear un reinserter específico para estos textos.
2. Escribir las traducciones largas en `0x1F838+`.
3. Parchear punteros internos:
   - `$54AE` para modos,
   - `$54EB` para `CANTO DE JIZO` / `CARGAR`,
   - `$5501` / `$550D` para selector de load,
   - directo `$551D` si hace falta para error de backup RAM.
4. Probar visualmente si las cajas actuales bastan.
5. Si no bastan, localizar y ampliar/recolocar las cajas de texto antes de cerrar v03.

## Riesgos

- El prompt `¡Introduce el canto de Jizo!` probablemente necesitará caja superior más ancha.
- Los mensajes de error largos pueden necesitar más líneas o una caja diferente.
- Las rutinas de load pueden construir líneas mezclando texto + número/dificultad; hay que conservar esos campos para no romper el selector de partida.

## Resultado de la prueba wrap v03

La prueba `traduccion_v03_password_texts_wrap_test` confirmó que el repointing funciona, pero también confirmó que el enfoque de sólo partir líneas no basta.

Observaciones del usuario:

- La caja superior de `¡Introduce el canto de Jizo!` sólo permite una línea visible. Si el texto se parte en dos, la segunda línea suena/dibuja internamente pero no se ve.
- El mensaje `¡El canto de Jizo no es correcto!` partido en varias líneas cabe, pero al continuar con la frase siguiente, ésta sobrescribe la anterior en vez de limpiar/paginar correctamente.
- Conclusión: antes de depender de scroll/wrap, hay que ampliar las cajas gráficas y la zona real de texto.

Comparación aproximada de longitud:

```text
じぞうのうたが ちがっとるぞ!  ≈ 15 caracteres visibles
¡El canto de Jizo no es correcto! = 32 caracteres contando espacios/signos
```

La frase española necesita más del doble de anchura si se quiere leer de forma natural.

## Nuevo enfoque acordado

1. Ampliar caja gráfica y área real de texto.
2. Dejar al menos 1 tile de margen respirando antes del borde derecho.
3. Después aplicar wrap por palabras sobre la nueva anchura real.
4. Sólo usar paginación/scroll cuando la caja ampliada siga sin bastar.
5. Este trabajo servirá como prototipo para convertir bocadillos verticales de aldeanos a horizontales.
