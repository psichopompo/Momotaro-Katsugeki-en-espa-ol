# Nota — `?` usado como espacio en password

No se debe convertir globalmente el signo `?` en un espacio vacío.

## Riesgo

El signo `?` puede usarse en otros contextos del juego:

- diálogos normales;
- preguntas del quiz;
- menús;
- textos de ayuda;
- fuente latina validada (`¿?`).

Si se borra el glyph global o se cambia la tabla general, romperíamos esos usos.

## Objetivo correcto

Modificar sólo la representación del `espacio insertado` en la pantalla de password.

Opciones seguras:

1. Identificar el código interno que `いれる` inserta en el buffer de password y cambiar sólo su render en esa pantalla.
2. Si ese código reutiliza el glyph global de `?`, parchear la rutina de impresión de password para que en ese contexto dibuje un tile vacío.
3. Si existe una tabla específica para la pantalla de password, cambiar sólo esa entrada de la tabla.
4. Mantener intacto el `?` normal de la fuente general.

## Prueba necesaria

Antes de tocar nada:

1. Localizar el valor exacto que se inserta al pulsar `いれる`.
2. Ver si ese valor se usa también en otros contextos.
3. Hacer una prueba con un marcador temporal sólo en la pantalla de password.
4. Confirmar que los `?` normales siguen funcionando en diálogos/quiz.

Conclusión: `ESPACIO` debe verse vacío sólo en la pantalla de password, no se debe eliminar el signo de interrogación global.
