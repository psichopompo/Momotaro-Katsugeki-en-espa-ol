# Password grid flat logic test

ROM: `Roms/Momotarou Katsugeki (Japan) - password_grid_flat_logic_test.pce`

IPS: `Parches/momotaro_password_grid_flat_logic_test.ips`

## Objetivo

Segundo paso de la Vía A. Además de cambiar visualmente el tilemap, se parchea la lógica de navegación/selección para que use una parrilla 8x8 plana.

## Cambios

- Fuente latina validada.
- Tabla runtime de 64 símbolos en `0x1BBB9`.
- Tilemap plano 8x8.
- Tabla de offsets `CC61`: `00 08 10 18 20 28 30 38`.
- Tabla de valores `CC82`: `01..40` en orden row-major.
- Límites de navegación: filas `0..7`, columnas `0..7`.

## Parrilla esperada

```text
ABCDEFGH
IJKLMNÑO
PQRSTUVW
XYZabcde
fghijklm
nñopqrst
uvwxyz01
23456789
```

## Qué comprobar

1. Si el cursor ya se mueve sólo por las 64 letras visibles.
2. Si al seleccionar A/B/C... se insertan los caracteres correctos.
3. Si desaparece la columna invisible de la izquierda.
4. Si el buffer inferior deja de mostrar caracteres basura arriba.

Nota: en esta prueba la columna derecha (`ADELANTE/ATRÁS/...`) queda inalcanzable o rota; se arreglará después. El objetivo es sólo alinear parrilla visual y lógica.

## Regiones cambiadas

- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
- `0x{off:06X}` len `{len(buf)}`
