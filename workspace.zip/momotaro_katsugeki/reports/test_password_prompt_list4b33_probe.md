# Prueba v03 — prompt superior probe lista $4B33

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_list4b33_probe.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_prompt_list4b33_probe.ips`

## Objetivo

Descartar el overlay/duplicado del prompt superior. Esta prueba NO añade sprites nuevos en CD98. En su lugar modifica otra lista candidata que empieza con los mismos cuatro chunks, CPU `$4B33`, ROM `0x2EB33`.

Texto:

```text
¡Introduce el canto de Jizo!
```

## Cambio prompt

- Texto del prompt relocalizado en ROM `0x1F880`, CPU `$5880`.
- Lista candidata `$4B33` modificada para 7 chunks en una sola línea:
  - patrones offset `$0A,$0C,$0E,$10,$12,$14,$16`.
  - X offsets `$98,$B8,$D8,$F8,$18,$38,$58`.
- No se toca `CD98` ni se crea overlay. Esta prueba es diagnóstica: si desaparece/rompe parte del marco, es aceptable para saber si la lista interviene.
- Bank `$17` padding `0x2F8B5-0x30000` intacto.

## Incluye de base

- Error de Jizo bueno + limpieza expandida.
- Navegación DOWN corregida:
  - U/V -> 0
  - T -> Z
  - t -> z
  - z -> 9

## Qué comprobar

1. Si el prompt se ve como una sola frase o sigue duplicado.
2. Si se ve completo o dónde se corta.
3. Si al pasar a la pantalla de error ya no queda residuo del prompt.
4. Que el error de Jizo sigue limpio/completo.
5. Que la navegación especial sigue bien.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
