# Prueba v02 — columna de opciones del password

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v02_opciones_test.pce`

IPS de prueba acumulativo contra ROM limpia:

`Parches/Pruebas/momotaro_traduccion_v02_opciones_test.ips`

Preview estático:

`images/password_options_v02_preview.png`

## Criterio de organización

`traduccion_v01` queda como única versión confirmada en `Roms/` y `Parches/`. Esta v02 está en `Pruebas`; si se confirma, se promocionará a:

```text
Roms/Momotarou Katsugeki (Japan) - traduccion_v02.pce
Parches/momotaro_traduccion_v02.ips
```

## Objetivo

Añadir la columna de opciones del password:

```text
ADELANTE
ATRÁS
ESPACIO
BORRAR
FIN
```

Como no caben con letras 8x8 normales en la zona derecha, esta prueba usa tiles compactos de dos letras por tile, dibujados con una mini fuente 3x5.

## Layout de la parrilla preservado

```text
A B C D E F G a b c d e f g
H I J K L M N h i j k l m n
Ñ O P Q R S T ñ o p q r s t
U V W X Y Z · u v w x y z ·
· · 0 1 2 3 4 5 6 7 8 9 · ·
```

## Opciones visuales/lógicas

```text
ADELANTE: ['AD', 'EL', 'AN', 'TE'] -> $F0
ATRÁS: ['AT', 'RÁ', 'S'] -> $F1
ESPACIO: ['ES', 'PA', 'CI', 'O'] -> $F2
BORRAR: ['BO', 'RR', 'AR'] -> $F3
FIN: ['FI', 'N'] -> $F4
```

Valores de lógica original:

- `$F0` = ADELANTE.
- `$F1` = ATRÁS.
- `$F2` = ESPACIO / insertar espacio (`$FF`) desplazando caracteres.
- `$F3` = BORRAR.
- `$F4` = FIN.

## Cambios técnicos

- La tabla runtime de la pantalla se amplía: alfabeto `1..64`, punto `$41`, slash `$42`, opciones compactas `$43..$52`.
- La tabla de selección se relocaliza de `$DC00` a `$DD00` porque ahora hay 10 filas lógicas.
- Se restauran filas lógicas 5..9 para opciones con valores `$F0..$F4`.
- Se amplía de forma controlada la ruta ASCII de `AAB4` para que los source bytes `$66..$75` puedan mapearse a glyphs compactos `$E0..$EF`.
- Los slashes estáticos del buffer se mantienen.
- El parche `CB97: CMP #$41` se mantiene para evitar la ruta dakuten/handakuten con valores latinos.

## Validación estática

- Option chunks: `16`.
- Tabla ASCII extendida: `70` bytes en ROM `0x43F9B` / CPU `$BF9B`.
- Runtime table: `84` bytes en `0x1BBB9`, termina en `0x1BC0D`.
- Selection table: `174` bytes en `0x1BD00` / CPU `$DD00`.
- Low stream RLE: `196` / `260` bytes.
- High stream RLE: `12` / `12` bytes.
- Values table: `140` bytes.

## Qué comprobar

1. Que las cinco opciones se ven a la derecha y son legibles.
2. Que el cursor puede llegar a ellas.
3. Que ADELANTE mueve el cursor del buffer a la derecha.
4. Que ATRÁS mueve el cursor del buffer a la izquierda.
5. Que ESPACIO inserta el espacio/separador como antes.
6. Que BORRAR borra.
7. Que FIN intenta validar el password.
8. Que la parrilla aceptada no se ha roto.
