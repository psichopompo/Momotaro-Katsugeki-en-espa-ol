# Prueba v03 — error de Jizo ajustado y desplazado

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_bubblefit_shift_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_error_text4_bubblefit_shift_test.ips`

## Base

Parte de `traduccion_v02` y conserva el viewport 5x4 que ya permitió ver las cuatro líneas completas.

## Texto fijo

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

## Cambios

- Ventanilla de texto: 5 columnas x 4 líneas en bank `$0F`, como la prueba exitosa.
- Quinta columna con offset `$7F`.
- Bloque completo desplazado aproximadamente 8 px a la izquierda y 16 px arriba.
- Texto: `LDX #$50 -> #$48`, `LDY #$68 -> #$58`.
- Bocadillo original no se modifica in-place, pero se usa un stream relocalizado con el mismo tamaño que la prueba buena, desplazado:
  - left = 8, right = 27.
  - top = 11, bottom = 19.
  - rabillo en la misma posición relativa del bocadillo.
- Estatua/Momotaro: `X #$2C -> #$24`, `Y #$78 -> #$68`.

## Validación

- Bank `$17` no se toca: `0x2F8B5-0x30000` idéntico a v02.
- Lista original `0x2EC10-0x2EC4D` intacta.
- Stream original de bocadillo `0x1E29C-0x1E2DF` intacto; se usa una copia ampliada en `0x1F970`.
- Viewport seguro en `0x1F900`.
- Texto/línea stride en zona libre segura.

## Medidas buscadas

- La prueba anterior ya cubría las cuatro líneas y el usuario la dio como bastante buena.
- Esta prueba sólo refina composición: desplazar todo el conjunto a la izquierda y hacia arriba sin cambiar el texto.
- El desplazamiento por tilemap sólo permite múltiplos de 8 px para el bocadillo; se prueba -8 px X y -16 px Y como aproximación segura.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Que las cuatro líneas siguen completas.
3. Que el conjunto estatua+bocadillo+texto queda mejor centrado horizontalmente.
4. Que subirlo 16 px no lo deja demasiado alto.
5. Que los márgenes internos del texto siguen correctos.
6. Que estatua/rabillo siguen encajando.
