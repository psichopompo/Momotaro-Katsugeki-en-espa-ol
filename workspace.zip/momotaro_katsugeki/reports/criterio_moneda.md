# Criterio para símbolo de dinero

## Observación nueva

El usuario ha confirmado que el carácter de dinero aparece también al recoger la moneda que sueltan los enemigos. Por tanto, no conviene sustituir `両` por un icono de moneda: sería redundante visualmente, porque aparecería una moneda/moneda-icono justo al coger una moneda.

## Criterio recomendado

Mantener el concepto de moneda histórica japonesa, pero romanizado.

Opciones:

### En HUD / tiendas / cantidades compactas

Usar una abreviatura de un solo carácter:

```text
R
```

Ejemplos:

```text
203R
200R
3000R
```

Interpretación: `R` = `ryō`.

Ventajas:

- Ocupa lo mismo o casi lo mismo que `両`.
- No parece un resto japonés sin traducir.
- No usa `$`, que rompe ambientación.
- No usa `¥`, que remite al yen moderno.
- No usa icono de moneda, que sería redundante al recoger monedas.

### En diálogos y mensajes largos

Usar `ryō` o `ryo` según disponibilidad de fuente.

Preferencia si añadimos macrón:

```text
Has conseguido 100 ryō.
```

Alternativa sin macrón:

```text
Has conseguido 100 ryo.
```

### En mensajes muy cortos

```text
+100R
100R
```

## Pendiente técnico

1. Localizar si `両` es glyph de fuente, tile de HUD o gráfico independiente según contexto.
2. Comprobar si el mismo carácter se usa en:
   - HUD,
   - tiendas,
   - mensajes de obtención,
   - drops de enemigos.
3. Decidir si se reemplaza por `R` globalmente en esos contextos o si hay varias fuentes/tilemaps.
4. Si se usa `ryō`, añadir `ō` a la tabla latina o escribir `ryo`.

## Decisión provisional

- No usar icono de moneda.
- No usar `$` ni `¥` salvo que más adelante se decida por razones de espacio.
- Usar `R` en UI compacta.
- Usar `ryō/ryo` en texto narrativo si cabe.
