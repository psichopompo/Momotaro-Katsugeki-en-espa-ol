# Test rótulo español con layout original del logo — v4

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_original_layout_test_v4.pce`

IPS: `Parches/momotaro_title_logo_spanish_original_layout_test_v4.ips`

Vista previa: `images/title_logo_spanish_original_layout_v4_preview.png`

## Cambio respecto a v1

La v1 codificaba los patrones como cuatro tiles BG 8x8. Eso era incorrecto para este stream.

La v4 corrige el orden de bytes de cada fila de sprite: en la VRAM/SAT real el primer byte de la palabra corresponde a la mitad derecha y el segundo a la mitad izquierda.

Codifica cada patrón como **sprite PCE 16x16 en orden VRAM real**:

```text
4 planos; cada plano = 16 filas x 2 bytes
```

Se mantiene intacta la lista original del logo japonés en ROM `0x2E2B0`.

## Datos

- Asset: `title_assets/title_logo_es_fullscreen.png`.
- Base visible usada: X=128, Y=88.
- Stream original: `0x252C8-0x2617A` (3763 bytes).
- Stream nuevo: `3636` bytes.
- Patrones: 64.
- Longitudes por patrón: min `16`, max `100`.

## Nota

Si la estructura sale bien, quedará ajustar paleta y quizá la cobertura de los extremos izquierdo/derecho, porque el layout original cubre aproximadamente x=7..246.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `2`
- `0x0252CC` len `9`
- `0x0252D6` len `4`
- `0x0252DB` len `12`
- `0x0252E9` len `6`
- `0x0252F0` len `47`
- `0x025320` len `31`
- `0x025341` len `12`
- `0x02534E` len `12`
- `0x02535B` len `70`
- `0x0253A2` len `16`
- `0x0253B3` len `72`
- `0x0253FC` len `26`
- `0x025417` len `9`
- `0x025421` len `2`
- `0x025424` len `7`
- `0x02542C` len `9`
- `0x025437` len `44`
- `0x025464` len `8`
- `0x02546D` len `9`
- `0x025477` len `33`
- `0x02549A` len `51`
- `0x0254CF` len `119`
- `0x025547` len `41`
- `0x025571` len `99`
- `0x0255D5` len `41`
- `0x0255FF` len `45`
- `0x025630` len `13`
- `0x02563E` len `9`
- `0x02564B` len `22`
- `0x025662` len `188`
- `0x02571F` len `87`
- `0x025777` len `5`
- `0x02577D` len `81`
- `0x0257CF` len `40`
- `0x0257F8` len `11`
- `0x025807` len `283`
- `0x025923` len `48`
- `0x025954` len `58`
- `0x02598F` len `7`
- `0x025997` len `32`
- `0x0259B8` len `11`
- `0x0259C4` len `9`
- `0x0259CE` len `6`
- `0x0259D5` len `24`
- `0x0259EE` len `6`
- `0x0259F9` len `19`
- `0x025A0D` len `2`
- `0x025A10` len `50`
- `0x025A43` len `27`
- `0x025A5F` len `50`
- `0x025A92` len `69`
- `0x025AD8` len `21`
- `0x025AEE` len `23`
- `0x025B06` len `7`
- `0x025B0F` len `46`
- `0x025B3E` len `11`
- `0x025B4A` len `16`
- `0x025B5B` len `78`
- `0x025BAA` len `15`
- `0x025BBA` len `12`
- `0x025BC7` len `6`
- `0x025BCE` len `8`
- `0x025BD7` len `10`
- `0x025BE2` len `14`
- `0x025BF1` len `33`
- `0x025C13` len `76`
- `0x025C60` len `57`
- `0x025C9A` len `25`
- `0x025CB4` len `61`
- `0x025CF3` len `1`
- `0x025CF5` len `84`
- `0x025D4A` len `17`
- `0x025D5C` len `47`
- `0x025D8C` len `26`
- `0x025DA9` len `10`
- `0x025DB4` len `12`
- `0x025DC1` len `19`
- `0x025DD7` len `223`
- `0x025EB7` len `90`
- `0x025F12` len `21`
- `0x025F28` len `78`
- `0x025F77` len `26`
- `0x025F92` len `32`
- `0x025FB3` len `130`
- `0x026036` len `25`
- `0x026050` len `24`
- `0x026069` len `10`
- `0x026074` len `13`
- `0x026083` len `12`
- `0x026090` len `35`
- `0x0260B4` len `2`
- `0x0260B7` len `24`
- `0x0260D0` len `4`
- `0x0260D6` len `3`
- `0x0260DC` len `15`
- `0x0260EC` len `4`
- `0x0260F5` len `61`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
