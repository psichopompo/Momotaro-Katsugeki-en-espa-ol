# Prompt superior — causa estructural del corte/artefactos

## Contexto

Se analizó con el core PC Engine instrumentado (`beetle-pce-fast-libretro`) la ROM de prueba:

```text
Roms/Pruebas/Anteriores/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_reloc4b33_v2_test.pce
```

Rango VRAM vigilado:

```text
0x6B80..0x6EFF
```

Este rango cubre los chunks/patrones proyectados por `$4B33`:

```text
1AE 1B0 1B2 1B4 1B6 1B8 1BA
```

## Resultado clave

Los chunks no fallan por el marco ni por la lista `$4B33`.

El fallo aparece porque la rutina que prepara/limpia el área de patrones sólo inicializa hasta `1B7`. Los chunks `1B8..1BB` reciben sólo escrituras parciales de glyphs encima de datos no preparados.

## Evidencia del log

En el frame `157`, antes de escribir los glyphs visibles, aparece una preparación masiva:

```text
1AE: 64 writes
1AF: 64 writes
1B0: 64 writes
1B1: 64 writes
1B2: 64 writes
1B3: 64 writes
1B4: 64 writes
1B5: 64 writes
1B6: 64 writes
1B7: 64 writes
```

Los valores escritos en esta fase son esencialmente:

```text
0x0000 y 0xFFFF
```

Es decir, una plantilla/limpieza del bloque de patrones, no texto concreto.

Después, los glyphs se escriben en tandas de 8 words por medio patrón:

```text
1AE: frames 185/190
1AF: frames 195/200
1B0: frames 205/210
1B1: frames 215/220
1B2: frames 225/230
1B3: frames 235/240
1B4: frames 245/250
1B5: frames 255/260
1B6: frames 265/270
1B7: frames 275/280
1B8: frames 285/290
1B9: frames 295/300
1BA: frames 305/310
1BB: frames 315/320
```

Pero para `1B8..1BB` **no existe** la preparación completa previa. Sólo hay la escritura parcial de glyphs.

## Rutina responsable de la preparación

La rutina relevante está en bank `$0D`:

```text
CPU C2FE
ROM 0x1A2FE
```

Fragmento clave:

```asm
C355: LDY #$08
C357: LDA #$00
C359: JSR $FC43
C35C: LDA #$FF
C35E: JSR $FC43
C361: LDA #$FF
C363: JSR $FC43
C366: LDA #$00
C368: JSR $FC43
C36B: DEY
C36C: BNE $C357
```

`FC43` escribe 16 words del valor de `A` a VRAM:

```asm
FC43: LDX #$10
FC45: STA $0002
FC48: STA $0003
FC4B: DEX
FC4C: BNE $FC45
FC4E: RTS
```

Por tanto, este bloque construye una plantilla de patrones repitiendo grupos de:

```text
16 words 0x0000
16 words 0xFFFF
16 words 0xFFFF
16 words 0x0000
```

La instrumentación confirma que esta fase cubre `1AE..1B7`, pero no `1B8..1BB`.

## Tabla de direcciones base

La rutina usa una tabla en CPU `$EC04`, que corresponde a la ROM:

```text
ROM 0x000C04
```

Contenido inicial relevante:

```text
84 6B   -> $6B84
84 6D   -> $6D84
84 6F   -> $6F84
```

Estos son puntos de trabajo/linea para el motor de texto en VRAM.

## Rutinas que escriben los glyphs

Las escrituras parciales de glyphs pasan por rutinas del bank `$0C`:

```text
D6BF
D6EC..D711
D720..D734
```

Estas rutinas sí llegan a escribir datos sobre `1B8..1BB`, pero sólo como escritura parcial de glyphs: no limpian ni construyen el bloque completo.

## Conclusión

La lista `$4B33` sólo proyecta patrones.

El problema real está en que la fase de preparación/plantilla no cubre todos los patrones que ahora queremos proyectar.

```text
Proyectamos: 1AE..1BA
Preparación completa: 1AE..1B7
Sin preparación completa: 1B8..1BB
```

Por eso `de J` y `izo!` arrastran basura.

## Próximo parche lógico

No tocar posiciones ni marco todavía.

Primero ampliar la preparación de `C2FE` para que cubra también:

```text
1B8
1B9
1BA
1BB
```

La zona a preparar debe pasar de aproximadamente:

```text
1AE..1B7
```

a:

```text
1AE..1BB
```

El candidato evidente es el contador:

```asm
C355: LDY #$08
```

pero antes de modificarlo conviene verificar cómo encaja con el avance de VRAM y la tabla `$EC04`, porque puede afectar también al cambio/scroll de líneas del motor de texto.
