# Pruebas v2 — prompt de título y texto de Jizo

## Prompt de título con tilde reforzada

ROM: `work/Momotarou Katsugeki (Japan) - start_prompt_tilde_test_v2.pce`

IPS: `work/momotaro_start_prompt_tilde_test_v2.ips`

Texto:

```text
PULSA BOTÓN RUN
```

Cambio frente a v1: se refuerza el glyph de `Ó` en la fuente de título. La limitación es que esta fuente de 8x8 no tiene espacio real por encima; por tanto se intenta hacer la tilde más visible dentro del mismo tile.

Regiones cambiadas:

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`

## Texto Jizo/password v2

ROM: `work/Momotarou Katsugeki (Japan) - jizo_text_test_v2.pce`

IPS: `work/momotaro_jizo_text_test_v2.ips`

Objetivo: evitar el auto-wrap que cortaba `incorrecto!` y hacía que `Revísalo bien` sobreescribiera la parte sobrante.

Textos de prueba:

```text
¡Canto de Jizo!

¡Canto erróneo!
Revísalo bien
Prueba de nuevo
```

Cada línea está limitada a 15 caracteres o menos, que parece ser el ancho seguro del bocadillo pequeño.

La traducción final elegida sigue siendo:

```text
¡Introduce el canto de Jizo!
¡El canto de Jizo no es correcto!
Compruébalo bien
e inténtalo otra vez.
```

Esa versión requerirá repunteo/reubicación y/o bocadillo más ancho.

Regiones cambiadas:

- `0x01F55B` len `9`
- `0x01F565` len `8`
- `0x01F56F` len `53`
- `0x03DB6A` len `5`
- `0x03DB70` len `7`
- `0x03DB7A` len `13`
- `0x03DB8A` len `5`
- `0x03DB90` len `8`
- `0x03DB9A` len `15`
- `0x03DBAA` len `7`
- `0x03DBB2` len `22`
- `0x03DBCA` len `1`
- `0x03DBCD` len `3`
- `0x03DBD1` len `7`
- `0x03DBD9` len `7`
- `0x03DBE1` len `20`
- `0x03DBF6` len `41`
- `0x03DC21` len `36`
- `0x03DC46` len `17`
- `0x03DC58` len `35`
- `0x03DC7C` len `19`
- `0x03DC90` len `25`
- `0x03DCAA` len `30`
- `0x03DCC9` len `26`
- `0x03DCE5` len `26`
- `0x03DD00` len `51`
- `0x03DD34` len `4`
- `0x03DD39` len `4`
- `0x03DD3E` len `34`
- `0x041CB4` len `4`
- `0x041CB9` len `58`
- `0x041CF4` len `4`
- `0x041CF9` len `58`
- `0x042B86` len `1`
- `0x042B88` len `3`
