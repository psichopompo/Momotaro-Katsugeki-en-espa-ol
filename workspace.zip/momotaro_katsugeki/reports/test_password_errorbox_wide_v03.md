# Prueba v03 — bocadillo de error de Jizo ampliado

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_errorbox_wide_test.pce`

IPS:

`Parches/Pruebas/momotaro_traduccion_v03_errorbox_wide_test.ips`

## Objetivo

Probar el enfoque nuevo: ampliar caja/área real antes de depender de scroll. Esta prueba se centra en el bocadillo central del error de canto de Jizo.

## Cambios

- Repointing de textos a zona libre, como en la prueba anterior.
- Caja central del error redibujada por tilemap: de `17x7` tiles aprox. a `24x10` tiles aprox.
- Área útil buscada: unas 21-22 columnas, dejando margen derecho.
- Tabla de líneas del texto de error relocalizada y ampliada a 4 líneas (`$7008,$7208,$7408,$7608`).
- Texto de error sin scroll, repartido en 4 líneas:

```text
¡El canto de Jizo no
es correcto!
Compruébalo bien
e inténtalo otra vez.
```

El prompt superior `¡Introduce el canto de Jizo!` sigue pendiente de ampliación de caja superior; en esta prueba se mantiene en una línea para confirmar que sólo se arregla el error central.

## Asignaciones de texto

- `diff_facil`: ROM `0x1F838`, CPU `$5838`, len `8`
- `diff_normal`: ROM `0x1F840`, CPU `$5840`, len `9`
- `diff_dificil`: ROM `0x1F849`, CPU `$5849`, len `10`
- `diff_muy_dificil`: ROM `0x1F853`, CPU `$5853`, len `14`
- `empty`: ROM `0x1F861`, CPU `$5861`, len `1`
- `menu_jizo`: ROM `0x1F862`, CPU `$5862`, len `16`
- `menu_cargar`: ROM `0x1F872`, CPU `$5872`, len `9`
- `load_question`: ROM `0x1F87B`, CPU `$587B`, len `23`
- `backup_error`: ROM `0x1F892`, CPU `$5892`, len `60`
- `jizo_prompt`: ROM `0x1F8CE`, CPU `$58CE`, len `30`
- `jizo_error`: ROM `0x1F8EC`, CPU `$58EC`, len `74`

## Datos nuevos

- Stream RLE de caja central: ROM `0x1F940`, CPU `$5940`, len `91`.
- Tabla de 4 líneas: ROM `0x1BDB0`, CPU `$DDB0`, len `8`.
- Espacio total usado en zona libre de bank `$0F`: hasta `0x1F99B`.

## Qué comprobar

1. Que la caja central del error es más ancha/alta.
2. Que el mensaje de error completo cabe sin sobrescrituras.
3. Que queda margen derecho y no pasa lo de `bien` pegado al borde.
4. Si la cola/bocadillo no pisa mal a Momotarou.
5. El prompt superior probablemente seguirá cortándose: es conocido y será el siguiente objetivo.
6. Que v02 sigue intacta en parrilla/opciones.
