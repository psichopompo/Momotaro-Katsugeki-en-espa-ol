# Prueba v03 — error de Jizo shift4 + limpieza completa

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_bubblefit_shift4_clear_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_error_text4_bubblefit_shift4_clear_test.ips`

## Base

Parte de `traduccion_v02` y conserva el viewport 5x4 que ya permitió ver las cuatro líneas completas.

## Texto fijo

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

## Cambios

- Ventanilla de texto: 5 columnas x 4 líneas en bank `$0F`, como la prueba exitosa.
- Quinta columna con offset `$7F`.
- Rabillo corregido: ahora sube con el bocadillo (`top+3/top+4`) y no queda en la posición vertical antigua.
- Ajuste fino respecto a shift3:
  - estatua 2 px a la izquierda (`X #$1F -> #$1D`).
  - texto 3 px a la derecha (`X #$43 -> #$46`).
  - bocadillo 2 px a la izquierda mediante scroll de fondo (`<$35 = #$02`).
- Bocadillo original no se modifica in-place, pero se usa un stream relocalizado con el mismo tamaño que la prueba buena.
  - left = 8, right = 27.
  - top = 11, bottom = 19.
  - rabillo en la misma posición relativa del bocadillo.
  - Esto mueve el bocadillo 1 tile a la derecha respecto a shift2. El tilemap trabaja en pasos de 8 px; si necesitamos exactamente 4 px, habrá que hacer tiles de borde desplazados medio tile.
- Estatua/Momotaro: `X #$1D`, `Y #$68`.

## Limpieza de residuos

La prueba aceptada visualmente podía dejar residuos al repetir un password erróneo. Causa probable: la rutina original `CE35` sólo limpia el área de patrones de texto suficiente para 3 líneas x 4 sprites. Nuestra ventanilla usa 4 líneas x 5 sprites.

Parche aplicado:

```asm
CE53: CPY #$18  ; original
CE53: CPY #$28  ; nuevo, limpia 40 bloques/patrones
```

Esto debe limpiar la zona expandida antes de redibujar el mensaje, tanto tras repetir error como tras volver de endings.

## Validación

- Bank `$17` no se toca: `0x2F8B5-0x30000` idéntico a v02.
- Lista original `0x2EC10-0x2EC4D` intacta.
- Stream original de bocadillo `0x1E29C-0x1E2DF` intacto; se usa una copia ampliada en `0x1F970`.
- Viewport seguro en `0x1F900`.
- Stub de scroll BG: ROM `0x1BDC0` / CPU `$DDC0`.
- Limpieza expandida de patrones de texto: ROM `0x1AE54`, valor `$28`.
- Texto/línea stride en zona libre segura.

## Medidas buscadas

- La prueba anterior ya cubría las cuatro líneas y el usuario la dio como bastante buena.
- Esta prueba sólo refina composición: desplazar todo el conjunto a la izquierda y hacia arriba sin cambiar el texto.
- El bocadillo necesitaba 2 px a la izquierda; como el tilemap va en tiles, se usa scroll BG local de 2 px para esta pantalla.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Que las cuatro líneas siguen completas.
3. Que el conjunto estatua+bocadillo+texto queda mejor centrado horizontalmente.
4. Que subirlo 16 px no lo deja demasiado alto.
5. Que los márgenes internos del texto siguen correctos.
6. Que el rabillo ya está alineado verticalmente con el bocadillo.
7. Que el bocadillo queda 2 px más a la izquierda que en shift3.
8. Que el texto, movido 3 px a la derecha, sigue sin salirse y respira mejor.
