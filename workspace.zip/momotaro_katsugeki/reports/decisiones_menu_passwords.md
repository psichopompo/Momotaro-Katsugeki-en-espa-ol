# Decisiones actualizadas — menú inicial y passwords

## Passwords: alfabeto de 64 símbolos

Decisión: usar 64 caracteres latinos para sustituir la parrilla de 64 hiragana:

- 27 mayúsculas: `A-Z` + `Ñ`
- 27 minúsculas: `a-z` + `ñ`
- 10 números: `0-9`

Total: `64`.

No se considera necesario evitar por completo letras parecidas (`O/o/0`, `I/l/1`, etc.), ya que el jugador selecciona desde una parrilla visual y puede reintentar la password tantas veces como quiera. Aun así, en la fuente se cuidarán especialmente:

- `i` minúscula con punto visible.
- `I` mayúscula con posible serif para distinguirla.
- `0` algo distinto de `O` si el diseño lo permite.

## Texto folclórico de Jizō

Se decide conservar la referencia a Jizō en la pantalla de password.

Texto original localizado:

```text
じぞうのうたを いれるのじゃ!
じぞうのうたが ちがっとるぞ!
ちゃんと かくにんして
もういちど いれなおすのじゃ!
```

Traducción elegida:

```text
¡Introduce el canto de Jizo!
¡El canto de Jizo no es correcto!
Compruébalo bien
e inténtalo otra vez.
```

Motivo: conserva la referencia folclórica a Jizo y al “canto”, pero mantiene el verbo funcional `introducir`, que es lo que expresa el japonés `いれる` (`ireru`).

Nota: se usará `Jizo` sin macrón para evitar añadir `ō`, salvo que más adelante decidamos añadir ese glyph.

## Opciones de la derecha en password

Originales:

```text
すすむ
もどる
いれる
けす
おわり
```

Traducción revisada tras probar la pantalla:

```text
ADELANTE
ATRÁS
INTRODUCIR
BORRAR
FIN
```

Notas funcionales:

- `すすむ` mueve el cursor hacia delante/derecha por los caracteres ya introducidos; por tanto `ADELANTE` es más claro que `SEGUIR`.
- `もどる` mueve hacia atrás/izquierda por los caracteres ya introducidos; por tanto `ATRÁS` es más claro que `VOLVER`.
- `いれる` sólo actúa sobre un carácter ya introducido y lo convierte en `?`. Funcionalidad exacta pendiente de documentar; mantenemos provisionalmente `INTRODUCIR` hasta entenderlo mejor.
- `けす` borra un carácter: `BORRAR`.
- `おわり` envía/finaliza la password, no sale de la pantalla: `FIN` es mejor que `SALIR`.

Observación técnica: `INTRODUCIR` y `ADELANTE` son largos. Puede requerir desplazar la columna, usar fuente compacta o editar esa zona como gráfico/tilemap.

## Opciones del menú inicial

Preferencia:

```text
EMPEZAR / COMENZAR
CONTINUAR
```

Se priorizará `EMPEZAR / CONTINUAR` por claridad. `COMENZAR` queda como alternativa si visualmente encaja mejor.

## Estado técnico de HAJIMETE / TSUZUGI

Se confirma la hipótesis: no parecen cadenas de texto normales. El código del título usa datos de sprites/tilemap en banco físico `$17`.

Puntos de interés:

- Código en banco `$0C` alrededor de CPU `$8E9D` y `$8EC3`.
- Datos en banco `$17`, CPU `$4281` y `$429B` aprox.
- Offset ROM aproximado: `0x2E281` y `0x2E29B`.

Es probable que haya listas de piezas gráficas, y que el resaltado se haga por paleta/atributo más que con un gráfico duplicado completo.

## Siguiente enfoque

1. Dejar preparada la tabla de password de 64 símbolos, pero posponer la validación de passwords hasta tener acceso cómodo a passwords generadas en el juego.
2. Continuar con menú inicial: traducir `PUSH RUN BUTTON`, luego editar `HAJIMETE / TSUZUGI` como gráficos/sprites.
3. Después pasar a diálogos legibles y extracción/inserción real.
