# Prueba técnica 01 — fuente latina y signos españoles

## Archivos generados

- ROM parcheada de prueba: `work/Momotarou Katsugeki (Japan) - latin_test.pce`
- Parche IPS: `work/momotaro_latin_test.ips`
- Vista previa aproximada: `images/latin_test_preview.png`
- Script generador: `tools/make_latin_test_patch.py`
- Tabla preliminar: `work/charset_latin_test.tbl`

## Objetivo

Comprobar que se pueden añadir caracteres latinos con signos españoles antes de empezar la traducción masiva.

La prueba modifica el primer bloque de texto de la casa inicial para mostrar:

```text
¿CAÑA?
 ÁÉÍÓÚ Ü Ñ
 áéíóú ü ñ ¡!
```

El texto se ha metido dentro del hueco del primer mensaje original, sin repuntear todavía, para que sea una prueba segura y reversible.

## Fuente localizada

La fuente de texto principal está en 1bpp.

- Banco físico: `$1E`
- Offset ROM base aproximado de la fuente: `0x3D660`
- Dirección CPU cuando está mapeada: `$5600`
- Tamaño de glyph: 8 bytes por carácter, 8x8 píxeles, 1 bit por píxel.

El motor copia los glyphs a VRAM mediante una rutina que usa esa fuente. La rutina relevante localizada en desensamblado está en el banco `$0C`, zona `$9619-$971F`, con uso de VDC `$0002/$0003`.

## Mapeo de caracteres

El juego no usa directamente el byte de texto como índice de tile. Hay tablas de conversión.

Tablas importantes localizadas:

- `0x41CF3`: mapa para bloque japonés principal `$A0-$DF`, banco físico `$20`.
- `0x41CB3`: mapa alternativo/complementario para `$A0-$DF`, banco físico `$20`.
- `0x42B5B`: mapa ASCII parcial, banco físico `$21`.

Para esta prueba se han añadido glyphs nuevos y se han mapeado los códigos de texto `$B0-$BF` directamente a glyphs `$B0-$BF`.

Tabla usada en la prueba:

| Código | Carácter |
|---:|---|
| `$B0` | á |
| `$B1` | é |
| `$B2` | í |
| `$B3` | ó |
| `$B4` | ú |
| `$B5` | ü |
| `$B6` | ñ |
| `$B7` | Á |
| `$B8` | É |
| `$B9` | Í |
| `$BA` | Ó |
| `$BB` | Ú |
| `$BC` | Ü |
| `$BD` | Ñ |
| `$BE` | ¿ |
| `$BF` | ¡ |

## Advertencia importante

Esta prueba reutiliza códigos japoneses (`$B0-$BF`). Por tanto, puede romper textos japoneses que aún no estén traducidos. No es un problema para la prueba técnica, pero para la traducción final habrá que decidir entre:

1. traducir/reinsertar todos los bloques afectados antes de publicar;
2. reservar un rango seguro y parchear la rutina de mapeo;
3. añadir una tabla latina alternativa seleccionable por control code;
4. o implementar un sistema más amplio de fuente/tabla.

## Resultado actual

La vista previa indica que los glyphs se renderizan correctamente en 1bpp. Son diseños provisionales; habrá que refinarlos visualmente, especialmente para que las tildes no ocupen demasiado espacio vertical.

La prueba en emulador debe confirmar:

- que los nuevos caracteres salen en pantalla;
- que la tabla de conversión usada por la escena es efectivamente la parcheada;
- que no hay problemas de control codes en `$B0-$BF`;
- que los signos `¿` y `¡` son estables.

## Siguiente paso técnico

Probar el IPS o la ROM parcheada en emulador. Si se ve bien, el siguiente paso será añadir minúsculas completas y crear una tabla de inserción estable para textos españoles.
