# Prueba v03 — error de Jizo 4 líneas con pantalla original

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_vanilla_test.pce`

IPS:

`Parches/Pruebas/momotaro_traduccion_v03_error_text4_vanilla_test.ips`

## Objetivo

Revertir completamente los cambios de bocadillo/viewport/metasprite del mensaje de error y volver al estado de `traduccion_v02` para esa pantalla.

Después se inserta **sólo** el texto de error en las cuatro líneas fijadas por el usuario:

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

No se toca el bocadillo. No se toca el viewport/proyección. No se cambia el texto después de esta prueba.

## Detalle técnico

- Base: `traduccion_v02` confirmada.
- Texto nuevo: ROM `0x1F838`, CPU `$5838`, len `71`.
- Se parchea sólo el puntero de error `CE5F/CE63` hacia el texto nuevo.
- Se añade una 4.ª entrada válida a la tabla de líneas en ROM `0x1BDB0` / CPU `$DDB0`:
  - `$7008`
  - `$7208`
  - `$7408`
  - `$7608`
- La tabla de líneas sólo define dónde está el paisaje/texto en VRAM; **no amplía la ventanilla visible**.

## Longitudes de línea

```text
[17, 15, 15, 19]
```

## Validación anti-corrupción

Se ha comprobado antes de escribir que estas regiones quedan idénticas a `traduccion_v02`:

- `0x1E29C-0x1E2DF`: tilemap original de la caja central de error.
- `0x2EC10-0x2EC4D`: viewport/metasprite original usado por la pantalla.
- `0x2F8B5-0x2F930`: zona libre bank17; no se escribe nada ahí.

Cambios contra `traduccion_v02`:

- `0x1AE60` len `1`
- `0x1AE64` len `1`
- `0x1AE68` len `2`
- `0x1AE70` len `2`
- `0x1AEF4` len `2`
- `0x1AEF9` len `2`
- `0x1BDB0` len `8`
- `0x1F838` len `70`

## Qué comprobar

1. Que EMPEZAR/CONTINUAR ya no se corrompen.
2. Que la caja/bocadillo del error vuelve al estado original.
3. Qué parte exacta de las cuatro líneas se ve.
4. Dónde se corta el texto: horizontalmente, verticalmente o por la ventanilla.
5. No evaluar todavía si el bocadillo es bonito: esta prueba es sólo para medir la ventanilla real.
