# Prueba v03 — error de Jizo 4 líneas, ancho +1 chunk en bank $0F

ROM:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_width_bank0f_test.pce`

IPS:

`Parches/Pruebas/momotaro_traduccion_v03_error_text4_width_bank0f_test.ips`

## Objetivo

Mantener el bocadillo original y el texto exactamente en estas 4 líneas:

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

La prueba anterior mostraba sólo 16 caracteres de la primera línea (`¡El canto de Jiz`). Esta prueba intenta que aparezca la `o` de `Jizo` sin tocar el bocadillo.

## Cambio técnico mínimo

- No se toca el tilemap/bocadillo de error.
- Se añade una ventanilla/metasprite de 5 columnas x 3 filas en la zona libre del bank `$0F`, no en bank `$17`:
  - ROM `0x1F900` / CPU `$5900` / len `76`.
- Se parchea `CF59` para mapear bank `$0F` en vez de `$17` sólo al leer esta lista.
- Se separan las líneas en VRAM con stride de 5 chunks / 20 caracteres:
  - `$7008`, `$7288`, `$7508`, `$7788`.

Esto es para comprobar si el problema horizontal era que el 17.º carácter se pisaba con la siguiente línea o no se proyectaba.

## Validación anti-corrupción

- `0x1E29C-0x1E2DF` idéntico a v02: bocadillo original.
- `0x2EC10-0x2EC4D` idéntico a v02: lista original preservada.
- `0x2F8B5-0x30000` idéntico a v02: bank `$17` completo desde esa zona no se toca.
- Nuevo viewport escrito en bank `$0F`, `0x1F900`, zona FF libre en v02.

## Longitudes

`[17, 15, 15, 19]`

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`

## Qué comprobar

1. Que EMPEZAR/CONTINUAR no se corrompen; ésta es la comprobación principal frente al test anterior.
2. Que el bocadillo sigue exactamente como en la prueba vanilla/original.
3. Si ahora se ve `Jizo` completo en la primera línea.
4. Qué pasa con las líneas 2 y 3 tras cambiar el stride.
5. No evaluar todavía la cuarta línea: seguimos midiendo ancho de ventanilla.
