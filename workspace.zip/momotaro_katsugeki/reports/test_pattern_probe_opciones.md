# Pattern probe para opciones de inicio

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_pattern_probe.pce`

IPS: `Parches/momotaro_start_options_pattern_probe.ips`

Vista previa: `images/start_options_pattern_probe_preview.png`

## Objetivo

Dejar intactas las listas originales `$46B5/$46C5`, pero sustituir el stream gráfico original por 6 patrones marcados con números `0-5`.

Esto sirve para ver en el emulador exactamente qué patrón usa cada sprite y cómo se combinan los patrones cuando un sprite es ancho.

## Resultado esperado

Al pulsar RUN, donde antes salían `HAJIMETE / TSUZUGI` deberían verse bloques numerados. La posición/secuencia de esos números nos dirá cómo mapear correctamente los gráficos españoles.

## Datos

- Stream nuevo: `277` bytes de 283.
- Lens: `[50, 40, 49, 48, 40, 49]`.
- Listas de metasprite: originales, sin tocar.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0272DF` len `46`
- `0x027311` len `6`
- `0x027318` len `12`
- `0x027325` len `54`
- `0x02735C` len `8`
- `0x027365` len `6`
- `0x02736C` len `22`
- `0x027383` len `11`
- `0x02738F` len `1`
- `0x027391` len `3`
- `0x027395` len `1`
- `0x027397` len `38`
- `0x0273C2` len `31`
- `0x0273E2` len `1`
- `0x0273E4` len `1`
- `0x0273E6` len `4`
- `0x0273F3` len `6`
