# Prueba de repertorio latino completo

ROM generada: `Momotarou Katsugeki (Japan) - latin_charset_test.pce`

IPS generado: `momotaro_latin_charset_test.ips`

Tabla asociada: `charset_latin_charset_test.tbl`

Vista previa: `images/latin_charset_test_preview.png`

## Objetivo

Comprobar en emulador si todos los códigos latinos propuestos son seguros antes de fijar tabla definitiva.

## Texto incluido

Página 1:

```text
abcdefghijklmn
opqrstuvwxyz
áéíóú ü ñ ç
```

Página 2:

```text
ABCDEFGHIJKLM
NOPQRSTUVWXYZ
ÁÉÍÓÚ Ü Ñ
```

Página 3:

```text
¿? ¡! 012345
6789 200¤
.,:;… '-/()% 
```

Página 4:

```text
&+ ºª
```

## Notas

- La `c` minúscula usa `$DB`, no `$A3`.
- `$A3` queda reservado/no seguro.
- `DE` y `DF` no se usan porque el motor los trata como marcas de dakuten/handakuten.
- `Ç` queda pendiente de slot definitivo porque `$DB` se está usando provisionalmente para `c`.
- El símbolo `¤` sigue siendo provisional para moneda/icono.

## Regiones cambiadas

- `0x01F078` len `114`
- `0x01F0EB` len `9`
- `0x01F0F5` len `11`
- `0x01F101` len `10`
- `0x03DB6A` len `5`
- `0x03DB70` len `7`
- `0x03DB7A` len `13`
- `0x03DB8A` len `5`
- `0x03DB90` len `8`
- `0x03DB9A` len `15`
- `0x03DBAA` len `7`
- `0x03DBB2` len `22`
- `0x03DBCA` len `1`
- `0x03DBCD` len `3`
- `0x03DBD1` len `7`
- `0x03DBD9` len `7`
- `0x03DBE1` len `20`
- `0x03DBF6` len `41`
- `0x03DC21` len `36`
- `0x03DC46` len `17`
- `0x03DC58` len `35`
- `0x03DC7C` len `19`
- `0x03DC90` len `25`
- `0x03DCAA` len `30`
- `0x03DCC9` len `26`
- `0x03DCE5` len `26`
- `0x03DD00` len `51`
- `0x03DD34` len `4`
- `0x03DD39` len `4`
- `0x03DD3E` len `19`
- `0x03DD55` len `11`
- `0x041CB4` len `4`
- `0x041CB9` len `58`
- `0x041CF4` len `4`
- `0x041CF9` len `58`
