# Prueba v03 — error de Jizo 4 líneas con viewport 5x4 seguro

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_viewport20_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_error_text4_viewport20_test.ips`

## Objetivo

Ahora que la prueba in-place v2 demostró que la quinta columna aparece si usamos offset `$7F`, esta prueba intenta mostrar las cuatro líneas completas.

Texto fijo:

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

## Cambio técnico

- Bocadillo original intacto.
- Bank `$17` intacto.
- Nueva lista de sprites/ventanilla en bank `$0F` zona libre:
  - ROM `0x1F900` / CPU `$5900` / len `101`.
- Lista de viewport: 5 columnas x 4 filas = 20 sprites.
- Quinta columna usa x offset `$7F`, porque `$80` se interpreta como negativo.
- Líneas en VRAM con stride de 5 chunks / 20 caracteres:
  - `$7008`
  - `$7288`
  - `$7508`
  - `$7788`

## Validación anti-corrupción

- `0x1E29C-0x1E2DF` idéntico a v02: bocadillo original.
- `0x2EC10-0x2EC4D` idéntico a v02: lista original preservada.
- `0x2F8B5-0x30000` idéntico a v02: bank `$17` no se toca.

## Longitudes

`[17, 15, 15, 19]`

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Que se ve `Jizo` completo.
3. Que la tercera línea muestra `Revísalo bien e` completa.
4. Que aparece la cuarta línea `inténtalo de nuevo.`.
5. El bocadillo se mantiene original; si el texto se sale visualmente, eso ahora mismo es aceptable.
