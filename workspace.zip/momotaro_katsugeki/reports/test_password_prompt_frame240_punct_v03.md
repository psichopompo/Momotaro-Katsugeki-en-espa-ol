# Prueba v03 — prompt superior marco 240 + signos

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_frame240_punct_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_prompt_frame240_punct_test.ips`

## Objetivo

Usar la lista real que sí afectó al prompt (`$4B33`), pero correctamente: sin cortarla, sin overlay y relocalizándola completa a bank `$0F` para no pisar datos contiguos.

Texto:

```text
¡Introduce el canto de Jizo!
```

## Cambio prompt

- Texto del prompt relocalizado en ROM `0x1F880`, CPU `$5880`.
- Lista original `$4B33` parseada completa.
- Texto completo ya limpio por `BA8A: LDY #$09 -> #$0D`. Esta variante reconstruye el marco superior a 240 px centrados y corrige los signos de apertura `¡`/`¿` copiando e invirtiendo `!`/`?`.
- Resto de la lista preservado.
- Lista relocalizada en ROM `0x1FA00`, CPU `$5A00`, len `266`.
- Base X de `CC2D`: `$58 -> $60`.
- Marco superior: left cap + 6 horizontales + right cap; objetivo 240 px.
- Resto de la lista compensado -8 px para no mover la caja inferior.
- `CC2D` apunta ahora a bank `$0F` / `$5A00`.
- Preparación/limpieza de patrones del prompt ampliada: ROM `0x43A8B`, `$09 -> $0D`.
- Glifos `¡` y `¿` corregidos por inversión vertical de `!` y `?`.
- No se toca `CD98` ni se crea overlay.
- Bank `$17` padding `0x2F8B5-0x30000` intacto.

## Incluye de base

- Error de Jizo bueno + limpieza expandida.
- Navegación DOWN corregida:
  - U/V -> 0
  - T -> Z
  - t -> z
  - z -> 9

## Qué comprobar

1. Que el prompt se ve como una sola frase, sin overlay ni duplicado.
2. Si se ve completo o dónde se corta.
5. Si al pasar a la pantalla de error ya no queda residuo del prompt.
6. Que el error de Jizo sigue limpio/completo.
7. Que la navegación especial sigue bien.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
