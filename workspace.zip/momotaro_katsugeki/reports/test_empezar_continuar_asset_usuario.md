# Test `EMPEZAR / CONTINUAR` usando asset del usuario

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_spanish_asset_test.pce`

IPS: `Parches/momotaro_start_options_spanish_asset_test.ips`

Vista previa: `images/start_options_spanish_asset_preview.png`

## Asset usado

`title_assets/start_options_es.png`

Se remapean sus colores así:

- Transparente → índice 0.
- Amarillo/naranja → índice 1, para que la paleta/atributo del juego decida seleccionado/no seleccionado.
- Negro/dark → índice 2.

## Datos

- Stream gráfico relocalizado: ROM `0x2F8B5`, CPU `$78B5`.
- Stream nuevo: `377` bytes.
- Longitudes por patrón: `[50, 53, 54, 25, 50, 49, 52, 43]`.
- Lista 1: CPU `$5A30`, ROM `0x2FA30`.
- Lista 2: CPU `$5A45`, ROM `0x2FA45`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x018EEB` len `1`
- `0x018EFF` len `1`
- `0x018F03` len `1`
- `0x02E6B1` len `4`
- `0x02F8B5` len `125`
- `0x02F933` len `6`
- `0x02F93A` len `9`
- `0x02F944` len `115`
- `0x02F9B8` len `65`
- `0x02F9FA` len `25`
- `0x02FA14` len `26`
- `0x02FA30` len `20`
- `0x02FA45` len `20`
