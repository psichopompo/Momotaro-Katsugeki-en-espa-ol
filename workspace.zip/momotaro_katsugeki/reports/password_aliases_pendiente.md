# Tarea pendiente — alias de passwords secretos

## Motivo

Al convertir la parrilla japonesa de password a una parrilla latina, los passwords secretos originales siguen funcionando por sus valores internos, pero pierden su significado visible.

Ejemplo confirmado:

```text
Password secreto japonés: いわさきはえがへた
Significado: Iwasaki dibuja mal
Entrada latina equivalente actual: BqdGlDWÑI
```

`BqdGlDWÑI` funciona, pero para un jugador no significa nada. La idea es crear aliases legibles que conserven el sentido original.

## Idea

Permitir que el jugador escriba una frase española, por ejemplo:

```text
IWASAKI DIBUJA MAL
```

y que internamente el juego la traduzca al password real equivalente antes de validar.

Flujo propuesto:

```text
El jugador introduce alias español
        ↓
El juego compara el buffer con una tabla de aliases
        ↓
Si coincide, sustituye el buffer por la secuencia interna real
        ↓
La rutina original de validación procesa el password auténtico
```

## Ventajas

- No rompe el sistema original de passwords.
- Conserva compatibilidad con la validación original.
- Devuelve significado a passwords secretos que eran bromas o referencias internas.
- Evita que el jugador tenga que escribir secuencias latinas sin sentido.

## Estado

Pendiente. No implementar hasta cerrar la pantalla de password/load y estabilizar las rutinas de entrada/validación.
