# Test `EMPEZAR / CONTINUAR` como metasprites

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_spanish_test.pce`

IPS: `Parches/momotaro_start_options_spanish_test.ips`

Vista previa del diseño gráfico: `images/start_options_spanish_preview.png`

## Qué hace

- Reemplaza el stream comprimido de los rótulos por 8 chunks de sprite nuevos.
- Mueve las listas de metasprite a una zona libre del banco `$17` (`$58B5` y `$58CA`).
- Actualiza la tabla de punteros de `0x2E6B1` para apuntar a esas listas nuevas.
- Dibuja `EMPEZAR` y `CONTINUAR` con una fuente compacta 5x7 + sombra.

## Importante

Es una prueba técnica. En esta primera versión los rótulos se dibujan sin sombra para que el stream comprimido quepa en el espacio original. Todavía hay incertidumbre en bits de atributos/tamaño/paleta de los sprites. Si se ve mal, la captura nos dirá qué ajustar.

## Stream gráfico

- Offset original usado: `0x272DE-0x273F8`.
- Longitud máxima original ocupada: `283` bytes.
- Longitud nueva comprimida: `211` bytes.

## Listas nuevas

- Lista 1 CPU `$58B5`, ROM `0x2F8B5`.
- Lista 2 CPU `$58CA`, ROM `0x2F8CA`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0272DE` len `13`
- `0x0272EC` len `5`
- `0x0272F2` len `27`
- `0x027310` len `20`
- `0x027325` len `7`
- `0x02732D` len `27`
- `0x02734A` len `3`
- `0x027350` len `11`
- `0x02735C` len `8`
- `0x027365` len `25`
- `0x027381` len `3`
- `0x027385` len `15`
- `0x027395` len `31`
- `0x0273B5` len `35`
- `0x0273D9` len `32`
- `0x02E6B2` len `3`
- `0x02F8B5` len `20`
- `0x02F8CA` len `20`
