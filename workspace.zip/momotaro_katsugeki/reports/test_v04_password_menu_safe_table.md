# v04 password/menu — tabla C5B6 relocalizada segura

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_safe_table_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v04_password_menu_safe_table_test.ips`

## Base

Parte de `traduccion_v03` confirmada.

## Objetivo

Traducir textos de menú password/load y ensanchar sólo el selector inicial sin escribir en bank17 aparentemente libre.

La prueba anterior escribió una lista en `0x2FA59` y rompió el título. Esta prueba relocaliza la tabla/listas que usa `C5B6` a bank `$0F` seguro.

## Textos

- `diff_facil`: ROM `0x1FB10`, CPU `$5B10`, len `8`
- `diff_normal`: ROM `0x1FB18`, CPU `$5B18`, len `9`
- `diff_dificil`: ROM `0x1FB21`, CPU `$5B21`, len `10`
- `diff_muy_dificil`: ROM `0x1FB2B`, CPU `$5B2B`, len `14`
- `empty`: ROM `0x1FB39`, CPU `$5B39`, len `1`
- `menu_jizo`: ROM `0x1FB3A`, CPU `$5B3A`, len `16`
- `menu_cargar`: ROM `0x1FB4A`, CPU `$5B4A`, len `9`
- `load_question`: ROM `0x1FB53`, CPU `$5B53`, len `23`
- `backup_error`: ROM `0x1FB6A`, CPU `$5B6A`, len `60`

## Metasprite C5B6 relocalizado

- Tabla nueva: ROM `0x1FBA6`, CPU `$5BA6`.
- Estado 0 copiado de `$4ADF`: ROM `0x1FBAE`, CPU `$5BAE`, len `46`.
- Estado 1 ampliado: ROM `0x1FBDC`, CPU `$5BDC`, len `41`.
- Estado 2/3 copiado de `$4AC1`: ROM `0x1FC05`, CPU `$5C05`, len `76`.

## Código parcheado

- `C5B6`: bank `$17 -> $0F`.
- `C5CD/C5D2`: tabla `$4AB9/$4ABA` -> `$5BA6`.

## Qué comprobar

1. Título: no debe haber duplicados/artefactos de EMPEZAR/CONTINUAR.
2. Selector inicial: `CANTO DE JIZO` / `CARGAR` y si la caja se ensancha.
3. Pantalla de dificultad: sigue bien.
4. Pantalla de carga: texto aún puede estar cortado; no se ha ensanchado todavía.
5. Cargar partida funciona.
6. Prompt y error Jizo de v03 siguen bien.

## Cambios contra v03

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
