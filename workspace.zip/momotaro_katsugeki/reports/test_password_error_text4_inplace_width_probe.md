# Prueba v03 — ancho diagnóstico in-place

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_error_text4_inplace_width_probe.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_error_text4_inplace_width_probe.ips`

## Objetivo

Intentar mostrar sólo la `o` de `Jizo` sin relocalizar listas ni tocar zonas libres problemáticas.

Texto fijo:

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

## Cambio técnico

La lista original del viewport en `0x2EC10` tiene 12 sprites: 4 columnas x 3 filas. En esta prueba se mantiene exactamente el mismo tamaño de lista y se redistribuyen esos 12 sprites como:

- línea 1: 5 chunks/sprites, para llegar al carácter 17.
- línea 2: 4 chunks/sprites.
- línea 3: 3 chunks/sprites.

Esto es diagnóstico: si aparece la `o`, sabemos que la forma correcta de ampliar el ancho pasa por añadir más sprites/chunks reales a la lista, no por moverla a otro banco.

También se separan las líneas en VRAM:

- `$7008`
- `$7288`
- `$7488`
- `$7688`

para que la línea 2 no pise el carácter 17 de la línea 1.

## Validación

- No se escribe en `0x2F8B5-0x30000`, la zona que corrompió título/opciones.
- No se toca el tilemap del bocadillo central (`0x1E29C-0x1E2DF`).
- La modificación in-place de `0x2EC10` mantiene el mismo largo (`61` bytes) y el mismo terminador.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`

## Qué comprobar

1. Que no hay corrupción en título/EMPEZAR/CONTINUAR.
2. Si aparece `¡El canto de Jizo` completo.
3. No evaluar todavía la tercera línea si se recorta: hemos sacrificado ancho de línea 3 para diagnosticar la primera.
