# Prueba v02 — opciones de password como gráfico

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v02_opciones_gfx_test2.pce`

IPS de prueba acumulativo contra ROM limpia:

`Parches/Pruebas/momotaro_traduccion_v02_opciones_gfx_test2.ips`

Preview real de tilemap:

`images/password_options_gfx_v02_test2_actual_tilemap_preview.png`

Gráfico fuente de opciones copiado:

`font_edit/password_options_user_gfx.png`

Referencia de tiles:

`font_edit/password_options_user_gfx_tiles_8x.png`

## Cambios respecto al test mini-fuente

- Se descarta la mini-fuente 3x5.
- Las opciones se insertan como gráfico a partir de `IMG_4537.PNG`, usando la letra ajustada por el usuario.
- La columna baja 3 px dentro de sus tiles hasta quedar más centrada con la zona del recuadro de inserción.
- La parte superior visible de `ADELANTE` queda aproximadamente en `y=155`.
- El cursor de opciones ya no usa las X de la parrilla: se añade una X especial `x=200`.
- El cursor de opciones se ajusta por palabra: ADELANTE/ESPACIO/BORRAR/FIN quedan 3 px más arriba respecto al gráfico, y ATRÁS queda 1 px más arriba respecto al test anterior.

## Parrilla preservada

```text
A B C D E F G a b c d e f g
H I J K L M N h i j k l m n
Ñ O P Q R S T ñ o p q r s t
U V W X Y Z · u v w x y z ·
· · 0 1 2 3 4 5 6 7 8 9 · ·
```

## Opciones

```text
ADELANTE = $F0
ATRÁS    = $F1
ESPACIO  = $F2
BORRAR   = $F3
FIN      = $F4
```

## Ajustes adicionales

- `$FF` dinámico del buffer, usado por ESPACIO, ahora se dibuja como punto grueso, no como slash. Los slashes de separación siguen siendo estáticos en el tilemap.
- DOWN desde `z` minúscula se redirige a `9` antes de permitir bajar a la columna de opciones.
- Las filas de opciones sólo son seleccionables en la columna lógica del `9`, para evitar el retorno raro hacia `z` al pulsar arriba.

## Validación estática

- Imagen fuente opciones: `44x55` px, dos colores.
- BBox blanca usada: `(4, 5, 39, 50)` -> crop `35x45`.
- Tiles de opciones: `5x6` = `30`.
- Glyph IDs opciones: `$E0..$FD`.
- Source bytes opciones: `$66..$83`.
- Tabla ASCII extendida: `84` bytes en `0x43F9B` / CPU `$BF9B`.
- Runtime table: `98` bytes en `0x1BBB9`, termina en `0x1BC1B`.
- Selection table: `175` bytes en `0x1BD00` / CPU `$DD00`.
- Low stream RLE: `207` / `260` bytes.
- High stream RLE: `12` / `12` bytes.
- Values table: `140` bytes.
- Stub navegación DOWN especial: `0x1BC30` / CPU `$DC30`, `23` bytes.

## Qué comprobar

1. Que las opciones se ven con la fuente del PNG enviado.
2. Que la columna está más baja y no invade visualmente la parrilla.
3. Que el puntero queda a la izquierda de la palabra, no encima de letras.
4. Que el puntero queda alineado verticalmente con cada palabra.
5. Que ADELANTE / ATRÁS / ESPACIO / BORRAR / FIN siguen funcionando.
6. Que la parrilla aceptada y el buffer no se han roto.
7. Que ESPACIO deja un punto grueso en el slot, no un slash.
8. Que desde `z` minúscula, pulsar abajo va a `9`, y desde `9` baja a ADELANTE.
