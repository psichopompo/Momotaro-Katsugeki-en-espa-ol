# Prueba v03 — prompt superior marco 240 px

ROM:
`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_frame240_test.pce`

IPS:
`Parches/Pruebas/momotaro_traduccion_v03_prompt_frame240_test.ips`

## Objetivo

Usar la lista real que sí afectó al prompt (`$4B33`), pero correctamente: sin cortarla, sin overlay y relocalizándola completa a bank `$0F` para no pisar datos contiguos.

Texto:

```text
¡Introduce el canto de Jizo!
```

## Cambio prompt

- Texto del prompt relocalizado en ROM `0x1F880`, CPU `$5880`.
- Lista original `$4B33` parseada completa.
- Parte superior con texto completo ya limpio por `BA8A: LDY #$09 -> #$0D`. Esta variante no mueve el texto; reconstruye sólo el marco superior para medir 240 px centrado: 224 px de texto + 8 px de margen a cada lado.
- Resto de la lista preservado.
- Lista relocalizada en ROM `0x1FA00`, CPU `$5A00`, len `266`.
- Marco superior reconstruido con 8 piezas arriba y 8 abajo: left cap + 6 horizontales + right cap.
- Offsets de marco: `$B0,$D0,$F0,$10,$30,$50,$70,$7F`.
- `CC2D` apunta ahora a bank `$0F` / `$5A00`.
- Preparación/limpieza de patrones del prompt ampliada: ROM `0x43A8B`, `$09 -> $0D`.
- No se toca `CD98` ni se crea overlay.
- Bank `$17` padding `0x2F8B5-0x30000` intacto.

## Incluye de base

- Error de Jizo bueno + limpieza expandida.
- Navegación DOWN corregida:
  - U/V -> 0
  - T -> Z
  - t -> z
  - z -> 9

## Qué comprobar

1. Que el prompt se ve como una sola frase, sin overlay ni duplicado.
2. Si se ve completo o dónde se corta.
4. Si al pasar a la pantalla de error ya no queda residuo del prompt.
5. Que el error de Jizo sigue limpio/completo.
6. Que la navegación especial sigue bien.

## Cambios contra v02

- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
- `0x{off:05X}` len `{ln}`
