# Prompt de título — `PULSA BOTÓN RUN` final

Se ha aplicado el diseño G de `Ó`, con la tilde invertida según indicación:

- Fila 1: píxeles 5 y 6.
- Fila 2: píxeles 4 y 5.
- El cuerpo de la `O` queda igual que en el diseño G elegido.

## Archivos actuales

- ROM: `Roms/Momotarou Katsugeki (Japan) - start_prompt_tilde_final.pce`
- IPS: `Parches/momotaro_start_prompt_tilde_final.ips`
- Vista previa: `images/title_O_accent_final_G_inverted.png`

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
