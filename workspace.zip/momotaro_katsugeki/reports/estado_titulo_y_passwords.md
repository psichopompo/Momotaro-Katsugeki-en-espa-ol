# Estado actual — título y pantalla de passwords

## Título / menú inicial

### Rótulo principal

Estado: **aceptado**.

Archivos de referencia actuales:

- ROM/parche del rótulo principal: pendiente de consolidar en una build integral.
- Asset final del usuario: `title_assets/title_logo_es_fullscreen_final.png`
- Asset recortado final: `title_assets/title_logo_es_cropped_final.png`

### Prompt de título

Estado: **aceptado**.

```text
PULSA BOTÓN RUN
```

### Opciones del menú inicial

Estado: **aceptado funcionalmente**.

```text
EMPEZAR
CONTINUAR
```

La versión que funciona es la basada en el asset del usuario y en la corrección del orden de bytes de sprite.

## Requisitos si se rediseñan `EMPEZAR / CONTINUAR`

Para que el pipeline actual pueda reintegrarlo sin rehacer el reverse:

- Mantener el lienzo aproximado del asset actual: `125 x 19 px`.
- Fondo transparente.
- Sin antialias.
- Sin semitransparencias.
- Mantener las palabras dentro de la misma caja visual.
- Usar colores planos; se remapearán a:
  - transparente = índice 0,
  - color de letra = índice 1,
  - negro/sombra = índice 2.
- Evitar superar 128 px útiles de ancho, porque el pipeline usa un canvas interno de `128 x 16` sprites.

Si cambia la anchura o la altura, habría que reajustar la conversión y quizá las listas de sprites.

## Pantalla de passwords

### Texto superior / bocadillo

Traducción final objetivo:

```text
¡Introduce el canto de Jizo!
¡El canto de Jizo no es correcto!
Compruébalo bien
e inténtalo otra vez.
```

La versión corta actual era sólo una prueba técnica; no es la traducción final.

### Opciones de la derecha

Nueva comprensión funcional:

```text
ADELANTE
ATRÁS
ESPACIO
BORRAR
FIN
```

Notas:

- `すすむ`: avanza por los caracteres ya introducidos.
- `もどる`: retrocede por los caracteres ya introducidos.
- `いれる`: inserta un espacio en la posición actual y desplaza lo posterior a la derecha. El juego lo representa como `?`, pero debe traducirse como `ESPACIO`.
- `けす`: borra un carácter.
- `おわり`: finaliza/envía la password; mejor `FIN` que `SALIR`.

### Carácter de espacio

El original representa el espacio como `?`, lo que es confuso. Propuesta:

- cambiar el glyph/representación de ese carácter por un hueco vacío o un marcador muy discreto;
- en la parrilla/menú llamarlo `ESPACIO`.

### Alfabeto de 64 símbolos

Propuesta previa válida:

- `A-Z` + `Ñ` = 27
- `a-z` + `ñ` = 27
- `0-9` = 10
- total = 64

Esta parrilla sirve si cada casilla japonesa equivale a un índice independiente.

### Passwords con sentido

Se han identificado passwords con significado/lectura japonesa:

- `いわさきはえがへた` → Iwasaki ha e ga heta → graphics/sprite gallery.
- `いわさきはうたがへた` → Iwasaki ha uta ga heta → sound test.
- `らきあまくさ` → final fácil.
- `こちみたしよ` → final normal.
- `きゆかたいと` → final difícil.
- `じうよしたすま` → final muy difícil.

Conclusión: no son sólo cadenas aleatorias. Algunas passwords son frases/bromas/nombres. Habrá que decidir si:

1. se conserva el algoritmo y se translitera visualmente con alfabeto latino de 64 símbolos;
2. o se parchean claves especiales para que tengan sentido en castellano.

La opción 1 es más segura inicialmente.

## Próximo bloque de investigación

Pantalla de password:

1. Localizar físicamente la parrilla hiragana.
2. Confirmar si son 64 índices independientes.
3. Identificar el orden lógico de esos 64 índices.
4. Sustituir visualmente la parrilla por la propuesta latina.
5. Localizar el glyph/caracter usado para el espacio `?` y convertirlo en vacío.
6. Traducir las opciones de la derecha.
7. Probar passwords conocidas.
