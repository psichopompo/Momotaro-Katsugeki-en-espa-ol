# Instrumentación VRAM — prompt superior password

## Objetivo

Responder a la pregunta correcta:

```text
¿Quién escribe los patrones 1AE..1BA?
```

y comprobar si los chunks extra del prompt existen limpios en VRAM o si contienen restos/artefactos ya antes de proyectarse.

## Entorno

Se compiló un core instrumentado:

```text
/home/user/emutools/beetle-pce-fast-libretro/mednafen_pce_fast_libretro.so
```

Instrumentación añadida:

- getter de VRAM,
- getter de SAT,
- getter de MPR,
- log filtrado de escrituras VRAM,
- registro de frame, dirección VRAM, valor, PC y MPR.

Rango vigilado:

```text
VRAM words 0x6B80..0x6EFF
```

Equivale a chunks/patrones:

```text
1AE, 1B0, 1B2, 1B4, 1B6, 1B8, 1BA
```

## ROM analizada

```text
Roms/Pruebas/Anteriores/Momotarou Katsugeki (Japan) - traduccion_v03_prompt_reloc4b33_v2_test.pce
```

Esta es una prueba buena para análisis porque ya muestra la lista `$4B33` relocalizada y los artefactos del prompt.

## Resultado visual extraído

Imagen renderizada desde VRAM final:

```text
images/prompt_chunks_1AE_1BA_vram_render.png
```

Observación visual:

```text
1AE: correcto / texto legible
1B0: correcto / texto legible
1B2: correcto / texto legible
1B4: correcto / texto legible
1B6: parcialmente correcto; contiene “de”, pero el resto no es texto limpio
1B8: incorrecto / artefactos
1BA: incorrecto / restos gráficos
```

## Escrituras por patrón 16x16

Resumen del log filtrado:

```text
1AE: 80 writes, frames 157..190
1AF: 80 writes, frames 157..200
1B0: 80 writes, frames 157..210
1B1: 80 writes, frames 157..220
1B2: 80 writes, frames 157..230
1B3: 80 writes, frames 157..240
1B4: 80 writes, frames 157..250
1B5: 80 writes, frames 157..260
1B6: 80 writes, frames 157..270
1B7: 80 writes, frames 157..280
1B8: 16 writes, frames 285..290
1B9: 16 writes, frames 295..300
1BA: 16 writes, frames 305..310
1BB: 16 writes, frames 315..320
```

## Conclusión técnica

No es cierto que `1B6/1B8/1BA` no existan.

Tampoco es exactamente que nadie los escriba.

Lo que ocurre es más concreto:

- `1AE..1B7` reciben una preparación mucho más completa.
- `1B8..1BB` reciben sólo escrituras parciales, 16 words por patrón 16x16, no una preparación completa equivalente a los anteriores.
- El contenido final de `1B8/1BA` confirma que no son chunks limpios de texto; contienen restos/artefactos.

Esto explica por qué:

- `de` se ve parcialmente,
- `Jizo!` se ve con basura,
- el defecto viaja con el chunk,
- ampliar/mover el marco no arregla esos artefactos.

## PCs relevantes observados

Para los patrones preparados parcialmente (`1B8..1BB`) aparecen escrituras desde rutinas de copia/generación alrededor de:

```text
D6xx / D70x / D734
```

Estas direcciones coinciden con rutinas de escritura de glyphs/patrones en el banco `0C`:

```text
D6BF
D6EC..D711
D720..D734
```

También aparecen escrituras de limpieza/rellenado desde rutinas de sistema como:

```text
FC48 / FC4B / FC4C
```

## Próxima investigación

La nueva pregunta no es de posición, sino de contador/generación:

```text
¿Por qué la preparación completa llega hasta 1B7 y después 1B8..1BB sólo reciben escrituras parciales?
```

Hipótesis más probable:

```text
La rutina de generación de texto/patrones está limitada por el ancho original, aproximadamente 4 chunks de texto; al forzar la proyección de chunks extra, éstos no están plenamente generados/limpios.
```

Siguiente paso recomendado:

1. Trazar la llamada desde `CE96` / rutina equivalente del prompt.
2. Identificar el contador de caracteres/chunks que decide cuántos patrones preparar.
3. Ampliar limpieza/generación de patrones del prompt, no seguir moviendo la lista `$4B33`.
