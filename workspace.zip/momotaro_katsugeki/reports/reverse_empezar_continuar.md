# Reverse preliminar — `HAJIMETE / TSUZUGI` / futuro `EMPEZAR / CONTINUAR`

## Conclusión actual

`HAJIMETE / TSUZUGI` no son texto normal. Se dibujan con el sistema de sprites/metasprites del título.

El código relevante está en el banco físico `$0C`, mapeado como `$C000`.

## Rutina de dibujo de metasprites

La rutina común está en el banco fijo, CPU `$E3EB`.

Formato de cada entrada de metasprite observado:

```text
byte 0: índice de tile/patrón relativo a una base de VRAM
byte 1: atributo/paleta/tamaño, pendiente de documentar exacto
byte 2: atributo/paleta/flip/tamaño, pendiente de documentar exacto
byte 3: offset X con signo
byte 4: offset Y con signo
```

La lista termina con `$FF`.

La herramienta añadida para inspeccionar listas es:

```text
tools/parse_metasprite.py
```

Ejemplo:

```bash
python3 tools/parse_metasprite.py 0x46B5 0x46C5 0x4281 0x429B --screen-x 0x80 --screen-y 0xC8
```

## Código de opciones del menú inicial

En la pantalla tras pulsar RUN, el código principal está en CPU `$CF0D`:

```asm
_CF0D:  LDA   #$17
_CF0F:  CLC
_CF10:  ADC   <$20
_CF12:  TAM   #$02        ; banco físico $17 en MPR2
_CF14:  LDX   #$80
_CF16:  LDY   #$C8
_CF18:  JSR   $EE86       ; base de pantalla X=$80, Y=$C8
_CF1B:  LDA   #$A0
_CF1D:  STA   <$55
_CF1F:  LDA   #$03
_CF21:  STA   <$56        ; base de tiles/patrones $03A0
_CF23:  LDA   $3AB5       ; selección actual: 0/1
_CF26:  ASL   A
_CF27:  TAX
_CF28:  LDA   $46B1,X     ; tabla de punteros de metasprite
_CF2B:  STA   <$53
_CF2D:  LDA   $46B2,X
_CF30:  STA   <$54
_CF32:  STZ   <$52
_CF34:  JMP   $E3EB
```

## Tabla de punteros

Banco físico `$17`, CPU `$46B1`, ROM `0x2E6B1`:

```hex
B5 46 C5 46
```

Esto da dos listas:

- `$46B5`
- `$46C5`

Probablemente corresponden a los dos estados de selección.

## Lista `$46B5`

ROM `0x2E6B5`:

```text
00: raw 02 06 01 08 F0 ; tile $02 -> VRAM $03A4 ; dx +8  ; dy -16 ; pantalla aprox (136,184)
01: raw 04 07 00 F3 F0 ; tile $04 -> VRAM $03A8 ; dx -13 ; dy -16 ; pantalla aprox (115,184)
02: raw 00 07 01 D3 F0 ; tile $00 -> VRAM $03A0 ; dx -45 ; dy -16 ; pantalla aprox (83,184)
FF
```

## Lista `$46C5`

ROM `0x2E6C5`:

```text
00: raw 02 07 01 08 F0 ; tile $02 -> VRAM $03A4 ; dx +8  ; dy -16 ; pantalla aprox (136,184)
01: raw 04 06 00 F3 F0 ; tile $04 -> VRAM $03A8 ; dx -13 ; dy -16 ; pantalla aprox (115,184)
02: raw 00 06 01 D3 F0 ; tile $00 -> VRAM $03A0 ; dx -45 ; dy -16 ; pantalla aprox (83,184)
FF
```

La diferencia entre ambas listas está en los atributos `$06/$07`. Esto encaja con la hipótesis de que el resaltado se hace por paleta/atributo, no por gráficos duplicados completos.

## Próximo problema pendiente

Aunque ya conocemos la lista que coloca los sprites, aún falta localizar o reconstruir la fuente gráfica de los tiles/patrones `$03A0`, `$03A4`, `$03A8`.

Búsquedas raw de tiles contra la captura no han dado coincidencias directas, así que los gráficos de estas opciones probablemente se cargan/descomprimen antes, o no están en la ROM en formato PCE lineal directo.

## Siguiente paso técnico

1. Localizar la rutina que carga en VRAM los patrones `$03A0-$03A8`.
2. Determinar si esos patrones vienen comprimidos, empaquetados o generados desde una tabla.
3. Una vez localizado el origen gráfico, sustituirlo por `EMPEZAR / CONTINUAR`.
4. Si el espacio/patrón no permite esas palabras, evaluar una variante gráfica compacta.

## Traducción objetivo

Primera opción:

```text
EMPEZAR
CONTINUAR
```

Alternativa si el espacio gráfico es restrictivo:

```text
COMENZAR
CONTINUAR
```

o una versión más corta, sólo si fuera necesario:

```text
NUEVA
CLAVE
```
