# Password grid actual aceptado

Build aceptada por el usuario tras prueba completa de letras y números.

ROM actual:

`Roms/Momotarou Katsugeki (Japan) - password_grid_current.pce`

IPS actual:

`Parches/momotaro_password_grid_current.ips`

Origen técnico: `password_grid_grouped_font_v2`.

## Confirmado por prueba en emulador

- Parrilla agrupada correcta.
- Cursor correcto.
- Izquierda/derecha correctas.
- Todos los caracteres insertan el carácter esperado.
- Corregido el fallo desde `q` hasta `9` provocado por la ruta japonesa de dakuten/handakuten.
- Fuente corregida v2 importada.
- Slashes del buffer restaurados.
- Slots vacíos con punto medio grueso.

## Layout aceptado

```text
A B C D E F G     a b c d e f g
H I J K L M N     h i j k l m n
Ñ O P Q R S T     ñ o p q r s t
U V W X Y Z       u v w x y z

    0 1 2 3 4     5 6 7 8 9
```

## Pendiente inmediato

Traducir/recuperar la columna de opciones del password:

```text
ADELANTE
ATRÁS
ESPACIO
BORRAR
FIN
```
