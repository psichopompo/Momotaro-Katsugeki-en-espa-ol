# Prueba v02 — opciones de password como gráfico

ROM de prueba:

`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v02_opciones_gfx_test.pce`

IPS de prueba acumulativo contra ROM limpia:

`Parches/Pruebas/momotaro_traduccion_v02_opciones_gfx_test.ips`

Preview real de tilemap:

`images/password_options_gfx_v02_actual_tilemap_preview.png`

Gráfico fuente de opciones copiado:

`font_edit/password_options_user_gfx.png`

Referencia de tiles:

`font_edit/password_options_user_gfx_tiles_8x.png`

## Cambios respecto al test mini-fuente

- Se descarta la mini-fuente 3x5.
- Las opciones se insertan como gráfico a partir de `IMG_4537.PNG`, usando la letra ajustada por el usuario.
- La columna baja hasta la zona del recuadro de inserción.
- La parte superior visible de `ADELANTE` queda aproximadamente en `y=152`.
- El cursor de opciones ya no usa las X de la parrilla: se añade una X especial `x=200`.
- El cursor de opciones se baja 2 px respecto al top de cada palabra.

## Parrilla preservada

```text
A B C D E F G a b c d e f g
H I J K L M N h i j k l m n
Ñ O P Q R S T ñ o p q r s t
U V W X Y Z · u v w x y z ·
· · 0 1 2 3 4 5 6 7 8 9 · ·
```

## Opciones

```text
ADELANTE = $F0
ATRÁS    = $F1
ESPACIO  = $F2
BORRAR   = $F3
FIN      = $F4
```

## Validación estática

- Imagen fuente opciones: `44x55` px, dos colores.
- BBox blanca usada: `(4, 5, 39, 50)` -> crop `35x45`.
- Tiles de opciones: `5x6` = `30`.
- Glyph IDs opciones: `$E0..$FD`.
- Source bytes opciones: `$66..$83`.
- Tabla ASCII extendida: `84` bytes en `0x43F9B` / CPU `$BF9B`.
- Runtime table: `98` bytes en `0x1BBB9`, termina en `0x1BC1B`.
- Selection table: `175` bytes en `0x1BD00` / CPU `$DD00`.
- Low stream RLE: `207` / `260` bytes.
- High stream RLE: `12` / `12` bytes.
- Values table: `140` bytes.

## Qué comprobar

1. Que las opciones se ven con la fuente del PNG enviado.
2. Que la columna está más baja y no invade visualmente la parrilla.
3. Que el puntero queda a la izquierda de la palabra, no encima de letras.
4. Que el puntero queda alineado verticalmente con cada palabra.
5. Que ADELANTE / ATRÁS / ESPACIO / BORRAR / FIN siguen funcionando.
6. Que la parrilla aceptada y el buffer no se han roto.
