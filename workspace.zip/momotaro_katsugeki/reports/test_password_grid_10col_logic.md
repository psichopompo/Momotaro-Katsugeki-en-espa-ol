# Password grid 10-column logic test

ROM: `Roms/Momotarou Katsugeki (Japan) - password_grid_10col_logic_test.pce`

IPS: `Parches/momotaro_password_grid_10col_logic_test.ips`

Preview estático: `images/password_grid_10col_logic_preview.png`

## Objetivo

Nueva prueba centrada en alinear visual y lógica de la parrilla del password:

- 64 símbolos latinos.
- 10 columnas, como se pidió.
- Separación horizontal de 16 px.
- Separación vertical de 16 px.
- Cursor con tablas X/Y parcheadas, no heredadas del layout japonés.
- Tile IDs empezando en `1`, no en `0`, para que no desaparezcan `A`/`9` por desplazamiento.

## Parrilla esperada

```text
ABCDEFGHIJ
KLMNÑOPQRS
TUVWXYZabc
defghijklm
nñopqrstuv
wxyz012345
6789
```

El último renglón tiene sólo `6789`; las seis celdas restantes son inválidas y la rutina original debería saltarlas.

## Correcciones respecto al test anterior

1. **Off-by-one visual**: el test anterior colocaba `0..63` en tilemap. En esta pantalla el patrón 0 queda en blanco y los glifos generados empiezan en 1. Por eso la parrilla se desplazaba y faltaba el `9`. Ahora se colocan `1..64`.
2. **Tablas X/Y del cursor**: el test anterior cambiaba valores y límites, pero dejaba la tabla X japonesa (`D8 C8 B8...`). Por eso el puntero sólo podía moverse por una franja y el orden físico salía invertido. Ahora `CC6B` y `CC78` se parchean para el layout latino.
3. **Geometría**: pasa de 8x8 a 10 columnas; las filas se separan una tile-row en blanco para no quedar pegadas.

## Validación estática hecha antes de generar

- Símbolos codificados: `64`.
- Tabla runtime: `66` bytes en `0x1BBB9`.
- Low stream RLE: `148` / `260` bytes.
- High stream RLE: `12` / `12` bytes.
- X table: `13` bytes, navegación limitada a las 10 primeras columnas.
- Y table: `10` bytes, navegación limitada a las 7 primeras filas.
- Valores `CC82`: `130` / 130 bytes.

## Regiones relevantes cambiadas

- Fuente latina 1bpp: `0x3D660` len `1792`
- Tabla conversión latina 1: `0x41CB3` len `64`
- Tabla conversión latina 2: `0x41CF3` len `64`
- Tabla conversión latina 3: `0x42B5B` len `54`
- Puntero tabla runtime low: `0x1A85E` len `1`
- Puntero tabla runtime high: `0x1A862` len `1`
- Tabla runtime 64 símbolos: `0x1BBB9` len `66`
- Tilemap RLE low: `0x1E18C` len `260`
- Tilemap RLE high: `0x1E290` len `12`
- Nav row wrap up: `0x1AA56` len `1`
- Nav row max: `0x1AA6A` len `1`
- Nav col max: `0x1AA80` len `1`
- Nav col wrap left: `0x1AA95` len `1`
- CC61 offsets fila: `0x1AC61` len `10`
- CC6B tabla X cursor: `0x1AC6B` len `13`
- CC78 tabla Y cursor: `0x1AC78` len `10`
- CC82 valores selección: `0x1AC82` len `130`

## Qué comprobar en emulador

1. Que se ven 10 columnas y el `9` aparece.
2. Que el cursor llega a la primera columna real y a la décima columna real.
3. Que la esquina superior izquierda introduce `A`.
4. Que hacia la derecha se introducen `B`, `C`, `D`...
5. Que al bajar desde `A` se llega a `K`, luego `T`, etc.
6. Que la última fila sólo contiene `6 7 8 9` y el cursor salta las celdas vacías.

Nota: las opciones de la derecha (`ADELANTE`, `ATRÁS`, `ESPACIO`, `BORRAR`, `FIN`) todavía no son el objetivo de esta ROM. Primero hay que dejar cuadrada la parrilla visual/lógica.
