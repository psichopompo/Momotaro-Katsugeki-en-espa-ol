# Test v3 `EMPEZAR / CONTINUAR` como metasprites

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_spanish_test_v3.pce`

IPS: `Parches/momotaro_start_options_spanish_test_v3.ips`

Vista previa: `images/start_options_spanish_v3_preview.png`

## Cambio respecto a v2

La v2 corrigió el formato de sprite 16x16 y ya produjo rótulos reconocibles, pero sin sombra y con aspecto pobre.

La v3 relocaliza el stream gráfico al hueco libre del banco `$17` para que quepa con sombra.

## Parches de carga

La rutina original cargaba el stream desde banco `$13`, CPU `$72DE`.

Ahora:

- MPR2/MPR3 se cambian a `$16/$17`.
- Fuente del stream: CPU `$78B5`, banco `$17`, ROM `0x2F8B5`.

## Datos

- Stream nuevo: `301` bytes.
- Longitudes por patrón: `[30, 42, 44, 30, 38, 37, 39, 40]`.
- Lista 1: CPU `$59F0`, ROM `0x2F9F0`.
- Lista 2: CPU `$5A05`, ROM `0x2FA05`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x018EEB` len `1`
- `0x018EFF` len `1`
- `0x018F03` len `1`
- `0x02E6B1` len `4`
- `0x02F8B5` len `301`
- `0x02F9F0` len `20`
- `0x02FA05` len `20`
