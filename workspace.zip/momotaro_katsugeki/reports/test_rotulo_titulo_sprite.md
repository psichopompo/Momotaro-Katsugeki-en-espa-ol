# Test del rótulo principal del título como sprites

ROM: `Roms/Momotarou Katsugeki (Japan) - title_logo_spanish_sprite_test.pce`

IPS: `Parches/momotaro_title_logo_spanish_sprite_test.ips`

Vista previa: `images/title_logo_spanish_sprite_test_preview.png`

## Qué hace

Sustituye el stream gráfico del logo japonés principal por el rótulo español `MOMOTARO EN ACCIÓN` entregado por el usuario.

## Datos

- Asset fuente: `title_assets/title_logo_es_fullscreen.png`.
- Región tomada del asset: pantalla completa, filas `27..90`.
- Stream original: `0x252C8-0x2617A` (3763 bytes).
- Stream nuevo: `3652` bytes.
- Patrones: 64 de 16x16.
- Metasprite list parcheada: ROM `0x2E2B0`, 8 sprites de 32x64.

## Notas

La posición y estructura deberían ser razonables. Los colores son provisionales porque aún no hemos volcado la paleta real de sprites del título; el mapeo de índices se ajustará tras ver captura.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
- `0x0252C9` len `2`
- `0x0252CC` len `7`
- `0x0252D6` len `8`
- `0x0252DF` len `11`
- `0x0252EB` len `4`
- `0x0252F0` len `41`
- `0x02531A` len `12`
- `0x025328` len `15`
- `0x025338` len `113`
- `0x0253AA` len `96`
- `0x02540B` len `22`
- `0x025422` len `9`
- `0x02542C` len `8`
- `0x025435` len `65`
- `0x025477` len `7`
- `0x02547F` len `2`
- `0x025482` len `38`
- `0x0254AA` len `21`
- `0x0254C0` len `150`
- `0x025557` len `108`
- `0x0255C4` len `7`
- `0x0255CC` len `32`
- `0x0255ED` len `48`
- `0x02561E` len `7`
- `0x025626` len `7`
- `0x02562E` len `10`
- `0x025639` len `4`
- `0x02563E` len `11`
- `0x02564A` len `51`
- `0x02567E` len `70`
- `0x0256C5` len `5`
- `0x0256CB` len `3`
- `0x0256CF` len `7`
- `0x0256D7` len `20`
- `0x0256EC` len `21`
- `0x025702` len `6`
- `0x025709` len `53`
- `0x02573F` len `49`
- `0x025771` len `22`
- `0x025788` len `7`
- `0x025790` len `37`
- `0x0257B6` len `16`
- `0x0257C7` len `51`
- `0x0257FB` len `9`
- `0x025805` len `4`
- `0x02580A` len `14`
- `0x025819` len `25`
- `0x025833` len `50`
- `0x025866` len `2`
- `0x025869` len `60`
- `0x0258A6` len `194`
- `0x025969` len `35`
- `0x02598D` len `9`
- `0x025997` len `70`
- `0x0259DE` len `5`
- `0x0259E4` len `2`
- `0x0259E7` len `6`
- `0x0259EE` len `6`
- `0x0259F9` len `42`
- `0x025A24` len `21`
- `0x025A3A` len `5`
- `0x025A40` len `340`
- `0x025B95` len `25`
- `0x025BB3` len `19`
- `0x025BC7` len `2`
- `0x025BCA` len `9`
- `0x025BD5` len `29`
- `0x025BF3` len `103`
- `0x025C5B` len `83`
- `0x025CAF` len `56`
- `0x025CE8` len `91`
- `0x025D44` len `2`
- `0x025D47` len `20`
- `0x025D5C` len `41`
- `0x025D86` len `26`
- `0x025DA1` len `7`
- `0x025DA9` len `5`
- `0x025DB0` len `27`
- `0x025DCC` len `11`
- `0x025DD8` len `376`
- `0x025F51` len `86`
- `0x025FA8` len `8`
- `0x025FB1` len `83`
- `0x026005` len `22`
- `0x02601C` len `16`
- `0x02602D` len `5`
- `0x026033` len `13`
- `0x026041` len `11`
- `0x02604D` len `39`
- `0x026075` len `6`
- `0x02607C` len `5`
- `0x026082` len `32`
- `0x0260A3` len `39`
- `0x0260CB` len `9`
- `0x0260D6` len `3`
- `0x0260DA` len `8`
- `0x0260E3` len `11`
- `0x0260EF` len `3`
- `0x0260F3` len `16`
- `0x026105` len `5`
- `0x02610B` len `39`
- `0x026133` len `2`
- `0x026136` len `8`
- `0x02613F` len `60`
- `0x02E2B0` len `6`
- `0x02E2B7` len `4`
- `0x02E2BC` len `2`
- `0x02E2BF` len `1`
- `0x02E2C2` len `1`
- `0x02E2C4` len `1`
- `0x02E2C7` len `1`
- `0x02E2C9` len `1`
- `0x02E2CC` len `1`
- `0x02E2D1` len `1`
- `0x02E2D3` len `1`
- `0x02E2D6` len `1`
- `0x02E2D8` len `10`
