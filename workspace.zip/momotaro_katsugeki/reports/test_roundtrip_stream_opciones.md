# Test roundtrip del stream gráfico original de `HAJIMETE / TSUZUGI`

ROM: `Roms/Momotarou Katsugeki (Japan) - start_options_roundtrip_test.pce`

IPS: `Parches/momotaro_start_options_roundtrip_test.ips`

## Objetivo

Validar si nuestro descompresor+recompresor del stream de opciones es correcto.

Se hace:

1. Descomprimir el stream original `0x272DE`.
2. Recomprírmirlo con nuestro compresor.
3. Reinsertarlo en la ubicación original.
4. Dejar intactas las listas de metasprite originales.

## Resultado esperado

Al pulsar RUN deberían verse los rótulos japoneses originales perfectamente, igual que en la ROM limpia, pero con el prompt ya traducido `PULSA BOTÓN RUN`.

- Si se ven bien: el compresor es correcto y el problema está en cómo generamos/ordenamos los patrones nuevos o sus listas.
- Si se ven mal: el compresor/descompresor todavía no reproduce el formato real.

## Datos

- Patrones descomprimidos: `6`.
- Fin de descompresión original: `0x273F9`.
- Espacio original: `283` bytes.
- Stream recomprimido: `283` bytes.
- Longitudes por patrón: `[54, 59, 53, 64, 36, 16]`.

## Regiones cambiadas

- `0x0042B0` len `7`
- `0x0042B8` len `8`
- `0x018E87` len `12`
