# Organización del workspace de Momotarou Katsugeki

## Roms/

La carpeta principal queda vacía de ROMs de prueba activas cuando no hay una build aceptada integral.

- `Original/` — copia de la ROM limpia.
- `Anteriores/` — todas las pruebas anteriores, tanto fallidas como parciales/exitosas.

## Parches/

La carpeta principal queda vacía de IPS activos cuando no hay un parche consolidado actual.

- `Anteriores/` — todos los IPS de pruebas anteriores.

## Tablas/

Contiene tablas de caracteres/propuestas actuales. Las tablas anteriores están en `Tablas/Anteriores/`.

## work/

Carpeta de trabajo/scratch para scripts. Conserva la ROM limpia usada por las herramientas.
