# Organización del workspace de Momotarou Katsugeki (traducción al español)

> Actualizado el **2026-08-03**, tras la sesión del selector de dificultad y la
> retirada de la v27.
> Rutas relativas a la raíz del workspace (`/home/user`).

---

## ESTADO ACTUAL EN UNA PANTALLA

**Versión válida: `test_diffsel_v26.pce`** — MD5 `b124c7ae288678a1419557276afd5648`

| Pantalla | Estado |
|---|---|
| Título y menú principal | ✅ traducido |
| Selector CANTO DE JIZO / CARGAR | ✅ texto correcto |
| Carga de partida ("¿Cuál quieres cargar?") | ✅ pregunta en una línea, "?" visible, bocadillo ensanchado |
| Selección de dificultad | ✅ textos, bocadillo y centrado correctos |
| Pantalla de contraseñas | ✅ parrilla latina, opciones, navegación, error de Jizo |
| **Resto del juego** | ❌ **sin traducir** (guion, aldeanos, tiendas, objetos) |

> El avance real es de **interfaz inicial**. El grueso del juego está por delante.

### Pendiente inmediato

1. **Parpadeo de "CANTO DE JIZO"**: al confirmar sólo parpadea parte del rótulo.
   La v27 lo empeoró (ahora sólo parpadearía "JIZO"). Ver diario, entrada 26.
2. **Botón II (tecla B) para salir de la pantalla de contraseñas**: la v27 lo hizo
   mal (lleva al mapa en vez de al selector). Hay que **trazar** la ruta real de
   cancelación.

> ⚠️ **La v27 está descartada.** Partir siempre de **v26**.

---

## `/home/user/emutools/`  (imprescindible para ejecutar/compilar)

### `beetle-pce-fast-libretro/` — core **instrumentado**
- `libretro.c` y `mednafen/pce_fast/{huc6280.c,vdc.c}` contienen los hooks `arena_*`.
- Es **el único core con instrumentación**: watchpoints, logs de VRAM/SAT/PC/MPR.
- Tras editar cualquier fuente: `cd emutools/beetle-pce-fast-libretro && make -j4`.
- Produce `mednafen_pce_fast_libretro.so`, que es el que usa el runner.
- No contiene `.git`; el commit de origen no es recuperable.

### `beetle-pce-libretro/` — core de referencia del usuario
- Beetle PCE **v1.29.0** (`mednafen_pce_libretro.so`). **Sin instrumentar.**
- Es el core que usa David en RetroArch: *NEC - PC Engine / SuperGrafx / CD (Beetle PCE)*.
- Se adoptó porque el Fast daba problemas con las capturas.

### Compatibilidad entre cores (medido)

| Recurso | Fast | PCE | Nota |
|---|---|---|---|
| `.srm` (BRAM, 2048 B) | ✅ | ✅ | **El mismo vale para ambos** |
| `.state` | 13.379 B | 83.523 B | ❌ **NO compatibles entre sí** |

**Consecuencia práctica:** los `.state` que aporta David son de Beetle PCE y **no
cargan en el runner instrumentado (Fast)**. Para llegar a una pantalla concreta hay
que navegar con entrada simulada en Fast — que resulta inestable en el selector de
dificultad — o instrumentar también el core PCE.

---

## `/home/user/downloads/`  (entradas de emulación)

- `momotaro.srm` — BRAM de la partida de prueba ("DIFÍCIL 1"). Válido en ambos cores.
- `momotaro.state` — save-state **de Beetle PCE Fast**, entra a la pantalla de carga.
- `momotaro_pce.state` (13.714 B) — save-state **de Beetle PCE**, pantalla de carga.
- `Momotarou Katsugeki (Japan).state` — save-state **de Beetle PCE**, entra **directo
  a la pantalla de selección de dificultad**. Aportado por David.

---

## `/home/user/uploads/`  (entradas del usuario)

- `PROMPT_METODO.md` — **reglas obligatorias** de investigación y entrega.
- `savestate/` — BRAM aportada por el usuario.
- Documentos de apoyo de Claude y capturas recientes.

---

## `/home/user/momotaro_katsugeki/`

### Documentación

- **`investigation.md`** — diario permanente y prioritario. **Leer primero.**
- `ESTRUCTURA_WORKSPACE.md` — este inventario.
- `reports/` — informes con el razonamiento de cada fase.
  - `password_aliases_pendiente.md` — trabajo futuro sobre alias de contraseñas.
  - `PROMPT_para_Claude_*.md`, `PLAN_pregunta_carga.md`, `ODISEA_SELECTOR_TEXTO.md`.
  - Los volcados `bank_XX_8000.asm` se borraron: son **regenerables** con `tools/dis6280/`.

### ROMs y parches

- `Roms/Original/Momotarou Katsugeki (Japan).pce` — ROM japonesa limpia.
  MD5 `ec7358edb3672a8aa8850623eec72a71`.
- **`Roms/Pruebas/test_diffsel_v26.pce`** — **versión válida actual**.
  MD5 `b124c7ae288678a1419557276afd5648`.
- `Parches/momotaro_diffsel_v26.ips` — MD5 `4e20fb2e1534017416f338dd1c93ee81`.
- `work/Momotarou Katsugeki (Japan).pce` — copia de la ROM japonesa (idéntica byte a byte).

### Herramientas (`tools/`)

- **`libretro_pce_runner.py`** — runner del core instrumentado. Carga ROM/state/SRM y
  expone VRAM, SAT, MPR, PC y los logs `arena_*`.
- `dis6280/` + `dis6280_bin` — desensamblador HuC6280.
  **Pierde el permiso de ejecución en cada arranque: `chmod +x tools/dis6280_bin`.**
- `make_ips_final.py` — genera el IPS desde la ROM original.
- `make_v04_password_menu_safe_table_test.py` — generador de la prueba v04 del menú.
- `latin_text_tools.py`, `decode_text.py`, `measure_width.py`, `find_text_tiles.py`.

### Datos de traducción

- `Tablas/` — tabla latina y propuestas.
- `translations/` — bloques de texto conocidos.
- `font_edit/` — fuente y parrilla de contraseñas.
- `tile_assets/`, `title_assets/` — activos gráficos.

### Evidencia

- `instrument/` — capturas y volcados de las mediciones.
  **Crear los subdirectorios antes de escribir en ellos** (`os.makedirs(..., exist_ok=True)`):
  la v27 falló justo por esto.
- `references/` — capturas de referencia.

---

## MAPA DE DIRECCIONES ÚTILES (medidas y verificadas)

### Compositor de sprites
- `$E3EB–$E5B0` (ROM 0x03EB–0x05B0), **banco 0, sin comprimir**.
- `$E455` — sign-extend de `x_rel` (**entero con signo de 8 bits**).
- `$E4B4` — clip: descarta si X₁₆ ≥ `$0120` o si es negativo.
- Fórmula: `X_SAT = base_efectiva + sex(x_rel)`, con `sex ∈ [-128, +127]`.

### Bases por pantalla
- Tabla indexada por `$3C83`, trampolín en `$DC77`, llamada desde `$C5BD`.
  - modo 0 = dificultad → `$58` (ajustado luego a `$52`)
  - modo 1 = selector CANTO/CARGAR → `$4A`
  - modo 2 = carga de partida → `$4D`
- `LDX #$4A` original en `$C5C3` (ROM **0x1A5C4**).

### Selección de dificultad
- Bucle de render: `$C4C0`. Orden `$C59C = [2,1,0]`.
- **Tabla de destinos CG `$C5A2`** — la causa de "MUY DIFÍC N" era su paso de 5 tiles.
  Corregida a `$7008, $7188, $7288`.
- SAT del bloque: `$5BAE`.
- **Bocadillo: stream en ROM 0x1E07A** (tabla `$C499`, modo 0 → `$407A`).
  *No* es el stream del selector ni el `CPX #$0C` de `$C633`.

### Pantalla de carga
- Texto de la pregunta: ROM **0x1FB53** (CPU `$5B53`), encoding latino.
- Tabla de textos `$5501` (ROM 0x1F501).
- Bloque2 (datos SAT): ROM **0x1FC05**, entradas de 5 bytes `[code, fl_lo, fl_hi, x, y]`,
  terminador `$FF`. `tile = code + 0x1C0`.
  **Cuidado: no pisar el `FF` final** (ya ocurrió una vez y metió basura en pantalla).
- Melocotón: rutina `$C73A`; `$3C86` desde la tabla `$C6FC`; la carga usa ROM **0x1A704**.
  Relación medida: `X_melocotón = $3C86 + 34`.
- Glifo "¿": ROM **0x3DCA8** (versión de Claude: `0c 00 0c 38 63 63 3e 00`).

### Mapeo de botones (PC Engine / RetroArch / libretro)

Medido y confirmado por David con su configuración de RetroArch en Mac Mini:

| PC Engine | Tecla (teclado de David) | libretro ID | Función en el juego |
|---|---|---|---|
| **Botón I** | — | 8 (`A`) | Atacar / golpe de espada |
| **Botón II** | **B** | 0 (`B`) | Saltar |
| **SELECT** | — | 2 | Estado / inventario |
| **RUN** | **A** y **ENTER** | 3 (`START`) | Pausa; confirmar en menús |

Notas medidas:
- En los menús, **RUN confirma** y el **botón II** hace de cancelar/atrás donde está
  implementado (p. ej. en la pantalla de partidas guardadas).
- En la **pantalla de contraseñas el botón II no vuelve atrás**: el original no lo
  implementa. Es la mejora pendiente nº 2, no un bug.
- El runner inyecta entrada por **ID de libretro**, no por nombre. `ID 3` = RUN es el
  que se usa para atravesar el título y el menú principal.

### Formato de los streams de bocadillo
- `FF nn tile` genera **nn+1 copias**, no `nn`. Ese off-by-one descuadraba los bordes.

### Modos de dificultad
- Texto "MUY DIFÍCIL": ROM **0x1FB2B** (12 glifos). Conservado en 0x1FC51.
- Tabla de punteros: ROM **0x1F4AE** — ya tiene **4 entradas**.
- ゲロゲロモード se desbloquea al completar むずかし. **Se deja oculto**, como el original.

### Mapeo de RAM
- `$3C86` (página 3) se mapea a `BaseRAM[0x1C86]` (mirror `A & 0x1FFF`), **no** a `0x3C86`.

---

## Para ponerte al día en un chat nuevo

1. **Leer `investigation.md` completo**, sobre todo las entradas 20–26.
2. **Leer `uploads/PROMPT_METODO.md`** (reglas de investigación).
3. Verificar el runner:
   `cd /home/user/momotaro_katsugeki/tools && python3 -c "from libretro_pce_runner import Runner; print('ok')"`
4. Si falta el `.so`: `cd /home/user/emutools/beetle-pce-fast-libretro && make -j4`.
5. `chmod +x tools/dis6280_bin`.
6. Partir siempre de **`Roms/Pruebas/test_diffsel_v26.pce`**.
7. Atacar las dos tareas pendientes **una a una**, y sólo tras **medir la causa**.

---

## NORMAS QUE SE GANARON FALLANDO

1. **Un cambio por prueba.** La v27 tocó tres bytes a la vez y no se supo cuál rompió qué.
2. **Nunca entregar una ROM que el script no llegó a verificar.** Si la verificación
   peta, la entrega no existe.
3. **Crear los directorios de salida antes de escribir** (`os.makedirs(..., exist_ok=True)`).
4. **Un destino de salto se mide, no se deduce.** `$C83D` se dio por "ruta de cancelar"
   sin trazarla: era la de contraseña aceptada.
5. **Desensamblar todo parche de código** antes de darlo por bueno.
6. **No asumir valores en tiempo de ejecución** ("el byte bajo siempre es `$08`").
7. **Scripts cortos.** Un cambio, una verificación, un resultado.
8. **Comprobar qué stream/tabla controla cada pantalla**: la de dificultad y la del
   selector usan streams distintos, y se perdieron varias iteraciones por eso.
