# Diario de investigación — Momotarou Katsugeki ES

> Norma desde 2026-07-31: este archivo es el registro permanente del proyecto. Toda afirmación relevante debe marcarse como `[HECHO]`, `[HIPÓTESIS]` o `[DESCARTADO]`. Las hipótesis falsas se conservan.

## 2026-07-31 — Reglas de trabajo adoptadas

- [HECHO] El usuario aportó `PROMPT_METODO.md` con el método de trabajo para ingeniería inversa/romhacking.
- [HECHO] Reglas adoptadas para el resto del proyecto:
  - comprender antes de parchear;
  - mantener evidencias: offsets, trazas, capturas, volcados;
  - no asumir espacios libres sin comprobar contenido actual;
  - no borrar hipótesis falsas: marcarlas como `[DESCARTADO]`;
  - probar activamente en emulador/instrumentación cuando sea posible;
  - versiones numeradas acumulativas;
  - responder en castellano;
  - reconocer errores explícitamente.
- [HECHO] Este diario se crea tarde, cuando el proyecto ya está avanzado. Se reconstruye a partir de informes existentes, capturas y conversación.
- [HIPÓTESIS] Este diario debe ir sustituyendo progresivamente a notas dispersas en `reports/`, aunque se conservarán los informes específicos.

## ROM base

- [HECHO] ROM limpia original:
  - ruta principal: `work/Momotarou Katsugeki (Japan).pce`
  - copia: `Roms/Original/Momotarou Katsugeki (Japan).pce`
  - tamaño: `524288` bytes / `0x80000`
  - MD5: `ec7358edb3672a8aa8850623eec72a71`
  - SHA1: `b63aa8ae29b4d06dea7f5b795c4192285fc3c43b`
  - SHA256: `548f41efee5b0b5dfed041766cd83aa54ba68f573b82733c81979d50ea65c1ad`
- [HECHO] No tiene cabecera copier de 512 bytes.
- [HECHO] Cadena interna en `0x1FE0`: `MOMOKATSU   1.07900518`.

## Herramientas creadas/usadas

- [HECHO] Herramientas principales en `tools/`:
  - `latin_text_tools.py`
  - `decode_text.py`
  - `extract_known_text_blocks.py`
  - `render_font_indexed.py`
  - `render_pce_tiles.py`
  - `dis6280_bin`
  - scripts `make_*` para pruebas de fuentes, título, password y menús.
- [HECHO] Se compiló `dis6280_bin` para desensamblar HuC6280.
- [HECHO] Se clonó y compiló `beetle-pce-fast-libretro` en:
  - `/home/user/emutools/beetle-pce-fast-libretro/`
- [HECHO] Se añadieron hooks mínimos al core para:
  - leer VRAM/SAT/MPR;
  - registrar escrituras VRAM filtradas;
  - registrar frame/PC/MPR.
- [HECHO] Runner mínimo libretro en:
  - `tools/libretro_pce_runner.py`
- [HECHO] Peculiaridad instrumental: `beetle-pce-fast-libretro` expone símbolos sólo si `link.T` exporta `arena_*`. Se parcheó `link.T`.
- [HECHO] Peculiaridad PCE sprites: X de SAT crudo se renderiza con offset de `-0x20` en Mednafen (`pos = SpriteList[i].x - 0x20`).

## Fuente latina y codificación

- [HECHO] Fuente 1bpp principal en ROM:
  - base `0x3D660`
  - formato `1bpp`, 8x8, 8 bytes/glifo.
- [HECHO] Tabla latina validada en:
  - `Tablas/charset_latin_charset_test_v2.tbl`
- [HECHO] Repertorio validado:
  - minúsculas/mayúsculas latinas;
  - tildes;
  - `ñ/Ñ`;
  - `¿? ¡!`;
  - números y puntuación.
- [HECHO] Bytes directos inseguros detectados:
  - `A2` para `b`, usar `5B`;
  - `A3` para `c`, usar `5D`;
  - `B0` para `p`, usar `5E`;
  - `5C` reservado como conmutador/escape;
  - `DE/DF` reservados en texto por dakuten/handakuten.
- [HECHO] Atajos validados:
  - `5B -> b`
  - `5D -> c`
  - `5E -> p`
  - `5F -> Ç`
- [HECHO] En `v03` se corrigieron `¡` y `¿` por inversión vertical de `!` y `?`.

## Título y menú principal

- [HECHO] Título/logo español aceptado:
  - `MOMOTARO EN ACCIÓN`
- [HECHO] Prompt de título aceptado:
  - `PULSA BOTÓN RUN`
- [HECHO] Menú principal aceptado:
  - `EMPEZAR`
  - `CONTINUAR`
- [HECHO] Build histórico confirmado:
  - `Roms/Anteriores/Momotarou Katsugeki (Japan) - title_menu_es_current.pce`
- [HECHO] En la organización actual sólo queda en principal la versión acumulativa más reciente.

## Password screen — descubrimientos iniciales

- [HECHO] La pantalla de password usa la fuente 1bpp `0x3D660`.
- [HECHO] La tabla `0x1F7B8-0x1F837` no controlaba visualmente la parrilla del password.
- [HECHO] La tabla runtime en torno a `0x1A897` alimenta la generación de glyphs de la parrilla.
- [HECHO] La columna derecha de opciones original se codificaba con IDs de glifo en el tilemap/estructura de pantalla.
- [HECHO] La lógica original de navegación/selección estaba en torno a:
  - `CC52`: obtiene valor seleccionado;
  - `CC61`: offsets por fila;
  - `CC6B`: tabla X cursor;
  - `CC78`: tabla Y cursor;
  - `CC82`: tabla de valores.
- [DESCARTADO] Modificar sólo la tabla de caracteres runtime para poner 64 latinos daba parrilla visual desordenada y no alineaba cursor/lógica.
- [DESCARTADO] Las primeras pruebas 8x8 y 10 columnas no solucionaban a la vez visual, cursor, orden y valores.

## Password screen — parrilla final

- [HECHO] Layout aceptado de parrilla agrupada:

```text
A B C D E F G     a b c d e f g
H I J K L M N     h i j k l m n
Ñ O P Q R S T     ñ o p q r s t
U V W X Y Z       u v w x y z

    0 1 2 3 4     5 6 7 8 9
```

- [HECHO] La fuente corregida por el usuario se importó desde `IMG_4536.PNG`.
- [HECHO] El usuario confirmó que todos los caracteres y números se insertan correctamente.
- [HECHO] Se corrigió un fallo del buffer: desde `q` en adelante entraba en ruta japonesa de dakuten/handakuten. Parche aplicado:
  - `CB97: CMP #$2D -> CMP #$41`
- [HECHO] El buffer inferior muestra puntos gruesos y slashes estáticos.
- [HECHO] `ESPACIO` debe dibujar punto grueso en el slot, no slash. Los slashes son separadores estáticos.

## Password screen — opciones columna derecha

- [HECHO] Opciones definitivas aceptadas:
  - `ADELANTE`
  - `ATRÁS`
  - `ESPACIO`
  - `BORRAR`
  - `FIN`
- [HECHO] `いれる` se confirmó funcionalmente como `ESPACIO`, no como “INTRODUCIR”.
- [HECHO] La columna se acabó insertando como gráfico del usuario (`IMG_4537.PNG`), no con mini-fuente 3x5.
- [DESCARTADO] Mini-fuente 3x5: funcionaba, pero visualmente desentonaba.
- [HECHO] La columna se bajó y se alineó a la caja inferior.
- [HECHO] Se corrigió el cursor de opciones con X/Y especiales.

## Password screen — navegación

- [HECHO] Se corrigió navegación horizontal invertida: derecha/izquierda se comportan como en pantalla.
- [HECHO] Ajustes DOWN confirmados:
  - `U/V + abajo -> 0`
  - `T + abajo -> Z`
  - `t + abajo -> z`
  - `z + abajo -> 9`
- [HECHO] El usuario confirmó que la navegación quedó según lo pedido.

## Password screen — mensaje de error de Jizo

- [HECHO] Texto final confirmado:

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

- [DESCARTADO] Intentar usar scroll/paginación con la caja original: se sobrescribía texto y/o sólo se veían 3 líneas.
- [HECHO] El mensaje de error es por sprites/metasprite, no BAT.
- [HECHO] La lista original visible del error era 3 filas x 4 sprites; se amplió a 5 columnas x 4 líneas.
- [HECHO] Se descubrió que offsets X de sprites en la lista son con signo: `$80` no es +128, sino negativo; se usó `$7F` para el límite positivo.
- [HECHO] Se limpió correctamente el área expandida para evitar residuos al repetir errores o volver desde endings:
  - `CE53: CPY #$18 -> #$28`
- [HECHO] Bocadillo central ajustado/centrado y confirmado por el usuario.
- [HECHO] El usuario confirmó que tras endings y errores repetidos el mensaje ya se ve limpio.

## Password screen — prompt superior

- [HECHO] Texto final:

```text
¡Introduce el canto de Jizo!
```

- [DESCARTADO] Overlay adicional desde `CD98`: mostraba texto duplicado y dejaba residuos en la pantalla de error.
- [DESCARTADO] Overlay alineado: seguía duplicando y dejando residuos.
- [DESCARTADO] Modificar lista `$402F` / `0x2E02F`: no cambió el corte real del prompt.
- [DESCARTADO] Modificar lista `$426C` / `0x2E26C`: no solucionó prompt y corrompió título.
- [DESCARTADO] Modificar lista `$4A45` / `0x2EA45`: sin cambios visibles.
- [HECHO] Lista `$4B33` sí controla el prompt. Su modificación afecta directamente a texto/marco.
- [HECHO] `$4B33` es una lista de entradas de 5 bytes:
  - byte 0 = offset de patrón;
  - byte 1 = atributo/paleta;
  - byte 2 = flags;
  - byte 3 = offset X con signo;
  - byte 4 = offset Y con signo.
- [HECHO] La generación de chunks del prompt se verificó con instrumentación de VRAM:
  - `1AE..1B7` recibían preparación completa;
  - `1B8..1BB` sólo recibían escritura parcial.
- [HECHO] Causa encontrada: la rutina de preparación real estaba en bank `$21`:
  - CPU `$BA8A`, ROM `0x43A8B`
  - `BA8A: LDY #$09`
- [HECHO] Parche confirmado por instrumentación:
  - `BA8A: LDY #$09 -> LDY #$0D`
  - ahora `1AE..1BB` se preparan completos.
- [HECHO] Marco superior reconstruido en `$4B33` relocalizada.
- [HECHO] Versión visual actual casi cerrada: prompt limpio, marco superior con lateral derecho pendiente/ajustes de marco finos.
- [HECHO] Capturas/archivos de análisis relevantes:
  - `images/prompt_chunks_prep_ba8a_vram_render.png`
  - `images/prompt_upper_sprites/frame_pieces_order.png`
  - `images/prompt_upper_sprites/assembled_prompt_box_and_text.png`
  - `reports/instrumentacion_prompt_causa_generacion.md`
  - `reports/prompt_upper_sprites_4b33.md`

## Passwords secretos probados

- [HECHO] El sistema interno de passwords sigue funcionando con nuestra parrilla latina.
- [HECHO] Passwords confirmados por el usuario:

```text
wCpeIfP     -> Ending muy difícil
cJQIep      -> Ending normal
GoFIBM      -> Ending difícil
rGAPad      -> Ending fácil
BqdGlCIWÑI  -> Sound test
BqdGlDWÑI   -> Graphics test
```

- [HECHO] `reports/passwords_secretos_probados.md` documenta la equivalencia.

## Menú password/load pendiente

- [HECHO] Prueba actual en `Roms/Pruebas`:
  - `Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_test.pce`
- [HECHO] El usuario probó una versión de menú y observó:
  - pantalla de dificultades: correcta;
  - selector inicial `CANTO DE JIZO / CARGAR`: caja estrecha y texto cortado;
  - selector de carga: caja estrecha y texto cortado.
- [HIPÓTESIS] Estas pantallas comparten problemas de marco/viewport similares al prompt superior/error Jizo y requerirán ampliar lista/ventana, no sólo repuntar texto.

## Build actual

- [HECHO] Versión acumulativa principal actual:
  - `Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce`
  - `Parches/momotaro_traduccion_v03.ips`
- [HECHO] Prueba activa actual:
  - `Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_test.pce`
  - `Parches/Pruebas/momotaro_traduccion_v04_password_menu_test.ips`
- [HECHO] `v04_password_menu_test` es una prueba de textos de menú/load; no está confirmada ni promovida.

## Errores propios relevantes

- [DESCARTADO/ERROR] Se asumió erróneamente que zonas aparentemente libres en bank `$17` podían usarse; causó corrupción del título/menú. Norma reforzada: comprobar contenido actual y no sólo referencias aparentes.
- [DESCARTADO/ERROR] Se usó overlay para prompt superior; funcionó como diagnóstico pero era solución sucia, duplicaba texto y dejaba residuos.
- [DESCARTADO/ERROR] Se confundió posición de piezas del marco con prioridad/orden de sprites. Norma: validar geométricamente continuidad de marco, no sólo presencia de una línea.
- [DESCARTADO/ERROR] Se parcheó una instrucción equivocada al cambiar base X (`LDY` en vez de operando de `LDX`), provocando cuelgue. Norma: desensamblar/validar bytes tras cualquier parche de código.
- [DESCARTADO/ERROR] Se respondió al hilo equivocado en una ocasión; norma de comunicación: confirmar cuál es la ROM/prueba activa antes de contestar si hay varias ramas de prueba.

## 2026-07-31 — v04 menu password/load: primera prueba cautelosa

- [HECHO] El usuario pidió abordar cajas de menú/load de una en una.
- [HECHO] Se empieza por el selector inicial `CANTO DE JIZO / CARGAR`, no por la pantalla de carga.
- [DESCARTADO] Prueba `traduccion_v04_main_selector_box_probe`: escribió una lista en `0x2FA59` de bank `$17`; el usuario observó corrupción en pantalla de título. Causa: espacio aparentemente libre pero compartido/ocupado en la ROM modificada. Refuerza norma de no usar bank `$17` sin verificar en base actual.
- [HECHO] Nueva prueba generada: `Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_safe_table_test.pce`.
- [HECHO] En esta prueba, los textos de menú/load se insertan en zona libre de bank `$0F` desde `0x1FB10`.
- [HECHO] La tabla/listas de `C5B6` se relocalizan a bank `$0F` seguro:
  - tabla nueva: ROM `0x1FBA6`, CPU `$5BA6`;
  - estado 0 copiado de `$4ADF`;
  - estado 1 ampliado para selector inicial;
  - estado 2/3 copiado de `$4AC1`.
- [HIPÓTESIS] Si esta prueba no corrompe título y ensancha caja inicial, se podrá aplicar la misma técnica a la pantalla de carga, pero verificando cada estado/lista por separado.

## 2026-07-31 — v04 menu selector: fallo observado y alias de passwords

- [HECHO] El usuario probó `traduccion_v04_password_menu_safe_table_test` y confirmó que el título ya no se corrompe.
- [HECHO] En el selector inicial, el texto sigue mal construido:
  - `CANTO DTO DE`
  - `CARGAARGA   R`
- [HECHO] La caja/lista parece haber aumentado o cambiado, pero el contenido textual se repite/solapa por chunks. Esto sugiere un problema de generación/preparación/proyección del texto, no sólo de marco.
- [HIPÓTESIS] El selector inicial podría tener una limitación similar al prompt superior: se proyectan más chunks de los que la rutina prepara correctamente, o se reutilizan offsets/patrones de la lista original.
- [HECHO] Tarea pendiente confirmada por el usuario: añadir alias significativos para passwords secretos originales japoneses.
- [HECHO] Objetivo de alias: conservar el significado original de passwords secretos japoneses que al remapearse a la parrilla latina quedan como secuencias sin sentido.
- [HECHO] Ejemplo dado por el usuario:
  - password japonés `いわさきはえがへた` = `Iwasaki dibuja mal`;
  - entrada latina actual equivalente: `BqdGlDWÑI`;
  - alias deseado futuro: permitir introducir algo como `IWASAKI DIBUJA MAL` o equivalente legible.
- [HIPÓTESIS] Implementación futura más segura: tabla de alias antes de la validación; si el buffer coincide con alias español, sustituir por la secuencia interna real y dejar que la validación original continúe.
