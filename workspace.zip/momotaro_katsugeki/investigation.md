# Diario de investigación — Momotarou Katsugeki ES

> Norma desde 2026-07-31: este archivo es el registro permanente del proyecto. Toda afirmación relevante debe marcarse como `[HECHO]`, `[HIPÓTESIS]` o `[DESCARTADO]`. Las hipótesis falsas se conservan.

## 2026-07-31 — Reglas de trabajo adoptadas

- [HECHO] El usuario aportó `PROMPT_METODO.md` con el método de trabajo para ingeniería inversa/romhacking.
- [HECHO] Reglas adoptadas para el resto del proyecto:
  - comprender antes de parchear;
  - mantener evidencias: offsets, trazas, capturas, volcados;
  - no asumir espacios libres sin comprobar contenido actual;
  - no borrar hipótesis falsas: marcarlas como `[DESCARTADO]`;
  - probar activamente en emulador/instrumentación cuando sea posible;
  - versiones numeradas acumulativas;
  - responder en castellano;
  - reconocer errores explícitamente.
- [HECHO] Este diario se crea tarde, cuando el proyecto ya está avanzado. Se reconstruye a partir de informes existentes, capturas y conversación.
- [HIPÓTESIS] Este diario debe ir sustituyendo progresivamente a notas dispersas en `reports/`, aunque se conservarán los informes específicos.

## ROM base

- [HECHO] ROM limpia original:
  - ruta principal: `work/Momotarou Katsugeki (Japan).pce`
  - copia: `Roms/Original/Momotarou Katsugeki (Japan).pce`
  - tamaño: `524288` bytes / `0x80000`
  - MD5: `ec7358edb3672a8aa8850623eec72a71`
  - SHA1: `b63aa8ae29b4d06dea7f5b795c4192285fc3c43b`
  - SHA256: `548f41efee5b0b5dfed041766cd83aa54ba68f573b82733c81979d50ea65c1ad`
- [HECHO] No tiene cabecera copier de 512 bytes.
- [HECHO] Cadena interna en `0x1FE0`: `MOMOKATSU   1.07900518`.

## Herramientas creadas/usadas

- [HECHO] Herramientas principales en `tools/`:
  - `latin_text_tools.py`
  - `decode_text.py`
  - `extract_known_text_blocks.py`
  - `render_font_indexed.py`
  - `render_pce_tiles.py`
  - `dis6280_bin`
  - scripts `make_*` para pruebas de fuentes, título, password y menús.
- [HECHO] Se compiló `dis6280_bin` para desensamblar HuC6280.
- [HECHO] Se clonó y compiló `beetle-pce-fast-libretro` en:
  - `/home/user/emutools/beetle-pce-fast-libretro/`
- [HECHO] Se añadieron hooks mínimos al core para:
  - leer VRAM/SAT/MPR;
  - registrar escrituras VRAM filtradas;
  - registrar frame/PC/MPR.
- [HECHO] Runner mínimo libretro en:
  - `tools/libretro_pce_runner.py`
- [HECHO] Peculiaridad instrumental: `beetle-pce-fast-libretro` expone símbolos sólo si `link.T` exporta `arena_*`. Se parcheó `link.T`.
- [HECHO] Peculiaridad PCE sprites: X de SAT crudo se renderiza con offset de `-0x20` en Mednafen (`pos = SpriteList[i].x - 0x20`).

## Fuente latina y codificación

- [HECHO] Fuente 1bpp principal en ROM:
  - base `0x3D660`
  - formato `1bpp`, 8x8, 8 bytes/glifo.
- [HECHO] Tabla latina validada en:
  - `Tablas/charset_latin_charset_test_v2.tbl`
- [HECHO] Repertorio validado:
  - minúsculas/mayúsculas latinas;
  - tildes;
  - `ñ/Ñ`;
  - `¿? ¡!`;
  - números y puntuación.
- [HECHO] Bytes directos inseguros detectados:
  - `A2` para `b`, usar `5B`;
  - `A3` para `c`, usar `5D`;
  - `B0` para `p`, usar `5E`;
  - `5C` reservado como conmutador/escape;
  - `DE/DF` reservados en texto por dakuten/handakuten.
- [HECHO] Atajos validados:
  - `5B -> b`
  - `5D -> c`
  - `5E -> p`
  - `5F -> Ç`
- [HECHO] En `v03` se corrigieron `¡` y `¿` por inversión vertical de `!` y `?`.

## Título y menú principal

- [HECHO] Título/logo español aceptado:
  - `MOMOTARO EN ACCIÓN`
- [HECHO] Prompt de título aceptado:
  - `PULSA BOTÓN RUN`
- [HECHO] Menú principal aceptado:
  - `EMPEZAR`
  - `CONTINUAR`
- [HECHO] Build histórico confirmado:
  - `Roms/Anteriores/Momotarou Katsugeki (Japan) - title_menu_es_current.pce`
- [HECHO] En la organización actual sólo queda en principal la versión acumulativa más reciente.

## Password screen — descubrimientos iniciales

- [HECHO] La pantalla de password usa la fuente 1bpp `0x3D660`.
- [HECHO] La tabla `0x1F7B8-0x1F837` no controlaba visualmente la parrilla del password.
- [HECHO] La tabla runtime en torno a `0x1A897` alimenta la generación de glyphs de la parrilla.
- [HECHO] La columna derecha de opciones original se codificaba con IDs de glifo en el tilemap/estructura de pantalla.
- [HECHO] La lógica original de navegación/selección estaba en torno a:
  - `CC52`: obtiene valor seleccionado;
  - `CC61`: offsets por fila;
  - `CC6B`: tabla X cursor;
  - `CC78`: tabla Y cursor;
  - `CC82`: tabla de valores.
- [DESCARTADO] Modificar sólo la tabla de caracteres runtime para poner 64 latinos daba parrilla visual desordenada y no alineaba cursor/lógica.
- [DESCARTADO] Las primeras pruebas 8x8 y 10 columnas no solucionaban a la vez visual, cursor, orden y valores.

## Password screen — parrilla final

- [HECHO] Layout aceptado de parrilla agrupada:

```text
A B C D E F G     a b c d e f g
H I J K L M N     h i j k l m n
Ñ O P Q R S T     ñ o p q r s t
U V W X Y Z       u v w x y z

    0 1 2 3 4     5 6 7 8 9
```

- [HECHO] La fuente corregida por el usuario se importó desde `IMG_4536.PNG`.
- [HECHO] El usuario confirmó que todos los caracteres y números se insertan correctamente.
- [HECHO] Se corrigió un fallo del buffer: desde `q` en adelante entraba en ruta japonesa de dakuten/handakuten. Parche aplicado:
  - `CB97: CMP #$2D -> CMP #$41`
- [HECHO] El buffer inferior muestra puntos gruesos y slashes estáticos.
- [HECHO] `ESPACIO` debe dibujar punto grueso en el slot, no slash. Los slashes son separadores estáticos.

## Password screen — opciones columna derecha

- [HECHO] Opciones definitivas aceptadas:
  - `ADELANTE`
  - `ATRÁS`
  - `ESPACIO`
  - `BORRAR`
  - `FIN`
- [HECHO] `いれる` se confirmó funcionalmente como `ESPACIO`, no como “INTRODUCIR”.
- [HECHO] La columna se acabó insertando como gráfico del usuario (`IMG_4537.PNG`), no con mini-fuente 3x5.
- [DESCARTADO] Mini-fuente 3x5: funcionaba, pero visualmente desentonaba.
- [HECHO] La columna se bajó y se alineó a la caja inferior.
- [HECHO] Se corrigió el cursor de opciones con X/Y especiales.

## Password screen — navegación

- [HECHO] Se corrigió navegación horizontal invertida: derecha/izquierda se comportan como en pantalla.
- [HECHO] Ajustes DOWN confirmados:
  - `U/V + abajo -> 0`
  - `T + abajo -> Z`
  - `t + abajo -> z`
  - `z + abajo -> 9`
- [HECHO] El usuario confirmó que la navegación quedó según lo pedido.

## Password screen — mensaje de error de Jizo

- [HECHO] Texto final confirmado:

```text
¡El canto de Jizo
no es correcto!
Revísalo bien e
inténtalo de nuevo.
```

- [DESCARTADO] Intentar usar scroll/paginación con la caja original: se sobrescribía texto y/o sólo se veían 3 líneas.
- [HECHO] El mensaje de error es por sprites/metasprite, no BAT.
- [HECHO] La lista original visible del error era 3 filas x 4 sprites; se amplió a 5 columnas x 4 líneas.
- [HECHO] Se descubrió que offsets X de sprites en la lista son con signo: `$80` no es +128, sino negativo; se usó `$7F` para el límite positivo.
- [HECHO] Se limpió correctamente el área expandida para evitar residuos al repetir errores o volver desde endings:
  - `CE53: CPY #$18 -> #$28`
- [HECHO] Bocadillo central ajustado/centrado y confirmado por el usuario.
- [HECHO] El usuario confirmó que tras endings y errores repetidos el mensaje ya se ve limpio.

## Password screen — prompt superior

- [HECHO] Texto final:

```text
¡Introduce el canto de Jizo!
```

- [DESCARTADO] Overlay adicional desde `CD98`: mostraba texto duplicado y dejaba residuos en la pantalla de error.
- [DESCARTADO] Overlay alineado: seguía duplicando y dejando residuos.
- [DESCARTADO] Modificar lista `$402F` / `0x2E02F`: no cambió el corte real del prompt.
- [DESCARTADO] Modificar lista `$426C` / `0x2E26C`: no solucionó prompt y corrompió título.
- [DESCARTADO] Modificar lista `$4A45` / `0x2EA45`: sin cambios visibles.
- [HECHO] Lista `$4B33` sí controla el prompt. Su modificación afecta directamente a texto/marco.
- [HECHO] `$4B33` es una lista de entradas de 5 bytes:
  - byte 0 = offset de patrón;
  - byte 1 = atributo/paleta;
  - byte 2 = flags;
  - byte 3 = offset X con signo;
  - byte 4 = offset Y con signo.
- [HECHO] La generación de chunks del prompt se verificó con instrumentación de VRAM:
  - `1AE..1B7` recibían preparación completa;
  - `1B8..1BB` sólo recibían escritura parcial.
- [HECHO] Causa encontrada: la rutina de preparación real estaba en bank `$21`:
  - CPU `$BA8A`, ROM `0x43A8B`
  - `BA8A: LDY #$09`
- [HECHO] Parche confirmado por instrumentación:
  - `BA8A: LDY #$09 -> LDY #$0D`
  - ahora `1AE..1BB` se preparan completos.
- [HECHO] Marco superior reconstruido en `$4B33` relocalizada.
- [HECHO] Versión visual actual casi cerrada: prompt limpio, marco superior con lateral derecho pendiente/ajustes de marco finos.
- [HECHO] Capturas/archivos de análisis relevantes:
  - `images/prompt_chunks_prep_ba8a_vram_render.png`
  - `images/prompt_upper_sprites/frame_pieces_order.png`
  - `images/prompt_upper_sprites/assembled_prompt_box_and_text.png`
  - `reports/instrumentacion_prompt_causa_generacion.md`
  - `reports/prompt_upper_sprites_4b33.md`

## Passwords secretos probados

- [HECHO] El sistema interno de passwords sigue funcionando con nuestra parrilla latina.
- [HECHO] Passwords confirmados por el usuario:

```text
wCpeIfP     -> Ending muy difícil
cJQIep      -> Ending normal
GoFIBM      -> Ending difícil
rGAPad      -> Ending fácil
BqdGlCIWÑI  -> Sound test
BqdGlDWÑI   -> Graphics test
```

- [HECHO] `reports/passwords_secretos_probados.md` documenta la equivalencia.

## Menú password/load pendiente

- [HECHO] Prueba actual en `Roms/Pruebas`:
  - `Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_test.pce`
- [HECHO] El usuario probó una versión de menú y observó:
  - pantalla de dificultades: correcta;
  - selector inicial `CANTO DE JIZO / CARGAR`: caja estrecha y texto cortado;
  - selector de carga: caja estrecha y texto cortado.
- [HIPÓTESIS] Estas pantallas comparten problemas de marco/viewport similares al prompt superior/error Jizo y requerirán ampliar lista/ventana, no sólo repuntar texto.

## Build actual

- [HECHO] Versión acumulativa principal actual:
  - `Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce`
  - `Parches/momotaro_traduccion_v03.ips`
- [HECHO] Prueba activa actual:
  - `Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_test.pce`
  - `Parches/Pruebas/momotaro_traduccion_v04_password_menu_test.ips`
- [HECHO] `v04_password_menu_test` es una prueba de textos de menú/load; no está confirmada ni promovida.

## Errores propios relevantes

- [DESCARTADO/ERROR] Se asumió erróneamente que zonas aparentemente libres en bank `$17` podían usarse; causó corrupción del título/menú. Norma reforzada: comprobar contenido actual y no sólo referencias aparentes.
- [DESCARTADO/ERROR] Se usó overlay para prompt superior; funcionó como diagnóstico pero era solución sucia, duplicaba texto y dejaba residuos.
- [DESCARTADO/ERROR] Se confundió posición de piezas del marco con prioridad/orden de sprites. Norma: validar geométricamente continuidad de marco, no sólo presencia de una línea.
- [DESCARTADO/ERROR] Se parcheó una instrucción equivocada al cambiar base X (`LDY` en vez de operando de `LDX`), provocando cuelgue. Norma: desensamblar/validar bytes tras cualquier parche de código.
- [DESCARTADO/ERROR] Se respondió al hilo equivocado en una ocasión; norma de comunicación: confirmar cuál es la ROM/prueba activa antes de contestar si hay varias ramas de prueba.

## 2026-07-31 — v04 menu password/load: primera prueba cautelosa

- [HECHO] El usuario pidió abordar cajas de menú/load de una en una.
- [HECHO] Se empieza por el selector inicial `CANTO DE JIZO / CARGAR`, no por la pantalla de carga.
- [DESCARTADO] Prueba `traduccion_v04_main_selector_box_probe`: escribió una lista en `0x2FA59` de bank `$17`; el usuario observó corrupción en pantalla de título. Causa: espacio aparentemente libre pero compartido/ocupado en la ROM modificada. Refuerza norma de no usar bank `$17` sin verificar en base actual.
- [HECHO] Nueva prueba generada: `Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_safe_table_test.pce`.
- [HECHO] En esta prueba, los textos de menú/load se insertan en zona libre de bank `$0F` desde `0x1FB10`.
- [HECHO] La tabla/listas de `C5B6` se relocalizan a bank `$0F` seguro:
  - tabla nueva: ROM `0x1FBA6`, CPU `$5BA6`;
  - estado 0 copiado de `$4ADF`;
  - estado 1 ampliado para selector inicial;
  - estado 2/3 copiado de `$4AC1`.
- [HIPÓTESIS] Si esta prueba no corrompe título y ensancha caja inicial, se podrá aplicar la misma técnica a la pantalla de carga, pero verificando cada estado/lista por separado.

## 2026-07-31 — v04 menu selector: fallo observado y alias de passwords

- [HECHO] El usuario probó `traduccion_v04_password_menu_safe_table_test` y confirmó que el título ya no se corrompe.
- [HECHO] En el selector inicial, el texto sigue mal construido:
  - `CANTO DTO DE`
  - `CARGAARGA   R`
- [HECHO] La caja/lista parece haber aumentado o cambiado, pero el contenido textual se repite/solapa por chunks. Esto sugiere un problema de generación/preparación/proyección del texto, no sólo de marco.
- [HIPÓTESIS] El selector inicial podría tener una limitación similar al prompt superior: se proyectan más chunks de los que la rutina prepara correctamente, o se reutilizan offsets/patrones de la lista original.
- [HECHO] Tarea pendiente confirmada por el usuario: añadir alias significativos para passwords secretos originales japoneses.
- [HECHO] Objetivo de alias: conservar el significado original de passwords secretos japoneses que al remapearse a la parrilla latina quedan como secuencias sin sentido.
- [HECHO] Ejemplo dado por el usuario:
  - password japonés `いわさきはえがへた` = `Iwasaki dibuja mal`;
  - entrada latina actual equivalente: `BqdGlDWÑI`;
  - alias deseado futuro: permitir introducir algo como `IWASAKI DIBUJA MAL` o equivalente legible.
- [HIPÓTESIS] Implementación futura más segura: tabla de alias antes de la validación; si el buffer coincide con alias español, sustituir por la secuencia interna real y dejar que la validación original continúe.

## 2026-08-01 — Reconstrucción del entorno y verificación de v03

- [HECHO] Se descargó y descomprimió el `workspace.zip` indicado por el usuario en `/home/user/reconstruction`. Se leyó completo este diario, `uploads/PROMPT_METODO.md` y los informes clave: `informe_inicial_momotaro_katsugeki.md`, `estado_traduccion_v03.md`, `password_investigacion_estado.md` y `prompt_superior_pruebas_fallidas.md`.
- [HECHO] Se actualizó `ESTRUCTURA_WORKSPACE.md` conforme al contenido real de la instantánea. En particular, existen los directorios `Roms/Pruebas`, `Roms/Anteriores`, `Parches/Pruebas` y `Parches/Anteriores`, pero no contienen entregas en esta instantánea.
- [HECHO] La única ROM de traducción entregable presente es `Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce` (524288 bytes):
  - MD5 `570c7ab23ae6fcc7002d6d6664df2239`
  - SHA-1 `387b2817a1e04246bec0e1b1441ea8fb3a55d1cf`
  - SHA-256 `cb119f2a65f6f41367ba810a15e027315a91098c3a636285501273a31deeeda1`
  - CRC32 `c6739728`.
- [HECHO] `Parches/momotaro_traduccion_v03.ips` está presente (7721 bytes): SHA-1 `808a173180c3c417f33461650c66f8c25e4ab392`, CRC32 `68107769`.
- [HECHO] Los informes y generadores de `traduccion_v04_password_menu_safe_table_test` sí están presentes (`reports/test_v04_password_menu_safe_table.md`, `tools/make_v04_password_menu_safe_table_test.py`), pero no hay ningún `.pce` ni `.ips` v04 en el ZIP. Por tanto no se puede ejecutar ni verificar esa prueba desde esta instantánea sin regenerarla; no se ha regenerado ni modificado ninguna ROM.
- [HECHO] La ROM limpia de `work/Momotarou Katsugeki (Japan).pce` es idéntica byte a byte a `Roms/Original/Momotarou Katsugeki (Japan).pce` (`cmp -s`).
- [HECHO] Se comprobó el core en `emutools/beetle-pce-fast-libretro/mednafen_pce_fast_libretro.so`: ELF x86-64, SHA-256 `b80184ffc6255d5f7f015fc92a3705788663115c1007dbcd4241ba49c2b5ce3b`, GNU Build-ID `715d893dd566d80c09c189644b0e8c2b081c9e11`. `ldd` resolvió `libc.so.6` y `libm.so.6`, sin biblioteca ausente.
- [HECHO] No fue necesario recompilar el core: cargó mediante `ctypes.CDLL` y `retro_load_game` aceptó v03. El core se identificó como `Beetle PCE Fast v1.31.0.0`, con geometría base 256x243. La copia incluida no tiene directorio `.git` ni otro identificador de revisión de fuentes; el commit exacto no es recuperable con evidencia desde este workspace. No se inventa uno.
- [HECHO] El runner tiene por defecto una ruta absoluta antigua (`/home/user/emutools/...`) que no existe en este entorno reconstruido. La verificación se hizo pasando explícitamente el core de `/home/user/reconstruction/emutools/...`; no se modificó el runner.
- [HECHO] Ejecución de control de v03: tras 240 frames se recibió vídeo 256x243 y PC `$E5BB`, con MPR `[FF,F8,17,00,20,21,0C,00]`. Captura individual: `instrument/environment_check_v03_frame240.png`, SHA-256 `887e6c6a572b0378627d4e1f63a224a984e53b024b6f32e9853c6ef12ba9f7b4`.
- [HECHO] Ejecución de control visual: a frame 1800, tras inyectar el input libretro ID 3 en los frames 1790--1791, se obtuvo `instrument/environment_check_v03_title_menu.png` (SHA-256 `cb6739731fdfb5752cd2b0bdd68fa07ca5972e8ccc01b7e7c12ca810d145c1f2`). La captura muestra el título `MOMOTARO EN ACCIÓN`, el prompt `PULSA BOTÓN RUN` y el menú `EMPEZAR` / `CONTINUAR` sin corrupción visible. Esto verifica que el core carga y ejecuta la ROM v03 parcheada.
- [HECHO] No se escribió ningún byte en ROM, IPS, BRAM/SRM ni en los scripts de parcheo durante esta reconstrucción. Los únicos cambios de esta sesión son `ESTRUCTURA_WORKSPACE.md`, esta entrada de diario y capturas de verificación dentro de `instrument/`.

## 2026-08-01 — Runner, referencia BRAM real y limpieza del archivo

- [HECHO] Se corrigió el instrumental `tools/libretro_pce_runner.py` (SHA-256 tras el cambio: `9d66fbdee86246df469591a3fb4bdc00fe492a028922d829092d1422a05facdf`). `DEFAULT_CORE_PATH` se resuelve desde `__file__` como `<workspace>/emutools/beetle-pce-fast-libretro/mednafen_pce_fast_libretro.so`; se eliminó la dependencia de `/home/user/emutools/...`.
- [HECHO] Control del cambio: `python3 tools/libretro_pce_runner.py 'Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce'` carga el core por defecto, ejecuta 10 frames y devuelve vídeo 256x243. No se ha modificado ninguna ROM.
- [HECHO] Se añadió al runner soporte explícito de SaveRAM del frontend libretro: `save_ram_path=...`, `read_save_ram()` y validación de tamaño. Evidencia en `libretro.c`: `retro_get_memory_data(RETRO_MEMORY_SAVE_RAM)` devuelve `SaveRAM` y `retro_get_memory_size(...)` devuelve 2048 bytes para esta ROM (`libretro.c:2818-2857`). El core no persiste los SRM por sí mismo en este frontend mínimo; el runner los carga después de `retro_load_game` y nunca escribe automáticamente de vuelta al fichero de origen.
- [HECHO] SRM real aportado: `uploads/savestate/Momotarou Katsugeki (Japan).srm`, 2048 bytes, MD5 `15e2124911a4d18782e012da7029c128`, SHA-1 `debcc6d62c27e7628104d7bfa18373a3362226a1`, SHA-256 `b3f4cff1a2e7ea6a348089809ed6f765c8fc68dc1c5997a3fb9c16fdaeaecdef`, CRC32 `edb73b3e`.
- [HECHO] Al cargar ese fichero real, los 2048 bytes expuestos por `retro_get_memory_data(RETRO_MEMORY_SAVE_RAM)` coincidieron byte a byte con el fichero fuente antes de ejecutar. Tras la captura permanecieron iguales tanto la RAM del core como el SRM de origen (mismo SHA-256). Esta ejecución usa una partida real aportada por el usuario; no usa BRAM sintética, memoria forzada ni parche de ROM.
- [HECHO] Referencia visual requerida del selector: `instrument/bram_validation/reference_real_srm_selector_frame2050.png`, SHA-256 `0d69ef23d32b02d04a669fd50c3699570dc78daf4f1dca44303f4a39f04d72f3`. Protocolo de entrada desde arranque: ID libretro 3 (RUN/Start) en frames 1790--1799; ID 5 (DOWN) en 1800--1819; ID 3 en 1850--1859; captura en frame 2050. El control intermedio `input_timing_after_down_frame1825.png` muestra `CONTINUAR` seleccionado antes de confirmar. La referencia conserva los textos tal como están en v03; no se pretende que sea la prueba v04 ausente.
- [DESCARTADO/ERROR] Primera secuencia de navegación: DOWN sólo en frames 1810--1811 y confirmación en 1830. Se etiquetó inicialmente de forma demasiado amplia como referencia. Control posterior sin DOWN produjo una captura idéntica byte a byte (`d1b602513614bfdcef294d6efe45af8328d246bf674a0d19dd4ffff96b914d6a`), por lo que ese DOWN no había sido aceptado. La captura se conserva y se renombró `control_real_srm_down_too_early_frame2050.png`; no se usa como referencia. Norma aplicada: validar el estado de selección con una captura antes de declarar alcanzada una pantalla.
- [HECHO] Antes de borrar `workspace.zip` se ejecutó `unzip -t`: sin errores. Se inspeccionó `__MACOSX/`: 791 ficheros, todos AppleDouble (`._*`), y los 791 tenían un payload equivalente existente fuera de esa carpeta; no contenía datos únicos del proyecto. Con esa verificación se eliminaron `/home/user/reconstruction/workspace.zip` y `/home/user/reconstruction/__MACOSX/`. No se eliminó ningún archivo de proyecto.

## 2026-08-01 — Error de compilación al ampliar la instrumentación BRAM

- [DESCARTADO/ERROR] Primer intento de instrumentar la BRAM: se añadió `arena_current_pc_for_bus = GetRealPC()` dentro de las funciones auxiliares `RdMem`/`WrMem` de `huc6280.c` y se ejecutó `make -j168` en `emutools/beetle-pce-fast-libretro`.
- [HECHO] La compilación falló antes del enlazado: `PC_local undeclared` en `RdMem` y `WrMem` (`huc6280.c:185,202`). Evidencia completa: `instrument/bram_validation/core_rebuild_2026-08-01.log`.
- [HECHO] Causa: `GetRealPC()` depende de `PC_local`, variable local del bucle de ejecución de CPU; `RdMem`/`WrMem` son funciones independientes y no tienen ese ámbito. La suposición de que podían leer directamente el PC local fue incorrecta.
- [HECHO] No se ha sustituido el `.so` anterior: el fallo ocurrió al compilar objetos y no llegó a enlazar. No hubo modificación de ROM, IPS ni SRM.
- [HECHO] Norma reforzada: antes de insertar un hook en una función auxiliar del núcleo, comprobar si la dirección/PC que se pretende registrar está disponible en su ámbito, no sólo que el macro exista en el mismo fichero.

## 2026-08-01 — Instrumentación BRAM y primera traza de validación

- [HECHO] Se localizó en el core que `SaveRAM` tiene 2048 bytes y que el bus CPU la atiende en la página física `$F7` (`SaveRAMRead`/`SaveRAMWrite` en `libretro.c`). Se añadió instrumentación de lecturas/escrituras que registra `frame`, tipo, offset, valor, PC del opcode y MPR.
- [DESCARTADO/ERROR] Primer intento de registrar `GetRealPC()` directamente dentro de `RdMem`/`WrMem` falló al compilar: `PC_local undeclared`. Causa: ese PC es local al bucle de `HuC6280_Run`, no a las funciones auxiliares. La salida está en `instrument/bram_validation/core_rebuild_2026-08-01.log`. No se enlazó ni sustituyó el core anterior.
- [HECHO] Corrección instrumental: el PC de bus se fija al inicio de cada opcode dentro de `HuC6280_Run` y se conserva durante sus accesos `RdMem`/`WrMem`. Compilaciones exitosas posteriores: `make -j168` en `emutools/beetle-pce-fast-libretro/`; registros completos en `core_rebuild_bramlog_fix_2026-08-01.log` y `core_rebuild_bramlog_control_2026-08-01.log`.
- [HECHO] Core instrumentado final: SHA-256 `08aba6ae9abb7794a44d9cc25ed5a1c1b9ce7ac218b57f1fec31accc5bba24c8`, Build-ID `3c6c795cd67d5e9e5438e545abb0b431e2fb075b`. Sigue sin haber metadatos Git, por lo que no hay commit de fuentes recuperable.
- [HECHO] Se añadió al runner lectura de System RAM y API de BRAM log. Hash actual de `tools/libretro_pce_runner.py`: `220a5b4627e211429a7dbe32b0348c19670f8998f6683828a17124e03b681ba4`. Herramienta reproducible: `tools/trace_bram_validation.py`, SHA-256 `30940cffb7e08b8e71c537f5f66f4b4bf6e4325840d8f6156b417fc5954dae63`.
- [HECHO] Prueba de control del contador: `arena_bramlog_control_read()` llamó explícitamente al mismo handler `SaveRAMRead`, sin ejecutar código del juego ni escribir BRAM. Con el SRM real leyó `$000=$48` y `$060=$01`, con dos entradas registradas. Evidencia `instrument/bram_validation/bramlog_control_external_not_game.tsv` (SHA-256 `25df35ea6be7e8bd17bf26b3d4a802d82e84a50d71852779b20323ab0f9e0091`). Este control es instrumental, no comportamiento del juego.
- [DESCARTADO/ERROR] Se asumió inicialmente que el menú de título `EMPEZAR / CONTINUAR` era vertical y se pulsó DOWN. Es horizontal; DOWN no seleccionó `CONTINUAR`, RUN entró en `EMPEZAR` y produjo una pantalla de introducción. Se conserva la evidencia con nombres `*_wrong_route` y `control_real_srm_selected_empezar_not_selector_frame2050.png`; no se usa para conclusiones BRAM. Norma reforzada: antes de declarar una pantalla alcanzada, validar el estado de selección con captura y/o RAM.
- [HECHO] Protocolo correcto hasta `CANTO DE JIZO / CARGAR`: RUN F1790--1799; RIGHT F1800--1819; RUN F1850--1859. La referencia real correcta es `instrument/bram_validation/reference_real_srm_canto_cargar_frame2050.png`, SHA-256 `982166c2fd548c07aa48ce44be4e2002ac2ef95aef6122365601fb8d90cc61cd`. En F2050 se midió System RAM `$3C83=01`, `$3C84=00`, `$3C85=02`.
- [HECHO] En la ruta correcta, al confirmar CONTINUAR, la traza con SRM real contiene 2972 lecturas BRAM (F1863--F1864), cero escrituras; control de BRAM inicializada por el core: 10 lecturas en F1863, cero escrituras. Evidencias:
  - `instrument/bram_validation/bram_trace_real_srm_title_continue_to_selector.tsv`, SHA-256 `5adeb8933711ab7ec46cc7f68d99a8c20c82f8db9906df0c551f31734a05ae58`;
  - `instrument/bram_validation/bram_trace_core_initialized_title_continue_to_selector.tsv`, SHA-256 `5102e5cf6be47124a2d73ef664ec18f61b2eb557b5c32ab73d361d7bf0b493f7`.
- [HECHO] En todos esos accesos MPR0--7 = `FF F8 17 00 F7 21 2F 00`: MPR4=`$F7` mapea BRAM en CPU `$8000-$9FFF`; MPR6=`$2F` mapea el código CPU `$Dxxx` al banco físico `$2F`.
- [HECHO] Rutina de validación localizada y desensamblada en `instrument/bram_validation/bank_2F_validation_trace_window.asm`:
  - `$DB4F-$DB5A` compara `$8000-$8003` con firma `HUBM`;
  - `$DB5C-$DB8E` inspecciona `$8010-$8011` y `$8006-$8007`;
  - `$DAD3-$DAFA`, incluido `$DAF0`, compara la firma desde `$8014`; la traza observa `00 00 MOMOKATSU.` en `$8014-$801F`;
  - `$DB1C-$DB4E` recorre y suma el bloque; `$D8B0-$D8BE` incorpora el checksum almacenado.
- [HECHO] Comprobación matemática del SRM real: `$8010-$8011 = $0090`; la rutina recorre `$8014-$809F` (140 bytes). La suma es `$0FDC`; el valor `$8012-$8013` es `$F024`; suma módulo `$10000` = `$0000`. Esto demuestra checksum aditivo complementario de 16 bits para esta estructura.
- [HECHO] Con SRM real, escoger CARGAR y confirmar provoca 206 lecturas BRAM en F2620, cero escrituras, y llega al mapa del juego. Evidencias `bram_trace_real_srm_load_confirm.tsv` (SHA-256 `65f156fb243d6dd3254c3b1f8b28d7c9da3812ba65fb533349f4e7ac19b033d9`) y `real_srm_after_load_confirm_frame3200.png` (SHA-256 `72ec528d47b521936d3caae5638456301a8de14b507224b4895d94df9991f3c6`).
- [HECHO] Con BRAM inicializada por el core, la misma navegación termina en canto de Jizo y no alcanza el selector de carga; por eso su traza de confirmación de carga es cero. Captura `control_core_initialized_after_load_confirm_frame3200.png`, SHA-256 `4735a0e73b86f30d8f8361d5576dee98e738571c5678eb8f95dc945d8241b955`.
- [HECHO] Integridad tras las trazas: v03 conserva SHA-256 `cb119f2a65f6f41367ba810a15e027315a91098c3a636285501273a31deeeda1`; el SRM real conserva SHA-256 `b3f4cff1a2e7ea6a348089809ed6f765c8fc68dc1c5997a3fb9c16fdaeaecdef`.
- [HECHO] No se ha generado BRAM sintética, no se ha forzado memoria de juego y no se ha aplicado ningún bypass o parche a ROM.

## 2026-08-01 — BRAM sintética v01: construcción y verificación inversa

- [HECHO] Se creó `tools/build_synthetic_bram_v01.py` (SHA-256 `2fec5f503e78140e436bd0708568ff9607c515c1f2f093f9abf95e377b120c9b`). El generador parte de un `bytearray(0x800)` de ceros; no abre ni copia el SRM aportado.
- [HECHO] Se generó la primera entrega numerada de BRAM sintética: `instrument/bram_validation/generated/synthetic_bram_v01_reconstructed.srm`, 2048 bytes:
  - MD5 `15e2124911a4d18782e012da7029c128`
  - SHA-1 `debcc6d62c27e7628104d7bfa18373a3362226a1`
  - SHA-256 `b3f4cff1a2e7ea6a348089809ed6f765c8fc68dc1c5997a3fb9c16fdaeaecdef`
  - CRC32 `edb73b3e`.
- [HECHO] v01 escribe desde cero la cabecera `HUBM 00 88 A0 80`, tamaño `$0090`, firma `00 00 MOMOKATSU.`, payload medido en `$0060-$007F` y calcula el checksum con `(-sum(cuerpo)) & $FFFF`; calcula `$F024` para `$0012-$0013`. El resto de bytes queda a cero; 45 bytes no nulos.
- [HECHO] Comparación externa posterior, separada del generador: v01 es idéntica byte a byte al SRM real de referencia. Esto demuestra una reconstrucción reproducible de esa estructura desde un buffer cero, pero v01 no es todavía una partida nueva distinta: reconstruye el mismo estado conocido mediante constantes medidas.
- [HECHO] Verificación inversa obligatoria: se cargó v01 por el runner, siguiendo la misma entrada hacia CONTINUAR. La traza `instrument/bram_validation/bram_trace_synthetic_v01_title_continue_to_selector.tsv` contiene exactamente 2972 lecturas BRAM, cero escrituras, SHA-256 `1924493547b62f0a3f106449b0bc8afd78a8d0ed03b86f9024f4afea1b2a4be0`.
- [HECHO] Se compararon las filas de datos de esa traza con la traza del SRM real, ignorando sólo cabeceras de procedencia: igualdad exacta de las 2972 filas (frame, tipo, offset, valor, PC y MPR). No se aceptó la versión basándose sólo en el contador.
- [HECHO] La captura del selector generada con v01 es idéntica píxel a píxel a la referencia real: `instrument/bram_validation/synthetic_v01_canto_cargar_frame2050.png`, SHA-256 `982166c2fd548c07aa48ce44be4e2002ac2ef95aef6122365601fb8d90cc61cd`.
- [HECHO] Verificación adicional: al seleccionar CARGAR y confirmar, v01 produjo 206 lecturas y cero escrituras. Sus 206 filas son idénticas a la traza real de carga. La captura final del mapa es idéntica píxel a píxel: `synthetic_v01_after_load_confirm_frame3200.png`, SHA-256 `72ec528d47b521936d3caae5638456301a8de14b507224b4895d94df9991f3c6`.
- [HECHO] v01, la ROM v03 y el SRM real de origen conservaron sus SHA-256 durante las pruebas. No se ha modificado ROM, IPS ni el SRM original; no se ha usado bypass ni estado de juego forzado.
- [HIPÓTESIS] Para generar estados nuevos y no sólo reconstruir el de referencia faltará asignar significado al payload `$0060-$007F` y comprobar si existen estructuras posteriores. No se modifica ningún byte de ese payload sin medir primero su efecto.

## 2026-08-01 — Payload BRAM: transferencia, descifrado y v02 inyectada

- [HECHO] Se instrumentaron lecturas/escrituras CPU a System RAM, con rango filtrable. Core final de esta fase: SHA-256 `69b13909fc26e2e197694e58b430cef00370480d07e012e34a211f558d2e575f`, Build-ID `50a930de194e61405a4151fceab36fb92671b3fe`; compilación exacta `make -j168`, salida en `instrument/bram_validation/core_rebuild_ramlog_reads_2026-08-01.log`.
- [HECHO] Prueba de control: 20 frames de arranque normal registraron 30958 accesos de escritura a System RAM. El contador puede subir.
- [HECHO] Primer registro sin filtro entre F2600--F3199 alcanzó el tope de 200000 entradas; quedó documentado en `ram_trace_synthetic_v01_load_confirm.tsv`, pero no se usa como evidencia completa. Se aplicó un filtro `$17D7-$17F6` y ventanas de un frame/100 frames sin saturación.
- [HECHO] Al confirmar CARGAR en F2620, el código CPU `$DBFB` lee exactamente BRAM `$0060-$007F` y `$DBFD` escribe los 32 mismos valores, en el mismo orden, en System RAM `$17D7-$17F6`. Evidencia emparejada: `instrument/bram_validation/bram_to_system_ram_copy_synthetic_v01.tsv`, SHA-256 `8669c7eadac6a7e6c5ad6e3275a8d149517c2f88728aec2dde1da9b18dc7b6be`.
- [HECHO] Desensamblado del consumidor inmediato (`bank_2F_payload_decode_window.asm`): `$D20B-$D217` ejecuta `LDA $37D8,X / EOR $37F6 / STA $37D8,X` con `X=0..$15`. Por tanto descifra en sitio `$37D8-$37ED` con la clave de `$37F6`; `$37F6` procede de BRAM `$007F`.
- [HECHO] Traza filtrada F2600--F3199: 120 accesos sin saturación (32 escrituras `$DBFD`, 22 lecturas `$D20B`, 22 lecturas de clave `$D20E`, 22 escrituras `$D211` y auxiliares). Archivo `system_ram_payload_access_synthetic_v01_f2600_f3199.tsv`, SHA-256 `d24a285a4b99b4371c60930901c5013a4d85ba4cb859574751777f0eefa4c844`.
- [HECHO] Se creó experimento inyectado y explícitamente etiquetado v02: `generated/synthetic_bram_v02_injected_decoded_37d8_03.srm`, SHA-256 `96b2b1dbe0b634aaf67e1616ee2ac5e3bc3f50c3d9ddbb77a9ab8c4b98b465fe`. Sólo cambia respecto de v01: `$0061 $91->$90` y checksum `$0012 $24->$25`.
- [HECHO] Motivo de v02: medición previa demuestra `$37D8 = BRAM[$61] XOR BRAM[$7F]`; con clave `$93`, `$91` produce `$02` y `$90` produce `$03`. Es un estado inyectado, no comportamiento original.
- [HECHO] v02 pasa validación: 2972 lecturas BRAM. Topología de trazas (frame, tipo, offset, PC, MPR) idéntica a v01; sólo cambian valores de `$0061` (18 lecturas) y `$0012` (17), como corresponde. Evidencia `bram_trace_synthetic_v02_title_continue_to_selector.tsv`, SHA-256 `bdda11f45cd6d4b4ce4792492c8f5fa1f15b7db2fdfed7c6cfc6da7b1706bdac`.
- [HECHO] Tras CARGAR, v02 mide `$37D8=$03` y realiza 206 lecturas BRAM. Las capturas de selector y mapa en F3200 son idénticas píxel a píxel a v01. Por tanto se demuestra propagación, pero no efecto visual en esa ventana.
- [HIPÓTESIS] El bloque descifrado contiene datos de partida; no está demostrada la semántica individual de `$37D8`. Norma aplicada: no generar más variantes de BRAM hasta formular una medición concreta sobre un consumidor o estado observable.

## 2026-08-01 — Payload BRAM: línea abierta y aparcada

- [HECHO] El usuario dictamina cerrar la fase de payload BRAM. Se aparca como línea abierta sin más trabajo previsto, con todo lo medido hasta ahora:
  - Copia exacta BRAM `$0060-$007F` -> System RAM `$17D7-$17F6` (CPU `$DBFB` lee, `$DBFD` escribe) al confirmar CARGAR en F2620.
  - Descifrado XOR en sitio `$37D8-$37ED ^= $37F6` (bucle `$D20B-$D217`), con `$37F6` procedente de BRAM `$007F`.
  - v02 inyectada (`$0061 $91->$90`) demostró que `$37D8` descifrado pasa de `$02` a `$03` sin efecto visual medido en selector/mapa. Sin semántica individual demostrada.
- [HECHO] Regla acordada: no generar más variantes de BRAM. v01 (reconstrucción byte a byte de la partida real) es la herramienta base de estados válidos; con eso basta.
- [HECHO] Se retoma el objetivo principal: resultados visibles en el juego. Orden de trabajo: (A) selector `CANTO DE JIZO / CARGAR` roto en v04; (B) pantalla de CARGAR cortada/bocadillo estrecho. Antes de tocar nada hay que comprobar si A y B comparten causa (texto que se construye mal dentro de un marco / sistema de chunks).

## 2026-08-01 — Selector `CANTO DE JIZO / CARGAR`: arquitectura de render medida

- [HECHO] Se regeneró la ROM v04 con `tools/make_v04_password_menu_safe_table_test.py` (no venía en el ZIP). Hashes:
  - `Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v04_password_menu_safe_table_test.pce`: MD5 `5f12711093468a82247c3028281de305`, SHA-1 `d177caf26bfe0df0982ea1f44d6b1a591bd191b9`, SHA-256 `1aa0129e31b67027764ebd801a8bf96501e3a97c5e33d478882ee69ef7b5b38e`, CRC32 `67d8a11d`.
  - IPS `Parches/Pruebas/momotaro_traduccion_v04_password_menu_safe_table_test.ips`: MD5 `a23a7d723da26347e1abcd2192e90987`, SHA-256 `6206f6c364410565e92a6441cc068baf4fd9de2b5afb1a888b3fc02ae72ed900`.
- [HECHO] Se movió el workspace de `/home/user/reconstruction/` a la raíz (`/home/user/momotaro_katsugeki`, `/home/user/emutools`, `/home/user/uploads`) para que coincidieran las rutas absolutas de los scripts y el runner.
- [HECHO] Las dos opciones del selector se renderizan desde la tabla `$54EB` (banco `$0F`, ROM `0x1F4EB`). Original y v03 apuntan a texto japonés (`$54EF`/`$54FA`); v04 apunta a `$5B3A` (`CANTO DE JIZO`) y `$5B4A` (`CARGAR`).
- [HECHO] El bucle emisor está en banco `$0D`, rutina `C4F6` (CPU `$C4F6`): para A=0..1 carga puntero de texto en `[$BF]` y destino en `[$16]`, y hace `JSR $AA16`.
- [HECHO] Instrumentación nueva del core (export `arena_aa16log_*`): captura en cada `JSR $AA16` el frame, puntero de fuente `[$BF/$C0]`, destino `[$16/$17]` y `<$20`. Core final: SHA-256 `37a587c0eb93dfe4b0b55b5a217c425e1ffa0dcd7e5cc90e148e8cfa64ea38d5`. Logs de compilación en `instrument/v04_selector/core_rebuild_aa16*_2026-08-01.log`.
- [HECHO] Captura de llamadas `$AA16` en el selector (frame 1870, 2 llamadas):
  - v04: fuente `$5B3A` destino `$7008`; fuente `$5B4A` destino `$7148`. `<$20=0`.
  - v03: fuente `$54EF` destino `$7008`; fuente `$54FA` destino `$7148`. `<$20=0`.
  - Archivos: `instrument/v04_selector/aa16_v04.tsv` y `aa16_v03.tsv`.
- [HECHO] `$AA16` (banco `$21`) hace `TMA`/`TAM` para poner MPR6=`$0C` y salta a `$D619`; el render real de texto ocurre en banco `$0C` (PCs `$D6xx`), que escribe los glifos a VRAM.
- [HECHO] El texto del selector NO son sprites SAT: se escriben como tiles BG a VRAM `$7000-$7600` en los frames 1863-1870 (ráfaga de 128+1690+1302+1152+1256+1664 escrituras). Los sprites SAT (patrones `$280-$2BA`) son un elemento aparte (rollo Jizo / decoración) e idénticos entre v03 y v04.
- [HECHO] Se reconstruyó desde las escrituras VRAM los glifos renderizados (7 filas por carácter) en orden de dirección VRAM: `C,N,O,D,(esp),C,E,A` y luego bloques vacíos. No corresponde a `CANTO DE JIZO`/`CARGAR`; el texto renderizado sale distorsionado/truncado. Evidencia cruda en el análisis de `instrument/v04_selector/vram_v04_bg_full.tsv`.
- [HIPÓTESIS] El orden de los glifos en la CG VRAM puede no ser el orden visual (el tilemap podría reordenarlos). Para cerrar la hipótesis del solape (`CANTO DTO DE`/`CARGAARGA R`) hace falta leer el tilemap BG y comparar el orden visual de glifos entre v03 y v04, no el orden de la CG.
- [HECHO] Recortes para confirmación visual: `instrument/v04_selector/v04_selector_text_crop.png` y `v03_selector_text_crop.png`.

## 2026-08-01 — Selector: lectura del tilemap BG (resultado decisivo)

- [HECHO] Se instrumentó el core para leer registros VDC (`MWR`, `BXR`, `BYR`). Core final: SHA-256 `8963569affed7f3c3d0ee1d56b994c9ea248b1b4c050e6204cbcb08e0498bd78`.
- [HECHO] En el selector: `MWR=0x50` → BAT de 64x64 tiles en VRAM `$0000-$3FFF`; `BXR=BYR=0` (scroll 0, base BAT en VRAM `$0000`). Confirmado por `DrawBG` del core (`BAT_Base = &VRAM[bat_y]`, `bat_y=(BYR>>3&h)<<w`).
- [HECHO] **La BAT (tilemap) de VRAM `$0000-$3FFF` es byte a byte IDÉNTICA entre v03 y v04** (0 palabras distintas). La traducción v04 NO cambió ninguna celda del tilemap. Evidencia: diff de VRAM completa en `instrument/v04_selector/vram_v03_frame2050.tsv` vs `vram_v04_frame2050.tsv`.
- [HECHO] Las ÚNICAS diferencias de VRAM entre v03 y v04 en el selector son:
  - CG de sprites `$7000-$75FF`: 74 palabras.
  - SAT `$7F00-$7FFF`: 81 palabras.
  No hay diferencias en el tilemap ni en la CG de BG.
- [HECHO] El interior de la caja del selector es el tile BG `$109` (fondo texturizado con `0x0100`), no texto. Por tanto el texto visible de la caja se dibuja encima, vía sprites.
- [HECHO] La rutina `$AA16->$D619` escribe los glifos a la CG de sprites: destino `$7008` = sprite tile `0x1C0`, destino `$7148` = sprite tile `0x1C5`.
- [HECHO] Los glifos realmente escritos a la CG (tiles `0x1C0-$0x1C8`, filas 9-15) son: `C, N, O, D, (blanco), C, E, A`. No corresponden a un `CANTO DE JIZO` limpio; la emisión de glifos ya sale recortada/desordenada a nivel de CG.
- [HIPÓTESIS, NO CERRADA] La hipótesis del usuario de "el segundo chunk re-emite desde una posición anterior" NO se cumple en el tilemap (la BAT no cambia). El solape debe vivir en el sistema de sprites (CG + SAT), no en el tilemap. Todavía no he podido reconstruir el orden visual exacto (`CANTO DTO DE`/`CARGAARGA R`) desde la SAT en F2050; la colocación de los sprites de texto de la caja no queda capturada limpiamente en ese frame.
- [HECHO] Comparación visual v03 vs v04 de la caja: `instrument/v04_selector/v03_vs_v04_box_text.png`.
- [HECHO] Nota sobre el core: el error de "pantalla duplicada/aplastada al pausar en segundo plano" es del core Beetle PCE FAST, reproducible también con ROM japonesa limpia; está fuera de nuestro alcance. Se documenta como pendiente decidir si migrar a Beetle PCE (pero requiere revalidar toda la instrumentación jsrlog/ramlog/vramlog/aa16log/vdc antes).

## 2026-08-01 — Selector: CAUSA identificada (solape de CG entre opciones)

- [HECHO] Se instrumentó el log por glifo (JSR $D6BF) capturando por glifo: char byte ($10), puntero de glifo ($14/$15), destino CG ($16/$17) y contador ($C3). Core final: SHA-256 `2165e38c46b329438f5ad848ab928e5cbce2ccb8c72ccb4b6f1a38cb124e73c3`.
- [HECHO] El bucle emisor es `$D619` (banco `$0C`): lee fuente `[$BF]`, para cada byte llama `$AB91` (font/control) y `$AAB4` (char->glifo), luego `$D6BF` escribe 8 filas a VDC en `$16` y avanza `$16+= $40` por par de glifos.
- [HECHO] **Cada tile de CG alberga 2 glifos** (par que comparte dirección `dest`). El destino inicial de cada opción lo fija la tabla `$C5A8` (banco `$0D`): opción 1 -> `$7008` (tile 0x1C0), opción 2 -> `$7148` (tile 0x1C5).
- [HECHO] Tabla V04 (14 glifos opción 1 -> tiles 0x1C0..0x1C6; 7 glifos opción 2 -> tiles 0x1C5..0x1C8). **La opción 2 sobreescribe los tiles 0x1C5 y 0x1C6 de la opción 1** (que contienen "JI" y "ZO").
- [HECHO] Tabla V03 (7 glifos opción 1 -> tiles 0x1C0..0x1C3; 4 glifos opción 2 -> tiles 0x1C5..0x1C6). Sin solape (queda libre el tile 0x1C4).
- [HECHO] **Causa raíz**: el texto español "CANTO DE JIZO" (14 glifos) es más largo que el japonés (7 glifos) y su CG se extiende hasta el tile 0x1C6, invadiendo el destino fijo ($7148, tile 0x1C5) de la opción 2. La opción 2 re-escribe encima de la opción 1. Confirma la hipótesis del usuario (puntero de destino del segundo chunk no desplazado para acomodar el texto largo).
- [HECHO] Evidencia: `instrument/v04_selector/glyph_v04.tsv` y `glyph_v03.tsv`.

## 2026-08-01 — Problema B (pantalla de CARGAR): medición inicial

- [HECHO] La pantalla de carga/dificultad se alcanza: selector -> CARGAR (DOWN, `$3C84` 0->1) -> confirmar. Estado `$3C83=02`, `$3C85=01`. El box de la pantalla de carga aparece hacia el frame 1988-1990.
- [HECHO] El box de la pantalla de carga es un box BG fijo de **11 celdas ~94px de ancho interior** (tiles de marco 101-108, interior 109), idéntico al box del selector. La SAT y el tilemap son **idénticos entre v03 y v04**; la ÚNICA diferencia de VRAM es la CG `$7000-$728F` (glifos del texto del box).
- [HECHO] El texto de la pregunta de carga está en RAM `$37D7` (dificultad "DIFÍCIL 1") y `$37E1` (parte de "¿Cuál quieres cargar?").
- [HECHO] La pregunta traducida "¿Cuál quieres cargar?" = **21 caracteres**, que exceden la capacidad del box fijo (~11 glifos/línea). Se renderiza en la CG de sprites y sale **cortada/desbordada**: en la CG v04 se decodifica `C ¿ ... D E C L I`, sin correspondencia limpia con el texto esperado. Evidencia: `instrument/v04_selector/vram_load_v04.tsv` vs `vram_load_v03.tsv`; SAT `sat_load_v04.tsv`/`sat_load_v03.tsv`.
- [HECHO] El render de este texto NO pasa por `$AA16`/`$D6BF` en la ventana 1975-2000 (sin llamadas). El texto del box de carga se compone por otra ruta (búfer RAM `$37D7` + `$C518`/`$C559`), aunque el resultado visible es también texto de CG de sprites.
- [HIPÓTESIS] B comparte la "familia" con A (texto de CG de sprites dentro de un box fijo), pero el mecanismo concreto es distinto: en A dos opciones se solapan porque el destino de CG de la 2ª no se desplaza; en B un texto único más largo que el box se corta/desborda. Falta confirmar con traza del render del box de carga cuál es el parámetro de ancho/línea que falla.

## 2026-08-01 — Problema B: CAUSA confirmada (misma raíz que A)

- [HECHO] Se corrigió el protocolo de trace del box de carga: primero llegar al selector (1790/1800/1850) y luego instrumentar la transición a carga (DOWN 1950, RUN 1990). En frame 2129 el box de carga renderiza su texto.
- [HECHO] El box de carga renderiza **5 chunks** (pregunta + 4 dificultades), cada uno con destino de CG fijo desde la tabla `$C5AC` (banco `$0D`): `$7008, $7148, $7288, $73C8, $7508`. Separación entre destinos = `0x140` (5 tiles = 10 glifos por slot).
- [HECHO] En v04, la pregunta traducida "¿Cuál quieres cargar?" = **21 glifos** (tiles 0x1C0-0x1CA) se emite en la llamada 1 (dest `$7008`), pero necesita 11 tiles y solo tiene 5 reservados; **invade el tile 0x1C5** (dest de la llamada 2).
- [HECHO] La llamada 2 (dificultad " DIFÍCIL 1", 10 glifos) empieza en dest `$7148` (tile 0x1C5) y **re-escribe** sobre los tiles 0x1C5-0x1C9 que ya ocupó la pregunta. Resultado: corrupción visual en la pregunta y en la dificultad.
- [HECHO] En v03 (original), la primera cadena japonesa es de 10 glifos (5 tiles, 0x1C0-0x1C4) y **no llega** al tile 0x1C5; por eso no hay solape.
- [HECHO] **Conclusión: A y B comparten la MISMA causa raíz.** Ambos usan destinos de CG fijos por slot (tabla `$C5A8` en el selector, `$C5AC` en la carga), con 5 tiles (10 glifos) de separación. Al traducir a textos más largos que 10 glifos, el primer chunk invade el slot del siguiente y se corrompen mutuamente. Evidencia: `glyph` log v04 en frame 2129 (pregunta 21 glifos hasta tile 0x1CA; dificultad re-escribe tiles 0x1C5-0x1C9).

## 2026-08-01 — Problema B: mecanismo de posicionamiento y opción multi-línea

- [HECHO] El render de la pantalla de carga (`$C518`) hace 5 pasadas (X=0..4): copia la cadena de la tabla `$5501` al búfer RAM `$37D7` y la renderiza como glifos CG en el destino de la tabla `$C5AC` (5 slots: `$7008,$7148,$7288,$73C8,$7508`). Cada slot = 5 tiles = 10 glifos = una "línea".
- [HECHO] En v04, la pregunta (chunk 0, 21 glifos) desborda su slot y pisa el slot 1 (dificultad). La dificultad re-escribe tiles 0x1C5-0x1C9. Mismo mecanismo que A.
- [HECHO] El texto de menú se posiciona por SAT: los glifos CG se colocan en pantalla mediante la SAT. En la pantalla de carga, la rejilla de dificultad son tiles de texto 0x1C0-0x1D8 en una cuadrícula 5x3 (sx=88,104,120,136,152; sy=56,88,120).
- [HIPÓTESIS] Para "dividir en líneas" un texto largo, la vía natural es hacer que el texto ocupe MÚLTIPLES chunks/filas (cada chunk = una línea con su slot CG y su fila Y), en lugar de una sola fila que se desborda. Requiere cambiar cómo se genera/coloca el texto de la pregunta y del selector. Es un cambio de layout, no un simple desplazamiento de destinos.
- [DESCARTADO/ERROR] No puedo confirmar visualmente el layout de la pantalla de carga desde mi modelo de render sin visión; no confío en el render de píxeles para decidir la colocación exacta de filas. Me apoyo en los logs de glifos (sólidos).

## 2026-08-01 — Box del menú: rutina de dibujado y ancho parametrizado

- [HECHO] La caja de los menús (selector y carga) es un box BG de **12 tiles de ancho** (`CPX #$0C` en `$C678`) y **5 filas de alto** (`CPY #$05` en `$C689`), dibujado por la rutina `$C633-$C68E` (banco `$0D`). Escribe al tilemap en frames 1866-1867 (PCs `$C655/$C657/$C65A`).
- [HECHO] El interior del box son 11 celdas (tiles 109) de ancho (cols 11-21), ~88 px. El texto se dibuja encima como glifos de CG de sprites.
- [HECHO] El ancho del box es una **constante en el código** (`CPX #$0C`), no un dato fácil de parchear sin tocar la rutina. Ampliarlo requiere subir ese valor y re-centrar (mover la X inicial).
- [HECHO] Según el usuario: el texto va alineado a la izquierda con el puntero (melocotón) a la izquierda; el box está centrado y simétrico. La frase más larga debe ser la referencia para centrar el box con margen de 8 px a cada lado.
- [HIPÓTESIS] Para que "CANTO DE JIZO" (14 glifos) y "¿Cuál quieres cargar?" (21 glifos) quepan en una línea, hay que (a) ensanchar el box (subir `CPX #$0C`) y (b) re-centrarlo. Falta medir cómo se centra el box (X inicial) y cómo se posiciona el texto dentro.

## 2026-08-01 — Plan de ampliación del box (en análisis, NO implementado)

Estado del análisis para implementar "frases en una línea + box ensanchado centrado":

1. **Ancho del box**: rutina `$C633` dibuja el box con ancho `CPX #$0C` (12 tiles) y alto `CPY #$05` (5 filas). Es una constante de código.
2. **Texto**: glifos de CG de sprites, posicionados por SAT, alineados a la izquierda con el puntero (melocotón) a la izquierda.
3. **Necesario para el objetivo**:
   - (a) ensanchar el box: subir el ancho en `$C633` (y el interior consecuente);
   - (b) re-centrar el box horizontalmente (ajustar X inicial de dibujado);
   - (c) ampliar el CG/slots para que cada frase larga quepa en una fila (sin piso de la siguiente);
   - (d) alinear el texto a la izquierda después del melocotón.

Esto NO es un simple parche de datos: toca la rutina del box, el posicionamiento SAT y el layout de CG. Requiere varias pruebas en emulador. Antes de escribir la ROM, presentaré el plan exacto de cambios y offsets al usuario para su confirmación.

## 2026-08-01 — Verificación de competencia CG (pregunta vs rejilla de dificultad)

- [HECHO] En el estado estable de la pantalla de carga (frame 2600), los tiles CG 0x1C0-0x1C9 contienen SOLO la pregunta ("C,¿,a,D,E,C,L,I" = parte de "¿Cuál quieres cargar?"), y los tiles 0x1CA-0x1D9 están vacíos.
- [HECHO] La rejilla de dificultad (SAT, tiles 0x1C0-0x1D8) se renderiza cada frame desde el SAT en las filas y156-209 (debajo del box). No compite con la pregunta en el CG en estado estable.
- [HECHO] Hay un "refresco" continuo de los bloques CG $7140-$7240 (12 writes cada ~9 frames) que corresponde al cursor/selector de la rejilla, no a la pregunta.
- [CONCLUSIÓN] La pregunta se puede reubicar a tiles contiguos (0x1C0-0x1CA) sin pisar la rejilla, porque la rejilla no ocupa esos tiles en estado estable. Simplifica el reasignado de destinos.

## 2026-08-01 — Box del selector: geometría y rutina de dibujado

- [HECHO] El box del selector se dibuja en el tilemap en las **columnas 10-21** (12 tiles) y **filas 11-15** (5 filas). Direcciones BAT: filas $02CA/$030A/$034A/$038A/$03CA, cada fila +0x40 (64 tiles), col 0xCA-0xD5.
- [HECHO] Los tiles del marco: fila superior 0101 0102×10 0103; lados 0104/0105; interior 0109×10; inferior 0106 0107×4 010E 010F 0107×4 0108.
- [HECHO] La rutina `$C633-$C68E` dibuja un bloque de **12 tiles de ancho** (`CPX #$0C`) × **5 filas** (`CPY #$05`), avanzando +$40 por fila, con origen en `<$16` + `$2C`. Parte del box se dibuja por rutinas enlazadas por jump tables (PCs del log `$C6DB,$C640,$C63D,...`).
- [HECHO] El box actual (12 tiles) está centrado: col 10-21 dentro de un tilemap visible de 32 cols (centro col 16). Para ensancharlo a N tiles manteniéndolo centrado, la columna base sería (32-N)/2.
- [HIPÓTESIS] El dibujado completo del box (marco 0101-0109) lo hacen varias rutinas enlazadas; todavía no está totalmente mapeado el flujo de dibujado (hay jump tables). Modificar la anchura requiere tocar esas rutinas con cuidado. Por método, se propone un enfoque por fases y de bajo riesgo.

## 2026-08-01 — Verdad visual programática del selector (Pillow)

- [HECHO] Norma de trabajo adoptada: análisis de imagen con Pillow (comparar, volcar regiones a texto, contar píxeles), no razonar sobre descripciones. Cuando el usuario reporte algo visual, pedir la captura y medirla.
- [HECHO] Captura del usuario (`referencia_usuario_selector_default.png`) es 256x240 (emulador), distinta de las del core mínimo (256x243). No comparar píxel a píxel entre orígenes; comparar por regiones relativas.
- [HECHO] Decodificado desde píxeles del selector (v04):
  - Box: bordes verticales en x80 y x175, interior ~95px (~11 tiles).
  - Línea 1: "CANTO DE JIZO" pero con la parte derecha corrupta y desbordando el box (texto llega a x~190 cuando el interior termina en x175).
  - Línea 2: "CARGAR" también corrupto/desbordando.
  - Melocotón a la izquierda (x80-90).
- [HECHO] Coincide con el análisis de CG: "CANTO DE JIZO" (14 glifos, tiles 0x1C0-0x1C6) y "CARGAR" pisa tiles 0x1C5-0x1C6.
- [HECHO] El texto desborda el box por la derecha: el box interior actual (~95px) no alcanza para 14 glifos (~112px).

## 2026-08-01 — Estado real del análisis de implementación

- [HECHO] El texto del menú (selector) se renderiza como sprites; el diff VRAM v03-v04 está solo en CG `$7000-$7200` (glifos) y SAT `$7F00`. Tilemap idéntico.
- [DESCARTADO/ERROR] Mi render manual de sprites (fullrender, spr_text_layer) NO reproduce fielmente el texto del menú en pantalla (el interior del box salía sólido; acuerdo ~87-91% pero sin texto legible). No me baso en ese render manual para decidir cambios de coordenadas.
- [HECHO] La corrupción visual (`CANTO DTO DE`) está confirmada por píxeles en la captura del usuario y del core: texto desborda el box por la derecha, solape de glifos.
- [HIPÓTESIS] La causa del solape está en los destinos de CG fijos por chunk (`$C5A8` selector, `$C5AC` carga) con slots de 10 glifos. Para verificar el arreglo de forma fiable necesito el log de glifos del render (`$D6BF`), que ya instrumenté y que muestra cada glifo con su destino CG.
- [PENDIENTE] Aún no se ha escrito ningún byte en ROM. El paso siguiente seguro es: en una ROM de prueba v05, cambiar SOLO el destino de CG de la opción 2 del selector (de `$7148`/tile 0x1C5 a `$71C8`/tile 0x1C7) y verificar con el log de glifos que ya no hay solape, antes de tocar box/SAT.

## 2026-08-01 — ROM v05: reubicar destino CG de "CARGAR" (selector)

- [HECHO] Se generó ROM de prueba `Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v05_selector_cg_from_v04.pce` (SHA-256 `90a878f9aec220174e64b30ae6433c4dd323263eedf83f8fe075956ce8a18723`). Cambio mínimo: en la tabla `$C5A8` (ROM `0x1A5A8`) el idx1 (opción 1 "CARGAR") pasa de `$7148` (tile 0x1C5) a `$71C8` (tile 0x1C7).
- [HECHO] Verificación con log de glifos (`$D6BF`): ya NO hay solape de CG. Opción 1 "CANTO DE JIZO" usa tiles 0x1C0-0x1C6; opción 2 "CARGAR" usa tiles 0x1C7-0x1CA. Tiles disjuntos.
- [HECHO] Verificación por píxeles (render del core, frame 2050): la línea 2 ahora se lee "CARGAR" limpio (antes "CARGARGA R"); la línea 1 se lee "CANTO DE JIZO" pero muy apretada contra el borde derecho del box (la O final casi toca el borde) y no centrada.
- [HECHO] **Progreso**: el solape de CG está eliminado. **Problema restante**: la línea 1 ("CANTO DE JIZO") es más larga que el box actual (~112px vs ~95px), así que queda apretada/sale del box. Es el problema de ancho del box que abordaremos en la siguiente fase (ensanchar box + re-centrar).
- Capturas: `instrument/v04_selector/core_v05_sel2050.png` y `core_v04_sel2050.png`.

## 2026-08-01 — Hallazgo en archivos de Claude (Claude.txt / Claude 2.txt)

- [HECHO] Los archivos `uploads/Claude.txt` y `uploads/Claude 2.txt` contienen el historial de una sesión previa de Claude que ya resolvió un problema ANÁLOGO: el texto traducido al español (error Jizo / prompt de contraseña) no se veía entero.
- [HECHO] Diagnóstico de Claude (confirmado con evidencia de VRAM/SAT):
  - "El cuadro de diálogo se dibuja con sprites, no con el fondo (BAT), exactamente igual que los rótulos del menú."
  - "3 filas de 4 sprites de 32×16 px cada una. Ancho útil por línea: 4×32px=128px ⇒ 16 caracteres máximo por línea."
  - El texto traducido se sale por la derecha porque supera el presupuesto de sprites de la línea (y el ancho útil).
  - Pantalla visible real = 256 px (confirmado con HDR/HDW).
- [HECHO] Claude también diagnosticó el patrón de "duplicado/residuo": sprites de texto nuevos dibujados sin condición de pantalla que quedan flotando sobre otras pantallas (bug de dibujo incondicional).
- [HECHO] La solución de Claude para "el texto no se ve entero": (a) ampliar la caja (marco + contenido) de forma coherente, o (b) desplazar todo el conjunto hacia la izquierda para ganar margen a la derecha, o (c) acortar el texto. El método es reescribir los sprites originales en su sitio (no crear listas duplicadas).
- [HECHO] La captura del usuario de v05 muestra el texto aún desbordando por la derecha del box (llega a x~185, box interior termina en x~175) y el melocotón montándose sobre "JIZO". Coincide con el diagnóstico de Claude.
- [CONCLUSIÓN] El cambio de destino CG (v05) NO basta: la disposición de sprites (SAT) del texto sigue siendo fija y no da cabida a los glifos extra. Hay que ampliar el presupuesto de sprites/linea (y el marco) de forma coherente.

## 2026-08-01 — Reconocimiento: desajuste de entorno de emulación

- [HECHO] Hay un desajuste entre mi entorno (core libretro mínimo, frame 2050, 256x243) y el emulador del usuario (256x240, otro renderizado). Las coordenadas de sprites no coinciden:
  - En mi render del core v04, el melocotón (naranja) está en x89-167, y159-206.
  - En la captura del usuario, el melocotón está junto al texto en el box central (y~97).
- [HECHO] La SAT que leo del core (frame 2050) tiene sprites en pos_x 120-225, pos_y 50-152; NINGUNO cae en el box central (x86-185, y97-122) donde el usuario ve el texto. Sin embargo el texto central SÍ cambia entre v03 y v04 (545 px de diff).
- [HIPÓTESIS] El desajuste impide correlacionar mi render del core con la captura del usuario. No debo usar mi render manual/SAT para decidir coordenadas hasta alinear el estado de navegación exacto con el del usuario.
- [HECHO] Lecciones clave de Claude.txt/Claude 2.txt (para el problema del texto que no se ve entero):
  - El texto de menús/diálogos se dibuja con **sprites de 32px de ancho** (4 caracteres a 8px), con un presupuesto fijo por línea (~16 caracteres / 128px).
  - El texto traducido se sale por la derecha cuando supera el presupuesto; la solución es ampliar el presupuesto de sprites (y el marco) de forma coherente, o desplazar el conjunto.
  - El texto se reescribe sobre los sprites ORIGINALES (no crear listas duplicadas, que causan residuo/duplicado visual).
  - Pantalla visible real = 256 px.
- [PENDIENTE] Alinear mi entorno de navegación al del usuario (mismo frame/estado) antes de decidir cambios de layout; o usar directamente la captura del usuario como referencia de píxeles.

## 2026-08-01 — SOLUCIÓN CLAVE del prompt de contraseña (Extracto chat original.txt)

- [HECHO] El usuario aportó `uploads/Extracto chat original.txt` con el tramo final del chat donde se resolvió el problema del prompt de contraseña (mismo mecanismo que el selector).
- [HECHO] Mecanismo confirmado: el texto del juego NO se escribe carácter a carácter en pantalla; el juego genera **bloques/chunks de sprites 32x16 en VRAM** (cada chunk 32x16 usa 2 patrones 16x16, y avanza de 2 en 2), y luego los proyecta como sprites.
- [HECHO] El juego solo prepara/limpia los chunks previstos para el texto japonés original. Al traducir a frases más largas, los **chunks extra no se preparan** → aparecen con basura gráfica.
- [HECHO] La solución del prompt fue ampliar la rutina de preparación `BA8A` (bank $21): `LDY #$09 -> LDY #$0D` (ROM `0x43A8B`: 09→0D). Esto amplió la preparación de 10 a 14 patrones, cubriendo los chunks extra (1B8..1BB), que antes tenían solo 16 writes y ahora 144.
- [HECHO] Validación: con el parche, el prompt salió completo y sin artefactos. Además se reconstruyó el marco superior.
- [HECHO] Para el ERROR Jizo la solución fue ampliar su viewport de sprites (3 filas x 4 sprites -> 5 columnas x 4 líneas) y arreglar la limpieza para evitar residuos.
- [HIPÓTESIS] El selector (CANTO DE JIZO / CARGAR) usa el MISMO mecanismo de chunks de sprites, y tiene una rutina de preparación de patrones propia (a destinos $7000+, no $6B84 del prompt) que probablemente no cubre los chunks extra. Hay que localizar esa rutina y ampliar su contador.
- [PENDIENTE] Localizar la rutina de preparación de patrones del selector (la que limpia CG $7000+) y su contador/límite.

## 2026-08-01 — Conclusión sobre el selector (comparación v04 vs v05 por píxeles)

- [HECHO] Comparando render del core v04 vs v05 (frame 1950): el ÚNICO cambio está en la línea 2 (y116-122), de x88 a x214. La línea 1 (y100-106) es idéntica entre ambas.
- [HECHO] En v05, la línea 2 "CARGAR" se lee más limpia DENTRO del box, pero su proyección se extiende hasta x214 (fuera del box que termina en x176) — el residuo se sale por la derecha.
- [HECHO] En v04 y v05, la línea 1 "CANTO DE JIZO" (14 glifos) se proyecta dentro del box pero con residuo/corrupción a la derecha (x~176-190).
- [HECHO] El texto se proyecta vía SAT; la posición de cada sprite depende del índice de tile CG. Al mover destinos CG, la proyección se desplaza.
- [CONCLUSIÓN] El box es demasiado estrecho para el texto traducido. El texto se sale por la derecha. Hay que AMPLIAR el box (marco) de forma coherente, como pidió el usuario y como confirmó Claude. El cambio de destino CG solo mejora parcialmente la línea 2 pero no resuelve el desborde.
- [PENDIENTE] Ampliar el marco del box del selector para que quepa "CANTO DE JIZO" (y que "CARGAR" quepa en su fila), manteniendo el texto centrado/alineado. Localizar la rutina que dibuja el marco del box ($C633 / metasprite) y ampliarla.

## 2026-08-01 — Verificación de la afirmación de Claude (texto en BAT vs sprites)

- [HECHO] Claude afirmó que el texto del selector ("CANTO DE JIZO"/"CARGAR") está en el tilemap de fondo (BAT), no en sprites, y que nuestra búsqueda de "lista de sprites" fue en falso.
- [HECHO] VERIFICACIÓN PROPIA (ROM v05, frame 1950): el tilemap (BAT, filas 0-30) del selector NO contiene texto de glifos. Solo tiene el box (tiles 101-109) y vacío. Busqué todos los tiles no-box y no encontré ninguno.
- [HECHO] Los glifos del texto "CANTO DE JIZO"/"CARGAR" están en CG de sprites (tiles 0x1C0-0x1CA), confirmado leyendo los tiles bit a bit: son letras (C,N,O,D,esp,I/O,C,E,A...).
- [HECHO] La afirmación de Claude NO se sostiene para el selector en mi medición. Claude probablemente analizó OTRA pantalla: dijo que su navegación no estaba sincronizada y localizó la "caja" en Y=140-202 con patrones 0x1A8/0x1AA/0x1AC, que corresponde al gráfico decorativo inferior (melocotón/Jizo gigante en y152-208), NO al box del menú (y97-122).
- [CONCLUSIÓN] El texto del selector está en CG de sprites. Claude estaba mirando una pantalla distinta. No descarto que en la pantalla de CARGAR o en otras el texto sí esté en BAT, pero para el selector mi medición es clara.
- [HECHO] La posición en pantalla de los glifos la marca la SAT/proyección de sprites, y al mover destinos CG (v05) la posición cambió (línea 2 de x88 a x214), confirmando que la posición deriva del tile, no de un nametable fijo.

## 2026-08-01 — Discrepancia irreconciliable con Claude sobre el selector

- [HECHO] Claude afirma (con volcado de SAT y BAT) que el selector está en Y=140-202 y que el texto está en el tilemap (BAT filas 17-24, tiles 0x137-0x15d).
- [HECHO] Verificación PROPIA con la MISMA ROM v05 (SHA256 90a878f9...) y el MISMO método de navegación de Claude (frames 60/100/140): el box del selector está en filas 11-15 del BAT (tiles 101-103), NO hay texto en el BAT (filas 16-27 vacías), y el scroll es 0 (BYR=BXR=0).
- [HECHO] Mi medición y la de Claude son incompatibles en la misma ROM y método: yo veo el box en y90-130 sin texto en BAT; Claude lo ve en y140-202 con texto en BAT.
- [HIPÓTESIS] Difieren el core instrumentado, la geometría/resolución, o la interpretación de offsets de fila del BAT (scroll/desplazamiento vertical). No es una diferencia de ROM (misma SHA).
- [PENDIENTE] Resolver esta discrepancia con el usuario antes de tocar la ROM. Sin saber cuál de los dos modelos de pantalla es el correcto para el emulador real del usuario, no puedo diseñar el cambio de layout con seguridad.

## 2026-08-01 — Resolución de la discrepancia con Claude

- [HECHO] El usuario confirmó (por segunda vez) que ve el texto del selector en **y97-122** en su emulador real.
- [HECHO] Esto coincide EXACTAMENTE con mi medición del render del core (box en y90-130), y NO con la de Claude (que decía y140-202).
- [HECHO] Por tanto, para el selector, mi modelo de pantalla es el correcto. La afirmación de Claude de que el texto está en el tilemap (BAT filas 17-24) NO aplica al selector: en mi medición el BAT en esa zona solo tiene el box (tiles 101-109), sin texto.
- [HECHO] El texto del selector está en CG de sprites, proyectado vía SAT, y se sale del box por la derecha (confirmado por píxeles).
- [CONCLUSIÓN] El box del selector es demasiado estrecho para "CANTO DE JIZO" (14 glifos). El paso correcto es ampliar el box. La teoría de Claude sobre el texto en BAT quedó refutada para el selector.

## 2026-08-01 — Medición del marco del box del selector (para ampliarlo)

- [HECHO] El marco del box del selector es un metasprite. Original (japonés, $4AEE bank17): 6 sprites, ancho dx=0..64 (64px). V04/v05 ($5BDC bank0F): 8 sprites, ancho dx=0..96 (96px) — ya se ensanchó una vez.
- [HECHO] Formato del metasprite: tile, a1(pal/attr), a2, dx, dy. Fila superior: tile 05 en dx=0, tile 06 en dx=16/48, tile 08 en dx=96. Fila inferior: tile 00 en dx=0, tile 02 en dx=32/64, tile 04 en dx=96.
- [HECHO] El texto "CANTO DE JIZO" (13 caracteres) se compone en chunks de 32px = 4 chunks = 128px de texto. Con margen de 8px a cada lado = 144px de box necesarios.
- [HECHO] Box actual = 96px. **Faltan ~48px** de box (de 96 a ~144px), es decir ~6 tiles más (de 12 a ~18 tiles de ancho).
- [HECHO] El usuario confirmó el texto en y97-122 (coincide con mi modelo, no con el de Claude). El texto del selector está en CG de sprites, no en el tilemap.
- [PENDIENTE] Ampliar el metasprite del marco del box (añadir tramos intermedios) para pasar de 96px a ~144px, y verificar que "CANTO DE JIZO" ya no desborda. Aplicar luego a la pantalla de carga.

## 2026-08-01 — ROM v06: parche de ampliación de caja de Claude (resultado)

- [HECHO] Se generó ROM v06 (`Roms/Pruebas/Momotarou Katsugeki (Japan) - traduccion_v06_selector_box_widen_test.pce`, SHA256 `4fbe973a3b16694ae2d7fd008679d6ec5414fd543e1f82779ff250d935ffd3bd`) aplicando el parche de Claude: stream A, fila superior + 3 interiores (8 bytes).
- [HECHO] Cambios: rellenos de ceros `69->65` y `13->0F`; contadores de tramos `09->10` en `0x1E0D5/0x1E0D9/0x1E0DD/0x1E0E1/0x1E0E5/0x1E0E9/0x1E0ED/0x1E0F1`.
- [HECHO] Verificado en render del core (frame 1950): el texto se lee más completo ("CANTO DE JIZO" y "CARGAR" ya no se cortan), pero **la caja quedó demasiado ancha y descentrada**: el texto desborda por la derecha hasta x223 (línea 1), y la caja ya no tiene bordes verticales limpios en la posición esperada.
- [HIPÓTESIS] El parche de ampliación de caja (tilemap) NO logra centrar bien en mi render: la caja se expande pero el texto (sprites) no se re-centra con ella, y el cálculo de centrado de Claude (relleno -4) no resultó correcto en ejecución.
- [PENDIENTE] El problema de fondo sigue: el texto del selector es de sprites y su posición/proyección no depende del tilemap. Ampliar solo la caja no lo centra. Habrá que verificar en el emulador del usuario qué se ve realmente, o re-posicionar el texto por su proyección SAT.

## 2026-08-01 — Resultado v06 en el emulador del usuario + pista clave

- [HECHO] En el emulador del usuario (captura 121045), la v06 muestra: la caja quedó como "escalera descendente" en 4 franjas hacia la derecha (las filas desalineadas), y el último peldaño rebasa el borde derecho y reaparece por la izquierda (wrap del BAT). El texto sigue mal: "CANTO DTO DE" / "JIZO CZO C ARGA".
- [HECHO] La caja ampliada quedó desalineada: cada fila de la caja empezó en columna distinta (efecto escalera), por el ajuste de relleno de Claude (69->65, 13->0F) que no mantuvo las filas alineadas.
- [HECHO] El texto sigue mal. El usuario da una PISTA CLAVE:
  - "CANTO D" está bien; luego "TO DE JIZO" debería estar 4 tiles a la izquierda (se alinearían las 2 T y crearían la frase con coherencia).
  - "JIZO se cuela en la línea de abajo porque por la mala construcción se agota el espacio de la línea y salta a la inferior" -> wrap/desbordamiento.
  - Recuerda que en el prompt de password incorrecto el problema era que el texto/tiles/chunks estaban "desplazados un slot/tile a la izquierda o derecha", y se resolvió ampliando la preparación de chunks (BA8A: LDY #$09->#$0D).
- [HIPÓTESIS] El texto del selector sufre el mismo mecanismo que el prompt: el texto largo (CANTO DE JIZO) no cabe en el ancho de línea reservado y se envuelve/desplaza. Puede que el problema no sea (solo) la caja del tilemap sino el ancho de línea de proyección de los chunks de texto (sprites). Hay que localizar el ancho de línea reservado para el texto del selector (análogo a BA8A del prompt).

## 2026-08-01 — Extracto largo: confirmación del diagnóstico y método

- [HECHO] El usuario aportó `uploads/Extracto largo.txt` (18213 líneas) con el historial extenso de la traducción.
- [HECHO] Confirmación clave (línea 18035): "Esto se parece mucho a lo que pasó con el prompt superior antes de encontrar la rutina correcta: proyectar más espacio no basta si la rutina que genera los patrones o el buffer de texto no está preparada para esos chunks. Siguiente paso: inspeccionar en ejecución cómo se generan los chunks de ese selector, igual que hicimos con 1AE..1BA en el prompt."
- [HECHO] El mecanismo del texto del menú es idéntico al prompt: el texto se genera en chunks de sprites, y hay que ampliar la preparación de chunks (el prompt se resolvió con BA8A: LDY #$09->#$0D).
- [HECHO] Estructura del selector (líneas 8240-8360): tabla $54EB apunta a las opciones ($54EF=じぞうのうた, $54FA=ろーど). Rutina C4FA lee de $54EB. La traducción prevista es "CANTO DE JIZO" / "CARGAR".
- [HECHO] El diagnóstico correcto: ampliar el marco (caja) NO basta; hay que arreglar la GENERACIÓN/PREPARACIÓN de chunks de texto del selector. Es lo que vimos: v06 amplió la caja pero el texto siguió mal (wrap/desplazamiento).
- [MÉTODO] Para inspeccionar la generación de chunks del selector, usar el SRM real (que ya tenemos) para llegar al selector, y registrar SAT/sprites, metasprites, patrones VRAM con texto, escrituras y PCs que los generan.

## 2026-08-01 — Hallazgo decisivo: el texto del selector es de FONDO (BG), no sprites

- [HECHO] Experimento de capa: cambiar "CANTO DE JIZO" por "AAAA BBBB" en la ROM cambió el texto del render del box central. Confirma que el texto se lee de la ROM y se ve.
- [HECHO] El diff VRAM entre "CANTO DE JIZO" y "AAAA BBBB" está SOLO en CG $7000-$7100 (48 palabras) = la CG donde se dibujan los glifos.
- [HECHO] Borrar TODA la SAT (vacíarla) NO quitó el texto del render. -> NO es sprite proyectado por SAT.
- [HECHO] El tilemap del box central (filas 11-16) solo tiene el box (tiles 100-111), SIN cambios al cambiar el texto. -> El texto NO se escribe como tiles distintos en el BAT.
- [CONCLUSIÓN] El texto del selector se dibuja MODIFICANDO LA CG DE LOS TILES DE FONDO del interior del box (tile 109), que está en $7000+. Por eso: el diff está en CG $7000+, el tilemap no cambia, y no es sprite.
- [IMPLICACIÓN] Para arreglar el selector hay que AMPLIAR/PREPARAR el área de CG de fondo del texto ($7000+) que recibe los glifos de "CANTO DE JIZO", de forma que quepa y se limpie bien. Es lo mismo que el prompt (BA8A ampliaba la preparación de chunks).
- [HECHO] Esto REORIENTA el diagnóstico a favor de Claude (el texto es de fondo), pero el fix no es ampliar el marco del tilemap sino la CG/preparación del área de texto dentro del box.

## 2026-08-01 — Síntesis del problema del selector (texto de fondo)

- [HECHO] El texto del selector es de FONDO (BG): borrar la SAT completa no lo quita; el tilemap del box central (estado estable 1950) solo tiene el box (tiles 100-111).
- [HECHO] Los glifos del texto se dibujan en CG $7000+ (el diff entre "CANTO DE JIZO" y "AAAA BBBB" está solo en $7000-$7100).
- [HECHO] El texto se lee de la tabla $54EB (opciones) y se renderiza. Cambiar el texto cambia el render.
- [HECHO] La limpieza del selector ($C46A) cubre CG $7000-$763F (tile 0x1C0-0x1D8), suficiente para "CANTO DE JIZO".
- [PENDIENTE] Aún no localizado: la RUTINA QUE PROYECTA el texto de fondo (cuántos glifos por línea / cómo avanza), que es la que hace el wrap/desplazamiento. En el prompt era la preparación de chunks (BA8A). Para el selector, el análogo aún no se ha localizado con precisión.
- [MÉTODO] El siguiente paso es trazar la proyección del texto de fondo del selector: cómo el render escribe los glifos a CG y cómo el tilemap/fondo los posiciona, para encontrar el límite de ancho de línea.

## 2026-08-01 — Límite del análisis de capas del selector

- [HECHO] Cambiar el texto del selector solo modifica CG $7000-$7100 (48 palabras). El tilemap y la SAT no cambian.
- [HECHO] Borrar la SAT completa NO quita el texto del render.
- [HECHO] Borrar la CG $7000+ justo antes de capturar NO quita el texto del frame ya mostrado.
- [HECHO] El tilemap del box central (filas 11-16) solo tiene el box (tiles 100-111), sin texto, en todos los frames.
- [HECHO] El tile 109 (interior del box) usa CG en $6D0 (fondo normal), no $7000+.
- [HIPÓTESIS] El texto del selector se dibuja en una capa/camino cuyo mecanismo de proyección aún no se ha localizado por completo. Coincide con el patrón del prompt (texto de fondo generado en chunks), pero la rutina de proyección del selector no se ha aislado.
- [PENDIENTE] Para aislar la proyección del texto de fondo del selector, hace falta instrumentar el render del core a nivel de capas (cómo combina BG/objetos), o trazar la rutina que escribe el texto a CG y su posicionamiento. Es un análisis más profundo del que he podido cerrar en esta tanda.
- [DESCARTADO] Mi hipótesis previa de que el texto era de sprites quedó refutada por el experimento de vaciar la SAT. El texto es de fondo.

## 2026-08-01 — Continuación: límite de localización de la proyección

- [HECHO] Confirmado que el tilemap $0000 es el visible: escribir tile 101 (borde) en fila 13 col 22-23 produjo 82 px nuevos en el render (x176-191, y107-114).
- [HECHO] Escribir tile 0x1C0 en el tilemap del box NO produjo cambio visual (el tile 0x1C0 apunta a CG $1C00, no a $7000).
- [HECHO] La CG de fondo de un tile `charname` está en VRAM `charname*16` (FixTileCache). El tilemap $0000 es visible y usa esa CG.
- [HECHO] Los tiles de texto del selector (si estuvieran en el tilemap $0000) usarían charname 0x700+ para apuntar a CG $7000+. Pero en filas 11-16 (box central) no hay tiles 0x600-0x740.
- [HIPÓTESIS] El texto del selector se dibuja en CG $7000+ y se muestra como fondo, pero el mecanismo exacto de proyección (cómo el tilemap/fondo referencia esos glifos) no se ha aislado. Coincide con el patrón del prompt (BA8A). La rutina concreta de proyección del selector sigue sin localizarse pese a las mediciones.
- [DESCARTADO] La hipótesis de que el texto es sprite quedó refutada (vaciar SAT no lo quita). La de que está en el tilemap $0000 del box con tiles distintos tampoco se confirmó (el tilemap del box solo tiene 100-111).
- [PENDIENTE] Localizar la rutina que escribe los glifos a CG $7000+ Y configura el fondo/tilemap para mostrarlos como texto del selector. Este es el punto exacto que hay que ampliar.

## 2026-08-01 — Agotamiento de la vía de capas del texto del selector

- [HECHO] El render del selector (tanto japonés original como v05 traducido) muestra el texto del menú en el box central (y100-122).
- [HECHO] El texto del menú NO se escribe nunca en el tilemap $0000 filas 10-17 como tiles no-box (tracé frames 1780-2000; solo hay el box).
- [HECHO] No hay escrituras de tiles 0x600-0x800 (CG de fondo alta) en el tilemap filas 0-30.
- [HECHO] Escribir tiles en el tilemap $0000 fila 13 SÍ se refleja en el render (el tilemap $0000 es visible), pero el texto no está ahí.
- [HECHO] El diff JP vs v05 está en CG $6000-$6E00, $7000-$7200, SAT, y $1F00 (tilemap fila baja, fondo decorativo).
- [CONCLUSIÓN] El mecanismo de composición del texto del menú (cómo se muestra en el box central) NO se ha aislado con las herramientas de capas actuales. El texto se dibuja en CG $7000+ (fondo) pero la forma en que el fondo lo referencia/posiciona no corresponde al tilemap $0000 del box que se ha trazado.
- [RECOMENDACIÓN] Dada la dificultad, el siguiente paso más productivo es instrumentar el render del core a nivel de combinación de capas (cómo DrawBG + el texto se combinan), o probar la hipótesis de que la composición usa un tilemap en una base distinta (p.ej. scroll/registro que no se ha identificado). También probar si el texto usa un "overlay" o sistema de diálogo del juego distinto del tilemap normal.
- [DESCARTADO] Texto como sprite SAT: refutado (vaciar SAT no lo quita).
- [DESCARTADO] Texto en tilemap $0000 filas 10-17: no hay escrituras de tiles de texto.

## 2026-08-01 — Reenfoque: composición del menú (equivalente a BA8A)

- [HECHO] El usuario reorienta: el texto ya está bien generado en CG ($D619/$D6BF correctos). El problema es la COMPOSICIÓN (cómo se coloca en pantalla), no la generación.
- [HECHO] El render del selector es $C4F6 (banco $0D): lee $54EB (texto), destino CG $C5A8, llama $AA16->$D619. Escribe glifos a CG $7000+. Las 2 opciones van a tiles 0x1C0-0x1C6 (opción 0) y 0x1C7-0x1CA (opción 1).
- [HECHO] jsrlog durante construcción del menú: las llamadas dominantes son $C6AB/$C67A (bucle del box) y $867F/$E5C2 (construcción SAT del panel lateral, MPR6=$13). La rutina de composición del TEXTO CENTRAL no se ha aislado del ruido.
- [HECHO] El tilemap $0000 es el visible (confirmado). Pero el texto del menú NO está en el tilemap $0000 del box central (filas 11-16 solo tienen 100-111).
- [HECHO] En este core, la CG de fondo usa charname*16 desde VRAM 0 (sin base configurable). El texto (CG $7000+) no se mapea al tilemap del box con tiles 100-111.
- [PENDIENTE] La rutina de composición del texto central del menú (equivalente a BA8A del prompt) sigue SIN localizar. La pantalla usa un sistema de composición que no encaja con el tilemap $0000 del box ni con la SAT.
- [RECOMENDACIÓN] Dado el tiempo invertido y la dificultad, lo más sensato es documentar exhaustivamente este estado para retomarlo con Claude (cuando recupere límite), que tiene herramientas de instrumentación del render más profundas. El conocimiento consolidado está en reports/estado_selector_texto_fondo_2026-08-01.md y en este diario.

## 2026-08-01 — Hallazgo: el primer valor que difiere es el destino CG de la opción 1 ($C5A8[1])

- [HECHO] Comparé las escrituras de composición (frame 1870) entre la pantalla japonesa y la v05 (española).
- [HECHO] La opción 0 japonesa escribe glifos a CG tiles 0x1C0-0x1C3 (7 glifos). La opción 0 española escribe a 0x1C0-0x1C6 (14 glifos). Las direcciones extra en v05: $7109-$710F, $7149, $71C9+ (tiles 0x1C4-0x1C6 y siguientes).
- [HECHO] **El "primer valor que difiere" que define el límite es el DESTINO CG DE LA OPCIÓN 1 en la tabla `$C5A8`.** Original: `$7148` (tile 0x1C5), que asume la opción 0 corta (≤10 glifos). La opción 0 española (14 glifos, tiles 0x1C0-0x1C6) lo desborda y se solapa con la opción 1.
- [HECHO] Con el parche v05 ($C5A8[1]: $7148 -> $71C8, tile 0x1C7), el solape de CG se evita (opción 0 en 0x1C0-0x1C6, opción 1 en 0x1C7-0x1CA). La generación ya no se solapa.
- [PENDIENTE] El texto aún se ve mal en pantalla en v05 (desborde del box). El destino CG resuelve el solape de datos, pero la POSICIÓN en pantalla del texto español (110px) sigue superando el box (~95px). Falta resolver el desborde de pantalla (ya sea ampliando el espacio visible o ajustando la posición).
- [CONCLUSIÓN] El "contador/límite de longitud japonesa" que el usuario sospechaba ES la separación de destinos CG en `$C5A8` (7 tiles de separación = asume opción 0 de ≤10 glifos). Ajustarlo elimina el solape de CG, pero el desborde de pantalla es un tema aparte del ancho del box.

## 2026-08-01 — El límite de longitud es la tabla $C5A8 (destinos CG), no una rutina LDY#

- [HECHO] Busqué la rutina de preparación del menú (equivalente a $BA8A/LDY#$09 del prompt) en banco $0D y $21. El selector usa $C4F6 -> $AA16 -> $D619, que recorre el texto completo (sin límite de línea).
- [HECHO] El texto del menú NO se copia a un buffer RAM (la RAM no difiere entre JP y v05 salvo en las tablas de sprites $26A0-$28C0).
- [HECHO] El "límite de longitud japonesa" NO es una rutina con LDY#, sino la TABLA de destinos CG `$C5A8` (banco $0D, ROM 0x1A5A8): la separación entre el destino de la opción 0 ($7008) y el de la opción 1 ($7148 original / $71C8 v05) reserva un número fijo de tiles por opción.
- [HECHO] La separación original (0x1C0 = 7 tiles) asume la opción 0 de ≤10 glifos (japonés). La opción 0 española (14 glifos, 7 tiles) la desborda y se solapa con la opción 1.
- [HECHO] Ajustar $C5A8[1] a $71C8 (v05) elimina el solape de CG, pero el desborde de pantalla persiste (texto español más ancho que el box).
- [PENDIENTE] El usuario busca la rutina que "reserva N caracteres/columnas/tiles por opción". Hasta ahora la reserva está en la tabla $C5A8 (destinos CG). Falta confirmar si hay además una rutina de preparación de patrones del texto del menú (equivalente a $BA8A) que no se ha localizado.

## 2026-08-01 — Hallazgo: el tilemap tiene tiles de fondo en frames 1860-1865, pero el texto del menú NO está en el tilemap

- [HECHO] En frames 1860-1865, el tilemap filas 10-17 tiene MUCHOS tiles de fondo (0x142-0x144, 0x115, 0x11B, etc.), que forman el fondo decorativo de la pantalla.
- [HECHO] A partir de frame 1870, el tilemap filas 11-16 es solo el box (100-111), sin texto.
- [HECHO] Estos tiles de fondo (0x142-0x144) apuntan a CG normal (0x1420-0x1440), NO a CG $7000+ (donde están los glifos del texto del menú).
- [HECHO] El texto del menú usa CG $7000+ (glifos), confirmado. NO está en el tilemap del box (100-111) en estado estable.
- [HECHO] Escribir tile $700 (apunta a CG $7000) en fila 12 se refleja en la línea 1 del render (x80-111, y99-106). Confirma que tiles $700+ en fila 12 se verían como texto.
- [HECHO] PERO el tilemap del box en estado estable (1950) es 100-111, sin tiles $700+. El texto no está ahí.
- [CONCLUSIÓN/PENDIENTE] El texto del menú se dibuja en una capa que se muestra en el box central pero que NO corresponde al tilemap $0000 del box que se lee en estado estable, ni a la SAT. Sigue sin aislarse la capa/rutina exacta. El análisis de ChatGPT (que el problema es el BAT) NO se confirma en el tilemap $0000.

## 2026-08-01 — HERRAMIENTA DE CAPAS: el texto del menú ES de sprites (confirmado)

- [HECHO] Construí una herramienta de instrumentación de capas en el core: separa fondo (BG) y sprites (SPR) por píxel, y guarda el tile de cada sprite por posición.
- [HECHO] Core con capas: SHA-256 `e402f13f2b406c42a57549ea98fa3bbdd3e41038376c40a349126e64a59a4fa1`.
- [HECHO] **EL TEXTO DEL MENÚ ES DE SPRITES.** La capa capturada (frame 1950) muestra el texto como `B` (fondo+sprite), NO como fondo puro.
- [HECHO] Mapa de tiles de sprite del texto:
  - Línea 1 (y100-106): melocotón tile 1A0 + "CANTO DE JIZO" con tiles 1C0-1C4.
  - Línea 2 (y116-122): "CARGAR" con tiles 1C5-1C8.
- [HECHO] Posición en pantalla del texto: línea 1 x84-160, línea 2 x84-150 (según la capa capturada).
- [HECHO] Mi experimento anterior de "vaciar la SAT" fue defectuoso (la caché de sprites del core no se invalidaba); el texto SÍ es sprite.
- [CONCLUSIÓN] El problema del solape/desborde está en CÓMO SE POSICIONAN los sprites de texto (SAT), no en la generación de glifos ni en el fondo. Hay que localizar la rutina que configura la SAT de estos sprites de texto (tiles 1C0-1C8).
- [PENDIENTE] Localizar la rutina que escribe los sprites de texto (tiles 1C0-1C8) a la SAT con sus posiciones, y entender por qué el texto español se desborda/solapa (probablemente posiciones fijas pensadas para el japonés corto).

## 2026-08-01 — CAUSA RAÍZ DEFINITIVA: el bloque de datos de sprites del menú (ROM 0x1FBDC) tiene códigos de tile DUPLICADOS

### Instrumentación nueva (esta sesión)
- **[HECHO]** `arena_pce_get_pc_logical()` / `arena_pce_get_bank()` en huc6280.c: capturan PC lógico + banco MPR de la instrucción que escribe al VDC. El vramlog ahora registra `[frame, kind, addr, val, pc_logical, bank, 0]`.
- **[HECHO]** `splog` (JSR $E3EB) y `menudata` (PC 0xE4E3, bloque add-sprite): capturan puntero de datos y layout de cada sprite que añade el compositor.
- Core con estas capturas: verificar hash tras build (se reconstruyó varias veces).

### Rutina de composición de la SAT (la que buscaba el usuario) — LOCALIZADA
- **[HECHO]** Rutina genérica en **banco 0**: `0xE3EB` (init) → `0xE417` (loop por entrada) → bloque `0xE4C0` (add-sprite a tabla RAM `$26A0-$28A0`) → `0xE520` (limpia SAT) → `0xE55A` (sube tabla RAM a SAT `$7F00`, SATB).
- **[HECHO]** Formato de datos: cada entrada = **5 bytes** `[code→tile, flg_lo, flg_hi, x_rel, y_rel]`, termina en `$FF`. El puntero avanza de 5 en 5.
- **[HECHO]** Mapeo: **CG tile = code + 0x1C0** (patrón RAM = (code+0x1C0)*2 = code*2 + 0x380). Comprobado con la tabla de sprites.
- **[HECHO]** La SAT se reconstruye CADA frame del menú (frame 1886+).

### BLoque de datos del texto del menú (la causa del solape)
- **[HECHO]** Puntero de datos del texto del menú = `$5BDC` (banco 0x0F, **ROM 0x1FBDC**). El menú lo lee vía el bloque add-sprite (PC 0xE4E3) en frame 1886.
- **[HECHO]** Contenido del bloque (ROM 0x1FBDC), entradas de 5 bytes:
  - Línea2 (yrel=0x10): codes **5, 6, 6, 8**  → tiles CG 0x1C5, 0x1C6, **0x1C6**, 0x1C8  (0x1C6 DUPLICADO)
  - Línea1 (yrel=0x00): codes **0, 2, 2, 4**  → tiles CG 0x1C0, 0x1C2, **0x1C2**, 0x1C4  (0x1C2 DUPLICADO)
  - termina en `$FF`.
- **[HECHO]** En el ROM **original** japonés, ROM 0x1FBDC = todo `$FF` (este bloque lo añadió la traducción).
- **[HECHO]** Los códigos DUPLICADOS hacen que el MISMO tile de glifo se renderice en DOS posiciones → el texto "CANTO DE JIZO"/"CARGAR" aparece solapado/duplicado. Esta es la **causa raíz del desborde/solape visible**.

### Corrección de la interpretación previa
- **[DESCARTADO/ERROR PROPIO]** En esta sesión analicé v03 y concluí que el texto se truncaba a "CANTODE" (7 glifos). **ERROR**: v03 tiene el selector en JAPONÉS (tabla `$54EB` apunta a `$54EF/$54FA` = texto japonés; ROM 0x1FB3A está vacía `$FF`). El "CANTODE" que vi era kanji mal leído por mi ASCII. El texto español NO está en v03.
- **[HECHO]** v07_fix/v05 SÍ tienen el texto español correcto: entry0 `$5B3A`="CANTO DE JIZO" (ROM 0x1FB3A), entry1 `$5B4A`="CARGAR" (ROM 0x1FB4A).
- **[HECHO]** La composición de sprites del TÍTULO (JSR $E3EB desde 0xCC22, cnt 35+) es distinta de la del menú. El menú usa el bloque add-sprite (0xE4E3) sin re-entrar por JSR $E3EB.

### Estado del fix
- **[PENDIENTE]** El bloque ROM 0x1FBDC debe corregirse para que los códigos sean distintos y secuenciales, y para que cubran TODOS los tiles de glifo generados:
  - Línea1 "CANTO DE JIZO" (13 glifos) → tiles CG 0x1C0-0x1C6 (7 tiles, 2 glifos/tile). Códigos 0-6.
  - Línea2 "CARGAR" (6 glifos) → tiles CG 0x1D0-0x1D2 (v07_fix movió el destino de la opción 1 a $7408=tile 0x1D0). Códigos 0xD0-0xD2 rel.
  - Además, la tabla `$C5A8` (destinos CG) y el ancho del box deben ser coherentes (layout confirmado: texto alineado a la izquierda tras el melocotón, frase larga determina el ancho del box con 8px de margen, box centrado).
- **[PENDIENTE]** No modificar la ROM hasta que el usuario confirme el análisis/enfoque.

## 2026-08-01 — RESUELTO: el texto del selector "CANTO DE JIZO"/"CARGAR" renderiza correcto (MISSION COMPLETE)

### Causa raíz definitiva
- **[HECHO]** El bloque de datos de sprites del texto del menú (ROM `0x1FBDC`, banco 0x0F, puntero `$5BDC`) tenia codigos de tile DUPLICADOS (linea1: 0,2,2,4; linea2: 5,6,6,8), que hacian que el MISMO tile de glifo se renderizara dos veces -> solape/garble.
- **[HECHO]** Formato: entrada de 5 bytes `[code→tile, flg_lo, flg_hi, xrel, yrel]`, fin `$FF`. CG tile = code + 0x1C0. Sprite doble (flg_hi bit0) renderiza tiles P y P+1 (requiere code PAR). Sprite individual renderiza 1 tile.

### Los glifos reales ocupan MÁS tiles de los que la tabla japonesa asumía
- **[HECHO]** La generacion de glifos inyecta un ESPACIO inicial (byte $3C) antes de cada texto. Por eso:
  - Linea1 "CANTO DE JIZO" (13 letras + esp inicial = 14 slots) = 7 tiles `0x1C0-0x1C6`.
  - Linea2 "CARGAR" (6 letras + esp inicial = 7 slots) = 4 tiles `0x1D0-0x1D3` (el tile 0x1D3 contiene la R final).

### Bloque corregido (ROM 0x1FBDC)
```
L2 "CARGAR": 10 0e 00 00 10   11 0e 00 10 10   12 0e 00 20 10   13 0e 00 30 10  (4 individuales -> tiles 0x1D0-0x1D3)
L1 "CANTO DE JIZO": 00 0e 01 00 00   02 0e 01 20 00   04 0e 01 40 00   06 0e 00 60 00  (3 dobles + 1 simple -> tiles 0x1C0-0x1C6)
FF
```

### Entregables
- **ROM final**: `Roms/Momotarou Katsugeki (Japan) - traduccion_v08_selector_fix.pce`
  - SHA-256 `e74b23bd777660012c4c57933c5be548c5fb8d0742715f64f682793f5bb04003`
  - MD5 `dfe611d1b38a22129f4bd2fb71947026`, SHA-1 `750e0727cd24122f8d0eb35e6331b52e41bc74ad`, CRC32 `0b913386`
- **Parche IPS**: `Parches/momotaro_traduccion_v08_selector_fix.ips` (base = v07_fix, round-trip verificado).
- Base v07_fix: SHA-256 `ef31c01b0a1ac0afc1f3a90bf657c65e3fefc351ed854928b9c45728a9c48beb`.

### Verificacion
- **[HECHO]** Emulador: linea1 "CANTO DE JIZO" y linea2 "CARGAR" correctos, dentro de la caja (medido en captura del usuario).
- **[HECHO]** El texto cabe en la caja (no desborda).

### Descarte/errores previos
- El texto del menu NO es tilemap del box (es sprites).
- v03 tenia el selector en japones (tabla $54EB apuntaba al texto japones; 0x1FB3A vacia). El texto espanol esta en v07_fix+.
- Los codigos duplicados eran la causa del solape; mover destinos CG ($C5A8) no bastaba.

## 2026-08-01 — RESUELTO: la 5ª fila (rabillo) del bocadillo del selector, ahora 128px alineado

### Contexto del problema
- La caja (bocadillo) del selector es de **fondo (tilemap)**, dibujada en el **frame 1866** por la rutina `$C63C` (banco 0x0C, ROM 0x1863C) leyendo un stream de tiles.
- **Stream bajo (tiles):** logical `$40D1` = **ROM 0x1E0D1** (MPR2=banco 0x0F). Contiene box1 (selector) y box2 (cargar).
- **Stream alto (atributos):** logical `$410C` = **ROM 0x1E10C**. Para box1 es todo 0x00 (paleta 1) → no hay que tocarlo.
- Palabra de tilemap = `(alto+1)<<8 | bajo`. Para el box, alto=0x00 (→0x01) y bajo=tile (0x01-0x11).
- La rutina $C63C no es la que pensaba Claude ($C75D/$C786/$C7BE son lógica de estado, no dibujo). El box lo dibuja $C63C (32 tiles/fila) leyendo los streams vía $14/$15 (bajo) y $18/$19 (alto), con MAWR puesto por el caller.

### Tilemap antes (v12, ground truth por emulador)
```
r11-r14 (caja):  cols 8-23, 16 tiles = 128px  (101 102×14 103 / 104 109×14 105)
r15 (rabillo):   cols 13-24, 12 tiles = 96px   (106 107×4 10e 10f 107×4 108)  -> estrecho y desplazado
r16 (melocotón): cols 18-19
```

### Mapeo empírico (aprendido con ROMs de test, NO a ciegas)
- **Reducir 5 vacíos antes del rabillo desplaza el rabillo Y el melocotón 5 a la izquierda.**
- **Ensanchar los bordes del rabillo 3→5 añade 4 tiles y desplaza el melocotón 4 a la derecha.**

### Fix (ROM v13) — 4 bytes en el stream bajo
| offset | antes | después | efecto |
|---|---|---|---|
| 0x1E0F4 | `ff 14 00` (20 vacíos) | `ff 0f 00` (15) | rabillo a la izquierda 5 |
| 0x1E0F8 | `ff 03 07` (borde izq) | `ff 05 07` (5) | rabillo más ancho |
| 0x1E0FD | `ff 03 07` (borde der) | `ff 05 07` (5) | rabillo más ancho |
| 0x1E101 | `ff 18 00` (24 vacíos) | `ff 19 00` (25) | compensa el melocotón (lo mantiene en 18-19) |

### Tilemap después (v13, verificado)
```
r11-r15:  todas cols 8-23, 16 tiles = 128px, alineadas a la izquierda en col 8
r15:  106 107×6 10e 10f 107×6 108   (cola centrada en cols 15-16)
r16:  melocotón 110 111 en cols 18-19 (sin cambios)
```

### Entregables v13
- ROM: `Roms/Momotarou Katsugeki (Japan) - traduccion_v13_rabillo_fix.pce`
  - MD5 `a3da96c83f8588c403c96a36b982b279`, SHA-1 `e6c9ce18077619a95e8694213dd874a2d570f759`
  - SHA-256 `41f092ca0b55e7940604f3823eb08744d07a528fe72a71ea04f837da98a186a8`, CRC32 `e57b2171`
- Parche IPS: `Parches/momotaro_traduccion_v13_rabillo_fix.ips` (base = v12, round-trip verificado)

### Nota metodológica
- Los punteros del box se obtuvieron con el `boxptrlog` instrumentado (captura $14-$19 en PC $C63D), reiniciándolo justo antes del frame 1866 (el dibujo del box del selector; el primer arranque dibuja el título en frame 6, no confundir).
- El melocotón está DENTRO del rango del rabillo (cols 18-19), es el puntero de la opción seleccionada.

### Siguiente pantalla (PENDIENTE)
- **"¿Cuál quieres cargar?"**: texto no visible + caja a ensanchar (mismo enfoque). Es el **box2** del stream bajo (ROM 0x1E0D1, más abajo). No tocar box1.

### 2026-08-01 (2ª iteración) — Cola del rabillo centrada (v14)
- El usuario midió (capturas 192627 y ampliación 192449): la **cola puntiaguda** (tiles 110/111) quedó en **cols 18-19 (x147-155)**, mientras que la **muesca/base** de la cola (tiles 10e/10f) está en **cols 15-16 (x123-131)**. La cola quedó **24 px a la derecha** de su base.
- Causa: en v13 compensé los vacíos para dejar 110/111 en cols 18-19, pero la base de la cola (10e/10f, dentro del borde inferior) quedó en 15-16 → desalineadas 24 px.
- Fix (1 byte en stream bajo): `0x1E101: ff 19 00 → ff 16 00` (reduce 25→22 vacíos antes de `10 11`), mueve la cola 3 tiles (24 px) a la izquierda.
- Verificado (tilemap + frame renderizado): 110/111 ahora en **cols 15-16**, alineada con la muesca, apuntando a x127 (centro del box).
- ROM v14: `Roms/Momotarou Katsugeki (Japan) - traduccion_v14_cola_centrada.pce`
  - MD5 `d8f6dc80b4567109364ae004db62f54f`, SHA-1 `468535694363b441a63d2731470d23d4ba57b3a1`
  - SHA-256 `aad61b5849d41d4c946659f8a647db0a649f2480bd0c64792bc0697236583696`, CRC32 `648ff4ce`
- Parche IPS: `Parches/momotaro_traduccion_v14_cola_centrada.ips` (base v13, round-trip verificado).
- Resumen de cambios acumulados v12→v14 (stream bajo, box1): `0x1E0F4 20→15` (rabillo izq), `0x1E0F8/0x1E0FD 03→05` (bordes), `0x1E101 24→22` (cola centrada).

## 2026-08-02 — Pantalla "¿Cuál quieres cargar?": la pregunta sale partida y con la ¿ invertida

### Contexto
- v15 restaura el bloque2 $5C05 (ROM 0x1FC05) que el fix del selector (v08) había puesto a FF. Con esto el texto de la carga vuelve a aparecer, pero la pregunta "¿Cuál quieres cargar?" (21 chars, ROM 0x1FB53) sale ROTA: partida en 2 líneas, con la interrogación de apertura INVERTIDA (espejada) y mezclada con las opciones de dificultad (FÁCIL/NORMAL/DIFÍCIL/MUY DIFÍCIL).

### Causa raíz (medida)
- La pregunta y las opciones de dificultad COMPARTEN los mismos tiles de glifos (0x1c0-0x1d8) en el CG de sprites (base VRAM 0x2000). Los glifos se sobrescriben/colisionan.
- El renderizador de texto avanza cada glifo $40 (ancho doble, ROM 0x19716 ADC #$40, byte 0x19717=0x40) → cada línea cabe pocos glifos → la frase larga se parte.
- La ¿ invertida: el glifo del tile 0x1c0 en la pregunta no es una "¿" correcta (es basura/corrupta) — el mismo tile que el selector usa para "C".

### Experimentos (test, NO definitivos)
- Probar paso $20 (ROM 0x19717) → la frase cabe en una línea PERO se ve peor según el usuario (probablemente por colisión de tiles y por el doble-buffer del CG). El usuario pidió VOLVER al punto anterior (v15) y pasar el problema a Claude con un prompt autocontenido.

### Estado entregable (punto anterior, base para Claude)
- ROM v15: `Roms/Momotarou Katsugeki (Japan) - traduccion_v15_restaurar_bloque2.pce`
  - MD5 `beed9322df14f8f20b12bdaf4f599680`
  - SHA-256 `bd63d872352dd33d24d37e4f05bf08c76c34a393ac26358aec666dd4635adcf2`
  - CRC32 `75ea4231`

### Datos clave para Claude (offsets)
- Pregunta "¿Cuál quieres cargar?" = ROM 0x1FB53 (CPU $5B53).
- Tabla de punteros del selector de carga = ROM 0x1F501 (CPU $5501): [0]=$5B53 pregunta, [1..4]=dificultades, [5]=$5B39 vacío.
- Dificultades: FÁCIL $5B10, NORMAL $5B18, DIFÍCIL $5B21, MUY DIFÍCIL $5B2B.
- Bloque de sprites de dificultades (bloque2) = ROM 0x1FC05 (CPU $5C05): entries de 5 bytes [code→tile=code+0x1C0, fl_lo, fl_hi, x, y], fin $FF.
- Renderizador de texto: $AA16 (banco 0x21, ROM 0x42A16), $D6BF (banco 0x0C), avance glifo $40 en ROM 0x19716 (ADC #$40).
- CG de sprites: base VRAM 0x2000 (tile n = 0x2000 + n*0x20).
- Navegación para reproducir: título RUN → selector → DOWN (a CARGAR) → RUN → pantalla de la pregunta. SRM: `/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm`. STATE (justo al pulsar RUN en CARGAR): `/home/user/downloads/momotaro.state` (contiene la transición).

### NOTA IMPORTANTE (regresión)
- El usuario confirmó que el texto de la carga desapareció en v08 (cuando el fix del selector sobrescribió el bloque2 $5C05 a FF) y que v15 lo restaura. El fix definitivo NO debe volver a romper el selector ni perder el texto de la carga.

## 2026-08-02 (2) — Datos de runtime para Claude sobre la "¿" (falta en la fuente)

Claude desensambló la cadena de render del glifo y pidió 3 datos de runtime. Los capturé con el emulador instrumentado (hook en PC lógico $AACF, banco 0x21, justo donde se hace LDA ($14),Y):

### Datos medidos (HECHO)
- **`$3BA6` = 0** (variante de charset 0) al procesar la pregunta.
- **`$20` = 0** (offset de relocación de banco).
- **Puntero de fuente (variante 0) = `$9CF3`** (tabla en ROM 0x41CF3, banco 0x20).
- **`Y` (índice) para "¿" (`$C9`) = 41 (0x29)**.
- **MPR4 = 0x20** (mapea la página `$8000-9FFF` donde vive `$9CF3`).

### Diagnóstico definitivo (HECHO)
- La "tabla de fuente" `$9CF3` es una **tabla de IDENTIDAD**: devuelve el mismo byte del código (para "¿" `$C9` → `$C9`).
- El renderizador toma ese byte y lo multiplica ×8 + base ($60/$56) → dirección de glifo destino.
- **"¿" (`$C9`) → addr glifo `$5CA8` → ROM 0x3DCA8 (banco 0x1E)**. Ese patrón es **BASURA** (no es una ¿).
- **"?" (`$3F`) → addr glifo `$5858` → ROM 0x3D858**. Ese patrón es un "?" CORRECTO.
- => El carácter "¿" (que añadimos nosotros en la traducción) **NO tiene un glifo válido** en la fuente de bitmaps del banco 0x1E. El cálculo lo manda a una dirección donde hay otro dato (basura), lo que explica el aspecto espejado/corrupto y la mezcla con opciones.

### Fix probable (a confirmar por Claude)
- Escribir el bitmap correcto de "¿" en ROM 0x3DCA8 (banco 0x1E, offset 0x1CA8), o re-mapear el código 0xC9 a una entrada de glifo existente/válida.
- NO tocar el renderizador.
- No romper el selector (que usa los mismos tiles 0x1c0-0x1d8) ni el bloque2 (texto de carga).

### Nota sobre el ancho (parte del problema de la frase partida)
- El paso de glifo es $40 (ancho doble, ROM 0x19716 ADC #$40). La pregunta (21 chars) no cabe en la caja de 96px en una línea. Esto es un problema SEPARADO de la "¿" invertida. Claude debe decidir si el ancho se arregla con el ancho de la caja o con el paso de glifo, sin romper otros textos.

## 2026-08-02 (3) — CONFIRMADA la hipótesis de Claude: el pool de tiles dinámicos se agota

Claude agotó su límite. Deducí e hice yo el diagnóstico con el emulador instrumentado. Resultado: **Claude tenía razón en lo esencial.**

### Mapeo tile sprite ↔ VRAM (HECHO)
- Para sprite cg=0, tile `no` → VRAM `no * 0x40` (16x16, 4 planos). Verificado en vdc.c (CheckFixSpriteTileCache) y con datos:
  - tile `0x1c0` → VRAM `0x7000`
  - tile `0x1d8` → VRAM `0x7600`
  - tile `0x1c0-0x1d8` = VRAM `0x7000-0x7600` (25 tiles).

### El renderizador dinámico dibuja la pregunta en el MISMO rango que el bloque2 (HECHO)
- dstlog (hook en PC $D6BF): los glifos de la pregunta se dibujan en dest VRAM `0x7008,0x7048,0x7088...` = tiles `0x1c0,0x1c2,0x1c4...` (cada char = tile 0x1c0+n*2, avance $40).
- El SAT (frame estable) usa sprites con tiles `0x1c0-0x1d8` en 5 filas (y=56,72,88,104,120) para la pregunta.
- **El bloque2 de dificultades YA ocupa ese rango VRAM** (tiles 0x1c0-0x1c6 y 0x1d0-0x1d4 con datos) ANTES de dibujar la pregunta (capturado en frame +0 del .state).

### Desborde del pool (HECHO)
- Pool de tiles dinámicos `0x1c0-0x1d8` = 25 tiles.
- Pregunta "¿Cuál quieres cargar?" = 21 chars + dificultades (FÁCIL 5, NORMAL 6, DIFÍCIL 8, MUY DIFÍCIL 11) = 30 chars. Total 51.
- **51 > 25 → desborde.** El renderizador dinámico pisa los tiles del bloque2.

### Sobre el flag HFLIP (HECHO)
- El sprite de "¿" (tile 0x1c0) tiene flags=0x018e → **NO HFLIP, NO VFLIP**. El "espejado" NO es por flag; es por el bitmap corrupto causado por la colisión de tiles.

### Conclusión / fix probable (a implementar)
- **No es solo el bitmap**: aunque arreglemos la "¿" en su slot, seguirá pisándose con las dificultades porque comparten tiles 0x1c0-0x1d8.
- Fix estructural: **ampliar/realojar el rango de tiles dinámicos** del renderizador de texto para que no invada el rango estático del bloque2 (0x1c0-0x1d8), y/o dar a la pregunta su propio pool.
- Alternativa más simple: separar el renderizado de la pregunta de las opciones, o usar un rango VRAM libre para la pregunta.

### Datos clave para implementar
- Renderizador: PC $D6BF (banco 0x0C) copia glifo a dest VRAM $16/$17; avance $40 por char.
- El dest inicial y el pool de tiles: determinar dónde se fija el tile base del texto (probablemente una constante que apunta a 0x1c0/VRAM 0x7000).

### Dato adicional (HECHO) — layout de bloques de texto de la pantalla de carga
- La pantalla de carga renderiza 5 bloques de texto (pregunta + 4 dificultades), cada uno con dest base:
  - bloque 0: `$7008` (pregunta "¿Cuál quieres cargar?")
  - bloque 1: `$7148`
  - bloque 2: `$7288`
  - bloque 3: `$73c8`
  - bloque 4: `$7508`
- Paso entre bloques = `0x140` = espacio para **5 caracteres** (avance $40 por char doble).
- **La pregunta tiene 21 caracteres → desborda 16 chars a los bloques siguientes**, pisando las dificultades. Por eso se mezclan.
- Fijaciones de dest: ROM 0x1B8C4 (pregunta, ptr $5758) y ROM 0x1B95A (ptr $57AA), entre otras.
- El renderizador por bloque avanza $16/$17 en $40 por char (hook $D6BF); el bloque lo fija el caller.

### Estado: diagnóstico completo, falta implementar el fix estructural
- Confirmada la hipótesis de Claude: el pool/bloque de tiles de texto se agota y la pregunta invade las dificultades.
- El fix correcto NO es solo el bitmap de "¿": hay que **dar más espacio a la pregunta** (ampliar su bloque) o realojar los bloques.
- Decisión pendiente con el usuario sobre cómo proceder (cambio estructural delicado).

## 2026-08-02 (4) — Hallazgo definitivo: el bucle principal de la pantalla de carga

### El bucle (HECHO, desensamblado)
Rutina en banco 0x0C, ROM `0x1A519`-`0x1A558` (lógico `$C519-$C558`):
- Itera **5 bloques** (X = 0..4), CPX #$05.
- Cada iteración:
  - `LDA $5501,X` / `$5502,X` → puntero de texto (pregunta + 4 dificultades).
  - `LDA $C5AC,X` / `$C5AD,X` → destino base (tabla de 5 destinos).
  - `JSR $AA16` → renderiza el texto en el destino.
- Tabla de destinos `$C5AC` (ROM `0x1A5AC`): `[0x7008, 0x7148, 0x7288, 0x73c8, 0x7508]`.
- Tabla de textos `$5501` (ROM `0x1F501`): pregunta ($5B53) + dificultades.

### El bug (HECHO)
- `$AA16`/`$D6BF` avanza `$40` por carácter SIN límite de 5.
- La pregunta "¿Cuál quieres cargar?" (21 chars) se dibuja en `0x7008` + 20×$40 = hasta `0x7508`,
  **invadiendo los destinos de las dificultades** (`0x7148, 0x7288, 0x73c8, 0x7508`).
- Verificado en dstlog: la pregunta dibuja chars en `0x7008...0x7288` y la primera dificultad empieza en `0x7148` (DENTRO del rango de la pregunta) → colisión.

### Fix estructural (candidato)
- **Ampliar el bloque de la pregunta**: reubicar los 5 bloques para dar más espacio a la pregunta
  (p. ej. que la pregunta tenga un rango mayor antes de las dificultades).
- O cambiar el destino base de la pregunta a una zona VRAM más grande/libre.
- La tabla de destinos es `$C5AC` (ROM `0x1A5AC`), fácil de editar (5 punteros de 16 bits).
- El renderizador no tiene límite de caracteres → solo hay que dar espacio en VRAM.

### Dato clave para el fix
- El CG de sprites va de VRAM 0x0000 a... (verificar cuánto VRAM hay y qué está libre).
- Cada carácter doble-ancho ocupa 0x40 bytes (tile 16x16, 4 planos).
- La pregunta necesita 21 chars × 0x40 = 0x540 bytes de VRAM.

### Espacio VRAM disponible (HECHO)
- VRAM total: 65536 bytes (0x10000).
- CG de sprites usado: tiles 0x000-0x01f, 0x040-0x07f, 0x140-0x17e, 0x180-0x1bc, 0x1c0-0x1ca, 0x1fc-0x1ff.
- **Tiles libres: 0x1d9-0x1fb** (VRAM 0x7640-0x7ef0), 37 tiles, ANTES del SAT en 0x7f00.
- Suficiente para la pregunta (21 tiles) y las dificultades (30 tiles).

### Plan de fix estructural (candidato)
- La pregunta necesita 21 tiles. Actualmente su bloque (0x1c0-0x1d4) colisiona con las dificultades.
- Opción: reubicar las 4 dificultades a los tiles libres (0x1d9+), dejando a la pregunta todo el rango 0x1c0+ (0x7000+) sin invadir.
- Editar la tabla de destinos `$C5AC` (ROM 0x1A5AC): cambiar los destinos base de las dificultades a la zona libre.
- El SAT refleja dónde se dibuja cada glifo (verificado: glifo dibujado en 0x7008 = SAT tile 0x1c0), así que al mover el dest base, el SAT debería seguirlo.

### Pendiente
- Confirmar cómo el SAT referencia los tiles (si sigue automáticamente al dest de dibujo, o si hay que ajustar el SAT).
- Confirmar con el usuario antes de implementar el cambio estructural.

## 2026-08-02 (5) — Verificación empírica: el SAT NO sigue al cambio de destino en $C5AC

### Prueba realizada
- Creé ROM test moviendo el destino base de la pregunta (bloque 0) en la tabla `$C5AC` (ROM 0x1A5AC) de `0x7008` a `0x7608` (zona libre).
- **Resultado: el SAT NO cambió** — los sprites del texto siguen en tiles `0x1c0-0x1c4` (y=56,72,88,104,120).

### Conclusión
- El tile del SAT de los sprites de texto NO se deriva del destino VRAM del glifo (tabla `$C5AC`).
- El SAT usa **tiles fijos** `0x1c0-0x1d8` para el texto, que son los MISMOS que el bloque2 de dificultades.
- Editar solo `$C5AC` NO es suficiente. Hay otra tabla/código que fija el tile del SAT de cada sprite de texto.

### Mecanismo confirmado
- El bucle `$C518` (ROM 0x1A518) itera 5 textos, fija `$16/$17` (dest VRAM glifo) desde `$C5AC` y llama `$AA16`.
- `$AA16`/`$D6BF` escribe el glifo en VRAM[dest] y el SAT (tile 0x1c0+) por separado.
- El SAT se sube a VRAM 0x7F00 vía `$E55A`.
- **Falta localizar: dónde se fija el tile SAT (0x1c0+) de los sprites de texto.**

### Estado
- Fix estructural requiere mover TAMBIÉN el tile del SAT (no solo el dest del glifo).
- Pendiente localizar la tabla/código que asigna tiles SAT al texto, o confirmar con el usuario.

## 2026-08-02 (6) — Hallazgo clave: la pregunta comparte los sprites del bloque2 de dificultades

### Verificación empírica definitiva (HECHO)
- Al mover el dest VRAM del glifo de la pregunta (tabla `$C5AC`) a `0x7608`, el glifo SÍ se dibuja en `0x7608` (dstlog lo confirma), pero el **SAT NO cambia** — sigue con tiles `0x1c0-0x1d8` en las mismas posiciones (5 filas × 3 cols, y=56..120).
- => Los sprites del texto de la pantalla de carga tienen **tiles y posiciones SAT FIJOS**, definidos por una tabla de sprites (no por `$C5AC`).
- => La tabla `$C5AC` solo controla el **dest VRAM del glifo** (bitmap), NO el SAT.

### Interpretación
- Los sprites fijos de texto (tiles 0x1c0-0x1d8, posiciones 5×3) son el **bloque2 de dificultades** ($5C05).
- La pregunta "¿Cuál quieres cargar?" se dibuja como glifos en VRAM 0x7000+ (tiles 0x1c0+), que SON los mismos tiles del bloque2.
- **La pregunta SOBREESCRIBE los tiles del bloque2** con sus glifos, y al ser larga (21 chars) pisa todos los tiles de las dificultades.

### Implicación para el fix
- El fix correcto NO es solo `$C5AC` ni el bitmap de "¿".
- Hay que **dar a la pregunta su propio conjunto de sprites/tiles SAT**, separado del bloque2 de dificultades.
- Implica entender dónde se define el bloque de sprites de texto de la pantalla (que asigna tiles 0x1c0-0x1d8 y posiciones fijas) y separar la pregunta de las dificultades.

### Pendiente / decisión del usuario
- Rediseño del layout de sprites de la pantalla de carga (dar a la pregunta un bloque propio).
- Es un cambio más estructural de lo esperado. Confirmar enfoque con el usuario.

## 2026-08-02 (7) — DESBLOQUEO: el bloque2 controla el SAT del texto; hallazgo decisivo

### Experimentos que llegaron hasta el final
1. Mover el dest del glifo de la pregunta (`$C5AC` bloque 0) a 0x7608 → el glifo SÍ se dibuja en 0x7608 (dstlog) pero el SAT NO cambia (sigue en 0x1c0-0x1d8). El texto se ve mal/cortado.
2. **Mover los tiles del bloque2 ($5C05) +0x19 → el SAT SÍ cambia** a tiles 0x1d9-0x1f1 (verificado). Pero el texto de la pregunta DESAPARECE porque los glifos se dibujan en 0x1c0+ y el SAT ahora apunta a 0x1d9+ (no coinciden).

### Estructura del sistema (HECHO)
- El **bloque2 ($5C05)** define los sprites del texto de la pantalla de carga: tiles 0x1c0-0x1d8, posiciones 5×3 (y=56..120, x=106..170). El SAT se deriva del bloque2.
- El **renderizador dinámico ($AA16/$D6BF)** dibuja los glifos en VRAM 0x7000+ = tiles 0x1c0+, según el dest de `$C5AC`.
- **Para que el texto se vea, el SAT (bloque2) debe apuntar a los tiles donde se dibujan los glifos (0x1c0+).** Están acoplados.
- La pregunta (21 chars) desborda de 0x7008 a 0x7288, pisando el bloque 1 (dificultad, base 0x7148). Superponen en 0x7148-0x7248.

### Implicación para el fix
- Hay que separar la pregunta de las dificultades dando a cada una su propio rango de tiles Y su propio SAT.
- Opciones:
  A) Dibujar la pregunta en tiles altos libres (0x1d9+, dest `$C5AC`→0x7608) y apuntar su SAT a esos tiles (editar la parte del bloque2 correspondiente a la pregunta). Dejar dificultades en 0x1c0+.
  B) Ampliar el pool de tiles: mover dificultades a 0x1d9+ (bloque2) y dejar la pregunta en 0x1c0+ con su SAT, ajustando el dest de la pregunta.
- Ambos son cambios de DOS frentes (dest glifo + SAT), acoplados por el bloque2.

### Estado
- Sistema completamente entendido. Falta diseñar el layout exacto y aplicar.
- Recomendación: coordinar con Claude (cuando vuelva) para el cambio estructural de dos frentes, o implementarlo con mucho cuidado y verificar.

## 2026-08-02 (8) — La "¿" quedó a medias (hipótesis del usuario CONFIRMADA) + colisión de tiles

### La "¿" en la fuente es basura (HECHO)
- El glifo "¿" ($C9) se lee de ROM `0x3DCA8` (banco 0x1E, origen $5ca8 con MPR2=$1E). Contenido actual es BASURA, no un "?" invertido.
- El "?" correcto está en ROM `0x3D858`.
- **El usuario tenía razón**: la "¿" quedó a medias cuando se hizo la fuente; debería ser el "?" invertido verticalmente.
- Generé el "¿" correcto invirtiendo verticalmente el "?" de 0x3D858:
  bytes: `70 88 04 42 82 20 40 00 c2 24 18 08 08 04 fc 00 3e 40 40 44 42 fe 40 00 30 08 04 04 42 c2 82 00`
  (prueba en ROM /tmp/t_q_inv.pce).

### PERO: el tile 0x1c0 se sobrescribe (colisión)
- Aunque puse el "¿" invertido en 0x3DCA8, el VRAM tile 0x1c0 (0x7000) muestra una "C"/"O" constante.
- El renderizador escribe el glifo en 0x7008 pero OTRO proceso (bloque2/selector) lo sobrescribe con "C".
- => El bitmap solo NO basta: hay colisión de tiles entre la pregunta y las dificultades/selector.

### Doble problema confirmado
1. **Bitmap de "¿" mal** (quedó a medias) → arreglar invirtiendo el "?".
2. **Colisión de tiles** (0x1c0-0x1d8 compartidos) + **desborde** (pregunta 21 chars pisa dificultades).

### Punto clave para Claude
- El renderizador lee el glifo de ROM 0x3DCA8 (banco $1E) y lo escribe a VRAM (dest $C5AC).
- Para arreglar la "¿": escribir el bitmap invertido en 0x3DCA8.
- PERO también hay que resolver la colisión de tiles para que se vea.

## 2026-08-02 (9) — Corrección del bitmap de "¿" + tiles libres confirmados

### El slot de "¿" es de 8 bytes (Claude tenía razón) [HECHO]
- Cada código de la fuente usa un slot de **8 bytes** (verificado: 0x3DCA8=C9, 0x3DCB0=CA, 0x3DCB8=CB, 0x3DCC0=CC, contiguos de 8 en 8).
- Los slots 0xCA/0xCB/0xCC tienen contenido real (acentos). NO escribir 32 bytes (rompería 3 caracteres).
- Solo el slot 0xC9 (ROM 0x3DCA8, 8 bytes) pertenece a "¿".

### Bitmap correcto de "¿" = rotación 180° del "?" [HECHO]
- "?" está en ROM 0x3D858 (8 bytes): `00 40 20 82 42 04 88 70`.
- **Rotación 180°** (invertir filas + bit-reverse) = `0e 11 20 42 41 04 02 00`. Es la relación tipográficamente correcta (Claude tenía razón; el vflip-solo curva el gancho al lado equivocado).
- Aplicado SOLO al slot 0xC9 en /tmp/t_q_rot180.pce. Slots 0xCA/0xCB/0xCC intactos.

### Tiles libres confirmados [HECHO]
- Tiles 0x1d9-0x1fb (VRAM 0x7640-0x7ef0) están **libres** en runtime durante la pantalla de carga.
- El melocotón usa tile 0x1a0 (VRAM 0x6800), muy separado. NO choca con el plan de ampliar el pool.
- SAT de texto usa tiles 0x1c0-0x1d8 (pregunta+dificultades).

### Estado del fix estructural
- Bitmap de "¿" listo (8 bytes, rotación 180°).
- El fix estructural (separar pregunta de dificultades / ampliar pool) requiere rediseñar el bloque2 y el SAT; pendiente de implementar con cuidado.

## 2026-08-02 (10) — Hallazgo definitivo: la pantalla de la pregunta NO usa $E3EB

### Medición (HECHO)
- Añadí MPR2 al splog ([9]=HuCPU.MPR[2]).
- Capturé splog (llamadas a $E3EB) en TODA la ventana del .state (400 frames): **0 llamadas**.
- Capturé splog navegando título→selector→CARGAR→pregunta (reproducción real del bug): **0 llamadas en la transición a la pregunta**.
- Confirmé que el splog FUNCIONA: en el selector sí captura 64 llamadas (from=cc22, ptr $43d6.., MPR2=0x17).

### Conclusión (HECHO)
- **La pantalla de la pregunta NO usa el compositor genérico de sprites $E3EB.**
- El texto de la pregunta se compone con el renderizador directo ($C518/$AA16/$D6BF) que ya mapeamos.
- La hipótesis de Claude (JSR $E3EB con retorno en banco 0x0C) es INCORRECTA para esta pantalla. No hay tal sitio.

### Implicación
- El fix estructural NO pasa por $E3EB. Hay que trabajar sobre el renderizador directo:
  - El SAT del texto es fijo (tiles 0x1c0-0x1d8, del bloque2), el renderizador dibuja los glifos en esos tiles.
  - La pregunta desborda e invade las dificultades.
- El mecanismo de cómo el renderizador escribe el SAT (si lo hace) sigue sin localizarse: el renderizador escribe el glifo en VRAM y el SAT ya está precargado.

## 2026-08-02 (11) — CLAUDE SE EQUIVOCA EN LA CUENTA DE TILES (medido)

### Medición real del uso de tiles (HECHO, con dstlog)
- En el renderizado real, **cada 2 caracteres comparten 1 tile de 16x16** (el dest avanza $40 = 64 bytes por cada 2 chars).
- La pregunta (21 chars) usa **11 tiles** (destinos 0x7008-0x7288, tiles 0x1c0-0x1ca).
- "DIFÍCIL 1" (10 chars) usa 5 tiles (0x7148-0x7248, tiles 0x1c5-0x1c9).

### Cuenta correcta de tiles (refuta a Claude)
- Pregunta 21 → 11 tiles
- FÁCIL 5 → 3, NORMAL 6 → 3, DIFÍCIL 7 → 4, MUY DIFÍCIL 11 → 6
- **TOTAL = 27 tiles** (no 100 como calculó Claude).
- Presupuesto disponible: 60 tiles (0x1c0-0x1fb). **Sobran 33.**
- => **NO hay problema de presupuesto de VRAM.** El usuario tiene razón.

### SAT vs dstlog (el modelo correcto)
- El SAT muestra **15 sprites de texto** (5 filas × 3), tiles 0x1c0-0x1d8.
- Cada sprite (16x16) muestra 2 caracteres → capacidad de 30 caracteres.
- El problema NO es falta de tiles, sino **layout de los bloques en $C5AC**: la pregunta (21 chars)
  excede su bloque de 20 tiles e invade el bloque de la dificultad.

### $DE/$DF NO son saltos de línea (refuta a Claude)
- `$D756` (manejador de $DE/$DF) carga puntero de `$D7CA` (DE→0x5B14, DF→0x5B1C) y
  **copia 8 bytes de un glifo especial a VRAM** en $16-4. No es control de cursor/línea.
- Los manejadores apuntan a datos de glifos (bytes de tiles), no a subrutinas.
- => La hipótesis del salto de línea por $DE/$DF es INCORRECTA.

### Conclusión
- El fix real es de LAYOUT: repartir bien los bloques en $C5AC (o ampliar el bloque de la
  pregunta), con la caja ancha. Hay tiles de sobra. El usuario tiene razón en el enfoque.

## 2026-08-02 (12) — Confirmación: 0x7008 está dentro del tile 0x1c0; $C5AC solo no arregla

### Dato que pidió Claude (HECHO)
- El primer carácter de la pregunta se escribe en dest **0x7008**, que está **8 palabras dentro del tile 0x1c0** (0x7000-0x7040, tile 16x16).
- El tile 0x1c0 es el que usa el bloque2 ($5C05) para las dificultades.
- => Coincide con la hipótesis de que el arranque de la pregunta pisa el tile del bloque2 desde el primer glifo.

### PERO: mover $C5AC solo NO arregla (HECHO, medido)
- Probé mover el bloque 0 de la pregunta a 0x7000 (alineado a inicio de tile) y a 0x7600 (tile libre 0x1d8).
- **El SAT NO cambia** (sigue en tiles 0x1c0-0x1d8, fijo del bloque2). La pantalla se ve idéntica a la rota.
- => El dest del glifo ($C5AC) y el SAT (bloque2) están DESACOPLADOS: mover uno no mueve el otro.
- => La hipótesis de Claude de "realinear el arranque en $C5AC" NO es suficiente por sí sola.

### Implicación
- El fix real requiere **rediseñar el bloque2** (SAT) para que la pregunta use tiles propios,
  Y mover el dest del glifo ($C5AC) a esos mismos tiles. Son dos frentes acoplados.
- Otra vía: entender por qué el dest es 0x7008 (+8) y si el desalineamiento es la causa real
  de la colisión (aunque moverlo no cambie el SAT).

### Rediseño del bloque2 (estado)
- `$5C05` (bloque2) está en la tabla `$5BA6[2]/[3]` (bloques de sprites del menú).
- `$5501` es la tabla de textos de la pantalla de carga (pregunta + 4 dificultades).
- El compositor `$E3EB` usa `$5BA6` para el selector, pero NO para la pregunta (confirmado: 0 llamadas).
- El bloque2 define los 15 sprites de texto fijos (tiles 0x1c0-0x1d8, 5×3).
- Para poner la pregunta en una fila (11 tiles), hay que rediseñar el bloque2, pero el formato exacto
  de x/y y el flag "doble" requiere desensamblar el compositor que lo interpreta. Arriesgado hacerlo a ciegas.
- Siguiente paso: desensamblar el compositor que lee `$5C05` (Claude puede, tiene contexto), o entender
  cómo el renderizador $C518/$AA16 convierte el bloque2 en SAT.

### Qué me falta saber (para pedírselo a Claude, contexto que él tiene)
1. **Formato exacto del bloque2 ($5C05)**: cómo el compositor interpreta cada entry de 5 bytes
   [code, fl_lo, fl_hi, x, y]. Sé que tile=code+0x1C0 y fl_hi bit0="doble". FALTA:
   - Cómo se traduce x/y a la posición del sprite en el SAT (base de pantalla, unidades).
   - Dónde se fija la base (x/y) desde la que parte cada bloque.
   - Si el bit "doble" significa que el sprite ocupa 2 tiles de 16px.
2. **La rutina exacta que convierte $5C05 → SAT**: cuál código lee el bloque2 y construye las
   entradas SAT que vemos (tiles 0x1c0-0x1d8, posiciones 5×3: y=56..120, x=106..170).
   ¿Es $E3EB (compositor genérico) u otra? Nosotros medimos que la pregunta NO llama a $E3EB.
3. **Si el renderizador de texto ($C518/$AA16/$D6BF) escribe el SAT directamente**, o si el SAT
   está precargado del bloque2, y dónde.
4. **Por qué el dest es 0x7008 (+8)**: si el +8 es intencional (margen de glifo) y si alinearlo
   a 0x7000 (o mover el bloque) afecta al dibujo del glifo.

## 2026-08-02 (13) — Watchpoint SAT: PCs imprecisos pero apuntan a banco 0, región $E500-$E590

### Método de Claude aplicado (watchpoint escritura SAT)
- Capturé escrituras a VRAM 0x7F00+ (SAT) con tiles 0x1c0-0x1d8 durante la pregunta.
- PCs obtenidos: 0xe4aa, 0xe574, 0xe582, 0xe588, 0xe58b, 0xe57c, 0xe585, 0xe4be, 0xe4c1, etc. (banco 0).
- **El PC varía mucho (±0x20) entre frames** → la captura del PC del vramlog NO es fiable
  (desfase de la instrumentación, peor que el 1-2 bytes que advirtió Claude).
- El melocotón (tile 0x1a0) se escribe desde ~0xe4aa-0xe4c3; el texto (0x1c0-0x1d8) desde ~0xe574-0xe58e.

### Interpretación
- Todos los PCs apuntan a la región $E500-$E590 de banco 0 (composición del SAT del menú).
- `$E574` = `JSR $EF5F`, `$E577` = `JMP $C518`. El bucle `$C518` dibuja el texto.
- El SAT se escribe cada frame desde la tabla intermedia; los tiles 0x1c0-0x1d8 vienen del bloque2.

### Estado
- No pude aislar el PC exacto de la rutina por el desfase de la instrumentación.
- El hallazgo útil: la composición del SAT del texto ocurre en banco 0, región $E500-$E590,
  vía $E574→$C518. Claude puede desensamblar esto con el desfase en mente.
- FALTA (para el fix): cómo $C518/$AA16 convierte el bloque2 en el SAT con tiles 0x1c0-0x1d8.

## 2026-08-02 (14) — AVANCE: formato del bloque2 descifrado

### Hallazgo (HECHO, por experimento)
- Al cambiar la y de una entrada del bloque2 ($5C05), el sprite correspondiente del SAT se desplaza.
- El bloque2 define **posiciones relativas a una base** (base_x=106, base_y=56).
- Cada entrada [code, fl_lo, fl_hi, x, y]: tile=code+0x1C0, posición=(106+x, 56+y) en píxeles.
- x_rel e y_rel en píxeles directos (y=0x10=16 → fila siguiente a +16px; x=0x20=32 → siguiente sprite +32px).
- Flag "doble" (fl_hi bit0): el sprite ocupa 2 tiles (32px de ancho).

### Implicación para el rediseño
- El bloque2 define 15 sprites (5 filas × 3) que muestran los tiles 0x1c0-0x1d8.
- La pregunta (21 chars) se reparte en varias filas (3 sprites dobles por fila = ~12 chars/fila).
- Para poner la pregunta en UNA línea: ampliar la fila de la pregunta a ~6 sprites dobles
  (x=0..0xA0) y ensanchar el bocadillo.

### El compositor del SAT está COMPRIMIDO en ROM (HECHO)
- El código en banco 0 (0xE540-0xE5A0) que compone el SAT es **código comprimido** (patrones
  de repetición `61 60 81 80 31 30...`), descomprimido en runtime. No desensamblable estático.
- El PC del vramlog (0xe571-0xe591) apunta a esa zona pero es poco fiable por el desfase.

### Estado
- Entiendo el formato del bloque2 y la base (106,56).
- El rediseño (pregunta en una línea) es viable: ampliar la fila de la pregunta en el bloque2 a
  ~6 sprites dobles + ensanchar el bocadillo + ajustar $C5AC.
- El compositor comprimido dificulta la verificación, pero puedo iterar empíricamente editando
  el bloque2 (los datos) y observando el SAT.

## 2026-08-02 (15) — PLAN completo del rediseño (pantalla "¿Cuál quieres cargar?")

### Problema raíz (HECHO, medido)
- Pregunta (base 0x7008) dibuja 21 chars → tiles 0x1c0-0x1ca (11 tiles, 2 chars/tile).
- Dificultad "DIFÍCIL 1" (base 0x7148) dibuja 10 chars → tiles 0x1c5-0x1c9 (5 tiles).
- **Se superponen en tiles 0x1c5-0x1c9** → por eso se mezclan.
- El SAT (bloque2, $5C05) muestra los tiles en 5 filas de 3 sprites → la pregunta se ve partida.

### Frentes a tocar
1. **$C5AC (destinos, ROM 0x1A5AC):** reubicar para que cada bloque tenga tiles SIN solapar.
   - Pregunta: tiles 0x1c0-0x1d5 (22 tiles, cabe 21 chars).
   - Dificultades: tiles libres 0x1d6-0x1fb.
2. **Bloque2 ($5C05, ROM 0x1FC05):** reorganizar los 15 sprites:
   - Pregunta en UNA fila ancha (6 sprites dobles, x=0..0xA0, y=0x00).
   - Dificultades debajo (2-3 filas).
   - Base del bloque2: x=106, y=56.
3. **Bocadillo (box2, stream 0x1E0D1):** ensanchar de 11 a ~24 tiles (88px → ~192px).
   - Borde sup `01 9×02 03` → `01 16×02 03` (u otro ancho).
   - Ajustar interiores `04 9×09 05` → `04 N×09 05`.
   - Ajustar rellenos `ff 19 00` (vacíos) según el nuevo ancho.

### Método (seguro, David: revertimos si falla)
- Iterar empíricamente: editar un frente, verificar en emulador (SAT + pantalla), revertir si rompe.
- Verificar con dstlog (dónde se dibujan los glifos) y SAT (qué sprites se muestran).
- No romper el selector (CANTO DE JIZO/CARGAR) ni el texto de la carga (bloque2 restaurado en v15).

### Datos clave
- Base bloque2: x=106, y=56. Sprite doble = 2 tiles = 32px.
- Pregunta 21 chars = 11 tiles = 6 sprites dobles (en fila ancha).
- Bocadillo actual: 11 tiles (88px), 10 filas interiores.

## 2026-08-02 (16) — AVANCE GRANDE: la pregunta SÍ usa el compositor de sprites ($E4E3) con el bloque2

### Descubrimiento (HECHO, con menudata)
- El compositor de sprites ($E4E3, bus_pc=0xE4E3) SÍ construye el SAT de la pregunta, recorriendo el
  **bloque2 ($5C05-$5C4B)** entrada por entrada (5 bytes/sprites, cnt 1-15).
- Para cada entrada: sprite en posición final (x, y), tile=code+0x1C0.
- **base_x=0x4a (74), base_y=0x38 (56)** para el texto de la pregunta.
- El menudata da: ptr=$5C05..$5C4B (cada +5), base_x=0x4a, base_y=0x38, cnt 1-15.
- El splog no capturó esto porque el compositor se llama por un camino que no es JSR $E3EB directo
  (por eso antes vimos "0 llamadas").

### Implicación
- La pregunta se renderiza con el compositor de sprites estándar, usando el bloque2 como datos.
- El fix de "pregunta en una línea" = reorganizar el bloque2 (x_rel/y_rel de las entradas de la
  pregunta) + ajustar base_x/base_y si hace falta + $C5AC para el destino de los glifos.

### Arimética de posición (a confirmar)
- La posición final (x,y) del menudata: x=0x6a(106),0x8a(138),0xaa(170) para tiles 0x1c0,0x1c2,0x1c4
  (x_rel 0,0x20,0x40 del bloque2). base_x=0x4a(74). 
- Relación no trivial (106 != 74+0). Falta la aritmética exacta del compositor (código comprimido).

### Estado
- El compositor ($E4E3) es el que construye el SAT de la pregunta. Código en ROM comprimido (0xE540+).
- Para el rediseño: entender la aritmética de posición (base_x + x_rel * factor) descomprimiendo el
  compositor, o iterar empíricamente editando el bloque2.
- El bloque2 está en RAM intermedia 0x0000 (SAT) antes de subirse a VRAM 0x7F00.

## 2026-08-02 (17) — AVANCE: la pregunta "¿Cuál quieres cargar?" queda en UNA línea (David: partir de la separación correcta)

### Método aplicado (directiva de David)
"Partir de la separación correcta, aunque el texto se corte, y luego ampliar la ventanilla y
poner los caracteres en el orden correcto." => primero UNA línea con orden y separación natural.

### Causa del desorden anterior (paso16/20/24) — HECHO
- El bloque2 tiene 15 entradas fijas; los experimentos solo movieron 6 y dejaron 0x1c5 y otros
  en su sitio => el orden se desordenaba.
- El compositor SÍ salta sprites: ver regla abajo.

### REGLA DEL COMPOSITOR (HECHO, medido por sonda)
- Un sprite se DESCARTAR si x_final >= 234 (x_final = base_x + x_rel, mod 256; base_x_eff=106).
  - simple: presente hasta x=233, descartado desde x=234.
  - doble: ídem (no depende del ancho).
- Un sprite con x_final que da 0 (wrap a 256) aparece en x=0 (envuelto, basura).
- Implicación: en una fila de 11 tiles (176px), la última tile debe estar en x<=233 => la
  pregunta en una fila debe empezar en x=73 (SAT).

### Rediseño del bloque2 ($5C05, ROM 0x1FC05) — pregunta en UNA fila
- Pregunta (6 sprites, y=0x00): 0x1c0(D)@73, 0x1c2(D)@105, 0x1c4(D)@137, 0x1c6(D)@169,
  0x1c8(D)@201, 0x1ca(SIMPLE)@233  (x_rel DF,FF,1F,3F,5F,7F)
  - El último tile 0x1ca es SIMPLE (16px) porque es el char "?" y doble desbordaría.
- Dificultad (5 sprites dobles, y=0x20): 0x1d0@80, 0x1d2@112, 0x1d4@144, 0x1d6@176, 0x1d8@208.
- Sobrantes (idx 0,7,8,9): code=0x15 (tile vacio 0x1d5, transparente), x=0,y=0.
  - No ocultarlos con y=0xF0: envuelve a y=40 y aparece en pantalla (HECHO, medido).

### $C5AC (ROM 0x1A5AC) — mover dificultad a tiles libres
- [0]=0x7008 (pregunta, tile SAT 0x1c0) sin cambios.
- [1]=0x7408 (dificultad -> SAT 0x1d0), [2]=0x7608 (0x1d8), [3]=0x7808 (0x1e0), [4]=0x7a08 (0x1e8).
- Antes [1]=0x7148 (SAT 0x1c5) pisaba la pregunta en 0x1c5-0x1c9 (causa de la mezcla).

### Fix bitmap "¿" (pendiente, ahora aplicado)
- ROM 0x3DCA8, 8 bytes: `0e 11 20 42 41 04 02 00` (rotacion 180° del "?").
- Aplicado en la ROM de prueba test_qonerow.

### Resultado (HECHO, medido)
- SAT: pregunta en UNA fila (0x1c0,0x1c2,0x1c4,0x1c6,0x1c8,0x1ca en y=56, x=73..233), orden de lectura.
- dstlog: pregunta limpia en tiles 0x1c0-0x1ca; dificultad " DIFÍCIL 1" en tiles 0x1d0-0x1d4; bloques 2-4 vacíos.
- sprtile: fila de pregunta muestra tiles en orden 0x1c1..0x1ca izquierda->derecha, espaciado 16px/tile.
- Frame: pregunta en una línea (y67-74, x42-207 aprox), dificultad en y100-106.
- La caja (bocadillo) es x80-175 (94px); la pregunta la desborda por ambos lados => esperado, toca ENSANCHAR la caja.

### Pendiente
- Ensanchar la caja (box2) para que quepa la pregunta. El texto actualmente sale centrado sobre la caja;
  David quiere alineado a la izquierda => decidir ancho y posición de la caja + alineación de la pregunta.
- Verificar que la dificultad lea "DIFÍCIL 1" correctamente.
- Alinear pregunta a la izquierda respecto al bocadillo ensanchado.
- ROM de prueba: Roms/Pruebas/test_qonerow.pce (MD5 16e30a5ea2ef3c088f592d3d33535062).

## 2026-08-02 (18) — Localizacion del texto de la pregunta + calibracion del glifo "?"

### Texto "¿Cuál quieres cargar?" (HECHO)
- ROM 0x1FB53 (CPU $5B53): `01 c9 43 b5 bb ac 20 b1 b5 a9 a5 b2 a5 b3 20 5d a1 b2 a7 a1 b2 3f 00`
  = [01] + 21 chars latinos + [00]. Codigos: c9=? C=43 u=b5 á=bb l=ac esp=20 q=b1 i=a9 e=a5 r=b2 g=a7 s=b3 c=5d a=a1 ?=3f.
- Tabla de textos $5501 (ROM 0x1F501): [0]=$5B53 (pregunta), [1-5]=dificultades/vacio.

### Calibracion del render de glifos (HECHO, mapeo 1:1)
- Escribiendo diagonal 0x80..0x01 en slot 0xC9 (ROM 0x3DCA8): fila de byte r -> pantalla y=r+67,
  bit en posicion c (bit7=col0) -> x=41+c. NO hay desplazamiento de columna (antes crei que si).
- La "?" (0x3F) se pinta bien en pantalla; la "?" de apertura (0xC9) con rot180 (0e 11 20 42 41 04 02 00)
  se pinta 1:1 pero David la ve como un pegote ("churro raro").
- La rot180 es tipograficamente correcta (Claude lo confirmo) pero en esta fuente bloqueada queda rara.
- Alternativa: vflip (70 88 04 42 82 20 40 00) o disenar una "?" a mano mas limpia. Pendiente decision de David.

## 2026-08-02 (19) — MELOCOTON localizado y parcheado (pantalla de carga)

### Rom de Claude y glifo "?"
- David paso la ROM de Claude (GitHub v07_wip, MD5 993ea16e). Es MI rediseño (pregunta en fila + dificultad en y76)
  con el glifo "?" de Claude. El glifo "?" de Claude (0x3DCA8 = 0c 00 0c 38 63 63 3e 00) se ve mejor alineado que
  el mio (punto arriba y gancho en y70-73, centrado con el cuerpo de las letras). ADOPTADO.
- Nota: Claude busco "¿Cuál quieres cargar?" en ASCII plano y NO lo encontro (esta en encoding latino en ROM 0x1FB53).
  Claude dijo que su ROM no lo contenia, pero si esta (solo busco mal).

### MELOCOTON de la pantalla de carga (HECHO)
- Rutina $C73A (banco 0x0D, ROM 0x1A73A) compone el melocoton:
  - base_x = $3C86 + $35, base_y = ($C767[fila] + $3C87) + $37
  - $3C86/$3C87 se inicializan en $C6D0 (ROM 0x1A6D0) desde la tabla $C6FC (ROM 0x1A6FC)
- La CARGA usa $3C83=0x02 => entrada 2 de la tabla $C6FC:
  - $3C86 = ROM 0x1A704 = 0x50, $3C87 = ROM 0x1A703 = 0x48, $3C85 = ROM 0x1A702 = 0x03
- El SELECTOR usa otra entrada (0x1A6FE, entrada 0) => NO se toca.
- Relacion medida: X_melocoton = $3C86 + 34. Con $3C86=0x50(80) => X=114. Con $3C86=0x27(39) => X=73.
- PARCHE: ROM 0x1A704: 0x50 -> 0x27. Mueve el melocoton a X=73 (alineado con la pregunta).
- El melocoton y "DIFÍCIL 1" ahora en la misma linea (y76 SAT, pantalla y84-94), sin solape
  (melocoton pantalla x45-51, "DIFÍCIL 1" x56-175).
- Importante mapeo RAM: $3C86 (pag 3, 0x3000-0x3FFF) se mapea a BaseRAM[0x1C86] (mirrored A&0x1FFF), NO a 0x3C86.
- ROM final: Roms/Pruebas/test_qonerow_melo.pce (MD5 0d044a6a4d0227a7bdb982d1fb5d9b82).

### Estado
- Pregunta en una linea (correcta), dificultad en la linea del melocoton, glifo "?" de Claude, melocoton alineado a la izquierda.
- FALTA: ensanchar el bocadillo (box2) para que quepa la pregunta (desborda x80-175). El texto actualmente sale centrado
  sobre la caja; David quiere alineado a la izquierda.
- Pendiente experimento precaucion: "MUY DIFÍCIL" en la pantalla de seleccion de dificultad (ventanilla/bocadillo).

## 2026-08-02 (20) — Cambio de emulador: Beetle PCE (no Fast)

### Motivo (HECHO)
- David reporta que el core **Beetle PCE Fast** da problemas con las capturas de pantalla.
- Se adopta como referencia el core que él usa en RetroArch: **NEC - PC Engine / SuperGrafx / CD (Beetle PCE)**.

### Estado de los dos cores (HECHO, medido)
- `emutools/beetle-pce-fast-libretro/` → `mednafen_pce_fast_libretro.so`
  - Es el core **instrumentado** (hooks `arena_*`). Sigue siendo el único con instrumentación.
- `emutools/beetle-pce-libretro/` → `mednafen_pce_libretro.so` (Beetle PCE v1.29.0)
  - Clonado y compilado en esta sesión. **Sin instrumentar.**
  - Arrancaba con segfault; se aisló con gdb y se corrigió la secuencia de init.

### Compatibilidad de estados (HECHO, medido)
| Recurso | Fast | PCE | Notas |
|---|---|---|---|
| `.srm` (BRAM 2048 B) | OK | OK | **Compatible en ambos**. No hay que regenerarlo |
| `.state` | 13.379 B (`#RZIPv…`) | serialize = 83.523 B | **NO compatible entre cores** |

- `retro_unserialize` de un state Fast dentro de PCE devuelve `False`.
- Consecuencia práctica: los `.state` que aporta David son de **Beetle PCE** y **no
  cargan en el runner instrumentado (Fast)**. Para pantallas concretas hay que navegar
  con entrada simulada en Fast, o instrumentar también el core PCE.

### Save-states aportados por David (HECHO)
- `momotaro_pce.state` (13.714 B) — Beetle PCE, entra a la pantalla de carga.
- `Momotarou Katsugeki (Japan).state` — Beetle PCE, entra **directo a la pantalla de
  selección de dificultad**. Descargado desde el repo del usuario.

### Limitación registrada
- La navegación por entrada simulada hasta la pantalla de dificultad en Fast resultó
  **inestable** (el segundo RUN sobre EMPEZAR no siempre se registra). Varias entregas
  de esta sesión se verificaron sólo por offsets medidos y las comprobó David en su
  Beetle PCE. Queda anotado como limitación real del banco de pruebas.

## 2026-08-02 (21) — RESUELTO: la "?" de cierre de "¿Cuál quieres cargar?"

### Causa real (HECHO, desensamblado)
- El compositor de sprites **no está comprimido en RAM**: está en ROM banco 0,
  `$E3EB–$E5B0` (fichero 0x03EB–0x05B0). El "dump de RAM alrededor del PC" que se
  pidió inicialmente **no aplicaba**: el PC apunta a ROM.
- `x_rel` se trata como **entero con signo de 8 bits**, con sign-extend en `$E455`
  (`AND #$80` / `BEQ` / `DEC $15`).
- Clip en `$E4B4`: descarta si X₁₆ ≥ `$0120` **o si es negativo**.

Fórmula real:
```
X_SAT = base_efectiva + sex(x_rel),  sex(x_rel) ∈ [-128, +127]
```

Con base efectiva 106:
- `x_rel = $7F` (+127) → X = 233 ← **techo absoluto alcanzable**
- `x_rel = $82` (−126) → X = −20 → descartada

### [DESCARTADO] "el umbral es 234"
La sonda anterior concluyó que existía un límite en X ≥ 234. **Es falso como causa**:
no hay ningún `CMP #$EA`. 233 es simplemente `106 + 127`, la frontera del signed 8-bit.
La medición era correcta; la interpretación, no.

### Solución (HECHO, aplicada)
No se puede llegar a X=236 tocando `x_rel`: hay que **subir la base**.
- `LDX #$4A` → `#$4D` en `$C5C3` (ROM **0x1A5C4**): base 74 → 77, base efectiva 106 → 109.
- Con `x_rel = $7F` (+127): 109 + 127 = **236** ✔
- Los `x_rel` del bloque2 se restauran a `DF FF 1F 3F 5F 7F` (sin el +3 previo).
- Melocotón compensado en ROM 0x1A704 → `$2A`.
- Selector compensado en `$5BDC` con `x_rel −3`.

### Bocadillo de la pantalla de carga (HECHO)
- Ensanchado a 24 tiles = 192 px, rabillo centrado en columnas 15–16.
- **Hallazgo del formato de stream**: `FF nn tile` genera **nn+1 copias**, no `nn`.
  Ese off-by-one era la causa de que el borde inferior se descuadrara.

### Entrega
- `Roms/Pruebas/test_q_close_v18.pce` — MD5 `ad1d53bc34dd7570033199006ac915f1`
- `Parches/momotaro_pantalla_carga_v18.ips` — MD5 `bce49f82c424470355efe79ff57466f0`

## 2026-08-02 (22) — Selector de dificultad: bases por pantalla

### Regresión detectada por David (HECHO)
El `LDX #$4D` global de v18 movió **también** el texto del selector de dificultad,
que necesita base `$58`. El texto se iba a la izquierda y chocaba con el melocotón
(el melocotón sí estaba en su sitio).

### Fix (HECHO)
Tabla de `base_x` **por pantalla**, indexada por `$3C83`:

| `$3C83` | Pantalla | base_x |
|---|---|---|
| 0 | Selección de dificultad | `$58` |
| 1 | Selector CANTO/CARGAR | `$4A` |
| 2 | Carga de partida | `$4D` (la "?" a X=236) |

- Trampolín en `$DC77`, llamada desde `$C5BD`.
- Zona libre usada: ROM 0x1BC77 (un intento previo pisó el `JMP $EE86`; corregido).

### Entrega
- `Roms/Pruebas/test_diffsel_v19.pce` — MD5 `1779453d5c79a78f35b0adee4202d4c2`

## 2026-08-03 (23) — ゲロゲロモード: cuarto modo de dificultad

### Confirmado (HECHO, fuentes externas + ROM)
| Modo JP | Desbloqueo |
|---|---|
| かんたん (fácil) | siempre |
| ふつう (normal) | siempre |
| むずかし (difícil) | siempre |
| **ゲロゲロ** | **al completar むずかし** |

- El texto "MUY DIFÍCIL" **ya existe** en ROM 0x1FB2B (12 glifos).
- La tabla de punteros en 0x1F4AE **ya tiene 4 entradas**.
- ゲロゲロ ≈ "modo vómito/arcada" por lo duro que es. Nombre definitivo **sin decidir**
  (candidatos: MUY DIFÍCIL, NÁUSEAS, LETAL, INFERNAL).
- **Decisión de David**: dejarlo oculto, como en el original. Sólo se usó "MUY DIFÍCIL"
  temporalmente como *probe* de anchura.

### [HIPÓTESIS descartada por análisis] "el bocadillo se ensanchará solo"
El bocadillo es un stream de tiles de tamaño fijo. Si al desbloquear ゲロゲロ el juego
sólo añade una fila de sprites sin tocar el stream, el texto se saldrá. **No hay
reescalado automático**: habrá que ampliarlo a propósito cuando se monte la 4ª fila.

## 2026-08-03 (24) — CAUSA RAÍZ: "MUY DIFÍC N" y "ORMAL" (colisión CG)

### El síntoma
Con "MUY DIFÍCIL" en la opción superior se leía `MUY DIFÍC N`, y `NORMAL` perdía
su primera letra (`ORMAL`).

### Causa (HECHO, desensamblado)
**No es un fallo de la fuente: es colisión de tiles CG.**

El bucle `$C4C0` pinta 3 líneas con destinos fijos en la tabla `$C5A2`:

| Línea | Destino original | Capacidad |
|---|---|---|
| Y0 (arriba) = DIFÍCIL | `$7008` | 5 tiles (paso `$140`) |
| Y1 = NORMAL | `$7148` | 5 tiles |
| Y2 = FÁCIL | `$7288` | 5 tiles |

"MUY DIFÍCIL" son 12 glifos = **6 tiles**, pero sólo había **5** reservados.
El 6.º tile cae en `$7148`, justo donde NORMAL escribe su primera "N".

Mapa de orden `$C59C = [2,1,0]`: arriba = id2 (difícil), medio = normal, abajo = fácil.

### Segundo hallazgo: el bocadillo de dificultad es OTRO stream
- **No** lo controla el stream del selector, ni el `CPX #$0C` de `$C633`.
- El bocadillo de la pantalla de dificultad es el stream en **ROM 0x1E07A**
  (tabla `$C499`, modo 0 → `$407A`).
- Por eso ensanchar el stream del selector no cambiaba nada aquí. Varias iteraciones
  se perdieron por atacar el stream equivocado.

### Fix (HECHO)
- `$C5A2` → `$7008, $7188, $7288` (6 + 4 + 3 tiles, sin solape).
- SAT `$5BAE` alineado a esos tiles.
- Stream 0x1E07A ensanchado a 14 tiles = 112 px.

## 2026-08-03 (25) — Ajuste fino del selector de dificultad (v25/v26)

### Iteraciones con David midiendo sobre captura (HECHO)
| Ajuste | Cambio |
|---|---|
| Rabillo del bocadillo | `empty` antes de `10 11`: 20 → 23 (+3 tiles = +24 px derecha) |
| Texto | `base_x` `$58` → `$52` (X₀ 120 → 114, −6 px) |
| Melocotón | `$3C86` `$50` → `$4A` (X 114 → 108, −6 px) |
| Bocadillo | 112 px / 14 tiles |

### v26 — restauración de la etiqueta (HECHO)
- Puntero 0x1F4AE[2]: `$5C51` (MUY DIFÍCIL) → `$5B21` (DIFÍCIL).
- SAT superior: 2 dobles (8 glifos), sin sprite extra.
- El string "MUY" en 0x1FC51 **se conserva** para ゲロゲロ más adelante.

### ESTADO ACEPTADO POR DAVID
```
Roms/Pruebas/test_diffsel_v26.pce
  MD5    b124c7ae288678a1419557276afd5648
  SHA-1  38d48019ec4d0053ff43c99aa14571b7684f16d6
  CRC32  b79d884d
Parches/momotaro_diffsel_v26.ips  MD5 4e20fb2e1534017416f338dd1c93ee81
```
Confirmado por David: *"Perfecto. Ya está todo como queríamos."*

Nota estética asumida: queda espacio vacío a la derecha del bocadillo, aceptado a
propósito para que quepa "MUY DIFÍCIL" cuando se implemente ゲロゲロ.

## 2026-08-03 (26) — v27 RETIRADA: dos parches sin verificar

> **Esta entrada documenta un fallo de método. La v27 NO debe usarse.**

### Qué pasó
Se generó `test_menu_v27.pce` atacando dos problemas a la vez:
1. Que al confirmar "CANTO DE JIZO" parpadee el rótulo entero (sólo parpadeaba "CANTO DE").
2. Que el botón II (tecla B) permita salir de la pantalla de contraseñas.

**El script petó antes de ejecutar ninguna verificación**:
```
FileNotFoundError: 'instrument/menu_fix/v27_load.png'
ls: cannot access 'Parches/momotaro_menu_v27.ips'
```
Faltaba el directorio `instrument/menu_fix/`. Se entregó una ROM que **nunca se vio
funcionar**: sin captura del selector, sin conteo del parpadeo y sin IPS.

### [DESCARTADO/ERROR] Parche del parpadeo: se cambiaron 3 cosas a la vez
```
C64A:  CLC ADC #$2C  →  SEC SBC #$08   ← MUEVE el rectángulo
C678:  CPX #$0C      →  CPX #$40       ← ancho
C689:  CPY #$05      →  CPY #$07       ← alto
```
Las dos últimas amplían, que era la intención. **La primera lo desplaza** −52 respecto
al original, y eso no formaba parte del objetivo.

Resultado medido por David: ahora parpadea **sólo "JIZO"**. El rectángulo no se
ensanchó, **se movió** hacia el final del texto.

El comentario del parche decía *"alinear a base de tile `$xx00` desde `$xx08`"*: eso
**asume** que el byte bajo siempre vale `$08`. No se midió.

→ Lo correcto: **revertir `C64A`** al original y probar sólo con `CPX`/`CPY`.

### [DESCARTADO/ERROR] Parche del botón II: destino supuesto, no medido
```
C992:  JMP $DC90
DC90:  PLA / PLA / JMP $C83D
```
El diario de v27 afirmaba *"`$C83D` (ruta cancel de password)"`*. **Era una suposición.**

Resultado medido por David: pulsar B **no vuelve al selector, entra al mapa**, justo
antes de la primera fase. `$C83D` no es la ruta de cancelar: es la de **contraseña
aceptada**.

Riesgo adicional no verificado: `PLA PLA` asume que en la pila sólo está la dirección
de retorno del `JSR`. Si la rutina guardó registros antes, quedan descuadrados.

→ Lo correcto: **trazar** qué ocurre al cancelar la pantalla de contraseñas por la vía
normal del juego y ver a qué dirección salta de verdad. No adivinarla.

### Normas reforzadas
1. **Un cambio por prueba.** Si se tocan tres cosas a la vez y falla, no se sabe cuál.
2. **Nunca entregar una ROM que el script no llegó a verificar.** Si la verificación
   peta, la entrega no existe.
3. **Crear los directorios de salida antes de escribir en ellos** (`os.makedirs(..., exist_ok=True)`).
4. **Un destino de salto se mide, no se deduce del contexto.**
5. **No meter scripts de 100+ líneas en una sola ejecución.** Pasos cortos: un cambio,
   una verificación, un resultado.

### Estado
La versión válida sigue siendo **v26**. La v27 queda descartada y documentada.

## TAREAS PENDIENTES (al cerrar esta sesión)

1. **Parpadeo de "CANTO DE JIZO"** — sólo parpadea parte del rótulo. Revertir `C64A`
   y probar únicamente ampliando `CPX`/`CPY`, midiendo antes el valor real del byte bajo.
2. **Botón II para salir de la pantalla de contraseñas** — trazar la ruta real de
   cancelación antes de parchear. No es un bug: es una mejora que el original no tiene.
3. **ゲロゲロモード** — decidir nombre definitivo; dejarlo oculto como en el original.
4. **Alias de contraseñas en castellano** conservando el significado japonés
   (`reports/password_aliases_pendiente.md`).
5. El grueso del juego (guion, diálogos de aldeanos, tiendas) **sigue sin traducir**.
