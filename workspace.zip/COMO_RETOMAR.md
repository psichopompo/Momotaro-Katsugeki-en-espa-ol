# Cómo retomar el proyecto Momotarou Katsugeki

Traducción al castellano de **Momotarou Katsugeki** (PC Engine, Hudson 1990).
Dirige **David** (*Psicopompo*, elotrolado.net). Repo:
`https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol`

---

## Lo primero que hay que leer

1. **`Momotaro/docs/PROMPT_METODO.md`** — el método. Es obligatorio.
2. **`Momotaro/LEEME.md`** — estado y las 99 normas ganadas fallando.
3. **`Momotaro/investigation.md`** — el diario, 103 entradas. Las hipótesis
   falsas **no se borran**: quedan como `[DESCARTADO]` con el motivo.
4. **`Momotaro/docs/ESTADO.md`** — resumen corto de en qué punto estamos.

---

## Reglas de trato (las pidió David)

- Responder **siempre en castellano**.
- Distinguir **[HECHO]** (medido, con evidencia) de **[HIPÓTESIS]**.
- Reconocer los errores propios **explícitamente**, diciendo qué falló en el
  razonamiento. Han sido muchos y han enseñado mucho.
- Si David dice algo que contradice el análisis, **comprobarlo antes de
  descartarlo**: sus intuiciones han resuelto varios bloqueos.
- **No reparticionar su texto sin avisar** (norma 38).
- Capturas individuales, no rejillas.
- David no es romhacker: dirige, edita gráficos y prueba en Beetle y Mesen.
  Sabe usar breakpoints con instrucciones exactas.
- Antes de pedirle un breakpoint, **intentar sacar el dato de la ROM** con
  las herramientas ya escritas (norma 98).
- Toda dirección de VRAM que se le pase **se recalcula y se verifica**
  decodificando el dato en el volcado (norma 97).

---

## Estado a día de hoy

### ROMs que se conservan

```
Momotarou Katsugeki (Japan).pce   ec7358edb3672a8aa8850623eec72a71   VIRGEN
momotaro_es_v109.pce              e618d5a111a9ad4326efdf1973b04bab   base histórica
test_horizontal_v157.pce          294f0c20ef190860391267c330007dad   ÚLTIMA VALIDADA
test_apaisado_v158.pce            1e6171dae2393006bfae8f842ae1cdfd   20x4, SIN PROBAR
```

Las demás (v144-v155, biseccións) están borradas: su historia está en el
diario. Parche: `parches/momotaro_apaisado_v158.ips` (round-trip verificado).

### Traducción

| bloque | estado | ¿cabe? |
|---|---|---|
| menú SELECT | hecho (v148) | sí |
| guion, 87 textos | hecho, en repaso con David | **no** (+3358 B) |
| mensajes de victoria, 35 | hecho | sí (1616/1621 B) |
| nombres de artes, 13 | hecho | sí, exacto (92/92) |
| vítores, dinero, final, quiz, casino | pendientes | — |

El texto vive en `docs/traduccion.py` **en prosa, sin cortar**; el reparto en
líneas lo hace `tools/maquetar.py`. Cambiar el ancho no obliga a retocar
ninguna frase.

### El bocadillo 20x4 (v158)

Todo medido y construido, **falta probarlo en pantalla**:

- geometría en `tools/geom_v158.py`, validada contra la tabla real de la v157;
- rutina de escritura inmediata en `tools/rutina_v158.py` (97 B en `$9B7C`),
  desensamblada y con las 80 celdas simuladas una a una;
- el búfer de RAM **desaparece**: no hacía falta buscar 80 bytes libres.

### El espacio del guion (sin resolver)

Faltan 3358 B. La vía elegida es liberar el quiz: el breakpoint de David
demostró que se lee con el puntero de página cero `$BF/$C0` y que **los 12
sitios que lo cargan están todos en el banco `$08`**, así que se puede mover
sin tocar el mapeo de bancos.

---

## Reconstruir desde cero

```bash
cd /home/user/Momotaro
python3 tools/build_v158.py        # genera test_apaisado_v158.pce
python3 tools/geom_v158.py         # valida la geometría
python3 tools/rutina_v158.py       # muestra la rutina ensamblada
python3 tools/maquetar.py          # reparto de líneas de los 87 textos
python3 docs/traduccion.py         # el guion maquetado
```

Todos los constructores llevan `assert` del byte esperado, del hueco libre y
de las zonas que no se pueden tocar. Si algo cambia, revientan.

---

## Lo siguiente

1. Que David pruebe la **v158** y diga qué se ve.
2. Terminar el repaso de la traducción (va por el texto 31).
3. Mover el quiz para meter el guion traducido.
4. Traducir vítores, dinero, final y casino.
5. Cargar el rabillo simétrico (está en ROM `0x5292`, 46 B comprimidos).
