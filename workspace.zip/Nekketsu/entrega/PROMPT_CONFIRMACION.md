# Prompt de confirmación tras el resumen de estado

> Envíaselo como respuesta a su resumen, antes de que empiece a investigar.

---

## PROMPT

Confirmo el resumen: refleja correctamente el estado del proyecto. Buen
trabajo de reconstrucción, y en particular dos cosas que quiero reconocer
porque son exactamente el método que busco:

- No inventaste el commit del core cuando no había evidencia para
  recuperarlo. Dijiste que no era recuperable y lo dejaste anotado así.
- Detectaste que la ROM y el IPS de v04 no venían en el ZIP y te
  detuviste en lugar de regenerarlos por tu cuenta.

Adelante con la investigación de la BRAM, con tres ajustes.

### 1. Arregla el runner antes de nada

Has detectado que el runner lleva una ruta absoluta antigua
(`/home/user/emutools/...`) que no existe en este entorno, y has optado por
pasarle el core explícitamente en cada ejecución. Prudente, pero eso va a
darte fricción en toda la sesión.

Arréglalo ya: convierte esa ruta en **relativa al workspace** o en un
parámetro con valor por defecto correcto. Anótalo en el diario como cambio
de instrumental, no de proyecto.

### 2. Captura primero la referencia, antes de tocar nada

Tu plan de cinco pasos está bien ordenado, pero le falta un paso cero.

**Antes de generar ninguna BRAM sintética ni aplicar ningún bypass**, carga
mi `.srm` real y captura el selector `CANTO DE JIZO / CARGAR` tal como se ve
ahora. Esa es tu referencia: cómo debe verse la pantalla con una partida
válida de verdad.

Sin esa referencia, si más adelante tu BRAM generada produce algo raro no
podrás distinguir si el fallo es del juego, de tu parche o de tu propia
BRAM. Con ella, siempre tendrás contra qué comparar.

Guarda esa captura identificada como referencia, e indica en el diario que
procede de una partida real, no inyectada.

### 3. Sobre el orden de trabajo

De acuerdo con tu plan: primero entender cómo el juego valida la BRAM,
después decidir si generas una válida o parcheas la comprobación. Y sí,
mantén separada y etiquetada cualquier evidencia que venga de estado
inyectado.

Recuerda el punto que más me importa: **una medición → una causa
identificada → un arreglo → una verificación.** Si al trazar el selector no
consigues demostrar la causa del texto mal construido, dímelo y lo
hablamos. No quiero otra tanda de pruebas `probe_1`, `probe_2`, `shift3`.

### 4. Un apunte sobre el diario

El diario ha funcionado: gracias a él hemos podido resucitar en una ventana
nueva un proyecto cuyo chat había muerto. Mantén ese nivel — evidencia
concreta, sumas de verificación, errores propios anotados con su norma
correspondiente — y actualízalo sobre la marcha, no solo al cerrar la
sesión.

Cuando tengas la captura de referencia y las primeras trazas de la
validación de BRAM, enséñamelas antes de proponer ningún parche.
