# Prompt de entrada — retomar Momotaro Katsugeki en un chat nuevo

> Sustituye `ENLACE_AL_ZIP` por la URL real del ZIP en GitHub.

---

## PROMPT

Proyecto Momotaro Katsugeki.

Hola, Arena. Me llamo David. Tú y yo hemos estado trabajando juntos en este
proyecto en otro chat, pero, debido al contexto acumulado, ha comenzado a ir
lento, y me he visto obligado a migrar a un nuevo chat. Te paso el enlace al
workspace del proyecto, subido a GitHub. Descárgalo, descomprímelo y sigue
las instrucciones de `ESTRUCTURA_WORKSPACE.md`.

ENLACE_AL_ZIP

Cuando termines de descomprimir, **borra el ZIP**: no quiero copias
duplicadas ocupando espacio.

---

### Dos cosas antes de que empieces a trabajar

**1. Corrige una entrada del diario.**

En `investigation.md`, la entrada del 2026-08-03 (23) sobre ゲロゲロモード
tiene una etiqueta mal puesta. Dice:

> [HIPÓTESIS descartada por análisis] "el bocadillo se ensanchará solo"

Eso es confuso: mezcla "descartada" con "razonada pero no medida". **Nadie ha
comprobado** qué hace el juego al desbloquear el cuarto modo. Reescríbela como
hipótesis abierta, dejando claro:

- Que es un **razonamiento**, no una medición: el bocadillo viene de un stream
  de tamaño fijo (`0x1E07A`), y no hay evidencia de que exista una rutina que
  lo dimensione según el contenido.
- Que hay una **pista en contra**: la tabla de punteros en `0x1F4AE` ya tiene
  **cuatro** entradas y el texto "MUY DIFÍCIL" ya está en ROM (`0x1FB2B`). Los
  autores no dejaron eso a medias, así que es posible que el original sí
  contemple la cuarta línea.
- **Cómo resolverla**: forzar temporalmente el cuarto modo como desbloqueado y
  mirar qué pinta el juego. Si el bocadillo crece solo, no hay nada que hacer;
  si no crece, ya sabremos cuánto hay que ampliarlo.

Añádelo también a las tareas pendientes. **No la resuelvas ahora**: primero
quiero cerrar las dos tareas del menú.

**2. Ponte al día y dame un resumen.**

Lee `investigation.md` completo (sobre todo las entradas 20–27) y
`uploads/PROMPT_METODO.md`. Después dime qué funciona, qué está roto y cuál
es el siguiente paso, para confirmar que hemos recuperado el hilo.

**No toques la ROM hasta que yo confirme el resumen.**

---

### Recordatorio de método

El punto que más me importa, porque es donde se torció la última sesión:

> **Una medición → una causa identificada → un arreglo → una verificación.**

En concreto, y esto viene de errores reales documentados en el diario:

- **Un cambio por prueba.** La v27 tocó tres bytes a la vez y no se supo cuál
  rompió qué.
- **Nunca entregues una ROM que el script no llegó a verificar.** La v27 petó
  antes de capturar nada y se entregó igualmente.
- **Crea los directorios de salida antes de escribir** (`os.makedirs(...,
  exist_ok=True)`). Ese fue literalmente el motivo del fallo anterior.
- **Un destino de salto se mide, no se deduce.** `$C83D` se dio por "ruta de
  cancelar" sin trazarla, y era la de contraseña aceptada.
- **Scripts cortos.** Nada de cien líneas en una sola ejecución: un cambio, una
  verificación, un resultado. Si algo falla, quiero saber exactamente dónde.

Partimos siempre de `Roms/Pruebas/test_diffsel_v26.pce`. **La v27 está
descartada.**
