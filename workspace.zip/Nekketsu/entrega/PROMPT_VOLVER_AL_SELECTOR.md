# Prompt: cerrar la fase BRAM y volver al selector

> Envíaselo como respuesta a su informe de v02.

---

## PROMPT

Buen trabajo con la BRAM. La reconstrucción de v01 —byte a byte idéntica,
con las mismas 2972 lecturas y la misma traza fila a fila— es exactamente
la verificación inversa que pedí, y ya te da la herramienta que
necesitábamos: puedes generar estados de partida válidos sin depender de mi
archivo.

**Pero ahí se acaba esta fase.**

### 1. Para la investigación del payload

El experimento v02 (`$0061`, la clave XOR de `$37F6`) está bien medido,
pero es un desvío: tú mismo concluyes que no hay evidencia de su
significado semántico ni de ningún efecto visual. Eso no nos acerca al
objetivo.

Anótalo en el diario como **línea abierta y aparcada**, con lo que ya sabes
(la copia `$0060-$007F` → `$17D7-$17F6` y el descifrado en `$D20B-$D217`),
y déjalo ahí. Lo retomaremos si algún día hace falta.

**No generes más variantes de BRAM.** v01 es la herramienta; con eso basta.

### 2. Volvemos al objetivo real

Quiero resultados visibles en el juego. Dos problemas, por orden:

**Problema A — el selector `CANTO DE JIZO / CARGAR`**

En `traduccion_v04_password_menu_safe_table_test` el texto sale así:

```
esperado           obtenido
CANTO DE JIZO      CANTO DTO DE
CARGAR             CARGAARGA   R
```

**Problema B — la pantalla de CARGAR**

El contenido se ve cortado y el bocadillo queda estrecho.

Empieza por A. Pero antes de tocar nada, **comprueba si A y B comparten
causa**: los dos son texto que se construye mal dentro de un marco, y sería
absurdo arreglarlos por separado si el origen es el mismo sistema de
chunks. Mídelo y dime qué encuentras.

### 3. Cómo quiero que lo ataques

Primero: la ROM v04 no estaba en el ZIP. Regenérala con
`tools/make_v04_password_menu_safe_table_test.py` para tener el fallo
delante.

Después, **mira el patrón del defecto**, que es muy revelador:

```
CANTO D + TO DE          el segundo trozo repite desde una posición anterior
CARGA   + ARGA   R       el segundo trozo repite desde una posición anterior
```

En ambos casos el texto no está truncado ni corrupto: está **solapado**. El
segundo chunk vuelve a emitir caracteres que el primero ya había escrito.
Eso apunta a que el avance del puntero de destino (o el cálculo del origen)
entre chunk y chunk no coincide con la longitud real emitida.

Así que la medición concreta que quiero es esta: **instrumenta el bucle que
emite los chunks** y regístrame, para cada uno:

- offset de origen en la lista
- celda de destino
- longitud emitida
- valor del contador o índice que usa para avanzar

Y hazlo **dos veces**: con la lista original japonesa, que funciona, y con
la lista relocalizada de v04, que falla. La comparación de esas dos tablas
debería enseñar el desajuste sin necesidad de suponer nada.

Tu hipótesis anterior —que se proyectan más chunks de los que la rutina
prepara, o que se reutilizan offsets de la lista original— es razonable y
esta medición la confirma o la descarta.

### 4. Recordatorio de método

Una medición → una causa identificada → un arreglo → una verificación.

Si al trazar el bucle no consigues demostrar la causa, **dímelo y lo
hablamos**. Prefiero eso a otra tanda de `probe_1`, `probe_2`, `shift3`.

Y cuando propongas el arreglo, explícame primero qué vas a cambiar y por
qué, antes de escribirlo en la ROM.

---

Enséñame las dos tablas de chunks —la original y la de v04— antes de
proponer ningún parche.
