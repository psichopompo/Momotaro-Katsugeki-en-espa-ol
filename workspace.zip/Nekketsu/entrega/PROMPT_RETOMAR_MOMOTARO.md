# Prompt para retomar el proyecto Momotarou Katsugeki en un chat nuevo

> Pégalo entero como primer mensaje.
> **Antes de enviarlo, sustituye `TU_USUARIO/TU_REPO` por la URL real.**

---

## PROMPT

Retomamos un proyecto que veníamos haciendo en otra ventana de chat. Aquella
sesión murió por un problema técnico (adjunté un archivo binario renombrado
como `.png` y a partir de ahí el servicio rechazó todos los mensajes), así
que empezamos aquí de cero en cuanto a contexto, pero **no en cuanto a
trabajo**: todo lo hecho está guardado.

### 1. Reconstruir el entorno

El proyecto está en un repositorio de GitHub. Clónalo en el workspace:

```
git clone https://github.com/TU_USUARIO/TU_REPO.git
```

(Si el nombre de la carpeta resultante es largo o incómodo, renómbrala a
algo corto y dímelo.)

Estructura que vas a encontrar:

```
emutools/
  beetle-pce-fast-libretro/     core del emulador que TÚ compilaste e
                                instrumentaste, con fuentes y el .so ya
                                construido (mednafen_pce_fast_libretro.so)

momotaro_katsugeki/
  investigation.md              EL DIARIO DE INVESTIGACIÓN
  ESTRUCTURA_WORKSPACE.md       descripción de carpetas (DESACTUALIZADO)
  reports/                      ~120 informes .md con el razonamiento
  tools/                        scripts de análisis y parcheo
    dis6280/                    desensamblador del HuC6280
  Roms/                         ROM original japonesa + última parcheada
  parches/                      último parche
  font_edit/  tile_assets/  Tablas/  translations/  instrumental/  work/
  references/                   algunas capturas de referencia

uploads/
  savestate/                    mi partida guardada (la que me pediste)
  PROMPT_METODO.md              el método de trabajo
  (varios documentos de apoyo)
```

Nada más clonar:

- `ESTRUCTURA_WORKSPACE.md` **está desactualizado**: he limpiado el
  workspace y ya no coincide. Actualízalo tú.
- Comprueba que el `.so` de `emutools/` carga en este sandbox. Si falla por
  incompatibilidad de bibliotecas, **recompílalo** desde las fuentes que
  están ahí mismo. Anota en el diario el commit del core y el comando de
  compilación exactos, que en la sesión anterior no quedaron registrados.
- Borré los volcados `reports/bank_XX_8000.asm` (ocupaban 14 MB). **Son
  regenerables**: el desensamblador está en `tools/dis6280/`. Regenéralos
  solo cuando los necesites.

### 2. Ponte en situación antes de tocar nada

1. Lee `investigation.md` completo.
2. Lee los informes clave de `reports/`, en especial
   `informe_inicial_momotaro_katsugeki.md`, `estado_traduccion_v03.md`,
   `password_investigacion_estado.md` y `prompt_superior_pruebas_fallidas.md`.
3. Verifica que el emulador funciona cargando la ROM parcheada.
4. **Dame un resumen del estado**: qué funciona, qué está roto y cuál era
   el siguiente paso.

No modifiques la ROM hasta que yo confirme que el resumen es correcto.

### 3. Dónde estamos de verdad

Quiero que tengas clara la escala, porque es fácil confundirse:

**El proyecto está en sus inicios.** De todo el juego, solo está traducido
el **menú principal**. El trabajo del menú de contraseñas ha consumido
muchísimo esfuerzo, pero es una pieza pequeña del conjunto: queda
prácticamente todo el juego por delante.

Estado concreto:

- Versión buena confirmada:
  `Roms/Momotarou Katsugeki (Japan) - traduccion_v03.pce`
- `traduccion_v04_password_menu_safe_table_test`: **no aceptada**. Dejó de
  corromper el título, pero el selector sigue construyendo mal el texto.
- Pendiente para más adelante: alias de contraseñas en castellano
  conservando el significado japonés original (anotado en
  `reports/password_aliases_pendiente.md`).

### 4. El método (esto es lo importante)

En `uploads/PROMPT_METODO.md` está el método completo. Léelo y aplícalo.
Hay un punto que subrayo porque es justo donde se torció el trabajo
anterior:

> **COMPRENDER ANTES QUE MODIFICAR.**
>
> Prohibido probar variantes hasta que una funcione. Prohibido escribir
> bytes a ciegas o mover offsets al azar. Antes de cualquier parche tienes
> que haber **demostrado la causa** con una medición: traza de ejecución,
> breakpoint, volcado de VRAM, lectura de memoria o comparación frame a
> frame contra la ROM original sin modificar.

En `reports/` hay más de **sesenta archivos** `test_password_*` con nombres
como `probe_1`, `probe_2`, `v2`, `v3`, `shift`, `shift2`, `shift3`,
`shift4`... Eso es prueba y error sobre el mismo menú, no investigación.
No quiero volver a eso.

La secuencia correcta es: **una medición → una causa identificada → un
arreglo → una verificación.** Si no puedes medir algo, dilo en lugar de
improvisar un parche.

Reglas concretas:

- Marca cada afirmación como **[HECHO]** (medido, con evidencia) o
  **[HIPÓTESIS]** (sin demostrar). No las mezcles.
- **Un contador a cero no prueba nada** si antes no has validado con una
  prueba de control que ese contador puede subir.
- Si un resultado viene de un **estado inyectado** (memoria forzada,
  savestate manipulado), dilo y no lo presentes como comportamiento
  observado del juego.
- Antes de dar por libre un espacio, **comprueba su contenido actual**.
- Antes de mover o agrandar algo, mira **qué hay inmediatamente detrás**.
- **Desensambla todo salto relativo** que escribas a mano antes de meterlo
  en la ROM.
- Prueba tú mismo cada versión en el emulador y examina **frame a frame**
  cuando busques un fallo intermitente.
- **Numera cada versión** que me entregues, con sus sumas de verificación.
  No sobrescribas el mismo archivo: si no, es imposible saber cuál pruebo.
- Capturas **individuales**, no rejillas: juntas son ilegibles.

### 5. Mantén el diario

`investigation.md` es el registro permanente y tiene prioridad sobre tu
memoria: cuando dudes, consúltalo.

- Cada anotación con evidencia: direcciones, offsets, volcados, trazas.
- **Las hipótesis falsas NO se borran.** Se anotan como [DESCARTADO] con el
  motivo por el que resultaron falsas.
- Anota también **tus propios errores** y su causa. Si repites uno,
  conviértelo en norma escrita.
- Orden cronológico, como una bitácora.
- **Actualízalo sobre la marcha**, no solo al final de la sesión.

### 6. El siguiente paso

Tu último mensaje en la sesión anterior decía:

> Para inspeccionar esa pantalla en ejecución necesito llegar al selector
> `CANTO DE JIZO / CARGAR`. Con BRAM limpia o inventada el juego entra
> directamente a la pantalla de canto de Jizo. He probado a rellenar
> SRAM/BRAM de forma artificial, pero no activa el selector: seguramente
> hay checksum o estructura válida de partida.

Planteabas cargar mi SRAM real, entrar al selector y registrar: SAT y
sprites activos, listas y metasprites usadas, patrones de VRAM con el
texto, escrituras a esos patrones y los PCs que los generan. Después
comparar el selector inicial con la pantalla de carga y con la de
dificultad, que ya funciona.

Mi savestate está en `uploads/savestate/`. Úsalo.

**Pero antes o en paralelo quiero que hagas otra cosa**, que es la que de
verdad resuelve el problema de fondo: **localiza la rutina que valida la
BRAM y trázala.** Si hay checksum, hay código que lo calcula. Encontrándolo
podrás generar tú mismo una BRAM válida, o parchear temporalmente la
comprobación para entrar al selector sin depender de mi archivo.

Eso te da una herramienta reutilizable para todo el resto del proyecto:
podrás alcanzar cualquier estado de partida que necesites sin pedirme nada.
En un proyecto anterior resolvimos así el acceso a escenas concretas
—forzando las variables de estado en RAM en vez de jugar hasta ellas— y fue
lo que desbloqueó el trabajo.

### 7. Cómo quiero que trabajemos

- Responde **siempre en español**.
- **Reconoce tus errores explícitamente.** Si me dices algo incorrecto,
  corrígelo señalando qué falló en tu razonamiento.
- Distingue con claridad lo **medido** de lo **supuesto**.
- Si te digo algo que contradice tu análisis, **compruébalo antes de
  descartarlo**. Conozco el juego jugándolo y mi intuición puede ahorrarte
  trabajo: en el proyecto anterior varios atascos se desbloquearon así.
- No des por cerrado un problema hasta que yo lo confirme probándolo.
- Sé conciso. Estilo de ingeniero explicando su trabajo, no de generador de
  parches.

---

Empieza por los puntos 1 y 2. No toques la ROM hasta que me hayas dado el
resumen de situación y yo te lo confirme.
