# Nekketsu Koukou Dodgeball Bu — Soccer Hen MD · Traducción al español

**Mega Drive / Genesis · Technos Japan · 1992 · Exclusivo de Japón**

Traducción completa al castellano de *Nekketsu Koukou Dodgeball Bu - Soccer
Hen MD*, el juego de fútbol que Technos publicó en 1992 protagonizado por
Kunio-kun. Salió únicamente en Japón, nunca tuvo localización oficial y
jamás se había traducido a ningún idioma occidental. Hasta donde sabemos,
esta es la primera versión jugable en un idioma distinto del japonés.

---

## Qué incluye

Se ha traducido **todo el texto visible**:

- Los **86 bloques de diálogo** de la historia, con la secuencia completa
  de 24 escenas
- Menús, opciones y pantalla de clave
- Los **trece nombres de equipo** de la pantalla de selección (DUELO 2J)
- La pantalla de alineación (cambio de posición, `RES` / `VEL` / `TIR`)
- Las presentaciones de los trece partidos
- El marcador de resultados
- Rótulos de escena: sala del club, vestuarios, títulos de partido
- Créditos finales

Se han **redibujado los gráficos** que contenían texto japonés: el rótulo
del título, la placa de selección de escuela y la cinta del club. Se creó
una **fuente gruesa de 20 letras** con contorno negro para los nombres de
equipo, y se injertaron en la fuente original las vocales acentuadas, la
`Ñ` y los signos `¿` `¡`. Los corazones de Misako se han restaurado tal
como aparecen en el original.

---

## Cómo aplicar el parche

Se incluyen dos formatos:

| Archivo | Recomendado |
|---|---|
| `Nekketsu_Soccer_MD_ES_v2_8.bps` | ✅ Verifica la ROM de origen |
| `Nekketsu_Soccer_MD_ES_v2_8.ips` | Alternativa |

Usa [Flips](https://www.romhacking.net/utilities/1040/), Lunar IPS o
cualquier parcheador compatible.

### ROM necesaria

La ROM japonesa original, **sin cabecera** y sin modificar:

| | |
|---|---|
| Tamaño | 524.288 bytes (512 KB) |
| CRC32 | `F49C3A86` |
| MD5 | `FF7A9A6FB74A640F40F10DFF53E9CF4D` |
| SHA-1 | `D865B01E58A269400DE369FC1FBB3B3E84E1ADD0` |

### ROM resultante

| | |
|---|---|
| Tamaño | 1.048.576 bytes (1 MB) |
| CRC32 | `8BA4F074` |
| MD5 | `30C69454512344419B622DB67D51E65B` |
| SHA-1 | `608739BF89A75915A5D90719D9E0BAC3D8AAA3F2` |

La ROM crece de 512 KB a 1 MB. Es normal: la traducción necesita espacio
para las fuentes nuevas, los gráficos redibujados y el código añadido.

> **No se distribuye la ROM.** Solo el parche. Consigue la tuya por tu
> cuenta.

---

## Compatibilidad

Probado en **Genesis Plus GX**. Debería funcionar en cualquier emulador
razonablemente preciso y en hardware real mediante flashcart (Mega
EverDrive y similares), ya que solo se han empleado técnicas estándar del
68000 y del VDP.

No se ha probado en hardware real. Si alguien lo hace, el informe sería
bienvenido.

---

## Limitaciones conocidas

- En la pantalla de alineación, la flecha del cursor SÍ/NO aparece un
  instante antes que la pregunta. Es puramente cosmético.
- **El juego no se ha probado de principio a fin.** Las zonas de difícil
  acceso (torneo completo, modo VS, claves válidas) han recibido menos
  pruebas. Si encuentras algún fallo, abre un *issue*.

---

## Sobre el proyecto

Conviene decirlo con claridad: **quien firma esto no es romhacker.** El
trabajo técnico —análisis del formato de compresión propietario,
desensamblado del 68000, localización de punteros, parches de código y
reubicación de assets— lo ha realizado una IA con la que se ha trabajado
codo con codo durante el desarrollo.

La aportación humana ha sido **dirigir el proyecto**: decidir qué se
traducía y cómo, probar cada versión, detectar los fallos y aportar
intuición cuando el análisis se atascaba. Alguna de esas intuiciones
resultó decisiva —por ejemplo, tratar los nombres de equipo como texto en
lugar de como gráficos, lo que redujo su coste de 146 a 35 *tiles* y
desbloqueó un callejón sin salida—. El pixel art (fuentes, rediseño de
sprites, rótulo del título) también es humano.

El proyecto completo llevó **entre dos y tres días de trabajo intenso**.
Un romhacker en solitario habría tardado meses. No se dice para restar
mérito a nadie, sino porque ilustra lo que la IA permite hacer hoy en este
campo.

Todo el proceso quedó documentado en un diario de investigación de más de
**8.800 líneas**, en el que las hipótesis descartadas no se borran: se
anotan con el motivo por el que resultaron falsas. Se escribieron unas
**60 herramientas** en Python para el análisis: descompresor y
recompresor del formato del juego, desensamblador 68000, editor de
fuentes, generador de parches y un arnés de emulación instrumentado sobre
Genesis Plus GX.

---

## Historial de versiones

| Versión | Cambios |
|---|---|
| **2.8** | Restaurada la presentación de partido en castellano a partir del segundo encuentro |
| 2.7 | Corregido el destello de caracteres japoneses en la pantalla de resultados |
| 2.6 | Corregido el volcado de fuente que escribía sobre el *nametable* |
| 2.5 | Anulado el texto antiguo de «¿CAMBIAR POSICIÓN?» |
| 2.3 | Nombres alineados a la izquierda; limpieza del rótulo japonés |
| 2.2 | Corregido un cuelgue en la escena del club; rótulo del título restaurado |
| 2.1 | Cinta verde sin parpadeo; marcos de selección adaptables |
| 2.0 | Nombres de las trece escuelas traducidos con fuente gruesa |
| 1.9 | Rótulo del título y placa «ELIGE ESCUELA» |
| 1.8 | Fuente románica restaurada; cinta verde reconstruida |
| 1.7 | Corazones de Misako; rótulo «CLUB DE DODGEBALL» |
| 1.6 | Secuencia completa de 24 diálogos restituida; ritmo acelerado |

---

## Aviso legal

Trabajo de aficionados sin ánimo de lucro. *Nekketsu Koukou Dodgeball-bu -
Soccer Hen MD* es propiedad de sus respectivos titulares. Esta traducción
no está autorizada ni respaldada por Technos Japan ni por sus sucesores.

Se distribuye **únicamente el parche**. No se incluye ni se enlaza la ROM.

Puedes redistribuirlo libremente siempre que se mantenga la atribución y
no se cobre por ello.
