"""nav.py - secuencias de navegacion reproducibles hasta la pantalla del bug."""
import sys
sys.path.insert(0,'/home/user/project/tools')

# Secuencia verificada: llega a la presentacion del PRIMER partido (estado 0x0c/0x5c)
# START en el titulo -> START en el menu (TORNEO 1J) -> presentacion
NAV_FIRST_MATCH = {430:['START'],435:[], 700:['START'],705:[], 780:['START'],785:[]}
FRAME_PRESENT = 960     # pantalla de presentacion ya dibujada y estable

def run_to_first_match(m, upto=FRAME_PRESENT, nav=None):
    nav = nav if nav is not None else NAV_FIRST_MATCH
    for f in range(upto):
        if f in nav:
            if nav[f]: m.press(*nav[f])
            else: m.release()
        m.run(1)
    return m
