"""font4.py - ESTUDIO: fuente de cuerpo 4 px (mas contundente que la de 3 px).

Objetivo: recuperar peso visual sin perder la ventaja de la arquitectura B.
Trazo de 1 px, altura 7. Ancho variable por letra, igual que placafont.py:
la 'I' sigue costando 1 px porque su forma no necesita mas.
"""

V = {
'A': [".##.",
      "#..#",
      "#..#",
      "####",
      "#..#",
      "#..#",
      "#..#"],
'C': [".###",
      "#...",
      "#...",
      "#...",
      "#...",
      "#...",
      ".###"],
'D': ["###.",
      "#..#",
      "#..#",
      "#..#",
      "#..#",
      "#..#",
      "###."],
'E': ["####",
      "#...",
      "#...",
      "###.",
      "#...",
      "#...",
      "####"],
'F': ["####",
      "#...",
      "#...",
      "###.",
      "#...",
      "#...",
      "#..."],
'I': ["#",
      "#",
      "#",
      "#",
      "#",
      "#",
      "#"],
'K': ["#..#",
      "#.#.",
      "##..",
      "##..",
      "#.#.",
      "#..#",
      "#..#"],
'L': ["#...",
      "#...",
      "#...",
      "#...",
      "#...",
      "#...",
      "####"],
'N': ["#..#",
      "##.#",
      "##.#",
      "#.##",
      "#.##",
      "#..#",
      "#..#"],
'O': [".##.",
      "#..#",
      "#..#",
      "#..#",
      "#..#",
      "#..#",
      ".##."],
'P': ["###.",
      "#..#",
      "#..#",
      "###.",
      "#...",
      "#...",
      "#..."],
'R': ["###.",
      "#..#",
      "#..#",
      "###.",
      "#.#.",
      "#..#",
      "#..#"],
'S': [".###",
      "#...",
      "#...",
      ".##.",
      "...#",
      "...#",
      "###."],
'T': ["####",
      ".#..",
      ".#..",
      ".#..",
      ".#..",
      ".#..",
      ".#.."],
'U': ["#..#",
      "#..#",
      "#..#",
      "#..#",
      "#..#",
      "#..#",
      ".##."],
}

KERN = 1

def word_width(w, kern=KERN):
    return sum(len(V[c][0]) for c in w) + kern*(len(w)-1)

def render(w, kern=KERN):
    W = word_width(w, kern)
    px = [[False]*W for _ in range(7)]
    x = 0
    for c in w:
        g = V[c]; n = len(g[0])
        for y in range(7):
            for dx in range(n):
                if g[y][dx] == '#':
                    px[y][x+dx] = True
        x += n + kern
    return px

if __name__ == '__main__':
    import sys
    sys.path.insert(0, '/home/user/project/tools')
    import placafont as P3
    print(f"{'palabra':8} {'3 px':>10} {'4 px':>10}   {'tiles 3':>8} {'tiles 4':>8}")
    for w in ('PASA','TIRA','CEDE','PLACA','FINTA','OK'):
        a = P3.word_width(w); b = word_width(w)
        print(f'{w:8} {a:>7} px {b:>7} px   {(a+7)//8:>8} {(b+7)//8:>8}')
    print()
    print('=== CRITERIO: PLACA PLACA en el panel ===')
    for lab, mod in (('3 px', P3), ('4 px', sys.modules['__main__'])):
        W = mod.word_width('PLACA')
        print(f'  cuerpo {lab}: PLACA = {W} px  ->  2xPLACA+1 = {2*W+1} px')
