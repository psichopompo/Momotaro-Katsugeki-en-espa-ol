"""hudtools.py - descompresor de assets (formato del juego) + utilidades de tiles.
Basado en hist/scripts/decompress.py (documentacion historica ya validada).
"""
from pathlib import Path

def decomp(rom, start, count=256):
    """Descomprime `count` tiles desde `start`. Devuelve (bytes, data_end, ctrl_end)."""
    data_p = start + 6
    ctrl_p = start + int.from_bytes(rom[start+4:start+6], 'little')
    out = []
    state = 0
    for _ in range(count):
        if state == 4:
            ctrl_p += 1; state = 0
        code = (rom[ctrl_p] >> (state*2)) & 3
        state += 1
        if code == 0:
            tile = bytearray(32)
        elif code == 1:
            tile = bytearray(rom[data_p:data_p+32]); data_p += 32
        else:
            mask = int.from_bytes(rom[data_p:data_p+4], 'little'); data_p += 4
            tile = bytearray(32)
            for j in range(32):
                if (mask >> j) & 1:
                    tile[j] = rom[data_p]; data_p += 1
            if code == 3:
                for base in (0, 16):
                    for k in range(7):
                        j = base + k*2
                        tile[j+2] ^= tile[j]
                        tile[j+3] ^= tile[j+1]
        out.append(bytes(tile))
    return b''.join(out), data_p, ctrl_p

def tile_rows(tile32):
    """8 filas de 8 indices de color."""
    rows = []
    for y in range(8):
        r = []
        for xb in range(4):
            b = tile32[y*4+xb]
            r.append((b >> 4) & 0xF); r.append(b & 0xF)
        rows.append(r)
    return rows

def is_blank(tile32):
    return not any(tile32)

def ascii_art(tile32, on='#', off='.'):
    return '\n'.join(''.join(on if v else off for v in r) for r in tile_rows(tile32))

def render_sheet(data, path, cols=16, scale=3, labels=True, hi=None):
    from PIL import Image, ImageDraw
    n = len(data)//32
    cell = 8*scale
    lab = 11 if labels else 0
    rows = (n+cols-1)//cols
    im = Image.new('RGB', (cols*cell, rows*(cell+lab)), (18,18,24))
    d = ImageDraw.Draw(im)
    hi = hi or set()
    for i in range(n):
        t = data[i*32:(i+1)*32]
        x = (i % cols)*cell; y = (i//cols)*(cell+lab)
        if labels:
            col = (255,80,80) if i in hi else (200,200,0)
            d.text((x+1, y), f'{i:02X}', fill=col)
        for yy, r in enumerate(tile_rows(t)):
            for xx, v in enumerate(r):
                if v:
                    c = (255,255,255) if v > 7 else (150,150,160)
                    d.rectangle([x+xx*scale, y+lab+yy*scale,
                                 x+xx*scale+scale-1, y+lab+yy*scale+scale-1], fill=c)
    im.save(path)
    return path
