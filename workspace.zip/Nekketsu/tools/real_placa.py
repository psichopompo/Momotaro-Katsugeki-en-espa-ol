"""real_placa.py - PRUEBA REAL en el emulador de la fuente ultracondensada.

Estudio, no implementacion: parchea solo la copia en RAM del cartucho.
NO se genera ninguna ROM.
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
import hud_v14 as H
from hudtools import decomp
from placafont import V, word_width, KERN, render

ROM = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_1.md'
BG, INK = 9, 15
N_CELLS = 7
BASE    = 256                  # -> VRAM 0x540..0x546 (dentro del hueco libre)
N_TILES = 269                  # igualar DMA de la v1.1 (si no, diverge la partida)
X_LEFT, X_RIGHT = 4, 21

def phrase_tiles(words, gap, ncells=N_CELLS):
    W = ncells*8
    px = [[BG]*W for _ in range(8)]
    x = 0
    for wi,word in enumerate(words):
        if wi: x += gap
        g = render(word)
        for y in range(7):
            for dx in range(len(g[0])):
                if g[y][dx] and x+dx < W:
                    px[y][x+dx] = INK
        x += word_width(word)
    out=[]
    for c in range(ncells):
        t=bytearray()
        for y in range(8):
            for xb in range(4):
                X=c*8+xb*2
                t.append((px[y][X]<<4)|px[y][X+1])
        out.append(bytes(t))
    return out, x-1

def poke_bytes(m, off, b):
    for k in range(0,len(b)-len(b)%2,2):
        m.poke16(off+k,(b[k]<<8)|b[k+1])

def _geom(m,d6,x,cols,tbl):
    b=H.COORD+d6*16
    m.poke16(b+0,x); m.poke16(b+2,x); m.poke16(b+4,cols-1); m.poke16(b+6,0x19)
    m.poke16(b+8,tbl>>16); m.poke16(b+10,tbl&0xFFFF); m.poke16(b+12,1)

def _fill(m,tbl,cols,words):
    ent=cols*2*2; base=tbl+32
    for cid in range(8):
        e=base+cid*ent
        m.poke16(tbl+cid*4,e>>16); m.poke16(tbl+cid*4+2,e&0xFFFF)
        for k,w in enumerate([H.SP]*cols + (words or [H.SP]*cols)):
            m.poke16(e+k*2,w)

def apply(m, gap=18):
    data,_,_ = decomp(m.rom, H.ASSET_OLD, 256)
    big = bytearray(data)
    tiles, ink = phrase_tiles(['PLACA','PLACA'], gap)
    for t in tiles: big += t
    while len(big)//32 < N_TILES: big += bytes([BG*17])*32
    blob = H.compress(bytes(big), header=m.rom[H.ASSET_OLD:H.ASSET_OLD+4])[0]
    poke_bytes(m, H.ASSET_NEW, blob)
    for pd in H.D1_PTRS: m.poke16(pd+2, N_TILES)
    ph=[0x8440+BASE+i for i in range(N_CELLS)]
    _geom(m,3,X_LEFT ,N_CELLS,H.TBL_S0); _fill(m,H.TBL_S0,N_CELLS,ph)
    _geom(m,1,X_RIGHT,N_CELLS,H.TBL_S2); _fill(m,H.TBL_S2,N_CELLS,ph)
    _geom(m,2,X_LEFT ,1,H.TBL_S1); _fill(m,H.TBL_S1,1,[ph[0]])
    _geom(m,0,X_RIGHT,1,H.TBL_S3); _fill(m,H.TBL_S3,1,[ph[0]])
    return ink
