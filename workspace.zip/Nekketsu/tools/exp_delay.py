"""exp_delay.py - mide el reparto tecleo/lectura segun CHAR_DELAY."""
import sys, pickle
sys.path.insert(0,'/home/user/project/tools')
from md import MD
import dlgtext as D

ROM='/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_5.md'
rom=open(ROM,'rb').read()

def txt(i):
    p=int.from_bytes(rom[0x80020+i*4:0x80024+i*4],'big')
    if p==0xFFFFFFFF or p>=len(rom): return '?'
    c,f,l,n=D.read_block(rom,p)
    return (' | '.join(x.strip() for x in l if x.strip())) or '(vacio)'

def sample(delay, frames=8600):
    m=MD(ROM)
    if delay is not None:
        assert m.peek16(0x0058B2)==0x0012, 'estructura inesperada'
        m.poke16(0x0058B0, delay)
    S=[];prev=None
    for f in range(frames):
        m.run(1)
        st=(m.w16(0xf940),m.w16(0xf94c),m.w16(0xf94e),m.w16(0xf950))
        if st!=prev: S.append((f,)+st); prev=st
    del m
    return S

def slots(S, lo=1700, hi=8600):
    ev=[r for r in S if lo<=r[0]<hi]
    out=[];i=0
    while i<len(ev):
        f,flag,busy,modo,blq=ev[i]
        if blq==41 and flag==0xffff:
            e0=f;t0=t1=None;b=None;j=i+1
            while j<len(ev):
                f2,fl2,bu2,mo2,bq2=ev[j]
                if bq2==41 and fl2==0xffff: break
                if bq2!=41 and fl2==0xffff and t0 is None: t0=f2;b=bq2
                if bq2!=41 and fl2==0 and t0 is not None and t1 is None: t1=f2
                j+=1
            nx=ev[j][0] if j<len(ev) else None
            if t0 and t1 and nx: out.append((b,e0,t0,t1,nx))
            i=j
        else: i+=1
    return out

if __name__=='__main__':
    res={}
    for d in (None,1,0):
        S=sample(d)
        res[d]=slots(S)
        tag='orig(2)' if d is None else str(d)
        print(f"\n=== CHAR_DELAY={tag}  -> {len(res[d])} dialogos")
        print(f"{'blq':>4} {'slot':>5} {'borra':>6} {'teclea':>7} {'VISIBLE':>8} {'seg':>5}  texto")
        for b,e0,t0,t1,nx in res[d]:
            print(f"{b:4d} {nx-e0:5d} {t0-e0:6d} {t1-t0:7d} {nx-t1:8d} {(nx-t1)/60:5.2f}  {txt(b)[:42]}")
    pickle.dump(res,open('/home/user/project/work/exp_delay.pkl','wb'))
    print("\n=== resumen (segundos visibles)")
    ids=[b for b,*_ in res[None]]
    print(f"{'blq':>4} {'orig':>6} {'d=1':>6} {'d=0':>6}  texto")
    for b in ids:
        row=[]
        for d in (None,1,0):
            v=[nx-t1 for bb,e0,t0,t1,nx in res[d] if bb==b]
            row.append(f"{v[0]/60:6.2f}" if v else "  ----")
        print(f"{b:4d} {row[0]} {row[1]} {row[2]}  {txt(b)[:40]}")
