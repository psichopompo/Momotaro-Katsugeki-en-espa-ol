"""newletters.py - glifos nuevos para el HUD, en el estilo de 0x286AA.
Convencion: '#'=color 15 (trazo), '+'=color 14 (antialias), '.'=color 0 (fondo).
Metrica copiada de las letras existentes (P A U S E O K): stem '+##+'.
"""
GLYPHS = {
'C': ["+#####+.",
      "+##++##+",
      "+##+....",
      "+##+....",
      "+##+....",
      "+##++##+",
      "+#####+.",
      ".+++++..'".replace("'","")],
'D': ["+#####+.",
      "+##++##+",
      "+##+.+##",
      "+##+.+##",
      "+##+.+##",
      "+##++##+",
      "+#####+.",
      ".+++++.."],
'F': ["+#######",
      "+##+++++",
      "+##+....",
      "+#####+.",
      "+##++...",
      "+##+....",
      "+##+....",
      ".++....."],
'I': [".+####+.",
      ".++##++.",
      "..+##+..",
      "..+##+..",
      "..+##+..",
      ".++##++.",
      ".+####+.",
      "..++++.."],
'L': ["+##+....",
      "+##+....",
      "+##+....",
      "+##+....",
      "+##+....",
      "+##++++.",
      "+#######",
      ".++++++."],
'N': ["+##+.+##",
      "+###.+##",
      "+####+##",
      "+##+#+##",
      "+##++###",
      "+##+.###",
      "+##+.+##",
      ".++...++"],
'R': ["+######+",
      "+##+++##",
      "+##+.+##",
      "+##+++##",
      "+#####+.",
      "+##+##+.",
      "+##++##+",
      ".++..+++"],
'T': ["########",
      "+++##+++",
      "..+##+..",
      "..+##+..",
      "..+##+..",
      "..+##+..",
      "..+##+..",
      "...++..."],
}
COL = {'#': 15, '+': 14, '.': 0}

def encode(rows):
    """8 filas de 8 chars -> 32 bytes (4bpp planar Mega Drive)."""
    assert len(rows) == 8, rows
    out = bytearray()
    for r in rows:
        assert len(r) == 8, (r, len(r))
        for xb in range(4):
            hi = COL[r[xb*2]]; lo = COL[r[xb*2+1]]
            out.append((hi << 4) | lo)
    return bytes(out)

# asignacion letra -> indice de tile libre (confirmados vacios)
SLOTS = {'C':0x00, 'D':0x7A, 'F':0x89, 'I':0x98,
         'L':0xA1, 'N':0xDE, 'R':0xE2, 'T':0xE3}
RESERVED = [0xFC, 0xFD, 0xFE, 0xFF]

def build():
    return {ch: encode(GLYPHS[ch]) for ch in GLYPHS}
