"""shot_font.py - captura comparativa REAL en el juego: v1.1 vs tipografia condensada.

No escribe ninguna ROM. Parchea solo la memoria del emulador (poke16 sobre la
copia en RAM del cartucho), antes de que el juego cargue el asset del HUD.
"""
import sys, random
sys.path.insert(0,'/home/user/project/tools')
from md import MD
import hud_v14 as H
import hudfont as F

ROM = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_1.md'

# --- tipografia condensada con margen OPACO (indice 9) ---
# El margen transparente (indice 0) mostraria el cesped: es el bug del fondo
# verde ya demostrado. Indice 9 = mismo color que el fondo del panel.
def cond_tile(ch):
    out = bytearray()
    for r in F.GLYPHS[ch]:
        for xb in range(4):
            a = r[xb*2]; b = r[xb*2+1]
            hi = 15 if a=='#' else 9
            lo = 15 if b=='#' else 9
            out.append((hi<<4)|lo)
    return bytes(out)

def build_cond_asset(rom):
    from hudtools import decomp
    data,_,_ = decomp(rom, H.ASSET_OLD, 256)
    big = bytearray(data)
    for ch in H.NEW8: big += cond_tile(ch)
    for ch in H.DUP5: big += cond_tile(ch)
    assert len(big)//32 == H.N_TILES
    return bytes(big)

def poke_bytes(m, off, b):
    for k in range(0, len(b)-len(b)%2, 2):
        m.poke16(off+k, (b[k]<<8)|b[k+1])
    if len(b)%2:
        last = off+len(b)-1
        cur = m.peek16(last & ~1)
        if last & 1: m.poke16(last & ~1, (cur & 0xFF00)|b[-1])
        else:        m.poke16(last & ~1, (b[-1]<<8)|(cur & 0xFF))

def apply_cond(m):
    big = build_cond_asset(m.rom)
    blob = H.compress(big, header=m.rom[H.ASSET_OLD:H.ASSET_OLD+4])[0]
    poke_bytes(m, H.ASSET_NEW, blob)
    return len(blob)

# ---------------------------------------------------------------------------
# variante 2: condensada COMPLETA (incluye O y K, que en v1.1 son los tiles
# originales gruesos 0x15/0x16). Añade 2 tiles -> 271. El hueco 0x540-0x54F
# tiene 16 tiles; 13 en uso -> caben.
# ---------------------------------------------------------------------------
N_TILES_2 = 271
IDX_O2, IDX_K2 = 269, 270     # -> VRAM 0x54D, 0x54E

def build_cond_asset_full(rom):
    from hudtools import decomp
    data,_,_ = decomp(rom, H.ASSET_OLD, 256)
    big = bytearray(data)
    for ch in H.NEW8: big += cond_tile(ch)   # 256..263  C D F I L N R T
    for ch in H.DUP5: big += cond_tile(ch)   # 264..268  P A U S E
    big += cond_tile('O')                    # 269
    big += cond_tile('K')                    # 270
    assert len(big)//32 == N_TILES_2
    return bytes(big)

def apply_cond_full(m):
    big  = build_cond_asset_full(m.rom)
    blob = H.compress(big, header=m.rom[H.ASSET_OLD:H.ASSET_OLD+4])[0]
    poke_bytes(m, H.ASSET_NEW, blob)
    for pd in H.D1_PTRS:                      # d1 = numero de tiles a cargar
        m.poke16(pd+2, N_TILES_2)
    # reescribir la entrada del comando 6 ('OK') en las 4 tablas por slot
    NEW = {'O': 0x8440+IDX_O2, 'K': 0x8440+IDX_K2}
    for tbl, cols in ((H.TBL_S0,5),(H.TBL_S1,2),(H.TBL_S2,5),(H.TBL_S3,2)):
        ent = cols*2*2; base = tbl+32
        e = base + 6*ent
        words = [H.SP]*cols + [ (NEW[c] if c in NEW else H.W(c)) for c in 'OK'[:cols].ljust(cols) ]
        for k,w in enumerate(words):
            m.poke16(e+k*2, w)
    return len(blob)
