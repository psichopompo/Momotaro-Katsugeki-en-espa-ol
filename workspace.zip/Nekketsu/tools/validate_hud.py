"""validate_hud.py - aplica el parche HUD SOLO en memoria y valida los 5 comandos."""
import sys, hashlib
sys.path.insert(0,'/home/user/project/tools')
from md import MD
from nav import NAV_FIRST_MATCH
from patch_hud import plan_rom_writes, COMMANDS, TABLE, ENTRY, IDX, SP
from newletters import build, SLOTS

ROM='rom/Nekketsu_Soccer_MD_ES_v0_9_9.md'
VRAM_BASE=0x440          # el asset HUD se carga aqui
PANEL_L, PANEL_R = 2, 10 # interior util del panel (11 = borde)

def apply_in_memory(m, rom):
    # 1) glifos nuevos -> directamente en VRAM (el asset esta comprimido en ROM;
    #    para VALIDAR basta inyectar los tiles ya descomprimidos)
    g = build()
    for ch, idx in SLOTS.items():
        t = VRAM_BASE + idx
        for k in range(16):
            wv = int.from_bytes(g[ch][k*2:k*2+2],'big')
            m.poke_vram16(t*32 + k*2, wv)
    # 2) resto: escrituras en la ROM en RAM
    for off, b, why in plan_rom_writes(rom):
        for k in range(0, len(b), 2):
            m.poke16(off+k, int.from_bytes(b[k:k+2],'big'))

def wbe(v,r,c):
    o=0xc000+r*0x80+c*2
    return (v[o^1]<<8)|v[(o+1)^1]

def read_row(v, r, lo=0, hi=16):
    return [(c, wbe(v,r,c)&0x7ff) for c in range(lo,hi)]

REV = {0x440+i: ch for ch,i in IDX.items()}
def decode(v, r):
    out=''
    for c in range(PANEL_L, PANEL_R+1):
        t = wbe(v,r,c)&0x7ff
        out += REV.get(t, ' ' if t==0x485 else '?')
    return out
