"""bateria4.py - BATERIA COMPLETA de validacion del HUD cuerpo 4 px.

Compara la v1.1 (referencia) contra la v1.1 + parche cuerpo-4px aplicado SOLO
en memoria del emulador. NO se genera ninguna ROM.

Criterios de aceptacion del usuario:
  1. Ningun artefacto grafico
  2. Ninguna corrupcion de VRAM
  3. Ninguna letra fantasma
  4. Ningun borde roto
  5. Ningun sprite afectado
  6. Ningun retrato afectado
  7. PAUSA perfecto
  8. Comandos perfectamente legibles
"""
import sys, random, hashlib
sys.path.insert(0, '/home/user/project/tools')
from md import MD
import try4, font4
import shot_run as R

ROM = try4.ROM
SEED = 7

# ---- geometria conocida y verificada ----
BORDES = {1: 0x471, 11: 0x472, 20: 0x472, 30: 0x473}
PANEL_COLS = list(range(4, 11)) + list(range(21, 28))
RETRATOS = {(23, 5), (23, 6), (23, 9), (23, 10),
            (24, 5), (24, 6), (24, 9), (24, 10),
            (23, 21), (23, 22), (23, 25), (23, 26),
            (24, 21), (24, 22), (24, 25), (24, 26)}
# tiles del catalogo cuerpo 4px: 0x540..0x54F
CAT_LO, CAT_HI = 0x540, 0x54F


def wbe(v, r, c):
    o = 0xc000 + r * 0x80 + c * 2
    return (v[o ^ 1] << 8) | v[(o + 1) ^ 1]


ROM_V12 = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_2.md'
USE_ROM = False        # True -> valida el FICHERO v1.2 en vez del parche


def boot(patch, upto=1700):
    if USE_ROM:
        m = MD(ROM_V12 if patch else ROM)
    else:
        m = MD(ROM)
        if patch:
            try4.apply(m, font4, align_l=0, sec_w=3, force=None)
    R.boot(m, upto)
    return m


def play(m, n, seed=SEED, start=0):
    rnd = random.Random(seed)
    for i in range(start, start + n):
        if i % 5 == 0:
            m.press(rnd.choice(['A', 'B', 'C']),
                    rnd.choice(['RIGHT', 'LEFT', 'UP', 'DOWN']))
        elif i % 5 == 2:
            m.release()
        m.run(1)


def png_diff(a, b, box):
    from PIL import Image, ImageChops
    ia = Image.open(a).convert('RGB').crop(box)
    ib = Image.open(b).convert('RGB').crop(box)
    return sum(1 for p in ImageChops.difference(ia, ib).get_flattened_data()
               if p != (0, 0, 0))


# =====================================================================
# T1 - BORDES Y RETRATOS: barrido largo
# =====================================================================
def _capture_tilemap(patch, nframes, cells):
    """Recorre nframes y devuelve {frame: {(r,c): tile}} para las celdas dadas.

    IMPORTANTE: una sola instancia MD viva a la vez. El core de GPGX es una
    libreria compartida con estado GLOBAL: dos instancias simultaneas se pisan
    (verificado: lib._handle identico -> VRAM identica entre ref y parche).
    """
    m = boot(patch)
    rnd = random.Random(SEED)
    out = {}
    for i in range(nframes):
        if i % 5 == 0:
            m.press(rnd.choice(['A','B','C']), rnd.choice(['RIGHT','LEFT','UP','DOWN']))
        elif i % 5 == 2:
            m.release()
        m.run(1)
        if i % 3: continue
        v = m.vram()
        out[m.frame] = {(r, c): wbe(v, r, c) for (r, c) in cells}
    del m
    return out


def t1_bordes_retratos(nframes=3000):
    cells = set(RETRATOS) | {(26, c) for c in BORDES}
    ref = _capture_tilemap(False, nframes, cells)
    cur = _capture_tilemap(True,  nframes, cells)
    bad_borde = []; bad_retrato = []
    for f in sorted(set(ref) & set(cur)):
        for c, t in BORDES.items():
            if cur[f][(26, c)] & 0x7FF != t:
                bad_borde.append((f, c, cur[f][(26, c)] & 0x7FF))
        for rc in RETRATOS:
            if cur[f][rc] != ref[f][rc]:
                bad_retrato.append((f, rc))
    return {'frames': nframes, 'comparados': len(set(ref) & set(cur)),
            'bordes_rotos': bad_borde[:10], 'n_bordes': len(bad_borde),
            'retratos_alterados': bad_retrato[:10], 'n_retratos': len(bad_retrato)}


# =====================================================================
# T2 - LETRAS FANTASMA: ningun tile del catalogo fuera de su zona
# =====================================================================
def t2_fantasmas(nframes=6000):
    m = boot(True)
    ghosts = []
    rnd = random.Random(SEED)
    for i in range(nframes):
        if i % 5 == 0:
            m.press(rnd.choice(['A','B','C']), rnd.choice(['RIGHT','LEFT','UP','DOWN']))
        elif i % 5 == 2:
            m.release()
        m.run(1)
        if i % 3: continue
        v = m.vram()
        for r in range(28):
            for c in range(32):
                t = wbe(v, r, c) & 0x7FF
                if CAT_LO <= t <= CAT_HI:
                    if r != 26 or c not in PANEL_COLS:
                        ghosts.append((m.frame, r, c, t))
    return {'frames': nframes, 'n_fantasmas': len(ghosts), 'ejemplos': ghosts[:10]}


# =====================================================================
# T3 - PAUSA pixel a pixel
# =====================================================================
def t3_pausa():
    import os
    os.makedirs('/home/user/project/work/shots/bat', exist_ok=True)
    out = {}
    for tag, patch in (('ref', False), ('c4', True)):
        m = boot(patch)
        play(m, 400)
        m.press('START'); m.run(3); m.release()
        for _ in range(30): m.run(1)
        p = f'/home/user/project/work/shots/bat/pausa_{tag}.png'
        m.save_png(p); out[tag] = p
    n = png_diff(out['ref'], out['c4'], (0, 0, 256, 224))
    return {'px_distintos': n, 'ref': out['ref'], 'c4': out['c4']}


# =====================================================================
# T4 - PRESENTACION / KATAKANA / CRAM / regresion global de VRAM
# =====================================================================
def t4_presentacion():
    import os
    os.makedirs('/home/user/project/work/shots/bat', exist_ok=True)
    res = {}
    snaps = {}
    for tag, patch in (('ref', False), ('c4', True)):
        if USE_ROM:
            m = MD(ROM_V12 if patch else ROM)
        else:
            m = MD(ROM)
            if patch:
                try4.apply(m, font4, align_l=0, sec_w=3, force=None)
        # presentacion del primer partido
        R.boot(m, 960)
        p = f'/home/user/project/work/shots/bat/present_{tag}.png'
        m.save_png(p)
        snaps[tag] = {'png': p, 'cram': m.cram(), 'vram': m.vram()}
        del m          # una sola instancia viva: el core tiene estado global
    res['present_px'] = png_diff(snaps['ref']['png'], snaps['c4']['png'],
                                 (0, 0, 256, 224))
    res['cram_igual'] = snaps['ref']['cram'] == snaps['c4']['cram']
    # regresion global: que tiles de VRAM difieren
    a, b = snaps['ref']['vram'], snaps['c4']['vram']
    diff = [t for t in range(NON_TILE_LO)
            if a[t*32:(t+1)*32] != b[t*32:(t+1)*32]]
    res['tiles_distintos'] = diff
    res['n_tiles_distintos'] = len(diff)
    return res


def _vram_after(patch, n=800):
    m = boot(patch); play(m, n)
    v = m.vram(); del m
    return v


# Zonas de VRAM que NO son patrones graficos (leidas de los registros VDP):
#   plano A 0xC000-0xDFFF, window 0xD000, plano B 0xE000-0xFFFF, SAT 0xDE00
# En indices de tile (32 B): 0xC000/32 = 0x600 en adelante.
NON_TILE_LO = 0x600


def t5_partido_vram():
    """Regresion de VRAM durante el partido: solo deben cambiar 0x540-0x54F.

    Se excluyen los indices >= 0x600: esa zona es TILEMAP (plano A/B, window)
    y SAT, no patrones. Cambia legitimamente porque el HUD escribe otra fila 26.
    Verificado: el unico 'tile' que aparecia fuera era 0x668 = 0xCD00, que es
    exactamente la fila 26 del plano A (0xC000 + 26*128).
    """
    a = _vram_after(False); b = _vram_after(True)
    diff = [t for t in range(NON_TILE_LO)
            if a[t*32:(t+1)*32] != b[t*32:(t+1)*32]]
    fuera = [t for t in diff if not (CAT_LO <= t <= CAT_HI)]
    return {'tiles_distintos': diff, 'fuera_del_catalogo': fuera}


def t6_sprites():
    """La SAT no debe cambiar."""
    a = _vram_after(False, 600); b = _vram_after(True, 600)
    sa = a[0xDE00:0xDE00+80*8]; sb = b[0xDE00:0xDE00+80*8]
    return {'sat_igual': sa == sb,
            'bytes_distintos': sum(1 for x, y in zip(sa, sb) if x != y)}
