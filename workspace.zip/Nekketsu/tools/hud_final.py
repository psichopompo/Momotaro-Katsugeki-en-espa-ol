"""hud_final.py - configuracion EXACTA ya validada en §8.5. Sin experimentos.

Genera la lista completa de escrituras (offset, bytes, motivo).
La usan identicamente el validador en memoria y el generador de ROM.
"""
import sys
sys.path.insert(0, '/home/user/project/tools')
from hudtools import decomp
from newletters import build, SLOTS

_src = open('/home/user/project/hist/scripts/recompress.py').read().split("if __name__")[0]
_ns = {}; exec(_src, _ns)
compress = _ns['compress']

# ---- constantes verificadas ----
ASSET_OLD   = 0x0286AA
ASSET_NEW   = 0x094000                 # zona libre (todo 0xFF), 6278 B necesarios
ASSET_PTRS  = [0x0020D0, 0x005102]     # operandos de los 2 lea.l
VRAM_BASE   = 0x440                    # el asset se carga aqui

TABLE       = 0x08A700                 # tabla de comandos reubicada
PTR_TABLE   = 0x00A5C4                 # 8 punteros long
COLS, ROWS  = 5, 2
ENTRY       = COLS * ROWS * 2          # 20 bytes por entrada

OFF_D2_INF  = 0x00A572                 # ancho fila inferior: #$2 -> #$4   (CODIGO, 2 B)
VAL_D2_INF  = 0x0004

X_CMD_OFF   = 0x00A5A2 + 2             # X_inf del slot del comando (d6=3) : 5 -> 4
X_CMD_VAL   = 4
X_OK_OFF    = 0x00A59E + 2             # X_inf del slot del OK      (d6=2) : 8 -> 10
X_OK_VAL    = 10

SP = 0x8485
def T(i): return 0x8440 + i

EX  = {'P':0x10,'A':0x11,'U':0x12,'S':0x13,'E':0x14,'O':0x15,'K':0x16}
IDX = dict(EX); IDX.update(SLOTS)
def W(ch): return SP if ch == ' ' else T(IDX[ch])

# ID de comando (indice en la tabla de 8 punteros) -> texto
COMMANDS = {0:'', 1:'PASA', 2:'FINTA', 3:'TIRA', 4:'PLACA', 5:'CEDE', 6:'OK', 7:''}

def build_writes(rom):
    w = []
    # 1) asset con las 8 letras nuevas, recomprimido, en su nueva direccion
    data,_,_ = decomp(rom, ASSET_OLD, 256)
    mod = bytearray(data)
    for ch, idx in build_slots().items():
        mod[idx*32:(idx+1)*32] = build()[ch]
    blob,_ = compress(bytes(mod), header=rom[ASSET_OLD:ASSET_OLD+4])
    w.append((ASSET_NEW, blob, f'asset HUD + 8 letras ({len(blob)} B)'))
    # 2) repuntar los 2 cargadores
    for pa in ASSET_PTRS:
        w.append((pa, ASSET_NEW.to_bytes(4,'big'), f'cargador -> {ASSET_NEW:06X}'))
    # 3) tabla de comandos (8 entradas x 20 B): fila sup vacia, texto en la inferior
    for cid in range(8):
        txt = COMMANDS.get(cid, '')
        top = [SP]*COLS
        bot = [W(c) for c in txt[:COLS].ljust(COLS)]
        base = TABLE + cid*ENTRY
        for k, ww in enumerate(top+bot):
            w.append((base + k*2, ww.to_bytes(2,'big'), f'cmd[{cid}]"{txt}" w{k}'))
    # 4) repuntar los 8 punteros
    for cid in range(8):
        w.append((PTR_TABLE + cid*4, (TABLE + cid*ENTRY).to_bytes(4,'big'),
                  f'ptr[{cid}] -> {TABLE+cid*ENTRY:06X}'))
    # 5) coordenadas X (datos)
    w.append((X_CMD_OFF, X_CMD_VAL.to_bytes(2,'big'), 'X_inf comando 5 -> 4'))
    w.append((X_OK_OFF,  X_OK_VAL.to_bytes(2,'big'),  'X_inf OK       8 -> 10'))
    # 6) unico cambio de CODIGO: ancho 3 -> 5 columnas
    w.append((OFF_D2_INF, VAL_D2_INF.to_bytes(2,'big'), 'd2 inferior: 3 -> 5 cols (CODIGO)'))
    return w

def build_slots():
    return SLOTS

def apply_emu(m, rom):
    for off, b, _ in build_writes(rom):
        for k in range(0, len(b) - len(b)%2, 2):
            m.poke16(off+k, int.from_bytes(b[k:k+2],'big'))
        if len(b) % 2:
            last = off + len(b) - 1
            cur = m.peek16(last & ~1)
            m.poke16(last & ~1, (cur & 0xFF00) | b[-1] if (last & 1) else (b[-1]<<8)|(cur & 0xFF))
