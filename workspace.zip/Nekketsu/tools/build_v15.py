"""build_v15.py - ROM v1.5: bloque completo de dialogos.

Parte de la v1.4 y aplica cuatro cambios, todos verificados en emulador:

 1. FIX del desfase de sangria entre lineas  (2 bytes)
    0x00593C: 0000 -> FFFF
    Bug del juego original: al saltar de linea la columna se ponia a 0 y el
    flujo le sumaba 1 antes de pintar, asi que la 2a linea empezaba una
    columna a la derecha de la 1a. Con -1 ambas arrancan igual.

 2. Reformateo de los 48 dialogos
    - alineados a la IZQUIERDA con sangria uniforme de 2 tiles
      (la sangria es columna base 1 + offset interno del motor 1; no se
       anaden espacios propios)
    - fila base FIJA 0x18 (24) tenga 1 o 2 lineas
    - frases partidas recompuestas: ninguna se corta
    - NO se toca ni una palabra de la traduccion

 3. Fuente nueva de dialogos en el asset 0x90000
    86 glifos, trazo uniforme de 1 px, alturas regulares, tildes de 2 px.

 4. Checksum de cartucho recalculado.

Bloques NO tocados por diseno: nombres de jugador, nombres de capitan,
creditos, 'FIN', 'FIN DE LA PARTIDA' y el menu 'Volver a intentarlo?'
(su separacion 'SI    NO' es funcional: ahi va el cursor).
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D
import dlgfont as F
import realign as R
import hud_v14 as H

# rellenar o no los bloques (ver investigation.md: el relleno es el temporizador)
# Relleno SELECTIVO. Sin relleno general (si no, el juego se salta
# dialogos: el relleno alarga la escritura y la escena avanza sin
# esperar). PAD_MIN garantiza un minimo de words por bloque para que
# las frases cortas no desaparezcan en menos de un segundo.
PAD_FULL = False
PAD_MIN = 0
CHAR_DELAY = None
from hudtools import decomp

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_4.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_5.md'

FONT_ASSET = 0x90000
NEWLINE_FIX = (0x00593C, bytes.fromhex('FFFF'), bytes.fromhex('0000'))
ROW_BASE = 0x18          # fila fija para todos los dialogos
INDENT = 0               # sin espacios propios: el motor ya deja 2 tiles
WIDTH = 30               # ancho util real medido en pantalla


def split_lines(txt, avail):
    """1 linea si cabe; si no, el corte en 2 mas EQUILIBRADO.

    Antes se tomaba el primer corte valido (codicioso), lo que producia
    resultados como 'KUNIO: Me' / 'dan pena...'. Ahora se evaluan todos los
    puntos y se elige el que deja las dos lineas mas parecidas, que es lo
    que se lee de forma natural.
    """
    if len(txt) <= avail:
        return [txt]
    w = txt.split(' ')
    best = None
    for k in range(1, len(w)):
        a = ' '.join(w[:k])
        b = ' '.join(w[k:])
        if len(a) <= avail and len(b) <= avail:
            score = abs(len(a) - len(b))
            if best is None or score < best[0]:
                best = (score, [a, b])
    return best[1] if best else None


# El usuario indica que la frase correcta es
#   'El equipo sufrio una intoxicacion alimentaria y no puede ir.'
# Con el prefijo son 69 caracteres y el limite fisico es 60 (2 lineas x 30).
# Se reparte en los dos bloques que el juego muestra consecutivamente.
OVERRIDE = {
    0x0804F4: 'TAKASHI: El equipo sufri\u00f3 una',
    0x080572: 'intoxicaci\u00f3n alimentaria y no puede ir.',
}


def build_dialogue_writes(rom):
    out = []
    avail = WIDTH - INDENT
    saltados = []
    for addr, col, fila, lines, n, sz in D.all_blocks(rom):
        if not R.is_dialogue(lines):
            continue
        txt = OVERRIDE.get(addr) or ' '.join(l.strip() for l in lines if l.strip())
        new = split_lines(txt, avail)
        if new is None:
            saltados.append((addr, txt))
            continue
        new = [' ' * INDENT + L for L in new]
        # relleno minimo: se anaden espacios a la ULTIMA linea hasta alcanzar
        # PAD_MIN words. Son invisibles y solo sirven de temporizador.
        if PAD_MIN:
            usados = sum(len(L) for L in new) + len(new)
            falta = PAD_MIN - usados
            if falta > 0:
                new = new[:-1] + [new[-1] + ' ' * falta]
        try:
            blob = D.write_block(col, ROW_BASE, new, sz)
        except ValueError as e:
            saltados.append((addr, f'{txt}  [{e}]'))
            continue
        out.append((addr, blob, ' | '.join(new)))
    return out, saltados


def build_font_write(rom):
    data, end, _ = decomp(rom, FONT_ASSET, 256)
    big = bytearray(data)
    n = 0
    for ch in F.G:
        if ch == ' ':
            continue
        try:
            t = D.enc(ch) & 0x7FF
        except ValueError:
            continue
        if t * 32 + 32 > len(big):
            continue
        # conservar el indice de color del glifo original
        ink = 0
        for b in big[t * 32:(t + 1) * 32]:
            hi, lo = (b >> 4) & 0xF, b & 0xF
            if hi:
                ink = hi; break
            if lo:
                ink = lo; break
        if not ink:
            ink = 15
        big[t * 32:(t + 1) * 32] = F.encode(ch, ink=ink, bg=0)
        n += 1
    blob = H.compress(bytes(big), header=rom[FONT_ASSET:FONT_ASSET + 4])[0]
    orig_size = end - FONT_ASSET
    if len(blob) > orig_size:
        raise RuntimeError(f'fuente {len(blob)} B > {orig_size} B disponibles')
    return blob, n, orig_size


def main():
    D.PAD_FULL = PAD_FULL
    rom = bytearray(open(SRC, 'rb').read())
    src_md5 = hashlib.md5(rom).hexdigest()

    off, new, expect = NEWLINE_FIX
    got = bytes(rom[off:off + 2])
    if got != expect:
        raise RuntimeError(f'{off:#08x}: esperaba {expect.hex()} y hay {got.hex()}')

    dlg, saltados = build_dialogue_writes(bytes(rom))
    font, nglifos, fsize = build_font_write(bytes(rom))

    rom[off:off + 2] = new
    for a, blob, _ in dlg:
        rom[a:a + len(blob)] = blob
    rom[FONT_ASSET:FONT_ASSET + len(font)] = font

    if CHAR_DELAY is not None:
        # 0x0058AE: 3d7c 0002 0012 = move.w #$2,$12(a6)
        #   +0 opcode  +2 VALOR INMEDIATO  +4 desplazamiento
        # El valor esta en 0x0058B0. Antes escribia en 0x0058B2 y corrompia
        # el desplazamiento, convirtiendolo en $8(a6): otro campo distinto.
        assert rom[0x0058B2:0x0058B4] == b'\x00\x12', 'estructura inesperada'
        rom[0x0058B0:0x0058B2] = CHAR_DELAY.to_bytes(2, 'big')

    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    open(DST, 'wb').write(bytes(rom))
    print(f'origen : {SRC}\n  md5  : {src_md5}')
    print(f'destino: {DST}\n  md5  : {hashlib.md5(rom).hexdigest()}')
    print()
    print(f'fix del salto de linea : 1 escritura (2 B) en {off:#08x}')
    print(f'dialogos reformateados : {len(dlg)}')
    n1 = sum(1 for _, _, t in dlg if '|' not in t)
    print(f'   de 1 linea {n1}   de 2 lineas {len(dlg)-n1}')
    print(f'fuente                 : {nglifos} glifos, '
          f'{len(font)} B de {fsize} disponibles')
    if saltados:
        print(f'\nNO reformateados ({len(saltados)}):')
        for a, t in saltados:
            print(f'   {a:#08x} {t[:60]!r}')


if __name__ == '__main__':
    main()
