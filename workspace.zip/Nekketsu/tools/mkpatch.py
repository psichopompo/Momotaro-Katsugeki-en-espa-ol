"""mkpatch.py - genera parches IPS y BPS a partir de dos ROMs del mismo tamano.

IPS: formato clasico, registros [offset:3][len:2][data]. Limite 16 MB.
BPS: formato moderno con checksums CRC32 de origen, destino y del propio
     parche. Se emite en su forma mas simple: un unico SourceRead que copia
     toda la ROM y luego los bloques modificados como SourceCopy/TargetRead.
     Para maxima compatibilidad se usa TargetRead sobre los tramos que cambian.
"""
import sys, zlib


def diff_runs(a, b, min_gap=8):
    """Tramos [ini, fin) donde a y b difieren, fusionando huecos pequenos.

    Si el destino es mayor que el origen (p. ej. jp 512 KB -> 1 MB), la cola
    sobrante se trata como un unico tramo modificado.
    """
    tail = None
    if len(b) > len(a):
        tail = (len(a), len(b))      # cola nueva: todo contenido a escribir
        b_head = b[:len(a)]
    else:
        b_head = b[:len(a)] if len(a) > len(b) else b
        a = a[:len(b)]
    runs = []
    i = 0
    b = b_head
    n = min(len(a), len(b))
    while i < n:
        if a[i] != b[i]:
            j = i
            gap = 0
            k = i
            while k < n:
                if a[k] != b[k]:
                    j = k
                    gap = 0
                else:
                    gap += 1
                    if gap > min_gap:
                        break
                k += 1
            runs.append((i, j + 1))
            i = k
        else:
            i += 1
    if tail:
        runs.append(tail)
    return runs


# ---------------------------------------------------------------- IPS
def make_ips(src, dst):
    if len(dst) > 0x1000000:
        raise RuntimeError('IPS no admite ROMs > 16 MB')
    out = bytearray(b'PATCH')
    for ini, fin in diff_runs(src, dst):
        pos = ini
        while pos < fin:
            chunk = min(0xFFFF, fin - pos)
            if pos == 0x454F46:          # 'EOF' como offset: hay que evitarlo
                pos -= 1
                chunk += 1
            out += pos.to_bytes(3, 'big')
            out += chunk.to_bytes(2, 'big')
            out += dst[pos:pos + chunk]
            pos += chunk
    out += b'EOF'
    return bytes(out)


# ---------------------------------------------------------------- BPS
def _num(n):
    """Entero de longitud variable de BPS."""
    out = bytearray()
    while True:
        x = n & 0x7F
        n >>= 7
        if n == 0:
            out.append(0x80 | x)
            break
        out.append(x)
        n -= 1
    return bytes(out)


SOURCE_READ, TARGET_READ, SOURCE_COPY, TARGET_COPY = 0, 1, 2, 3


def make_bps(src, dst, metadata=b''):
    out = bytearray(b'BPS1')
    out += _num(len(src))
    out += _num(len(dst))
    out += _num(len(metadata))
    out += metadata

    runs = diff_runs(src, dst)
    pos = 0
    src_eff = src + b'\xff' * max(0, len(dst) - len(src))
    for ini, fin in runs:
        if ini > pos:                      # tramo identico -> SourceRead
            out += _num(((ini - pos) - 1) << 2 | SOURCE_READ)
        out += _num(((fin - ini) - 1) << 2 | TARGET_READ)
        out += dst[ini:fin]
        pos = fin
    if pos < len(dst):
        out += _num(((len(dst) - pos) - 1) << 2 | SOURCE_READ)

    out += zlib.crc32(src).to_bytes(4, 'little')
    out += zlib.crc32(dst).to_bytes(4, 'little')
    out += zlib.crc32(bytes(out)).to_bytes(4, 'little')
    return bytes(out)


def apply_ips(src, patch):
    assert patch[:5] == b'PATCH'
    rom = bytearray(src)
    i = 5
    while True:
        if patch[i:i + 3] == b'EOF':
            break
        off = int.from_bytes(patch[i:i + 3], 'big'); i += 3
        ln = int.from_bytes(patch[i:i + 2], 'big'); i += 2
        if ln == 0:                        # RLE
            rl = int.from_bytes(patch[i:i + 2], 'big'); i += 2
            val = patch[i]; i += 1
            rom[off:off + rl] = bytes([val]) * rl
        else:
            rom[off:off + ln] = patch[i:i + ln]; i += ln
    return bytes(rom)


if __name__ == '__main__':
    base, target, stem = sys.argv[1], sys.argv[2], sys.argv[3]
    a = open(base, 'rb').read()
    b = open(target, 'rb').read()
    ips = make_ips(a, b)
    bps = make_bps(a, b)
    open(stem + '.ips', 'wb').write(ips)
    open(stem + '.bps', 'wb').write(bps)
    runs = diff_runs(a, b)
    print(f'base   : {base}  ({len(a)} B, crc32 {zlib.crc32(a):08x})')
    print(f'destino: {target}  ({len(b)} B, crc32 {zlib.crc32(b):08x})')
    print(f'tramos modificados: {len(runs)}  ({sum(f-i for i,f in runs)} B)')
    print(f'  {stem}.ips  {len(ips)} B')
    print(f'  {stem}.bps  {len(bps)} B')
    chk = apply_ips(a, ips)
    print(f'verificacion IPS: {"OK" if chk == b else "FALLA"}')
