"""hud_final2.py - HUD COMPLETAMENTE DESACOPLADO.

Cada slot tiene su propia entrada de 16 bytes:
    +0  X_sup      +2  X_inf     +4  ancho_inf-1   +6  Y_inf
    +8  puntero a SU PROPIA tabla de textos (long)
   +12  ancho_sup-1                        +14  reserva

Bloque SUPERIOR: 3 parches in-place (mismo tamaño).
Bloque INFERIOR: se sustituye el setup por un JSR a un trampolin, que resuelve
                 a0/d0/d1/d2/d3/d4/d5 leyendo TODO de la entrada del slot.
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
from hudtools import decomp
from newletters import build

_src = open('/home/user/project/hist/scripts/recompress.py').read().split("if __name__")[0]
_ns = {}; exec(_src, _ns)
compress = _ns['compress']

# ---------------- constantes ----------------
ASSET_OLD  = 0x0286AA
ASSET_NEW  = 0x094000
ASSET_PTRS = [0x0020D0, 0x005102]

SAFE = {'C':0x89,'D':0x98,'F':0xA1,'I':0xFC,'L':0xFD,'N':0xFE,'R':0xFF,'T':0xEE}
EX   = {'P':0x10,'A':0x11,'U':0x12,'S':0x13,'E':0x14,'O':0x15,'K':0x16}
IDX  = dict(EX); IDX.update(SAFE)
SP = 0x8485
def W(ch): return SP if ch == ' ' else 0x8440 + IDX[ch]

COORD   = 0x08A800     # 4 slots x 16 B = 64 B
TRAMP   = 0x08A900     # trampolin (56 B)
TBL_S0  = 0x08AA00     # tabla de textos del slot 0 (ancho 5)
TBL_S1  = 0x08AB00     # tabla de textos del slot 1 (ancho 4)
TBL_S2  = 0x08AC00     # tabla del slot 2 (ancho 5, panel derecho)
TBL_S3  = 0x08AD00     # tabla del slot 3 (ancho 2, panel derecho)

# ---- geometria final (medida: interior del panel = cols 2..10) ----
# slot0: X=2 ancho 5 -> cols 2..6      slot1: X=7 ancho 4 -> cols 7..10
# borde col 11 INTACTO. 9 celdas justas, sin separador (como el original).
GEOM = {
    #  d6 : (X_sup, X_inf, ancho_inf-1, Y_inf, tabla, ancho_sup-1)
    # zona legible: izq 4..10, der 21..27 (la animadora tapa 2-3 y 28-29)
    3: (5,  4, 4, 0x19, TBL_S0, 1),   # slot0: 5 cols -> 4..8   comandos principales
    2: (9,  9, 1, 0x19, TBL_S1, 1),   # slot1: 2 cols -> 9,10   OK (CEDE -> "CE")
    1: (21, 21, 4, 0x19, TBL_S2, 1),  # slot2: 5 cols -> 21..25
    0: (25, 26, 1, 0x19, TBL_S3, 1),  # slot3: 2 cols -> 26,27
}
TEXT = {0:'', 1:'PASA', 2:'FINTA', 3:'TIRA', 4:'PLACA', 5:'CEDE', 6:'OK', 7:''}

def entry(txt, cols):
    """fila superior vacia + fila inferior con el texto, `cols` words cada una."""
    return [SP]*cols + [W(c) for c in txt[:cols].ljust(cols)]

def trampoline():
    b = bytearray()
    b += bytes.fromhex('2006')                       # move.l d6,d0
    b += bytes.fromhex('e980')                       # asl.l  #4,d0     (d6*16)
    b += b'\x49\xf9' + COORD.to_bytes(4,'big')       # lea.l  COORD,a4
    b += bytes.fromhex('d9c0')                       # adda.l d0,a4
    b += bytes.fromhex('3a2b0002')                   # move.w 2(a3),d5   (ID)
    b += bytes.fromhex('028500000007')               # andi.l #7,d5
    b += bytes.fromhex('e585')                       # asl.l  #2,d5
    b += bytes.fromhex('226c0008')                   # movea.l 8(a4),a1  (tabla propia)
    b += bytes.fromhex('d3c5')                       # adda.l d5,a1
    b += bytes.fromhex('2051')                       # movea.l (a1),a0
    b += bytes.fromhex('302c0002')                   # move.w 2(a4),d0   (X_inf)
    b += bytes.fromhex('322c0006')                   # move.w 6(a4),d1   (Y_inf)
    b += bytes.fromhex('342c0004')                   # move.w 4(a4),d2   (ancho-1)
    b += bytes.fromhex('363c0001')                   # move.w #1,d3      (2 filas)
    b += bytes.fromhex('383c4000')                   # move.w #$4000,d4
    b += bytes.fromhex('4245')                       # clr.w  d5
    b += bytes.fromhex('4e75')                       # rts
    return bytes(b)

CALL_LO, CALL_HI = 0x00A546, 0x00A57E   # 56 bytes de setup a sustituir

def asset_blob(rom):
    data,_,_ = decomp(rom, ASSET_OLD, 256)
    mod = bytearray(data); g = build()
    for ch, idx in SAFE.items(): mod[idx*32:(idx+1)*32] = g[ch]
    return compress(bytes(mod), header=rom[ASSET_OLD:ASSET_OLD+4])[0]

def build_writes(rom):
    w = []
    blob = asset_blob(rom)
    w.append((ASSET_NEW, blob, f'asset+8 letras seguras ({len(blob)}B)'))
    for pa in ASSET_PTRS:
        w.append((pa, ASSET_NEW.to_bytes(4,'big'), 'cargador asset'))

    # --- tabla de coordenadas: 16 B por slot ---
    for d6,(xs,xi,aw,yi,tbl,asup) in GEOM.items():
        b = COORD + d6*16
        for off,val,tag in ((0,xs,'X_sup'),(2,xi,'X_inf'),(4,aw,'ancho_inf-1'),
                            (6,yi,'Y_inf'),(12,asup,'ancho_sup-1'),(14,0,'resv')):
            w.append((b+off, val.to_bytes(2,'big'), f'd6={d6} {tag}'))
        w.append((b+8, tbl.to_bytes(4,'big'), f'd6={d6} tabla propia -> {tbl:06X}'))

    # --- una tabla de textos POR SLOT, dimensionada a SU ancho ---
    for tbl, cols in ((TBL_S0,5), (TBL_S1,2), (TBL_S2,5), (TBL_S3,2)):
        ent = cols*2*2
        data_base = tbl + 8*4          # 8 punteros long, luego las entradas
        for cid in range(8):
            e = data_base + cid*ent
            w.append((tbl+cid*4, e.to_bytes(4,'big'), f'{tbl:06X} ptr[{cid}]'))
            for k,ww in enumerate(entry(TEXT.get(cid,''), cols)):
                w.append((e+k*2, ww.to_bytes(2,'big'), f'{tbl:06X} cmd[{cid}] w{k}'))

    # --- trampolin ---
    t = trampoline()
    w.append((TRAMP, t, f'trampolin ({len(t)}B)'))

    # --- bloque SUPERIOR: 3 parches in-place ---
    w.append((0x00A51E, bytes.fromhex('e980'), 'SUP asl.l #4 (d6*16)'))
    w.append((0x00A520, b'\x49\xf9'+COORD.to_bytes(4,'big'), 'SUP lea COORD,a4'))
    w.append((0x00A52E, bytes.fromhex('342c000c'), 'SUP move.w 12(a4),d2'))

    # --- bloque INFERIOR: JSR al trampolin + NOPs ---
    patch = b'\x4e\xb9' + TRAMP.to_bytes(4,'big')
    patch += b'\x4e\x71' * ((CALL_HI-CALL_LO-6)//2)
    assert len(patch) == CALL_HI-CALL_LO, (len(patch), CALL_HI-CALL_LO)
    w.append((CALL_LO, patch, f'INF -> JSR trampolin + {(CALL_HI-CALL_LO-6)//2} NOP'))
    return w

def apply_emu(m, rom):
    for off,b,_ in build_writes(rom):
        for k in range(0, len(b)-len(b)%2, 2):
            m.poke16(off+k, int.from_bytes(b[k:k+2],'big'))
        if len(b)%2:
            last=off+len(b)-1; cur=m.peek16(last & ~1)
            m.poke16(last & ~1, (cur & 0xFF00)|b[-1] if (last&1) else (b[-1]<<8)|(cur&0xFF))
