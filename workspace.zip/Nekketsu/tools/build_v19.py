"""build_v19.py - ROM v1.9: integracion de los graficos del usuario.

Parte de la v1.8 y aplica TRES cambios:

 1. OPCIONES alineado con INICIO y balon devuelto a su sitio  (2 words)
 2. Rotulo de la pantalla de titulo, redibujado por el usuario
 3. Placa 'ELIGE ESCUELA' de la pantalla de seleccion, redibujada por el usuario

--------------------------------------------------------------------------
1. ALINEACION DEL MENU
--------------------------------------------------------------------------
En la japonesa START y OPTION arrancan los dos en la columna 13. Al traducir
se dejo OPCIONES en la 12 y se movio el BALON para compensar. Se revierte:

  0x08805C: 000C -> 000D    columna de OPCIONES,  12 -> 13
  0x0008EA: 00D0 -> 00D8    X del balon, 208 -> 216 (valor original japones)

--------------------------------------------------------------------------
2. ROTULO DEL TITULO
--------------------------------------------------------------------------
PNG 256x224 con transparencia dibujado por el usuario sobre una captura real,
asi que la posicion ya es exacta (filas 3..15, columnas 1..30).

Los 10 colores que usa son EXACTAMENTE los de la paleta 1 japonesa de esa
pantalla, verificados uno a uno. Nuestro rotulo se pinta con la paleta 3
(atributo 0x6000) cargada desde 0xA3400, asi que se reescribe esa paleta con
los valores japoneses.

  tilemap  0x0A3000   32x16 words, volcado por 0x088030
  tiles    0x096000   asset de 256 tiles, base 0x200 (reubicado en la v1.3)
  paleta   0x0A3400   16 words, cargada por 0x08850A

--------------------------------------------------------------------------
3. PLACA 'ELIGE ESCUELA'
--------------------------------------------------------------------------
PNG 160x48 con los 8 indices originales. Verificado que el MARCO queda
intacto (0 pixeles distintos fuera del interior x 12..147, y 8..39).

  tilemap  0x02AD68   20x6 words, atributo 0x2000 (paleta 1)
  tiles    0x041500   asset de 512 tiles, base 0x100
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D
import titulo as T
import hud_v14 as H
from hudtools import decomp
from PIL import Image

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_8.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_9.md'

UP = '/home/user/uploads'
PNG_TITULO = f'{UP}/IMG_4512.PNG'
PNG_PLACA = f'{UP}/IMG_4515.PNG'

# --- 1 --------------------------------------------------------------------
COL_OPCIONES = 0x08805C
BALON_X = 0x0008EA

# --- 2 --------------------------------------------------------------------
TIT_MAP = 0x0A3000
TIT_PAL = 0x0A3400
TIT_ASSET = 0x096000
TIT_NTILES = 256

# --- 3 --------------------------------------------------------------------
PLACA_MAP = 0x02AD68          # 20x6 words
PLACA_ASSET = 0x042A20        # 1024 tiles (localizado por traza VRAM<-ROM)
PLACA_BASE = 0x100            # tile de VRAM = base + indice del asset
PLACA_ATTR = 0x2000           # paleta 1
# Los DOS lea.l que cargan el asset. Mi busqueda anterior no los encontro
# porque recorria la ROM de 2 en 2 bytes desde offset par, y estos punteros
# caen en offset IMPAR+1 dentro de la instruccion (41f9 en 0x00371E y
# 0x003B76, el operando queda en 0x003720 y 0x003B78, que si son pares...
# el fallo real fue exigir que el LONG empezara en direccion par ALINEADA
# con el inicio de instruccion). Localizados buscando el valor como LONG en
# cualquier offset par y comprobando el 41f9 previo.
PLACA_PTRS = (0x003720, 0x003B78)
PLACA_NEW = 0x0993EA          # hueco libre verificado a 0xFF (PAR: el 68000
                              # aborta con address error si lee un word en
                              # direccion impar. 0x0993E9 lo era y dejaba la
                              # pantalla en negro)

# indices de color de la placa, medidos en el original japones
PLACA_COL = {
    (0x8b, 0x89, 0x00): 0x2, (0x20, 0x20, 0x00): 0x3,
    (0x8b, 0x89, 0x20): 0x4, (0xcd, 0xce, 0x00): 0x6,
    (0x62, 0x65, 0x20): 0x7, (0xee, 0xee, 0x00): 0x8,
    (0x41, 0x44, 0x00): 0x9, (0xee, 0xee, 0xee): 0xE,
}


def patch_menu(rom):
    v = int.from_bytes(rom[COL_OPCIONES:COL_OPCIONES + 2], 'big')
    if v != 12:
        raise RuntimeError(f'{COL_OPCIONES:#08x}: esperaba 12, hay {v}')
    rom[COL_OPCIONES:COL_OPCIONES + 2] = (13).to_bytes(2, 'big')
    v = int.from_bytes(rom[BALON_X:BALON_X + 2], 'big')
    if v != 0xD0:
        raise RuntimeError(f'{BALON_X:#08x}: esperaba 0x00D0, hay {v:#06x}')
    rom[BALON_X:BALON_X + 2] = (0xD8).to_bytes(2, 'big')


def patch_titulo(rom):
    orden, tmap = T.build(PNG_TITULO)
    if len(orden) > TIT_NTILES:
        raise RuntimeError(f'{len(orden)} tiles > {TIT_NTILES} del asset')
    if len(tmap) != 512:
        raise RuntimeError('el tilemap deberia tener 512 words')

    # tiles
    data, end, _ = decomp(bytes(rom), TIT_ASSET, TIT_NTILES)
    big = bytearray(len(data))
    for i, blk in enumerate(orden):
        big[i * 32:(i + 1) * 32] = blk
    hdr = bytes(rom[TIT_ASSET:TIT_ASSET + 4])
    comp = H.compress(bytes(big), header=hdr)[0]
    disp = end - TIT_ASSET
    if len(comp) > disp:
        raise RuntimeError(f'titulo: {len(comp)} B > {disp} B disponibles')
    rom[TIT_ASSET:TIT_ASSET + len(comp)] = comp

    # tilemap
    for i, w in enumerate(tmap):
        rom[TIT_MAP + i * 2:TIT_MAP + i * 2 + 2] = w.to_bytes(2, 'big')

    # paleta
    for i, w in enumerate(T.palette_words()):
        rom[TIT_PAL + i * 2:TIT_PAL + i * 2 + 2] = w.to_bytes(2, 'big')

    return len(orden), len(comp), disp


def patch_placa(rom):
    """Escribe la placa del usuario en el asset y ajusta el tilemap.

    El tilemap original REUTILIZA tiles entre celdas distintas (p.ej. 0x18E
    aparece en 3 celdas). En la placa japonesa esas celdas eran identicas,
    pero en la del usuario no lo son, asi que no basta con sobrescribir el
    tile: hay que dar un tile PROPIO a cada celda en conflicto.

    Medido: 4 tiles compartidos con contenido distinto (0x18E, 0x190, 0x131,
    0x167). Se les asignan indices libres del asset (hay 525 vacios).
    """
    im = Image.open(PNG_PLACA).convert('RGB')
    if im.size != (160, 48):
        raise RuntimeError(f'la placa deberia ser 160x48, es {im.size}')
    px = im.load()
    M = [[0] * 160 for _ in range(48)]
    for y in range(48):
        for x in range(160):
            c = px[x, y]
            if c not in PLACA_COL:
                raise RuntimeError(f'color fuera de paleta en ({x},{y}): {c}')
            M[y][x] = PLACA_COL[c]

    data, end, _ = decomp(bytes(rom), PLACA_ASSET, 1024)
    big = bytearray(data)
    libres = [i for i in range(1024) if not any(data[i * 32:(i + 1) * 32])]
    usado = {}          # bytes del tile -> indice asignado
    nuevos = 0
    n = 0

    for r in range(6):
        for c in range(20):
            off = PLACA_MAP + (r * 20 + c) * 2
            w = int.from_bytes(rom[off:off + 2], 'big')
            idx = (w & 0x7FF) - PLACA_BASE
            blk = bytearray()
            for y in range(8):
                for xb in range(4):
                    a = M[r * 8 + y][c * 8 + xb * 2]
                    b = M[r * 8 + y][c * 8 + xb * 2 + 1]
                    blk.append((a << 4) | b)
            blk = bytes(blk)
            if blk in usado:
                dst = usado[blk]
            elif idx not in usado.values():
                dst = idx
                usado[blk] = idx
            else:
                dst = libres.pop(0)
                usado[blk] = dst
                nuevos += 1
            if big[dst * 32:(dst + 1) * 32] != blk:
                big[dst * 32:(dst + 1) * 32] = blk
                n += 1
            nw = (w & 0xF800) | (PLACA_BASE + dst)
            rom[off:off + 2] = nw.to_bytes(2, 'big')

    hdr = bytes(rom[PLACA_ASSET:PLACA_ASSET + 4])
    comp = H.compress(bytes(big), header=hdr)[0]
    disp = end - PLACA_ASSET
    if len(comp) <= disp:
        rom[PLACA_ASSET:PLACA_ASSET + len(comp)] = comp
        return n, len(comp), disp, nuevos, None
    # No cabe in situ: detras hay OTRO asset pegado (0x045A14), asi que no se
    # puede desbordar. Se reubica al hueco libre y se repuntan los dos lea.l.
    room = 0x0A0000 - PLACA_NEW
    if len(comp) > room:
        raise RuntimeError(f'placa: {len(comp)} B > {room} B en {PLACA_NEW:#08x}')
    if any(b != 0xFF for b in rom[PLACA_NEW:PLACA_NEW + len(comp)]):
        raise RuntimeError(f'{PLACA_NEW:#08x} no esta libre')
    rom[PLACA_NEW:PLACA_NEW + len(comp)] = comp
    for ptr in PLACA_PTRS:
        if int.from_bytes(rom[ptr:ptr + 4], 'big') != PLACA_ASSET:
            raise RuntimeError(f'{ptr:#08x} no apunta al asset de la placa')
        if bytes(rom[ptr - 2:ptr]) != b'\x41\xf9':
            raise RuntimeError(f'{ptr:#08x} no va precedido de lea.l')
        rom[ptr:ptr + 4] = PLACA_NEW.to_bytes(4, 'big')
    return n, len(comp), disp, nuevos, PLACA_NEW


def main():
    rom = bytearray(open(SRC, 'rb').read())
    print(f'origen : {SRC}\n  md5  : {hashlib.md5(rom).hexdigest()}\n')

    patch_menu(rom)
    print('1) menu: OPCIONES columna 12 -> 13,  balon x 208 -> 216')

    nt, ct, dt = patch_titulo(rom)
    print(f'\n2) rotulo del titulo: {nt} tiles unicos')
    print(f'   asset {TIT_ASSET:#08x}: {ct} B de {dt} disponibles')
    print(f'   tilemap {TIT_MAP:#08x}: 512 words')
    print(f'   paleta  {TIT_PAL:#08x}: 16 colores japoneses')

    np_, cp, dp, nuevos, moved = patch_placa(rom)
    print(f'\n3) placa ELIGE ESCUELA: {np_} tiles escritos, '
          f'{nuevos} desduplicados')
    if moved is None:
        print(f'   asset {PLACA_ASSET:#08x}: {cp} B de {dp} disponibles')
    else:
        print(f'   asset reubicado {PLACA_ASSET:#08x} -> {moved:#08x}'
              f'  ({cp} B; no cabia en {dp})')
        print(f'   repuntados los lea.l de '
              + ', '.join(f'{p:#08x}' for p in PLACA_PTRS))

    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    final = bytes(rom)
    if len(D.block_spans(final)) != 86:
        raise RuntimeError('la tabla de dialogos se ha roto')
    ndiff = sum(1 for a, b in zip(open(SRC, 'rb').read(), final) if a != b)
    open(DST, 'wb').write(final)
    print(f'\ndestino: {DST}')
    print(f'  md5  : {hashlib.md5(final).hexdigest()}')
    print(f'  bytes distintos respecto a la v1.8: {ndiff}')
    print('  tabla de dialogos: 86 bloques  OK')


if __name__ == '__main__':
    main()
