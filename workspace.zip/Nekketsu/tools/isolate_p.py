"""isolate_p.py - prueba aislada: cambiar UNA letra original a fondo opaco
y medir el verde por celda de pantalla."""
import sys, random
sys.path.insert(0,'/home/user/project/tools')
import numpy as np
from md import MD
from hud_v13 import apply_emu, IDX, ASSET_NEW
from geom_test import boot, wbe

REV={0x440+i:ch for ch,i in IDX.items()}

def opaque_version(m, tile):
    """lee el tile de VRAM y devuelve los 32 bytes con indice 0 -> 9"""
    v=m.vram()
    out=bytearray()
    for k in range(32):
        b=v[(tile*32+k)^1]
        hi,lo=(b>>4)&0xF, b&0xF
        if hi==0: hi=9
        if lo==0: lo=9
        out.append((hi<<4)|lo)
    return bytes(out)

def poke_tile(m, tile, data32):
    import ctypes
    base=m.lib.arena_get_vram()
    buf=(ctypes.c_ubyte*0x10000).from_address(base)
    for i,b in enumerate(data32):
        buf[(tile*32+i)^1]=b

def rgb(m):
    raw,w,h,pitch,fmt=m.last
    a=np.frombuffer(raw,dtype=np.uint16).reshape(h,pitch//2)[:,:w].astype(np.uint32)
    return np.dstack([((a>>11)&31)*255//31,((a>>5)&63)*255//63,(a&31)*255//31]).astype(np.uint8)

def green_per_cell(img, row, cols):
    """cuenta pixeles verdes en cada celda de 8x8 de la fila `row`"""
    out={}
    for c in cols:
        blk=img[row*8:(row+1)*8, c*8:(c+1)*8]
        g=((blk[:,:,1]>90)&(blk[:,:,0]<90)&(blk[:,:,2]<90)).sum()
        out[c]=int(g)
    return out

def run(fix_tiles, tag):
    rom=open('/home/user/project/rom/Nekketsu_Soccer_MD_ES_v0_9_10.md','rb').read()
    m=MD('/home/user/project/rom/Nekketsu_Soccer_MD_ES_v0_9_10.md',evcap=10)
    m.trace(True); m.config()
    apply_emu(m, rom)
    boot(m)
    # tras el boot el asset ya esta en VRAM: parchear los tiles pedidos
    for t in fix_tiles:
        poke_tile(m, t, opaque_version(m, t))
    bp=m.bp_add(0x00A582); prev=m.bp_hits(bp)
    rnd=random.Random(21)
    for i in range(300):
        m.press(rnd.choice(['A','B','C','Y']), rnd.choice(['RIGHT','LEFT']))
        for k in range(8):
            m.run(1); h=m.bp_hits(bp)
            if h>prev:
                prev=h
                v=m.vram()
                L=[wbe(v,26,c)&0x7FF for c in range(0,16)]
                txt=''.join(REV.get(t,'') for t in L)
                if txt.startswith('PASA'):
                    m.run(1)
                    img=rgb(m)
                    letters={c:REV[L[c]] for c in range(16) if L[c] in REV}
                    g=green_per_cell(img, 26, sorted(letters))
                    m.save_png(f'/home/user/project/work/shots/iso_{tag}.png')
                    m.close()
                    return letters, g
        m.release(); m.run(2)
    m.close(); return None, None
