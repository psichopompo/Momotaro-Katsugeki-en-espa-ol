"""hud_v2.py - configuracion del HUD con tiles SEGUROS y geometria corregida.

Cambios respecto a la v0.9.11 (retirada):
  - las 8 letras van a tiles verificados con marcador activo (no a los 5 en uso)
  - el OK conserva su celda-espacio inicial como separador (igual que el original)
  - nada invade las columnas 1 y 11 (bordes del marco)
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
from hudtools import decomp
from newletters import build

_src = open('/home/user/project/hist/scripts/recompress.py').read().split("if __name__")[0]
_ns = {}; exec(_src, _ns)
compress = _ns['compress']

ASSET_OLD  = 0x0286AA
ASSET_NEW  = 0x094000
ASSET_PTRS = [0x0020D0, 0x005102]

# --- tiles SEGUROS (verificados con marcador solido, §12 punto 1b) ---
SAFE = {'C':0x89, 'D':0x98, 'F':0xA1, 'I':0xFC, 'L':0xFD, 'N':0xFE, 'R':0xFF, 'T':0xEE}
EX   = {'P':0x10,'A':0x11,'U':0x12,'S':0x13,'E':0x14,'O':0x15,'K':0x16}
IDX  = dict(EX); IDX.update(SAFE)

SP = 0x8485
def T(i): return 0x8440 + i
def W(ch): return SP if ch == ' ' else T(IDX[ch])

TABLE     = 0x08A700
PTR_TABLE = 0x00A5C4
COLS, ROWS = 5, 2
ENTRY = COLS*ROWS*2          # 20 bytes

OFF_D2_INF = 0x00A572        # 3 -> 5 columnas (unico cambio de codigo)
VAL_D2_INF = 0x0004
OFF_X_CMD  = 0x00A5A2 + 2    # X_inf del slot del comando (d6=3)
OFF_X_OK   = 0x00A59E + 2    # X_inf del slot del OK      (d6=2)

COMMANDS = {0:'', 1:'PASA', 2:'FINTA', 3:'TIRA', 4:'PLACA', 5:'CEDE', 6:'OK', 7:''}

def asset_blob(rom):
    data,_,_ = decomp(rom, ASSET_OLD, 256)
    mod = bytearray(data)
    g = build()
    for ch, idx in SAFE.items():
        mod[idx*32:(idx+1)*32] = g[ch]
    return compress(bytes(mod), header=rom[ASSET_OLD:ASSET_OLD+4])[0]

def entry_words(cid):
    """5 words fila superior (vacia) + 5 words fila inferior."""
    txt = COMMANDS.get(cid,'')
    top = [SP]*COLS
    if cid == 6:                       # OK: conserva su espacio separador inicial
        bot = [SP, W('O'), W('K'), SP, SP]
    else:
        bot = [W(c) for c in txt[:COLS].ljust(COLS)]
    return top + bot

def build_writes(rom, x_cmd, x_ok):
    w = []
    blob = asset_blob(rom)
    w.append((ASSET_NEW, blob, f'asset+8 letras seguras ({len(blob)} B)'))
    for pa in ASSET_PTRS:
        w.append((pa, ASSET_NEW.to_bytes(4,'big'), 'cargador'))
    for cid in range(8):
        base = TABLE + cid*ENTRY
        for k, ww in enumerate(entry_words(cid)):
            w.append((base+k*2, ww.to_bytes(2,'big'), f'cmd[{cid}] w{k}'))
    for cid in range(8):
        w.append((PTR_TABLE+cid*4, (TABLE+cid*ENTRY).to_bytes(4,'big'), f'ptr[{cid}]'))
    w.append((OFF_X_CMD, x_cmd.to_bytes(2,'big'), f'X comando = {x_cmd}'))
    w.append((OFF_X_OK,  x_ok.to_bytes(2,'big'),  f'X OK = {x_ok}'))
    w.append((OFF_D2_INF, VAL_D2_INF.to_bytes(2,'big'), 'd2 = 5 columnas (CODIGO)'))
    return w

def apply_emu(m, rom, x_cmd, x_ok):
    for off,b,_ in build_writes(rom, x_cmd, x_ok):
        for k in range(0, len(b)-len(b)%2, 2):
            m.poke16(off+k, int.from_bytes(b[k:k+2],'big'))
        if len(b)%2:
            last=off+len(b)-1; cur=m.peek16(last & ~1)
            m.poke16(last & ~1, (cur & 0xFF00)|b[-1] if (last&1) else (b[-1]<<8)|(cur&0xFF))
