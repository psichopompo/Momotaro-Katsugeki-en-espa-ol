"""rotulo.py - compone el rotulo de cabecera de las escenas.

El rotulo de la sala del club NO es una cadena de texto: es un TILEMAP plano
en 0x08C100 (words con indice de tile) que apunta a una tira de tiles ya
renderizada. Los glifos van a MEDIA CELDA: la tira se dibuja como un mapa de
bits continuo y luego se corta en tiles de 8 px, asi que una letra puede
quedar repartida entre dos tiles.

Ruta completa (hook de la traduccion v0.9.8):

  0x08C040: move.w #$4,d0     columna 4
            move.w #$3,d1     fila 3
            move.w #$17,d2    ancho-1 = 23  -> 24 tiles de borrado
            move.w #$2,d3     alto-1  = 2   -> 3 filas
            jsr $7a6e                        BORRA
            move.w #$9,d0     columna 9      <-- 0x08C05C
            move.w #$4,d1     fila 4
            move.w #$d,d2     ancho-1 = 13   <-- 0x08C064
            move.w #$0,d3     alto-1 = 0
            lea.l $8c100,a0                  <-- TILEMAP
            jsr $7a3c                        PINTA

Fuente medida sobre el rotulo actual 'SALA DEL CLUB': mayusculas de 7 px de
alto, trazo de 2 px, ancho variable. Se reproduce aqui glifo a glifo para
que el rotulo nuevo sea indistinguible en estilo del que ya habia.
"""

# Glifos de 7 filas. Trazo de 2 px, medidos sobre el rotulo original.
GL = {
'A': ["..████..",
      ".██··██.",
      "██····██",
      "██····██",
      "████████",
      "██····██",
      "██····██"],
'B': ["██████..",
      "██···██.",
      "██···██.",
      "██████..",
      "██····██",
      "██····██",
      "███████."],
'C': ["..████..",
      ".██··██.",
      "██······",
      "██······",
      "██······",
      ".██··██.",
      "..████.."],
'D': ["██████..",
      "██···██.",
      "██····██",
      "██····██",
      "██····██",
      "██···██.",
      "██████.."],
'E': ["███████.",
      "██......",
      "██......",
      "██████..",
      "██......",
      "██......",
      "███████."],
'G': ["..████..",
      ".██··██.",
      "██......",
      "██··████",
      "██····██",
      ".██··██.",
      "..█████."],
'L': ["██......",
      "██......",
      "██......",
      "██......",
      "██......",
      "██......",
      "███████."],
'O': ["..████..",
      ".██··██.",
      "██····██",
      "██····██",
      "██····██",
      ".██··██.",
      "..████.."],
'U': ["██····██",
      "██····██",
      "██····██",
      "██····██",
      "██····██",
      "██···██.",
      "..█████."],
' ': ["........",
      "........",
      "........",
      "........",
      "........",
      "........",
      "........"],
}

SEP = 1          # columnas de aire entre letras
SPACE = 5        # ancho del espacio entre palabras


def render(texto):
    """Devuelve 8 filas de '#'/'.' con el texto compuesto a media celda."""
    rows = [''] * 8
    for i, ch in enumerate(texto):
        if ch == ' ':
            for r in range(8):
                rows[r] += '.' * SPACE
            continue
        g = GL[ch]
        # recortar columnas vacias a derecha e izquierda del glifo
        cols = len(g[0])
        lo = min((c for c in range(cols)
                  for r in range(7) if g[r][c] == '█'), default=0)
        hi = max((c for c in range(cols)
                  for r in range(7) if g[r][c] == '█'), default=cols - 1)
        for r in range(7):
            rows[r] += g[r][lo:hi + 1].replace('█', '#')
        rows[7] += '.' * (hi - lo + 1)
        if i != len(texto) - 1:
            for r in range(8):
                rows[r] += '.' * SEP
    return rows


def to_tiles(rows, ntiles=None):
    """Corta el bitmap en tiles de 8x8. Devuelve lista de matrices 8x8."""
    w = max(len(r) for r in rows)
    rows = [r.ljust(w, '.') for r in rows]
    if ntiles is None:
        ntiles = (w + 7) // 8
    total = ntiles * 8
    pad = total - w
    left = pad // 2
    rows = ['.' * left + r + '.' * (pad - left) for r in rows]
    out = []
    for t in range(ntiles):
        out.append([r[t * 8:(t + 1) * 8] for r in rows])
    return out


def encode_tile(tile, ink=15, bg=0):
    """32 bytes 4bpp."""
    out = bytearray()
    for y in range(8):
        r = tile[y]
        for xb in range(4):
            a = ink if r[xb * 2] == '#' else bg
            b = ink if r[xb * 2 + 1] == '#' else bg
            out.append((a << 4) | b)
    return bytes(out)


def show(rows):
    for r in rows:
        print(r.replace('#', '\u2588').replace('.', '\u00b7'))


if __name__ == '__main__':
    import sys
    txt = sys.argv[1] if len(sys.argv) > 1 else 'CLUB DE DODGEBALL'
    rows = render(txt)
    print(f'{txt}  ->  {len(rows[0])} px')
    show(rows)
    ts = to_tiles(rows)
    print(f'{len(ts)} tiles')
