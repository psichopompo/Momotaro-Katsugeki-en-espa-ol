"""tilerender.py - render VRAM tile banks (read-only forensics)."""
from PIL import Image, ImageDraw

def logical(vram, addr):
    """VRAM logical byte: GPGX stores vram byteswapped on LE hosts."""
    return vram[addr ^ 1]

def tile_pixels(vram, tile):
    """Return 8x8 list of palette indices for a tile."""
    base = tile * 32
    px = []
    for y in range(8):
        row = []
        for xb in range(4):
            b = logical(vram, base + y * 4 + xb)
            row.append((b >> 4) & 0xF)
            row.append(b & 0xF)
        px.append(row)
    return px

def render_band(vram, first_tile, ntiles, scale=2, colors=None):
    im = Image.new('RGB', (ntiles * 8 * scale, 8 * scale), (0, 0, 40))
    p = im.load()
    for t in range(ntiles):
        px = tile_pixels(vram, first_tile + t)
        for y in range(8):
            for x in range(8):
                v = px[y][x]
                c = colors[v] if colors else ((0, 0, 40) if v == 0 else (255, 255, 255))
                for sy in range(scale):
                    for sx in range(scale):
                        p[(t * 8 + x) * scale + sx, y * scale + sy] = c
    return im

def render_bands(vram, base_tile, nbands, band_w, out, scale=2, labels=None, colors=None):
    pad = 18
    bw = band_w * 8 * scale
    im = Image.new('RGB', (bw, nbands * (8 * scale + pad)), (12, 12, 18))
    d = ImageDraw.Draw(im)
    for k in range(nbands):
        ft = base_tile + k * band_w
        b = render_band(vram, ft, band_w, scale, colors)
        y = k * (8 * scale + pad)
        lab = labels[k] if labels else ''
        d.text((2, y + 3), f'banda {k}: tiles {ft:03X}-{ft+band_w-1:03X}  {lab}', fill=(255, 255, 0))
        im.paste(b, (0, y + pad))
    im.save(out)
    return out
