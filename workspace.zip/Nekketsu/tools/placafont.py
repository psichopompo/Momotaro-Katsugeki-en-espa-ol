"""placafont.py - ESTUDIO. Diseno de PLACA con ancho variable por letra.

Principio: NO se escala horizontalmente (eso destruiria el trazo de 1 px).
Se REDISTRIBUYE el ancho: cada letra recibe el minimo numero de columnas que
su forma necesita para seguir siendo inequivoca, y el avance es por letra.

Analisis de coste por letra (mayusculas, trazo 1 px):
  I  -> 1 col basta (barra vertical). Con serifas necesitaria 3.
  L  -> 3 cols: vertical + pie. Con 2 el pie es un pixel: ambiguo con I.
  P  -> 3 cols: vertical + cuenco cerrado de 2.
  C  -> 3 cols: no puede bajar de 3 sin cerrarse y parecer O/G.
  A  -> 3 cols: dos diagonales + travesano.
"""

# '#' tinta, '.' fondo. Cada glifo declara su propio ancho.
V = {
'P': ["##.",
      "#.#",
      "#.#",
      "##.",
      "#..",
      "#..",
      "#.."],
'L': ["#..",
      "#..",
      "#..",
      "#..",
      "#..",
      "#..",
      "###"],
'A': [".#.",
      "#.#",
      "#.#",
      "###",
      "#.#",
      "#.#",
      "#.#"],
'C': [".##",
      "#..",
      "#..",
      "#..",
      "#..",
      "#..",
      ".##"],
'I': ["#",
      "#",
      "#",
      "#",
      "#",
      "#",
      "#"],
'O': [".#.",
      "#.#",
      "#.#",
      "#.#",
      "#.#",
      "#.#",
      ".#."],
'K': ["#.#",
      "#.#",
      "##.",
      "##.",
      "#.#",
      "#.#",
      "#.#"],
'S': [".##",
      "#..",
      "#..",
      ".#.",
      "..#",
      "..#",
      "##."],
'T': ["###",
      ".#.",
      ".#.",
      ".#.",
      ".#.",
      ".#.",
      ".#."],
'E': ["###",
      "#..",
      "#..",
      "##.",
      "#..",
      "#..",
      "###"],
'F': ["###",
      "#..",
      "#..",
      "##.",
      "#..",
      "#..",
      "#.."],
'N': ["#.#",
      "###",
      "###",
      "#.#",
      "#.#",
      "#.#",
      "#.#"],
'D': ["##.",
      "#.#",
      "#.#",
      "#.#",
      "#.#",
      "#.#",
      "##."],
'R': ["##.",
      "#.#",
      "#.#",
      "##.",
      "#.#",
      "#.#",
      "#.#"],
'U': ["#.#",
      "#.#",
      "#.#",
      "#.#",
      "#.#",
      "#.#",
      ".#."],
}

KERN = 1     # 1 px entre letras: minimo para que no se fundan

def word_width(word, kern=KERN):
    return sum(len(V[c][0]) for c in word) + kern*(len(word)-1)

def render(word, kern=KERN):
    """Devuelve matriz de 7 filas x width, con True donde hay tinta."""
    W = word_width(word, kern)
    px = [[False]*W for _ in range(7)]
    x = 0
    for c in word:
        g = V[c]; w = len(g[0])
        for y in range(7):
            for dx in range(w):
                if g[y][dx] == '#':
                    px[y][x+dx] = True
        x += w + kern
    return px

def show(word, kern=KERN):
    px = render(word, kern)
    return '\n'.join(''.join('#' if b else '.' for b in row) for row in px)

if __name__ == '__main__':
    print('=== anchos por letra ===')
    for c in 'PLACA':
        print(f'  {c} -> {len(V[c][0])} px')
    w = word_width('PLACA')
    print(f'\nPLACA con kern={KERN}: {w} px')
    print(show('PLACA'))
    print()
    for gap in (1,2,3):
        tot = w*2 + gap
        print(f'PLACA + {gap}px + PLACA = {tot} px   (disponible 56)  '
              f'{"CABE, sobran %d px"%(56-tot) if tot<=56 else "NO CABE, faltan %d px"%(tot-56)}')
