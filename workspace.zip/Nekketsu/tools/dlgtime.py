"""dlgtime.py - mide la linea de tiempo real de los dialogos de escena.

Modelo descubierto (ver investigation.md, seccion "Intérprete de actores"):

  El diálogo NO lo dispara un temporizador de texto. Lo dispara el mismo
  script que anima a los personajes, mediante la orden FF08:

     00F8C6: addq.l #$2,a0
     00F8C8: move.w (a0)+,d1      ; indice de bloque
     00F8CE: move.w d1,$f940.w    ; <-- dispara el dialogo

  Cada FF08 abre una RANURA que dura hasta el siguiente FF08. Dentro de la
  ranura el motor hace DOS pasadas (0x00582C togglea el modo $e(a6)):

     pasada 0 (modo 0) : bloque 41, 60 espacios -> BORRA el panel
     pasada 1 (modo 1) : el texto real

  ranura = borrado + tecleo + VISIBLE

  Y el punto critico (0x005846): si llega un FF08 nuevo mientras $c(a6) != 0
  (todavia tecleando), la peticion se IGNORA -> el dialogo se SALTA.
  Eso, y no otra cosa, es lo que hacia desaparecer 'MISAKO: Encantada'
  cuando los bloques iban rellenos de espacios.

Consecuencia de diseño: el tiempo de lectura no se puede alargar por encima
de la ranura sin tocar la animacion. Lo que SI se puede hacer sin rozar el
"acting" es acelerar el tecleo, que convierte tiempo de escritura en tiempo
de lectura dentro de la misma ranura.
"""
import sys
sys.path.insert(0, '/home/user/project/tools')
from md import MD
import dlgtext as D

ROM = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_5.md'

# move.w #$2,$12(a6) -> el valor inmediato esta en 0x0058B0 (NO en 0x0058B2,
# ahi va el desplazamiento 0012). Error cometido y corregido en la v1.5.
DELAY_IMM = 0x0058B0
DELAY_CHK = 0x0058B2

ERASE_BLOCK = 0x29          # 41: el bloque de borrado (0x005876)


def block_text(rom, idx):
    p = int.from_bytes(rom[0x80020 + idx * 4:0x80024 + idx * 4], 'big')
    if p == 0xFFFFFFFF or p >= len(rom):
        return '(sin puntero)'
    try:
        c, f, lines, n = D.read_block(rom, p)
        t = ' | '.join(l.strip() for l in lines if l.strip())
        return t or '(vacio)'
    except Exception:
        return '(?)'


def measure(rom_path=ROM, delay=None, frames=3600):
    """Devuelve la lista de episodios de dialogo con sus tiempos."""
    rom = open(rom_path, 'rb').read()
    m = MD(rom_path)
    if delay is not None:
        assert m.peek16(DELAY_CHK) == 0x0012, 'estructura inesperada'
        m.poke16(DELAY_IMM, delay)

    samples = []
    prev = None
    for f in range(frames):
        m.run(1)
        st = (m.w16(0xf940), m.w16(0xf94c), m.w16(0xf94e), m.w16(0xf950))
        if st != prev:
            samples.append((f,) + st)
            prev = st
    del m

    # reconstruir: cada bloque != 41 es un dialogo; busy = $f94c
    eps = []
    cur = None
    for f, flag, busy, mode, blq in samples:
        if blq == ERASE_BLOCK:
            if cur is not None and cur['erase'] is None:
                cur['erase'] = f
            continue
        if cur is None or cur['blq'] != blq:
            if cur:
                eps.append(cur)
            cur = {'blq': blq, 'start': f, 'typed': None, 'erase': None}
        if busy == 0 and cur['typed'] is None and f > cur['start']:
            cur['typed'] = f
    if cur:
        eps.append(cur)

    out = []
    for e in eps:
        if e['typed'] is None:
            continue
        fin = e['erase'] if e['erase'] else e['typed']
        out.append({
            'blq': e['blq'],
            'teclea': e['typed'] - e['start'],
            'visible': max(0, fin - e['typed']),
            'texto': block_text(rom, e['blq']),
        })
    return out


def report(delay=None, frames=3600, rom_path=ROM):
    eps = measure(rom_path, delay, frames)
    d = 'original (2)' if delay is None else str(delay)
    print(f'=== CHAR_DELAY = {d}   ({len(eps)} dialogos vistos)')
    print(f"{'blq':>4} {'teclea':>7} {'VISIBLE':>8} {'seg':>6}  texto")
    for e in eps:
        print(f"{e['blq']:4d} {e['teclea']:7d} {e['visible']:8d} "
              f"{e['visible']/60:6.2f}  {e['texto'][:46]}")
    return eps


if __name__ == '__main__':
    d = sys.argv[1] if len(sys.argv) > 1 else None
    report(None if d in (None, 'orig') else int(d))
