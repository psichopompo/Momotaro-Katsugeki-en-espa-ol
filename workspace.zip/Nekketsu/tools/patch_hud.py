"""patch_hud.py - definicion declarativa del parche del HUD (opcion B-minima).

NO escribe nada por si mismo: expone `PLAN`, que aplican tanto el validador en
memoria como el generador de ROM. Asi lo validado y lo escrito son identicos.
"""
import sys
sys.path.insert(0, '/home/user/project/tools')
from newletters import build, SLOTS

SP = 0x8485                      # tile "espacio" del HUD
def T(idx): return 0x8440 + idx  # idx de asset -> word de tilemap

EX = {'P':0x10,'A':0x11,'U':0x12,'S':0x13,'E':0x14,'O':0x15,'K':0x16}
IDX = dict(EX); IDX.update(SLOTS)          # todas las letras disponibles

def word(ch):
    return SP if ch == ' ' else T(IDX[ch])

# --- destino de la tabla reubicada (zona libre verificada, todo 0xFF) ---
TABLE = 0x08A700
ENTRY = 16          # 3 words fila superior + 5 words fila inferior

# --- los 6 comandos, en el mismo orden que la tabla original ---
# [0] パス  [1] ドリブル  [2] シュート  [3] タックル  [4] スルー  [5] OK
COMMANDS = ['PASA', 'FINTA', 'TIRA', 'PLACA', 'CEDE', 'OK']

# --- offsets de codigo (opcion B-minima: 2 bytes) ---
OFF_D2_INF   = 0x00A572     # move.w #$2,d3-count columnas fila inferior
VAL_D2_INF   = 0x0004       # -> 5 columnas
OFF_PTRS     = 0x00A5C8     # 6 punteros long a las entradas
OFF_COORDS   = 0x00A596     # 4 entradas x (X_sup, X_inf)
OFF_PAUSA    = 0x007CBA     # tilemap "PAUSE" (5 words)

# --- reubicacion del asset HUD (no cabe in situ: +224 bytes) ---
ASSET_OLD    = 0x0286AA
ASSET_NEW    = 0x094000     # zona libre verificada (todo 0xFF)
ASSET_PTRS   = [0x0020D0, 0x005102]   # operandos de los 2 lea.l

X_INF = 3                   # x inicial fila inferior (panel util = cols 2..10)


def plan_rom_writes(rom):
    """Devuelve lista de (offset, bytes, motivo). Solo datos + 2 bytes de codigo."""
    w = []

    # 1) los 8 glifos nuevos van al asset DESCOMPRIMIDO (se recomprime aparte)

    # 2) tabla de comandos reubicada
    for e, txt in enumerate(COMMANDS):
        base = TABLE + e * ENTRY
        sup = [SP, SP, SP]
        s = txt[:5].ljust(5)
        inf = [word(c) for c in s]
        for k, ww in enumerate(sup + inf):
            w.append((base + k*2, ww.to_bytes(2, 'big'), f'cmd[{e}] "{txt}" word{k}'))

    # 3) repuntar los 6 punteros
    for e in range(6):
        w.append((OFF_PTRS + e*4, (TABLE + e*ENTRY).to_bytes(4, 'big'),
                  f'puntero cmd[{e}] -> {TABLE + e*ENTRY:06X}'))

    # 4) coordenada X de la fila inferior (4 entradas de la tabla de coords)
    for e in range(4):
        w.append((OFF_COORDS + e*4 + 2, X_INF.to_bytes(2, 'big'),
                  f'coord X inferior entrada {e} -> {X_INF}'))

    # 5) los 2 bytes de codigo: ancho de la fila inferior 3 -> 5 columnas
    w.append((OFF_D2_INF, VAL_D2_INF.to_bytes(2, 'big'),
              'd2 fila inferior: 3 -> 5 columnas'))

    # 6) PAUSE -> PAUSA (solo reordena referencias, no toca tiles)
    for k, ch in enumerate('PAUSA'):
        w.append((OFF_PAUSA + k*2, word(ch).to_bytes(2, 'big'), f'PAUSA[{k}]={ch}'))

    return w
