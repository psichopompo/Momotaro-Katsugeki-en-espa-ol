"""escuelas.py - nombres de las 13 escuelas de la pantalla de seleccion.

ESTRUCTURA (medida en la ROM):

  tabla de descriptores  0x02BD18, 13 entradas de 8 bytes:
      +0  word  ancho-1  en celdas
      +2  word  alto-1   en celdas  (siempre 2 -> 3 filas)
      +4  long  puntero al tilemap del nombre

  Los 13 tilemaps van CONTIGUOS desde 0x02BD80 hasta 0x02BFC0, ordenados por
  el mismo indice de la tabla. Cada uno son ancho*alto words leidos por filas,
  con atributo 0x8000 (prioridad).

  El ANCHO ES UN DATO, no una restriccion del motor: se puede ampliar mientras
  el nombre no invada la columna del vecino. Limites por columna:
      izquierda  cols  1..10
      centro     cols 12..21
      derecha    cols 23..31

ESTILO (medido en el NEKKETSU japones): letras de cuerpo blanco (indice F)
con contorno de 1 px (indice E) sobre fondo transparente (0). Alto util 24 px
= las 3 filas de celda.

Los tiles se alojan en el asset de la pantalla, que la v1.9 reubico a
0x0993EA. Los tiles del nombre japones quedan libres al sustituirlos.
"""

TABLA = 0x02BD18          # 13 descriptores de 8 bytes
MAPAS = 0x02BD80          # primer tilemap
FIN_MAPAS = 0x02BFC0      # limite: 288 celdas * 2 B
ATTR = 0x8000
ALTO = 3                  # filas de celda

BLANCO = 0xF
CONTORNO = 0xE
FONDO = 0x0

# columna inicial y limite derecho de cada posicion en la rejilla
COLS = {
    0: (1, 10),    # columna izquierda
    1: (12, 21),   # columna central
    2: (23, 31),   # columna derecha
}

# orden en pantalla: 3 por fila salvo el ultimo
NOMBRES = [
    'NEKKETSU', 'YUSHUIN', 'SHICHIFUKU',
    'SHIGUMA', 'MATAGI', 'YOSHIMOTO',
    'EDOBANA', 'IPPONZURI', 'OSOREZAN',
    'YAMAMOTO', 'HORIHORI', 'HATTORI',
    'SHIMANCHU',
]

# Fuente de caja alta, cuerpo de 5x7 px. Con el contorno de 1 px alrededor
# ocupa 7x9, y se dibuja centrada verticalmente en las 3 filas (24 px).
GL = {
'A': ["..###..", ".#...#.", "#.....#", "#.....#", "#######", "#.....#", "#.....#"],
'B': ["#####..", "#....#.", "#....#.", "#####..", "#....#.", "#....#.", "#####.."],
'C': ["..####.", ".#....#", "#......", "#......", "#......", ".#....#", "..####."],
'D': ["#####..", "#....#.", "#.....#", "#.....#", "#.....#", "#....#.", "#####.."],
'E': ["#######", "#......", "#......", "#####..", "#......", "#......", "#######"],
'F': ["#######", "#......", "#......", "#####..", "#......", "#......", "#......"],
'G': ["..####.", ".#....#", "#......", "#..####", "#.....#", ".#....#", "..####."],
'H': ["#.....#", "#.....#", "#.....#", "#######", "#.....#", "#.....#", "#.....#"],
'I': ["#####..", "..#....", "..#....", "..#....", "..#....", "..#....", "#####.."],
'J': ["....###", ".....#.", ".....#.", ".....#.", ".....#.", "#....#.", ".####.."],
'K': ["#....#.", "#...#..", "#..#...", "###....", "#..#...", "#...#..", "#....#."],
'L': ["#......", "#......", "#......", "#......", "#......", "#......", "#######"],
'M': ["#.....#", "##...##", "#.#.#.#", "#..#..#", "#.....#", "#.....#", "#.....#"],
'N': ["#.....#", "##....#", "#.#...#", "#..#..#", "#...#.#", "#....##", "#.....#"],
'O': ["..###..", ".#...#.", "#.....#", "#.....#", "#.....#", ".#...#.", "..###.."],
'P': ["#####..", "#....#.", "#....#.", "#####..", "#......", "#......", "#......"],
'Q': ["..###..", ".#...#.", "#.....#", "#.....#", "#...#.#", ".#...#.", "..###.#"],
'R': ["#####..", "#....#.", "#....#.", "#####..", "#..#...", "#...#..", "#....#."],
'S': ["..####.", ".#....#", "#......", "..###..", "......#", "#....#.", ".####.."],
'T': ["#######", "...#...", "...#...", "...#...", "...#...", "...#...", "...#..."],
'U': ["#.....#", "#.....#", "#.....#", "#.....#", "#.....#", ".#...#.", "..###.."],
'V': ["#.....#", "#.....#", "#.....#", ".#...#.", ".#...#.", "..#.#..", "...#..."],
'W': ["#.....#", "#.....#", "#.....#", "#..#..#", "#.#.#.#", "##...##", "#.....#"],
'X': ["#.....#", ".#...#.", "..#.#..", "...#...", "..#.#..", ".#...#.", "#.....#"],
'Y': ["#.....#", ".#...#.", "..#.#..", "...#...", "...#...", "...#...", "...#..."],
'Z': ["#######", ".....#.", "....#..", "...#...", "..#....", ".#.....", "#######"],
}

SEP = 1      # columnas de aire entre letras (antes del contorno)


def render(texto, sep=SEP):
    """Bitmap de 7 filas con el texto ('#' = cuerpo de la letra)."""
    rows = [''] * 7
    for i, ch in enumerate(texto):
        g = GL[ch]
        cols = len(g[0])
        lo = min((c for c in range(cols) for r in range(7) if g[r][c] == '#'),
                 default=0)
        hi = max((c for c in range(cols) for r in range(7) if g[r][c] == '#'),
                 default=cols - 1)
        for r in range(7):
            rows[r] += g[r][lo:hi + 1]
        if i != len(texto) - 1:
            for r in range(7):
                rows[r] += '.' * sep
    return rows


def outline(rows, w, h, x0, y0):
    """Matriz h x w de indices: cuerpo blanco + contorno de 1 px."""
    W, H = len(rows[0]), len(rows)

    def ink(x, y):
        return 0 <= y < H and 0 <= x < W and rows[y][x] == '#'

    px = [[FONDO] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            tx, ty = x - x0, y - y0
            if ink(tx, ty):
                px[y][x] = BLANCO
            else:
                vecino = any(ink(tx + dx, ty + dy)
                             for dx in (-1, 0, 1) for dy in (-1, 0, 1)
                             if (dx, dy) != (0, 0))
                if vecino:
                    px[y][x] = CONTORNO
    return px


def build(texto, ancho_celdas, sep=SEP):
    """Devuelve la matriz de indices de un nombre, de ancho*8 x 24 px."""
    w = ancho_celdas * 8
    h = ALTO * 8
    rows = render(texto, sep)
    tw, th = len(rows[0]), len(rows)
    if tw + 2 > w:
        raise ValueError(f'{texto!r}: {tw + 2} px > {w} px de caja')
    x0 = (w - tw) // 2
    y0 = (h - th) // 2
    return outline(rows, w, h, x0, y0)


def ancho_minimo(texto, sep=SEP):
    """Celdas necesarias para el texto, contando el contorno."""
    rows = render(texto, sep)
    return -(-(len(rows[0]) + 2) // 8)


def to_tiles(px, ancho_celdas):
    """Corta la matriz en tiles de 8x8, por filas."""
    out = []
    for r in range(ALTO):
        for c in range(ancho_celdas):
            blk = bytearray()
            for y in range(8):
                for xb in range(4):
                    a = px[r * 8 + y][c * 8 + xb * 2]
                    b = px[r * 8 + y][c * 8 + xb * 2 + 1]
                    blk.append((a << 4) | b)
            out.append(bytes(blk))
    return out
