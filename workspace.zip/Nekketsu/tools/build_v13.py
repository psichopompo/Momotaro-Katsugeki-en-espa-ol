"""build_v13.py - ROM v1.3: rotulo nuevo de la pantalla de titulo.

DECISION: se usa el PNG en su POSICION ORIGINAL, sin desplazar.
  - el "desalineamiento" no era un problema real: la rejilla 8x8 es fija;
  - ambas variantes necesitan ampliar la tabla de metatiles casi igual
    (26 vs 28), asi que cuadrar no ahorra nada;
  - respetar el original es fiel al diseno del usuario.

Cambios respecto a v1.2:
  1. tiles del titulo   -> asset regenerado y reubicado a 0x096000
  2. tabla de metatiles -> reubicada a 0x088600 y ampliada
  3. stream de metatiles-> regenerado in situ (0x01A008, 256 B)
  4. paleta 3           -> 4 colores nuevos en idx 10..13 (0xA3400)
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
from PIL import Image
import hud_v14 as H

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_2.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_3.md'
PNG = '/home/user/uploads/IMG_4508.PNG'

# --- direcciones verificadas ---
ASSET_OLD = 0x0A0000      # asset de tiles del titulo
PTR_ASSET = 0x000824      # operando del  lea.l $a0000,a0   (en 0x000822)
PTR_D1    = 0x00082A      # operando del  move.w #$100,d1   (en 0x000828)
# RUTA REAL del rotulo (hallada por traza de escrituras al plano A):
#   0x088030: lea.l $a3000,a0     tilemap PLANO 32x16 words (1024 B)
#   0x08803C: jsr   $7a3c         blitter generico
# La ruta de metatiles 0x19BE8/0x47E0/0x4748 pinta OTRA capa que luego queda
# SOBRESCRITA por esta. Modificarla no servia de nada: ese fue el error que
# hizo fracasar los primeros intentos.
TILEMAP   = 0x0A3000      # 32 cols x 16 filas, 1 word por celda
TM_ROWS   = 16
PAL3_ROM  = 0x0A3400      # 16 words, paleta 3 (justo tras el tilemap)
EMPTY_TILE = 0x200        # tile vacio del fondo (NO tocar)
TILE_BASE = 0x201         # primer tile USABLE: 0x200 es el vacio del fondo
# El tile 0x200 lo usa todo el fondo (cielo, gradas, publico) como relleno
# transparente, y el metatile 0 es (2000,2000,2000,2000). Sobrescribirlo
# destruye la pantalla entera. Verificado: el fondo referencia 0x200 en las
# filas 0-2 y 16-22.

# --- reubicaciones (huecos 0xFF verificados) ---
ASSET_NEW = 0x096000      # dentro de 0x095950..0x09FFFF (42672 B)

BLANK = tuple([(0, 0, 0, 0)] * 64)
USE_FLIPS = False      # sin flips: 221 tiles, cabe de sobra en 256
# La rejilla de metatiles es PAR: metafila k = filas 2k y 2k+1.
# El rotulo ocupa filas 3..15 (rango impar), asi que hay que trabajar en
# METAFILAS COMPLETAS 1..7 = filas 2..15, o el grafico sale partido.
ROW_LO, ROW_HI = 2, 15
# Escala REAL con la que el VDP (y GPGX) renderiza cada nibble de color.
# Los nibbles son PARES (0,2,4,6,8,a,c,e) y el valor RGB es nibble*0x11.
# Verificado midiendo pixel a pixel el rotulo original:
#   word 0eee -> #eeeeee   word 000e -> #ee0000   word 0e00 -> #0000ee
# Mi tabla anterior (0..255/7) estaba mal y desviaba TODOS los colores.
LEVELS = [0x00, 0x22, 0x44, 0x66, 0x88, 0xaa, 0xcc, 0xee]


def snap(c):
    return tuple(min(LEVELS, key=lambda L: abs(L - v)) for v in c[:3])


def pal_word(rgb):
    """RGB -> word CRAM.  Formato 0000 BBB0 GGG0 RRR0 (confirmado empiricamente)."""
    r, g, b = (LEVELS.index(v) for v in rgb)
    return (b << 9) | (g << 5) | (r << 1)


def load_cells(path):
    img = Image.open(path).convert('RGBA')
    px = img.load(); W, H = img.size

    def cell(r, c, fh=False, fv=False):
        k = []
        for y in range(8):
            for x in range(8):
                X = c * 8 + (7 - x if fh else x)
                Y = r * 8 + (7 - y if fv else y)
                if X >= W or Y >= H or X < 0 or Y < 0:
                    k.append((0, 0, 0, 0)); continue
                p = px[X, Y]
                k.append((snap(p) + (1,)) if p[3] > 0 else (0, 0, 0, 0))
        return tuple(k)
    return cell


def build_palette(rom):
    """Devuelve (16 words de paleta 3, dict color->indice)."""
    cur = [int.from_bytes(rom[PAL3_ROM + i * 2:PAL3_ROM + i * 2 + 2], 'big')
           for i in range(16)]
    inv = {}
    for i, w in enumerate(cur):
        b = (w >> 9) & 7; g = (w >> 5) & 7; r = (w >> 1) & 7
        inv[(LEVELS[r], LEVELS[g], LEVELS[b])] = i

    img = Image.open(PNG).convert('RGBA'); px = img.load()
    from collections import Counter
    cnt = Counter()
    for y in range(img.height):
        for x in range(img.width):
            p = px[x, y]
            if p[3] > 0:
                cnt[snap(p)] += 1

    mapping = {}
    free = [i for i in range(1, 16) if cur[i] == 0]
    for col, _ in cnt.most_common():
        if col in inv and inv[col] != 0:
            mapping[col] = inv[col]
        else:
            if not free:
                raise RuntimeError(f'sin slots libres para {col}')
            s = free.pop(0)
            cur[s] = pal_word(col)
            mapping[col] = s
    return cur, mapping


def encode_tile(key, mapping):
    """64 celdas RGBA -> 32 bytes 4bpp."""
    out = bytearray()
    for y in range(8):
        for xb in range(4):
            px = []
            for k in range(2):
                p = key[y * 8 + xb * 2 + k]
                px.append(0 if p[3] == 0 else mapping[(p[0], p[1], p[2])])
            out.append((px[0] << 4) | px[1])
    return bytes(out)


def analyse(rom):
    """Trocea el PNG y devuelve (tiles_unicos, cellref, mapping)."""
    cell = load_cells(PNG)
    _, mapping = build_palette(rom)
    canon = {}
    order = []

    def ref(r, c):
        k = cell(r, c)
        if k == BLANK:
            return None
        if USE_FLIPS:
            vs = [(cell(r, c), 0, 0), (cell(r, c, True, False), 1, 0),
                  (cell(r, c, False, True), 0, 1), (cell(r, c, True, True), 1, 1)]
            cn = min(v[0] for v in vs)
            if cn not in canon:
                canon[cn] = len(order); order.append(cn)
            for kk, fh, fv in vs:
                if kk == cn:
                    return canon[cn], fh, fv
        if k not in canon:
            canon[k] = len(order); order.append(k)
        return canon[k], 0, 0

    cellref = {(r, c): ref(r, c) for r in range(TM_ROWS) for c in range(32)}
    return order, cellref, mapping


def rom_tile0(rom):
    """32 bytes del tile 0x200 original (vacio): se conserva intacto."""
    import hudtools
    data, _, _ = hudtools.decomp(rom, ASSET_OLD, 256)
    return data[0:32]


def build_writes(rom):
    """[(offset, bytes, motivo)] con todo lo que cambia respecto a v1.2."""
    order, cellref, mapping = analyse(rom)
    w = []

    # ---- 1. asset de tiles ----
    # posicion 0 = tile vacio original (0x200), el rotulo empieza en 0x201
    tiles = bytearray(rom_tile0(rom))
    for k in order:
        tiles += encode_tile(k, mapping)
    n_tiles = len(order) + 1
    if n_tiles > 256:
        raise RuntimeError(f'{n_tiles} tiles > 256')
    blob = H.compress(bytes(tiles), header=rom[ASSET_OLD:ASSET_OLD + 4])[0]
    w.append((ASSET_NEW, blob, f'asset titulo {n_tiles} tiles ({len(blob)} B)'))
    w.append((PTR_ASSET, ASSET_NEW.to_bytes(4, 'big'), 'puntero asset titulo'))
    w.append((PTR_D1, n_tiles.to_bytes(2, 'big'), f'd1 = {n_tiles} tiles'))

    # ---- 2. tilemap plano ----
    tm = bytearray(rom[TILEMAP:TILEMAP + TM_ROWS * 64])
    for r in range(TM_ROWS):
        for c in range(32):
            q = cellref.get((r, c))
            if q is None:
                word = 0x6000 | EMPTY_TILE
            else:
                ti, fh, fv = q
                word = 0x6000 | (fv << 12) | (fh << 11) | (TILE_BASE + ti)
            tm[r * 64 + c * 2]     = (word >> 8) & 0xFF
            tm[r * 64 + c * 2 + 1] = word & 0xFF
    w.append((TILEMAP, bytes(tm), 'tilemap plano del titulo (32x16)'))

    # ---- 3. paleta 3 ----
    pal, _ = build_palette(rom)
    w.append((PAL3_ROM, b''.join(x.to_bytes(2, 'big') for x in pal),
              'paleta 3'))
    return w


def main():
    rom = bytearray(open(SRC, 'rb').read())
    writes = build_writes(bytes(rom))
    touched = set()
    for off, b, _ in writes:
        for k in range(len(b)):
            touched.add(off + k)
        rom[off:off + len(b)] = b
    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF
    open(DST, 'wb').write(bytes(rom))
    print(f'destino : {DST}')
    print(f'  md5   : {hashlib.md5(rom).hexdigest()}')
    print(f'escrituras   : {len(writes)}')
    print(f'bytes tocados: {len(touched)}')
    for off, b, why in writes:
        print(f'  {off:#08x}  {len(b):>6} B  {why}')


if __name__ == '__main__':
    main()
