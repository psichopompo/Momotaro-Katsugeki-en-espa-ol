import sys, os, random
sys.path.insert(0,'/home/user/project/tools')
from md import MD
import shot_font as S
import shot_run as R

# tiles de letra en VRAM (v1.1): 540-54C nuevos + 455(O) 456(K) originales
LET = set(range(0x540,0x54D)) | {0x455,0x456}

def wbe(v,r,c):
    o=0xc000+r*0x80+c*2
    return (v[o^1]<<8)|v[(o+1)^1]

def rowtiles(v,r):
    return [wbe(v,r,c)&0x7FF for c in range(32)]

def score(v):
    """cuantas celdas de letra hay dibujadas en las filas del HUD"""
    n=0
    for r in (23,24,25,26):
        n += sum(1 for t in rowtiles(v,r) if t in LET)
    return n

def hunt(m, tag, outdir, want=8, budget=4000, seed=7):
    os.makedirs(outdir, exist_ok=True)
    rnd=random.Random(seed)
    best={}   # firma -> (score, frame)
    saved=0
    for i in range(budget):
        if i%5==0:   m.press(rnd.choice(['A','B','C']), rnd.choice(['RIGHT','LEFT','UP','DOWN']))
        elif i%5==2: m.release()
        m.run(1)
        if i%2: continue
        v=m.vram()
        s=score(v)
        if s>=4:
            sig=tuple(rowtiles(v,26)[:32])
            if sig not in best:
                best[sig]=(s,m.frame)
                saved+=1
                m.save_png(f'{outdir}/{tag}_{saved:02d}.png')
                if saved>=want: break
    return saved, best

if __name__=='__main__':
    which, out = sys.argv[1], sys.argv[2]
    m=MD(S.ROM)
    if which=='cond': S.apply_cond(m)
    R.boot(m)
    n,best=hunt(m, which, out)
    print(which,'shots',n)
    for sig,(s,f) in best.items():
        print(' f=%d score=%d'%(f,s))
