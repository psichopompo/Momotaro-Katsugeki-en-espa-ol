"""dlgtext.py - codec y reformateo de los dialogos de las escenas.

Formato descubierto (ver investigation.md):
  bloques de 126 bytes desde 0x08027E
    word 0    : columna base (1)
    word 1    : fila base (0x18)
    words...  : caracteres
    0x8000    : salto de linea
    0xFFFF    : fin de bloque

Codec (verificado contra VRAM y contra el render de la fuente):
  0x3F        -> espacio        (NO 0x00: 0x00 tambien es un blanco pero el
                                 juego usa 0x3F en todos los dialogos)
  0x01..0x3E  -> ASCII (t + 0x20)   digitos, signos, ':' etc.
  0x21..0x3A  -> 'A'..'Z'
  0x50, 0x51  -> '¿', '¡'
  0x52..0x57  -> 'A','E','I','O','U','N' acentuadas mayusculas
  0x80..0x99  -> 'a'..'z'  (t - 0x1F)
  0x9A..0x9F  -> 'á','é','í','ó','ú','ñ'
"""

BASE   = 0x08027E
END_OF_TABLE = 0x0827B6      # primer word que ya no es cabecera valida
# Los bloques NO son todos de 126 B: hay de 56, 66, 126 y uno de 186.
# Hay que recorrerlos secuencialmente siguiendo el terminador 0xFFFF.
STRIDE = None

SP  = 0x3F
# True  -> rellenar con espacios (duracion original, texto lento)
# False -> sin relleno (texto rapido; la duracion la da el retardo por char)
PAD_FULL = True
NL  = 0x8000
END = 0xFFFF

# --- tabla de decodificacion ---
_SPECIAL = {
    # 0x4B: corazon. Codigo elegido porque (a) no lo usa ninguno de los 86
    # bloques de texto, (b) su tile en la hoja de fuente 0x90000 esta VACIO,
    # y (c) los diagonos se pintan con atributo 0x0000 (paleta 0) mientras
    # que el unico uso de 0x4B en pantalla es 0x204B (paleta 1), otro juego
    # de graficos. Verificado en emulador sobre 7.400 frames.
    0x4B: '\u2665',
    0x50: '\u00bf', 0x51: '\u00a1',
    0x52: '\u00c1', 0x53: '\u00c9', 0x54: '\u00cd',
    0x55: '\u00d3', 0x56: '\u00da', 0x57: '\u00d1',
    0x9A: '\u00e1', 0x9B: '\u00e9', 0x9C: '\u00ed',
    0x9D: '\u00f3', 0x9E: '\u00fa', 0x9F: '\u00f1',
}
_REV = {v: k for k, v in _SPECIAL.items()}


def dec(w):
    if w == SP:
        return ' '
    if w in _SPECIAL:
        return _SPECIAL[w]
    if w < 0x3F:
        return chr(w + 0x20)
    if 0x80 <= w <= 0x99:
        return chr(w - 0x1F)
    return '\ufffd'


def enc(ch):
    if ch == ' ':
        return SP
    if ch in _REV:
        return _REV[ch]
    o = ord(ch)
    if 0x20 <= o < 0x5F:
        return o - 0x20
    if 0x61 <= o <= 0x7A:
        return o + 0x1F
    raise ValueError(f'caracter no representable: {ch!r}')


def read_block(rom, addr):
    """Devuelve (col, fila, [lineas], words_usados)."""
    col = int.from_bytes(rom[addr:addr + 2], 'big')
    fila = int.from_bytes(rom[addr + 2:addr + 4], 'big')
    i = addr + 4
    lines = ['']
    n = 0
    while n < 200:
        w = int.from_bytes(rom[i:i + 2], 'big')
        i += 2
        n += 1
        if w == END:
            break
        if w == NL:
            lines.append('')
            continue
        lines[-1] += dec(w)
    return col, fila, lines, n


def write_block(col, fila, lines, capacity):
    """Serializa el bloque; debe caber en `capacity` bytes exactos."""
    out = bytearray()
    out += col.to_bytes(2, 'big')
    out += fila.to_bytes(2, 'big')
    for k, L in enumerate(lines):
        if k:
            out += NL.to_bytes(2, 'big')
        for ch in L:
            out += enc(ch).to_bytes(2, 'big')
    out += END.to_bytes(2, 'big')
    if capacity is not None:
        if len(out) > capacity:
            raise ValueError(f'bloque de {len(out)} B > {capacity}')
        # Relleno con ESPACIOS antes del END, nunca 0xFF despues:
        #  - 0xFFFF es el terminador de la tabla y romperia el recorrido
        #    secuencial de los 86 bloques;
        #  - el motor tarda 3 frames por word, asi que el relleno determina
        #    CUANTO TIEMPO permanece el dialogo en pantalla. Manteniendo el
        #    bloque lleno se conserva la duracion original.
        pad = (capacity - len(out)) // 2
        if PAD_FULL and pad:
            out = out[:-2] + SP.to_bytes(2, 'big') * pad + END.to_bytes(2, 'big')
        elif pad:
            # sin relleno: se repite el END hasta llenar. El recorrido
            # secuencial para en el primer END, que es el bueno.
            out = out + END.to_bytes(2, 'big') * pad
        if len(out) < capacity:
            out += b'\x00' * (capacity - len(out))
    return bytes(out)


def _is_header(rom, a):
    col = int.from_bytes(rom[a:a + 2], 'big')
    fila = int.from_bytes(rom[a + 2:a + 4], 'big')
    return col <= 8 and fila in (0x16, 0x17, 0x18, 0x19, 0x1a)


def block_spans(rom):
    """[(addr, tamano_en_bytes)] recorriendo la tabla secuencialmente.

    El tamano incluye el RELLENO que sigue al terminador, porque es capacidad
    reutilizable del bloque.

    Los bloques se rellenan tras el END con words neutros (0x0000 o 0xFFFF).
    Antes esta funcion asumia que el siguiente bloque empezaba justo despues
    del primer END, y en cuanto una ROM llevaba relleno solo encontraba UN
    bloque (defecto real medido en la v1.5: 1 de 86). Ahora el relleno se
    salta explicitamente hasta dar con la siguiente cabecera valida.
    """
    out = []
    a = BASE
    while a < END_OF_TABLE:
        if not _is_header(rom, a):
            break
        i = a + 4
        g = 0
        while g < 200 and i < END_OF_TABLE:
            w = int.from_bytes(rom[i:i + 2], 'big')
            i += 2
            g += 1
            if w == END:
                break
        # saltar el relleno neutro que pueda seguir al terminador
        j = i
        while j < END_OF_TABLE and not _is_header(rom, j):
            w = int.from_bytes(rom[j:j + 2], 'big')
            if w not in (0x0000, END):
                break
            j += 2
        out.append((a, j - a))
        a = j
    return out


def all_blocks(rom):
    return [(a,) + read_block(rom, a) + (sz,) for a, sz in block_spans(rom)]
