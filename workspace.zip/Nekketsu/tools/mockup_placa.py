"""mockup_placa.py - MAQUETA a tamano real sobre una captura REAL del juego.

No toca la ROM ni el emulador: compone pixeles sobre el PNG capturado,
respetando la paleta y la rejilla reales del panel.
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
from PIL import Image
from placafont import V, word_width, KERN, render

# colores REALES leidos de la captura
INK  = (255,255,255)     # indice 15
BG   = None              # se toma del propio panel (no se pinta)

# geometria medida
ROW_Y   = 208            # fila 26 -> y = 26*8 = 208
PANEL_L = 4*8            # col 4  -> x = 32
PANEL_R = 21*8           # col 21 -> x = 168
AVAIL   = 56             # 7 celdas

def clear_band(im, x0, w=AVAIL, y0=ROW_Y, h=8):
    """Borra la banda de texto tomando el color de fondo del propio panel."""
    bg = im.getpixel((x0+w-2, y0+7))     # esquina interior: fondo del panel
    for y in range(y0, y0+h):
        for x in range(x0, x0+w):
            im.putpixel((x,y), bg)
    return bg

def draw_word(im, word, x0, y0=ROW_Y, kern=KERN, ink=INK):
    px = render(word, kern)
    for y,row in enumerate(px):
        for x,b in enumerate(row):
            if b:
                im.putpixel((x0+x, y0+y), ink)
    return word_width(word, kern)

def compose(src, dst, gap=18):
    im = Image.open(src).convert('RGB')
    W = word_width('PLACA')
    for x0 in (PANEL_L, PANEL_R):
        clear_band(im, x0)
        draw_word(im, 'PLACA', x0)
        draw_word(im, 'PLACA', x0 + W + gap)
    im.save(dst)
    return W, gap

if __name__ == '__main__':
    src = '/home/user/project/work/shots/placa/actual_f2411.png'
    for gap,name in ((18,'max'),(4,'min')):
        W,g = compose(src, f'/home/user/project/work/shots/mock_{name}.png', gap)
        print(f'gap={g:2} px  ->  2x PLACA({W}) = {2*W+g} px de 56  '
              f'work/shots/mock_{name}.png')
