"""build_v18.py - ROM v1.8: fuente romanica del menu + cinta verde del rotulo.

Parte de la v1.7 y aplica DOS cambios, ambos verificados en emulador.

--------------------------------------------------------------------------
CAMBIO 1 (4 bytes) - restaurar la fuente romanica en la pantalla de titulo
--------------------------------------------------------------------------
  0x000842: 00091100 -> 0002767A

El juego escribe los MISMOS codigos de tile en ambas versiones; lo que
cambia es el juego de tiles cargado en VRAM 0. La traduccion v0.9.8 repunto
este cargador a la fuente de dialogos.

  JP    000840: lea.l $2767a,a0     fuente romanica (serif, trazo 2 px)
  v1.7  000840: lea.l $91100,a0     nuestra fuente de dialogos

La romanica sigue INTACTA en 0x02767A, byte a byte identica a la japonesa
(8192 B descomprimidos, 4080 B comprimidos). Cobertura verificada: tiene
glifo para todos los caracteres de INICIO, OPCIONES, TORNEO 1J, TORNEO 2J,
DUELO 2J, CLAVE y los dos copyright, incluido el simbolo (C).

ALCANCE: el cargador solo se ejecuta con $f800 = 0x08, que es la pantalla de
titulo Y el menu principal (son el mismo estado). El usuario lo aprueba
expresamente: "forman parte del mismo menu, lo raro seria que fuera
cambiando".

--------------------------------------------------------------------------
CAMBIO 2 - cinta verde del rotulo de la sala del club
--------------------------------------------------------------------------
La v1.7 elimino el rotulo japones del stream de la escena, y con el se fue
la BANDEROLA VERDE sobre la que iba, porque ambos compartian las metafilas
1 y 2. El hook 0x08C040 solo pintaba texto plano.

Se reconstruye la cinta con los tiles ORIGINALES del juego, que siguen en el
asset de la escena:

  0x12E  borde diagonal izquierdo     0x15C  borde diagonal derecho
  0x1BF  relleno liso (verde)         0x100  fondo de la escena

Geometria medida en la japonesa (plano A, filas 3..5, cols 4..27, trapecio
que se ensancha 1 celda por lado y fila):

  fila 3: cols  6..25      fila 4: cols  5..26      fila 5: cols  4..27

El texto castellano va en la fila 4 (20 celdas interiores para 18 tiles),
con el mismo relieve del original: trazo blanco (F) y sombra (E) al
inferior-derecha sobre fondo de cinta (B).

Los 18 tiles nuevos se alojan en el asset de la escena 0x068CBE, que carga a
VRAM 0x2000 (tile base 0x100). Indices libres verificados: 0x0C6..0x103.
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D
import rotulo as R
import cinta as C
import hud_v14 as H
from hudtools import decomp

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_7.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_8.md'

# --- cambio 1 -------------------------------------------------------------
FONT_PTR = 0x000842
FONT_OLD = 0x091100
FONT_ROM = 0x02767A          # fuente romanica original

# --- cambio 2 -------------------------------------------------------------
SCENE_ASSET = 0x068CBE       # asset de la sala del club, 512 tiles
SCENE_BASE = 0x100           # VRAM tile base: asset idx = tile - 0x100
SCENE_NEW = 0x0972AE         # hueco libre para reubicar el asset de escena
SCENE_PTR = 0x017770         # tabla 0x17750, entrada f806=0x04, campo +0x00
TEXT_IDX0 = 0x0C6            # primer indice libre del asset
ROT_MAP = 0x08C100           # tilemap del rotulo
ROT_COL = 0x08C05C           # inmediato: columna inicial
ROT_ROW = 0x08C060           # inmediato: fila
ROT_W = 0x08C064             # inmediato: ancho-1
ROT_H = 0x08C068             # inmediato: alto-1
ROT_TEXT = 'CLUB DE DODGEBALL'
HEART = '\u2665'


def patch_font(rom):
    got = int.from_bytes(rom[FONT_PTR:FONT_PTR + 4], 'big')
    if got != FONT_OLD:
        raise RuntimeError(f'{FONT_PTR:#08x}: esperaba {FONT_OLD:#08x}, hay {got:#08x}')
    # comprobar que la romanica sigue donde debe
    d, end, _ = decomp(bytes(rom), FONT_ROM, 256)
    if len(d) != 8192:
        raise RuntimeError(f'la fuente romanica de {FONT_ROM:#08x} no descomprime bien')
    for ch in 'INICOPESTORNEUDLAV0129.':
        t = D.enc(ch)
        if not any(d[t * 32:(t + 1) * 32]):
            raise RuntimeError(f'la romanica no tiene glifo para {ch!r}')
    rom[FONT_PTR:FONT_PTR + 4] = FONT_ROM.to_bytes(4, 'big')
    return FONT_OLD, FONT_ROM


def build_cinta(rom):
    """Devuelve (blob_tilemap, tiles_nuevos, n)."""
    R.SEP, R.SPACE = 1, 5
    rows = R.render(ROT_TEXT)
    tiles = R.to_tiles(rows)
    n = len(tiles)
    idx = [TEXT_IDX0 + i for i in range(n)]

    # comprobar que esos indices del asset estan vacios
    data, end, _ = decomp(bytes(rom), SCENE_ASSET, 512)
    for i in idx:
        if any(data[i * 32:(i + 1) * 32]):
            raise RuntimeError(f'el indice {i:#05x} del asset NO esta vacio')

    # tiles de VRAM que referenciara el tilemap
    vram_tiles = [SCENE_BASE + i for i in idx]
    m = C.build_map(vram_tiles, row_text=4)
    return C.flatten(m), (data, idx, tiles), n


def main():
    rom = bytearray(open(SRC, 'rb').read())
    print(f'origen : {SRC}\n  md5  : {hashlib.md5(rom).hexdigest()}\n')

    # --- 1. fuente romanica ---------------------------------------------
    old, new = patch_font(rom)
    print(f'1) fuente del titulo y menu: {FONT_PTR:#08x}  {old:#08x} -> {new:#08x}')
    print('   afecta a INICIO, OPCIONES, TORNEO 1J/2J, DUELO 2J, CLAVE y (C)')

    # --- 2. cinta verde ---------------------------------------------------
    blob, (data, idx, tiles), n = build_cinta(rom)
    print(f'\n2) cinta verde del rotulo: {n} tiles de texto en '
          f'asset idx {idx[0]:#05x}..{idx[-1]:#05x}')

    # tilemap: 3 filas x 24 columnas desde la columna 4, fila 3
    for off, val, nm in ((ROT_COL, 4, 'columna'), (ROT_ROW, 3, 'fila'),
                         (ROT_W, 23, 'ancho-1'), (ROT_H, 2, 'alto-1')):
        prev = int.from_bytes(rom[off:off + 2], 'big')
        rom[off:off + 2] = val.to_bytes(2, 'big')
        print(f'   {off:#08x} {nm:<8} {prev} -> {val}')
    rom[ROT_MAP:ROT_MAP + len(blob)] = blob
    print(f'   tilemap {ROT_MAP:#08x}: {len(blob)} B (3 filas x 24 cols)')

    # grabar los tiles nuevos en el asset de la escena
    big = bytearray(data)
    for i, t in zip(idx, tiles):
        big[i * 32:(i + 1) * 32] = C.encode_tile(t)
    hdr = bytes(rom[SCENE_ASSET:SCENE_ASSET + 4])
    comp = H.compress(bytes(big), header=hdr)[0]
    _, end, _ = decomp(bytes(rom), SCENE_ASSET, 512)
    disp = end - SCENE_ASSET
    # No cabe in situ: mi compresor es peor que el del juego (8507 B frente a
    # los 7983 del original con los mismos datos mas 18 tiles). Se REUBICA al
    # hueco libre de 0x0972AE, verificado todo a 0xFF, y se repunta el unico
    # puntero que lo referencia: la entrada f806=0x04 de la tabla 0x17750.
    if len(comp) > disp:
        room = 0x0A0000 - SCENE_NEW
        if len(comp) > room:
            raise RuntimeError(f'asset {len(comp)} B > {room} B en {SCENE_NEW:#08x}')
        if any(b != 0xFF for b in rom[SCENE_NEW:SCENE_NEW + len(comp)]):
            raise RuntimeError(f'{SCENE_NEW:#08x} no esta libre')
        rom[SCENE_NEW:SCENE_NEW + len(comp)] = comp
        if int.from_bytes(rom[SCENE_PTR:SCENE_PTR + 4], 'big') != SCENE_ASSET:
            raise RuntimeError(f'{SCENE_PTR:#08x} no apunta al asset de escena')
        rom[SCENE_PTR:SCENE_PTR + 4] = SCENE_NEW.to_bytes(4, 'big')
        print(f'   asset de escena reubicado {SCENE_ASSET:#08x} -> {SCENE_NEW:#08x}'
              f'  ({len(comp)} B; no cabia en {disp})')
        print(f'   puntero {SCENE_PTR:#08x} repuntado')
    else:
        rom[SCENE_ASSET:SCENE_ASSET + len(comp)] = comp
        print(f'   asset {SCENE_ASSET:#08x}: {len(comp)} B de {disp} disponibles')

    # --- 3. corazones en el bloque 31 (rama de DERROTA) ------------------
    # El usuario vio 'XXXX' en un dialogo de Misako ANTES de que pregunte si
    # volver a intentarlo. No es el bloque 24 (sala del club, ya corregido en
    # la v1.7) sino el 31, que pertenece a la rama de derrota:
    #   'MISAKO: ¿Vais a perder? ¿No os importan mis ****?'
    # Lo dispara la orden FF08 de 0x01175C, dentro de un script de actor de
    # la tabla 0x010BC8, que el interprete 0x00F684 selecciona cuando el
    # modo de actor ($0(a6)) vale 0x0D. Es la entrada 72 de esa tabla.
    D.PAD_FULL = False
    spans = dict(D.block_spans(bytes(rom)))
    p31 = int.from_bytes(rom[0x80020 + 31 * 4:0x80024 + 31 * 4], 'big')
    c, f, lines, _ = D.read_block(bytes(rom), p31)
    nuevas = [L.replace('****', HEART * 4) for L in lines if L.strip()]
    if nuevas == [L for L in lines if L.strip()]:
        raise RuntimeError('no se encontro **** en el bloque 31')
    blob31 = D.write_block(c, f, nuevas, spans[p31])
    rom[p31:p31 + len(blob31)] = blob31
    print(f'\n3) corazones en el bloque 31 ({p31:#08x}) - rama de derrota')
    for L in nuevas:
        print(f'      {L.strip()!r}')

    # --- checksum ---------------------------------------------------------
    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    final = bytes(rom)
    if len(D.block_spans(final)) != 86:
        raise RuntimeError('la tabla de dialogos ha dejado de ser recorrible')
    ndiff = sum(1 for a, b in zip(open(SRC, 'rb').read(), final) if a != b)
    open(DST, 'wb').write(final)
    print(f'\ndestino: {DST}')
    print(f'  md5  : {hashlib.md5(final).hexdigest()}')
    print(f'  bytes distintos respecto a la v1.7: {ndiff}')
    print('  tabla de dialogos: 86 bloques  OK')


if __name__ == '__main__':
    main()
