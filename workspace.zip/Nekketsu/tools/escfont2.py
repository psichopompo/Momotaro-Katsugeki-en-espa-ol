"""escfont2.py - FUENTE gruesa alineada a celda para los nombres de escuela.

CAMBIO DE ENFOQUE (propuesto por el usuario, 2026-07-28)
--------------------------------------------------------------------------
Hasta ahora yo renderizaba cada nombre como un BITMAP CONTINUO de 80x24 px
y luego lo troceaba en celdas de 8x8. Con eso las letras caen en posiciones
arbitrarias de la rejilla: la 'S' de SHICHIFUKU y la 'S' de SHIGUMA quedan
cortadas por sitios distintos y producen TILES DISTINTOS. Resultado medido:
146 tiles para 13 nombres, porque el coste crecia con el numero de NOMBRES.

Aqui cada letra se alinea a una celda. La 'S' es siempre los mismos tiles,
este donde este. El coste pasa a depender solo del ALFABETO.

ALFABETO NECESARIO (medido sobre los 13 nombres): 20 letras
    A B C D E F G H I K M N O P R S T U Y Z
NO hacen falta: J L Q V W X, ni N-tilde, ni vocales acentuadas.

GEOMETRIA
--------------------------------------------------------------------------
1 celda de ancho por letra (8 px). Es obligatorio: SHICHIFUKU tiene 10
letras y la columna mas estrecha de la rejilla da 10 celdas.
    cuerpo 6 px + contorno de 1 px a cada lado = 8 px exactos
Entre dos letras contiguas quedan 2 px de contorno, que es justo el aspecto
de separacion oscura que tiene el rotulo japones.

ESTILO: cuerpo blanco (0xF), contorno (0xE), trazo de 2 px.
"""

CUERPO = 0xF
CONTORNO = 0xE
FONDO = 0x0

ANCHO_CUERPO = 6
ALTO_CUERPO = 10

# 20 glifos de 6x10, trazo de 2 px
GL = {
'A': ["..##..", ".####.", "##..##", "##..##", "##..##",
      "######", "######", "##..##", "##..##", "##..##"],
'B': ["#####.", "##..##", "##..##", "##..##", "#####.",
      "#####.", "##..##", "##..##", "##..##", "#####."],
'C': [".####.", "##..##", "##..##", "##....", "##....",
      "##....", "##....", "##..##", "##..##", ".####."],
'D': ["#####.", "##..##", "##..##", "##..##", "##..##",
      "##..##", "##..##", "##..##", "##..##", "#####."],
'E': ["######", "######", "##....", "##....", "#####.",
      "#####.", "##....", "##....", "######", "######"],
'F': ["######", "######", "##....", "##....", "#####.",
      "#####.", "##....", "##....", "##....", "##...."],
'G': [".####.", "##..##", "##....", "##....", "##.###",
      "##.###", "##..##", "##..##", "##..##", ".####."],
'H': ["##..##", "##..##", "##..##", "##..##", "######",
      "######", "##..##", "##..##", "##..##", "##..##"],
'I': ["######", "######", "..##..", "..##..", "..##..",
      "..##..", "..##..", "..##..", "######", "######"],
'K': ["##..##", "##.##.", "####..", "###...", "###...",
      "####..", "##.##.", "##..##", "##..##", "##..##"],
'M': ["##..##", "######", "######", "##..##", "##..##",
      "##..##", "##..##", "##..##", "##..##", "##..##"],
'N': ["##..##", "###.##", "###.##", "###.##", "###.##",
      "##.###", "##.###", "##.###", "##..##", "##..##"],
'O': [".####.", "##..##", "##..##", "##..##", "##..##",
      "##..##", "##..##", "##..##", "##..##", ".####."],
'P': ["#####.", "##..##", "##..##", "##..##", "#####.",
      "#####.", "##....", "##....", "##....", "##...."],
'R': ["#####.", "##..##", "##..##", "##..##", "#####.",
      "#####.", "##.##.", "##.##.", "##..##", "##..##"],
'S': [".####.", "##..##", "##....", "##....", ".####.",
      "..###.", "....##", "....##", "##..##", ".####."],
'T': ["######", "######", "..##..", "..##..", "..##..",
      "..##..", "..##..", "..##..", "..##..", "..##.."],
'U': ["##..##", "##..##", "##..##", "##..##", "##..##",
      "##..##", "##..##", "##..##", "##..##", ".####."],
'Y': ["##..##", "##..##", "##..##", ".####.", "..##..",
      "..##..", "..##..", "..##..", "..##..", "..##.."],
'Z': ["######", "######", "....##", "...##.", "..##..",
      "..##..", ".##...", "##....", "######", "######"],
}


def _check():
    for ch, g in GL.items():
        assert len(g) == ALTO_CUERPO, (ch, len(g))
        for r in g:
            assert len(r) == ANCHO_CUERPO, (ch, r)


_check()


def glifo(ch, filas_celda):
    """Matriz 8 x (filas_celda*8) de indices de color, con contorno.

    El cuerpo (6x10) se contornea a 8x12 y se centra verticalmente en la
    caja de filas_celda*8 px. Con filas_celda=2 (16 px) quedan 2 px de aire
    arriba y abajo; con 3 (24 px), 6 px.
    """
    h = filas_celda * 8
    w = 8
    g = GL[ch]
    y0 = (h - (ALTO_CUERPO + 2)) // 2      # +2 = contorno arriba y abajo
    x0 = 1                                  # contorno izquierdo

    def ink(x, y):
        return 0 <= y < ALTO_CUERPO and 0 <= x < ANCHO_CUERPO and g[y][x] == '#'

    px = [[FONDO] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            tx, ty = x - x0, y - y0 - 1
            if ink(tx, ty):
                px[y][x] = CUERPO
            elif any(ink(tx + dx, ty + dy)
                     for dx in (-1, 0, 1) for dy in (-1, 0, 1)
                     if (dx, dy) != (0, 0)):
                px[y][x] = CONTORNO
    return px


def a_tiles(px):
    """Corta una columna de 8 px de ancho en tiles de 8x8 (de arriba abajo)."""
    out = []
    for r in range(len(px) // 8):
        blk = bytearray()
        for y in range(8):
            fila = px[r * 8 + y]
            for xb in range(4):
                blk.append((fila[xb * 2] << 4) | fila[xb * 2 + 1])
        out.append(bytes(blk))
    return out


def banco(filas_celda):
    """dict letra -> lista de tiles (uno por fila de celda)."""
    return {ch: a_tiles(glifo(ch, filas_celda)) for ch in GL}


ALFABETO = ''.join(sorted(GL))
