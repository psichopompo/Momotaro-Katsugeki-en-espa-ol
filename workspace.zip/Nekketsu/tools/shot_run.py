import sys, random
sys.path.insert(0,'/home/user/project/tools')
from md import MD
import shot_font as S

NAV = {430:['START'],435:[],700:['START'],705:[],780:['START'],785:[]}

def boot(m, upto=1700):
    nav=dict(NAV)
    for f in range(1000,1500,120): nav[f]=['START']; nav[f+5]=[]
    for f in range(upto):
        if f in nav:
            if nav[f]: m.press(*nav[f])
            else: m.release()
        m.run(1)
    m.release()

def frames_with_cmds(m, tag, outdir, nshots=6, seed=7, budget=1500):
    """Juega y guarda capturas cuando el HUD dibuja comandos."""
    import os
    os.makedirs(outdir, exist_ok=True)
    bp = m.bp_add(0x00A582)
    prev = m.bp_hits(bp)
    rnd = random.Random(seed)
    saved = 0
    for i in range(budget):
        if i % 7 == 0:
            m.press(rnd.choice(['A','B','C']), rnd.choice(['RIGHT','LEFT','UP','DOWN']))
        elif i % 7 == 3:
            m.release()
        m.run(1)
        h = m.bp_hits(bp)
        if h > prev + 2:
            prev = h
            saved += 1
            m.save_png(f'{outdir}/{tag}_{saved:02d}.png')
            if saved >= nshots: break
    return saved

if __name__ == '__main__':
    which = sys.argv[1]
    out   = sys.argv[2]
    m = MD(S.ROM)
    if which == 'cond':
        S.apply_cond(m)
    boot(m)
    n = frames_with_cmds(m, which, out)
    print(which, 'shots', n, 'frame', m.frame)
