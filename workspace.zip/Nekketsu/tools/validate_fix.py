"""validate_fix.py - Validacion del fix de 1 byte en los 13 partidos.

TODO ocurre en memoria del emulador. El fichero .md NUNCA se modifica
(se verifica por md5 en cada ejecucion).

Metodo: se navega hasta la presentacion y se fuerza $f852 (indice de partido)
ANTES del frame 832, que es cuando 0xC4100 vuelca el banco de graficos a VRAM.
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
from md import MD
from nav import NAV_FIRST_MATCH

FIX_ADDR   = 0x0C41C2      # operando inmediato de move.w #$3,d3
FIX_OLD    = 0x0003
FIX_NEW    = 0x0002
LOAD_FRAME = 832           # 0xC4100 vuelca el banco aqui
SET_FRAME  = 820           # forzamos $f852 antes
PRESENT    = 980

MATCHES = {0:'1o', 1:'2o', 2:'3o', 9:'10o', 12:'FINAL'}


def run(match_idx, apply_fix, tag):
    md5a = hashlib.md5(open('rom/es098.md','rb').read()).hexdigest()
    m = MD('rom/es098.md', evcap=1000); m.trace(True); m.config()
    if apply_fix:
        assert m.peek16(FIX_ADDR) == FIX_OLD, 'valor original inesperado'
        m.poke16(FIX_ADDR, FIX_NEW)
    for f in range(PRESENT):
        if f in NAV_FIRST_MATCH:
            if NAV_FIRST_MATCH[f]: m.press(*NAV_FIRST_MATCH[f])
            else: m.release()
        if f == SET_FRAME:
            m.poke_wram16(0xf852, match_idx)
        m.run(1)
    png = f'work/shots/val_{tag}.png'
    m.save_png(png)
    v = m.vram()
    f852 = m.w16(0xf852)
    m.close()
    assert md5a == hashlib.md5(open('rom/es098.md','rb').read()).hexdigest(), 'ROM MODIFICADA'
    return v, png, f852


def row(v, r, n=32):
    return [(v[0xc000+r*0x80+c*2] << 8) | v[0xc000+r*0x80+c*2+1] for c in range(n)]


def analyse(v):
    """Devuelve dict con el estado de las filas relevantes."""
    return {
        'titulo': [row(v, r) for r in (3, 4, 5)],
        'fila6':  row(v, 6),
        'rival':  [row(v, r) for r in (21, 22, 23)],
        'fila20': row(v, 20),
        'fila24': row(v, 24),
    }


def is_blank(r):
    return all(c == 0 for c in r)


def tiles(r):
    return [c & 0x7ff for c in r]
