/* arena_dbg.c - instrumentation module for Genesis Plus GX
 *
 * Goal: reconstruct execution flow (call tree), attribute VDP/VRAM traffic to
 * the 68k PC that caused it, and snapshot machine state on demand.
 *
 * All logic lives in C: calling back into Python per instruction would be
 * ~700k calls/frame and unusable.
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

#include "shared.h"
#include "macros.h"
#include "debug/cpuhook.h"

/* ---------------- event record ---------------- */
/* ev.type */
enum {
  EV_EXEC = 1,     /* instruction executed (only when exec logging armed)  */
  EV_CALL = 2,     /* JSR/BSR taken: a=target, v=return addr               */
  EV_RET  = 3,     /* RTS: a=target(return to)                             */
  EV_JMP  = 4,     /* JMP/BRA long-distance tail call: a=target            */
  EV_VRAMW= 5,     /* a=vram addr, v=data                                  */
  EV_CRAMW= 6,
  EV_VSRW = 7,
  EV_VDPREG=8,     /* a=reg index, v=value                                 */
  EV_MEMW = 9,     /* 68k write inside watch range: a=addr,v=val,w=width   */
  EV_MEMR = 10,
  EV_MARK = 11,    /* host-injected marker: a=id, v=frame                  */
  EV_DMA  = 12,    /* DMA transfer: a=dest vram addr, v=length             */
};

typedef struct {
  uint32_t type;   /* low 8 bits type, bits 8..15 width         */
  uint32_t pc;     /* PC of instruction responsible             */
  uint32_t a;
  uint32_t v;
  uint32_t frame;
  uint32_t depth;
} ev_t;

static ev_t   *evbuf = NULL;
static size_t  evcap = 0;
static size_t  evcnt = 0;
static int     evwrap = 0;        /* 1 = ring (overwrite), 0 = stop when full */
static uint32_t cur_frame = 0;

/* what to record */
static int rec_exec   = 0;   /* record every instruction                     */
static int rec_flow   = 0;   /* record call/ret/jmp                          */
static int rec_vram   = 0;
static int rec_cram   = 0;
static int rec_vdpreg = 0;
static int rec_mem    = 0;

/* exec logging restricted to [exec_lo, exec_hi] when exec_filter=1 */
static int      exec_filter = 0;
static uint32_t exec_lo = 0, exec_hi = 0xffffffff;

/* memory watch window (68k address space) */
static uint32_t mem_lo = 0xffffffff, mem_hi = 0;

/* current PC, updated on every exec hook so VDP writes can be attributed */
static uint32_t cur_pc = 0;
static uint32_t prev_pc = 0;
static int32_t  depth = 0;

/* --- breakpoints: execution stops being "armed" or a counter increments --- */
#define MAXBP 64
static uint32_t bp_addr[MAXBP];
static uint32_t bp_hits[MAXBP];
static int      bp_n = 0;
/* when bp_stop_addr is hit, arena_bp_fired is set (host polls between frames) */
static uint32_t bp_stop_addr = 0xffffffff;
static int      bp_fired = 0;
static uint32_t bp_fired_pc = 0;

/* trace enable master switch */
static int tracing = 0;

/* ---------------- helpers ---------------- */
static void push_ev(uint32_t type, uint32_t width, uint32_t pc, uint32_t a, uint32_t v)
{
  if (!evbuf) return;
  if (evcnt >= evcap) {
    if (!evwrap) return;
    evcnt = 0;
  }
  ev_t *e = &evbuf[evcnt++];
  e->type  = (type & 0xff) | (width << 8);
  e->pc    = pc;
  e->a     = a;
  e->v     = v;
  e->frame = cur_frame;
  e->depth = (uint32_t)depth;
}

/* Read a word from 68k program space without side effects (ROM / RAM only).
 * NOTE: Genesis Plus GX byteswaps both cart.rom and work_ram on
 * little-endian hosts to optimise 16-bit access, so we must go through the
 * core's own READ_WORD macro rather than indexing bytes directly. */
static uint16_t peek16(uint32_t addr)
{
  addr &= 0xfffffe;
  if (addr < 0x400000) {
    if (addr + 1 < (uint32_t)cart.romsize)
      return *(uint16_t *)(cart.rom + addr);
    return 0;
  }
  if (addr >= 0xe00000)
    return *(uint16_t *)(work_ram + (addr & 0xfffe));
  return 0;
}

/* ---------------- the hook ---------------- */
static void arena_hook(hook_type_t type, int width, unsigned int address, unsigned int value)
{
  if (!tracing) return;

  switch (type) {
  case HOOK_M68K_E: {
    prev_pc = cur_pc;
    cur_pc  = address;

    /* breakpoints */
    for (int i = 0; i < bp_n; i++) {
      if (bp_addr[i] == address) bp_hits[i]++;
    }
    if (address == bp_stop_addr && !bp_fired) { bp_fired = 1; bp_fired_pc = address; }

    if (rec_flow) {
      /* Decode the instruction we are ABOUT to execute, so we can build a
       * call tree. We only care about JSR/BSR/RTS/RTE and long branches. */
      uint16_t op = peek16(address);

      if ((op & 0xffc0) == 0x4e80) {           /* JSR <ea> */
        uint32_t tgt = 0xffffffff;
        uint16_t mode = op & 0x3f;
        if (mode == 0x39) tgt = ((uint32_t)peek16(address+2) << 16) | peek16(address+4);   /* (xxx).L */
        else if (mode == 0x38) { int16_t s = (int16_t)peek16(address+2); tgt = (uint32_t)(int32_t)s; } /* (xxx).W */
        else if (mode == 0x3a) { int16_t s = (int16_t)peek16(address+2); tgt = address + 2 + s; }      /* d16(PC) */
        push_ev(EV_CALL, 0, address, tgt, 0);
        depth++;
      }
      else if ((op & 0xff00) == 0x6100) {      /* BSR */
        uint32_t tgt;
        uint8_t d8 = op & 0xff;
        if (d8 == 0x00)      { int16_t s = (int16_t)peek16(address+2); tgt = address + 2 + s; }
        else if (d8 == 0xff) { tgt = address + 2 + (int32_t)(((uint32_t)peek16(address+2)<<16)|peek16(address+4)); }
        else                 { tgt = address + 2 + (int8_t)d8; }
        push_ev(EV_CALL, 1, address, tgt, 0);
        depth++;
      }
      else if (op == 0x4e75 || op == 0x4e73 || op == 0x4e77) { /* RTS / RTE / RTR */
        push_ev(EV_RET, 0, address, 0, 0);
        depth--;
        if (depth < 0) depth = 0;
      }
      else if ((op & 0xffc0) == 0x4ec0) {      /* JMP <ea> */
        uint32_t tgt = 0xffffffff;
        uint16_t mode = op & 0x3f;
        if (mode == 0x39) tgt = ((uint32_t)peek16(address+2) << 16) | peek16(address+4);
        else if (mode == 0x38) { int16_t s = (int16_t)peek16(address+2); tgt = (uint32_t)(int32_t)s; }
        else if (mode == 0x3a) { int16_t s = (int16_t)peek16(address+2); tgt = address + 2 + s; }
        push_ev(EV_JMP, 0, address, tgt, 0);
      }
    }

    if (rec_exec) {
      if (!exec_filter || (address >= exec_lo && address <= exec_hi))
        push_ev(EV_EXEC, 0, address, 0, 0);
    }
    break;
  }

  case HOOK_VRAM_W:
    if (rec_vram) push_ev(EV_VRAMW, width, cur_pc, address, value);
    break;
  case HOOK_CRAM_W:
    if (rec_cram) push_ev(EV_CRAMW, width, cur_pc, address, value);
    break;
  case HOOK_VSRAM_W:
    if (rec_cram) push_ev(EV_VSRW, width, cur_pc, address, value);
    break;
  case HOOK_VDP_REG:
    if (rec_vdpreg) push_ev(EV_VDPREG, width, cur_pc, address, value);
    break;
  case HOOK_M68K_W:
    if (rec_mem && address >= mem_lo && address <= mem_hi)
      push_ev(EV_MEMW, width, cur_pc, address, value);
    break;
  case HOOK_M68K_R:
    if (rec_mem && address >= mem_lo && address <= mem_hi)
      push_ev(EV_MEMR, width, cur_pc, address, value);
    break;
  default:
    break;
  }
}

/* ---------------- exported API ---------------- */
void arena_init(unsigned int capacity)
{
  if (evbuf) free(evbuf);
  evcap = capacity;
  evbuf = (ev_t *)malloc(sizeof(ev_t) * evcap);
  evcnt = 0;
  set_cpu_hook(arena_hook);
}

void arena_free(void) { if (evbuf) free(evbuf); evbuf = NULL; evcap = evcnt = 0; }

void arena_config(int exec, int flow, int vram, int cram, int vdpreg, int mem, int wrap)
{ rec_exec=exec; rec_flow=flow; rec_vram=vram; rec_cram=cram; rec_vdpreg=vdpreg; rec_mem=mem; evwrap=wrap; }

void arena_exec_filter(int on, unsigned int lo, unsigned int hi)
{ exec_filter=on; exec_lo=lo; exec_hi=hi; }

void arena_mem_window(unsigned int lo, unsigned int hi) { mem_lo=lo; mem_hi=hi; }

void arena_trace(int on) { tracing = on; }
void arena_reset_events(void) { evcnt = 0; depth = 0; }
void arena_set_frame(unsigned int f) { cur_frame = f; }
void arena_mark(unsigned int id) { push_ev(EV_MARK, 0, cur_pc, id, cur_frame); }

unsigned int arena_event_count(void) { return (unsigned int)evcnt; }
void *arena_events(void) { return evbuf; }
unsigned int arena_event_size(void) { return (unsigned int)sizeof(ev_t); }

void arena_bp_clear(void) { bp_n = 0; bp_stop_addr = 0xffffffff; bp_fired = 0; }
int  arena_bp_add(unsigned int addr)
{ if (bp_n >= MAXBP) return -1; bp_addr[bp_n]=addr; bp_hits[bp_n]=0; return bp_n++; }
unsigned int arena_bp_hits(int i) { return (i>=0 && i<bp_n) ? bp_hits[i] : 0; }
void arena_bp_stop(unsigned int addr) { bp_stop_addr = addr; bp_fired = 0; }
int  arena_bp_fired(void) { return bp_fired; }
void arena_bp_reset_fired(void) { bp_fired = 0; }

/* state access */
void *arena_get_vram(void)     { return vram; }
void *arena_get_cram(void)     { return cram; }
void *arena_get_vsram(void)    { return vsram; }
void *arena_get_work_ram(void) { return work_ram; }
void *arena_get_vdp_regs(void) { return reg; }
void *arena_get_rom(void)      { return cart.rom; }
unsigned int arena_get_romsize(void) { return (unsigned int)cart.romsize; }

unsigned int arena_get_pc(void)  { return m68k_get_reg(M68K_REG_PC); }
unsigned int arena_get_reg(int i){ return m68k_get_reg((m68k_register_t)i); }
unsigned int arena_cur_pc(void)  { return cur_pc; }

/* diagnostics */
unsigned int arena_dbg_state(int which)
{
  switch (which) {
  case 0: return tracing;
  case 1: return rec_flow;
  case 2: return (unsigned int)evcnt;
  case 3: return (unsigned int)evcap;
  case 4: return cur_pc;
  case 5: return peek16(cur_pc);
  case 6: return (unsigned int)cart.romsize;
  case 7: return peek16(0x208);
  }
  return 0xdeadbeef;
}

/* ---------------- runtime ROM poking (EMULATOR MEMORY ONLY) ----------------
 * Writes into cart.rom, the copy the CPU executes from. The ROM file on disk
 * is never touched. Used to neutralise a hook in-flight to prove causality.
 * Values are 68k-order words; cart.rom is byteswapped on LE hosts, and
 * *(uint16*)(cart.rom+addr) is exactly what the CPU fetches, so we write
 * through that same expression. */
int arena_poke16(unsigned int addr, unsigned int value)
{
  addr &= 0xfffffe;
  if (addr + 1 >= (unsigned int)cart.romsize) return -1;
  *(uint16_t *)(cart.rom + addr) = (uint16_t)value;
  return 0;
}

unsigned int arena_peek16(unsigned int addr)
{
  addr &= 0xfffffe;
  if (addr + 1 >= (unsigned int)cart.romsize) return 0xffffffff;
  return *(uint16_t *)(cart.rom + addr);
}

/* ---------------- work RAM poking (EMULATOR MEMORY ONLY) ----------------
 * work_ram is byteswapped on LE hosts, same convention as cart.rom. */
void arena_poke_wram16(unsigned int addr, unsigned int value)
{
  *(uint16_t *)(work_ram + (addr & 0xfffe)) = (uint16_t)value;
}

unsigned int arena_peek_wram16(unsigned int addr)
{
  return *(uint16_t *)(work_ram + (addr & 0xfffe));
}
