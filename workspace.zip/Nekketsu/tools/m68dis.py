"""dis.py - static 68000 disassembly helper over a ROM image (read-only)."""
import sys
from pathlib import Path
from capstone import Cs, CS_ARCH_M68K, CS_MODE_BIG_ENDIAN, CS_MODE_M68K_000

_md = Cs(CS_ARCH_M68K, CS_MODE_BIG_ENDIAN | CS_MODE_M68K_000)
_md.detail = True


def load(path):
    return Path(path).read_bytes()


def dis(rom, start, count=40, end=None):
    """Yield (addr, bytes_hex, mnemonic, op_str)."""
    n = 0
    size = (end - start) if end else max(count * 10, 64)
    for i in _md.disasm(rom[start:start + size], start):
        yield i.address, i.bytes.hex(), i.mnemonic, i.op_str
        n += 1
        if end is None and n >= count:
            break
        if end and i.address >= end:
            break


def show(rom, start, count=40, end=None, out=None):
    lines = []
    for a, b, m, o in dis(rom, start, count, end):
        lines.append(f'{a:06X}: {b:<20} {m:<10} {o}')
    s = '\n'.join(lines)
    if out:
        Path(out).write_text(s + '\n')
    return s


def jumptable(rom, addr, n):
    """Read a run of `bra.w` entries (0x60xx) used as a dispatch table."""
    out = []
    for i in range(n):
        a = addr + i * 4
        op = int.from_bytes(rom[a:a + 2], 'big')
        disp = int.from_bytes(rom[a + 2:a + 4], 'big')
        if disp >= 0x8000:
            disp -= 0x10000
        tgt = a + 2 + disp
        out.append((i, a, op, tgt))
    return out


if __name__ == '__main__':
    rom = load(sys.argv[1])
    start = int(sys.argv[2], 16)
    cnt = int(sys.argv[3]) if len(sys.argv) > 3 else 40
    print(show(rom, start, cnt))
