"""twoptr.py - ESTUDIO: esquema de DOS PUNTEROS independientes.

Idea del usuario: no hace falta una tira por combinacion. Basta con
  slot A -> puntero a palabra1, posicion propia
  slot B -> puntero a palabra2, posicion propia

HALLAZGO: la v1.1 YA tiene esa arquitectura. El trampolin 0x8A900 lee, POR
SLOT: su tabla propia ($8(a4)), su X propia ($2(a4)) y su ancho propio
($4(a4)). Solo hay que meter tiras de palabra en vez de letras sueltas.

Coste en codigo: CERO instrucciones nuevas.
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
import hud_v14 as H
from hudtools import decomp
from placafont import V, word_width, KERN, render

ROM = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_1.md'
BG, INK = 9, 15
PANEL_BG = 0x8485          # tile de fondo del panel YA existente

WORDS = ['PASA','TIRA','CEDE','PLACA','FINTA','OK']

def word_tiles_px(word):
    """Renderiza la palabra en una tira de ceil(w/8) tiles."""
    w = word_width(word)
    n = (w+7)//8
    W = n*8
    px = [[BG]*W for _ in range(8)]
    g = render(word)
    for y in range(7):
        for dx in range(len(g[0])):
            if g[y][dx]: px[y][dx] = INK
    out=[]
    for c in range(n):
        t=bytearray()
        for y in range(8):
            for xb in range(4):
                X=c*8+xb*2
                t.append((px[y][X]<<4)|px[y][X+1])
        out.append(bytes(t))
    return out, n, w

# --- catalogo: cada palabra una sola vez en el asset ---
def build_catalog():
    cat={}; tiles=[]; idx=256
    for w in WORDS:
        ts,n,px = word_tiles_px(w)
        cat[w]=(idx,n,px)
        tiles += ts; idx += n
    return cat, tiles

# --- IDs de comando del juego ---
CMD = {1:'PASA', 2:'FINTA', 3:'TIRA', 4:'PLACA', 5:'CEDE', 6:'OK'}

# LAYOUT: 7 celdas por panel (cols 4..10 izq, 21..27 der)
#   slot principal  -> 3 celdas, cols +0..+2
#   hueco           -> 1 celda,  col  +3
#   slot secundario -> 3 celdas, cols +4..+6
SLOT_W = 3
OFF_MAIN, OFF_SEC = 0, 4
ALIGN_L = 1      # desplazamiento del texto del panel IZQUIERDO
# El slot secundario izquierdo solo muestra OK (1 tile) y CEDE (2 tiles) -
# medido en 1500 muestras: OK 38.2%, vacio 34.3%, CEDE 27.5%. Nunca 3 tiles.
# Con ancho 2 termina en col 10 y no toca el borde (col 11).
SEC_W = 2

if __name__ == '__main__':
    cat,tiles = build_catalog()
    print('=== CATALOGO DE PALABRAS (cada una UNA vez) ===')
    for w in WORDS:
        i,n,px = cat[w]
        print(f'  {w:6} idx={i:3} VRAM={0x440+i:#05x}  {n} tiles  {px:2} px')
    print(f'\n  TOTAL {len(tiles)} tiles  (hueco libre 0x540-0x54F = 16) -> '
          f'{"CABE, sobran %d"%(16-len(tiles))}')
    print()
    print('=== COMBINACIONES: ¿cabe cualquier par en 7 celdas? ===')
    peor=0; peor_n=None
    for a in WORDS:
        for b in WORDS:
            wa=cat[a][2]; wb=cat[b][2]
            # posiciones reales: slot principal en col+0, secundario en col+4
            fin_a = wa                      # px desde el inicio del panel
            ini_b = OFF_SEC*8               # 32 px
            gap = ini_b - fin_a
            tot = ini_b + wb
            if gap<peor or peor_n is None:
                if peor_n is None or gap<peor: peor, peor_n = gap, (a,b)
            assert tot<=56, (a,b,tot)
    print(f'  Todas las 36 combinaciones caben en 56 px.')
    a,b = peor_n
    print(f'  Peor caso: {a} + {b}  -> separacion minima = {peor} px')


# ---------------------------------------------------------------------------
# APLICACION AL EMULADOR (estudio: solo memoria, NUNCA una ROM)
# ---------------------------------------------------------------------------
N_TILES = 269          # igualar el DMA de la v1.1 o la partida diverge
X_LEFT, X_RIGHT = 4, 21

def poke_bytes(m, off, b):
    for k in range(0,len(b)-len(b)%2,2):
        m.poke16(off+k,(b[k]<<8)|b[k+1])

def _geom(m,d6,x,cols,tbl,x_sup=None):
    """x = X del bloque INFERIOR (texto). x_sup = X del bloque SUPERIOR
    (las flechas indicadoras). Son independientes: si no se pasa x_sup se
    CONSERVA el valor original de la v1.1, para no mover las flechas."""
    b=H.COORD+d6*16
    if x_sup is not None: m.poke16(b+0,x_sup)
    m.poke16(b+2,x); m.poke16(b+4,cols-1); m.poke16(b+6,0x19)
    m.poke16(b+8,tbl>>16); m.poke16(b+10,tbl&0xFFFF); m.poke16(b+12,1)

def _fill(m, tbl, cols, cat, allowed):
    """allowed: dict id_comando -> palabra, o None para celda vacia."""
    ent=cols*2*2; base=tbl+32
    for cid in range(8):
        e=base+cid*ent
        m.poke16(tbl+cid*4, e>>16); m.poke16(tbl+cid*4+2, e&0xFFFF)
        word = allowed.get(cid)
        if word:
            i,n,_ = cat[word]
            row = [0x8440+i+k for k in range(n)] + [PANEL_BG]*(cols-n)
        else:
            row = [PANEL_BG]*cols
        for k,w in enumerate([PANEL_BG]*cols + row):
            m.poke16(e+k*2, w)

def apply(m):
    """Dos punteros independientes: cada slot elige su palabra y su posicion."""
    data,_,_ = decomp(m.rom, H.ASSET_OLD, 256)
    big = bytearray(data)
    cat, tiles = build_catalog()
    for t in tiles: big += t
    while len(big)//32 < N_TILES: big += bytes([BG*17])*32
    blob = H.compress(bytes(big), header=m.rom[H.ASSET_OLD:H.ASSET_OLD+4])[0]
    poke_bytes(m, H.ASSET_NEW, blob)
    for pd in H.D1_PTRS: m.poke16(pd+2, N_TILES)

    # todos los comandos disponibles en los dos slots de cada panel
    full = {cid:w for cid,w in CMD.items()}
    # d6=3 slot0 IZQ principal  |  d6=2 slot1 IZQ secundario
    # ALIGN_L: el panel izquierdo tiene los retratos en cols 5-6 y 9-10, pero
    # el texto arrancaba en 4 y 8 -> desfase de 1 columna. El panel derecho ya
    # esta alineado (retratos 21-22 / 25-26, texto 21 y 25). Se corrige solo
    # el izquierdo desplazando el TEXTO +1, sin tocar retratos ni sprites.
    _geom(m,3,X_LEFT +OFF_MAIN+ALIGN_L,SLOT_W,H.TBL_S0); _fill(m,H.TBL_S0,SLOT_W,cat,full)
    _geom(m,2,X_LEFT +OFF_SEC +ALIGN_L,SEC_W ,H.TBL_S1); _fill(m,H.TBL_S1,SEC_W ,cat,full)
    # d6=1 slot2 DER principal  |  d6=0 slot3 DER secundario
    _geom(m,1,X_RIGHT+OFF_MAIN,SLOT_W,H.TBL_S2); _fill(m,H.TBL_S2,SLOT_W,cat,full)
    _geom(m,0,X_RIGHT+OFF_SEC ,SLOT_W,H.TBL_S3); _fill(m,H.TBL_S3,SLOT_W,cat,full)
    return cat
