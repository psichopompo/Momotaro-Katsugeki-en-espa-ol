"""build_v17.py - ROM v1.7: corazones, rotulo nuevo y fin del parpadeo.

Parte de la v1.6 y aplica TRES cambios, todos verificados en emulador.

--------------------------------------------------------------------------
CAMBIO 1 - se elimina el rotulo japones que parpadeaba
--------------------------------------------------------------------------
El usuario observo que antes de 'SALA DEL CLUB' se ve brevemente el rotulo
japones. Medido: 18 frames (4807-4824).

CAUSA (demostrada, no supuesta): la escena la pinta 0x004C76 en el sub-estado
$f802=0x2c, a partir del stream de metatiles 0x01BBF8. El rotulo japones esta
INCRUSTADO en ese stream, en las metafilas 1 y 2. El hook de la traduccion
(0x08C000 -> 0x08C040) que borra y repinta en castellano solo entra en el
sub-estado $f802=0x5c, 18 frames despues.

En vez de adelantar el hook, se elimina el rotulo EN ORIGEN: las metafilas 1
y 2 del stream se ponen al metatile 0 (fondo). Verificado que los metatiles
0x01..0x16 son EXCLUSIVOS de esas dos metafilas: no se usan en ninguna otra
parte del mapa, asi que no se pierde nada de la escena.

  0x01BC08  32 bytes  ->  0x00

--------------------------------------------------------------------------
CAMBIO 2 - rotulo 'CLUB DE DODGEBALL'
--------------------------------------------------------------------------
Traduccion mas literal de la japonesa. El rotulo NO es texto: es un tilemap
plano en 0x08C100 que apunta a una tira de tiles pre-renderizada a media
celda. Se compone con tools/rotulo.py, reproduciendo la misma fuente de
7 px y trazo de 2 px del rotulo anterior.

  18 tiles (antes 14). El borrado limpia 24, asi que cabe.
  Se centra en columna 7 (antes 9).

  0x08C05C  columna    9  -> 7
  0x08C064  ancho-1  0x0d -> 0x11
  0x08C100  tilemap  14 words -> 18 words
  asset 0x90000: 18 tiles nuevos en 0xA0..0xAD (los 14 que ya usaba el
                 rotulo) + 0xF2..0xF5 (vacios y sin uso, verificado)

--------------------------------------------------------------------------
CAMBIO 3 - corazones en lugar de asteriscos
--------------------------------------------------------------------------
El usuario pidio restituir los corazones de la version de Famicom/NES.
(La japonesa de Mega Drive pone 'XXXX': verificado, tile 0x038 = 'X'.)

  codigo 0x4B = corazon, elegido porque:
    - no lo usa ninguno de los 86 bloques de texto
    - su tile en la hoja de fuente esta VACIO
    - los dialogos usan atributo 0x0000 (paleta 0) y el unico uso de 0x4B
      en pantalla es 0x204B (paleta 1): otro juego de graficos
  bloque 24: 'os dare **** a todos' -> 'os dare (4 corazones) a todos'
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D
import dlgfont as F
import rotulo as R
import hud_v14 as H
from hudtools import decomp

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_6.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_7.md'

FONT_ASSET = 0x90000
STREAM = 0x01BBF8            # stream de metatiles de la sala del club

# Escenas de vestuario. Mismo defecto que la sala del club pero por OTRA ruta:
# no las pinta 0x004C76 sino 0x0050B2, que elige stream segun el resultado:
#   0050BE: move.w $f8d2,d0 / cmp.w $f8d0,d0 / bcs $50d0
#   0050CA: lea.l  $241E0,a6      <- victoria
#           (si no) $23EC8        <- derrota
# El texto japones va incrustado en la METAFILA 11 (no en la 1-2 como en la
# sala del club), y el hook 0x08E040 que pinta 'VEST. NEKKETSU'/'VEST.
# YUSHUIN' no entra hasta 14 frames despues. Medido: +66 JAPO -> +80 ES.
VEST_STREAMS = (0x0240E0, 0x0243E8, 0x024770)
VEST_ROW = 11
ROT_MAP = 0x08C100           # tilemap del rotulo
ROT_COL = 0x08C05C           # inmediato: columna inicial
ROT_W = 0x08C064             # inmediato: ancho-1
ROT_TEXT = 'CLUB DE DODGEBALL'
# tiles donde se aloja el rotulo nuevo: los 14 del viejo + 4 vacios
ROT_TILES = list(range(0xA0, 0xAE)) + [0xF2, 0xF3, 0xF4, 0xF5]

HEART = '\u2665'


def kill_japanese_label(rom):
    """Metafilas 1 y 2 del stream -> metatile 0 (fondo)."""
    # comprobar que son las del rotulo antes de tocar
    fila1 = rom[STREAM + 16:STREAM + 32]
    fila2 = rom[STREAM + 32:STREAM + 48]
    if max(fila1) == 0 and max(fila2) == 0:
        raise RuntimeError('las metafilas 1 y 2 ya estan vacias')
    usados = set(fila1) | set(fila2) - {0}
    # ningun metatile del rotulo puede aparecer fuera de esas dos filas
    for r in range(16):
        if r in (1, 2):
            continue
        for b in rom[STREAM + r * 16:STREAM + r * 16 + 16]:
            if b in usados and b != 0:
                raise RuntimeError(f'metatile {b:#04x} tambien fuera del rotulo')
    rom[STREAM + 16:STREAM + 48] = b'\x00' * 32
    return 32


def kill_vest_labels(rom):
    """Metafila 11 de los tres streams de vestuario -> metatile 0."""
    total = 0
    for S in VEST_STREAMS:
        o = S + VEST_ROW * 16
        fila = rom[o:o + 16]
        if not any(fila):
            raise RuntimeError(f'{S:#08x} mf{VEST_ROW} ya esta vacia')
        usados = {b for b in fila if b}
        for r in range(16):
            if r == VEST_ROW:
                continue
            for b in rom[S + r * 16:S + r * 16 + 16]:
                if b in usados:
                    raise RuntimeError(
                        f'{S:#08x}: metatile {b:#04x} tambien fuera de mf{VEST_ROW}')
        rom[o:o + 16] = b'\x00' * 16
        total += 16
    return total


def build_rotulo(rom):
    """Compone el rotulo nuevo y devuelve (tiles, tilemap, columna)."""
    rows = R.render(ROT_TEXT)
    tiles = R.to_tiles(rows)
    n = len(tiles)
    if n > len(ROT_TILES):
        raise RuntimeError(f'{n} tiles > {len(ROT_TILES)} disponibles')
    if n > 24:
        raise RuntimeError(f'{n} tiles > 24 que limpia el borrado')
    col = 4 + (24 - n) // 2
    idx = ROT_TILES[:n]
    return tiles, idx, col, n


def main():
    rom = bytearray(open(SRC, 'rb').read())
    print(f'origen : {SRC}\n  md5  : {hashlib.md5(rom).hexdigest()}\n')

    # --- 1. eliminar el rotulo japones -----------------------------------
    nb = kill_japanese_label(rom)
    print(f'1) rotulo japones eliminado del stream {STREAM:#08x} ({nb} B a 0x00)')
    nv = kill_vest_labels(rom)
    print(f'   textos japoneses de los 3 vestuarios eliminados ({nv} B a 0x00)')
    for S in VEST_STREAMS:
        print(f'      {S:#08x} mf{VEST_ROW}')

    # --- 2. rotulo nuevo --------------------------------------------------
    tiles, idx, col, n = build_rotulo(rom)
    old_col = int.from_bytes(rom[ROT_COL:ROT_COL + 2], 'big')
    old_w = int.from_bytes(rom[ROT_W:ROT_W + 2], 'big')
    if old_col != 9 or old_w != 0x0d:
        raise RuntimeError(f'estructura inesperada: col={old_col} w={old_w}')
    rom[ROT_COL:ROT_COL + 2] = col.to_bytes(2, 'big')
    rom[ROT_W:ROT_W + 2] = (n - 1).to_bytes(2, 'big')
    for i, t in enumerate(idx):
        rom[ROT_MAP + i * 2:ROT_MAP + i * 2 + 2] = t.to_bytes(2, 'big')
    # limpiar words sobrantes del tilemap antiguo
    for i in range(n, 24):
        rom[ROT_MAP + i * 2:ROT_MAP + i * 2 + 2] = b'\xff\xff'
    print(f'2) rotulo {ROT_TEXT!r}: {n} tiles, columnas {col}..{col+n-1}')
    print(f'   {ROT_COL:#08x} columna {old_col} -> {col}')
    print(f'   {ROT_W:#08x} ancho-1 {old_w:#04x} -> {n-1:#04x}')

    # --- 3. corazon en el bloque 24 --------------------------------------
    D.PAD_FULL = False
    spans = dict(D.block_spans(bytes(rom)))
    if len(spans) != 86:
        raise RuntimeError(f'tabla con {len(spans)} bloques, deberia haber 86')
    p24 = int.from_bytes(rom[0x80020 + 24 * 4:0x80024 + 24 * 4], 'big')
    c, f, lines, nw = D.read_block(bytes(rom), p24)
    nuevas = [L.replace('****', HEART * 4) for L in lines]
    if nuevas == lines:
        raise RuntimeError('no se encontro **** en el bloque 24')
    blob = D.write_block(c, f, nuevas, spans[p24])
    rom[p24:p24 + len(blob)] = blob
    print(f'3) corazones en el bloque 24 ({p24:#08x})')
    for L in nuevas:
        print(f'      {L.strip()!r}')

    # --- tiles: rotulo nuevo + corazon, en el asset de fuente ------------
    data, end, _ = decomp(bytes(rom), FONT_ASSET, 256)
    big = bytearray(data)
    for t, tile in zip(idx, tiles):
        big[t * 32:(t + 1) * 32] = R.encode_tile(tile, ink=15, bg=0)
    # los tiles del rotulo viejo que ya no se usan -> vacios
    for t in ROT_TILES[n:]:
        big[t * 32:(t + 1) * 32] = b'\x00' * 32
    # corazon
    big[0x4B * 32:0x4C * 32] = F.encode(HEART, ink=15, bg=0)
    blob = H.compress(bytes(big), header=bytes(rom[FONT_ASSET:FONT_ASSET + 4]))[0]
    # LIMITE del hueco original: 0x090F0B. Alli empieza OTRO asset comprimido
    # (151 B, 8 tiles) que el juego carga a VRAM 0x9E40 = tiles 0x4F2..0x4F5.
    #
    # HIPOTESIS DESCARTADA: crei que la cola entre 0x090F0B y 0x091029 era
    # espacio libre, restos del asset de la v1.4 (4137 B frente a los 3851 de
    # la v1.6). La rellene con 0xFF y los tiles 0x4F2..0x4F5 se llenaron de
    # basura: estaban VACIOS en v1.4 y v1.6, y en v1.7 mostraban katakana.
    # Regresion detectada por la bateria, no por inspeccion.
    # El fallo fue buscar solo punteros 'lea.l' a esa zona: el descompresor
    # 0xF2A4 recibe la direccion en un registro, asi que su ausencia no
    # prueba nada. Lo correcto es descomprimir y ver si sale un asset valido.
    #
    # El asset nuevo tampoco cabe in situ por dos motivos acumulados:
    #   - mi compresor es 64 B peor que el del juego (3915 vs 3851 con los
    #     MISMOS datos: la v1.6 no se podria reconstruir hoy en su hueco)
    #   - el rotulo de 18 tiles cuesta 345 B frente a los 241 del de 14
    # Solucion: REUBICAR el asset a 0x091100 (hueco de 12.183 B verificado
    # todo a 0xFF) y repuntar los cinco cargadores, igual que ya se hizo con
    # el HUD (0x94000) y con el rotulo del titulo (0x96000).
    NEW_BASE = 0x091100
    LOADERS = (0x000842, 0x00103A, 0x001BAA, 0x003ED6, 0x004BC8)
    room = 0x094000 - NEW_BASE
    if len(blob) > room:
        raise RuntimeError(f'asset {len(blob)} B > {room} B en {NEW_BASE:#08x}')
    if any(b != 0xFF for b in rom[NEW_BASE:NEW_BASE + len(blob)]):
        raise RuntimeError(f'{NEW_BASE:#08x} no esta libre')
    rom[NEW_BASE:NEW_BASE + len(blob)] = blob
    for off in LOADERS:
        if int.from_bytes(rom[off:off + 4], 'big') != FONT_ASSET:
            raise RuntimeError(f'{off:#08x} no apunta al asset de fuente')
        rom[off:off + 4] = NEW_BASE.to_bytes(4, 'big')
    print(f'\n   asset reubicado {FONT_ASSET:#08x} -> {NEW_BASE:#08x}'
          f'  ({len(blob)} B, {len(LOADERS)} cargadores repuntados)')
    disp = room



    # --- checksum ---------------------------------------------------------
    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    final = bytes(rom)
    if len(D.block_spans(final)) != 86:
        raise RuntimeError('la tabla de dialogos ha dejado de ser recorrible')
    ndiff = sum(1 for a, b in zip(open(SRC, 'rb').read(), final) if a != b)
    open(DST, 'wb').write(final)
    print(f'\ndestino: {DST}')
    print(f'  md5  : {hashlib.md5(final).hexdigest()}')
    print(f'  bytes distintos respecto a la v1.6: {ndiff}')
    print('  tabla de dialogos: 86 bloques  OK')


if __name__ == '__main__':
    main()
