"""geom_test.py - barrido objetivo de posiciones X del comando."""
import sys, random
sys.path.insert(0,'/home/user/project/tools')
from md import MD
from hud_v2 import apply_emu, IDX

REV = {0x440+i: ch for ch,i in IDX.items()}
NAV = {430:['START'],435:[],700:['START'],705:[],780:['START'],785:[]}
PANEL_L, PANEL_R = 2, 10       # interior util
BORDER_L, BORDER_R = 1, 11     # marco intocable
SPRITE_R = 4                   # la animadora llega hasta ~col 4

def boot(m):
    nav=dict(NAV)
    for f in range(1000,1500,120): nav[f]=['START']; nav[f+5]=[]
    for f in range(1700):
        if f in nav:
            if nav[f]: m.press(*nav[f])
            else: m.release()
        m.run(1)

def wbe(v,r,c):
    o=0xc000+r*0x80+c*2
    return (v[o^1]<<8)|v[(o+1)^1]

def capture_commands(m, want=5, tries=200, seed=4):
    """Devuelve {texto: (fila25, fila26)} usando breakpoint en el dibujado."""
    bp=m.bp_add(0x00A582)
    prev=m.bp_hits(bp)
    rnd=random.Random(seed)
    out={}
    for i in range(tries):
        m.press(rnd.choice(['A','B','C','X','Y','Z']),
                rnd.choice(['RIGHT','LEFT','UP','DOWN']))
        for k in range(8):
            m.run(1)
            h=m.bp_hits(bp)
            if h>prev:
                prev=h
                v=m.vram()
                r25=[wbe(v,25,c)&0x7FF for c in range(0,16)]
                r26=[wbe(v,26,c)&0x7FF for c in range(0,16)]
                txt=''.join(REV.get(t,'') for t in r26)
                if len(txt)>=3 and txt not in out:
                    out[txt]=(r25,r26)
        m.release(); m.run(2)
        if len(out)>=want: break
    return out

def metrics(r26):
    """Metricas objetivas de una fila dibujada."""
    letters=[(c,REV[t]) for c,t in enumerate(r26) if t in REV]
    if not letters: return None
    cmd=[c for c,ch in letters]
    # separar comando de OK: el OK son las 2 ultimas letras contiguas 'O','K'
    okcols=[c for c,ch in letters if ch in 'OK']
    ok_run=[]
    for c,ch in letters:
        if ch=='O' and (c+1,'K') in [(x,y) for x,y in letters]: ok_run=[c,c+1]
    cmdcols=[c for c,ch in letters if c not in ok_run]
    m={}
    m['cmd_cols']=cmdcols
    m['ok_cols']=ok_run
    allc=cmdcols+ok_run
    m['inside']=sum(1 for c in allc if PANEL_L<=c<=PANEL_R)/max(1,len(allc))*100
    m['hits_border']=any(c in (BORDER_L,BORDER_R) or c<PANEL_L or c>PANEL_R for c in allc)
    m['overlap_sprite']=sum(1 for c in cmdcols if c<=SPRITE_R)
    m['gap']=(min(ok_run)-max(cmdcols)-1) if (ok_run and cmdcols) else None
    m['margin_right']=(PANEL_R-max(allc)) if allc else None
    return m
