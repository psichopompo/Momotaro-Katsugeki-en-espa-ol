"""exp_isolate.py - Experimento de aislamiento (SOLO MEMORIA DEL EMULADOR).

Tres brazos:
  A) JP            control
  B) ES            sin neutralizar
  C) ES_NOHOOK     con  jsr $8A300  ->  NOP NOP NOP   (solo en cart.rom en RAM)

El fichero .md en disco NUNCA se modifica (se verifica por md5).
"""
import sys, hashlib, collections, pickle
sys.path.insert(0, '/home/user/project/tools')
from md import MD
from nav import NAV_FIRST_MATCH

HOOK_JSR = 0x8A60E      # jsr $8A300.l dentro del wrapper $8A600
PRESENT_FRAME = 980

BPS = [('54EC', 0x54ec), ('8A600', 0x8a600), ('8A300', 0x8a300),
       ('C4180', 0xc4180), ('7A6E_borrado', 0x7a6e), ('7A3C_pintado', 0x7a3c)]


def run(rom, tag, neutralise=False, upto=PRESENT_FRAME, trace_from=790):
    md5_before = hashlib.md5(open(rom, 'rb').read()).hexdigest()
    m = MD(rom, evcap=6_000_000)
    m.trace(True); m.config()

    note = ''
    if neutralise:
        orig = [m.peek16(HOOK_JSR + 2 * i) for i in range(3)]
        m.nop_out(HOOK_JSR, 3)
        now = [m.peek16(HOOK_JSR + 2 * i) for i in range(3)]
        note = (f'  neutralizado @{HOOK_JSR:06X}: '
                f'{" ".join(f"{w:04x}" for w in orig)} -> {" ".join(f"{w:04x}" for w in now)}')

    bps = {n: m.bp_add(a) for n, a in BPS}

    for f in range(trace_from):
        if f in NAV_FIRST_MATCH:
            if NAV_FIRST_MATCH[f]: m.press(*NAV_FIRST_MATCH[f])
            else: m.release()
        m.run(1)

    m.config(flow=1, vram=1)
    m.reset_events()
    for f in range(trace_from, upto):
        m.run(1)

    evs = [(e.kind, e.pc, e.a, e.v, e.frame) for e in m.events()]
    png = f'work/shots/iso_{tag}.png'
    m.save_png(png)
    hits = {n: m.bp_hits(i) for n, i in bps.items()}
    state = (m.w16(0xf800), m.w16(0xf802), m.w16(0xf806), m.w16(0xf852))
    vram = m.vram()
    m.close()

    md5_after = hashlib.md5(open(rom, 'rb').read()).hexdigest()
    assert md5_before == md5_after, 'EL FICHERO DE ROM CAMBIO'

    pickle.dump(evs, open(f'work/iso_{tag}.pkl', 'wb'))
    open(f'work/iso_{tag}_vram.bin', 'wb').write(vram)
    return dict(tag=tag, hits=hits, state=state, evs=evs, png=png,
                note=note, md5_ok=(md5_before == md5_after))


def vram_rows(evs, base=0xc000, planew=0x80):
    r = collections.defaultdict(collections.Counter)
    for k, pc, a, v, f in evs:
        if k == 5 and base <= a < base + 0x1000:
            r[(a - base) // planew][pc] += 1
    return r
