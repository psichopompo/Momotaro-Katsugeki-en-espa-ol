"""build_v20b.py - ROM v2.0: nombres de escuela con la fuente del usuario.

Rehace por completo la v2.0 retirada. Dos pantallas:

  A) SELECCION DE ESCUELA (DUELO 2J, f800=0x30)
     13 nombres como tilemaps que referencian tiles del asset 0x064FD4.

  B) MARCADOR / RESULTADOS (f806=0x28)
     13 rotulos que referencian una fuente SIN COMPRIMIR volcada a VRAM
     0x280 por el hook 0x08F500.

--------------------------------------------------------------------------
POR QUE LA v2.0 ANTERIOR SE RETIRO
--------------------------------------------------------------------------
Tome como "libres" los 254 indices de tile que usaba el rotulo japones.
NO lo estaban: el asset 0x064FD4 lo comparten varias pantallas y 205 de
esos tiles tenian contenido en uso. Sintomas: kanji en la O de DURACION,
fondos de presentacion corruptos.

Aqui se usan EXCLUSIVAMENTE:
  - los 223 tiles cuyo contenido actual es CERO (verificado byte a byte)
  - los 133 kanji EXCLUSIVOS del rotulo japones (work/exclusivos2.json),
    medidos cruzando 9.000 frames de juego contra los tilemaps

y se COMPRUEBA antes de escribir que cada indice destino esta a cero o en
la lista de exclusivos. Si no, aborta.

--------------------------------------------------------------------------
LA FUENTE
--------------------------------------------------------------------------
La diseño el usuario (uploads/IMG_4518.PNG), extraida pixel a pixel a
work/fuente_usuario.json: 20 glifos de 8x24 en indices de color.

Idea clave del usuario: tratar los nombres como TEXTO alineado a celda en
vez de como GRAFICOS. Cada letra ocupa 1 celda de 8 px, asi que un glifo
produce siempre los mismos tiles y el coste depende del alfabeto (20
letras) y no del numero de nombres. 35 tiles frente a los 146 de antes.
"""
import sys, json, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D
import escuelas as E
import hud_v14 as H
from hudtools import decomp

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_9.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v2_0.md'

# ---- pantalla de seleccion ----
ASSET = 0x064FD4          # asset compartido, NO reubicable (flujos solapados)
NTILES = 1024
BASE = 0x200              # tile de VRAM = BASE + indice del asset
ASSET_FIN = 0x069873
TABLA = 0x02BD18          # 13 descriptores de 8 B: ancho-1 | alto-1 | ptr
COORD = 0x003854          # 13 coordenadas de 4 B: columna | fila
MAPAS_NEW = 0x02C780      # hueco verificado a 0xFF (2.178 B)
LIM_MAPAS_NEW = 0x02D000

# ---- pantalla del marcador ----
FUENTE_ROM = 0x08F600     # 26 tiles SIN COMPRIMIR, copiados a VRAM 0x280
FUENTE_FIN = 0x08F940     # justo detras empieza la tabla de rotulos
CONTADOR = 0x08F518       # operando de move.w #$19f,d0 (words-1)
PTR_FUENTE = 0x08F50C     # operando de lea.l $8f600,a0
VRAM_CMD = 0x08F502       # operando de move.l #$50000001,$c00004
ROTULOS = 0x08FD40        # 13 punteros a tilemap de 12x3 celdas
ROT_W, ROT_H = 12, 3
FUENTE_NEW = 0x0C4580     # hueco grande, par, verificado a 0xFF

NOMBRES_MARCADOR = [
    'YUSHUIN', 'SHICHIFUKU', 'SHIGUMA', 'MATAGI', 'YOSHIMOTO', 'EDOBANA',
    'IPPONZURI', 'OSOREZAN', 'YAMAMOTO', 'HORIHORI', 'HATTORI',
    'SHIMANCHU', 'CAPITANES',
]

COLS = {0: (1, 10), 1: (12, 21), 2: (23, 31)}


def cargar_fuente():
    """20 glifos de 8x24 -> dict letra -> [tile_fila0, tile_fila1, tile_fila2]."""
    raw = json.load(open('/home/user/project/work/fuente_usuario.json'))
    out = {}
    for ch, g in raw.items():
        tiles = []
        for r in range(3):
            blk = bytearray()
            for y in range(8):
                fila = g[r * 8 + y]
                for xb in range(4):
                    blk.append((fila[xb * 2] << 4) | fila[xb * 2 + 1])
            tiles.append(bytes(blk))
        out[ch] = tiles
    return out


def main():
    rom = bytearray(open(SRC, 'rb').read())
    print(f'origen: {SRC}')
    print(f'  md5 : {hashlib.md5(rom).hexdigest()}\n')

    F = cargar_fuente()
    falta = set(''.join(E.NOMBRES) + ''.join(NOMBRES_MARCADOR)) - set(F)
    if falta:
        raise RuntimeError(f'faltan glifos: {sorted(falta)}')

    # ================================================================
    # A) PANTALLA DE SELECCION
    # ================================================================
    print('=== A) pantalla de seleccion de escuela ===')
    data, _, _ = decomp(bytes(rom), ASSET, NTILES)
    big = bytearray(data)

    vacios = [i for i in range(NTILES) if not any(data[i * 32:(i + 1) * 32])]
    excl = json.load(open('/home/user/project/work/exclusivos2.json'))
    permitidos = set(vacios) | set(excl)
    pool = vacios + [i for i in excl if i not in set(vacios)]
    print(f'  tiles vacios {len(vacios)}, kanji exclusivos {len(excl)}, '
          f'pool {len(pool)}')

    # Borrar los 133 kanji EXCLUSIVOS del rotulo japones. Es lo que libera
    # el espacio: sin este paso el asset recomprime a 19.175 B y no cabe en
    # los 18.591 disponibles. Con el borrado baja a 17.125 B.
    # Son exclusivos del rotulo, medidos cruzando 9.000 frames de juego
    # contra los tilemaps: ningun fondo ni escena los usa.
    for i in excl:
        big[i * 32:(i + 1) * 32] = bytes(32)
    print(f'  borrados {len(excl)} kanji exclusivos del rotulo japones')

    usado = {}
    it = iter(pool)

    def idx_de(tile):
        """Indice de asset para un tile, reutilizando si ya se escribio."""
        if tile in usado:
            return usado[tile]
        i = next(it)
        # NORMA: comprobar que el destino esta libre DE VERDAD
        if i not in permitidos:
            raise RuntimeError(f'tile {i} no esta en la lista de libres')
        if any(data[i * 32:(i + 1) * 32]) and i not in set(excl):
            raise RuntimeError(f'tile {i} tiene contenido y no es kanji del rotulo')
        usado[tile] = i
        big[i * 32:(i + 1) * 32] = tile
        return i

    plan = []
    for k, nombre in enumerate(E.NOMBRES):
        col_grp = k % 3 if k < 12 else 0
        lo, hi = COLS[col_grp]
        w = len(nombre)                     # 1 celda por letra
        if w > hi - lo + 1:
            # la columna es un dato editable: se desplaza a la izquierda
            pass
        idxs = []
        for r in range(3):
            for ch in nombre:
                idxs.append(idx_de(F[ch][r]))
        plan.append((k, nombre, w, idxs))

    # escribir tilemaps en el hueco libre
    need = sum(len(i) for _, _, _, i in plan) * 2
    if need > LIM_MAPAS_NEW - MAPAS_NEW:
        raise RuntimeError(f'tilemaps {need} B no caben')
    if any(b != 0xFF for b in rom[MAPAS_NEW:MAPAS_NEW + need]):
        raise RuntimeError(f'{MAPAS_NEW:#08x} no esta libre')
    assert MAPAS_NEW % 2 == 0

    ptr = MAPAS_NEW
    for k, nombre, w, idxs in plan:
        a = TABLA + k * 8
        rom[a:a + 2] = (w - 1).to_bytes(2, 'big')
        rom[a + 4:a + 8] = ptr.to_bytes(4, 'big')
        for i, t in enumerate(idxs):
            rom[ptr + i * 2:ptr + i * 2 + 2] = (E.ATTR | (BASE + t)).to_bytes(2, 'big')
        ptr += len(idxs) * 2
        # centrar dentro de su columna
        ca = COORD + k * 4
        col0 = int.from_bytes(rom[ca:ca + 2], 'big')
        col_grp = k % 3 if k < 12 else 0
        lo, hi = COLS[col_grp]
        col = lo + max(0, ((hi - lo + 1) - w) // 2)
        if col + w - 1 > 31:
            col = 31 - w + 1
        rom[ca:ca + 2] = col.to_bytes(2, 'big')
        marca = f'  col {col0}->{col}' if col != col0 else ''
        print(f'  #{k:2d} {nombre:<11} {w:2d} celdas, {len(idxs)} tiles{marca}')

    print(f'  tilemaps: {ptr - MAPAS_NEW} B en {MAPAS_NEW:#08x}')
    print(f'  tiles unicos escritos: {len(usado)}')

    # recomprimir el asset
    hdr = bytes(rom[ASSET:ASSET + 4])
    comp = H.compress(bytes(big), header=hdr)[0]
    disp = ASSET_FIN - ASSET
    if len(comp) > disp:
        raise RuntimeError(f'asset {len(comp)} B > {disp} B disponibles '
                           f'(NO es reubicable: flujos solapados)')
    rom[ASSET:ASSET + len(comp)] = comp
    print(f'  asset {ASSET:#08x}: {len(comp)} B de {disp} '
          f'(margen {disp - len(comp)})')

    # ================================================================
    # B) PANTALLA DEL MARCADOR
    # ================================================================
    print('\n=== B) pantalla de resultados (marcador) ===')
    # banco de tiles para la fuente sin comprimir: solo las 2 filas con
    # contenido. La banda util del usuario es y=4..18, o sea filas 0 y 1
    # de celda (y=0..15) mas 3 px que caen en la fila 2.
    # Se comprueba cuantas filas tienen contenido de verdad.
    filas_con_datos = set()
    for ch, tiles in F.items():
        for r, t in enumerate(tiles):
            if any(t):
                filas_con_datos.add(r)
    filas = sorted(filas_con_datos)
    print(f'  filas de celda con contenido: {filas}')

    orden = sorted(F)                      # alfabetico: A..Z sin J L Q V W X
    banco = []
    pos = {}
    for ch in orden:
        pos[ch] = len(banco) // len(filas)
        for r in filas:
            banco.append(F[ch][r])
    nt = len(banco)
    blob = b''.join(banco)
    print(f'  {len(orden)} letras x {len(filas)} filas = {nt} tiles, {len(blob)} B')

    # ¿cabe donde estaba? 26 tiles = 832 B, y detras esta la tabla
    if len(blob) <= FUENTE_FIN - FUENTE_ROM:
        destino = FUENTE_ROM
        rom[destino:destino + len(blob)] = blob
        print(f'  cabe en {FUENTE_ROM:#08x} ({len(blob)} B de '
              f'{FUENTE_FIN - FUENTE_ROM})')
    else:
        destino = FUENTE_NEW
        assert destino % 2 == 0
        if any(b != 0xFF for b in rom[destino:destino + len(blob)]):
            raise RuntimeError(f'{destino:#08x} no esta libre')
        rom[destino:destino + len(blob)] = blob
        rom[PTR_FUENTE:PTR_FUENTE + 4] = destino.to_bytes(4, 'big')
        print(f'  reubicada {FUENTE_ROM:#08x} -> {destino:#08x} '
              f'({len(blob)} B; no cabia en {FUENTE_FIN - FUENTE_ROM})')

    # contador de words a copiar
    words = len(blob) // 2
    rom[CONTADOR:CONTADOR + 2] = (words - 1).to_bytes(2, 'big')
    print(f'  contador {CONTADOR:#08x}: #{words - 1:#x} ({words} words)')

    # VRAM: 0x280 + nt tiles no debe pisar el slot 2 (0x300)
    if 0x280 + nt > 0x300:
        raise RuntimeError(f'la fuente pisa el slot 2: '
                           f'{0x280 + nt:#05x} > 0x300')
    print(f'  VRAM 0x280..{0x280 + nt:#05x} (slot 2 empieza en 0x300) OK')

    # reescribir los 13 rotulos
    VACIO = 0xC401                          # tile de relleno original
    for k, nombre in enumerate(NOMBRES_MARCADOR):
        p = int.from_bytes(rom[ROTULOS + k * 4:ROTULOS + k * 4 + 4], 'big')
        if len(nombre) > ROT_W:
            raise RuntimeError(f'{nombre} no cabe en {ROT_W} celdas')
        x0 = (ROT_W - len(nombre)) // 2
        celdas = [VACIO] * (ROT_W * ROT_H)
        for r_i, r in enumerate(filas):
            for j, ch in enumerate(nombre):
                t = 0x280 + pos[ch] * len(filas) + r_i
                celdas[r_i * ROT_W + x0 + j] = 0x8000 | t
        for i, v in enumerate(celdas):
            rom[p + i * 2:p + i * 2 + 2] = v.to_bytes(2, 'big')
        print(f'  #{k:2d} {nombre:<11} en {p:#08x}, x0={x0}')

    # ================================================================
    # checksum y verificacion
    # ================================================================
    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    final = bytes(rom)
    n = len(D.block_spans(final))
    if n != 86:
        raise RuntimeError(f'tabla de dialogos rota: {n} bloques')
    ndiff = sum(1 for a, b in zip(open(SRC, 'rb').read(), final) if a != b)
    open(DST, 'wb').write(final)
    print(f'\ndestino: {DST}')
    print(f'  md5 : {hashlib.md5(final).hexdigest()}')
    print(f'  bytes distintos respecto a la v1.9: {ndiff}')
    print(f'  dialogos: {n} bloques OK')


if __name__ == '__main__':
    main()
