"""build_patch.py - construye el conjunto COMPLETO de escrituras del parche HUD.
Fuente unica de verdad: la usan el validador en memoria y el generador de ROM.
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
from hudtools import decomp
from newletters import build, SLOTS
from patch_hud import (plan_rom_writes, ASSET_NEW, ASSET_PTRS, COMMANDS)

_src = open('/home/user/project/hist/scripts/recompress.py').read().split("if __name__")[0]
_ns = {}; exec(_src, _ns)
compress = _ns['compress']

ASSET_OLD = 0x0286AA
ASSET_TILES = 256

def build_writes(rom):
    """Devuelve [(offset, bytes, motivo)] con TODO el parche."""
    w = []
    # 1) asset con las 8 letras nuevas, recomprimido y reubicado
    data,_,_ = decomp(rom, ASSET_OLD, ASSET_TILES)
    mod = bytearray(data)
    g = build()
    for ch, idx in SLOTS.items():
        mod[idx*32:(idx+1)*32] = g[ch]
    blob,_ = compress(bytes(mod), header=rom[ASSET_OLD:ASSET_OLD+4])
    w.append((ASSET_NEW, blob, f'asset HUD +8 letras ({len(blob)} bytes)'))
    # 2) repuntar los 2 cargadores
    for pa in ASSET_PTRS:
        w.append((pa, ASSET_NEW.to_bytes(4,'big'), f'cargador -> {ASSET_NEW:06X}'))
    # 3) tabla de comandos, punteros, coords, d2 y PAUSA
    w += plan_rom_writes(rom)
    return w

def apply_to_emu(m, rom):
    for off, b, why in build_writes(rom):
        for k in range(0, len(b) - (len(b) % 2), 2):
            m.poke16(off+k, int.from_bytes(b[k:k+2],'big'))
        if len(b) % 2:
            last = off + len(b) - 1
            cur = m.peek16(last & ~1)
            if last & 1: m.poke16(last & ~1, (cur & 0xFF00) | b[-1])
            else:        m.poke16(last, (b[-1]<<8) | (cur & 0xFF))
