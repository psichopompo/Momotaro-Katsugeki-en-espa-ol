"""Captura los MISMOS frames con y sin tipografia condensada.

El parche condensado solo cambia pixeles de tiles: no altera la logica del
juego, asi que con la misma semilla la partida es identica frame a frame.
"""
import sys, os, random
sys.path.insert(0,'/home/user/project/tools')
from md import MD
import shot_font as S, shot_run as R

FRAMES = [1819, 2269, 2371, 2411, 2203, 1713]

def play(tag, outdir, frames, seed=7, budget=4000):
    os.makedirs(outdir, exist_ok=True)
    m = MD(S.ROM)
    if tag=='cond': S.apply_cond(m)
    R.boot(m)
    rnd=random.Random(seed)
    tgt=set(frames)
    for i in range(budget):
        if i%5==0:   m.press(rnd.choice(['A','B','C']), rnd.choice(['RIGHT','LEFT','UP','DOWN']))
        elif i%5==2: m.release()
        m.run(1)
        if m.frame in tgt:
            m.save_png(f'{outdir}/{tag}_f{m.frame}.png')
            tgt.discard(m.frame)
        if not tgt: break
    return m

if __name__=='__main__':
    for tag in ('v11','cond'):
        play(tag,'work/shots/pair',FRAMES)
        print(tag,'ok')
