import sys, os, random
sys.path.insert(0, '/home/user/project/tools')
from md import MD
import demo_placa as D
import shot_run as R

FRAMES = [2371, 2411, 2269, 1819]

def play(mode, outdir, frames=FRAMES, seed=7, budget=4000):
    os.makedirs(outdir, exist_ok=True)
    m = MD(D.ROM)
    if mode == 'narrow':
        n, ink = D.apply_narrow(m)
    else:
        D.apply_current(m)
    R.boot(m)
    rnd = random.Random(seed)
    tgt = set(frames); got = []
    for i in range(budget):
        if i % 5 == 0:
            m.press(rnd.choice(['A','B','C']), rnd.choice(['RIGHT','LEFT','UP','DOWN']))
        elif i % 5 == 2:
            m.release()
        m.run(1)
        if m.frame in tgt:
            m.save_png(f'{outdir}/{mode}_f{m.frame}.png')
            tgt.discard(m.frame); got.append(m.frame)
        if not tgt: break
    return got

if __name__ == '__main__':
    for mode in ('actual', 'narrow'):
        g = play(mode, '/home/user/project/work/shots/placa')
        print(mode, 'frames', g)
