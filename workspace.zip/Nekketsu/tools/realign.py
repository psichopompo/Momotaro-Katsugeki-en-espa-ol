"""realign.py - alinea a la izquierda los dialogos de las escenas.

Reglas acordadas con el usuario:
  1. sangria fija de 2 celdas (16 px)
  2. recomponer en una sola linea las frases partidas que quepan
  3. aplicar SOLO a dialogos, no a menus ni rotulos

Criterio de seleccion (el usuario lo apunto): los dialogos empiezan por el
nombre de quien habla, en mayusculas y seguido de ':'. Se anaden ademas los
textos narrativos de la intro/final, que no llevan nombre pero pertenecen a
las mismas escenas.

Todo bloque que NO cumpla el criterio se deja INTACTO.
"""
import re
import dlgtext as D

INDENT = 2
# Ancho util REAL = 29, medido en pantalla. Probado con 31 y con 30: en ambos
# casos la ultima letra se perdia ('entrenaban.' quedaba sin el punto). El
# valor coincide con el que ya usaban los bloques originales, asi que 29 es
# el ancho de linea del motor, no una eleccion del traductor japones.
WIDTH = 29

# nombre en mayusculas al principio, seguido de ':'
_SPEAKER = re.compile(r'^[A-ZÁÉÍÓÚÑ][A-ZÁÉÍÓÚÑ .]*:')

# Textos narrativos de las mismas escenas: no llevan nombre de personaje pero
# son parte de la intro / interludios / final. Se identifican por su contenido
# exacto para no tocar nada mas por accidente.
_NARRATIVE = (
    'En el campo del Nekketsu',
    '\u00a1Los capitanes derrotados',
    '\u00a1No podemos rechazar',
    '\u00a1Vamos a por ellos',
    '\u00a1La pr\u00f3xima vez, esforzaos',
)

# Bloques que NO deben tocarse aunque parezcan dialogo.
#  - 'FIN DE LA PARTIDA' es un rotulo centrado.
#  - El bloque de '\u00bfVolver a intentarlo?' lleva un MENU ('S\u00cd    NO') cuya
#    separacion es significativa: el juego coloca ahi el cursor. Recomponerlo
#    lo convertiria en 'S\u00cd NO' y romperia la seleccion. Detectado al revisar
#    el diff antes de aplicar nada.
_KEEP = ('FIN DE LA PARTIDA', 'MISAKO: \u00bfVolver a intentarlo?')


def is_dialogue(lines):
    txt = ' '.join(L.strip() for L in lines if L.strip()).strip()
    if any(txt.startswith(k) for k in _KEEP):
        return False
    if _SPEAKER.match(txt):
        return True
    return any(txt.startswith(n) for n in _NARRATIVE)


def reflow(lines, indent=INDENT, width=WIDTH):
    """Une las lineas, y las reparte a lo ancho respetando la sangria."""
    txt = ' '.join(L.strip() for L in lines if L.strip())
    txt = re.sub(r'\s+', ' ', txt).strip()
    avail = width - indent
    words = txt.split(' ')
    out = []
    cur = ''
    for w in words:
        cand = w if not cur else cur + ' ' + w
        if len(cand) <= avail:
            cur = cand
        else:
            out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    # Sin relleno por la derecha: cada word gastado es espacio del bloque y
    # los espacios de cola son invisibles. El bloque original SI los tenia
    # (por el centrado manual), pero no hacen falta.
    return [' ' * indent + L for L in out]


def plan(rom, only_dialogue=True):
    """Devuelve [(addr, antes, despues, cambia, motivo, capacidad)]."""
    res = []
    for addr, col, fila, lines, n, sz in D.all_blocks(rom):
        real = [L for L in lines if L.strip()]
        if not real:
            res.append((addr, lines, lines, False, 'vacio', sz))
            continue
        if only_dialogue and not is_dialogue(lines):
            res.append((addr, lines, lines, False, 'no es dialogo', sz))
            continue
        new = reflow(lines)
        try:
            D.write_block(col, fila, new, sz)
        except ValueError as e:
            res.append((addr, lines, lines, False, f'no cabe: {e}', sz))
            continue
        changed = [l.rstrip() for l in new] != [l.rstrip() for l in lines if l.strip()]
        res.append((addr, lines, new, changed, 'ok', sz))
    return res


def build_writes(rom, only_dialogue=True):
    """[(offset, bytes, motivo)] para los bloques que cambian."""
    out = []
    for addr, old, new, changed, motivo, sz in plan(rom, only_dialogue):
        if not changed:
            continue
        col = int.from_bytes(rom[addr:addr + 2], 'big')
        fila = int.from_bytes(rom[addr + 2:addr + 4], 'big')
        blob = D.write_block(col, fila, new, sz)
        assert len(blob) == sz, (addr, len(blob), sz)
        out.append((addr, blob, ' | '.join(l.strip() for l in new)[:40]))
    return out
