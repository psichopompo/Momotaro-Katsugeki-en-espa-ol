"""audit_full.py - auditoria EXHAUSTIVA de uso de tiles.

Criterio uniforme para todos:
  - expansion completa NxM de cada sprite de la SAT
  - plano A, plano B y ventana, con bases leidas de los registros VDP
  - registro de la RUTINA (PC) que escribe cada tile, via hook VRAM
  - cobertura de todos los modos alcanzables
"""
import sys, random, collections
sys.path.insert(0,'/home/user/project/tools')
from md import MD

def bases(m):
    r=m.vdp_regs()
    return ((r[2]&0x38)<<10, (r[4]&0x07)<<13, (r[3]&0x3E)<<10, (r[5]&0x7F)<<9)

def scan(m, ref, frame, tag):
    """anota en `ref` que tiles se REFERENCIAN, con contexto."""
    v=m.vram(); pa,pb,win,sat=bases(m)
    for name,base in (('planoA',pa),('planoB',pb),('window',win)):
        for o in range(base,base+0x1000,2):
            t=((v[o^1]<<8)|v[(o+1)^1])&0x7FF
            if t: ref[t].add((name,tag,frame))
    for s in range(80):
        o=sat+s*8
        x=((v[(o+6)^1]<<8)|v[(o+7)^1])&0x1FF
        if x==0: continue
        t=((v[(o+4)^1]<<8)|v[(o+5)^1])&0x7FF
        sz=v[(o+2)^1]; wt=((sz>>2)&3)+1; ht=(sz&3)+1
        for k in range(wt*ht):                    # EXPANSION NxM
            ref[(t+k)&0x7FF].add((f'sprite{wt}x{ht}',tag,frame))
