"""hud_v13.py - HUD definitivo: asset de 264 tiles, letras con fondo OPACO.

Cambios respecto a v1.0 (retirada):
  - las 8 letras van a los tiles 0x540-0x547 (VERIFICADOS sin uso ni escritura)
  - el asset se amplia de 256 a 264 tiles (d1: 0x100 -> 0x108, 2 words)
  - el fondo de los glifos usa el indice 9 (OPACO), como O y K
  - NO se toca ninguno de los 13 tiles del asset original en uso
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
from hudtools import decomp

_src = open('/home/user/project/hist/scripts/recompress.py').read().split("if __name__")[0]
_src = _src.replace("assert len(tiles)%32==0 and len(tiles)//32<=256",
                    "assert len(tiles)%32==0")
_ns = {}; exec(_src, _ns)
compress = _ns['compress']

ASSET_OLD  = 0x0286AA
ASSET_NEW  = 0x094000
ASSET_PTRS = [0x0020D0, 0x005102]      # operandos lea.l
D1_PTRS    = [0x0020D4, 0x005106]      # move.w #$100,d1  -> operando en +2
D1_VALUE   = 0x0108                    # 264 tiles

# --- glifos: fondo = indice 9 (OPACO), trazo = 15. Sin indice 0. ---
COL = {'#':15, '9':9}
GL = {
 'C':["9######9","9##99##9","9##99999","9##99999","9##99999","9##99##9","9######9","99999999"],
 'D':["9#####99","9##99##9","9##999##","9##999##","9##999##","9##99##9","9#####99","99999999"],
 'F':["9#######","9##99999","9##99999","9#####99","9##99999","9##99999","9##99999","99999999"],
 'I':["9#####99","999##999","999##999","999##999","999##999","999##999","9#####99","99999999"],
 'L':["9##99999","9##99999","9##99999","9##99999","9##99999","9##99999","9#######","99999999"],
 'N':["9##999##","9###9###","9####9##","9##9#9##","9##99###","9##999##","9##999##","99999999"],
 'R':["9#####99","9##99##9","9##99##9","9#####99","9##9###9","9##99##9","9##999##","99999999"],
 'T':["########","999##999","999##999","999##999","999##999","999##999","999##999","99999999"],
}
ORDER = 'CDFILNRT'
NEW_IDX = {ch: 256+i for i,ch in enumerate(ORDER)}      # 0x100..0x107 -> VRAM 540..547

EX  = {'P':0x10,'A':0x11,'U':0x12,'S':0x13,'E':0x14,'O':0x15,'K':0x16}
IDX = dict(EX); IDX.update(NEW_IDX)

SP = 0x8485
def W(ch): return SP if ch == ' ' else 0x8440 + IDX[ch]

def enc(rows):
    out = bytearray()
    for r in rows:
        assert len(r) == 8
        for xb in range(4):
            out.append((COL[r[xb*2]] << 4) | COL[r[xb*2+1]])
    return bytes(out)

# --- geometria YA VALIDADA (zona legible: izq 4..10, der 21..27) ---
COORD   = 0x08A800
TRAMP   = 0x08A900
TBL_S0  = 0x08AA00
TBL_S1  = 0x08AB00
TBL_S2  = 0x08AC00
TBL_S3  = 0x08AD00
GEOM = {
    3: (5,  4, 4, 0x19, TBL_S0, 1),   # slot0: 5 cols -> 4..8
    2: (9,  9, 1, 0x19, TBL_S1, 1),   # slot1: 2 cols -> 9,10
    1: (21, 21, 4, 0x19, TBL_S2, 1),  # slot2: 5 cols -> 21..25
    0: (25, 26, 1, 0x19, TBL_S3, 1),  # slot3: 2 cols -> 26,27
}
TEXT = {0:'', 1:'PASA', 2:'FINTA', 3:'TIRA', 4:'PLACA', 5:'CEDE', 6:'OK', 7:''}
PTR_TABLE = 0x00A5C4
CALL_LO, CALL_HI = 0x00A546, 0x00A57E

def trampoline():
    b = bytearray()
    b += bytes.fromhex('2006'); b += bytes.fromhex('e980')
    b += b'\x49\xf9' + COORD.to_bytes(4,'big')
    b += bytes.fromhex('d9c0')
    b += bytes.fromhex('3a2b0002'); b += bytes.fromhex('028500000007')
    b += bytes.fromhex('e585')
    b += bytes.fromhex('226c0008'); b += bytes.fromhex('d3c5'); b += bytes.fromhex('2051')
    b += bytes.fromhex('302c0002'); b += bytes.fromhex('322c0006'); b += bytes.fromhex('342c0004')
    b += bytes.fromhex('363c0001'); b += bytes.fromhex('383c4000'); b += bytes.fromhex('4245')
    b += bytes.fromhex('4e75')
    return bytes(b)

def asset_blob(rom):
    data,_,_ = decomp(rom, ASSET_OLD, 256)
    big = bytearray(data)
    for ch in ORDER: big += enc(GL[ch])
    return compress(bytes(big), header=rom[ASSET_OLD:ASSET_OLD+4]), bytes(big)

def entry(txt, cols):
    return [SP]*cols + [W(c) for c in txt[:cols].ljust(cols)]

def build_writes(rom):
    w = []
    blob = asset_blob(rom)[0][0]
    w.append((ASSET_NEW, blob, f'asset 264 tiles ({len(blob)}B)'))
    for pa in ASSET_PTRS: w.append((pa, ASSET_NEW.to_bytes(4,'big'), 'cargador'))
    for pd in D1_PTRS:    w.append((pd+2, D1_VALUE.to_bytes(2,'big'), 'd1 = 264 tiles'))
    for d6,(xs,xi,aw,yi,tbl,asup) in GEOM.items():
        b = COORD + d6*16
        for off,val,tag in ((0,xs,'X_sup'),(2,xi,'X_inf'),(4,aw,'ancho-1'),
                            (6,yi,'Y'),(12,asup,'ancho_sup-1'),(14,0,'resv')):
            w.append((b+off, val.to_bytes(2,'big'), f'd6={d6} {tag}'))
        w.append((b+8, tbl.to_bytes(4,'big'), f'd6={d6} tabla'))
    for tbl, cols in ((TBL_S0,5),(TBL_S1,2),(TBL_S2,5),(TBL_S3,2)):
        ent = cols*2*2; base = tbl + 32
        for cid in range(8):
            e = base + cid*ent
            w.append((tbl+cid*4, e.to_bytes(4,'big'), f'{tbl:06X} ptr[{cid}]'))
            for k,ww in enumerate(entry(TEXT.get(cid,''), cols)):
                w.append((e+k*2, ww.to_bytes(2,'big'), f'{tbl:06X} cmd[{cid}]'))
    t = trampoline()
    w.append((TRAMP, t, f'trampolin ({len(t)}B)'))
    w.append((0x00A51E, bytes.fromhex('e980'), 'SUP asl #4'))
    w.append((0x00A520, b'\x49\xf9'+COORD.to_bytes(4,'big'), 'SUP lea'))
    w.append((0x00A52E, bytes.fromhex('342c000c'), 'SUP ancho'))
    patch = b'\x4e\xb9'+TRAMP.to_bytes(4,'big') + b'\x4e\x71'*((CALL_HI-CALL_LO-6)//2)
    w.append((CALL_LO, patch, 'INF -> JSR trampolin'))
    return w

def apply_emu(m, rom):
    for off,b,_ in build_writes(rom):
        for k in range(0, len(b)-len(b)%2, 2):
            m.poke16(off+k, int.from_bytes(b[k:k+2],'big'))
        if len(b)%2:
            last=off+len(b)-1; cur=m.peek16(last & ~1)
            m.poke16(last & ~1, (cur & 0xFF00)|b[-1] if (last&1) else (b[-1]<<8)|(cur&0xFF))
