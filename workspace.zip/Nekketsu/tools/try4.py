"""try4.py - ESTUDIO: arquitectura B con fuente de cuerpo 4 px.

Prueba de estres del usuario: PLACA PLACA en los dos paneles.
Solo memoria del emulador. NO se genera ninguna ROM.
"""
import sys
sys.path.insert(0, '/home/user/project/tools')
import hud_v14 as H
from hudtools import decomp

ROM = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_1.md'
BG, INK = 9, 15
PANEL_BG = 0x8485

WORDS = ['PASA', 'TIRA', 'CEDE', 'PLACA', 'FINTA', 'OK']
CMD = {1: 'PASA', 2: 'FINTA', 3: 'TIRA', 4: 'PLACA', 5: 'CEDE', 6: 'OK'}

# el asset debe llegar como mucho a 0x54F (0x550 es del asset siguiente)
N_TILES = 272                      # 0x440 .. 0x54F  (hueco lleno justo)
X_LEFT, X_RIGHT = 4, 21


def word_tiles(word, mod):
    w = mod.word_width(word)
    n = (w + 7) // 8
    W = n * 8
    px = [[BG] * W for _ in range(8)]
    g = mod.render(word)
    for y in range(7):
        for dx in range(len(g[0])):
            if g[y][dx]:
                px[y][dx] = INK
    out = []
    for c in range(n):
        t = bytearray()
        for y in range(8):
            for xb in range(4):
                X = c * 8 + xb * 2
                t.append((px[y][X] << 4) | px[y][X + 1])
        out.append(bytes(t))
    return out, n, w


def build_catalog(mod):
    cat = {}; tiles = []; idx = 256
    for w in WORDS:
        ts, n, px = word_tiles(w, mod)
        cat[w] = (idx, n, px)
        tiles += ts; idx += n
    return cat, tiles


def poke_bytes(m, off, b):
    for k in range(0, len(b) - len(b) % 2, 2):
        m.poke16(off + k, (b[k] << 8) | b[k + 1])


def _geom(m, d6, x, cols, tbl):
    b = H.COORD + d6 * 16
    m.poke16(b + 2, x); m.poke16(b + 4, cols - 1); m.poke16(b + 6, 0x19)
    m.poke16(b + 8, tbl >> 16); m.poke16(b + 10, tbl & 0xFFFF); m.poke16(b + 12, 1)


def _fill(m, tbl, cols, cat, force=None):
    ent = cols * 2 * 2; base = tbl + 32
    for cid in range(8):
        e = base + cid * ent
        m.poke16(tbl + cid * 4, e >> 16); m.poke16(tbl + cid * 4 + 2, e & 0xFFFF)
        word = force if force else CMD.get(cid)
        if word:
            i, n, _ = cat[word]
            row = [0x8440 + i + k for k in range(n)][:cols]
            row += [PANEL_BG] * (cols - len(row))
        else:
            row = [PANEL_BG] * cols
        for k, w in enumerate([PANEL_BG] * cols + row):
            m.poke16(e + k * 2, w)


def apply(m, mod, align_l=0, sec_w=3, force=None):
    data, _, _ = decomp(m.rom, H.ASSET_OLD, 256)
    big = bytearray(data)
    cat, tiles = build_catalog(mod)
    for t in tiles:
        big += t
    while len(big) // 32 < N_TILES:
        big += bytes([BG * 17]) * 32
    assert len(big) // 32 == N_TILES
    blob = H.compress(bytes(big), header=m.rom[H.ASSET_OLD:H.ASSET_OLD + 4])[0]
    poke_bytes(m, H.ASSET_NEW, blob)
    for pd in H.D1_PTRS:
        m.poke16(pd + 2, N_TILES)

    _geom(m, 3, X_LEFT + align_l,      3,     H.TBL_S0); _fill(m, H.TBL_S0, 3,     cat, force)
    _geom(m, 2, X_LEFT + 4 + align_l,  sec_w, H.TBL_S1); _fill(m, H.TBL_S1, sec_w, cat, force)
    _geom(m, 1, X_RIGHT,               3,     H.TBL_S2); _fill(m, H.TBL_S2, 3,     cat, force)
    _geom(m, 0, X_RIGHT + 4,           3,     H.TBL_S3); _fill(m, H.TBL_S3, 3,     cat, force)
    return cat


if __name__ == '__main__':
    import font4, placafont
    for name, mod in (('3 px', placafont), ('4 px', font4)):
        cat, tiles = build_catalog(mod)
        print(f'--- cuerpo {name}: {len(tiles)} tiles (hueco 16) '
              f'{"CABE" if len(tiles)<=16 else "NO CABE"} ---')
        for w in WORDS:
            i, n, px = cat[w]
            print(f'    {w:6} {n} tiles {px:2} px')
