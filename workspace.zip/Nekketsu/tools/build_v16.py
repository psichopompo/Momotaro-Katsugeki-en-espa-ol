"""build_v16.py - ROM v1.6: ritmo de los dialogos.

Parte de la v1.5 y aplica DOS cambios, ambos medidos en emulador.

--------------------------------------------------------------------------
CAMBIO 1 (2 bytes) - velocidad de tecleo: 3 frames/caracter -> 1
--------------------------------------------------------------------------
  0x0058B0: 0002 -> 0000     valor inmediato de  move.w #$2,$12(a6)

Modelo demostrado en investigation.md:

  Los dialogos NO los dispara un temporizador de texto, sino el interprete
  de scripts de ACTOR (0x00F6AE), el mismo que anima a los personajes,
  mediante la orden FF08 (0x00F8C6 -> escribe $f940).

  Cada FF08 abre una RANURA que dura hasta el siguiente FF08:

      ranura = borrado + tecleo + VISIBLE

  La ranura la fija la animacion y NO se toca. Acortar el tecleo convierte
  ese tiempo, integramente, en tiempo de lectura. Los actores no se mueven
  ni un frame.

  Ademas, el gate de 0x005846 descarta cualquier dialogo que llegue mientras
  el motor sigue tecleando. Acortar el tecleo REDUCE ese riesgo: el barrido
  de 14.000 frames recupera el bloque 10 ('KUNIO: Me lo pides de repente...')
  que no se habia visto NUNCA, y no pierde ninguno.

  Rectifica la conclusion "conflicto irresoluble" de la v1.5, que era falsa:
  se probo a SUBIR el retardo (3,4,5), nunca a bajarlo.

--------------------------------------------------------------------------
CAMBIO 2 - reparto de la frase de la intoxicacion: ahora 2 lineas + 1
--------------------------------------------------------------------------
  0x0804F4  'TAKASHI: El equipo sufrio una' / 'intoxicacion alimentaria'
  0x080572  'y no puede ir.'

  Antes iba 1 linea y luego 2, que deja el primer panel medio vacio.
  Peticion del usuario, verificada: ambos bloques tienen 126 B de capacidad.

El campo $12(a6) pertenece en exclusiva al motor de dialogos: a6 solo se
carga con $f940 en 0x00582C y 0x0059B8, y el unico escritor del campo es el
propio motor (0x0058A8 / 0x0058AE). Verificado por barrido de la ROM.
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_5.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_6.md'

DELAY_IMM = 0x0058B0
DELAY_CHK = 0x0058B2          # aqui va el desplazamiento 0012, NO el valor
CHAR_DELAY = 0                # 0 -> 1 frame por caracter

SPLIT = {
    0x0804F4: ['TAKASHI: El equipo sufri\u00f3 una', 'intoxicaci\u00f3n alimentaria'],
    0x080572: ['y no puede ir.'],
}


def main():
    rom = bytearray(open(SRC, 'rb').read())
    src_md5 = hashlib.md5(rom).hexdigest()
    print(f'origen : {SRC}\n  md5  : {src_md5}')

    # --- cambio 1: retardo de tecleo -------------------------------------
    if bytes(rom[0x0058AC:0x0058B4]) != bytes.fromhex('4e753d7c00020012'):
        raise RuntimeError('estructura inesperada en 0x0058AE')
    assert bytes(rom[DELAY_CHK:DELAY_CHK + 2]) == b'\x00\x12'
    old = int.from_bytes(rom[DELAY_IMM:DELAY_IMM + 2], 'big')
    rom[DELAY_IMM:DELAY_IMM + 2] = CHAR_DELAY.to_bytes(2, 'big')
    print(f'\n1) retardo de tecleo  {DELAY_IMM:#08x}: '
          f'{old} -> {CHAR_DELAY}  ({old+1} -> {CHAR_DELAY+1} frames/caracter)')

    # --- cambio 2: reparto de la frase de TAKASHI ------------------------
    D.PAD_FULL = False
    spans = dict(D.block_spans(bytes(rom)))
    if len(spans) != 86:
        raise RuntimeError(f'la tabla deberia tener 86 bloques, tiene {len(spans)}')
    print('\n2) reparto de la frase de la intoxicacion')
    for addr, lines in SPLIT.items():
        cap = spans.get(addr)
        if cap is None:
            raise RuntimeError(f'{addr:#08x} no es cabecera de bloque')
        before = D.read_block(bytes(rom), addr)[2]
        blob = D.write_block(1, 0x18, lines, cap)
        rom[addr:addr + len(blob)] = blob
        print(f'   {addr:#08x} cap {cap} B')
        print(f'      antes : {[l.strip() for l in before if l.strip()]}')
        print(f'      ahora : {lines}')

    # --- checksum de cartucho --------------------------------------------
    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    # --- comprobacion final ----------------------------------------------
    final = bytes(rom)
    if len(D.block_spans(final)) != 86:
        raise RuntimeError('la tabla de bloques ha dejado de ser recorrible')
    ndiff = sum(1 for a, b in zip(open(SRC, 'rb').read(), final) if a != b)

    open(DST, 'wb').write(final)
    print(f'\ndestino: {DST}')
    print(f'  md5  : {hashlib.md5(final).hexdigest()}')
    print(f'  bytes distintos respecto a la v1.5: {ndiff}')
    print(f'  tabla de dialogos: 86 bloques recorribles  OK')


if __name__ == '__main__':
    main()
