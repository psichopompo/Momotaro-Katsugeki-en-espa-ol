"""demo_placa.py - PRUEBA DEL CRITERIO REAL: 'PLACA PLACA' en 7 celdas.

Zona legible medida: panel izq cols 4..10, panel der cols 21..27 -> 7 celdas.
Con la fuente actual PLACA ocupa 5 celdas -> PLACA+PLACA = 11 > 7. NO cabe.
Con tira sub-celda (avance 5 px) PLACA = 24 px -> PLACA PLACA = 54 px = 7 tiles.

Solo parchea la memoria del emulador. NO genera ninguna ROM.
"""
import sys
sys.path.insert(0, '/home/user/project/tools')
import hud_v14 as H
import narrowfont as NF
from hudtools import decomp

ROM = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_1.md'

PHRASE   = 'PLACA PLACA'
GAP_PX   = 6                       # aire entre las dos palabras
N_CELLS  = 7                       # zona legible por panel
X_LEFT, X_RIGHT = 4, 21


def phrase_pixels(words, gap=GAP_PX, ncells=N_CELLS):
    W = ncells * 8
    px = [[NF.BG] * W for _ in range(8)]
    x = 0
    for wi, word in enumerate(words):
        if wi:
            x += gap
        for ch in word:
            for y, row in enumerate(NF.G[ch]):
                for dx, c in enumerate(row):
                    if c == '#' and x + dx < W:
                        px[y][x + dx] = NF.INK
            x += NF.ADV
    return px, x - 1


def phrase_tiles(words, gap=GAP_PX, ncells=N_CELLS):
    px, ink = phrase_pixels(words, gap, ncells)
    out = []
    for c in range(ncells):
        t = bytearray()
        for y in range(8):
            for xb in range(4):
                X = c * 8 + xb * 2
                t.append((px[y][X] << 4) | px[y][X + 1])
        out.append(bytes(t))
    return out, ink


# ---- indices dentro del asset ampliado ----
# La frase va DENTRO del hueco libre confirmado 0x540-0x54F.
# Colocarla en 269 la habria llevado a 0x54D..0x553, pisando el asset
# siguiente (0x55C22 -> VRAM 0xAA00 = tile 0x550). Error detectado en
# captura: los tiles 0x550-0x553 mostraban basura del otro asset.
# En modo tira NO se usan los 13 tiles por-letra: la palabra es un bloque.
BASE_PHRASE = 256                        # -> VRAM 0x540 .. 0x546
# Se rellena hasta 269 tiles (el mismo numero que la v1.1) para que la
# longitud del DMA sea IDENTICA en ambos modos. Si no, el timing cambia y
# la partida diverge: las capturas dejarian de ser del mismo frame.
N_TILES     = 269
VRAM_PHRASE = 0x440 + BASE_PHRASE

def poke_bytes(m, off, b):
    for k in range(0, len(b) - len(b) % 2, 2):
        m.poke16(off + k, (b[k] << 8) | b[k + 1])
    if len(b) % 2:
        last = off + len(b) - 1
        cur = m.peek16(last & ~1)
        m.poke16(last & ~1, (cur & 0xFF00) | b[-1] if (last & 1)
                 else (b[-1] << 8) | (cur & 0xFF))


def _geom(m, d6, x, cols, tbl):
    b = H.COORD + d6 * 16
    m.poke16(b + 0, x)          # X_sup
    m.poke16(b + 2, x)          # X_inf
    m.poke16(b + 4, cols - 1)   # ancho-1
    m.poke16(b + 6, 0x19)       # Y
    m.poke16(b + 8, tbl >> 16)
    m.poke16(b + 10, tbl & 0xFFFF)
    m.poke16(b + 12, 1)


def _fill_table(m, tbl, cols, words):
    """words = lista de tiles (o None para dejar el slot en blanco)."""
    ent = cols * 2 * 2
    base = tbl + 32
    for cid in range(8):
        e = base + cid * ent
        m.poke16(tbl + cid * 4, e >> 16)
        m.poke16(tbl + cid * 4 + 2, e & 0xFFFF)
        row_top = [H.SP] * cols
        row_bot = words if words else [H.SP] * cols
        for k, w in enumerate(row_top + row_bot):
            m.poke16(e + k * 2, w)


def apply_narrow(m):
    """Fuente estrecha: 'PLACA PLACA' como tira de 7 tiles en ambos paneles."""
    data, _, _ = decomp(m.rom, H.ASSET_OLD, 256)
    big = bytearray(data)
    tiles, ink = phrase_tiles(PHRASE.split())
    for t in tiles:
        big += t
    while len(big) // 32 < N_TILES:          # relleno hasta igualar el DMA
        big += bytes([0x99]) * 32
    assert len(big) // 32 == N_TILES, len(big) // 32

    blob = H.compress(bytes(big), header=m.rom[H.ASSET_OLD:H.ASSET_OLD + 4])[0]
    poke_bytes(m, H.ASSET_NEW, blob)
    for pd in H.D1_PTRS:
        m.poke16(pd + 2, N_TILES)

    ph = [0x8440 + BASE_PHRASE + i for i in range(N_CELLS)]
    _geom(m, 3, X_LEFT,  N_CELLS, H.TBL_S0); _fill_table(m, H.TBL_S0, N_CELLS, ph)
    _geom(m, 1, X_RIGHT, N_CELLS, H.TBL_S2); _fill_table(m, H.TBL_S2, N_CELLS, ph)
    # Los slots secundarios (d6=2 -> slot1 izq, d6=0 -> slot3 der) siguen
    # dibujando su propia celda y BORRABAN la primera de la frase.
    # Se les da como contenido el tile que corresponde a esa columna, de modo
    # que dibujen lo mismo que ya hay. Ver diario: fallo detectado en captura.
    _geom(m, 2, X_LEFT,  1, H.TBL_S1); _fill_table(m, H.TBL_S1, 1, [ph[0]])
    _geom(m, 0, X_RIGHT, 1, H.TBL_S3); _fill_table(m, H.TBL_S3, 1, [ph[0]])
    return len(blob), ink


def apply_current(m):
    """Fuente ACTUAL v1.1 intentando 'PLACA PLACA' en las mismas 7 celdas."""
    txt = (PHRASE + ' ' * N_CELLS)[:N_CELLS]     # se trunca: 'PLACA P'
    ph = [H.SP if c == ' ' else 0x8440 + H.IDX_HUD[c] for c in txt]
    _geom(m, 3, X_LEFT,  N_CELLS, H.TBL_S0); _fill_table(m, H.TBL_S0, N_CELLS, ph)
    _geom(m, 1, X_RIGHT, N_CELLS, H.TBL_S2); _fill_table(m, H.TBL_S2, N_CELLS, ph)
    _geom(m, 2, X_LEFT,  1, H.TBL_S1); _fill_table(m, H.TBL_S1, 1, [ph[0]])
    _geom(m, 0, X_RIGHT, 1, H.TBL_S3); _fill_table(m, H.TBL_S3, 1, [ph[0]])
    return 0, 0


if __name__ == '__main__':
    t, ink = phrase_tiles(PHRASE.split())
    print(f"'{PHRASE}' -> tinta {ink} px, {len(t)} tiles ({len(t)*8} px disponibles)")
    print(f"fuente actual: {len(PHRASE.replace(' ',''))} letras x 1 celda + 1 sep = "
          f"{len(PHRASE.replace(' ',''))+1} celdas")
