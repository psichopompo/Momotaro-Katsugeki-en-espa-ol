"""test_reubic.py - ¿es reubicable el asset de fuente 0x090000?

METODO (no dar nada por supuesto):
  1. Se construye una ROM con el asset copiado a un hueco libre y los
     punteros repuntados.
  2. Se arranca la ROM ORIGINAL y la REUBICADA en el emulador, por
     separado (NUNCA dos instancias MD vivas a la vez), y se compara la
     VRAM byte a byte en los mismos frames.
  3. Si la VRAM es idéntica, la reubicación no altera lo que se dibuja.

Se compara también el framebuffer, porque la VRAM podría coincidir y aun
así diferir el resultado por CRAM o registros del VDP.
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_9.md'
ASSET, ASSET_END = 0x090000, 0x090F4B
DEST = 0x0C4580                      # hueco grande, par, verificado a 0xFF

# punteros REALES al asset (los 13 slots de la tabla de escenas 0x17750).
# Los demás candidatos del escaneo se descartaron: son idénticos en la ROM
# japonesa (que no puede apuntar a 0x090000, creado por la traducción) o
# son words de tilemap que casualmente forman el long buscado.
PTRS = [0x0177FC, 0x01785C, 0x0178DC, 0x01795C, 0x0179DC, 0x017A5C,
        0x017ADC, 0x017B5C, 0x017BDC, 0x017C5C, 0x017CDC, 0x017D5C,
        0x017DDC]


def build(dest=DEST):
    rom = bytearray(open(SRC, 'rb').read())
    size = ASSET_END - ASSET
    assert dest % 2 == 0, 'la direccion de reubicacion debe ser PAR'
    assert all(b == 0xFF for b in rom[dest:dest + size]), 'destino no libre'

    blob = bytes(rom[ASSET:ASSET_END])
    rom[dest:dest + size] = blob

    n = 0
    for p in PTRS:
        v = int.from_bytes(rom[p:p + 4], 'big')
        assert v == ASSET, f'{p:#08x} no apunta al asset ({v:#08x})'
        rom[p:p + 4] = dest.to_bytes(4, 'big')
        n += 1

    # borrar el original para que un acceso olvidado se note enseguida
    rom[ASSET:ASSET_END] = b'\xFF' * size

    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF
    return bytes(rom), n


NAV = {430: ['START'], 435: [], 700: ['START'], 705: [],
       780: ['START'], 785: []}


def snapshot(rom_bytes, tag, frames=900):
    """Arranca una ROM y devuelve hashes de VRAM en varios frames."""
    from md import MD
    import tempfile, os
    fd, path = tempfile.mkstemp(suffix='.md')
    os.write(fd, rom_bytes)
    os.close(fd)
    m = MD(path)
    out = {}
    try:
        for f in range(1, frames + 1):
            if f in NAV:
                if NAV[f]:
                    m.press(*NAV[f])
                else:
                    m.release()
            m.run(1)
            if f in (300, 500, 750, 900):
                v = m.vram()
                out[f] = hashlib.md5(v).hexdigest()
                m.save_png(f'/home/user/project/work/shots/reub_{tag}_{f}.png')
    finally:
        del m
        os.unlink(path)
    return out


if __name__ == '__main__':
    rom, n = build()
    print(f'asset {ASSET:#08x}-{ASSET_END:#08x} '
          f'({ASSET_END - ASSET} B) -> {DEST:#08x}')
    print(f'punteros repuntados: {n}')
    open('/home/user/project/rom/_test_reubic.md', 'wb').write(rom)
    print(f'md5 reubicada: {hashlib.md5(rom).hexdigest()}')
