"""cinta.py - reconstruye la banderola verde del rotulo de escena.

La japonesa dibuja 「ドッジボール部室」 sobre una CINTA trapezoidal de
3 filas x 24 columnas (192x24 px) en el plano A, filas 3..5, cols 4..27,
con atributo 0xA100 (paleta 1 + prioridad).

Anatomia medida en la ROM japonesa (work/shots/CINTA_jp.png):

  fila 3:  0x100 0x100 | 0x12E [texto...] 0x15C | 0x100 0x100
  fila 4:  0x100 | 0x12E 0x1BF [texto...] 0x1BF 0x15C | 0x100
  fila 5:  0x12E 0x1BF 0x1BF [texto...] 0x1BF 0x1BF 0x15C

  0x12E = borde diagonal IZQUIERDO   (la cinta se ensancha hacia abajo)
  0x15C = borde diagonal DERECHO
  0x1BF = relleno liso (todo color B)
  0x100 = fondo de la escena

El trapecio crece 1 celda por lado y por fila: fila 3 ocupa 4..25,
fila 4 ocupa 4..26 y fila 5 ocupa 4..27.

Colores (indices de la paleta 1):
  B = verde de la cinta       E = sombra del texto
  F = blanco del texto        D, C = tonos intermedios del antialias

Reutilizamos los tiles ORIGINALES de borde y relleno (0x12E, 0x15C, 0x1BF):
no hay que redibujarlos, solo referenciarlos desde el tilemap. Lo unico
nuevo es el texto en castellano, que se compone con la misma fuente de
7 px y trazo de 2 px del rotulo actual (tools/rotulo.py).
"""

# indices de tile del marco, tomados tal cual de la ROM japonesa
BORDE_IZQ = 0x12E
BORDE_DER = 0x15C
RELLENO = 0x1BF
FONDO = 0x100
ATTR = 0xA100 & 0xF800      # paleta 1 + prioridad, sin indice de tile

# geometria del trapecio: (columna_inicial, columna_final) por fila
GEOM = {3: (6, 25), 4: (5, 26), 5: (4, 27)}

# El texto va centrado en la fila 5 (la mas ancha) o repartido.
# En la japonesa el texto ocupa las tres filas porque el kanji es alto.
# En castellano basta una linea, que se coloca en la fila 4 (la del medio).


# indices de color medidos en los tiles originales de la cinta
C_CINTA = 0xB       # verde de fondo
C_TEXTO = 0xF       # blanco del texto
C_SOMBRA = 0xE      # sombra inferior-derecha del texto


def encode_tile(tile, ink=C_TEXTO, bg=C_CINTA, shadow=C_SOMBRA):
    """32 bytes 4bpp sobre fondo de cinta, con sombra a la derecha y abajo.

    El texto japones original lleva relieve: trazo blanco (F) con sombra (E)
    en el borde inferior-derecho. Se reproduce desplazando el trazo 1 px.
    """
    h = len(tile)
    w = len(tile[0])
    out = bytearray()
    for y in range(8):
        px = []
        for x in range(8):
            if y < h and x < w and tile[y][x] == '#':
                px.append(ink)
            else:
                # sombra: hay trazo 1 px arriba-izquierda
                sy, sx = y - 1, x - 1
                if 0 <= sy < h and 0 <= sx < w and tile[sy][sx] == '#':
                    px.append(shadow)
                else:
                    px.append(bg)
        for xb in range(4):
            out.append((px[xb * 2] << 4) | px[xb * 2 + 1])
    return bytes(out)


def build_map(text_tiles, row_text=4):
    """Devuelve {(fila, col): tile} para las tres filas de la cinta.

    text_tiles: lista de indices de tile del texto ya renderizado.
    """
    out = {}
    for row, (c0, c1) in GEOM.items():
        for c in range(4, 28):
            if c < c0 or c > c1:
                out[(row, c)] = FONDO
            elif c == c0:
                out[(row, c)] = BORDE_IZQ
            elif c == c1:
                out[(row, c)] = BORDE_DER
            else:
                out[(row, c)] = RELLENO
    # incrustar el texto centrado en la fila indicada
    c0, c1 = GEOM[row_text]
    hueco = (c1 - 1) - (c0 + 1) + 1          # celdas interiores
    n = len(text_tiles)
    if n > hueco:
        raise ValueError(f'{n} tiles de texto > {hueco} celdas disponibles')
    ini = c0 + 1 + (hueco - n) // 2
    for i, t in enumerate(text_tiles):
        out[(row_text, ini + i)] = t
    return out


def flatten(m):
    """Serializa el mapa a words para el blitter 0x7a3c (3 filas x 24 cols)."""
    out = bytearray()
    for row in (3, 4, 5):
        for c in range(4, 28):
            out += (ATTR | m[(row, c)]).to_bytes(2, 'big')
    return bytes(out)
