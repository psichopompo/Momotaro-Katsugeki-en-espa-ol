"""Capture a grid of frames to identify screens quickly."""
import sys, numpy as np
sys.path.insert(0,'/home/user/project/tools')
from md import MD
from PIL import Image, ImageDraw

def rgb(m):
    raw,w,h,pitch,fmt = m.last
    a = np.frombuffer(raw, dtype=np.uint16).reshape(h, pitch//2)[:, :w].astype(np.uint32)
    r = ((a>>11)&31)*255//31; g=((a>>5)&63)*255//63; b=(a&31)*255//31
    return np.dstack([r,g,b]).astype(np.uint8)

def strip(rom, nframes, every, out, script=None, mash=None, scale=1, label=lambda m,f:''):
    m = MD(rom, evcap=100); m.trace(False)
    shots=[]
    for f in range(nframes):
        if script and f in script:
            if script[f]: m.press(*script[f])
            else: m.release()
        if mash:
            per,hold = mash
            if f%per==0: m.press('START')
            elif f%per==hold: m.release()
        m.run(1)
        if f%every==0 and m.last:
            shots.append((f, rgb(m), label(m,f)))
    m.close()
    if not shots: return
    h,w,_ = shots[0][1].shape
    cols = 5; rows=(len(shots)+cols-1)//cols
    pad=16
    im = Image.new('RGB',(cols*w, rows*(h+pad)),(15,15,20))
    d=ImageDraw.Draw(im)
    for i,(f,arr,lab) in enumerate(shots):
        x=(i%cols)*w; y=(i//cols)*(h+pad)
        im.paste(Image.fromarray(arr),(x,y+pad))
        d.text((x+2,y+3),f'f{f} {lab}',fill=(255,255,0))
    im.save(out)
    print('saved',out,len(shots),'frames')
