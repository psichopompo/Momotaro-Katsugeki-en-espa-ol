"""titulo.py - convierte el rotulo del titulo (PNG del usuario) a tiles+tilemap.

El rotulo se pinta con:
  tilemap  0x0A3000   32x16 words, atributo 0x6000 (paleta 3)
  tiles    0x096000   asset comprimido, tile base 0x200
  paleta   0x0A3400   16 words

El PNG del usuario es de 256x224 con transparencia, dibujado sobre una
captura real, asi que la posicion ya es la correcta: filas 3..15,
columnas 1..30. Lo transparente = fondo del rotulo (tile 0x200).

Los 10 colores que usa son los de la PALETA 1 japonesa de esa pantalla,
verificados uno a uno. Se reescribe la paleta 3 con esos valores para que
coincidan.
"""

# paleta 1 de la pantalla de titulo japonesa (medida en el framebuffer)
PAL_JP = [
    (0x00, 0xaa, 0xee),   # 0  azul cielo  <- FONDO
    (0xee, 0x00, 0x00),   # 1  rojo
    (0x41, 0x00, 0x00),   # 2  rojo oscuro
    (0xee, 0x65, 0x00),   # 3  naranja
    (0x62, 0x20, 0x00),   # 4  marron
    (0x00, 0x00, 0xee),   # 5  azul
    (0x00, 0xaa, 0x00),   # 6  verde
    (0x00, 0x20, 0x00),   # 7  verde muy oscuro
    (0x00, 0xee, 0x62),   # 8  verde claro
    (0x00, 0xaa, 0x20),   # 9  verde medio
    (0xee, 0xee, 0x00),   # 10 amarillo
    (0x00, 0x00, 0x00),   # 11 (libre)
    (0x8b, 0x89, 0x8b),   # 12 gris
    (0x00, 0x00, 0x00),   # 13 (libre)
    (0x00, 0x00, 0x00),   # 14 negro
    (0xee, 0xee, 0xee),   # 15 blanco
]

IDX = {c: i for i, c in enumerate(PAL_JP)}
# 11, 13 y 14 comparten el negro: el original usa el 14 para el contorno
IDX[(0x00, 0x00, 0x00)] = 14

FONDO = 0            # indice del azul cielo
TILE_BASE = 0x200
MAP_ROWS, MAP_COLS = 16, 32


def rgb_to_word(r, g, b):
    """RGB de 8 bits -> word de CRAM: 0000 BBB0 GGG0 RRR0."""
    q = lambda v: min(7, (v + 0x11) // 0x22)
    return (q(b) << 9) | (q(g) << 5) | (q(r) << 1)


def palette_words():
    return [rgb_to_word(*c) for c in PAL_JP]


def png_to_indices(path):
    """Devuelve una matriz 224x256 de indices de color (transparente=FONDO)."""
    from PIL import Image
    im = Image.open(path).convert('RGBA')
    w, h = im.size
    if (w, h) != (256, 224):
        raise ValueError(f'se esperaba 256x224, es {w}x{h}')
    px = im.load()
    out = [[FONDO] * 256 for _ in range(224)]
    desconocidos = {}
    for y in range(224):
        for x in range(256):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            i = IDX.get((r, g, b))
            if i is None:
                desconocidos[(r, g, b)] = desconocidos.get((r, g, b), 0) + 1
                continue
            out[y][x] = i
    if desconocidos:
        raise ValueError(f'colores fuera de paleta: {desconocidos}')
    return out


# NOTA: hubo aqui una funcion _cerrar_cuna() que rellenaba con contorno el
# hueco entre la diagonal del rombo MD y la esquina de EDICION. ESTABA MAL:
# barria desde y=86, o sea DENTRO del emblema MD, y pintaba un mazacote
# negro que invadia el logo. El usuario lo detecto de inmediato.
# Se ha eliminado: el PNG que entrego el usuario (md5 bdb62b3f...) ya trae
# el contorno repasado a mano, asi que no hay que retocar nada.
# REGLA: no "arreglar" el arte del usuario por mi cuenta.


def build(path):
    """Devuelve (tiles, tilemap) listos para escribir en la ROM.

    tiles   : dict {indice_de_tile: bytes(32)}
    tilemap : lista de MAP_ROWS*MAP_COLS words
    """
    px = png_to_indices(path)
    tiles = {}
    orden = []
    tmap = []
    for r in range(MAP_ROWS):
        for c in range(MAP_COLS):
            blk = bytearray()
            for y in range(8):
                for xb in range(4):
                    a = px[r * 8 + y][c * 8 + xb * 2]
                    b = px[r * 8 + y][c * 8 + xb * 2 + 1]
                    blk.append((a << 4) | b)
            blk = bytes(blk)
            if blk not in tiles:
                tiles[blk] = len(orden)
                orden.append(blk)
            tmap.append(0x6000 | (TILE_BASE + tiles[blk]))
    return orden, tmap
