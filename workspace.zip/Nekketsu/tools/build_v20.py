"""build_v20.py - ROM v2.0: nombres de las escuelas en castellano.

Parte de la v1.9 y traduce los 13 nombres de la pantalla de seleccion
(DUELO 2J, estado $f800 = 0x30).

--------------------------------------------------------------------------
ESTRUCTURA (medida, no supuesta)
--------------------------------------------------------------------------
  tabla 0x02BD18, 13 descriptores de 8 bytes:
      +0 word  ancho-1 en celdas
      +2 word  alto-1  en celdas   (siempre 2 -> 3 filas)
      +4 long  puntero al tilemap

  Los 13 tilemaps van CONTIGUOS de 0x02BD80 a 0x02BFC0 (288 celdas, 576 B),
  cada uno de ancho*3 words leidos por filas, atributo 0x8000.

  EL ANCHO ES UN DATO EDITABLE, no una restriccion del motor. Esto invalida
  el temor inicial de tener que usar cuerpos de letra distintos por nombre:
  basta ampliar la caja mientras no invada la columna vecina.

  Limites por posicion en la rejilla (medidos sobre el nametable):
      izquierda cols  1..10     centro cols 12..21     derecha cols 23..31

  Anchos originales: 6 o 9 celdas. Ampliando a lo que permite cada hueco,
  12 de los 13 nombres entran con la MISMA fuente de cuerpo 5x7 y
  separacion de 1 px. Solo SHICHIFUKU (10 letras) necesita separacion 0,
  que no cambia el tamano de la letra: solo junta el interletraje.

--------------------------------------------------------------------------
ESTILO
--------------------------------------------------------------------------
Medido en el NEKKETSU japones: cuerpo blanco (indice 0xF) con contorno de
1 px (0xE) sobre fondo transparente. Es el mismo criterio que el usuario
pidio ("como la pantalla de PRIMER PARTIDO").

--------------------------------------------------------------------------
TILES
--------------------------------------------------------------------------
Van al asset de la pantalla, que la v1.9 reubico a 0x0993EA (1024 tiles,
base de VRAM 0x100). Los tiles del nombre japones quedan libres al
sustituirlos y se reutilizan; si hacen falta mas, se toman de los vacios.
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D
import escuelas as E
import hud_v14 as H
from hudtools import decomp

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_9.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v2_0.md'

# ASSET de los NOMBRES. No es el de la placa (0x0993EA): localizado por
# traza VRAM<-ROM sobre el tile 0x203, que resulto venir de aqui con base
# 0x200. Escribir en el asset equivocado producia nombres con trozos de
# kanji: los indices existian pero los tiles reales estaban en otro sitio.
ASSET = 0x064FD4
NTILES = 1024
BASE = 0x200              # tile de VRAM = BASE + indice del asset
ASSET_NEW = 0x0A3420      # hueco libre PAR verificado a 0xFF
TABLA = 0x02BD18
COORD = 0x003854          # tabla de coordenadas: 13 entradas (col, fila)
LIM_MAPAS = 0x02BFC0      # detras hay otro tilemap: no se puede desbordar
# Los tilemaps ampliados no caben en su zona original (672 B frente a 576),
# asi que se reubican al hueco libre de 0x02C780 (2178 B verificados a 0xFF).
# Como cada descriptor lleva su propio puntero, basta actualizarlos: no hay
# codigo que asuma que los 13 mapas son contiguos ni que esten donde estaban.
MAPAS_NEW = 0x02C780

# separacion de interletraje por nombre (1 salvo el que no cabe)
SEP = {'SHICHIFUKU': 0}


def main():
    rom = bytearray(open(SRC, 'rb').read())
    print(f'origen : {SRC}\n  md5  : {hashlib.md5(rom).hexdigest()}\n')

    # ---- leer los descriptores originales -------------------------------
    desc = []
    for k in range(13):
        a = TABLA + k * 8
        w = int.from_bytes(rom[a:a + 2], 'big') + 1
        h = int.from_bytes(rom[a + 2:a + 4], 'big') + 1
        p = int.from_bytes(rom[a + 4:a + 8], 'big')
        if h != E.ALTO:
            raise RuntimeError(f'#{k}: alto {h}, esperaba {E.ALTO}')
        desc.append([w, h, p])

    # ---- indices de tile REALMENTE libres -------------------------------
    # ERROR CORREGIDO: antes tomaba como "libres" los indices que usaba el
    # rotulo japones. NO lo estan: este asset lo comparten varias pantallas
    # (presentacion de partido, menu de duracion...) y esos mismos tiles se
    # usan alli. Sobrescribirlos corrompio la escena de presentacion, la
    # pantalla de DURACION PARTIDO y parte del menu.
    # Se usan EXCLUSIVAMENTE los tiles vacios (223 disponibles, hacen falta
    # ~116), y los tilemaps de los nombres se repuntan a esos indices.
    data, end, _ = decomp(bytes(rom), ASSET, NTILES)
    pool = [i for i in range(NTILES) if not any(data[i * 32:(i + 1) * 32])]
    print(f'tiles vacios disponibles en el asset: {len(pool)}')

    # ---- componer cada nombre -------------------------------------------
    big = bytearray(data)
    usado = {}
    nuevos = []
    total_celdas = 0
    plan = []
    for k, nombre in enumerate(E.NOMBRES):
        col = k % 3 if k < 12 else 0
        lo, hi = E.COLS[col]
        maxw = hi - lo + 1
        sep = SEP.get(nombre, E.SEP)
        need = E.ancho_minimo(nombre, sep)
        if need > maxw:
            raise RuntimeError(f'{nombre}: necesita {need} celdas, caben {maxw}')
        w = max(need, desc[k][0])          # no encoger por debajo del original
        w = min(w, maxw)
        px = E.build(nombre, w, sep)
        tiles = E.to_tiles(px, w)
        total_celdas += len(tiles)
        plan.append((k, nombre, desc[k][0], w, tiles))

    # ¿cabe el conjunto de tilemaps en su zona?
    need_bytes = sum(len(t) for _, _, _, _, t in plan) * 2
    disp_bytes = LIM_MAPAS - E.MAPAS
    if need_bytes <= disp_bytes:
        destino = E.MAPAS
    else:
        destino = MAPAS_NEW
        libre = 0x02D000 - MAPAS_NEW
        if need_bytes > libre:
            raise RuntimeError(f'tilemaps: {need_bytes} B > {libre} B en '
                               f'{MAPAS_NEW:#08x}')
        if any(b != 0xFF for b in rom[MAPAS_NEW:MAPAS_NEW + need_bytes]):
            raise RuntimeError(f'{MAPAS_NEW:#08x} no esta libre')
        if MAPAS_NEW % 2:
            raise RuntimeError('la direccion de reubicacion debe ser PAR')
        disp_bytes = libre
        print(f'tilemaps reubicados a {MAPAS_NEW:#08x} '
              f'({need_bytes} B; no cabian en {LIM_MAPAS - E.MAPAS})')

    # ---- escribir tiles y tilemaps --------------------------------------
    ptr = destino
    it = iter(pool)
    for k, nombre, w0, w, tiles in plan:
        idxs = []
        for blk in tiles:
            if blk in usado:
                idxs.append(usado[blk])
                continue
            t = next(it)
            usado[blk] = t
            big[t * 32:(t + 1) * 32] = blk
            idxs.append(t)
            nuevos.append(t)
        # descriptor
        a = TABLA + k * 8
        rom[a:a + 2] = (w - 1).to_bytes(2, 'big')
        rom[a + 4:a + 8] = ptr.to_bytes(4, 'big')
        # tilemap
        for i, t in enumerate(idxs):
            v = E.ATTR | (BASE + t)
            rom[ptr + i * 2:ptr + i * 2 + 2] = v.to_bytes(2, 'big')
        ptr += len(idxs) * 2
        # la columna tambien es un dato editable (tabla 0x003854). Si el
        # nombre se sale por el borde derecho de la pantalla (col 31), se
        # desplaza a la izquierda usando el hueco entre columnas.
        ca = COORD + k * 4
        col0 = int.from_bytes(rom[ca:ca + 2], 'big')
        col = col0
        if col + w - 1 > 30:
            col = 30 - w + 1
            lo, _ = E.COLS[k % 3 if k < 12 else 0]
            col = max(col, lo - 1)
            rom[ca:ca + 2] = col.to_bytes(2, 'big')
        marca = '' if w == w0 else f'  (ancho {w0} -> {w})'
        if col != col0:
            marca += f'  (col {col0} -> {col})'
        print(f'  #{k:2d} {nombre:<11} {w} celdas, {len(idxs)} tiles{marca}')

    print(f'\ntilemaps: {ptr - destino} B de {disp_bytes} disponibles')
    print(f'tiles escritos: {len(usado)} unicos')

    # ---- recomprimir el asset -------------------------------------------
    hdr = bytes(rom[ASSET:ASSET + 4])
    comp = H.compress(bytes(big), header=hdr)[0]
    disp = 0x069873 - ASSET      # fin del asset original
    if len(comp) <= disp:
        rom[ASSET:ASSET + len(comp)] = comp
        print(f'asset {ASSET:#08x}: {len(comp)} B de {disp} disponibles')
    else:
        # No cabe: se reubica y se repuntan TODOS sus punteros. El asset lo
        # referencian 44 sitios (1 lea.l en 0x00373E y 43 entradas de la
        # tabla de escenas 0x17750), asi que hay que actualizarlos todos.
        assert ASSET_NEW % 2 == 0, 'la reubicacion debe ser PAR'
        room = 0x0B0000 - ASSET_NEW
        if len(comp) > room:
            raise RuntimeError(f'asset {len(comp)} B > {room} B')
        if any(b != 0xFF for b in rom[ASSET_NEW:ASSET_NEW + len(comp)]):
            raise RuntimeError(f'{ASSET_NEW:#08x} no esta libre')
        rom[ASSET_NEW:ASSET_NEW + len(comp)] = comp
        n = 0
        for i in range(0, len(rom) - 4, 2):
            if int.from_bytes(rom[i:i + 4], 'big') == ASSET:
                rom[i:i + 4] = ASSET_NEW.to_bytes(4, 'big')
                n += 1
        print(f'asset reubicado {ASSET:#08x} -> {ASSET_NEW:#08x} '
              f'({len(comp)} B; no cabia en {disp})')
        print(f'   {n} punteros repuntados')

    # ---- checksum --------------------------------------------------------
    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    final = bytes(rom)
    if len(D.block_spans(final)) != 86:
        raise RuntimeError('la tabla de dialogos se ha roto')
    ndiff = sum(1 for a, b in zip(open(SRC, 'rb').read(), final) if a != b)
    open(DST, 'wb').write(final)
    print(f'\ndestino: {DST}')
    print(f'  md5  : {hashlib.md5(final).hexdigest()}')
    print(f'  bytes distintos respecto a la v1.9: {ndiff}')


if __name__ == '__main__':
    main()
