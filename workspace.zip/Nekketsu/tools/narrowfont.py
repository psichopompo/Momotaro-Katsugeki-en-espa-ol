"""narrowfont.py - fuente de 4 px y TIRAS DE PALABRA a paso sub-celda.

Diferencia esencial con hudfont.py (que era un error de planteamiento):
  hudfont.py mantenia 1 letra = 1 tile -> estrechar la letra NO ahorraba celdas.
  Aqui la palabra entera se pre-renderiza sobre una tira de tiles y las letras
  CRUZAN los limites de tile. El paso de avance es de 5 px, no de 8.

  PLACA = 5 letras * 5 px de avance - 1 = 24 px = EXACTAMENTE 3 tiles
  (con la fuente actual PLACA ocupa 5 tiles)
"""

ADV  = 5      # avance entre letras (cuerpo 4 px + 1 px de aire)
BODY = 4
BG, INK = 9, 15     # 9 = azul del panel (opaco), 15 = blanco

G = {
'A':[".##.",
     "#..#",
     "#..#",
     "####",
     "#..#",
     "#..#",
     "#..#"],
'C':[".###",
     "#...",
     "#...",
     "#...",
     "#...",
     "#...",
     ".###"],
'D':["###.",
     "#..#",
     "#..#",
     "#..#",
     "#..#",
     "#..#",
     "###."],
'E':["####",
     "#...",
     "#...",
     "###.",
     "#...",
     "#...",
     "####"],
'F':["####",
     "#...",
     "#...",
     "###.",
     "#...",
     "#...",
     "#..."],
'I':["###.",
     ".#..",
     ".#..",
     ".#..",
     ".#..",
     ".#..",
     "###."],
'K':["#..#",
     "#.#.",
     "##..",
     "##..",
     "#.#.",
     "#..#",
     "#..#"],
'L':["#...",
     "#...",
     "#...",
     "#...",
     "#...",
     "#...",
     "####"],
'N':["#..#",
     "##.#",
     "##.#",
     "#.##",
     "#.##",
     "#..#",
     "#..#"],
'O':[".##.",
     "#..#",
     "#..#",
     "#..#",
     "#..#",
     "#..#",
     ".##."],
'P':["###.",
     "#..#",
     "#..#",
     "###.",
     "#...",
     "#...",
     "#..."],
'R':["###.",
     "#..#",
     "#..#",
     "###.",
     "#.#.",
     "#..#",
     "#..#"],
'S':[".###",
     "#...",
     "#...",
     ".##.",
     "...#",
     "...#",
     "###."],
'T':["####",
     ".#..",
     ".#..",
     ".#..",
     ".#..",
     ".#..",
     ".#.."],
'U':["#..#",
     "#..#",
     "#..#",
     "#..#",
     "#..#",
     "#..#",
     ".##."],
}

def strip_pixels(word):
    """Devuelve (matriz 8 x W, ncells). W multiplo de 8."""
    ink_w = (len(word)-1)*ADV + BODY
    ncells = (ink_w + 7)//8
    W = ncells*8
    px = [[BG]*W for _ in range(8)]
    for i, ch in enumerate(word):
        x0 = i*ADV
        for y, row in enumerate(G[ch]):
            for x, c in enumerate(row):
                if c == '#':
                    px[y][x0+x] = INK
    return px, ncells, ink_w

def strip_tiles(word):
    """Lista de tiles (32 bytes cada uno) que forman la palabra."""
    px, ncells, _ = strip_pixels(word)
    out = []
    for c in range(ncells):
        t = bytearray()
        for y in range(8):
            for xb in range(4):
                x = c*8 + xb*2
                t.append((px[y][x] << 4) | px[y][x+1])
        out.append(bytes(t))
    return out

if __name__ == '__main__':
    for w in ('PLACA','FINTA','PASA','TIRA','CEDE','OK'):
        px, n, ink = strip_pixels(w)
        print(f'{w:6} tinta={ink:2} px  ->  {n} tiles ({n*8} px)   '
              f'(fuente actual: {len(w)} tiles)')
