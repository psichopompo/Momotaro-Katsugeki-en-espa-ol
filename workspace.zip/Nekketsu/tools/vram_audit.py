"""vram_audit.py - auditoria exhaustiva de uso de tiles en VRAM.

Muestrea CADA frame: plano A, plano B, ventana (window), tabla de sprites
y los registros del VDP (por si cambian las bases). No asume direcciones fijas.
"""
import sys
sys.path.insert(0,'/home/user/project/tools')

def bases(m):
    r = m.vdp_regs()
    return {
        'planeA': (r[2] & 0x38) << 10,
        'planeB': (r[4] & 0x07) << 13,
        'window': (r[3] & 0x3E) << 10,
        'sat':    (r[5] & 0x7F) << 9,
    }

def scan_frame(m, acc, label):
    v = m.vram()
    b = bases(m)
    # planos: 64x32 words = 0x1000 bytes
    for name in ('planeA','planeB','window'):
        base = b[name]
        for o in range(base, base+0x1000, 2):
            t = ((v[o^1]<<8) | (v[(o+1)^1])) & 0x7FF
            if t: acc.setdefault(t, set()).add(f'{name}@{label}')
    # sprites: 80 entradas de 8 bytes
    sat = b['sat']
    for s in range(80):
        o = sat + s*8
        sz = v[(o+2)^1]
        t  = ((v[(o+4)^1]<<8) | v[(o+5)^1]) & 0x7FF
        if t:
            w = ((sz>>2)&3)+1; h = (sz&3)+1
            for k in range(w*h):        # un sprite ocupa tiles CONSECUTIVOS
                acc.setdefault((t+k)&0x7FF, set()).add(f'sprite@{label}')
    return b
