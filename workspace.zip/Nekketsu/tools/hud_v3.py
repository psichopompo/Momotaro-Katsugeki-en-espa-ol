"""hud_v3.py - HUD con ANCHO INDEPENDIENTE POR SLOT.

Idea: la tabla de coordenadas pasa de 4 a 8 bytes por slot y gana un campo
"ancho". La rutina se adapta con 3 parches del MISMO tamaño (in-place):

    asl.l #2,d0      -> asl.l #3,d0        (indice *8 en vez de *4)
    lea.l $A596,a4   -> lea.l $NUEVA,a4    (tabla reubicada)
    move.w #imm,d2   -> move.w 4(a4),d2    (ancho leido de la tabla)

Nueva entrada de 8 bytes:  +0 X_sup   +2 X_inf   +4 ancho-1   +6 reserva
"""
import sys
sys.path.insert(0,'/home/user/project/tools')
from hudtools import decomp
from newletters import build

_src = open('/home/user/project/hist/scripts/recompress.py').read().split("if __name__")[0]
_ns = {}; exec(_src, _ns)
compress = _ns['compress']

ASSET_OLD  = 0x0286AA
ASSET_NEW  = 0x094000
ASSET_PTRS = [0x0020D0, 0x005102]

SAFE = {'C':0x89,'D':0x98,'F':0xA1,'I':0xFC,'L':0xFD,'N':0xFE,'R':0xFF,'T':0xEE}
EX   = {'P':0x10,'A':0x11,'U':0x12,'S':0x13,'E':0x14,'O':0x15,'K':0x16}
IDX  = dict(EX); IDX.update(SAFE)
SP = 0x8485
def W(ch): return SP if ch == ' ' else 0x8440 + IDX[ch]

# --- tablas reubicadas a zona libre verificada ---
COORD_NEW = 0x08A800          # 4 slots x 8 bytes = 32 B
TABLE     = 0x08A700          # entradas de comando

# --- parches de codigo (todos del MISMO tamaño que el original) ---
P_SUP_ASL  = (0x00A51E, bytes.fromhex('e780'))               # asl.l #3,d0
P_SUP_LEA  = (0x00A520, b'\x49\xf9' + COORD_NEW.to_bytes(4,'big'))
P_SUP_W    = (0x00A52E, bytes.fromhex('342c0004'))           # move.w 4(a4),d2
P_INF_ASL  = (0x00A55E, bytes.fromhex('e780'))
P_INF_LEA  = (0x00A560, b'\x49\xf9' + COORD_NEW.to_bytes(4,'big'))
P_INF_W    = (0x00A570, bytes.fromhex('342c0004'))

# --- geometria: (X_sup, X_inf, ancho_sup-1, ancho_inf-1) por d6 ---
# d6=3 -> slot0 (comando principal), d6=2 -> slot1 (OK / CEDE), d6=1,0 -> panel derecho
# NOTA: la tabla guarda UN ancho por slot; lo comparten sup e inf.
GEOM = {
    0: (25, 24, 1),   # panel derecho, se deja como estaba (2 cols)
    1: (21, 21, 1),
    2: ( 9,  8, 1),   # slot1: OK -> 2 columnas, NO invade el borde
    3: ( 5,  5, 1),   # slot0: se ajusta abajo
}

COMMANDS = {0:'',1:'PASA',2:'FINTA',3:'TIRA',4:'PLACA',5:'CEDE',6:'OK',7:''}
PTR_TABLE = 0x00A5C4

def entry_words(cid, cols):
    txt = COMMANDS.get(cid,'')
    if cid == 6: txt = 'OK'
    top = [SP]*cols
    bot = [W(c) for c in txt[:cols].ljust(cols)]
    return top + bot

def asset_blob(rom):
    data,_,_ = decomp(rom, ASSET_OLD, 256)
    mod = bytearray(data); g = build()
    for ch, idx in SAFE.items(): mod[idx*32:(idx+1)*32] = g[ch]
    return compress(bytes(mod), header=rom[ASSET_OLD:ASSET_OLD+4])[0]

def build_writes(rom, geom, cols_cmd):
    """geom: dict d6 -> (x_sup, x_inf, ancho-1). cols_cmd: nº columnas del slot0."""
    w = []
    blob = asset_blob(rom)
    w.append((ASSET_NEW, blob, f'asset+8 letras seguras ({len(blob)}B)'))
    for pa in ASSET_PTRS:
        w.append((pa, ASSET_NEW.to_bytes(4,'big'), 'cargador'))
    # tabla de coordenadas nueva (8 B por slot)
    for d6 in range(4):
        xs, xi, aw = geom[d6]
        base = COORD_NEW + d6*8
        w.append((base,   xs.to_bytes(2,'big'), f'd6={d6} X_sup'))
        w.append((base+2, xi.to_bytes(2,'big'), f'd6={d6} X_inf'))
        w.append((base+4, aw.to_bytes(2,'big'), f'd6={d6} ancho-1={aw}'))
        w.append((base+6, (0).to_bytes(2,'big'), f'd6={d6} reserva'))
    # entradas de comando: dimensionadas al ancho del slot0
    ENTRY = cols_cmd*2*2
    for cid in range(8):
        base = TABLE + cid*ENTRY
        for k, ww in enumerate(entry_words(cid, cols_cmd)):
            w.append((base+k*2, ww.to_bytes(2,'big'), f'cmd[{cid}] w{k}'))
    for cid in range(8):
        w.append((PTR_TABLE+cid*4, (TABLE+cid*ENTRY).to_bytes(4,'big'), f'ptr[{cid}]'))
    # parches de codigo
    for off, by in (P_SUP_ASL,P_SUP_LEA,P_SUP_W,P_INF_ASL,P_INF_LEA,P_INF_W):
        w.append((off, by, 'CODIGO'))
    return w

def apply_emu(m, rom, geom, cols_cmd):
    for off,b,_ in build_writes(rom, geom, cols_cmd):
        for k in range(0, len(b)-len(b)%2, 2):
            m.poke16(off+k, int.from_bytes(b[k:k+2],'big'))
        if len(b)%2:
            last=off+len(b)-1; cur=m.peek16(last & ~1)
            m.poke16(last & ~1, (cur & 0xFF00)|b[-1] if (last&1) else (b[-1]<<8)|(cur&0xFF))
