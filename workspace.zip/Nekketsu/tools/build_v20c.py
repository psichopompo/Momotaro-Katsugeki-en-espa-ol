"""build_v20c.py - ROM v2.0: nombres de escuela, via HOOK de VRAM.

CAMBIO DE ESTRATEGIA RESPECTO A build_v20b.py
--------------------------------------------------------------------------
La v20b fallo. Causa medida, no supuesta:

    0x004C64 / 0x003742:  move.w #$100,$fcc4     <- 256 tiles por slot

El asset 0x064FD4 tiene 1024 tiles pero el cargador SOLO SUBE LOS 256
PRIMEROS a VRAM. Solo valen los indices < 256, y ahi solo hay:

    2 tiles vacios + 23 kanji exclusivos = 25 huecos   (hacen falta 35)

Mi pool cogia indices >= 256, que nunca llegan a VRAM: de ahi las manchas.
La medicion de "+1.466 B de margen" era correcta pero irrelevante: medi el
tamano comprimido, no si los tiles llegaban a VRAM.

SOLUCION: el mismo mecanismo que ya usa el marcador. El hook 0x08F500
copia tiles DIRECTAMENTE al puerto de datos del VDP, sin pasar por el
asset ni por el limite de 256.

Ventajas medidas:
  - no consume indices del asset -> NO hay que borrar los 133 kanji
    -> desaparece el riesgo que retiro la v2.0 original
  - el asset 0x064FD4 se queda BYTE A BYTE IGUAL que en la v1.9

DESTINO EN VRAM (verificado en el emulador, no supuesto)
--------------------------------------------------------------------------
Mapa de la pantalla de seleccion (f800=0x30, rutina 0x0036EC):

    asset 0x0411d8 -> tiles 0x000..0x0ff
    asset 0x0993ea -> tiles 0x100..0x1ff
    asset 0x064fd4 -> tiles 0x200..0x2ff
    asset 0x066844 -> tiles 0x300..0x3ff
    asset 0x04e868 -> tiles 0x500..0x5ff
    planoA 0xC000 = tile 0x600, planoB 0xE000 = 0x700

El rango 0x400..0x4ff no lo carga nadie. Leyendo la VRAM real en esa
pantalla: 0x400..0x420 tiene contenido (algo lo usa aunque no figure en
la carga) y 0x430..0x4ff esta LIMPIO -> 208 tiles libres.

Se usa 0x430 en adelante: 35 tiles, hasta 0x453.

EL HOOK
--------------------------------------------------------------------------
Se intercepta 0x0037BC (`jmp $49e8`), que es el final de la carga de la
pantalla. Se sustituye por `jmp NUEVO`, y el hook copia los tiles y salta
a 0x49e8. Asi los tiles estan en VRAM antes de que se pinte nada.
"""
import sys, json, hashlib
sys.path.insert(0, '/home/user/project/tools')
import dlgtext as D
import escuelas as E
from hudtools import decomp

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_9.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v2_8.md'

# ---------- seleccion ----------
TABLA = 0x02BD18
COORD = 0x003854
MAPAS_NEW = 0x02C780
LIM_MAPAS = 0x02D000
ATTR = 0x8000
VRAM_TILE = 0x430              # primer tile libre verificado
HOOK_SITE = 0x0037BC           # jmp $49e8 al final de la carga
RET_ADDR = 0x0049E8
CODE = 0x0C4580                # zona libre para el codigo del hook
TILES_SEL = 0x0C4700           # y para los tiles

# ---------- marcador ----------
FUENTE_ROM = 0x08F600          # 26 tiles sin comprimir -> VRAM 0x280
# La fuente vieja ocupaba 0x280..0x299 (26 tiles). La nueva necesita 60 y
# 0x29A..0x2BB NO esta libre: son graficos de la escena (slot 1 = asset
# 0x064FD4 -> VRAM 0x200..0x2FF). Volcarla ahi corrompia el fondo de la 2a
# escena de presentacion.
# Hueco REAL medido leyendo la VRAM de la v1.9 en esa escena:
#   0x550..0x60d (190 tiles), 0x644..0x6bf (124), 0x77e..0x7ff (130)
#
# CORRECCION: 0x550 esta vacio EN EL MARCADOR pero NO en la escena ANTERIOR
# (59 de 60 tiles con contenido). Como el tilemap del marcador se pinta
# antes de que el hook vuelque la fuente, durante unos frames se ven los
# tiles de la escena previa: es el 'codigo raro' que reporta el usuario.
# Poner el gate a nop no bastaba, porque el hook se ejecuta despues.
#
# Hay que usar una zona vacia en AMBAS escenas. Medido cruzando las dos:
#   unica racha >= 60 tiles: 0x66e..0x6bf (82 tiles)
# Se usa 0x670 (par, con margen).
VRAM_MARC = 0x670
FUENTE_FIN = 0x08F940
CONTADOR = 0x08F518            # operando de move.w #$19f,d0
PTR_FUENTE = 0x08F50C          # operando de lea.l $8f600,a0
VRAM_CMD = 0x08F502            # operando de move.l #$50000001,$c00004
# El hook 0x08F440 solo vuelca la fuente si f80a == 0x4AF (un frame
# concreto), pero los rotulos se blitean SIEMPRE. Con la fuente vieja no se
# notaba porque VRAM 0x280 ya tenia letras; ahora que la fuente va a 0x550
# se ve un destello de basura hasta que el hook la sobrescribe.
# Se neutraliza la condicion: 0x08F446 bne.b -> nop, para que la copia se
# haga en todos los frames de la escena.
GATE_FUENTE = 0x08F446

# CODIGO RARO ANTES DE LOS NOMBRES — diagnostico del usuario, confirmado.
# Nuestro hook 0x08F400 hace `jsr $4a20` (rutina ORIGINAL) y despues pinta
# lo nuestro. La rutina original escribe en el nametable el rotulo JAPONES:
#   fila 3..5, col 36..44  -> tiles 0x390..0x392 (NEKKETSU en kanji)
#   fila 3..5, col 50..59  -> tiles 0x203..0x23a (nombre del rival)
# En nuestra ROM esos indices YA NO son kanji, asi que durante el primer
# frame de la escena se ven como basura/codigo. Es el patron que describio
# el usuario: "aparecen cuando sustituimos un grafico donde ya habia otro".
#
# Arreglo: BORRAR esas celdas con la rutina del propio juego (0x7A6E, misma
# firma que el blitter: d0=col d1=fila d2=ancho-1 d3=alto-1 d4=cmd) justo
# antes de blitear los nuestros.
# RESIDUO DEL TILEMAP VIEJO — mismo patron, detectado por el usuario en la
# pantalla de alineacion: "¿CAMBIAR POSICION?" aparece un instante con la
# 'ON' machacada y luego se corrige.
# Causa: el texto esta DUPLICADO en la ROM.
#   0x02A87C  tilemap VIEJO de la v0.9.8, con 'POSICI' + 0x0063 0x001F
#             (la O-acentuada y la N aplastadas para que cupiera)
#   0x08E2FA  tilemap NUEVO del hook, correcto: 'POSICIuN?'
# La rutina original pinta el viejo y el hook lo tapa despues.
# Arreglo: corregir el tilemap VIEJO en su sitio para que, aunque se pinte
# primero, ya sea correcto. Asi no hay residuo visible.
TILEMAP_VIEJO = 0x02A87C
TILEMAP_NUEVO = 0x08E2FA
# SOLO las celdas 3..23 son el texto "¿CAMBIAR POSICION? SI NO".
# A partir de la 27 vienen 'RE?VE?TI?' = las etiquetas RES/VEL/TIR de las
# seis tarjetas de jugador, que COMPARTEN este tilemap. Tocarlas rompio la
# pantalla en la v2.4 (aparecia 'OES' en vez de 'RES').
CELDA_INI = 3
# El "NO" del tilemap viejo esta en las celdas 25-26 y aparecia antes que
# la pregunta. RES empieza EXACTAMENTE en la 27, asi que se puede anular
# hasta la 26 inclusive sin tocar las etiquetas de las tarjetas.
CELDA_FIN = 27
N_CELDAS = 30

# CODIGO RARO DEL MARCADOR — CAUSA RAIZ [HECHO]
# El codigo ORIGINAL en 0x005172..0x0051C8 pinta los dos nombres de escuela
# de la pantalla de resultados reutilizando la tabla de descriptores de la
# SELECCION (0x02BD18): d0=f850 (nuestra escuela) y d0=f852 (rival).
#   0x00517E  lea.l $2bd18,a1   ... bsr $7a3c   -> nombre izquierdo
#   0x0051AA  lea.l $2bd18,a1   ... bsr $7a3c   -> nombre derecho
# Esos tilemaps usan la base de tile de la SELECCION (0x430). En la escena
# del marcador esa zona de VRAM contiene otra cosa, asi que durante ~7
# frames se ven katakana, numeros romanos y simbolos sueltos, hasta que
# nuestro hook 0x08F440 repinta con la base correcta (0x670).
# Medido: nametable fila3 col36 pasa de 0x451.. (base 0x430) en el frame
# +120 a 0x691.. (base 0x670) en el +128.
#
# El bloque es REDUNDANTE: nuestro hook pinta esos mismos dos nombres.
# Se anula con un salto a 0x0051CA, donde continua el resto de la rutina.
# PRESENTACION DE PARTIDO EN JAPONES a partir del 2o partido.
# El usuario juega el primer partido y la presentacion del segundo sale
# entera en japones (第2試合 / 七福学園高校戦).
# Causa: en la v0.9.8 el hook 0x08A300 hacia `jsr $c4180`, y esa rutina
# borra las bandas japonesas y pinta los rotulos en castellano leyendo
# 0x084470 (titulos) y 0x0844A4 (institutos). Desde la v1.9 ese `jsr`
# esta sustituido por un `rts`: la rutina nunca se llama.
#   v0.9.8 : 4eb9 000c4180   jsr $c4180
#   v1.9+  : 4e75 ......     rts            <-- desactivado
# La rutina y sus datos (0x0C4180, 0x0C4400, 0x0C44C0) siguen INTACTOS en
# la ROM: solo hay que restaurar la llamada.
HOOK_PRES = 0x08A300
RUT_PRES = 0x000C4180

BLOQUE_JP = 0x005172
BLOQUE_FIN = 0x0051CA

BORRA_RUT = 0x00007A6E
HOOK_ROT = 0x08F44E          # aqui empieza el blit del rotulo NEKKETSU
LIMPIA_CODE = 0x0C7000       # hueco libre (0x0C5800 lo ocupa la fuente
                             # romanica, 4.207 B; 0x0C8000 la escena club)

# CINTA: el hook 0x08C000 sustituye a `jsr $582c` en 0x0054A8, y 0x582c es
# el MOTOR DE DIALOGOS, que corre en CADA frame. Resultado: la cinta se
# borra y se redibuja 77 veces en 77 frames, y el barrido de la captura
# pilla el instante entre el borrado y el blit -> el borde inferior
# "vibra". Medido: la japonesa NUNCA llama al borrado en esa escena
# (0 hits); la v2.0 lo llama en todos los frames.
# Arreglo: que el hook dibuje la cinta SOLO la primera vez. Se usa un flag
# en RAM libre; si ya esta puesto, salta directo al motor de dialogos.
HOOK_CINTA = 0x08C000
FLAG_CINTA = 0xF7F0            # word libre en work RAM
ROTULOS = 0x08FD40
# Rotulo FIJO de NEKKETSU, blitea desde 0x08F45E con d2=9 (10 col), d3=2.
# Esta FUERA de la tabla ROTULOS y en la v2.0 anterior me lo deje sin
# actualizar: seguia con el reparto viejo de 1 tile por letra, asi que sus
# indices caian en fragmentos de otras letras -> 'NEKKETSU' cortado y los
# 'circulos a distinta altura' que reporto el usuario.
ROT_FIJO = 0x08FD00
ROT_FIJO_W = 10

# SOLAPAMIENTO v1.8/v1.9: la v1.8 reubico el asset de la ESCENA DEL CLUB a
# 0x0972AE, justo detras del rotulo del titulo (que entonces acababa en
# 0x0972AD). La v1.9 agrando el rotulo hasta 0x0972D3 y le PISO 46 bytes.
# Por eso la escena de Misako y los corazones sale corrupta desde la v1.9.
# Verificado: en jp.md y en v1.8 la escena esta perfecta; en v1.9 y v2.0 no.
# Se reubica la escena a un hueco limpio.
ESCENA_CLUB = 0x0972AE
PTR_ESCENA_CLUB = 0x017770
ESCENA_CLUB_NEW = 0x0C8000

# Off-by-one del rotulo del titulo (bug de la v1.9, detectado por el usuario)
# 0x00082A: move.w #$DE,d1 -> 222 tiles, pero el rotulo tiene 223 (0..222).
# El ultimo tile, que lleva el rabito de la O de EDICION, nunca se copiaba y
# quedaba a cero en VRAM. Verificado comparando ROM vs VRAM: 222 de 223
# tiles identicos, solo falla el 222.
CNT_TITULO = 0x00082A
N_TILES_TITULO = 223
ROT_W, ROT_H = 12, 3
TILES_MARC = 0x0C5000

NOMBRES_MARCADOR = [
    'YUSHUIN', 'SHICHIFUKU', 'SHIGUMA', 'MATAGI', 'YOSHIMOTO', 'EDOBANA',
    'IPPONZURI', 'OSOREZAN', 'YAMAMOTO', 'HORIHORI', 'HATTORI',
    'SHIMANCHU', 'CAPITANES',
]
# Limites por columna de la rejilla.
# La pantalla es H32: columnas visibles 0..31, y la 31 queda pegada al
# borde derecho. Los nombres de 10 celdas (SHICHIFUKU) terminaban en la 31
# y se veian cortados. Se comprime la rejilla hacia la izquierda para dar
# aire: la columna derecha arranca antes y termina en la 30.
# REJILLA FIJA (solucion propuesta por el usuario)
# El marco NO se calcula del descriptor: tiene su propia tabla en 0x0039D4,
# 13 entradas de 8 B = (x_px, y_celdas, ancho_celdas, alto_celdas). Al dejar
# anchos desiguales los marcos quedaban descuadrados y sus tramos de relleno
# (pri=1) tapaban letras: 'SHICHIFUKU' se veia como 'SHICHIF KU'.
#
# MARCO ADAPTABLE: el usuario pide recuperar el comportamiento original,
# en el que el marco se cine a cada nombre. Ahora es posible hacerlo BIEN
# porque el marco tiene su propia tabla (0x0039D4) y se puede ajustar por
# separado del descriptor: ancho = letras + 1, x = columna*8 - 4.
# La rejilla de 3 columnas sigue siendo fija para que queden alineados.
#
# (variante descartada) los 13 marcos con el mismo ancho de 10 celdas, que es
# el nombre mas largo (SHICHIFUKU). 3 columnas x 10 = 30 celdas de las 32.
# COL_X=[1,11,21]: la columna izquierda arranca en la 1 para que SHIMANCHU
# no quede pegado al borde. La tercera columna llega hasta la 30 con los
# nombres de 10 letras, que es el limite visible.
MARCO_W = 10
COL_X = [1, 11, 21]          # columna inicial de cada una de las 3 columnas
COLS = {i: (COL_X[i], COL_X[i] + MARCO_W - 1) for i in range(3)}
TABLA_MARCO = 0x0039D4


def cargar_fuente():
    raw = json.load(open('/home/user/project/work/fuente_usuario.json'))
    out = {}
    for ch, g in raw.items():
        tiles = []
        for r in range(3):
            blk = bytearray()
            for y in range(8):
                fila = g[r * 8 + y]
                for xb in range(4):
                    blk.append((fila[xb * 2] << 4) | fila[xb * 2 + 1])
            tiles.append(bytes(blk))
        out[ch] = tiles
    return out


def vdp_cmd(tile):
    """Comando de escritura de VRAM para un indice de tile."""
    addr = tile * 32
    return ((addr & 0x3FFF) << 16) | 0x4000_0000 | ((addr >> 14) & 3)


def main():
    rom = bytearray(open(SRC, 'rb').read())
    print(f'origen: {SRC}\n  md5 : {hashlib.md5(rom).hexdigest()}\n')

    F = cargar_fuente()
    falta = set(''.join(E.NOMBRES) + ''.join(NOMBRES_MARCADOR)) - set(F)
    if falta:
        raise RuntimeError(f'faltan glifos: {sorted(falta)}')

    # banco unico de tiles: letra -> [t0,t1,t2] indices relativos
    orden = sorted(F)
    banco, pos = [], {}
    for ch in orden:
        pos[ch] = len(banco)
        banco.extend(F[ch])
    nt = len(banco)
    blob = b''.join(banco)
    print(f'banco: {len(orden)} letras x 3 filas = {nt} tiles, {len(blob)} B')

    # ================================================================
    # A) SELECCION — tiles por hook, el asset NO se toca
    # ================================================================
    print('\n=== A) pantalla de seleccion ===')
    if VRAM_TILE + nt > 0x500:
        raise RuntimeError(f'los tiles pisan el slot de 0x500: '
                           f'{VRAM_TILE + nt:#05x}')
    print(f'  VRAM {VRAM_TILE:#05x}..{VRAM_TILE + nt - 1:#05x} '
          f'(libre verificado 0x430..0x4ff)')

    for a, n in ((TILES_SEL, len(blob)), (CODE, 0x80)):
        if any(b != 0xFF for b in rom[a:a + n]):
            raise RuntimeError(f'{a:#08x} no esta libre')
        assert a % 2 == 0
    rom[TILES_SEL:TILES_SEL + len(blob)] = blob

    # --- codigo del hook (68000) ---
    #   move.l #cmd,$c00004 ; lea tiles,a0 ; lea $c00000,a1
    #   move.w #n-1,d0 ; loop: move.w (a0)+,(a1) ; dbra ; jmp $49e8
    words = len(blob) // 2
    cmd = vdp_cmd(VRAM_TILE)
    code = bytearray()
    code += bytes.fromhex('23FC') + cmd.to_bytes(4, 'big') \
        + (0x00C00004).to_bytes(4, 'big')          # move.l #cmd,$c00004
    code += bytes.fromhex('41F9') + TILES_SEL.to_bytes(4, 'big')   # lea tiles,a0
    code += bytes.fromhex('43F9') + (0x00C00000).to_bytes(4, 'big')  # lea $c00000,a1
    code += bytes.fromhex('303C') + (words - 1).to_bytes(2, 'big')   # move.w #n,d0
    code += bytes.fromhex('32D8')                                    # move.w (a0)+,(a1)+
    code = code[:-2] + bytes.fromhex('3298')                         # move.w (a0)+,(a1)
    code += bytes.fromhex('51C8') + (0xFFFC).to_bytes(2, 'big')      # dbra d0,-4
    code += bytes.fromhex('4EF9') + RET_ADDR.to_bytes(4, 'big')      # jmp $49e8
    rom[CODE:CODE + len(code)] = code
    print(f'  hook en {CODE:#08x} ({len(code)} B), tiles en {TILES_SEL:#08x}')

    # interceptar el final de la carga
    old = int.from_bytes(rom[HOOK_SITE:HOOK_SITE + 6], 'big')
    esperado = (0x4EF9 << 32) | RET_ADDR
    if old != esperado:
        raise RuntimeError(f'{HOOK_SITE:#08x} no es jmp ${RET_ADDR:x} '
                           f'({old:#014x})')
    rom[HOOK_SITE:HOOK_SITE + 2] = bytes.fromhex('4EF9')
    rom[HOOK_SITE + 2:HOOK_SITE + 6] = CODE.to_bytes(4, 'big')
    print(f'  {HOOK_SITE:#08x}: jmp {RET_ADDR:#08x} -> jmp {CODE:#08x}')

    # --- tilemaps ---
    need = sum(len(n) for n in E.NOMBRES) * 3 * 2
    if need > LIM_MAPAS - MAPAS_NEW:
        raise RuntimeError(f'tilemaps {need} B no caben')
    if any(b != 0xFF for b in rom[MAPAS_NEW:MAPAS_NEW + need]):
        raise RuntimeError(f'{MAPAS_NEW:#08x} no esta libre')

    ptr = MAPAS_NEW
    for k, nombre in enumerate(E.NOMBRES):
        w = len(nombre)
        a = TABLA + k * 8
        rom[a:a + 2] = (w - 1).to_bytes(2, 'big')
        rom[a + 2:a + 4] = (2).to_bytes(2, 'big')
        rom[a + 4:a + 8] = ptr.to_bytes(4, 'big')
        for r in range(3):
            for ch in nombre:
                t = VRAM_TILE + pos[ch] + r
                rom[ptr:ptr + 2] = (ATTR | t).to_bytes(2, 'big')
                ptr += 2
        grp = k % 3 if k < 12 else 0
        lo, _ = COLS[grp]
        # ALINEADO A LA IZQUIERDA (propuesta del usuario). Centrar cada
        # nombre en su columna hacia que SHIMANCHU, el unico de la ultima
        # fila, quedara descolgado respecto a los de arriba. Alineando a la
        # izquierda las tres columnas quedan a plomo y da igual la longitud
        # de cada nombre.
        col = lo
        ca = COORD + k * 4
        col0 = int.from_bytes(rom[ca:ca + 2], 'big')
        fila = int.from_bytes(rom[ca + 2:ca + 4], 'big')
        rom[ca:ca + 2] = col.to_bytes(2, 'big')
        # marco fijo: misma anchura para los 13, alineado con la columna
        ma = TABLA_MARCO + k * 8
        mx0 = int.from_bytes(rom[ma:ma + 2], 'big')
        mw0 = int.from_bytes(rom[ma + 4:ma + 6], 'big')
        # MARCO ADAPTABLE (como el original japones): se cine al nombre.
        # El nombre ocupa w celdas empezando en `col`; el marco lleva media
        # celda de holgura a cada lado.
        rom[ma:ma + 2] = max(0, col * 8 - 4).to_bytes(2, 'big')
        rom[ma + 4:ma + 6] = (w + 1).to_bytes(2, 'big')
        print(f'  #{k:2d} {nombre:<11} {w:2d} celdas  col {col0}->{col}  '
              f'marco x {mx0}->{max(0, col * 8 - 4)} w {mw0}->{w + 1}')
    print(f'  tilemaps: {ptr - MAPAS_NEW} B en {MAPAS_NEW:#08x}')

    # el asset debe quedar INTACTO
    orig = open(SRC, 'rb').read()
    if rom[0x064FD4:0x069873] != orig[0x064FD4:0x069873]:
        raise RuntimeError('el asset 0x064FD4 se ha modificado')
    print('  asset 0x064FD4: INTACTO (byte a byte igual que la v1.9)')

    # ================================================================
    # B) MARCADOR
    # ================================================================
    print('\n=== B) pantalla de resultados ===')
    if any(b != 0xFF for b in rom[TILES_MARC:TILES_MARC + len(blob)]):
        raise RuntimeError(f'{TILES_MARC:#08x} no esta libre')
    rom[TILES_MARC:TILES_MARC + len(blob)] = blob
    rom[PTR_FUENTE:PTR_FUENTE + 4] = TILES_MARC.to_bytes(4, 'big')
    rom[CONTADOR:CONTADOR + 2] = (words - 1).to_bytes(2, 'big')
    # redirigir el volcado al hueco libre verificado
    rom[VRAM_CMD:VRAM_CMD + 4] = vdp_cmd(VRAM_MARC).to_bytes(4, 'big')
    print(f'  fuente {FUENTE_ROM:#08x} -> {TILES_MARC:#08x} ({len(blob)} B)')
    print(f'  contador: #{words - 1:#x} ({words} words)')
    if VRAM_MARC + nt > 0x6C0:
        raise RuntimeError('la fuente se sale de la racha libre 0x66e..0x6bf')
    print(f'  VRAM {VRAM_MARC:#05x}..{VRAM_MARC + nt - 1:#05x} '
          f'(hueco verificado, plano A en 0x600)')

    VACIO = 0xC401
    for k, nombre in enumerate(NOMBRES_MARCADOR):
        p = int.from_bytes(rom[ROTULOS + k * 4:ROTULOS + k * 4 + 4], 'big')
        if len(nombre) > ROT_W:
            raise RuntimeError(f'{nombre} no cabe en {ROT_W}')
        x0 = (ROT_W - len(nombre)) // 2
        celdas = [VACIO] * (ROT_W * ROT_H)
        for r in range(3):
            for j, ch in enumerate(nombre):
                celdas[r * ROT_W + x0 + j] = 0x8000 | (VRAM_MARC + pos[ch] + r)
        for i, v in enumerate(celdas):
            rom[p + i * 2:p + i * 2 + 2] = v.to_bytes(2, 'big')
    # rotulo FIJO de NEKKETSU (fuera de la tabla)
    nk = 'NEKKETSU'
    x0 = (ROT_FIJO_W - len(nk)) // 2
    celdas = [VACIO] * (ROT_FIJO_W * ROT_H)
    for r in range(3):
        for j, ch in enumerate(nk):
            celdas[r * ROT_FIJO_W + x0 + j] = 0x8000 | (VRAM_MARC + pos[ch] + r)
    for i, v in enumerate(celdas):
        rom[ROT_FIJO + i * 2:ROT_FIJO + i * 2 + 2] = v.to_bytes(2, 'big')
    print(f'  {len(NOMBRES_MARCADOR)} rotulos + el fijo NEKKETSU reescritos')

    # --- restaurar la presentacion de partido en castellano ---
    if bytes(rom[HOOK_PRES:HOOK_PRES + 2]) == bytes.fromhex('4e75'):
        rom[HOOK_PRES:HOOK_PRES + 2] = bytes.fromhex('4eb9')
        rom[HOOK_PRES + 2:HOOK_PRES + 6] = RUT_PRES.to_bytes(4, 'big')
        print(f'\n=== I) presentacion de partido en japones ===')
        print(f'  {HOOK_PRES:#08x}: rts -> jsr {RUT_PRES:#08x} (restaurado)')
    else:
        print(f'\n=== I) presentacion: {HOOK_PRES:#08x} ya activo ===')

    # --- anular el pintado japones de los nombres del marcador ---
    desp = BLOQUE_FIN - (BLOQUE_JP + 2)
    if bytes(rom[BLOQUE_JP:BLOQUE_JP + 2]) != bytes.fromhex('3038'):
        raise RuntimeError(f'{BLOQUE_JP:#08x} no es el move.w $f850,d0 '
                           f'esperado: {rom[BLOQUE_JP]:02x}{rom[BLOQUE_JP+1]:02x}')
    rom[BLOQUE_JP:BLOQUE_JP + 2] = bytes.fromhex('6000')
    rom[BLOQUE_JP + 2:BLOQUE_JP + 4] = desp.to_bytes(2, 'big')
    print(f'\n=== H) codigo raro del marcador ===')
    print(f'  {BLOQUE_JP:#08x}: bra.w {BLOQUE_FIN:#08x} (desp {desp:#06x})')
    print(f'  anulado el pintado japones que usaba la base de tile 0x430')

    # --- eliminar el dibujado VIEJO de "CAMBIAR POSICION" ---
    # Intento anterior (v2.4) FALLIDO: copie el tilemap nuevo sobre el
    # viejo celda a celda. El nuevo usa 3 celdas ('u','N','?') donde el
    # viejo usaba 2, asi que TODO lo de detras se corrio una posicion: el
    # "NO" desaparecio y la 'R' de "RES" se convirtio en 'O' en las seis
    # tarjetas de jugador. Daño colateral por no comprobar la longitud.
    #
    # Metodo correcto (el que ya funciono en otros casos, recordado por el
    # usuario): NO alinear, sino ANULAR el dibujado viejo. Se rellena el
    # tilemap viejo con la celda de espacio para que no pinte nada; el hook
    # dibuja despues la version buena.
    ESPACIO = 0x0000
    n_borradas = 0
    for i in range(CELDA_INI, CELDA_FIN):
        a = TILEMAP_VIEJO + i * 2
        if int.from_bytes(rom[a:a + 2], 'big') != ESPACIO:
            rom[a:a + 2] = ESPACIO.to_bytes(2, 'big')
            n_borradas += 1
    print(f'\n=== G) residuo de "CAMBIAR POSICION" ===')
    print(f'  tilemap viejo {TILEMAP_VIEJO:#08x}: {n_borradas} celdas anuladas')

    # --- limpiar el rotulo japones antes de pintar el nuestro ---
    # Se inserta una rutina que borra las dos zonas y luego salta al blit
    # original. El hook 0x08F440 pasa a llamarla.
    lim = bytearray()
    for col, anch in ((36, 11), (50, 11)):
        lim += bytes.fromhex('303C') + col.to_bytes(2, 'big')       # move.w #col,d0
        lim += bytes.fromhex('323C') + (3).to_bytes(2, 'big')       # move.w #3,d1
        lim += bytes.fromhex('343C') + (anch - 1).to_bytes(2, 'big')  # d2
        lim += bytes.fromhex('363C') + (2).to_bytes(2, 'big')       # d3
        lim += bytes.fromhex('383C') + (0x4000).to_bytes(2, 'big')  # d4
        lim += bytes.fromhex('4EB9') + BORRA_RUT.to_bytes(4, 'big')
    lim += bytes.fromhex('4E75')                                     # rts
    assert LIMPIA_CODE % 2 == 0
    if bytes(rom[0x08F448:0x08F44E]) != bytes.fromhex('4eb90008f500'):
        raise RuntimeError('0x08F448 no es el jsr $8f500 esperado')
    # ENGANCHE: 0x08F448 es `jsr $8f500` (volcado de la fuente). Se cambia
    # el destino a nuestra rutina de limpieza, que hara el volcado y luego
    # borrara las celdas del rotulo japones.
    #   nueva rutina: jsr $8f500 ; <borrados> ; rts
    lim2 = bytes.fromhex('4EB9') + (0x0008F500).to_bytes(4, 'big') + bytes(lim)
    if any(b != 0xFF for b in rom[LIMPIA_CODE:LIMPIA_CODE + len(lim2)]):
        raise RuntimeError(f'{LIMPIA_CODE:#08x} no esta libre')
    rom[LIMPIA_CODE:LIMPIA_CODE + len(lim2)] = lim2
    rom[0x08F44A:0x08F44E] = LIMPIA_CODE.to_bytes(4, 'big')
    print(f'  limpieza del rotulo japones en {LIMPIA_CODE:#08x} '
          f'({len(lim2)} B), enganchada en 0x08F44A')

    # quitar el gate temporal: si no, hay un destello de basura antes de
    # que la fuente llegue a VRAM
    if bytes(rom[GATE_FUENTE:GATE_FUENTE + 2]) != bytes.fromhex('6606'):
        raise RuntimeError(f'{GATE_FUENTE:#08x} no es el bne.b esperado: '
                           f'{rom[GATE_FUENTE]:02x}{rom[GATE_FUENTE+1]:02x}')
    rom[GATE_FUENTE:GATE_FUENTE + 2] = bytes.fromhex('4E71')   # nop
    print(f'  {GATE_FUENTE:#08x}: bne.b -> nop (la fuente se vuelca siempre)')

    # ================================================================
    # F) la cinta se redibuja en cada frame -> parpadeo del borde
    # ================================================================
    print('\n=== F) cinta redibujada cada frame (parpadeo del borde) ===')
    if bytes(rom[HOOK_CINTA:HOOK_CINTA + 12]) != bytes.fromhex(
            '4eb90000582c4eb90008c040'):
        raise RuntimeError(f'{HOOK_CINTA:#08x} no tiene el patron esperado')
    # nuevo envoltorio:
    #   tst.w FLAG ; bne ya ; move.w #1,FLAG ; jsr $8c040
    #   ya: jsr $582c ; rts
    code = bytearray()
    code += bytes.fromhex('4A78') + (FLAG_CINTA & 0xFFFF).to_bytes(2, 'big')
    # bne.b: destino = (PC+2) + desp = offset 6 + desp.
    # Hay que saltar al offset 18 (el jsr $582C), asi que desp = 12 = 0x0C.
    # Con 0x08 caia en el offset 14, EN MEDIO de `4EB9 0008C040`, y el
    # 68000 ejecutaba basura -> cuelgue con la nota de sonido colgada.
    code += bytes.fromhex('660C')                       # bne.b -> offset 18
    code += bytes.fromhex('31FC0001') + (FLAG_CINTA & 0xFFFF).to_bytes(2, 'big')
    code += bytes.fromhex('4EB9') + (0x0008C040).to_bytes(4, 'big')
    code += bytes.fromhex('4EB9') + (0x0000582C).to_bytes(4, 'big')
    code += bytes.fromhex('4E75')
    if len(code) > 0x40:
        raise RuntimeError('el envoltorio no cabe')
    rom[HOOK_CINTA:HOOK_CINTA + len(code)] = code
    print(f'  {HOOK_CINTA:#08x}: la cinta se dibuja una sola vez '
          f'(flag en {FLAG_CINTA:#06x})')

    # ================================================================
    # D) BUG DE LA v1.9: falta 1 tile del rotulo del titulo
    # ================================================================
    print('\n=== D) off-by-one del rotulo del titulo (bug de la v1.9) ===')
    n_ant = int.from_bytes(rom[CNT_TITULO:CNT_TITULO + 2], 'big')
    if n_ant != N_TILES_TITULO - 1:
        raise RuntimeError(f'{CNT_TITULO:#08x} vale {n_ant}, esperaba '
                           f'{N_TILES_TITULO - 1}')
    rom[CNT_TITULO:CNT_TITULO + 2] = N_TILES_TITULO.to_bytes(2, 'big')
    print(f'  {CNT_TITULO:#08x}: #{n_ant} -> #{N_TILES_TITULO} tiles')
    print(f'  recupera el tile 222 (rabito de la O de EDICION)')

    # --- reescribir el rotulo con la cuna cerrada ---
    import titulo as _T
    import hud_v14 as _H2
    orden_t, tmap_t = _T.build('/home/user/uploads/IMG_4512.PNG')
    if len(orden_t) != N_TILES_TITULO:
        raise RuntimeError(f'el rotulo da {len(orden_t)} tiles, '
                           f'esperaba {N_TILES_TITULO}')
    hdr_t = bytes(rom[0x096000:0x096004])
    comp_t = _H2.compress(b''.join(orden_t), header=hdr_t)[0]
    # el rotulo NO puede crecer hasta pisar la escena del club (0x0972AE)
    room_t = ESCENA_CLUB - 0x096000
    if len(comp_t) > room_t:
        print(f'  aviso: {len(comp_t)} B > {room_t} B hasta la escena; '
              f'la escena se reubica de todos modos')
    rom[0x096000:0x096000 + len(comp_t)] = comp_t
    for i, w in enumerate(tmap_t):
        rom[0x0A3000 + i * 2:0x0A3000 + i * 2 + 2] = w.to_bytes(2, 'big')
    print(f'  rotulo reescrito: {len(comp_t)} B, {len(orden_t)} tiles')

    # ================================================================
    # E) SOLAPAMIENTO v1.9: el rotulo del titulo pisa la escena del club
    # ================================================================
    print('\n=== E) escena del club pisada por el rotulo (bug de la v1.9) ===')
    from hudtools import decomp as _dec
    v18 = open('/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_8.md',
               'rb').read()
    _, _, fin_tit = _dec(bytes(rom), 0x096000, N_TILES_TITULO)
    print(f'  el rotulo del titulo acaba en {fin_tit:#08x}')
    print(f'  la escena del club empieza en {ESCENA_CLUB:#08x}')
    if fin_tit <= ESCENA_CLUB:
        print('  no hay solapamiento')
    else:
        print(f'  SOLAPAN {fin_tit - ESCENA_CLUB} B -> se reubica la escena')
        # el asset intacto esta en la v1.8, que aun no lo habia pisado
        _, _, fin_esc = _dec(v18, ESCENA_CLUB, 256)
        blob_esc = v18[ESCENA_CLUB:fin_esc]
        assert ESCENA_CLUB_NEW % 2 == 0
        if any(b != 0xFF for b in
               rom[ESCENA_CLUB_NEW:ESCENA_CLUB_NEW + len(blob_esc)]):
            raise RuntimeError(f'{ESCENA_CLUB_NEW:#08x} no esta libre')
        rom[ESCENA_CLUB_NEW:ESCENA_CLUB_NEW + len(blob_esc)] = blob_esc
        v = int.from_bytes(rom[PTR_ESCENA_CLUB:PTR_ESCENA_CLUB + 4], 'big')
        if v != ESCENA_CLUB:
            raise RuntimeError(f'{PTR_ESCENA_CLUB:#08x} = {v:#08x}')
        rom[PTR_ESCENA_CLUB:PTR_ESCENA_CLUB + 4] = \
            ESCENA_CLUB_NEW.to_bytes(4, 'big')
        print(f'  escena {ESCENA_CLUB:#08x} -> {ESCENA_CLUB_NEW:#08x} '
              f'({len(blob_esc)} B, tomada intacta de la v1.8)')

    # ================================================================
    # C) BUG PREEXISTENTE: acentos de la fuente románica
    # ================================================================
    print('\n=== C) acentos de la fuente del titulo (bug de la v1.8) ===')
    n_c, disp_c, donde = injertar_acentos(rom)
    print(f'  injertados 8 glifos (¿ ¡ Á É Í Ó Ú Ñ) desde la v1.7')
    if donde == FUENTE_TIT:
        print(f'  fuente {FUENTE_TIT:#08x}: {n_c} B de {disp_c}')
    else:
        print(f'  fuente reubicada {FUENTE_TIT:#08x} -> {donde:#08x} '
              f'({n_c} B; no cabia en {disp_c})')

    # ================================================================
    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    final = bytes(rom)
    n = len(D.block_spans(final))
    if n != 86:
        raise RuntimeError(f'dialogos rotos: {n}')
    ndiff = sum(1 for a, b in zip(orig, final) if a != b)
    open(DST, 'wb').write(final)
    print(f'\ndestino: {DST}')
    print(f'  md5 : {hashlib.md5(final).hexdigest()}')
    print(f'  bytes distintos vs v1.9: {ndiff}')
    print(f'  dialogos: {n} bloques OK')


# ==========================================================================
# BUG PREEXISTENTE: acentos y signos en la fuente románica
# --------------------------------------------------------------------------
# La v1.8 restauró la fuente románica japonesa 0x02767A para el título y los
# menús. Esa fuente NO tiene vocales acentuadas ni signos invertidos:
#
#     0x50 ¿   0x51 ¡   0x52 Á   0x53 É   0x54 Í   -> VACÍOS
#     0x55 Ó   0x56 Ú   0x57 Ñ                     -> son KANJI
#
# Por eso "DURACIÓN PARTIDO" (cadena en 0x000DAC, con 'u'=0x75 -> tile 0x55)
# mostraba un kanji en lugar de la Ó.
#
# IMPORTANTE: NO lo introdujo la v2.0. Verificado comparando las ROMs:
#     v1.7 (fuente 0x091100): tile 0x55 = 'Ó' correcta
#     v1.8 / v1.9 / v2.0     : tile 0x55 = kanji
# Es una regresión de la v1.8 que llevaba dos versiones sin detectarse.
#
# Los 8 glifos existen en la fuente de la v1.7. Se injertan.
DONANTE = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_7.md'
FUENTE_TIT = 0x02767A
FUENTE_TIT_FIN = 0x0286AA
GLIFOS_ES = list(range(0x50, 0x58))
FUENTE_TIT_NEW = 0x0C5800     # hueco libre par, por si no cabe con acentos
PTR_FUENTE_TIT = 0x000842     # lea.l de la fuente del titulo/menu


def injertar_acentos(rom):
    """Copia ¿ ¡ Á É Í Ó Ú Ñ de la fuente de la v1.7 a la románica."""
    import hud_v14 as _H
    from hudtools import decomp as _dec
    don = open(DONANTE, 'rb').read()
    src, _, _ = _dec(don, 0x091100, 256)
    dst, _, _ = _dec(bytes(rom), FUENTE_TIT, 256)
    dst = bytearray(dst)
    for c in GLIFOS_ES:
        dst[c * 32:(c + 1) * 32] = src[c * 32:(c + 1) * 32]
    hdr = bytes(rom[FUENTE_TIT:FUENTE_TIT + 4])
    comp = _H.compress(bytes(dst), header=hdr)[0]
    disp = FUENTE_TIT_FIN - FUENTE_TIT
    if len(comp) <= disp:
        rom[FUENTE_TIT:FUENTE_TIT + len(comp)] = comp
        if len(comp) < disp:
            rom[FUENTE_TIT + len(comp):FUENTE_TIT_FIN] = \
                b'\xFF' * (disp - len(comp))
        return len(comp), disp, FUENTE_TIT

    # No cabe (con los acentos sube a 4.207 B frente a 4.144). Se reubica.
    # Punteros verificados: SOLO 1 real, el lea.l de 0x000842 (el mismo que
    # cambio la v1.8). Los otros 4 candidatos del escaneo son bytes
    # identicos a la ROM japonesa, o sea datos, no punteros.
    assert FUENTE_TIT_NEW % 2 == 0
    if any(b != 0xFF for b in rom[FUENTE_TIT_NEW:FUENTE_TIT_NEW + len(comp)]):
        raise RuntimeError(f'{FUENTE_TIT_NEW:#08x} no esta libre')
    rom[FUENTE_TIT_NEW:FUENTE_TIT_NEW + len(comp)] = comp
    v = int.from_bytes(rom[PTR_FUENTE_TIT:PTR_FUENTE_TIT + 4], 'big')
    if v != FUENTE_TIT:
        raise RuntimeError(f'{PTR_FUENTE_TIT:#08x} no apunta a la fuente')
    rom[PTR_FUENTE_TIT:PTR_FUENTE_TIT + 4] = FUENTE_TIT_NEW.to_bytes(4, 'big')
    return len(comp), disp, FUENTE_TIT_NEW


if __name__ == '__main__':
    main()
