"""build_v12.py - construye la ROM v1.2 (HUD cuerpo 4 px) a partir de la v1.1.

A diferencia de try4.py (que parchea la copia en RAM del emulador), este script
escribe un FICHERO .md real. Cada escritura queda registrada con offset, bytes
y motivo, para poder auditarla.

Autorizado explicitamente por el usuario.
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')
import hud_v14 as H
import font4
from hudtools import decomp

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_1.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_2.md'

BG, INK = 9, 15
PANEL_BG = 0x8485
WORDS = ['PASA', 'TIRA', 'CEDE', 'PLACA', 'FINTA', 'OK']
CMD = {1: 'PASA', 2: 'FINTA', 3: 'TIRA', 4: 'PLACA', 5: 'CEDE', 6: 'OK'}

N_TILES = 272                 # VRAM 0x440..0x54F (hueco lleno justo)
X_LEFT, X_RIGHT = 4, 21
SLOT_W = 3
OFF_MAIN, OFF_SEC = 0, 4
ALIGN_L = 0                   # decision del usuario: cuerpo 4 px sin alinear


def word_tiles(word):
    w = font4.word_width(word)
    n = (w + 7) // 8
    W = n * 8
    px = [[BG] * W for _ in range(8)]
    g = font4.render(word)
    for y in range(7):
        for dx in range(len(g[0])):
            if g[y][dx]:
                px[y][dx] = INK
    out = []
    for c in range(n):
        t = bytearray()
        for y in range(8):
            for xb in range(4):
                X = c * 8 + xb * 2
                t.append((px[y][X] << 4) | px[y][X + 1])
        out.append(bytes(t))
    return out, n, w


def build_catalog():
    cat = {}; tiles = []; idx = 256
    for w in WORDS:
        ts, n, px = word_tiles(w)
        cat[w] = (idx, n, px)
        tiles += ts; idx += n
    return cat, tiles


def build_writes(rom):
    """Devuelve [(offset, bytes, motivo)] - todo lo que cambia respecto a v1.1."""
    w = []
    cat, tiles = build_catalog()

    # --- 1. asset ampliado con el catalogo de palabras ---
    data, _, _ = decomp(rom, H.ASSET_OLD, 256)
    big = bytearray(data)
    for t in tiles:
        big += t
    while len(big) // 32 < N_TILES:
        big += bytes([BG * 17]) * 32
    assert len(big) // 32 == N_TILES, len(big) // 32
    blob = H.compress(bytes(big), header=rom[H.ASSET_OLD:H.ASSET_OLD + 4])[0]
    w.append((H.ASSET_NEW, blob,
              f'asset HUD {N_TILES} tiles, catalogo cuerpo 4px ({len(blob)} B)'))

    # --- 2. numero de tiles a descomprimir (d1) en los dos cargadores ---
    for pd in H.D1_PTRS:
        w.append((pd + 2, N_TILES.to_bytes(2, 'big'), f'd1 = {N_TILES}'))

    # --- 3. tabla GEOM por slot ---
    #   d6=3 slot0 IZQ principal | d6=2 slot1 IZQ secundario
    #   d6=1 slot2 DER principal | d6=0 slot3 DER secundario
    geom = {
        3: (X_LEFT + OFF_MAIN + ALIGN_L, SLOT_W, H.TBL_S0),
        2: (X_LEFT + OFF_SEC + ALIGN_L,  SLOT_W, H.TBL_S1),
        1: (X_RIGHT + OFF_MAIN,          SLOT_W, H.TBL_S2),
        0: (X_RIGHT + OFF_SEC,           SLOT_W, H.TBL_S3),
    }
    for d6, (x, cols, tbl) in geom.items():
        b = H.COORD + d6 * 16
        # +0 X_sup NO se toca: mueve las flechas indicadoras de la fila 23
        w.append((b + 2,  x.to_bytes(2, 'big'),        f'd6={d6} X_inf={x}'))
        w.append((b + 4,  (cols - 1).to_bytes(2, 'big'), f'd6={d6} ancho-1'))
        w.append((b + 6,  (0x19).to_bytes(2, 'big'),   f'd6={d6} Y=25'))
        w.append((b + 8,  tbl.to_bytes(4, 'big'),      f'd6={d6} tabla'))
        w.append((b + 12, (1).to_bytes(2, 'big'),      f'd6={d6} ancho_sup-1'))

    # --- 4. tablas de palabra por slot ---
    for tbl in (H.TBL_S0, H.TBL_S1, H.TBL_S2, H.TBL_S3):
        ent = SLOT_W * 2 * 2
        base = tbl + 32
        for cid in range(8):
            e = base + cid * ent
            w.append((tbl + cid * 4, e.to_bytes(4, 'big'), f'ptr cmd {cid}'))
            word = CMD.get(cid)
            if word:
                i, n, _ = cat[word]
                row = [0x8440 + i + k for k in range(n)][:SLOT_W]
                row += [PANEL_BG] * (SLOT_W - len(row))
            else:
                row = [PANEL_BG] * SLOT_W
            # fila superior vacia + fila inferior con la palabra
            for k, ww in enumerate([PANEL_BG] * SLOT_W + row):
                w.append((e + k * 2, ww.to_bytes(2, 'big'),
                          f'cmd {cid} {word or "-"}'))
    return w, cat


def main():
    rom = bytearray(open(SRC, 'rb').read())
    src_md5 = hashlib.md5(rom).hexdigest()
    writes, cat = build_writes(bytes(rom))

    touched = set()
    for off, b, _ in writes:
        for k in range(len(b)):
            touched.add(off + k)
        rom[off:off + len(b)] = b

    open(DST, 'wb').write(bytes(rom))
    dst_md5 = hashlib.md5(rom).hexdigest()

    print(f'origen  : {SRC}')
    print(f'  md5   : {src_md5}')
    print(f'destino : {DST}')
    print(f'  md5   : {dst_md5}')
    print(f'  tamano: {len(rom)} bytes')
    print()
    print(f'escrituras : {len(writes)}')
    print(f'bytes tocados: {len(touched)}')
    print()
    print('catalogo:')
    for wd in WORDS:
        i, n, px = cat[wd]
        print(f'  {wd:6} idx={i:3} VRAM={0x440+i:#05x} {n} tiles {px:2} px')
    return writes, touched


if __name__ == '__main__':
    main()
