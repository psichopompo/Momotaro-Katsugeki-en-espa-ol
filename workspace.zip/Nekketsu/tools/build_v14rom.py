"""build_v14rom.py - ROM v1.4: corrige los dos bugs de la presentacion.

Parte de la v1.3 y aplica exactamente 4 bytes, ambos en zona de codigo ya
analizada. Ver investigation.md para el diagnostico completo.

FIX 1 - imagen cortada por arriba
  0x0C418E:  0007 -> 0005
  La rutina 0x0C4180 borraba las filas 2..9 antes de repintar el titulo, pero
  las filas 8 y 9 son escena legitima y se perdian. Se reduce a filas 2..7.
  No se puede bajar mas: la fila 6 lleva el titulo JAPONES incrustado en el
  stream de la escena y hay que seguir tapandolo.

FIX 2 - parpadeo del letrero
  0x08A300:  4EB9 -> 4E75  (jsr $c4180 -> rts)
  0x08A300 se llamaba cada frame desde 0x08A60E y hacia borrado + repintado
  completo del titulo. Es redundante: 0x0C4300 ya pinta una vez al entrar en
  el estado. Demostrado: VRAM identica con y sin el redibujado.
"""
import sys, hashlib
sys.path.insert(0, '/home/user/project/tools')

SRC = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_3.md'
DST = '/home/user/project/rom/Nekketsu_Soccer_MD_ES_v1_4.md'

WRITES = [
    (0x0C418E, bytes.fromhex('0005'),
     'FIX1 d3=5: borrar filas 2..7 (antes 2..9) - preserva la escena'),
    (0x08A300, bytes.fromhex('4e75'),
     'FIX2 rts: elimina el redibujado por frame - quita el parpadeo'),
]


def main():
    rom = bytearray(open(SRC, 'rb').read())
    src_md5 = hashlib.md5(rom).hexdigest()

    # comprobacion de seguridad: los bytes de partida deben ser los esperados
    expect = {0x0C418E: bytes.fromhex('0007'), 0x08A300: bytes.fromhex('4eb9')}
    for off, exp in expect.items():
        got = bytes(rom[off:off + len(exp)])
        if got != exp:
            raise RuntimeError(f'{off:#08x}: esperaba {exp.hex()} y hay {got.hex()}')

    for off, b, _ in WRITES:
        rom[off:off + len(b)] = b

    calc = sum(int.from_bytes(rom[i:i + 2], 'big')
               for i in range(0x200, len(rom), 2)) & 0xFFFF
    rom[0x18e] = (calc >> 8) & 0xFF
    rom[0x18f] = calc & 0xFF

    open(DST, 'wb').write(bytes(rom))
    print(f'origen : {SRC}')
    print(f'  md5  : {src_md5}')
    print(f'destino: {DST}')
    print(f'  md5  : {hashlib.md5(rom).hexdigest()}')
    print(f'  bytes: {len(rom)}')
    print()
    for off, b, why in WRITES:
        print(f'  {off:#08x}  {b.hex():8}  {why}')
    print(f'  {0x18e:#08x}  {calc:04x}      checksum de cartucho')


if __name__ == '__main__':
    main()
