"""placa.py - rotulo dorado de la pantalla de seleccion de escuela.

Reproduce la placa 「学校セレクト」 con texto castellano, conservando la
paleta y el estilo de relieve del original.

Paleta medida (indices de la paleta 1, colores reales del framebuffer):

  idx 3  #202000  contorno negro / sombra dura
  idx 9  #414400  sombra media (bisel inferior-derecho)
  idx 7  #626520  FONDO de la placa
  idx 2  #8b8900  dorado medio
  idx 4  #8b8920  dorado medio (variante del marco)
  idx 6  #cdce00  dorado claro
  idx 8  #eeee00  dorado brillante
  idx 14 #eeeeee  blanco (chispazos de las esquinas)

Criterio de relieve pedido por el usuario:
  - fuente gruesa
  - sombra en diagonal hacia abajo-derecha
  - tres tonos de brillo: base arriba/izquierda, mas claro cerca de las
    esquinas superiores izquierdas, y casi blanco en los picos superiores
    izquierdos
  - un tono algo mas oscuro que el base para recovecos y lados opuestos
    a la luz
"""

C_NEGRO = 0x3
C_SOMBRA = 0x9
C_FONDO = 0x7
C_MEDIO = 0x2
C_CLARO = 0x6
C_BRILLO = 0x8
C_BLANCO = 0xE

# Fuente de CAJA ALTA, 21 px de alto y trazo de 4 px.
# El kanji original mide 29 px de alto con trazo de 3-4 px; una fuente de
# 7 px como la del rotulo de la sala del club se veia diminuta dentro de la
# placa. Esta escala llena el interior (32 px) como el original.
GL = {
'A': ["..██████..",
      ".████████.",
      "███····███",
      "███····███",
      "███····███",
      "███····███",
      "██████████",
      "██████████",
      "███····███",
      "███····███",
      "███····███",
      "███····███",
      "███····███",
      "..........",
      ".........."],
'C': ["..██████..",
      ".████████.",
      "███····███",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███....███",
      ".████████.",
      "..██████..",
      "..........",
      "..........",
      ".........."],
'E': ["██████████",
      "██████████",
      "███.......",
      "███.......",
      "███.......",
      "███████...",
      "███████...",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "██████████",
      "██████████",
      "..........",
      ".........."],
'G': ["..██████..",
      ".████████.",
      "███····███",
      "███.......",
      "███.......",
      "███..█████",
      "███..█████",
      "███....███",
      "███....███",
      ".████████.",
      "..██████..",
      "..........",
      "..........",
      "..........",
      ".........."],
# La I va SIN serifas: con ellas y solo 1-2 px de separacion se fundia
# visualmente con la L contigua y 'ELIGE' se leia 'EIIGE'.
'I': ["..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..███.....",
      "..........",
      ".........."],
'L': ["███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "███.......",
      "██████████",
      "██████████",
      "..........",
      ".........."],
'S': ["..██████..",
      ".████████.",
      "███····███",
      "███.......",
      "███.......",
      ".████████.",
      "..██████..",
      ".......███",
      ".......███",
      "███....███",
      ".████████.",
      "..██████..",
      "..........",
      "..........",
      ".........."],
'U': ["███....███",
      "███....███",
      "███....███",
      "███....███",
      "███....███",
      "███....███",
      "███....███",
      "███....███",
      "███....███",
      "███....███",
      ".████████.",
      "..██████..",
      "..........",
      "..........",
      ".........."],
' ': [".........."] * 15,
}

SEP = 1      # aire entre letras
SPACE = 6    # ancho del espacio entre palabras


def render(texto):
    """Bitmap de 7 filas con el texto compuesto ('#' = trazo)."""
    rows = [""] * 15
    for i, ch in enumerate(texto):
        if ch == ' ':
            for r in range(15):
                rows[r] += '.' * SPACE
            continue
        g = GL[ch]
        cols = len(g[0])
        lo = min((c for c in range(cols) for r in range(15) if g[r][c] == "\u2588"),
                 default=0)
        hi = max((c for c in range(cols) for r in range(15) if g[r][c] == "\u2588"),
                 default=cols - 1)
        for r in range(15):
            rows[r] += g[r][lo:hi + 1].replace('█', '#')
        if i != len(texto) - 1:
            for r in range(15):
                rows[r] += '.' * SEP
    return rows


def emboss(rows, w, h, x0, y0):
    """Devuelve una matriz h x w de indices de color con el texto en relieve.

    x0, y0 = posicion del bitmap dentro de la placa.
    """
    W = len(rows[0])
    H = len(rows)

    def ink(x, y):
        return 0 <= y < H and 0 <= x < W and rows[y][x] == '#'

    px = [[C_FONDO] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            tx, ty = x - x0, y - y0
            if ink(tx, ty):
                # borde superior o izquierdo -> mas claro
                arriba = not ink(tx, ty - 1)
                izq = not ink(tx - 1, ty)
                if arriba and izq:
                    px[y][x] = C_BLANCO        # pico superior izquierdo
                elif arriba or izq:
                    px[y][x] = C_BRILLO        # canto iluminado
                else:
                    abajo = not ink(tx, ty + 1)
                    der = not ink(tx + 1, ty)
                    px[y][x] = C_MEDIO if (abajo or der) else C_CLARO
            else:
                # sombra proyectada en diagonal abajo-derecha
                if ink(tx - 1, ty - 1):
                    px[y][x] = C_NEGRO
                elif ink(tx - 2, ty - 2):
                    px[y][x] = C_SOMBRA
    return px


def frame(px, w, h):
    """Dibuja el marco cincelado de la placa sobre la matriz."""
    for x in range(w):
        px[0][x] = C_SOMBRA
        px[1][x] = C_BRILLO if x % 2 == 0 else C_CLARO
        px[h - 2][x] = C_MEDIO if x % 2 == 0 else C_SOMBRA
        px[h - 1][x] = C_NEGRO
    for y in range(h):
        px[y][0] = C_SOMBRA
        px[y][1] = C_BRILLO if y % 2 == 0 else C_CLARO
        px[y][w - 2] = C_MEDIO if y % 2 == 0 else C_SOMBRA
        px[y][w - 1] = C_NEGRO
    # linea interior oscura que separa marco de fondo
    for x in range(2, w - 2):
        px[2][x] = C_NEGRO
        px[h - 3][x] = C_NEGRO
    for y in range(2, h - 2):
        px[y][2] = C_NEGRO
        px[y][w - 3] = C_NEGRO
    return px


def build(texto='ELIGE ESCUELA', w=160, h=48):
    """Compone la placa reutilizando el MARCO ORIGINAL del juego.

    El marco no son lineas rectas: es un patron moteado de 6 px de grosor,
    imposible de reproducir a mano de forma convincente. Se toma tal cual de
    `work/placa_orig.json` (volcado de la VRAM japonesa) y solo se sustituye
    el interior, que es fondo liso mas el texto.

    Interior util medido: x 12..147, y 8..39 (el marco ocupa 12 px a cada
    lado en horizontal y 8 arriba / 8 abajo).
    """
    import json
    import os
    ref = os.path.join(os.path.dirname(__file__), '..', 'work',
                       'placa_orig.json')
    px = [row[:] for row in json.load(open(ref))]

    # limpiar el interior (dejar solo fondo)
    X0, X1, Y0, Y1 = 12, 148, 8, 40
    for y in range(Y0, Y1):
        for x in range(X0, X1):
            px[y][x] = C_FONDO

    rows = render(texto)
    tw, th = len(rows[0]), len(rows)
    if tw > X1 - X0:
        raise ValueError(f'texto de {tw} px > {X1 - X0} px de interior')
    x0 = X0 + (X1 - X0 - tw) // 2
    y0 = Y0 + (Y1 - Y0 - th) // 2

    W, H = tw, th

    def ink(x, y):
        return 0 <= y < H and 0 <= x < W and rows[y][x] == '#'

    for y in range(Y0, Y1):
        for x in range(X0, X1):
            tx, ty = x - x0, y - y0
            if ink(tx, ty):
                arriba = not ink(tx, ty - 1)
                izq = not ink(tx - 1, ty)
                if arriba and izq:
                    px[y][x] = C_BLANCO
                elif arriba or izq:
                    px[y][x] = C_BRILLO
                else:
                    abajo = not ink(tx, ty + 1)
                    der = not ink(tx + 1, ty)
                    px[y][x] = C_MEDIO if (abajo or der) else C_CLARO
            elif ink(tx - 1, ty - 1):
                px[y][x] = C_NEGRO
            elif ink(tx - 2, ty - 2):
                px[y][x] = C_SOMBRA
    return px


def to_tiles(px, w, h):
    """Corta la matriz en tiles de 8x8 y devuelve sus 32 bytes."""
    out = []
    for ty in range(h // 8):
        for tx in range(w // 8):
            data = bytearray()
            for y in range(8):
                for xb in range(4):
                    a = px[ty * 8 + y][tx * 8 + xb * 2]
                    b = px[ty * 8 + y][tx * 8 + xb * 2 + 1]
                    data.append((a << 4) | b)
            out.append(bytes(data))
    return out


if __name__ == '__main__':
    import sys
    txt = sys.argv[1] if len(sys.argv) > 1 else 'ELIGE ESCUELA'
    px = build(txt)
    CH = '0123456789ABCDEF'
    for row in px:
        print(''.join(CH[c] for c in row))
