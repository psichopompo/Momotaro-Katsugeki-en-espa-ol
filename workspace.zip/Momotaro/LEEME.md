# Momotarou Katsugeki — traducción al castellano

Dirige: **David** (Psicopompo, elotrolado.net)
ROM base: `Momotarou Katsugeki (Japan).pce`, 512 KB, MD5 `ec7358edb3672a8aa8850623eec72a71`
Repo: https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol

---

## 1. Estado actual

**ROM buena: `roms/momotaro_es_v272.pce`**

| ROM | MD5 | qué |
|---|---|---|
| `roms/momotaro_es_v272.pce` | `3043e0bdeffaae160e295b95c9400e4e` | **LA BUENA**: Artes / No puedo / ¡Puaj! |
| `roms/momotaro_es_v271.pce` | `68345b4235958b93ab26fde746d11d2f` | menú RUN real (banco `$0C`) + repunte |
| `roms/momotaro_es_v270.pce` | `bcf5cdb328f91c3cf30bdc1b91be70a7` | el `$01` duplicado del «Nada» |
| `roms/momotaro_es_v269.pce` | `0687a09590aaca90804e976ad23f57a7` | menú RUN del banco `$21` |
| `roms/momotaro_es_v268.pce` | `8a7cee42002affaec24b5c564170b6a8` | **password del Jizo en página limpia** |
| `roms/momotaro_es_v264.pce` | `695965973173f0a960eb3c0095f8cef0` | la `p` de «Capa» |
| `roms/momotaro_es_v263.pce` | `202f73d747a931e1d4faec4265783c3b` | del otro chat |
| `roms/Momotarou Katsugeki (Japan).pce` | `ec7358edb3672a8aa8850623eec72a71` | virgen, **INTOCABLE** |

Parche: `parches/momotaro_v272.ips`, contra la virgen, round-trip verificado.

### Qué se cerró en la última tanda

- **v268 — el password del Jizo**: 3 líneas, página propia, empezando arriba.
  Rutina de borrado en `$CABD` + continuación en `$DE69`. El cuelgue de la
  v267 era un `BCS` que tenía que ser `BPL` (norma 214).
- **v269 — menú RUN, banco `$21`**: No vale / Comer / Usar / Tirar /
  Sin nadie / Perro / Faisán / Mono. Se descubrió que **sí hay tablas de
  punteros** (la norma 207 era falsa, la corrige la 215).
- **v270 — el «Nada»**: `$01` duplicado en `0x42ED9` y `0x42F45`.
- **v271 — menú RUN de verdad, banco `$0C`**: las etiquetas que se ven en
  pantalla estaban aquí, no en el `$21`. Incluye `ﾀﾍﾞﾗﾚﾏｾﾝ`, que llevaba
  toda la sesión dada por «sin localizar».
- **v272 — ajuste al ancho**: el bocadillo son **8 celdas** (norma 237).

### Pendiente

1. **`Faltan momos` mide 12 caracteres** y el marco son 8. Sin medir si usa
   otro bocadillo. **Preguntar a David antes que nada.**
2. El **«Nada» de las aldeas** sigue mal: probablemente lee de otro sitio.
3. Las **tiendas**: saturación de sprites (16/scanline), proyecto aparte.

## 2. Cómo retomar el proyecto

```bash
python3 Momotaro/tools/build_v145.py     # reconstruye la v145 desde la v144
```

Los constructores usan rutas absolutas: funcionan desde cualquier directorio.
Cada uno lleva `assert` que verifican el MD5 de entrada, el byte esperado y
que la zona destino esté libre. **Si un assert salta, no se escribe la ROM.**

Aviso: `build_v140..v144` esperan como entrada la ROM de la versión anterior,
y en la limpieza se conservaron solo v109, v144 y v145. Para rehacer la
cadena completa hay que aplicar los IPS de `parches/` sobre la virgen. La
v144 ya está construida y validada, así que en la práctica solo se parte de
ella.

---

## 3. Método obligatorio — `docs/PROMPT_METODO.md`

- Diario `investigation.md`, 121 entradas. Las hipótesis falsas **no se
  borran**: se marcan `[DESCARTADO]` con el motivo.
- Una medición → una causa → un arreglo → una verificación.
- Prohibido escribir bytes a ciegas.
- Numerar cada versión con MD5/SHA-1/CRC32. No sobrescribir.
- Desensamblar todo salto escrito a mano antes de meterlo en la ROM.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- Capturas individuales, no rejillas.

---

## 4. Menú SELECT — analizado a fondo, sin parchear

Documentación completa en **`docs/menu_SELECT.md`** y **`docs/nombres_menu.md`**.

Resumen de lo medido:

```
BAT en $0000 (el menú RUN usa $0800), 64x32, BXR=BYR=0
patrones $100-$15F  gráficos: marco, recuadros y rótulos japoneses
patrones $200-$2FF  fuente, patrón = $200 + código de carácter
```

- **CG comprimido** en `0x7F8F2..0x7FE85` (1427 B → 96 tiles). Descompresor
  `$C1CC`/`$C206` transcrito en `tools/descomp_cg.py`, **96/96 tiles
  idénticos** y round-trip exacto. Quedan 379 B libres hasta `0x80000`.
- **BAT comprimida** en `0x1E7EA..0x1E9E8` (510 B → 22 filas × 32 celdas),
  RLE `FF cnt val`. En `tools/rle_bat.py`, round-trip exacto.
- **El original ya distingue dos fuentes**: rótulos y cifras en la gruesa
  (`$230-$25F`), contenido en la fina (`$2A0-$2DF`). Lo detectó David.
- **Minúsculas finas con acentos**: disponibles de serie en el CG.
- **Mayúsculas finas**: existen en la fuente de diálogo (`$70-$89`) pero no
  se suben al CG; se pueden inyectar en `$260-$279` (la fuente 1, que el
  menú carga y no usa).

### OBSTÁCULO MEDIDO que falta resolver

La BAT solo guarda el **byte bajo** del patrón, y el byte alto es siempre
`$01`. Es decir, la BAT comprimida solo puede expresar patrones `$100-$1FF`.
**Los rótulos NO se pueden escribir como texto tocando solo la BAT**: los
patrones de fuente son `$2xx`. Hay dos salidas:

1. **Redibujar los rótulos en el CG** (`0x7F8F2`), como se hizo con los del
   mapa y las aldeas. David edita el gráfico, yo monto los tiles.
2. Añadir código que escriba esas celdas en tiempo de ejecución, al estilo
   de `$D5EE`, que ya lo hace para las cifras.

La opción 1 es la coherente con lo ya hecho.

### Traducción aprobada por David

```
rótulos (gruesa):  VIDA · TÉCNICA · ORO · ARMA · ARMADURA · OBJETOS · ARTES
contenido (fina, con capitular fina):  minúsculas
```

Los nombres completos, con su cuenta de caracteres y el ancho útil de cada
panel, están en `docs/nombres_menu.md`.

Pendiente: la capitular del contenido debe ir en **fina**, no en gruesa
(en `capturas/select_B_minusculas.png` sale gruesa: hay que inyectar las
mayúsculas finas en `$260-$279`).

---

## 5. Lo que queda del proyecto

1. **Rótulos del menú SELECT** en el CG (ver el obstáculo de §4).
2. **Menú RUN**: es un bocadillo de sprites, texto pregrabado en el CG.
   36 sprites, texto en los patrones `$0380` y `$03A0`.
3. **Las tiendas** (`0x48470`): artefactos y HUD corrupto al salir.
   [HIPÓTESIS no verificada]
4. **ゲロゲロモード**: contenido en `0x1F4AE`, falta la estructura
   (listas `0x1A59C`/`0x1A59F`, limitador `CPY #$03` en `0x1A4F2`).
   Los passwords de 1up-games permiten llegar y verificarlo.
5. **Bocadillos verticales → horizontales** (la pieza grande).
6. Grueso del guion: objetos (`0x48CF0`), ermitaño y quiz (`0x4AE25`),
   piedra-papel-tijera (`0x4B8E2`).

---

## 6. Estructura

```
Momotaro/
├── LEEME.md               este archivo
├── investigation.md       diario, 121 entradas
├── roms/                  4 ROMs (virgen, v109, v144, v145)
├── parches/               IPS de v109, v144, v145
├── tools/
│   ├── build_v109..v145.py    constructores con assert
│   ├── dis6280.py             desensamblador HuC6280
│   │                          uso: rom off_hex n_DECIMAL carga_hex
│   ├── descomp_cg.py          CG comprimido (validado)
│   ├── rle_bat.py             BAT comprimida (validado)
│   ├── render_bg.py           renderiza el fondo desde un volcado de VRAM
│   ├── sim_select.py          simulador del menú SELECT
│   ├── render_rotulos.py      rótulos de mapa y aldea
│   ├── charset_oficial.py     CHAR_TO_CODE validado
│   └── fuente_menu.py         formato de la fuente gruesa + sombra
├── docs/
│   ├── PROMPT_METODO.md       el método, de obligada lectura
│   ├── menu_SELECT.md         anatomía completa del menú
│   ├── nombres_menu.md        inventario y espacio disponible
│   ├── Hilo_Momotaro_v3.txt   hilo del foro
│   └── *.state, *_vram.bin    volcados de referencia
└── capturas/
```

`Nekketsu/` es el proyecto anterior, terminado y sin tocar.

---

## 7. Normas ganadas fallando (las de esta sesión)

```
73. Antes de afirmar que un state "no tiene" algo, renderizar el FONDO, no
    solo los sprites.
74. Un rótulo que no está alineado a la rejilla contamina la fila de arriba:
    al borrarlo hay que contar TRES filas, no dos.
75. Un glifo vacío no es un glifo libre: puede ser el destino de un remapeo
    o el espacio.
76. Al inyectar un glifo en un CG ajeno, copiar la estructura de planos de
    un glifo VECINO que ya funcione, no solo el mapa de bits.
77. La BAT comprimida solo expresa el byte BAJO del patrón: comprobar el
    rango alcanzable ANTES de diseñar una solución basada en ella.
88. Una zona de RAM a cero en un state puede ser LA PILA. Antes de darla por
    libre, mirar hasta dónde ha bajado el puntero de pila en los states más
    cargados. ($20CE-$21D3 lo parecía y no lo era.)
89. Un hueco de RAM no se declara libre con UN state: hay que cruzar VARIOS,
    y que alguno use la zona colindante para probar que la frontera es real.
90. Antes de mover un búfer, CONTAR sus punteros en toda la ROM filtrando
    por banco. El del guion tenía 9 en 3 bancos, no los 2 que supuse.
91. Un marco de sprites puede ser MODULAR: antes de dar por hecho que hay
    que redibujarlo, volcar pieza a pieza y mirar si los bordes ya son
    rectos y repetibles. (La norma 87 no aplicaba al bocadillo.)
92. Antes de dibujar un grafico nuevo, BUSCARLO en los demas states del
    propio juego. La misma celda de VRAM puede tener contenido distinto
    segun la escena (el rabillo simetrico ya estaba en la celda 1AD).
93. Un glifo no es lo que dice la tabla que es: hay que VOLCAR SU BITMAP.
    El $CF que yo daba por «puntos suspensivos» eran DOS PUNTOS.
94. Al medir margenes de texto, descontar el aire que el propio glifo trae
    dentro de su celda; un margen simetrico en codigo se ve descentrado.
95. Una zona de RAM a cero en N states NO esta libre: los states son
    instantes, y si son de situaciones parecidas no prueban nada. $36F1
    parecia libre en 7 states y lo escribe una tienda. Solo vale un
    breakpoint de escritura jugando de verdad.
96. Un puntero puede no estar en la ROM: si se construye con inmediatos
    (LDA #lo / STA $zp), ningun barrido de words lo encontrara jamas.
97. Toda direccion de VRAM que se le pase al director se RECALCULA y se
    verifica decodificando el dato en el volcado. Un sprite de 16x16 son
    64 WORDS, no 8 bytes. (Le hice vigilar $0D68 en vez de $6B40.)
98. Antes de pedir un breakpoint, intentar sacar el dato de la ROM con las
    herramientas ya escritas. El rabillo simetrico estaba en 0x5292 y el
    descompresor lo encontro en 3 segundos.
99. Cuando dos calculos describen la misma cosa desde angulos distintos
     (la tabla de destinos y el reparto en sprites), DERIVAR uno del otro.
     Calculados por separado no casaron y 4 de 10 columnas eran invisibles.
100. El motor de texto escribe el GLIFO, no el FONDO. Antes de usar una
     celda de VRAM nueva como destino, inicializarla con el fondo del
     bocadillo (planos 0-2 = $FFFF). Si no, salen los restos de VRAM.
101. Cambiar donde se ESCRIBE el texto no cambia donde se DIBUJA el marco:
     son dos cosas distintas (tablas del banco $20 vs lista de sprites
     $9AA0). Tocar una sin la otra no produce ningun cambio visible.
102. El formato de una estructura NO se deduce leyendo el codigo que la
     consume: se CONTRASTA contra el resultado real (el SATB). Deduje
     [3]=dY,[4]=dX de $E43C/$E470 y era al reves; cuatro versiones
     perdidas por no cruzarlo con un state que ya tenia.
103. Toda rutina propia que escriba en VRAM debe llamar antes a $E185: no
     solo espera al VDC, tambien fija el AUTO-INCREMENTO (bits 3-4 del CR).
     Sin eso se escribe salteado y se machaca el fondo entero.
104. Antes de reemplazar una rutina COMPARTIDA, contar sus llamantes y de
     que banco entra cada uno. Si uno corre en otro contexto (carga de
     fase), se parchean los LLAMANTES, no la rutina.
105. Leer $0000 (status del VDC) BORRA los flags de interrupcion. Hacerlo
     mientras otro codigo espera el vblank lo cuelga para siempre.
106. Al sustituir una instruccion de 1 byte por un JSR de 3, comprobar que
     los 2 bytes extra no pisan lo que viene detras.
107. NO SE PARCHEAN PARCHES. Ante varios intentos fallidos seguidos, volver
     al ultimo estado correcto y avanzar de UNO EN UNO. Se acordo en
     Nekketsu y lo recordo David tras cinco entregas fallidas.
108. El motor escribe el glifo en el PLANO 3 de la celda (+48 words), no al
     principio. Un destino con resto 0 pinta bloques de color, no letras.
109. El bocadillo SOLO puede usar celdas que el CG cargue con fondo blanco:
     1A6-1AB. Cualquier otra da cuadros, aunque el destino sea correcto.
110. dX y dY de la lista de sprites son de 8 bits CON SIGNO ($E45B extiende
     el signo). Un bocadillo ancho hay que centrarlo en el ancla.
111. Las celdas del bocadillo NO son intercambiables: 1A0/1A2/1A4 son el
     lateral izquierdo, 1A1/1A3/1A5 el derecho (traen el trazo dibujado) y
     solo 1A6-1AB son relleno puro. Poner un lateral en medio mete el
     borde dentro del bocadillo.
112. Un sprite de 32 px de ancho REDONDEA su celda a par: el VDC ignora el
     bit 0 del patron. Para usar una celda impar, el sprite debe ser de 16.
113. El rabillo NO va en la lista fija de sprites: lo emite $9A78 en una
     segunda llamada, eligiendo una de las 4 variantes de $9ADD segun
     $368F (una de ellas es lateral, para el bocadillo del abuelo).
```

Las normas 12-72 están en `investigation.md`.

114. La FLECHA de continuar NO es un sprite: es un glifo de 8x8 que el motor
     escribe en el PLANO 3 de una celda del marco, con el destino puesto con
     inmediatos ($99C6: LDA #$B0 / LDA #$67 -> word $67B0 = celda 19E).
     Mover la lista de sprites NO la mueve. Se cambia en ROM 0x419E8.
115. Mesen direcciona la VRAM en BYTES y el VDC en WORDS: toda direccion
     leida del Memory Viewer se DIVIDE ENTRE 2 antes de compararla.
116. Dos rutinas que empiecen con el mismo LDA no son la misma cosa: antes de
     agruparlas, mirar el BITMAP que dibujan y QUIEN conmuta su variable.
     ($9A0E no es la flecha: es el cursor si/no de las tiendas.)

117. [CORREGIDA 2 VECES, ZANJADA] $5C conmuta $3666 y en el ORIGINAL
     alterna katakana ESTRECHO / ANCHO (la fuente virgen tiene los dos
     juegos: $34-$63 son katakana ancho). El juego lo usa en PARES 178
     veces para destacar sustantivos (オニ x29). En NUESTRA rama la tabla
     $9C73 y la fuente estan reescritas, asi que $5C solo desvia cuatro
     letras (j->A l->B n->C z->D en negrita) y CORROMPE el texto.
     NO EMITIR $5C NUNCA. La negrita se consigue escribiendo en MAYUSCULAS
     ($70-$89 son A-Z negrita), sin codigo de control.
118. Hay DOS motores de texto: $9807 (avance de pagina, lee ($92) crudo) y
     $9952 (APERTURA del bocadillo, lee por $9B0B). NO son intercambiables:
     usan lectores distintos. Todo cambio de geometria hay que hacerlo en
     los DOS. El clon entra por JMP $9952 desde ROM 0x168D8.
119. Antes de proponer "redirigir el salto y borrar el duplicado", comparar
     los PROLOGOS: $9952 activa $3690 y $3666 (JSR $9C69 / $9C5F) que $9807
     no toca. Dos rutinas que acaban igual pueden empezar distinto.

120. Un glifo no se identifica por deduccion cultural ("son cuatro y el
     juego es japones, luego son sutegana"): se VUELCA EL BITMAP. Eran
     mayusculas en negrita.
121. Un codigo de control que aparece un numero PAR de veces por bloque
     probablemente sea un DELIMITADOR (abre/cierra), no un interruptor de
     un solo sentido. Contar las apariciones y mirar que encierran.

122. Para razonar sobre lo que hace el motor ORIGINAL hay que usar las
     tablas ORIGINALES. Nuestra $9C73 tiene 124 de 256 bytes cambiados y la
     fuente 133 glifos: cualquier conclusion sacada sobre la ROM parcheada
     no describe el original. El arbitro es SIEMPRE la ROM virgen.

123. "Celda con datos" NO es "celda en uso". El 83% de la VRAM del juego es
     CG cargado que nadie dibuja. Para saber si una celda esta libre hay que
     mirar si la REFERENCIA el SATB (con su tamano real: ancho 32 -> &~1,
     alto 32 -> &~2, alto 64 -> &~6) o una entrada de la BAT (patron P ocupa
     los words P*16..P*16+15). Con el criterio bueno hay 62 celdas libres,
     no 2.
124. Patrones de BG y CG de sprites COMPARTEN la VRAM a partir de $1000.
     Pasar el texto de sprites a fondo NO ahorra memoria: 19 celdas de
     16x16 (64 w) y 76 patrones de 8x8 (16 w) son los mismos 1216 words.
125. $861F (ROM 0x4061F) descomprime UNA celda de 16x16 por llamada y
     autoincrementa el destino $3126/$3127 en $40. Para cargar mas CG basta
     otro bucle con otro destino: no se toca ni la rutina ni el formato.

126. Un contador de bucle NO se cambia por simetria: se SIMULA el bucle con
     los valores nuevos y se comprueba que el indice no se sale del buffer.
     El clon $9952 arrancaba en LDX #$06 con saltos de 12 (layout de 12
     columnas, mitad derecha, del bocadillo vertical japones); poner COLS en
     los tres inmediatos hacia que X llegase a 47 y machacase $368B.
127. Antes de saltar a una ROM de la otra rama, comparar zona a zona contra
     el ancestro comun y comprobar que los cambios propios siguen siendo
     aplicables (hueco libre, zona muerta intacta, enganche sin tocar).

128. NORMA 101 CON ASSERT: todo constructor que toque la tabla $9BBD debe
     cruzarla con la lista de sprites y abortar si alguna celda donde el
     motor escribe no la dibuja ningun sprite. Cai dos veces en lo mismo
     (v158 y v184).
129. La BASE del patron de sprite NO esta fija en $E3EB: la pone el llamante
     en $55/$56 ($9A7B: LDA #$38/#$03 = $0338 = celda 0x19C). b[0] es de 8
     bits SIN signo, asi que desde esa base solo se alcanzan 256 celdas
     hacia ARRIBA. Para usar celdas por debajo hay que bajar la base Y
     corregir todos los b[0], incluidos los de la tabla del rabillo $9ADD.

130. Antes de dar una ROM con geometria nueva, COMPONER EL MOCKUP con las
     piezas reales del CG. Los numeros decian que la v186 estaba bien y el
     mockup enseno dos huecos de fondo (5 px a la izquierda, 11 a la
     derecha) y que dos columnas quedaban tapadas por el lateral.
131. Una fila del bocadillo se valida CUBRIENDO EL INTERVALO: se ordenan los
     tramos blancos de cada sprite y se comprueba que no hay ni un pixel
     descubierto entre el trazo izquierdo y el derecho. Mirar solo "donde
     empieza y acaba el relleno" no basta.
132. Al componer un mockup, usar el CG DESCOMPRIMIDO DE LA ROM, no las
     celdas del savestate: en el state el plano 3 trae el texto que hubiera
     en pantalla y aparecen glifos fantasma.

133. Una rutina que se llama EN MEDIO de otra puede dejar el MPR cambiado.
     $9B7C mapea el banco 0x1E en MPR2 para leer el CG; el motor de texto
     necesita ahi el banco $24 (el guion). Al fin de pagina daba igual
     porque salia de la rutina, pero un volcado INTERMEDIO obliga a
     restaurar el mapeo antes de seguir leyendo.
134. La pagina cero de este juego esta COMPLETA: no queda un solo byte de
     $00-$FF sin referenciar. Si hace falta un dato temporal, hay que
     deducirlo de una variable que ya exista ($3657 dice por que mitad de
     pagina vamos) en vez de buscar sitio donde no lo hay.

135. La norma 126 (simular el bucle) hay que aplicarla a TODOS los motores,
     no al que se acaba de mirar. En la v184 la aplique al clon $9952 y me
     salte el motor principal $9807, que desbordaba el buffer 28 bytes y
     machacaba las COORDENADAS del bocadillo ($368B-$3690).
136. Un buffer de media pagina exige LIMPIARLO entre mitades: si la linea 3
     es mas corta que la 1, los restos de la primera mitad se pintan en la
     segunda. El limpiador $9C29 ya existe y borra solo $3667..$368A.

137. Una racha de ceros NO es un hueco libre. $9A4D (8 ceros) es el BITMAP
     DE BORRADO de la flecha y esta referenciado desde $9A49 como puntero
     de datos. Antes de usar un hueco hay que buscar su direccion como
     DATO (punteros), no solo como destino de JSR/JMP.
138. Antes de escribir una rutina nueva, mirar si ya existe una que haga el
     trabajo. La limpieza de la VRAM por pagina se resolvio con UN byte
     ($97EE: JSR $9C29 -> JSR $9C32) despues de haber escrito dos veces un
     parche de 18 bytes con dos bugs.

139. La X del bocadillo ($368B/$368C) es coordenada de MUNDO, no de
     pantalla: x_pantalla = $368B - scroll + dX, y el scroll vive en
     $35/$36. Sin restarlo, ninguna cuenta cuadra.
140. Un JSR solo alcanza el banco mapeado en esa ventana de memoria. Una
     rutina auxiliar para codigo del banco 0x0B tiene que vivir en el banco
     0x0B, aunque haya huecos de sobra en otros.
141. Un hueco de $FF con referencias DESDE OTRO BANCO suele ser seguro (ahi
     $9Exx es otra cosa), pero hay que comprobar si alguna referencia viene
     del MISMO banco. En el 0x0B hay dos (JSR $9FB4 y $9FCA) que saltan a
     relleno: probablemente codigo muerto, pero no se apoya un parche en una
     probabilidad.

142. El rabillo COMPARTE EL ANCLA con el cuerpo del bocadillo. Si se mueve
     el ancla para desplazar el bocadillo, el rabillo se mueve con el: al
     calcular su ajuste hay que descontar lo que ya aporta el ancla.
143. El flip H de un sprite NO viene de la lista de $7C02: lo decide $E445
     (EOR #$08 sobre el byte ALTO del atributo) segun el bit 6 de $52. Los
     42 sprites del bocadillo llevan b1 = $0F sin excepcion.

144. El VDC dibuja 16 SPRITES POR SCANLINE y uno de 32 px cuenta DOS. Si
     desaparecen trozos de personajes, contar las ranuras que gasta el
     bocadillo en cada fila. Subir o bajar el bocadillo NO lo arregla: solo
     mueve el recorte.
145. Antes de tapar un hueco con un sprite mas, mirar si se puede tapar
     RELLENANDO EL CG de una pieza que ya esta en pantalla. Un sprite
     cuesta una ranura por scanline; rellenar el CG no cuesta nada.
146. La cuenta de celdas del CG (0x3D400) NO es relleno: la lee $9C4E con
     LDX $5400. Al mover el stream hay que mover la cuenta y repuntar ese
     LDX, ademas de los inmediatos del puntero en $9C32.

147. Un sprite gasta una ranura de scanline en TODAS sus 16 filas, dibuje o
     no. Si la parte util esta arriba, las filas vacias de abajo roban
     ranuras a los personajes: hay que poner el dibujo al FONDO de la celda
     y subir el sprite lo mismo.
148. Las entradas del diccionario del guion pueden contener a su vez codigos
     $60-$8F (un nivel de anidamiento). Un lector que los copie crudos
     produce caracteres fantasma.
149. En un compresor voraz, la MARCA de "ya sustituido" no puede aparecer en
     las candidatas de la vuelta siguiente. Sin ese filtro entran entradas
     que no son texto y el guion ocupa 550 B mas.
150. Cuidado con `dic.get(k, None) or defecto` en Python: devuelve el defecto
     tambien cuando el valor es falsy. El caracter '0' lo es.

151. Si una metrica da EXACTAMENTE igual con dos algoritmos distintos,
     sospechar de la metrica antes que del algoritmo. El hueco total de una
     maquetacion no cambia al repartir distinto: lo que cambia es DONDE
     esta. Hay que medir lo que de verdad molesta.
152. El interlineado del bocadillo es de 8 px FIJOS: el motor escribe cada
     glifo en un cuadrante de 8x8 elegido por $3665. No se puede separar
     mas sin rehacer el direccionamiento.
153. Un inmediato que quedo a #$00 tras una conversion (SBC #$00, ADC #$00)
     es codigo muerto reciclable: son 5 bytes por cada uno, y en el clon
     $9952 dieron los 16 que hacian falta.

154. El indice de la fila de celdas se calcula sobre la linea RECIEN
     TERMINADA, y un dialogo puede acabar a media pagina. La formula tiene
     que valer tanto para el volcado intermedio como para el final:
     ($3657-1)&2, no $3657&2. Probarla con 1..12 lineas antes de escribirla.
155. Si una pieza del marco lleva BLANCO en todo su ancho, su posicion en la
     lista de sprites importa: indice bajo = encima. Los laterales tienen
     que ir DESPUES del relleno o taparan la primera y la ultima columna
     del texto.

156. Cuando un fallo sobrevive a varios arreglos, dejar de mirar el sintoma
     general y buscar el CASO EXTREMO que lo aisla. "Una pagina de una sola
     linea sale en la tercera" apunta al mecanismo; "faltan lineas" no.
157. Una rutina de recarga NO debe volcar el buffer si depende de una
     variable que el llamante aun no ha puesto al dia. El cargador $9AAE
     volcaba usando el $3657 de la pagina ANTERIOR, y eso dejaba media
     pantalla con el texto viejo.

158. El contador de linea $3657 solo sube al procesar un $3B, y la ULTIMA
     linea de un dialogo no lleva $3B detras. Por eso el fin de dialogo
     llega con un valor distinto que los otros dos volcados: hay que
     igualarlo con un INC antes de volcar, no inventar formulas.
159. Si dos situaciones distintas llegan al mismo punto con el MISMO valor
     de una variable pero necesitan resultados CONTRARIOS, el problema no
     tiene solucion con esa variable: hay que cambiar lo que llega, no la
     formula. (Tres versiones perdidas por no verlo.)

160. Antes de tocar el texto, COMPARARLO UNO A UNO con el REPASO que aprobo
     David. De los 87, ocho no coincidian y los ocho eran fallos de la
     insercion (palabras partidas con guion, espacios antes de los puntos
     suspensivos), no del texto aprobado.
161. Al quitar puntos suspensivos hay que distinguir el VOCATIVO: "Momotaro,
     las esperanzas" y no "Momotaro. Las esperanzas".
162. La ventana $E000-$FFFF es SIEMPRE el banco $00 (MPR7=$00, medido en los
     MPR de los 6 states). Un JSR a $FFxx llega desde CUALQUIER banco. El
     hueco $FF6B-$FFDF (117 B) desbloqueo el recorte, parado 9 versiones por
     dar por hecho que la rutina tenia que vivir en el banco $0B.
163. Corolario de la 137: $3691 PARECIA libre y no lo esta ($67C8 lo usa como
     contador). Y $3692 se indexa con ,Y hasta $3699. Contar referencias a la
     direccion NO basta: hay que mirar si alguien la indexa.
164. Un tramo a $FF en la ROM VIRGEN no puede ser destino de ningun salto: el
     juego original se colgaria. Es mas concluyente que escanear JSR, que da
     36 falsos positivos entre CG y tablas.
165. Si hay que mover una cosa y dejar otra quieta, buscar el punto del
     codigo ENTRE las dos: el bocadillo se emite en dos llamadas a $E3EB
     (rabillo y cuerpo) y recortar en medio sale gratis, sin RAM.
166. Un sprite gasta ranura aunque su franja este en blanco: al simular el
     limite de 16, contar solo las filas que DIBUJAN algo o salen falsos
     positivos (14 mutilados frente a los 8 reales).
167. "No referenciado en los states que tengo" NO significa "libre". En la
     v185 di por libres las celdas de VRAM 170-17F y el juego las usa para
     el proyectil y el jefe final: de ahi los cuadros verdes. Es la version
     en VRAM del error de $3691 (norma 163). Auditar con TODOS los volcados
     y con SAT **y** BAT: tools/audita_vram.py.
168. Escribir un operando en la direccion del OPCODE destroza la
     instruccion (puse $5F encima del E9 de SBC y salio "BBR5 $48"). Las
     constantes del constructor apuntan al OPERANDO: opcode+1. Y despues de
     escribir, un assert que compruebe que el opcode sigue ahi.
169. La celda de sprite maxima es la 1FB: el SATB ocupa el word $7F00, que
     es la celda 1FC.
170. El puntero del CG del bocadillo SE MUEVE en cada reconstruccion. No se
     escribe a mano en el constructor: se LEE del codigo de $9C32 (el
     puntero en $9C3C, la cuenta en $9C4E) y se recalcula el offset de ROM.
171. comprime() de descomp_cg.py espera los tiles CONCATENADOS (bytes
     multiplo de 32). Si se le pasa una lista devuelve 0 bytes EN SILENCIO.
172. Mover el dibujo dentro de una celda cambia lo que ocupa comprimido: al
     subir 9 filas, los ceros quedan abajo y el stream crecio 12 B. Si no
     cabe, mirar si hay relleno DELANTE y repuntar el cargador.
173. La norma 147 (dibujo al fondo de la celda) evita que el solape se VEA,
     pero NO ahorra ranuras. Si dos filas de sprites se solapan, en esas
     scanlines se suman las dos. Era la causa del nordo mutilado.
174. La BAT OCUPA VRAM, no solo referencia patrones. Con MWR=$0050 son 64x64
     words = $0000-$0FFF = las celdas de sprite 000-03F. Al auditar hay que
     restar el espacio que ocupa, no solo los patrones a los que apunta.
     (Dije que eran 64 celdas libres y son el mapa de fondo entero.)
175. El buffer de texto necesita 16 celdas CONTIGUAS: el cargador de blancas
     hace LDX #$10 con autoincremento del puntero de VRAM.
176. Un sprite de 32 px de ancho debe apuntar a celda PAR: el VDC ignora el
     bit 0 del patron. Al reubicar celdas, assert de paridad.
177. El marco del bocadillo carga 20 celdas y solo usa 10 (1A2-1AB es el
     relleno muerto desde la v193). Repaquetarlo libera 10 celdas de VRAM.
178. Hay DOS ramas del proyecto. La v225 deriva de mi v201, NO de mi v202:
     la mudanza de VRAM de la v202 se quedo en una rama muerta y el bloque
     verde se resolvio por otro camino en la v208. Base de patron buena:
     $170. Antes de parchear, comparar MD5 de la base, no el numero.
179. Los textos del abuelo (obtencion de item, dinero de minijuegos) estan
     en la tabla $C969 -> ROM 0x16969, 23 punteros. Su terminador es $A0,
     NO $00. Con $00 salen truncados.
180. En el bocadillo lo caro es el ALTO, no el ancho: cada fila de 16 px
     gasta sus ranuras en su franja. Bajar de 3 a 2 lineas saca el bocadillo
     de la franja congestionada; estrechar solo ahorra 1-2 ranuras.
181. El VDC no rota sprites, solo hace flip H y V. Para girar 90 grados hay
     que rotar los pixeles y reescribir la celda en el CG.
182. El hueco detras de una lista empieza DESPUES del terminador $FF, no
     encima. Escribir en la direccion del $FF deja la lista sin cerrar y el
     motor sigue leyendo lo que venga como registros de sprite.
183. $E3EB hace CLY y usa Y como indice propio ($E417). Cualquier valor de Y
     calculado ANTES de llamarla se pierde. Si hace falta despues, hay que
     recalcularlo.
184. Geometria del bocadillo: los laterales van 8 px por fuera del texto, no
     16. ancho = 8 + ncel*16 + 8. Con 8 celdas son 144 px; con 7, 128.
185. Cuando David dice "revirtamos y hagamoslo bien" tiene razon: arreglar
     un parche roto encima de otro parche roto (norma 107) cuesta mas que
     volver a la base buena y rehacerlo.
186. El marco del bocadillo esta DIBUJADO dentro de las celdas de texto, no
     es un sprite aparte: 1C4-1CB llevan el borde superior, 1D4-1DB el
     inferior, 1CC-1D3 ninguno. Al elegir celdas para una fila hay que coger
     las de la franja correcta o el marco sale abierto.
187. La tabla $9BBD solo vuelca texto a 1C4-1D3 (16 celdas = 2 filas). Las
     1D4-1DB son SOLO borde inferior: el bocadillo es 2 filas de texto + 1
     de marco, aunque parezcan 3 filas de texto.
188. El texto ocupa MEDIA celda, no la celda entera. $9C05 fija el
     cuadrante: linea 1 en la mitad inferior de 1C4-1CB, linea 2 en la
     mitad superior de 1CC-1D3. Por eso el bocadillo tiene 3 filas de
     sprites y solo 2 de texto: la tercera es medio blanco, medio borde.
189. Para mover una linea de texto 8 celdas basta sumar 2 al byte ALTO del
     destino (8 celdas * 64 words = $200). No hace falta duplicar la tabla.
190. El CG del bocadillo se carga POR ESCENA ($9C32 -> $52C2), no por
     apertura; el texto se escribe POR APERTURA y no se limpia. De ahi el
     texto residual que sobrevive en VRAM con el bocadillo ya cerrado.
191. RELEER LA NORMA 163 ANTES DE USAR RAM. Contar referencias directas a
     una direccion NO basta: hay que buscar accesos INDEXADOS ($3692,Y
     cubre $3692-$3699). Me salte mi propia norma y colgue el juego.
192. Antes de inventar una variable en RAM, mirar si el dato YA esta en
     algun sitio: $368F tiene la variante durante todo el dibujado.
193. CPX y CPY ENSUCIAN EL CARRY. Si detras hay un ADC, hace falta CLC
     aunque el codigo original no lo llevara.
194. ANTES de inyectar codigo en una rutina, listar que registros estan
     VIVOS en el llamante. $9FE0 la invoca el bucle de $9B7C, que usa X
     como CONTADOR: cualquier LDX ahi es un bucle infinito.
195. PLX y PLA restauran el registro pero MACHACAN N y Z. No se puede
     comparar, restaurar y luego ramificar: hay que ramificar primero y
     restaurar en cada rama.
196. Dos bugs distintos pueden dar el MISMO sintoma. Si un arreglo "logico"
     no cambia nada, el diagnostico estaba incompleto: volver a medir en
     vez de seguir parcheando.
197. El bloque de textos del abuelo ($C969) usa $A0 como salto de linea, no
     $3B. Cada bloque tiene tantas lineas como columnas tenia el bocadillo
     vertical japones, y rellena el final con $A0.
198. Si una verificacion da un resultado raro, sospechar PRIMERO del
     verificador. Un releido mal escrito me hizo creer que los textos se
     desbordaban cuando los bytes estaban perfectos.
199. LOS MPR DEL STATE, SIEMPRE. Antes de convertir una direccion logica en
     offset de ROM hay que leer los MPR del savestate: MPR2 puede ser $26 y
     no $24. Un banco mal supuesto da un texto que no existe y una teoria
     entera equivocada.
200. $3654=0 NO significa "bocadillo cerrado". Si el SAT tiene los sprites
     del bocadillo, esta abierto. Comprobar el SAT antes que una variable
     cuyo significado se supone.
201. Antes de declarar "ninguna tabla lo explica", RELEER LOS INFORMES
     ANTERIORES. La sustitucion $AB34 que resolvia el atasco de la 'p'
     llevaba documentada desde el informe v202-v225.
202. La tabla de $AB34 son DOS ARRAYS PARALELOS de 7 bytes (origen en
     0x42B4C, destino en 0x42B54), no pares intercalados. Volcarla "en
     pares" da ruido y lleva a descartarla.
203. La cadena real de decodificacion del menu tiene TRES pasos:
     sustitucion $AB34 -> eleccion de ruta $CB1B -> tabla de glifos.
     Un modelo con solo el ultimo paso predice mal.
204. El codigo de la 'p' en el menu es $5E (no $B0 ni $70). Los alias
     b=$5B c=$5D p=$5E valen para TODA la ruta baja, no solo para el canto.
205. El glifo $00 NO esta en blanco: pinta un cuadrado. Un $20 al final de
     una cadena da glifo $00 -> cuadrado negro. Los nombres no llevan
     relleno con espacios.
206. El bocadillo tiene 4 filas de texto pero el buffer solo 2 (32 celdas).
     La mitad que se pinta la elige calc_alto ($9FE0) con $3657: 1 o 2 son
     las filas A (1-2), y 3/4/0 las filas B (3-4). Para borrar la pagina
     ENTERA hay que volcar el buffer vacio DOS veces, con $3657=1 y $3657=3.
207. Los verbos del menu RUN ($B1B4, $B736) NO tienen tabla de punteros:
     esas words son las cadenas. Ninguna traduccion en infinitivo cabe en su
     hueco (faltan de 1 a 3 letras). Mover el bloque exige repuntar.
208. Para dejar una variable con un valor concreto al salir de un bucle,
     mirar si el propio bucle ya la escribe: invertir el orden de las
     iteraciones sale mas barato que un LDA/STA al final (3 bytes menos).
209. Banco $0B: 407 bytes libres en $DE69 y 44 en $DE34, a $FF tambien en
     la ROM virgen. Es el hueco grande mas cercano al codigo del bocadillo.
210. Si David dice "mejor, pero aun no", el cambio anterior es BUENO: son
     defectos de maquetacion, no un fallo. Conservarlo y ajustar encima de
     uno en uno, nunca encadenar un segundo cambio sin probar el primero.
211. Reentrar en un bucle por debajo de su comprobacion de fin es peligroso:
     $CA78 no comprueba $365D contra 32, esa comprobacion esta en $CA9F.
     Al reentrar hay que hacerlo por el punto que valida la condicion.
212. Un `assert` que compara el codigo contra MI simulador no verifica nada
     si el simulador esta mal. El de la v267 modelaba `BCS` con signo y dio
     el visto bueno a un bucle infinito. Los flags se simulan con las reglas
     del 6502, no con intuicion: `BCS`/`BCC` son SIN SIGNO (`$FF` = 255),
     `BPL`/`BMI` miran el bit 7 del resultado.
213. Sintoma de bucle infinito en el 6280: pantalla congelada pero **musica
     normal**. Las interrupciones siguen corriendo. Si el juego crashease de
     verdad, el sonido tambien se iria. Ese detalle localiza el fallo en un
     bucle de usuario, no en un salto a basura.
214. Para dejar una variable en 1 al salir de un bucle descendente de 2 en 2
     partiendo de 3, el salto correcto es `CMP #$01 / BPL`, no `BCS`.
215. [CORRIGE LA 207] El menu RUN SI tiene tablas de punteros: $B1AC
     (objetos) y $B1CC (aliados), 4 entradas cada una, ya en la ROM virgen.
     La 207 era falsa. Se puede reubicar y repuntar libremente.
216. Como se demuestra que unas words son una tabla de punteros y no las
     cadenas mismas: (1) una entrada REPETIDA, (2) los destinos teselan las
     cadenas sin huecos ni solapes, (3) identica en la ROM virgen, (4) el
     script las invoca como [cmd][word]. Buscar `LDA tabla,X` NO sirve: el
     interprete recibe el puntero como operando del guion.
217. ANTES de usar un hueco, comprobar EN QUE BANCO cae y si ese banco esta
     mapeado cuando corre el codigo que lo usa. Hueco de codigo y hueco de
     datos son presupuestos distintos y NO se suman. ($DE69 sirve para el
     password porque comparte banco $0B con $CA73; NO sirve para cadenas
     del banco $21.)
218. Una tabla de punteros puede vivir DENTRO del bloque de cadenas que
     gobierna. Antes de declarar un rango libre, restar las tablas que
     caigan dentro. Assert obligatorio: ninguna zona escribible puede
     solapar una tabla.
219. Sumar bytes libres NO demuestra que quepa: con huecos fragmentados y
     cadenas indivisibles hay que resolver el empaquetado. Best-fit se
     encajona con ajustes exactos; usar backtracking exhaustivo.
220. Antes de declarar unos punteros «corruptos», probar a leerlos contra
     TODAS las ventanas MPR, no solo la del banco donde estan escritos.
     Los de 0x4379D parecian basura y son punteros validos al banco $1E.
221. La norma 205 (el $20 final da cuadrado negro) aplica al espacio FINAL
     de una cadena en el menu SELECT, NO al espacio interior en el bocadillo:
     ahi `$20 -> $3C -> ruta baja -> glifo $00` y ese glifo son 8 bytes a
     cero. «No vale» y «Sin nadie» renderizan con el hueco limpio.
222. Los artefactos de las tiendas NO son problema de texto ni de datos:
     son saturacion de sprites (16/scanline, el limite del VDC). Medido en
     el volcado de VRAM: 56 sprites activos, pico de 16 en las lineas 80-87,
     y las celdas de patron con el CG correctamente cargado.
223. El japones se ve como signos raros porque la FUENTE (0x3D660) tiene
     133 glifos pisados: las minusculas y tildes latinas se escribieron
     encima del katakana ($A1-$DF). Las CADENAS estan intactas; lo que
     falta son los dibujos. Restaurar la fuente no puede romper datos.
224. [ANULADA por la 228] Se probo una ROM `v269jp` con la fuente de la
     virgen restaurada para leer el japones. NO FUNCIONO (salen lineas
     horizontales) y se ha borrado junto con su constructor. Si algun dia
     hace falta leer el japones, hay que localizar antes la fuente real.
225. dougu = `ﾄﾞｳｸﾞ ﾎｼｲ` en 0x436F9 ($B6F9), tabla en 0x436EB.
     jutsu = `ｼﾞｭﾂ ﾎｼｲ` en 0x4360C ($B60C), tabla en 0x435FE.
     taberaremasen = `ﾂｶｴﾏｾﾝ` en 0x4372E ($B72E), tabla $B712.
226. En las tablas de dougu/jutsu/bougu/menselect **solo la entrada [0] es
     un puntero real**. Las words siguientes son codigo o datos. Listarlas
     como tabla de 8 entradas produce cadenas solapadas y sin sentido.
227. El menu de FUERA de la aldea usa cadenas distintas de las de dentro:
     «Nada» esta traducido en 0x42EDA y 0x42F46. No es una inconsistencia
     del juego, son dos juegos de cadenas separados.
228. [CORRIGE LA 223] 0x3D660 NO es la fuente japonesa. Restaurarla desde la
     virgen no devuelve el katakana: salen lineas horizontales. Que 133
     glifos DIFIERAN de la virgen no demuestra que el original fuese el
     silabario. El japones se dibuja desde otro sitio, sin localizar.
229. Al traducir una cadena hay que mirar si el `$01` inicial YA esta
     puesto. Escribir la secuencia completa `01 texto 00` dentro de una
     cadena que ya empieza por `$01` deja `[01][01]` = doble salto de linea.
     Se ve bien en bocadillos de 2 filas y descuadra los de 4.
230. Sintoma enganoso: «signos raros» en pantalla no siempre es japones sin
     traducir. Puede ser castellano con un byte de control de mas. Antes de
     buscar la cadena japonesa, comparar el offset con la ROM virgen.
231. dougu -> «Objetos» (0x436F9), jutsu -> «Poderes» (0x4360C),
     tsukaemasen -> «Inútil» (0x4372E). Las tres caben en su hueco original;
     no hizo falta repuntar.
232. [AGUJERO DE METODO, 3 VECES] Antes de dar una direccion CPU a partir de
     un offset ROM, VERIFICAR la ventana MPR con una referencia ya conocida
     del mismo banco. El banco $0C se mapea en $C000 (como el $0B: 0x16A73 =
     $CA73), NO en $8000. Un breakpoint mal calculado no salta y parece que
     el codigo no se ejecuta; una busqueda de punteros con la ventana mal da
     «ninguna» y parece que no hay tabla. Ambas conclusiones son falsas.
233. El menu RUN vive en el banco $0C (ROM 0x18000-0x1A000 -> $C000-$DFFF):
     tabla 0x197F2 (dougu/jutsu/password/debug) y tabla 0x19A61
     (taberaremasen/tsukaemasen). Lo del banco $21 con `ﾎｼｲ` al final es
     dialogo, no menu.
234. No todos los punteros son tablas: el banco $0C carga tres direcciones
     con `LDA #lo / STA $BF / LDA #hi / STA $C0`. Para repuntar se tocan los
     operandos inmediatos. Buscar solo words contiguas no los encuentra.
235. Una cadena puede servir a varios punteros: «No se puede» cubre las dos
     copias de ﾂｶｴﾏｾﾝ y el ﾃﾞｷﾏｾﾝ. Antes de duplicar texto, comprobar si
     varios punteros pueden compartir destino.
236. Que una cadena japonesa «encaje con el nombre» que da David NO
     demuestra que sea la que se ve en pantalla. Confirmar siguiendo el
     codigo o con un breakpoint, nunca por parecido del texto.
237. El bocadillo pequeno del menu (banco $0C) tiene 8 CELDAS de ancho. El
     bucle de dibujo ($D619) NO corta: escribe hasta el $00 y lo que sobra
     se pinta fuera del marco. `$C3` es el cursor y nunca se compara con
     nada. Limite fisico, no de codigo: toda etiqueta de ese menu <= 8.
238. Textos finales del menu RUN (v272): Objetos / Artes / ¡Puaj! /
     No puedo. «Artes» por coherencia con el menu SELECT, que ya lo usa.
     Password y debug se quedan en japones (no salen en juego).
239. Las interjecciones llevan signos de apertura y cierre aunque los
     nombres de objeto no lleven punto (decision de David). «¡Puaj!» son 6
     caracteres con los dos signos incluidos.
240. El «Perro» que sale al elegir Usar sobre el Dango NO es un error de la
     traduccion: en la ROM japonesa original tambien aparece `ｲﾇ` (inu). Es
     una rareza del juego, oculta tras una combinacion improbable.
241. Antes de dar por bug algo raro en pantalla, comparar con la ROM virgen
     jugando la misma situacion. David lo hizo con el «Perro» y ahorro una
     investigacion entera.
242. Varios mensajes del menu RUN solo se ven provocando situaciones
     absurdas (Comer algo incomible, Usar una comida, gastar una tecnica sin
     momos). No hay forma de verificarlos sin jugar: se validan poco a poco.
243. El hilo del foro es `docs/Hilo_Momotaro_v5.txt` (BBCode). La v3 se
     borro por obsoleta y la v4 la edito David online. Estilo: parrafos
     narrativos, NO frases sueltas; contar tambien los errores y las
     decisiones fortuitas. Al tocarlo, verificar el balance de etiquetas y
     que el indice coincida en orden con los titulos reales.
244. Antes de escribir cualquier cosa para el hilo del foro, LEER EL DIARIO
     COMPLETO, no solo las ultimas entradas. Son 15.000 lineas y 165
     entradas: lo que no esta fresco en la sesion actual sigue siendo parte
     del proyecto. David detecto que faltaba toda la etapa de la conversion
     a horizontal, que es la mas importante del proyecto.
245. Hitos que NO pueden faltar en el hilo: conversion vertical->horizontal
     (72 bytes de tabla), el limite de 16 sprites/scanline y los 5 pixeles
     mutilados, las tres versiones con la geometria 16x32 al reves, la
     flecha de continuar (glifo en plano 3, no sprite), el cursor SI/NO que
     casi se rompe, y las contrasenas latinas (64 kana = 64 latinos, con las
     originales aun validas).
246. `investigation.md` esta FUSIONADO: tronco comun hasta la linea 10.737,
     luego RAMA A (otro chat) y RAMA B (este chat, la que produce la v272).
     Las dos ramas tienen numeracion SOLAPADA: la entrada 162 de una no es
     la de la otra. Buscar siempre en las dos antes de dar algo por sabido.
247. [CORRIGE mi entrada 114] La flecha de continuar NO se arreglo moviendo
     un byte a la celda $1AE. Eso el otro chat lo DESCARTO: esas filas son
     basura grafica, no la flecha. Lo medido: `$9A5F` = flecha (triangulo
     abajo), `$9A56` = cursor SI/NO (triangulo derecha), y **ninguna lista
     de sprites incluye sus celdas**. Se escriben en VRAM y nada las muestra.
     No las rompimos nosotros: la rutina es identica desde la v216.
248. `$19E` y `$1A6` se llevan 8 celdas = el desplazamiento de doble buffer.
     Es la MISMA flecha en las dos paginas, no dos flechas distintas.
249. Los passwords SECRETOS no pasan por el codec: se comparan crudos contra
     la tabla `$CFC5`. Sirven como sonda: si uno funciona, la cadena
     parrilla -> $3C94 esta bien sin necesidad de breakpoints. Pero solo
     ejercitan 30 de las 64 celdas y NINGUN digito: no valen como prueba
     general de que la entrada este completa.
250. [CORRIGE mi diagnostico] Los artefactos de las TIENDAS no son
     saturacion de sprites. Medido en 19 volcados (rama A, entrada 212):
     las tiendas llegan a 11 de 16 por linea. El pico de 16 que medi es el
     limite, no un exceso. La causa real: los rangos de codigos solapan
     ($A1-$B4 = a..t nuestro, $B1-$C5 = katakana), y quedan 58 tramos y
     7.786 bytes de japones que se pintan con la fuente latina. Se arregla
     TRADUCIENDO, no repartiendo sprites.
251. El hilo del foro tiene un limite DURO de 100.000 caracteres. Estado
     actual: 99.823. Antes de anadir nada, medir y compensar recortando.
252. Los nombres del menu SELECT estuvieron 10 de 11 CRUZADOS por un
     repunte antiguo. Ya corregido. El juego los indexa con una tabla de
     punteros de DOS NIVELES (entrada -> sublista -> cadena), no por
     posicion fisica.
253. [CORRIGE la 251] El foro cuenta los saltos de linea como CRLF (2
     caracteres), no como LF (1). La metrica buena es
     `len(texto) + texto.count('\n')`, no `len(texto)`. Con 1.150 lineas eso
     son 1.150 caracteres invisibles. Dejar ademas ~1.000 de margen porque
     el editor anade algo al pegar. Estado actual: 99.029 de 100.000.
