# Momotarou Katsugeki — traducción al castellano

Dirige: **David** (Psicopompo, elotrolado.net)
ROM base: `Momotarou Katsugeki (Japan).pce`, 512 KB, MD5 `ec7358edb3672a8aa8850623eec72a71`
Repo: https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol

---

## 1. Estado actual

| ROM | MD5 | qué |
|---|---|---|
| `roms/test_terminador_v144.pce` | `4887028c2f7d33421af89b833075a173` | **oficial**, validada por David |
| `roms/test_menu_v145.pce` | `27d45972652f7c7789364f67488d307d` | **última**, arreglos de fuente |
| `roms/momotaro_es_v109.pce` | `e618d5a111a9ad4326efdf1973b04bab` | base estable antigua |
| `roms/Momotarou Katsugeki (Japan).pce` | `ec7358edb3672a8aa8850623eec72a71` | virgen |

### Qué trae la v145 (31 bytes, todos en la fuente MENÚ)

1. **La `T` movida 1 px a la izquierda.** Medido: su cuerpo empezaba en x=1
   mientras A B C D E… empiezan en x=0. Era un defecto del original.
   Lo detectó David viendo «TECNICA» desalineada respecto a «VIDA» y «ORO».
2. **`É` gruesa** dibujada en el glifo `$40`. Ese código está en la lista de
   control `$AAA3`, nunca se dibuja por la ruta de diálogo, aparece 0 veces
   en los bloques traducidos y 0 celdas del menú lo usan: glifo muerto.
3. **Sombra en la tilde de la `Ó`** (`$5B`), +3 px. Reportado por un usuario
   en «PULSA BOTÓN RUN». La sombra se genera con el algoritmo validado de
   `tools/fuente_menu.py`, no a mano.

**Pendiente de aplicar en el menú**: escribir los rótulos traducidos. Ver
§4, hay un obstáculo medido que lo condiciona.

---

## 2. Cómo retomar el proyecto

```bash
python3 Momotaro/tools/build_v145.py     # reconstruye la v145 desde la v144
```

Los constructores usan rutas absolutas: funcionan desde cualquier directorio.
Cada uno lleva `assert` que verifican el MD5 de entrada, el byte esperado y
que la zona destino esté libre. **Si un assert salta, no se escribe la ROM.**

Aviso: `build_v140..v144` esperan como entrada la ROM de la versión anterior,
y en la limpieza se conservaron solo v109, v144 y v145. Para rehacer la
cadena completa hay que aplicar los IPS de `parches/` sobre la virgen. La
v144 ya está construida y validada, así que en la práctica solo se parte de
ella.

---

## 3. Método obligatorio — `docs/PROMPT_METODO.md`

- Diario `investigation.md`, 121 entradas. Las hipótesis falsas **no se
  borran**: se marcan `[DESCARTADO]` con el motivo.
- Una medición → una causa → un arreglo → una verificación.
- Prohibido escribir bytes a ciegas.
- Numerar cada versión con MD5/SHA-1/CRC32. No sobrescribir.
- Desensamblar todo salto escrito a mano antes de meterlo en la ROM.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- Capturas individuales, no rejillas.

---

## 4. Menú SELECT — analizado a fondo, sin parchear

Documentación completa en **`docs/menu_SELECT.md`** y **`docs/nombres_menu.md`**.

Resumen de lo medido:

```
BAT en $0000 (el menú RUN usa $0800), 64x32, BXR=BYR=0
patrones $100-$15F  gráficos: marco, recuadros y rótulos japoneses
patrones $200-$2FF  fuente, patrón = $200 + código de carácter
```

- **CG comprimido** en `0x7F8F2..0x7FE85` (1427 B → 96 tiles). Descompresor
  `$C1CC`/`$C206` transcrito en `tools/descomp_cg.py`, **96/96 tiles
  idénticos** y round-trip exacto. Quedan 379 B libres hasta `0x80000`.
- **BAT comprimida** en `0x1E7EA..0x1E9E8` (510 B → 22 filas × 32 celdas),
  RLE `FF cnt val`. En `tools/rle_bat.py`, round-trip exacto.
- **El original ya distingue dos fuentes**: rótulos y cifras en la gruesa
  (`$230-$25F`), contenido en la fina (`$2A0-$2DF`). Lo detectó David.
- **Minúsculas finas con acentos**: disponibles de serie en el CG.
- **Mayúsculas finas**: existen en la fuente de diálogo (`$70-$89`) pero no
  se suben al CG; se pueden inyectar en `$260-$279` (la fuente 1, que el
  menú carga y no usa).

### OBSTÁCULO MEDIDO que falta resolver

La BAT solo guarda el **byte bajo** del patrón, y el byte alto es siempre
`$01`. Es decir, la BAT comprimida solo puede expresar patrones `$100-$1FF`.
**Los rótulos NO se pueden escribir como texto tocando solo la BAT**: los
patrones de fuente son `$2xx`. Hay dos salidas:

1. **Redibujar los rótulos en el CG** (`0x7F8F2`), como se hizo con los del
   mapa y las aldeas. David edita el gráfico, yo monto los tiles.
2. Añadir código que escriba esas celdas en tiempo de ejecución, al estilo
   de `$D5EE`, que ya lo hace para las cifras.

La opción 1 es la coherente con lo ya hecho.

### Traducción aprobada por David

```
rótulos (gruesa):  VIDA · TÉCNICA · ORO · ARMA · ARMADURA · OBJETOS · ARTES
contenido (fina, con capitular fina):  minúsculas
```

Los nombres completos, con su cuenta de caracteres y el ancho útil de cada
panel, están en `docs/nombres_menu.md`.

Pendiente: la capitular del contenido debe ir en **fina**, no en gruesa
(en `capturas/select_B_minusculas.png` sale gruesa: hay que inyectar las
mayúsculas finas en `$260-$279`).

---

## 5. Lo que queda del proyecto

1. **Rótulos del menú SELECT** en el CG (ver el obstáculo de §4).
2. **Menú RUN**: es un bocadillo de sprites, texto pregrabado en el CG.
   36 sprites, texto en los patrones `$0380` y `$03A0`.
3. **Las tiendas** (`0x48470`): artefactos y HUD corrupto al salir.
   [HIPÓTESIS no verificada]
4. **ゲロゲロモード**: contenido en `0x1F4AE`, falta la estructura
   (listas `0x1A59C`/`0x1A59F`, limitador `CPY #$03` en `0x1A4F2`).
   Los passwords de 1up-games permiten llegar y verificarlo.
5. **Bocadillos verticales → horizontales** (la pieza grande).
6. Grueso del guion: objetos (`0x48CF0`), ermitaño y quiz (`0x4AE25`),
   piedra-papel-tijera (`0x4B8E2`).

---

## 6. Estructura

```
Momotaro/
├── LEEME.md               este archivo
├── investigation.md       diario, 121 entradas
├── roms/                  4 ROMs (virgen, v109, v144, v145)
├── parches/               IPS de v109, v144, v145
├── tools/
│   ├── build_v109..v145.py    constructores con assert
│   ├── dis6280.py             desensamblador HuC6280
│   │                          uso: rom off_hex n_DECIMAL carga_hex
│   ├── descomp_cg.py          CG comprimido (validado)
│   ├── rle_bat.py             BAT comprimida (validado)
│   ├── render_bg.py           renderiza el fondo desde un volcado de VRAM
│   ├── sim_select.py          simulador del menú SELECT
│   ├── render_rotulos.py      rótulos de mapa y aldea
│   ├── charset_oficial.py     CHAR_TO_CODE validado
│   └── fuente_menu.py         formato de la fuente gruesa + sombra
├── docs/
│   ├── PROMPT_METODO.md       el método, de obligada lectura
│   ├── menu_SELECT.md         anatomía completa del menú
│   ├── nombres_menu.md        inventario y espacio disponible
│   ├── Hilo_Momotaro_v3.txt   hilo del foro
│   └── *.state, *_vram.bin    volcados de referencia
└── capturas/
```

`Nekketsu/` es el proyecto anterior, terminado y sin tocar.

---

## 7. Normas ganadas fallando (las de esta sesión)

```
73. Antes de afirmar que un state "no tiene" algo, renderizar el FONDO, no
    solo los sprites.
74. Un rótulo que no está alineado a la rejilla contamina la fila de arriba:
    al borrarlo hay que contar TRES filas, no dos.
75. Un glifo vacío no es un glifo libre: puede ser el destino de un remapeo
    o el espacio.
76. Al inyectar un glifo en un CG ajeno, copiar la estructura de planos de
    un glifo VECINO que ya funcione, no solo el mapa de bits.
77. La BAT comprimida solo expresa el byte BAJO del patrón: comprobar el
    rango alcanzable ANTES de diseñar una solución basada en ella.
88. Una zona de RAM a cero en un state puede ser LA PILA. Antes de darla por
    libre, mirar hasta dónde ha bajado el puntero de pila en los states más
    cargados. ($20CE-$21D3 lo parecía y no lo era.)
89. Un hueco de RAM no se declara libre con UN state: hay que cruzar VARIOS,
    y que alguno use la zona colindante para probar que la frontera es real.
90. Antes de mover un búfer, CONTAR sus punteros en toda la ROM filtrando
    por banco. El del guion tenía 9 en 3 bancos, no los 2 que supuse.
91. Un marco de sprites puede ser MODULAR: antes de dar por hecho que hay
    que redibujarlo, volcar pieza a pieza y mirar si los bordes ya son
    rectos y repetibles. (La norma 87 no aplicaba al bocadillo.)
92. Antes de dibujar un grafico nuevo, BUSCARLO en los demas states del
    propio juego. La misma celda de VRAM puede tener contenido distinto
    segun la escena (el rabillo simetrico ya estaba en la celda 1AD).
93. Un glifo no es lo que dice la tabla que es: hay que VOLCAR SU BITMAP.
    El $CF que yo daba por «puntos suspensivos» eran DOS PUNTOS.
94. Al medir margenes de texto, descontar el aire que el propio glifo trae
    dentro de su celda; un margen simetrico en codigo se ve descentrado.
95. Una zona de RAM a cero en N states NO esta libre: los states son
    instantes, y si son de situaciones parecidas no prueban nada. $36F1
    parecia libre en 7 states y lo escribe una tienda. Solo vale un
    breakpoint de escritura jugando de verdad.
96. Un puntero puede no estar en la ROM: si se construye con inmediatos
    (LDA #lo / STA $zp), ningun barrido de words lo encontrara jamas.
97. Toda direccion de VRAM que se le pase al director se RECALCULA y se
    verifica decodificando el dato en el volcado. Un sprite de 16x16 son
    64 WORDS, no 8 bytes. (Le hice vigilar $0D68 en vez de $6B40.)
98. Antes de pedir un breakpoint, intentar sacar el dato de la ROM con las
    herramientas ya escritas. El rabillo simetrico estaba en 0x5292 y el
    descompresor lo encontro en 3 segundos.
99. Cuando dos calculos describen la misma cosa desde angulos distintos
    (la tabla de destinos y el reparto en sprites), DERIVAR uno del otro.
    Calculados por separado no casaron y 4 de 10 columnas eran invisibles.
```

Las normas 12-72 están en `investigation.md`.
