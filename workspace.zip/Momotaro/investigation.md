# Momotarou Katsugeki — diario de traducción (sesión del charset de la intro)

> **Qué es este archivo.** Continuación del diario del proyecto, con el
> trabajo hecho sobre la **intro** (charset español y texto) y el análisis
> de la fuente del **menú**. Se mantiene aparte del diario que lleva la
> otra ventana de chat para que ninguna de las dos pise el trabajo de la
> otra: aquí sólo hay Momotarou, y las entradas empiezan en la (28)
> continuando la numeración existente.
>
> Método: una medición -> una causa -> un arreglo -> una verificación.
> Las hipótesis falsas **no se borran**: se marcan `[DESCARTADO]` con el
> motivo, porque saber por dónde no hay que ir vale tanto como lo otro.

---

## Estado en una pantalla

| ROM | MD5 | qué es |
|---|---|---|
| `test_intro_v72.pce` | `80fd205e…` | base de esta rama (**no es virgen**) |
| ~~`test_intro_v73.pce`~~ | ~~`89bbc3a3…`~~ | **DESCARTADA**, base de fuente equivocada |
| `test_intro_v74.pce` | `85aa1672…` | charset ES correcto |
| `test_menu_v75.pce` | `04aa02e1…` | v74 + menú sin tildes rotas (parche aparte) |
| `test_intro_v76.pce` | `24446014…` | **vigente**: v74 + texto y páginas revisados por David |

### Las DOS fuentes (no confundirlas jamás)

| | fuente DIÁLOGO (intro) | fuente MENÚ |
|---|---|---|
| banco (vía `TAM #$04`) | `$1E` | `$02` |
| base ROM | `0x3D660` | `0x4000` |
| stride | 8 B, 1 plano | 16 B, cuerpo + sombra |
| índice | `tabla[byte-0x30]`, tabla en `0x43F9B` | `(byte-0x30) & 0xFF` |

### Motor de texto de la intro (`$D175`, ROM `0x1B175`)

```
0x00 = fin de línea      0xFE = fin de página
0xFF = fin del texto     0xFD / 0xFC = otros controles
máximo 4 líneas por página (CMP #$04 en $D1A6)
número de páginas: SIN LÍMITE (no hay contador)
ancho: 24 caracteres
```

### Normas ganadas en esta sesión

12. **`capstone` en modo 65C02 NO sirve para el HuC6280.** Lee `TAM` (`$53`)
    como `nop` y descoloca lo que sigue. Decodificar a mano `TAM`, `TMA`,
    `ST0/1/2`, `TII/TIA/TIN`, `CSL/CSH`, `SAX/SAY/SXY`, `BSR`.
13. **Medir contra la pantalla, no contra la teoría.** Una captura a tamaño
    real es la única prueba de qué píxeles emite el VDC.
14. **Una corrección también hay que medirla.** Me autocorregí con una
    medición más floja que la original y di tres cifras distintas para la
    misma pregunta.
15. **Lo medido en una fuente no vale para la otra.** Tres veces extrapolé
    del diálogo al menú y las tres me equivoqué.

---
---

## (28) v73 DESCARTADA — base de la fuente equivocada. v74 la sustituye

**Fecha:** 2026-08-06. Reporte de David con captura de pantalla a tamaño real.

### Síntomas reportados
1. Los espacios se dibujan como `Ó`. (En un intento anterior salían como `Á`.)
2. El primer `¡` no sale; sale un katakana ("una L pequeña con un palo vertical").
3. La `Ó` no se ve: solo dos píxeles sueltos.
4. Tras "BIEN" salen tres símbolos raros parecidos a interrogaciones (ya en v72).

### Medición (no hipótesis)
La captura era de 256x240, o sea **tamaño real**: cada celda de 8x8 son los
píxeles exactos que emitió el VDC. Se recortaron las 21 celdas de la línea 1
y se buscó cada bitmap dentro de la ROM. Resultado: las 26 letras A-Z
aparecen **una sola vez cada una**, siempre en la misma rejilla:

```
ROM = 0x3D660 + glifo * 8      (8 bytes por glifo, 1 BIT por píxel)
  A glifo 0x70 -> 0x3D9E0 = 00 38 6c c6 c6 fe c6 c6
  H glifo 0x77 -> 0x3DA18      O glifo 0x7E -> 0x3DA50
  Z glifo 0x89 -> 0x3DAA8      0 glifo 0x8C -> 0x3DAC0
```

**Comprobación cruzada por desensamblado.** El diario tenía mal copiado
`$AAD4`: dice cuatro `ASL A`, y son **tres**.

```
AAD4: 64 15        stz $15
AAD6: 0a / 26 15   asl a / rol $15    (x3)   -> glifo * 8
AADF: 18 / 69 60   clc / adc #$60
AAE4: a5 15 / 69 56  lda $15 / adc #$56      -> $5660 + glifo*8
```

`$5660` cae en la ventana de banco `$4000-$5FFF`; con el banco `0x1E`
mapeado ahí, ROM = `0x3C000 + ($5660-$4000)` = **`0x3D660`**. Dos métodos
independientes (píxeles en pantalla y aritmética del desensamblado) dan la
misma dirección al byte.

### [DESCARTADO] "la fuente está en ROM 0x3A10, stride 16, 2bpp con plano de contorno"
Falso. Es lo que asumió la v73 y de ahí salen los cuatro síntomas. Por qué
colé: a stride 16 los dibujos "parecían plausibles" — en los 8 primeros
bytes aparecía la letra y en los 8 siguientes algo que parecía una sombra.
Era una coincidencia de encuadre. **No se comprobó nunca contra la
pantalla**, que es la única medición que vale. Norma 4 del proyecto
(no dar por supuesto el origen de un tile) aplicada al revés.

### Causa única de los síntomas 1-3
Los 9 dibujos de la v73 se escribieron en `0x40C0`, `0x43D0`, `0x4410`,
`0x4500`, `0x47C0`, `0x4800-0x4830`. Nada de eso es la fuente del diálogo.

- **Síntoma 1:** `0x40C0` está a cero en la v72 y es el **tile en blanco**
  que el motor usa para el espacio. La v73 le escribió encima la `Ó`
  (`0c 18 7c c6 c6 c6 7c 00`, exactamente el bitmap que se ve entre las
  palabras). En el intento previo el primer dibujo escrito ahí fue la `Á`:
  mismo fallo, distinta letra. Esto explica por qué el síntoma "cambió de
  letra" entre intentos sin que cambiara la causa.
- **Síntoma 3:** único cambio de tabla de la v73, byte `0x63` -> glifo
  `0x6B`. El glifo `0x6B` **real** está en `0x3D9B8` y vale
  `00 04 02 00 00 00 00 00`: dos píxeles. La v73 lo creyó vacío porque
  miró `0x40C0`, que no es el glifo `0x6B`.
- **Síntoma 2:** el byte `0x67` seguía apuntando al glifo `0xE1` =
  `0x3DD68`, katakana, jamás tocado.

### Síntoma 4: los "..." — bug independiente, heredado de la v72
El renderer `$AB1B` solo pasa por tabla los bytes `0x30-0x83`:
`SEC / SBC #$30 / CMP #$54 / BCS fallback`. `.` es `0x2E` y `,` es `0x2C`,
**menores que `0x30`**: el SBC da `0xFE`/`0xFC`, superan el `CMP #$54` y
caen al fallback `$F589`, que hace `puntero = $4000 + idx*16` y lee de un
banco que no es la fuente.

```
'.' idx 0xFE -> $4FE0 -> ROM 0x4FE0 = 00 00 f8 03 0c 0e 02 18
```

Ese bitmap es **exactamente** el símbolo raro de la captura tras "BIEN":
predicción y medición coinciden byte a byte. `,` (idx `0xFC`) y `!`
(idx `0xF1`) están igual de rotos por el mismo motivo.

> Nota: el `!` **parecía** correcto en pantalla por casualidad — el
> fallback caía sobre un trozo de gráfico que se asemeja a una barra
> vertical. No era correcto. En la v74 también se encamina por tabla.

### v74 — arreglo
Barrido de los 256 glifos: solo 9 están enteros a cero (`0x00`, `0xE8`,
`0xE9`, `0xEE`, `0xF3`, `0xF8`, `0xFB`, `0xFC`, `0xFD`). El `0x00` no vale
(en la tabla, 0 significa "vete al fallback"). Quedan **ocho**, y hacían
falta **ocho**. Al estar a cero, escribir ahí no puede borrar nada.

```
Á 0x60 -> glifo 0xE8 @0x3DDA0     Ú 0x64 -> glifo 0xF8 @0x3DE20
É 0x61 -> glifo 0xE9 @0x3DDA8     Ñ 0x65 -> glifo 0xFB @0x3DE38
Í 0x62 -> glifo 0xEE @0x3DDD0     ¿ 0x66 -> glifo 0xFC @0x3DE40
Ó 0x63 -> glifo 0xF3 @0x3DDF8     ¡ 0x67 -> glifo 0xFD @0x3DE48
```

`.` `,` y `!` no necesitan dibujo nuevo: ya existen en la fuente. Se les
dan códigos que **sí** entran por tabla, apuntados a los glifos que ya
están dibujados:

```
. 0x68 -> glifo 0x8A      , 0x69 -> glifo 0xCC      ! 0x6A -> glifo 0x9E
```

`¿` y `¡` se dibujaron girando 180° los glifos `?` (`0x9D`) y `!` (`0x9E`)
del propio juego, para que el trazo case con el resto de la fuente.

**Verificaciones que aborta el constructor si fallan:**
- prueba de control: 5 glifos conocidos (A, H, O, Z, 0) deben leerse en
  `0x3D660 + g*8` con su bitmap esperado — si no, la base es otra y para;
- los 8 huecos destino deben estar a cero antes de escribir;
- `0x4000-0x6000` debe quedar **intacto** (es lo que rompió la v73);
- `0x40C0` debe seguir a cero (el tile en blanco del espacio);
- A-Z y 0-9 intactos byte a byte;
- ningún byte del texto puede quedar en fallback ni apuntar a glifo 0;
- el `.ips` se reaplica sobre la v72 y debe dar la ROM idéntica.

**Entrega v74** (construida desde `test_intro_v72.pce`, **no** desde la v73):
```
test_intro_v74.pce
  MD5    85aa167228220f0f8113551baf45d968
  SHA-1  ec8d25f919769e6b33301883c106abe5d03fc4a8
  CRC32  1a0882b4
  630 bytes distintos de la v72
momotaro_intro_v74.ips   798 B, 32 tramos, reaplicado y verificado
```

Texto: 575 -> 585 B, 354 B libres detrás. Ninguna línea supera los 24
caracteres del original.

### Herramienta nueva: simula_v74.py
Renderiza el texto leyendo la ROM **con el mismo algoritmo del 65C02**
(`$AB1B` -> tabla -> `$AAD4` -> `0x3D660 + g*8`). Permite ver el resultado
antes de encender el emulador y cuenta cuántos caracteres caen en fallback
(en la v74: **cero**). Es la comprobación que le faltó a la v73.

---

## (29) [HECHO] Hay DOS fuentes distintas. El menú ya usa acentos, y están rotos

Al auditar si la v74 podía romper otros textos (Norma 9: la tabla `0x43F9B`
es **global**, no exclusiva de la intro) apareció un hallazgo independiente.

### Las dos fuentes

| | fuente DIÁLOGO | fuente FALLBACK |
|---|---|---|
| base | `0x3D660` | `0x4000` |
| stride | 8 B | 16 B |
| índice | `tabla[byte-0x30]` | `(byte-0x30) & 0xFF` directo |
| formato | 1bpp, 8 filas | 1bpp, letra en filas 0-6, fila 7 = 0 |
| la usa | intro | menús (dificultad, JIZO, CARGAR) |

Son dos juegos de dibujos **separados**: la `A` del diálogo está en
`0x3D9E0` y la `A` del menú en `0x4110`, con bitmaps distintos.

Esto explica del todo por qué la v73 se estrelló: escribió en `0x40C0`,
`0x43D0`, `0x4410`, `0x4500`, `0x47C0`, `0x4800-0x4830`, que **son la
fuente del menú**. Machacó glifos del menú creyendo que ampliaba la del
diálogo.

### [HECHO] El menú de dificultad ya intenta escribir acentos

Textos en `0x1FB10` y siguientes, con tabla de punteros en `0x1F4AE`
(5 entradas medidas):

```
[0] $5B10 -> 0x1FB10  "F<C2>CIL"
[1] $5B18 -> 0x1FB18  "NORMAL"
[2] $5B21 -> 0x1FB21  "DIF<C4>CIL"
[3] $5B2B -> 0x1FB2B  "MUY DIF<C4>CIL"
[4] $5B39 -> 0x1FB39  "CANTO DE JIZO"
```

O sea que **alguien (en una sesión previa del proyecto) ya metió `0xC2`
para `Á` y `0xC4` para `Í`** en los textos del menú.

### [HECHO] Esos dos códigos están rotos

`0xC2` y `0xC4` dan `idx = 0x92` y `0x94`, ambos `>= 0x54`, así que van al
fallback, que lee:

```
0xC2 -> ROM 0x4920 = 00 00 00 7c 78 86 44 83 ...
0xC4 -> ROM 0x4940 = 00 00 00 00 00 01 01 7a ...
```

Ninguno de los dos es una letra: son trozos de otro gráfico. En pantalla
"FÁCIL" y "MUY DIFÍCIL" salen con basura en el sitio del acento.
No es una hipótesis: los bitmaps están volcados arriba y no se parecen a
ninguna vocal.

> Esto encaja con el parpadeo de "CANTO DE JIZO" que David reporta como
> pendiente. Misma zona, misma tabla de punteros, mismos textos. **No lo
> afirmo como causa**: solo señalo que hay que mirar ahí.

### Espacio libre en la fuente del menú: prácticamente nulo

Barrido de los 256 slots de `0x4000`: **solo uno** está entero a cero
(idx `0x0C`, byte `0x3C`). Es decir que en la fuente del menú NO hay sitio
para 6 vocales acentuadas + Ñ. Arreglar el menú va a exigir reutilizar
slots ocupados y demostrar antes que nadie los usa — no se puede hacer al
vuelo, es una tarea propia.

### [HECHO] La v74 no interfiere con nada de esto

- Los códigos que reasigna (`0x60-0x6A`) **no aparecen en ningún texto**
  del juego fuera de la intro. Comprobado byte a byte en `0x1F400-0x20000`
  y `0x1E000-0x1E200`: las apariciones de `0x60`, `0x66`, `0x67`, `0x6A`
  en esas zonas están dentro de streams de coordenadas (`0e 01 20 00 04...`)
  y de punteros, no de texto.
- Los 8 glifos que reescribe (`0xE8`, `0xE9`, `0xEE`, `0xF3`, `0xF8`,
  `0xFB`, `0xFC`, `0xFD`) estaban **a cero** y solo los referenciaban los
  códigos `0x6E`, `0x6F`, `0x74`, `0x79`, `0x7E`, `0x81`, `0x82`, `0x83`,
  que son katakana y no se usan en ningún texto.
- Diferencia de regiones tocadas, medida:
  - **v73**: `0x40C0-0x4830` (fuente del MENÚ) + texto + 1 B de tabla.
  - **v74**: `0x3DDA0-0x3DE50` (fuente del DIÁLOGO) + texto + 11 B de tabla.
    **Cero bytes** en `0x4000-0x5000`.

### Tarea nueva pendiente
Arreglar `FÁCIL` / `MUY DIFÍCIL` en el menú. Requiere fuente propia
(`0x4000`, stride 16) y allí casi no hay hueco. No tocar hasta terminar
la intro.

---

## (30) [HECHO] Confirmación por TAM: los dos bancos, demostrados desde el código

La entrada (29) acertó las direcciones (`0x3D660` y `0x4000`) pero las
dedujo **a medias**: `0x3D660` salió de la aritmética y de la pantalla,
pero `0x4000` se dio por bueno sin justificar el banco. Eso era un cabo
suelto: `$F589` calcula un puntero de **CPU** (`$4000 + idx*16`), y una
dirección de CPU en la ventana `$4000-$5FFF` no dice por sí sola a qué
ROM corresponde — depende del banco mapeado en MPR2.

### El error de herramienta que lo tapaba

`capstone` en modo `65C02` **no conoce los opcodes propios del HuC6280**.
El byte `0x53` (`TAM`) lo desensambla como `nop`, y el operando siguiente
como una instrucción cualquiera. Por eso en los volcados anteriores
aparecía basura del tipo `53 / 04 60 tsb $60` justo donde estaba la
instrucción decisiva.

> **Norma nueva (13):** `capstone` en 65C02 no vale para el HuC6280.
> Los opcodes `TAM` (`$53`), `TMA` (`$43`), `ST0/ST1/ST2`, `TII/TIA/TIN`,
> `CSL/CSH`, `SAX/SAY/SXY`, `BSR` hay que decodificarlos a mano. Cuando
> aparezca un `nop` sospechoso en medio de código con sentido, mirar el
> byte crudo.

### La medición

Decodificando a mano las dos colas de `$AB1B`:

```
ruta TABLA     $AAEA: a9 1e   LDA #$1E
               $AAEC: 18      CLC
               $AAED: 65 20   ADC $20      ; $20 = banco base del juego
               $AAEF: 53 04   TAM #$04     ; bit2 -> MPR2 = ventana $4000
               $AAF1: 60      RTS

ruta FALLBACK  $AB2C: a9 02   LDA #$02
               $AB2E: 18      CLC
               $AB2F: 65 20   ADC $20
               $AB31: 53 04   TAM #$04
               $AB33: 60      RTS
```

Es decir que **cada ruta mapea explícitamente su propio banco** antes de
leer los datos del glifo:

| ruta | banco | ventana `$4000` | fuente |
|---|---|---|---|
| tabla | `$1E` | ROM `0x3C000` | diálogo: `$5660` -> ROM **`0x3D660`** |
| fallback | `$02` | ROM `0x04000` | menú: `$4000+idx*16` -> ROM **`0x4000+idx*16`** |

Las dos direcciones de la entrada (29) quedan **confirmadas desde el
código**, no solo desde la pantalla. Tres vías independientes coincidiendo:
píxeles de la captura, aritmética de `$AAD4`, y el `TAM` de cada ruta.

### Prueba de control de la fuente del menú

Se probaron los 64 bancos posibles para la ventana `$4000-$5FFF` leyendo
el slot de la `A` (idx `0x11`). Solo **uno** da una letra:

```
banco $02 -> ROM 0x4110 = 38 6c c6 c6 fe c6 c6 00   ->   ..###...
                                                          .##.##..
                                                          ##...##.
                                                          #######.
```

Verificado además con A D I F C L M U Y: las nueve coherentes. Ningún
otro banco produce letras. Coincide con el `LDA #$02` del `TAM`.

### [CORRECCIÓN a la entrada 29] la fuente del menú NO es 1bpp

Dije "1bpp, letra en filas 0-6, fila 7 = 0". Incompleto. El stride es 16
porque hay **dos planos de 8 bytes**, igual que sospechaba (y descarté)
para el diálogo:

```
glifo 'A' menú, ROM 0x4110 = 38 6c c6 c6 fe c6 c6 00 | 04 12 29 21 01 39 21 e7
   plano0 = la letra          plano1 = otra cosa (no es contorno)
```

El plano 1 no es una sombra: para la `A` da un patrón inconexo. Queda
como **[PENDIENTE]** qué significa (probable segundo bitplane de color
2bpp). **No tocarlo hasta medirlo**: la v73 ya se estrelló por suponer
formatos de fuente.

### [HECHO] Dónde acaba realmente la fuente del menú

Barrido de los slots `0x30-0x9F`: a partir del slot `0x40` (byte `0x70`)
los datos dejan de tener forma de letra y aparecen patrones tipo
`00ff00ff00ff00ff` y `ff00ff00ff00ff00`, típicos de gráficos/máscaras.
Los slots `0x92` y `0x94` (los que usan `FÁCIL` y `MUY DIFÍCIL`) caen en
esa zona: **no son glifos rotos, es que ahí ya no hay fuente**.

Hay además un bloque de slots a cero en `0x34-0x3F` (bytes `0x64-0x6F`),
o sea **12 slots libres consecutivos** en ROM `0x4340-0x43F0`, más el
`0x30` y el `0x34-0x3F`. Corrige lo dicho en (29) ("solo 1 slot libre"):
aquel barrido exigía los 16 bytes a cero y aquí lo que importa es el
plano 0. **Hay sitio de sobra para los acentos del menú.**

> Y explica el otro destrozo de la v73: escribió en `0x43D0`, `0x4410`,
> `0x4500`, `0x47C0`, `0x4800-0x4830`. El `0x43D0` caía justo en esos
> slots libres (inofensivo), pero `0x4410` en adelante son **gráficos**.

### Consecuencia práctica
Arreglar `FÁCIL` / `MUY DIFÍCIL` es más fácil de lo que dije en (29):
hay 12 slots libres contiguos. Pero antes hay que medir qué es el plano 1
y con qué códigos se indexan. Tarea propia, después de la intro.

---

## (31) [HECHO] El plano 2 de la fuente del menú es SOMBRA. Y rectifico lo de los "12 slots libres"

### Qué es el segundo plano (resuelto)

En (30) dejé como `[PENDIENTE]` qué eran los bytes 8..15 de cada glifo del
menú, y dije que "para la A da un patrón inconexo". Era pereza de
análisis: sí tiene regla, y es simple.

```
plano1 = dilatar(plano0, {(+1,0), (0,+1), (+1,+1)}) - plano0
```

O sea: **la sombra del cuerpo proyectada a derecha-abajo**, excluyendo el
propio cuerpo. Es el mismo criterio de sombreado que yo *supuse* (y
descarté) para la fuente del diálogo — resulta que existe, pero en la otra
fuente.

**Contraste sobre las 26 letras y los 10 dígitos: 33/36 exactos.** Las
tres excepciones (`A`, `3`, `5`) difieren en **un** píxel, siempre dentro
de un hueco cerrado del dibujo, donde el grafista borró la sombra a mano.
Ninguna difiere **por exceso**: el plano1 nunca tiene píxeles fuera de la
sombra calculada, lo cual descarta que sea un bitplane de color arbitrario.

Hipótesis descartadas por medición (no por intuición):

| hipótesis | aciertos |
|---|---|
| contorno de 8 vecinos | 0/26 |
| contorno de 4 vecinos | 0/26 |
| derecha+abajo sin diagonal | 0/26 |
| izquierda+arriba | 0/26 |
| **derecha+abajo+diagonal** | **25/26** |

Round-trip verificado: regenerando la `A` desde su propio cuerpo sale
idéntica salvo ese píxel cosmético.

Implementado en `momo/fuente_menu.py`, que **genera** la sombra en vez de
pedir que se dibuje a mano: así no puede quedar incoherente con el cuerpo.

### [CORRECCIÓN a la entrada 30] no hay 12 slots libres. Hay UNO.

En (30) escribí que había "12 slots libres consecutivos en `0x4340-0x43F0`"
y que en (29) me había pasado de pesimista. **Me equivoqué al corregirme.**

Aquellos 12 slots tienen el plano 0 (cuerpo) a cero, sí — pero el plano 1
contiene `ff ff c3 c3 c3 c3 ff ff`, que renderizado es:

```
########
########
##....##
##....##
##....##
##....##
########
########
```

Un **rectángulo hueco**, repetido en los 12. Y el slot `0x2E` tiene
`00 00 44 28 10 28 44 00`, que es una **×**. Son glifos de verdad
(probablemente marcos de recuadro y una equis de la interfaz), no huecos.

Mirar solo el plano 0 fue el error: en una fuente de dos planos, un
cuerpo vacío **no** significa slot libre.

**El recuento bueno es el de la entrada (29): un único slot con los 16
bytes a cero, el idx `0x0C` (byte `0x3C`).** Y ese byte `0x3C` aparece en
los propios textos del menú (`02 3c 4d 55 59...`), así que probablemente
ni siquiera esté libre: parece un código de control.

> Lección: me autocorregí en (30) con una medición más floja que la
> original. Una corrección también hay que medirla. Tres cifras distintas
> para la misma pregunta (1 → 12 → 1) es una señal de que estaba yendo
> deprisa.

### Consecuencia para la tarea del menú

Arreglar `FÁCIL` / `MUY DIFÍCIL` **no** tiene sitio libre donde caer. Las
opciones reales, por orden de menos a más invasiva:

1. Reutilizar slots de katakana de la fuente del menú, demostrando antes
   que ningún texto del juego los usa (el mismo método que funcionó en la
   v74 para el diálogo). Los textos del menú usan `A1 A4 A5 A7 A8 A9 AC AE
   AF B1..B6 BB C9 CB DC`, así que hay katakana en uso: hay que listarlos
   todos antes de tocar nada.
2. Prescindir de la tilde en el menú (`FACIL`, `MUY DIFICIL`). Feo pero
   inofensivo, y es lo que hay ahora mismo en la práctica salvo que ahora
   sale basura en vez de nada.

No se toca hasta terminar la intro y hasta tener el inventario completo de
códigos usados en TODOS los textos del menú.

---

## (32) [HECHO] Inventario del menú: la fuente acaba en el idx 0x2F. NO hay katakana reutilizable

Prerequisito que yo mismo puse en (31): antes de tocar la fuente del menú,
inventariar TODOS los códigos que usan sus textos. Hecho.

### Todos los streams de texto del menú

Estructura del formato: `<nn> 3C <texto...> 00`, donde `nn` es 01/02
(¿ancho o posición?). Barrido del banco `0x1E000-0x20000`:

```
0x1F214  <<SCROL<TEST<<          0x1FB10  F<C2>CIL
0x1F246  STAGE<<AREA<NO<         0x1FB18  NORMAL
0x1F26A  <<DATA<CLEAR<<<         0x1FB21  DIF<C4>CIL
0x1F4B8  (japonés)               0x1FB2B  MUY DIF<C4>CIL
0x1F4C4  (japonés)               0x1FB3A  CANTO DE JIZO
0x1F4D0  (japonés)               0x1FB4A  CARGAR
0x1F4DD  (japonés)               0x1FB53  (pregunta de carga)
0x1F4EF  (japonés)               0x1FC51  MUY DIF<C4>CIL  <- SEGUNDA COPIA
```

**Hallazgo:** hay una **segunda copia** de `MUY DIFÍCIL` en `0x1FC51` que
no estaba en el diario. Termina en `0x1FC5E`, es decir **un byte antes**
de donde arranca el texto de la intro (`0x1FC5F`). Margen cero.

> Comprobado que la v74 **no** lo toca: `0x1FC40-0x1FC5F` queda byte a byte
> igual. Pero queda anotado como zona de riesgo: cualquier futuro intento
> de mover el texto de la intro *hacia atrás* pisaría ese texto.

Norma 3 verificada también por delante: el texto de la intro creció 10 B
(`0x1FE9D` -> `0x1FEA7`) y lo que había detrás era **sólo relleno `0xFF`**.

### Los 50 códigos en uso

```
01 02 20 3C 3F 41 43 44 45 46 47 49 4A 4C 4D 4E 4F 52 54 55 59 5A 5C 5D 5F
A1 A5 A7 A9 AC B1 B2 B3 B5 B6 B9 BB BC BD BF C0 C2 C4 C9 CC D1 D3 DB DD DE
```

### [DESCARTADO] "reutilizar katakana de la fuente del menú"

Propuse esto en (31) como vía principal. **No sirve.** Filtrando los
katakana `0xA1-0xDF` no usados salían 36 candidatos aparentemente
reutilizables. Contrastados contra la regla de sombra medida en (31):

```
cuadran la regla:  0 de 36
control ('B'):     cuadra
```

**Cero.** Y al renderizarlos no son katakana: son tramas de rayas
(`########` / `........` alternas), máscaras y trozos de gráfico.

Barrido completo idx `0x00-0x5F` aplicando la regla como criterio
objetivo de "esto es un glifo de fuente":

- idx `0x00-0x2F` (bytes `0x30-0x5F`): cuadran casi todos -> **es fuente**
  (dígitos 0-9, signos, y A-Z en `0x11-0x2A`).
- idx `0x30` en adelante: **ninguno** cuadra -> ya no es fuente.

**La fuente del menú son 48 slots, del idx `0x00` al `0x2F`, y están todos
ocupados salvo el `0x0C`.** No hay katakana que reciclar, porque en esta
fuente no hay katakana: eso era de la fuente del *diálogo*, y lo extrapolé
sin comprobarlo.

> Tercer error del mismo tipo en esta sesión: dar por bueno para la fuente
> del menú algo medido en la del diálogo. Las dos fuentes no comparten
> **nada**: ni base, ni banco, ni stride, ni formato, ni repertorio.

### Estado real de la tarea del menú

Para meter `Á` y `Í` en el menú no hay hueco dentro de la fuente. Opciones
que quedan, todas con coste:

1. **Sacrificar glifos poco usados de la propia fuente** (los signos de
   idx `0x0A`, `0x0B`, `0x0D`, `0x2C`, `0x2D`, `0x2F`), demostrando antes
   que ningún texto los usa. Ninguno está en la lista de 50, así que es
   viable — pero hay que comprobar los textos de **todo el juego**, no
   sólo los del menú.
2. **Mover la fuente entera** a un hueco mayor y repuntar `$F589`
   (`ADC #$40` -> el banco/base nuevos). Más invasivo, más potente:
   resolvería también futuros textos.
3. **Quitar las tildes en el menú** (`FACIL`, `MUY DIFICIL`). Coste cero,
   y hoy es estrictamente mejor que lo que hay (basura en pantalla).

Recomendación: **opción 3 ahora** (dos bytes: `C2`->`41`, `C4`->`49`, en
las tres copias) y dejar la 1 o la 2 para cuando se aborde el guion
completo, que va a necesitar sitio de todas formas.

---

## (33) [HECHO] v75 — quitadas las tildes rotas del menú (parche separado)

Aplicada la opción 3 de la entrada (32). **Parche independiente**, sobre la
v74, para que David pueda aceptar o rechazar la intro y el menú por
separado.

### Por qué NO se puede hacer buscar-y-reemplazar

`0xC2` y `0xC4` son katakana de uso corriente en el texto japonés que sigue
sin traducir: **14 y 56 apariciones** en el banco `0x1E000-0x20000`.
Cambiarlas todas destrozaría el japonés.

Se tocan sólo las **4** posiciones de textos latinos ya traducidos, y el
constructor verifica el **contexto completo** de cada una antes de
escribir (no sólo el byte):

```
0x1FB13  C2 -> 41   \x01<F·CIL\x00        FÁCIL       -> FACIL
0x1FB26  C4 -> 49   \x01<DIF·CIL\x00      DIFÍCIL     -> DIFICIL
0x1FB34  C4 -> 49   \x02<MUY DIF·CIL\x00  MUY DIFÍCIL -> MUY DIFICIL (1)
0x1FC5A  C4 -> 49   \x01<MUY DIF·CIL\x00  MUY DIFÍCIL -> MUY DIFICIL (2)
```

La cuarta es la copia descubierta en (32), la que acaba pegada al texto de
la intro.

### Verificación

- exactamente **4** bytes distintos de la v74 (el constructor aborta si son
  más o menos);
- nada tocado fuera de `0x1E000-0x20000`;
- renderizado de los dos rótulos con la fuente del menú, antes y después:
  antes salen dos manchas de gráfico en el sitio del acento, después se lee
  `FACIL` y `MUY DIFICIL` limpio.

### Entrega

```
test_menu_v75.pce
  MD5    04aa02e12223e5d16a1eda15883d3a0a
  SHA-1  e86ecbd8bae07ee893e6be9921da21ca08f55b10
  CRC32  8e91f81e
momotaro_menu_v75.ips   32 B, 4 tramos   (SOBRE LA v74, no sobre la v72)
```

### Sigue pendiente
Las tildes de verdad en el menú requieren reubicar la fuente entera o
sacrificar signos. Se abordará junto al guion completo, que va a necesitar
espacio igualmente. Esto es un apaño consciente, no la solución.

---

## (34) [HECHO] La ROM base de la intro NO es virgen. Y falta la ROM original en el workspace

Intentando abordar la tarea del cuarto modo (ゲロゲロモード), fui a
verificar el dato del diario «`LDX #$4A` en `$C5C3` (ROM `0x1A5C4`)» y no
está ahí.

### Lo medido

```
ROM 0x1A5B0  08 76 08 78 08 7a a9 0f 18 65 20 53 04 20 77 dc
ROM 0x1A5C0  ea ea ea ea ea ea ea ea ad 83 3c 0a aa bd a6 5b
```

Decodificado (banco `0x0D` en `$C000`):

```
$C5B6: a9 0f 18 65 20 53 04   LDA #$0F / CLC / ADC $20 / TAM #$04
$C5BD: 20 77 dc               JSR $DC77        <- el trampolín del diario
$C5C0: ea ea ea ea ea ea ea ea    <- OCHO NOPs
$C5C8: ad 83 3c               LDA $3C83        <- la tabla base_x
```

Donde el diario dice que hay `LDX #$4A` hay **ocho `NOP`**. Y el `LDX #$4A`
(`a2 4a`) **no aparece ni una sola vez en toda la ROM**.

Segunda zona igual, `$C95A` (ROM `0x1A95A`): cuatro `NOP` entre un
`BRA +7` y un `LDY $3C91`.

Son las **únicas dos** rachas de ≥4 `NOP` de los 512 KB.

### [HECHO] La v72 no es virgen

Prueba directa, sin depender de los NOPs: la ROM contiene **texto latino**
en los menús de un juego japonés de Hudson de 1990.

```
0x1FB10  ·<F·CIL··<NORMAL··<DIF·CIL··<MUY DIF·CIL···<CANTO DE JIZO··<CARGAR
0x1F214  ·<<<SCROL<TEST<<
```

`test_intro_v72.pce` acumula el trabajo de todas las sesiones anteriores
del proyecto. No es la ROM original.

### [HIPÓTESIS, no demostrado] los NOPs son de una sesión previa

Es lo más probable —encajan con el trabajo descrito en el diario sobre el
selector de dificultad— **pero no lo he demostrado**. Podrían estar en el
original: los `NOP` de relleno existen en ROMs comerciales. Para
demostrarlo hace falta comparar con la ROM virgen.

**Y la ROM virgen no está en el workspace.** Sólo hay:

```
test_intro_v72.pce   test_intro_v73.pce   test_intro_v74.pce   test_menu_v75.pce
```

Tampoco está `test_diffsel_v26.pce` (MD5 `b124c7ae…`), que según
`ESTRUCTURA_WORKSPACE.md` es la versión válida del menú. Es decir que
**la rama del menú y la rama de la intro se están construyendo sobre
bases distintas**, y sólo una de las dos está aquí.

### Riesgo real detectado

La v74 y la v75 se construyen sobre la v72. Si la rama del menú sigue
sobre la v26, al final habrá que fusionar dos ROMs que divergieron. Las
zonas que toca cada una:

```
v74/v75 (intro):  0x1FC5F-0x1FEA7 (texto), 0x3DDA0-0x3DE50 (fuente),
                  0x43F9B+ (tabla), + 4 bytes en 0x1FB13-0x1FC5A
v26 (menú):       desconocido desde aquí — la ROM no está
```

Se solapan en la zona `0x1FB10-0x1FC5E`, que es justo donde están los
textos del menú **y** la segunda copia de `MUY DIFÍCIL` pegada a la intro
(entrada 32).

### Qué hace falta de David

1. **La ROM virgen** (el dump original de Momotarou Katsugeki). Sin ella
   no se puede saber qué es obra del proyecto y qué es del juego.
2. **`test_diffsel_v26.pce`**, si la rama del menú va a continuar.

Hasta tener la 1, la tarea de ゲロゲロモード **no se puede abordar con
rigor**: no se puede distinguir código original de código ya parcheado, y
ése es precisamente el terreno donde la v27 se estrelló.

> Esto no invalida la v74 ni la v75: ambas parten de la v72, están
> construidas contra medidas hechas *sobre la v72*, y sus verificaciones
> son autocontenidas. Pero sí marca el límite de lo que puedo afirmar del
> código del selector de dificultad.

---

## (35) ゲロゲロモード: localizado el limitador exacto, y por qué NO basta cambiarlo

La entrada del diario sobre el cuarto modo estaba etiquetada como
«[HIPÓTESIS descartada por análisis]» sin que nadie hubiera medido nada.
Ya está medido. El resultado es mixto: se encuentra el limitador, y se
encuentra también por qué tocarlo a secas rompería el menú.

### [HECHO] El bucle que dibuja los modos: `$C4C0` (ROM `0x1A4C0`)

Banco `0x0D` en `$C000`. Desensamblado a mano (recordatorio: capstone no
sirve para el HuC6280):

```
$C4C2: ad 88 3c   LDA $3C88        ; modo actualmente seleccionado
$C4C5: 0a aa      ASL A / TAX
$C4C7: bd 98 c5   LDA $C598,X      ; puntero a la lista de orden
$C4CA: 85 14      STA $14
$C4CC: bd 99 c5   LDA $C599,X
$C4CF: 85 15      STA $15
$C4D1: b1 14      LDA ($14),Y      ; índice del modo Y-ésimo a dibujar
$C4D3: 0a aa      ASL A / TAX
$C4D5: 98 0a a8   TYA / ASL A / TAY
$C4D8: b9 a2 c5   LDA $C5A2,Y      ; destino CG
$C4DB: 85 16      STA $16
$C4DD: b9 a3 c5   LDA $C5A3,Y
$C4E0: 85 17      STA $17
$C4E2: bd ae 54   LDA $54AE,X      ; SAT
$C4E5: 85 bf      STA $BF
$C4E7: bd af 54   LDA $54AF,X
$C4EA: 85 c0      STA $C0
$C4EC: 20 16 aa   JSR $AA16        ; dibuja
$C4EF: 7a         PLY
$C4F0: c8         INY
$C4F1: c0 03      CPY #$03         <<< EL LIMITADOR: 3 modos
$C4F3: d0 cc      BNE $C4C1
$C4F5: 60         RTS
```

**El byte a cambiar sería ROM `0x1A4F2`: `03` -> `04`.** Un byte.

### [HECHO] Y por qué NO se puede cambiar sin más

Norma 1 (comprobar antes de escribir) y Norma 3 (mirar qué hay detrás).
Las tablas que el bucle indexa:

```
0x1A598: 9c c5        <- puntero a la lista del modo 0 ($C59C)
0x1A59A: 9f c5        <- puntero a la lista del modo 1 ($C59F)
0x1A59C: 02 01 00     <- LISTA del modo 0, TRES elementos
0x1A59F: 03 02 01     <- LISTA del modo 1, TRES elementos
0x1A5A2: 08 70 88 71 88 72 ...   <- tabla CG $C5A2
```

Las dos listas son de **3 elementos** y están **pegadas**: la del modo 0
termina exactamente donde empieza la del modo 1, y la del modo 1 termina
exactamente donde empieza la tabla CG. Poner `CPY #$04` haría que el bucle
leyera un cuarto byte de cada lista, es decir:

- lista modo 0 -> leería el `03` que es el **primer byte de la lista del
  modo 1**;
- lista modo 1 -> leería el `08` que es el **primer byte de la tabla CG**,
  y `08` como índice de modo se saldría de rango.

### [CORRECCIÓN en el acto] error mío de lectura

Al leer `$C598` como una tabla de 4 punteros me salieron «modo 2 ->
`$0102`» y «modo 3 -> `$0300`». Son basura: estaba leyendo los bytes de
las **listas** como si fueran punteros. La tabla `$C598` sólo tiene
**dos** entradas. Lo detecté al ver punteros que no apuntaban a ninguna
parte — un puntero a `$0102` en un banco de ROM no tiene sentido.

### [HECHO] Lo que sí está preparado para 4 modos

- La tabla de textos `0x1F4AE` tiene **4 entradas** válidas:
  `FÁCIL / NORMAL / DIFÍCIL / MUY DIFÍCIL`.
- La tabla CG `$C5A2` tiene datos en el índice Y=3 (`08 70`), no ceros.
- El texto `MUY DIFÍCIL` existe (dos copias).

O sea que el trabajo de *contenido* está hecho; lo que falta es la
*estructura* de listas.

### Lo que haría falta (NO ejecutado)

Reubicar las dos listas de orden a un hueco libre, ampliarlas a 4
elementos, y repuntar `$C598`. Es exactamente el patrón que funcionó en
Nekketsu con los tilemaps. Pero:

1. requiere localizar hueco libre **en el banco `0x0D`**, no en cualquier
   sitio (el bucle lee vía puntero de 16 bits dentro del banco mapeado);
2. hay que verificar que el orden de rotación de 4 elementos que espera el
   juego es el correcto, y eso **sólo se puede confirmar viéndolo**;
3. sigue faltando la ROM virgen (entrada 34) para saber si esta zona ya
   fue tocada.

**No se toca.** Queda documentado con el byte exacto y el obstáculo
exacto, para retomarlo con emulador delante.

> Corrijo la etiqueta del diario: la entrada sobre ゲロゲロモード **no**
> estaba «descartada por análisis». Ahora está *parcialmente resuelta*:
> limitador localizado (`0x1A4F2`), bloqueo identificado (listas pegadas),
> pendiente de reubicación y de verificación visual.

---

## (36) [HECHO] v76 — texto y reparto de páginas revisados por David

David revisó la v74 y corrigió redacción, puntuación y reparto. Sus dos
indicaciones:

1. «¡Esto es "Momotaro en acción"...!» debe ir en **página propia**, aunque
   la anterior no llegue a 4 líneas.
2. El texto tiene que decir exactamente lo que él dictó, con su puntuación.

### [HECHO] Límites reales del motor (medidos antes de repartir)

Desensamblado del intérprete `$D175` (ROM `0x1B175`), banco `0x0D`:

```
$D175: a9 0f 18 65 20 53 04   LDA #$0F / CLC / ADC $20 / TAM #$04
$D17C: b2 bf                  LDA ($BF)      ; byte del stream
$D17E: f0 21                  BEQ            ; 0x00 = fin de LÍNEA
$D180: c9 ff / d0 03 / 4c ff d1               ; 0xFF = FIN del texto
$D187: c9 fe / f0 3d                          ; 0xFE = fin de PÁGINA
$D18B: c9 fd / f0 47                          ; 0xFD = control
$D18F: c9 fc / f0 5b                          ; 0xFC = control
$D193: 20 38 aa               JSR $AA38      ; dibujar carácter
```

Manejador de fin de línea (`$D1A0`):

```
$D1A0: ee e3 3c   INC $3CE3     ; contador de líneas
$D1A6: c9 04      CMP #$04      <- MÁXIMO 4 LÍNEAS POR PÁGINA
$D1AC: 8d e8 3c   STA $3CE8     ; página llena -> espera botón
$D1B4: bd bb d2   LDA $D2BB,X   ; tabla de posiciones Y
```

**Hallazgo que desbloquea el reparto: no existe contador de páginas.**
`0xFE` sólo pone a cero el contador de línea. Por eso se puede pasar de 8
a **11 páginas sin tocar una sola instrucción**. Antes de medir esto no
había forma de saber si era seguro añadir páginas.

### Criterio de reparto

El texto se define por **frases**, no por líneas, y se agrupan de forma que
**ninguna frase quede partida entre dos páginas** — David ve el cambio de
página como un punto y aparte. Un primer intento mío partía frases entre
las páginas 6-7 y 8-9; lo deshice antes de entregarlo.

Resultado: **11 páginas**, ninguna de más de 4 líneas, ninguna línea de más
de 24 caracteres, ninguna frase cortada.

### Comillas: glifo nuevo sin dibujar nada

«Momotaro en acción» va entrecomillado. El ASCII `0x22` no sirve: es menor
que `0x30` y cae en el fallback. Pero la fuente ya tiene comillas dobles
japonesas en el glifo `0xD1`, **sin que ningún código lo referencie**.

```
"  byte 0x6B -> glifo 0xD1
```

Un byte de tabla, cero dibujos nuevos. Mismo método que con `.`, `,` y `!`.

### [HECHO] No hay minúsculas en la fuente

Comprobado por barrido: la fuente del diálogo **no tiene minúsculas
latinas**. El texto va en mayúsculas por necesidad, no por decisión.

### Entrega

```
test_intro_v76.pce
  MD5    244460145c74ede812daf88a3da51100
  SHA-1  97aeb7deb3c1a2ab1642f25ed8ec54a5581aa296
  CRC32  a44c59a0
  627 bytes distintos de la v72
momotaro_intro_v76.ips   835 B, 40 tramos, reaplicado y verificado
```

Texto 575 -> 586 B, con 354 B libres detrás. **0 caracteres en fallback.**
Las 11 páginas renderizadas desde la ROM en `preview_v76/`.

> La v75 (menú) sigue siendo un parche independiente sobre la **v74**.
> Si David acepta la v76, habrá que rehacer ese parche sobre ella: son los
> mismos 4 bytes y las direcciones no cambian.

---

## (37) [HECHO] Repaso de la traducción contra el texto dictado por David

David pidió repasar que el texto de la v76 coincida **exactamente** con el
que él escribió, signos de puntuación incluidos.

### Verificación automática, no a ojo

Se leyó el texto **de la ROM** (no del `.py`, para que la comprobación sea
independiente del constructor), decodificando los códigos por la tabla
`0x43F9B`, y se comparó carácter a carácter con el texto de David pasado a
mayúsculas:

```
David (mayúsculas): 585 caracteres
ROM v76           : 585 caracteres
*** IDÉNTICOS ***
```

Coinciden los puntos suspensivos, las comillas de «Momotaro en acción», la
coma de "estooo, hola.", el punto final de "seguro." y las once
exclamaciones con su signo de apertura.

### [HECHO] La estructura de 7 bloques de David NO cabe

David escribió el texto en 7 bloques. Comprobado bloque a bloque contra el
límite del motor (4 líneas por página, 24 caracteres por línea):

| bloque | líneas que necesita | ¿cabe? |
|---|---|---|
| 1 | 3 | sí |
| 2 | 2 | sí |
| 3 | 4 | sí (justo) |
| **4** | **6** | **NO** |
| **5** | **7** | **NO** |
| **6** | **5** | **NO** |
| 7 | 3 | sí |

### [HECHO] El límite de 4 líneas no se puede subir

Se comprobó si bastaba con cambiar el `CMP #$04` de `$D1A6`. **No.** La
tabla de posiciones Y de línea (`$D2BB`, ROM `0x1B2BB`) sólo tiene cuatro
entradas válidas:

```
línea 0 -> VRAM $7008     línea 4 -> $B220   <- basura
línea 1 -> VRAM $7308     línea 5 -> $20B9   <- basura
línea 2 -> VRAM $7608     línea 6 -> $EF5F   <- basura
línea 3 -> VRAM $7908     línea 7 -> $F920   <- basura
```

Las cuatro válidas van separadas `0x300` (una fila de tiles). De la quinta
en adelante son datos de otra cosa: subir el contador escribiría fuera del
bocadillo. El límite es real.

### Dónde se cortaron los 3 bloques que no caben

En los tres casos el corte cae en final de frase, nunca a mitad:

```
bloque 4 -> pág. 4 y 5:   "...selecciona el Modo Fácil!" | "¡No pasa nada..."
bloque 5 -> pág. 6, 7, 8: son exactamente sus 3 frases
bloque 6 -> pág. 9 y 10:  "...en el Modo Fácil!" | "¡Y conviértete..."
```

### [HECHO] La ROM que probó David es la nuestra

Descargada `test_intro_v74.pce` del repositorio de GitHub:

```
GitHub  85aa167228220f0f8113551baf45d968
local   85aa167228220f0f8113551baf45d968   -> idénticas
```

### Estado de la entrega

```
test_intro_v76.pce   MD5 244460145c74ede812daf88a3da51100   intro
test_momo_v77.pce    MD5 15d530653481ef9c3b2eccd94f7cea70   + menú (4 B)
```

Verificado: 480 caracteres de texto, **0 en fallback**, 11 páginas, fuente
del menú intacta, A-Z y 0-9 intactos byte a byte, IPS reaplicado sobre la
v72 reproduce la ROM exacta.

---

## (38) v78 — prueba de minúsculas. Y un error mío de la v74

### [ERROR MÍO] La fuente ya tenía acentos y minúsculas

Al generar por primera vez una **lámina completa de los 256 glifos** de la
fuente del diálogo (para localizar los kana de otro bloque de texto),
apareció que la fuente **ya contenía** desde la v72:

```
a-z        -> 0xA1-0xBA        á é í ó ú -> 0xBB-0xBF
ñ          -> 0xC1             Á É Í Ó Ú -> 0xC2-0xC6
Ñ ¿ ¡      -> 0xC8 0xC9 0xCA
```

Dibujé ocho glifos en la v74 que ya existían.

**Por qué se me pasó:** busqué huecos vacíos y comprobé que ningún *código*
`0x30-0x83` alcanzaba esos glifos — cierto, están fuera del alcance de la
tabla — pero **nunca miré la fuente entera de un vistazo**. Una lámina de
16×16 el primer día lo habría enseñado en dos segundos.

> **Norma 16: antes de dibujar un glifo, volcar la fuente ENTERA como
> imagen y mirarla.** Es un minuto y evita rehacer lo que ya está.

### [HECHO] De dónde salen esos glifos: los hizo David

Dato aportado por David: son de la **pantalla de contraseñas**. El original
usaba 64 kana con dakuten/handakuten, y él se dio cuenta de que 64 celdas
equivalen a A-Z + a-z + 0-9 + 2. Sustituyó el juego completo.

Eso explica la medición: están dimensionados para la rejilla de la
password, no para la fuente del diálogo.

```
A-Z del diálogo  : trazo 2 px, ancho 6-7, altura 7
a-z de password  : trazo 1 px, ancho 3-5, altura 5-7
Ñ ¿ ¡ (0xC8-0xCA): trazo 2 px   <- éstos sí son de cuerpo grueso
```

### v78: construida para que David lo juzgue en pantalla

44 códigos apuntados a glifos existentes. **No se dibuja ni un solo
glifo**: sólo se tocan la tabla y el texto (verificado, `0x3D660-0x3DE60`
byte a byte idéntico a la v72).

```
test_intro_v78.pce
  MD5    eab9cb85ed5ea22b97aa20e33cde654e
  CRC32  503a2b69
momotaro_intro_v78.ips   680 B, 10 tramos, verificado
```

### Resultado medido: la mezcla no funciona

Renderizado desde la ROM: en "¡Hola", la `H` es un bloque de trazo doble y
"ola" son trazos de un píxel. En "¡Esto es «Momotaro»", la `E` y la `M`
destacan como manchas. No es cuestión de gusto: son **dos cuerpos
tipográficos distintos** en la misma palabra.

Alternativa descartada por falta de sitio: dibujar 25 minúsculas de trazo
grueso. En la v76 sólo queda **un** glifo vacío en toda la fuente
(el `0x00`, que además significa "fallback" en la tabla).

### Recomendación
Mantener la **v76** (mayúsculas). Coincide además con el estilo del
original japonés, que va todo en kana sin distinción de caja.

---

## (39) [REGRESIÓN GRAVE, culpa mía] La v76/v77/v78 rompen el CANTO DE JIZO

David detecta que en la v77 la **parrilla de la pantalla de contraseñas
(«Canto de Jizo»)** sale con `Á` en lugar de los puntos, y el menú de la
derecha muestra `..RÁS` en vez de `ATRÁS`.

### Causa, medida

**No es un byte mal escrito.** Comprobado: `0x1E9C0`, `0x1E7E0` y `0x1E360`
están **intactos** en la v77. Los datos de la parrilla no se han tocado.

Lo que rompí es la **tabla `0x43F9B`**, que es **global**. Desvié 12
entradas:

```
byte 60: glifo DB -> E8     byte 66: E0 -> FC
byte 61: glifo DF -> E9     byte 67: E1 -> FD
byte 62: glifo AF -> EE     byte 68: E2 -> 8A
byte 63: glifo 00 -> F3     byte 69: E3 -> CC
byte 64: glifo A0 -> F8     byte 6A: E4 -> 9E
byte 65: glifo 9C -> FB     byte 6B: E5 -> D1
```

El glifo `0xDB`, al que apuntaba el byte `0x60`, es **el punto central**
de la celda de la parrilla:

```
........
...##...
...##...
........
```

La parrilla del Canto de Jizo está en ROM `0x1E9CA` y es un **tilemap**:

```
60 07 61 62 | 60 07 61 62 | 60 07 61 62 | ... (8 columnas)
```

Son índices de tile, **no texto** — pero el dibujante los resuelve por la
**misma tabla `0x43F9B`**. Al desviar `0x60` a la `Á`, cada punto de la
parrilla pasó a dibujar una `Á`. Exactamente lo que se ve en la captura.

### [ERROR DE MÉTODO] Por qué no lo detecté

En la entrada (32) hice el inventario de códigos y **di el visto bueno**.
El fallo: busqué los códigos sólo en los **streams de texto** (los que
tienen cabecero `<nn> 3C ... 00`). La parrilla no es un stream de texto, es
un tilemap, así que mi barrido no la vio.

Escribí literalmente que los códigos «no aparecen en ningún texto del
juego fuera de la intro». Era cierto y **era irrelevante**: la tabla no la
usa sólo el texto.

> **Norma 17: la tabla `0x43F9B` la comparten el intérprete de texto Y los
> tilemaps.** Antes de tocar una entrada hay que buscar ese byte en TODO el
> banco, no sólo en los streams de texto.
>
> **Norma 18: comprobar que un asset no se usa "en los sitios que conozco"
> no es comprobar que no se usa.** La norma 9 de Nekketsu decía justo esto
> y la apliqué a medias.

### Alcance

Afecta a **v76, v77 y v78**. La **v74 también** (mismos 12 desvíos).
La única versión sana de esta rama es la **v72**.

David validó la intro de la v74/v76 en pantalla, pero no llegó a abrir el
Canto de Jizo, así que la regresión pasó desapercibida.

### Restricción para el arreglo

Los glifos buenos (`0xA1-0xCA`, los que hizo David para la password) **no
son alcanzables por código directo**: `0xA1` da idx `0x71` ≥ `0x54`, o sea
fallback. Para usarlos hay que pasar por la tabla, y la tabla es global.

Búsqueda de códigos realmente seguros (entrada de tabla que hoy no dibuja
nada **y** que no aparezca en `0x1E000-0x1F200`): **ninguno cumple las dos**.
Los menos malos (`0x6E 0x6F 0x74 0x79 0x81 0x82 0x83`) aparecen **una sola
vez** cada uno, todos dentro del tilemap `0x1E355-0x1E3A0`.

### Siguiente paso
No improvisar. Hay que identificar qué dibuja el tilemap `0x1E355-0x1E3A0`
antes de decidir, y pedir a David la documentación del chat original: la
pantalla del Canto de Jizo la construyó él y sabrá qué códigos usa.

---

## (40) [ARREGLADO] v80 — corregida la regresión del Canto de Jizo

### Prueba definitiva de la causa

La `Á` que David ve en la parrilla es de **trazo grueso**: es el glifo
`0xE8` que dibujé yo, no la `Á` fina de `0xC2`. Confirma que la parrilla
resuelve sus tiles por la tabla `0x43F9B` y que la rompí yo.

### Documentación aportada por David (chat original)

Copiada a `docs/`. Datos que corrigen el diario:

- **ROM virgen**: `Momotarou Katsugeki (Japan).pce`, MD5
  `ec7358edb3672a8aa8850623eec72a71`. (Entrada 34: ya no es incógnita.)
- **Versión válida del proyecto**: `Momotaro katsugeki v30.pce`, MD5
  `1e2baa578f10a43deb3d95ecd1837c8f`. La `v26` que citaba
  `ESTRUCTURA_WORKSPACE` está superada.
- La entrada (83) del diario original ya avisaba: *«Diseñar glifos + tocar
  tabla a ciegas corrompe el espacio»*. El intento v73 del chat original
  falló **por la misma razón** que mi v74. Lo repetí sin saberlo.

### [HECHO] Por qué chocan los códigos

La parrilla (ROM `0x1E9CA`) usa los bytes `0x58 0x59 0x5A 0x5E 0x5F
0x60-0x68`. En ASCII eso es `X Y Z ^ _` y `` ` `` `a`-`h`: justo donde caen
las minúsculas. Por eso cualquier intento de meter acentos o minúsculas
por ahí rompe la pantalla.

### Solución de la v80

12 códigos elegidos que **no aparecen** en la parrilla (`0x1E9C0-0x1EA80`),
ni en el menú derecho (`0x1F200-0x1F300`), ni en los prompts
(`0x1FB00-0x1FC5F`):

```
Á 0x6E -> glifo 0xE8      ¿ 0x71 -> glifo 0xC9   (ya existía, grueso)
É 0x6F -> glifo 0xE9      ¡ 0x72 -> glifo 0xCA   (ya existía, grueso)
Í 0x74 -> glifo 0xEE      . 0x73 -> glifo 0x8A
Ó 0x79 -> glifo 0xF3      , 0x77 -> glifo 0xCC
Ú 0x7E -> glifo 0xF8      ! 0x81 -> glifo 0x9E
Ñ 0x6D -> glifo 0xC8      " 0x82 -> glifo 0xD1
```

Las cinco vocales acentuadas se dibujan **de trazo grueso** en los cinco
glifos que estaban vacíos (`0xE8 0xE9 0xEE 0xF3 0xF8`), para que casen con
las mayúsculas del diálogo. La `Ñ ¿ ¡` ya existían gruesas.

### Verificaciones que aborta el constructor

- ningún código elegido aparece en las tres zonas del Canto de Jizo;
- sin solape entre los códigos elegidos y los de la parrilla;
- sólo se dibujan los 5 glifos vacíos previstos;
- A-Z, 0-9 y **los glifos de David (`0xA1-0xCA`) intactos**;
- las entradas de tabla de los bytes de la parrilla, intactas;
- parrilla, menú y prompts idénticos byte a byte a la v72;
- 0 caracteres en fallback.

**Comprobación funcional:** renderizada la parrilla con la tabla de cada
versión — la v80 dibuja **exactamente lo mismo que la v72**, la v77 dibujaba
las `Á`.

```
test_intro_v80.pce
  MD5    3f758fe8cf53b9593e30eff9f2122dec
  SHA-1  753c52d985c8936a9cc3d483bf3031f38e50a1b4
  CRC32  eebbd8b0
momotaro_intro_v80.ips   796 B, 37 tramos, verificado
```

### [ERROR MÍO] Juzgar un glifo a ojo

Di por malo el resultado de la `Ó` mirando el PNG ampliado. Al medir los
píxeles del propio PNG, la `Ó` **es gruesa** y correcta. A ese tamaño la
tilde engaña. Medir, también cuando el error parece obvio a la vista.

### Minúsculas: pendiente y bloqueado
Con los códigos ASCII `a-h` ocupados por la parrilla, meter el alfabeto
minúsculo exige usar códigos no-ASCII y una tabla de conversión propia.
Es viable pero hay que rehacerlo con cuidado. **No se intenta ahora.**

---

## (41) [REGRESIÓN 2] v80 rompía el menú lateral del Jizo. v81 lo corrige

David prueba la v80: la parrilla vuelve a estar bien, pero **sobre el menú
lateral** (ADELANTE / ATRÁS / ESPACIO / BORRAR / FIN) aparecen superpuestos
los símbolos `!  ?  Ñ  ,`.

### Causa medida

En la v80 cambié **12** entradas de tabla. Ocho apuntaban a glifos VACÍOS
(seguras), pero **cinco apuntaban a glifos katakana CON DIBUJO**:

```
byte 6D: katakana E7 -> Ñ    byte 73: katakana ED -> .
byte 71: katakana EB -> ¿    byte 77: katakana F1 -> ,
byte 72: katakana EC -> ¡
```

Ésos son exactamente los símbolos que David ve encima del menú. El menú
lateral usa esos códigos, y al reasignarlos pasó a dibujar mis símbolos.

### [ERROR MÍO, el mismo dos veces seguidas]

En la v74 comprobé los códigos sólo contra los streams de texto y me
saltaron los tilemaps. En la v80 amplié el barrido a la parrilla, el menú
y los prompts... **pero delimitando las zonas a ojo**, con rangos que yo
mismo elegí (`0x1F200-0x1F300` para el menú). Si la zona real no está
dentro de ese rango, el barrido no la ve. Y no lo estaba.

Buscar en «los sitios donde creo que está» no es buscar. Es la norma 18
que yo mismo escribí en la entrada (39), incumplida en el mismo arreglo.

### El criterio bueno, que no depende de adivinar zonas

> **Norma 19: un código sólo es seguro si su entrada de tabla apuntaba a
> un glifo VACÍO en la ROM base.** Si el glifo está vacío, ese código no
> dibuja nada hoy en NINGUNA pantalla — sin importar dónde aparezca. No
> hace falta saber qué zonas existen ni delimitarlas.

Hay exactamente **8** códigos así: `0x6E 0x6F 0x74 0x79 0x7E 0x81 0x82 0x83`.

### v81

El texto sólo usa `! " , . ¡` y las cinco vocales acentuadas: la `Ñ` y el
`¿` no aparecen en la intro. Y el `!` **ya funciona** con el código `0x5C`
que trae la ROM base (apunta al glifo `0x9E`). Así que hacen falta
exactamente 8 códigos, y hay 8.

```
Á 0x6E   É 0x6F   Í 0x74   Ó 0x79
Ú 0x7E   ¡ 0x81   , 0x82   . 0x83
!  ->  0x5C  (ya existía, no se toca)
```

Las comillas de «Momotaro en acción» se quitan: no queda slot y son
prescindibles. La frase queda `¡ESTO ES MOMOTARO EN ACCIÓN, UN JUEGO QUE
CUALQUIERA PUEDE SUPERAR!`.

### Verificación nueva y definitiva

Se compara, **para los 256 bytes posibles**, qué dibujaba cada uno en la
v72 y qué dibuja en la v81:

```
bytes cuyo dibujo cambia: 6E 6F 74 79 7E 81 82 83
y los ocho dibujaban VACÍO en la v72
```

Ninguna pantalla del juego puede cambiar, porque ningún byte que antes
pintaba algo pinta ahora algo distinto. Esto **no depende de haber
localizado las zonas correctamente**, que es donde fallé dos veces.

```
test_intro_v81.pce
  MD5    b3c6c86ef66d7110791e6534fc2311f9
  SHA-1  2f2564f31a39439c251f19febb8373448160c0da
  CRC32  66571a87
momotaro_intro_v81.ips   795 B, 37 tramos, verificado
```

## (42) [PISTA IMPORTANTE de David] La pantalla de contraseña incorrecta

David aporta una captura de la pantalla de «El canto de Jizo no es
correcto»: usa **mayúsculas y minúsculas perfectamente**, y es casi
idéntica a la de la introducción — mismo bocadillo y **los mismos sprites
animados** de Momotaro y sus amigos abajo.

Consecuencias:

1. Confirma que el motor de diálogo **sí sabe dibujar minúsculas**. Si esa
   pantalla lo hace, la intro también puede.
2. Esa pantalla es el sitio donde mirar cómo se codifican las minúsculas
   sin romper nada: alguien ya resolvió ahí el problema que yo tengo.

**Tarea siguiente:** localizar el texto de esa pantalla y volcar sus bytes.
Eso da el mapa código→minúscula que funciona, medido de un caso real en vez
de deducido.

### [HECHO] El texto de «canto de Jizo no es correcto» NO está en la v72

Buscado en la ROM base, tanto por ASCII directo (`canto`, `Jizo`,
`correcto`) como decodificando por la tabla: **no aparece**. Los cuatro
punteros del motor de diálogo en ese banco (`0x1F385`, `0x1F485`,
`0x1F585`, `0x1F685`) apuntan a **katakana japonés sin traducir**.

Es decir que esa pantalla la tradujo David en la rama de la `v30`, que
**no está en este workspace**. La `v72` (base de la rama de la intro) no
la incluye.

**Para aprovechar esa pista hace falta `Momotaro katsugeki v30.pce`**
(MD5 `1e2baa578f10a43deb3d95ecd1837c8f`). Con ella se puede volcar el
texto ya traducido y leer el mapa código→minúscula que funciona de verdad,
en vez de deducirlo.

Refuerza además lo dicho en la entrada (34): las dos ramas divergieron y
hay que fusionarlas. La v30 tiene traducciones que la v72 no tiene.

---

## (43) [CORRECCIÓN a la entrada 42] Me equivoqué: la v81 SÍ es acumulativa

Dije que la pantalla de «El canto de Jizo no es correcto» no estaba en la
v72 porque no encontré su texto. David corrige: **todas sus versiones son
acumulativas**, la última estable lo contiene todo, y la captura era de la
v80/v81.

**Mi error de método:** busqué el texto por ASCII (`canto`, `Jizo`) y
decodificando por la tabla `0x43F9B`, y al no encontrarlo concluí que no
existía. Pero esa pantalla **no usa la ruta de la tabla**: usa la ruta
katakana (`>= 0xA0`, tabla `$9CF3/$9CB3`), que es otro camino del renderer
documentado en la entrada (82) del diario original.

Buscar por una sola codificación y concluir «no está» es el mismo fallo de
siempre: comprobar en los sitios que conozco no es comprobar.

> **Norma 20: el renderer tiene DOS rutas (tabla y katakana). Un texto que
> no aparece por una puede estar en la otra.** Antes de decir que algo no
> existe, probar las dos.

## (44) [REGRESIÓN 3] La v81 perdió las exclamaciones de cierre

David reporta que en la v81 **desaparecieron los 9 signos `!`** del final
de las frases. Los `¡` de apertura sí salen.

### Causa medida

En la v81 usé el código `0x5C` para el `!` porque su entrada de tabla ya
apuntaba al glifo `0x9E` (el `!`). Parecía gratis. **No lo era.**

Desensamblada la rutina de dibujo `$AA38`:

```
$AA5A: 20 8c aa   JSR $AA8C     ; ¿el byte está en la lista?
$AA5D: b0 05      BCS +5        ; NO -> dibujar como glifo normal
$AA5F: a9 03      LDA #$03
$AA61: 20 7b e3   JSR $E37B     ; SÍ -> tratamiento especial (no dibuja)
```

`$AA8C` recorre una tabla en `$AAA3` terminada en `0xFF`:

```
20 3A 3B 3C 3D 3F 40 5B 5C 5D 5E DE DF 21 A2 A3
```

**`0x5C` está en esa lista.** Es un código de CONTROL (espacio / salto /
separador), y el motor lo intercepta antes de llegar al dibujado. Por eso
la entrada de tabla apuntaba a un glifo válido y aun así no se veía nada:
el glifo nunca llega a consultarse.

Lección: que un código tenga entrada de tabla válida **no** significa que
sea imprimible. Hay un filtro previo.

> **Norma 21: antes de usar un código, comprobar que NO está en la lista
> de control `$AAA3` (ROM `0x42AA3`, termina en `0xFF`).**

### v82

Criterio de seguridad definitivo, ahora con las tres condiciones:

1. la entrada de tabla apuntaba a un **glifo vacío** en la v72 (no dibuja
   nada hoy en ninguna pantalla, esté donde esté);
2. el código **no está** en la lista de control `$AAA3`;
3. verificación final sobre los **256 bytes posibles**: sólo cambian los
   que antes pintaban vacío.

Hay exactamente **8** códigos que cumplen 1 y 2:
`0x6E 0x6F 0x74 0x79 0x7E 0x81 0x82 0x83`.

Y hacen falta 9 símbolos (`Á É Ó ¡ , . !` más `Í Ú` si aparecieran).
**Medido: el texto sólo usa `Á`, `É` y `Ó`.** No hay ninguna `Í` ni `Ú`.
Así que el hueco reservado a la `Í` se dedica al `!`:

```
Á 0x6E   É 0x6F   Ó 0x79   ! 0x74
¡ 0x81   , 0x82   . 0x83   Ú 0x7E (reservado, sin uso)
```

Si en el futuro el texto necesitara `Í` o `Ú`, habría que liberar otro
código o reubicar la fuente.

```
test_intro_v82.pce
  MD5    317e470a78d337d14ea5a0f76cba2fb7
  SHA-1  ffaaf479d3cad8a0303ac376b092df575b4082cf
  CRC32  9330a950
momotaro_intro_v82.ips   795 B, 37 tramos, verificado
```

Verificado: los 9 `!` presentes, 0 bytes de control en el texto, los 8
glifos modificados pintaban vacío antes, parrilla y menú intactos.

El constructor incluye ahora una comprobación que **aborta** si algún
código elegido aparece en la lista `$AAA3`.

---

## (45) [RESUELTO] El misterio de las minúsculas: hay DOS rutas y la buena es la katakana

David aporta `Extracto chat inicial.txt`, con el codificador original del
proyecto. **Ahí estaba la respuesta desde el principio.**

### La tabla oficial (`CHAR_TO_CODE`)

```python
' '            -> 0x20
'0'-'9'        -> 0x30+i
'A'-'Z'        -> 0x41+i
'!' '?' '$'    -> 0x21, 0x3F, 0x24
'a'-'z'        -> 0xA1+i          <<< POR ENCIMA DE 0xA0
'b','c','p'    -> 0x5B, 0x5D, 0x5E   (alias, "unsafe direct bytes")
'á é í ó ú ü ñ'-> 0xBB-0xC1
'Á É Í Ó Ú Ü Ñ'-> 0xC2-0xC8
'¿ ¡ . , : ; …'-> 0xC9-0xCF
''' '" - / ( ) % & + ¤ ç'  -> 0xD0-0xDA
'Ç º ª'        -> 0x5F, 0xDC, 0xDD
```

### Por qué esto lo cambia todo

El renderer tiene **dos rutas** (ya estaba en la entrada 82 del diario
original, y no supe leerlo):

```
byte >= 0xA0  ->  ruta KATAKANA: el glifo es el BYTE, directo
byte <  0xA0  ->  ruta TABLA:    glifo = tabla[byte-0x30]   (0x43F9B)
```

Las minúsculas y todos los acentos viven en `0xA1-0xDD`: **van por la ruta
katakana y no consultan la tabla `0x43F9B` en absoluto**.

Verificado glifo a glifo contra la ROM: `0xA1='a'`, `0xA5='e'`,
`0xBB='á'`, `0xBC='é'`, `0xBD='í'`, `0xC2='Á'`, `0xC8='Ñ'`, `0xCA='¡'`,
`0xCB='.'`, `0xCC=','`. Todos correctos.

### La respuesta a la pregunta de David

> «¿Que exista esa fuente no nos da la posibilidad de usarla en la
> introducción e incluso en el resto del juego?»

**Sí, completamente.** Y además es la vía *más segura*, no la más
arriesgada: al no tocar la tabla, es **imposible** que rompa la parrilla
del Canto de Jizo, el menú lateral o cualquier otra pantalla.

Las tres regresiones (v74, v80, v81) vinieron todas de modificar esa
tabla. Con la ruta katakana ese problema **desaparece de raíz**.

### [ERROR MÍO acumulado]

Tenía el dato delante desde el principio. La entrada (82) del diario
original decía: *«>= 0xA0 -> ruta katakana; < 0xA0 (ASCII) -> tabla
$BF9B»*. Lo leí, lo cité en la entrada (30) y **no saqué la consecuencia**:
que los códigos altos son alcanzables y no pasan por la tabla.

En vez de eso me empeñé en meter todo por la tabla, que es el recurso
escaso y compartido. Tres regresiones por no releer lo que ya estaba
escrito.

Y dije a David que ese texto «no estaba en la ROM» porque lo busqué sólo
por la ruta de la tabla. Estaba, codificado por la otra ruta.

### v83

```
test_intro_v83.pce
  MD5    e8821da7dcdef87f76a4837925e5074a
  SHA-1  9dbe7c519ee78415442241e28229c5864f556c3e
  CRC32  721eb33a
momotaro_intro_v83.ips   626 B, 8 tramos, verificado
```

Intro completa en mayúsculas y minúsculas, con tildes, `¡`, comillas y
puntuación. Se recuperan las comillas de «Momotaro en acción», que la v82
había perdido por falta de códigos.

**Verificado por el constructor, que aborta si falla:**
- tabla `0x43F9B` **INTACTA** — cero entradas modificadas;
- fuente del diálogo **INTACTA**;
- fuente del menú **INTACTA**;
- parrilla, menú lateral y prompts intactos;
- los 578 bytes modificados están **todos dentro del bloque de texto**.

De los 43 caracteres distintos del texto: 27 van por ruta katakana, 14 por
la tabla **con las entradas originales de la ROM** (mayúsculas y los tres
alias `b`, `c`, `p`), y el espacio y el `!` por fallback.

### [PENDIENTE de comprobar en pantalla] el `!`

El `!` se codifica `0x21`, que cae en fallback. En la pantalla de error de
contraseña **se ve correctamente**, así que debería funcionar igual aquí.
Pero mi renderizador de previsualización no simula la ruta de fallback, y
en las imágenes de `preview_v83/` el `!` no aparece.

**No sé si se verá o no.** Los 9 bytes `0x21` están en la ROM; queda que
David lo confirme en pantalla. Si no saliera, la solución es usar `0xD9`
(`¤`) o cualquier otro código libre de la zona katakana redibujado como
`!`, que es zona segura.

---

## (46) v83 PROMOCIONADA + inventario de fuentes y estado del guion

David confirma en pantalla: la v83 se ve correcta, con minúsculas, tildes,
comillas y el `!` (que iba por fallback y sí funciona). **v83 = versión
oficial.** Las anteriores pasan a `roms/Antiguas/`.

### Pregunta 1: ¿cuántas fuentes hay?

Medido buscando en la ROM entera los bitmaps conocidos de la `A`:

```
'A' de 8 B (1bpp)  -> 1 sola copia: 0x3D9E0
'A' de 16 B (2 pl) -> 1 sola copia: 0x4110
```

**Sólo hay DOS fuentes en todo el juego, y ninguna está desperdiciada:**

| | fuente DIÁLOGO | fuente MENÚ |
|---|---|---|
| base | `0x3D660` | `0x4000` |
| formato | 8 B/glifo, 1bpp | 16 B/glifo, cuerpo+sombra |
| glifos con dibujo | **247 de 256** | **234 de 256** |
| la usa | intro, error de Jizo, prompt del password, parrilla | rótulos del menú de dificultad |

**Respuesta a David: tu intuición es correcta.** La fuente del diálogo ya
es la fuente principal del juego. Verificado que la usan:

- la intro (v83);
- «¡El canto de Jizo no es correcto! / Revísalo bien e / inténtalo de
  nuevo.» — localizado en ROM **`0x1F836`**, decodificado con el charset
  oficial y coincide **literalmente** con la captura de David;
- «¡Introduce el canto de Jizo!» — localizado en ROM **`0x1F883`**;
- la parrilla de letras del password: en `0x1E040` se lee
  `HIJKLMN|OPQRSTU|VWXYZ|qrstu|vwxyz|áéíóú|üñÁÉÍ`, o sea **la parrilla y
  la intro comparten fuente y codificador**.

La fuente del menú es la excepción, y sólo la usan los rótulos de
dificultad. No hay fuentes «a medias» ni sobrantes.

### Pregunta 2: ¿sirve esta fuente para el guion, aldeanos y tiendas?

**Para dibujar, sí**: es la fuente principal y ya soporta 101 caracteres
(`charset_oficial.py`), con minúsculas, tildes, `¿ ¡ . , : ; ( ) % & …`.

**Pero el guion no está localizado, y ése es el problema real.**

### [HECHO] Los diálogos del juego NO están en texto plano

Barrido de los 512 KB buscando secuencias de kana (`0x01-0x3F`) de
longitud 12-60 terminadas en un código de control y con poca repetición
(criterio de «texto real»):

```
candidatos en TODA la ROM: 46
```

Cuarenta y seis para un juego entero con aldeanos, tiendas y guion. Es
demasiado poco: **el texto del juego no está almacenado en claro**.

Inspeccionados los bloques más densos en kana (`0x7A000` con 80 %,
`0x09000`, `0x10000`, `0x23000`): todos resultan ser **tilemaps**, con
patrones repetitivos del tipo `あいけこあいけこ#あいけこ`, no frases.

Encaja con lo que ya decía el diario original (entrada del 2026-08-02):
*«El código en banco 0 (0xE540-0xE5A0) que compone el SAT es código
comprimido»*. El juego usa compresión en varios sitios.

### [HIPÓTESIS] El guion está comprimido
No demostrado. Lo medido es que **no está en claro**; que esté comprimido
es la explicación más probable, pero hay que demostrarlo localizando la
rutina de descompresión y trazándola.

### Estado real de la tarea del guion

Lo que hace falta, en orden:

1. localizar la rutina que dibuja un bocadillo de aldeano (poner un
   watchpoint sobre la VRAM del bocadillo y ver quién escribe);
2. trazar hacia atrás de dónde saca los bytes;
3. si están comprimidos, identificar el algoritmo;
4. sólo entonces se puede pensar en traducir y en el cambio de vertical
   a horizontal.

**Nada de esto está documentado en ningún diario.** Ni en el mío ni en el
del chat original: la búsqueda de «aldean», «vertical», «tienda» y
«guion» en `investigation_chat_original.md` sólo devuelve la frase
*«El grueso del juego (guion, diálogos de aldeanos, tiendas) sigue sin
traducir»*. Es tarea nueva desde cero.

---

## (47) [HECHO] Descifrada la codificación japonesa. Localizado el bloque del tutorial

Con el log completo y el `.state` aportados por David.

### La tabla katakana es la IDENTIDAD

El renderer, para bytes `>= 0xA0`, usa la tabla `$9CF3` (modo 0) o
`$9CB3` (modo 1). Localizadas en el **banco `0x20`**:

```
$9CF3 = ROM 0x41CF3:  00 a1 a2 a3 a4 a5 a6 a7 a8 a9 aa ab ac ad ae af
                      b0 b1 b2 ... df          <- IDENTIDAD
$9CB3 = ROM 0x41CB3:  idéntica
```

`glifo = byte`. Eso **demuestra** por qué `charset_oficial.py` funciona:
no es una casualidad afortunada, es que la tabla no transforma nada.

### La codificación es JIS X 0201 (katakana de media anchura)

```
0xA1='。' 0xA2='「' 0xA3='」' 0xA4='、' 0xA5='・' 0xA6='ヲ'
0xA7-0xAF = ァィゥェォャュョッ      0xB0='ー'
0xB1-0xDD = アイウエオ...ワン       0xDE='゛' 0xDF='゜'
```

Los dakuten van como **carácter aparte** (`ケ` + `゛` = ゲ), lo que explica
las secuencias `B9 DE` del volcado.

Códigos de control adicionales medidos: `0x5C` (marca de énfasis/color,
la que me rompió el `!` en la v81), `0x3C` (espacio), `0x3D`/`0x5F`
(alargamiento `ー`), `0xFD` (wait), `0xFC` (page), `0xFE` (fin de página),
`0xFF` (fin), `0x00` (fin de línea).

### [HECHO] La intro japonesa original está en 0x1F5A5

Decodificada entera, y coincide literalmente con la traducción de David:

```
アクション ゲームガ ヘタナ ヒト コンニチハ
アクション ゲームガ ウマイ ヒト ドッ… ドウモ…
<FE> ドンナ ヒトデモ クリアデキル 「モモタロウカツゲキ」デス
...
```

Confirma que la intro que traducimos (`0x1FC5F`) es la reubicación de ese
texto, tal como cuenta el log.

### [HECHO] BLOQUE DEL TUTORIAL — el que David quiere traducir ahora

Localizado buscando `マス゛ハ` (`CF BD DE CA`):

```
ROM 0x1F2C7 - 0x1F365     159 bytes     4 páginas de 2 líneas
```

Texto original y traducción propuesta:

| | japonés | castellano |
|---|---|---|
| 1 | マズハ ゲームヲ タノシムタメノ / ジュンビ ウンドウヂャ! | Primero, ¡un calentamiento / para disfrutar del juego! |
| 2 | オチテクル ウンチヲ / ヨケルノヂャゾ! ウヒャヒャ! | ¡Esquiva las caquitas / que caen! ¡Ujujuy! |
| 3 | (Ⅱ)ボタンヲ オセバ ジャンプシテ / ヨケラレルコトニ ナットル! | ¡Pulsa el botón II para saltar / y esquivarlas! |
| 4 | ゴールメザシテ ミギニ ススメ! / ヨーイ! スタートヂャ! | ¡Ve a la derecha hacia la meta! / ¡Preparado! ¡Ya! |

Detalles medidos del bloque:
- cabecera `0x01` antes de la primera línea;
- separador de línea `0x00`, fin de página `0xFE`, dos `0xFD` (wait) al
  final de cada página — coincide con el avance automático que describe
  David;
- el byte `0x61` de la página 3 es el **glifo del botón II**;
- `0x5C` marca los términos destacados (ゲーム, クリア, ジャンプ…).

### [HECHO] No hay hueco detrás
En `0x1F366` empieza inmediatamente otro texto
(`オオ ヨクキタ モモタロウヨ!` — el diálogo del padre). Si la traducción
no cabe en 159 bytes hay que reubicarla, como se hizo con la intro.

### Sobre los diálogos de aldeanos
Con la codificación ya descifrada, ahora sí son localizables: basta buscar
las frases de las capturas de David en JIS X 0201. Tarea siguiente.

---

## (48) [HECHO] MAPA DEL GUION — dónde está cada texto del juego

Con la codificación JIS X 0201 descifrada, los textos aparecen buscando
las frases de las capturas de David. **No estaban comprimidos**: mi
barrido anterior fallaba porque buscaba hiragana (`0x01-0x3F`) cuando el
juego usa **katakana** (`0xA1-0xDF`).

> **[CORRECCIÓN a la entrada 46]** Dije que el guion «no está en claro» y
> lancé la hipótesis de que estuviera comprimido. **Falso.** Está en claro,
> en katakana. Busqué con el alfabeto equivocado. Otra vez el mismo error:
> no encontrar algo con un método no prueba que no exista.

### Zonas de texto localizadas

| ROM | contenido |
|---|---|
| `0x1F2C7-0x1F365` | **tutorial de 2 líneas** (el que se traduce ahora) |
| `0x1F366+` | escena de los padres: `オオ ヨクキタ モモタロウヨ!` |
| `0x1F079+` | más escenas con `モモタロウ` |
| `0x1F5A5` | intro japonesa original (ya reubicada a `0x1FC5F`) |
| `0x43740+` | **nombres del mapa**: `タビダチノ...`, `ハナサカ...` |
| `0x48470+` | **tiendas**: `イラッシャイ!`, `ブキ カッテイクト イイド!`, `オキニ メサナカッタ ヨウダナ!`, `マイドアリィ!`, `マタ キテクレヨナッ!` |
| `0x48CF0+` | **objetos y dinero**: `...ヲ テニ イレタ`, `モモタロウハ100$ヲ テニ イレタ` |
| `0x49213`, `0x4AF2F`, `0x4B0F7` | más nombres de aldeas |

El bloque `0x48000-0x49000` es el grueso del guion: tiendas, objetos y
mensajes de recompensa.

### Detalle útil
En la zona de tiendas el separador es `0xA0` (no `0x20`), y el símbolo de
moneda 両 se codifica como `$` (`0x24`). Habrá que respetarlo o
sustituirlo por un glifo propio.

---

## (49) [HECHO] v84 — bloque del tutorial traducido

Primer texto del **juego** traducido (hasta ahora sólo eran menús e intro).

### Delimitación exacta del bloque

```
ROM 0x1F2C9 - 0x1F365     157 bytes     4 páginas de 2 líneas
```

> **[CORRECCIÓN]** En la entrada (47) dije `0x1F2C7`. Son dos bytes antes
> de la cabecera: `c9 52` pertenecen al dato anterior. La cabecera `0x01`
> está en **`0x1F2C9`**. Lo detectó la verificación del constructor, que
> aborta si el primer byte no es `0x01`.

### [HECHO] Límite de ancho: 18 celdas

Medido de dos formas independientes:

1. **Contando celdas del original**: los dakuten (`゛ ゜`) se dibujan
   pegados al kana anterior y **no ocupan celda**. Descontándolos, la línea
   más larga del bloque japonés usa **18 celdas**.
2. **Midiendo la captura de David** (256×240, tamaño real): el paso entre
   caracteres es de **8 px exactos**, el texto empieza en x=64 y el
   interior del bocadillo llega a x=196.

También medido: el bocadillo del tutorial es de los grandes (138 px de
ancho interior, 40 px de alto), y **cada bocadillo del juego tiene su
propio tamaño** — el de los aldeanos mide 46 px de ancho y el de los
padres 128.

### [DESCARTADO] «el byte 0x61 es el glifo del botón II»

Lo supuse al ver que la página 3 del original empieza por `0x61` justo
antes de `ボタン`. **Falso.** `0x61` va por la ruta de la **tabla**
(idx `0x31`) y da el glifo `0xDF`, que es una rayita diagonal.

El icono del botón que se ve en la captura de David no es un carácter del
texto: lo dibuja el propio bocadillo como gráfico. Se escribe «II» con
letras normales.

### Traducción (revisada por David)

```
pág1  ¡Primero, un poco / de calentamiento!
pág2  ¡Esquiva los / ñordos! ¡Ujujuy!
pág3  ¡Pulsa II y salta / para esquivarlos!
pág4  ¡Ve hacia la / derecha, a la meta
```

Decisiones suyas: `ウンチ` -> «ñordos» (sin diminutivos), y «ve **hacia**
la derecha».

### Entrega

```
test_tutorial_v84.pce
  MD5    06b51246e5e3a69aacd4fd939e858432
  SHA-1  0db076cb78f6be0f29906dcee225665235812735
  CRC32  6ef7ca99
momotaro_tutorial_v84.ips   180 B, verificado
```

**143 B de 157: cabe en su sitio.** No hay que reubicar nada ni tocar
punteros; el sobrante se rellena con `0xFF`.

Verificado por el constructor, que aborta si falla:
- el bloque empieza por `0x01` y contiene `マズハ` (es el correcto);
- tabla `0x43F9B` y fuente **intactas**;
- los 152 bytes modificados están **todos dentro del bloque**;
- texto de la intro intacto;
- diálogo del padre (`0x1F366`, pegado detrás) intacto.

---

## (50) [CORRECCIÓN] El ancho real es 16, no 18. v85

David prueba la v84: **el texto se corta** en tres de las cuatro páginas
(«un poc», «salt», «esquiva», «la me»).

### [ERROR MÍO] Conté mal el ancho

En la entrada (49) dije 18 celdas. **Son 16.** El fallo: medí el bloque
desde `0x1F2C7`, y los dos primeros bytes (`c9 52`) no son texto sino
datos del bloque anterior. Al contarlos como caracteres, la línea 1 me
salía de 18 en vez de 16.

Verificado contra la captura de la v84: «¡Primero, un poc» son exactamente
**16 celdas visibles** y la 17 se corta a mitad.

Y verificado también sobre el original, midiendo desde `0x1F2C9`:

```
línea 1: 16   マズハ ゲームヲ タノシムタメノ
línea 5: 16   ボタンヲ オセバ ジャンプシテ
línea 7: 16   ゴールメザシテ ミギニ ススメ!
```

Ninguna línea del juego pasa de 16. Es el ancho del bocadillo.

### [HECHO] El bocadillo NO se ensancha solo

Medidos los dos bocadillos, el japonés original y el de la v84: **ambos
x=59-196, 138 px**. El bocadillo es de tamaño fijo y el texto se corta al
llegar a su borde; no hay auto-ajuste.

### [HECHO] Sí caben 3 líneas

- El motor admite hasta **4 líneas** por página (`CMP #$04` en `$D1A6`).
- La tabla de posiciones Y (`$D2BB`) tiene entradas válidas para 4:
  `$7008 $7308 $7608 $7908`, separadas `0x300` (una fila de tiles).
- El bocadillo mide 40 px de alto y con 2 líneas sólo usa 23.

Así que se pasa a **3 líneas** en las páginas que lo necesitan, que da
más margen que pelear por el ancho.

### v85

```
pág1  ¡Primero, algo / de calentamiento / para el juego!
pág2  ¡Esquiva los / ñordos! ¡Ujujuy!
pág3  ¡Pulsa II y salta / para esquivar!
pág4  ¡Ve hacia la / derecha, hasta / la meta!
```

Se recupera el «para el juego!» (el `タノシムタメノ` que se había perdido).

```
test_tutorial_v85.pce
  MD5    8ccc57b243c53e25fc0dddc146e0155d
  SHA-1  7aa8833a8917ec1d19cdd376eef939eb44632ee1
  CRC32  e5b5c8b1
momotaro_tutorial_v85.ips   176 B, verificado
```

**156 B de 157: cabe por un byte.** Sin reubicar.

### [PENDIENTE] Ampliar el bocadillo

David pide ampliarlo para ser más fieles. No lo he conseguido todavía:

- el log documenta el precedente del prompt de Jizo, que se amplió
  editando un **stream de bocadillo** con campos `left/right/top/bottom`
  en tiles (entrada del log, línea 17541), reubicado a `0x1F970`;
- busqué un stream equivalente para el tutorial (valores ~7/24/6/11) en
  `0x1E000-0x1F000` y **no aparece**;
- la tabla de punteros que creí encontrar en `0x39CE` resultó ser código
  que casa por casualidad, no punteros.

Es tarea propia y hay que hacerla con el emulador: poner un watchpoint
sobre la escritura del marco del bocadillo y ver qué rutina lo dibuja.
**No se toca hasta medirlo.**

---

## (51) [ERROR MÍO] La tercera línea NO cabe. v86 con más páginas

David prueba la v85: sigue habiendo frases cortadas y **la tercera línea
queda fuera del bocadillo**.

### Por qué falló

Razoné así: el bocadillo mide 40 px de alto, dos líneas ocupan 23, luego
cabe una tercera. **Mal.** Lo que no medí fue la **separación real entre
líneas**:

```
línea 1 en y=61
línea 2 en y=77   -> separación de 16 px
línea 3 caería en y=93
bocadillo: y=52-91
```

La tercera línea cae **2 px por debajo del borde inferior**. La separación
es de 16 px, no de los ~11 que yo suponía al dividir 23 entre 2.

Y lo peor del método: **no lo verifiqué en pantalla antes de entregar**.
Tenía la separación medida en la captura desde el principio (entrada 47:
«línea 1 y=61-67, línea 2 y=74-83») y no hice la resta.

> **Norma 22: el alto disponible no se deduce del alto de la caja, sino de
> la SEPARACIÓN entre líneas por el número de líneas.**

### [HECHO] No hay límite de páginas — la idea de David funciona

Desensamblado el manejador de `0xFE` (`$D1C7`, ROM `0x1B1C7`):

```
$D1C7: 20 a0 d1   JSR $D1A0     ; tratar como fin de línea
$D1CA: a9 01      LDA #$01
$D1CC: 8d e7 3c   STA $3CE7     ; marca "esperar"
$D1CF: a9 80      LDA #$80
$D1D1: 0c e4 3c   TSB $3CE4
$D1D4: 60         RTS
```

**No hay contador de páginas**, igual que en la intro. Se pueden añadir
todas las que hagan falta. La sugerencia de David es la solución correcta.

### El presupuesto real de bytes

El bloque tiene 157 B y cada página cuesta 4 bytes de control
(`0x00` + `FD FD` + `FE`). Medido:

```
4 páginas -> 140 caracteres de texto
6 páginas -> 132
8 páginas -> 124
```

Y el texto plenamente fiel («…para disfrutar del juego», «¡Preparado,
ya!»…) son **185 caracteres**. No cabe de ninguna manera sin reubicar el
bloque: más páginas dan más *espacio vertical*, pero **cuestan** bytes.

### v86 — 6 páginas de 2 líneas

```
pág1  ¡Primero, algo / de calentamiento
pág2  ¡Esquiva los / ñordos! ¡Ujujuy!
pág3  ¡Pulsa II para / saltar y evitar
pág4  los ñordos!
pág5  ¡Ve hacia la / derecha, a la
pág6  meta! ¡Ya!
```

Se recupera «¡Ya!» (el `ヨーイ! スタートヂャ!` del original) y ninguna
línea pasa de 16 celdas. Verificado leyendo la ROM construida:

```
pág1: 14, 16   pág2: 12, 16   pág3: 14, 15
pág4: 11       pág5: 12, 13   pág6: 10
```

```
test_tutorial_v86.pce
  MD5    81cf6ffcb1bbd275aa735f3004261fea
  SHA-1  53f30b13dafbcc4d24e5bded1120c53eeb3aba17
  CRC32  eac65926
momotaro_tutorial_v86.ips   180 B, verificado
```

**156 B de 157.** Sin reubicar, sin tocar tabla ni fuente.

### Para ser más fieles hay dos vías, y ambas son tarea propia
1. **Reubicar el bloque** a los 343 B libres de `0x1FEA8-0x20000`, como se
   hizo con la intro. Requiere localizar el puntero que lo referencia — que
   en la intro resultó construirse en runtime y costó un breakpoint.
2. **Ampliar el bocadillo**, que sigue pendiente (entrada 50).

---

## (52) [HECHO] v87 — BOCADILLO AMPLIADO. Descifrado el formato del marco

David pide ir a por todas: ampliar el bocadillo en vez de seguir
recortando texto. Hecho.

### El stream del bocadillo, descifrado

La tabla de bocadillos está en `$C499` (ROM **0x1A499**), 8 entradas:

```
modo 0 -> $407A -> ROM 0x1E07A   14 tiles de ancho
modo 1 -> $40C5 -> ROM 0x1E0C5
modo 2 -> $40D1 -> ROM 0x1E0D1   16 tiles  <- EL DEL TUTORIAL
modo 3 -> $410C -> ROM 0x1E10C
modo 4 -> $4118 -> ROM 0x1E118   24 tiles
modo 5 -> $4180 -> ROM 0x1E180
```

Identificado el modo 2 como el del tutorial porque describe tiles 8-23
(x = 64-191 px), y la captura de David mide el bocadillo en x=59-196.

**Formato:** `FF nn tile` = **nn+1** copias del tile (el off-by-one que ya
documentaba el diario original); cualquier otro byte es un tile literal.
El stream describe el tilemap entero, con **32 tiles por fila**.

**Tiles del marco:**
```
01 esquina sup-izq   02 borde superior   03 esquina sup-der
04 lateral izq       09 relleno          05 lateral der
06 esquina inf-izq   07 borde inferior   08 esquina inf-der
0e 0f = el rabito que apunta al personaje
10 11 = la flechita de "continuar"
```

Distribución original del modo 2:
```
fila 11:  8x00  01 02*14 03  8x00
filas 12-14:  8x00  04 09*14 05  8x00
fila 15:  8x00  06 07*6 0e 0f 07*6 08  8x00
```

### El ensanchado

Se pasa de 16 a **20 tiles de ancho**, quitando 2 tiles de relleno vacío
por cada lado para que la fila siga sumando 32 y el bocadillo siga
centrado. El rabito se recoloca en el centro.

```
fila 11:  6x00  01 02*18 03  6x00
filas 12-14:  6x00  04 09*18 05  6x00
fila 15:  6x00  06 07*8 0e 0f 07*8 08  6x00
```

**El stream nuevo ocupa 59 bytes, exactamente los mismos que el
original.** No hay que reubicar nada.

Verificado leyendo la ROM construida: tiles 6-25, x=48-207 px,
**18 celdas de texto** útiles (20 tiles menos las dos esquinas).

### v87 — texto completo y fiel

```
pág1  ¡Primero, un poco de / calentamiento!
pág2  ¡Esquiva los ñordos / que caen! ¡Ujujuy!
pág3  ¡Pulsa II y salta / para esquivarlos!
pág4  ¡Ve hacia la derecha / hasta la meta!
```

Correcciones de David aplicadas: **punto final** tras «calentamiento» y
«**hasta** la meta» en vez de «a la meta». Se recupera además el
«¡Ujujuy!» y el «que caen» completos.

Vuelve a 4 páginas de 2 líneas, como el original japonés.

```
test_tutorial_v87.pce
  MD5    8da4a303d52d853e5fec41446f3f8a55
  SHA-1  8b35d6cb34b9968692bd7adc56ce6fe9f46b4736
  CRC32  cb6254d2
momotaro_tutorial_v87.ips   260 B, verificado
```

156 B de 157 en el texto; el stream del bocadillo, 59 de 59.

Verificado por el constructor: tabla `0x43F9B` y fuente intactas, cada
fila del tilemap suma 32 tiles, y los únicos bytes modificados están en
el bloque de texto y en el stream del bocadillo.

### [PENDIENTE de comprobar en pantalla]
El límite de 18 celdas es **deducido** del ancho del marco, no medido en
pantalla. Si el motor sigue cortando a 16 por otra causa (un contador
propio), habrá que buscarlo. Que lo diga la captura de David.

---

## (53) [DESCARTADO] Ampliar el modo 2 no era el bocadillo del tutorial

David prueba la v87: **el bocadillo NO se ha ampliado** y el texto sigue
cortando en 16.

### Prueba

Medidas las capturas de la v83 (japonés) y de la v87: **ambas x=59-196,
138 px, contorno negro en x=61-194**. Idénticas. Y el cambio SÍ está en la
ROM (comprobado el stream `0x1E0D1`, distinto entre v83 y v87).

**Conclusión: el modo 2 de la tabla `$C499` no es el bocadillo del
tutorial.** Lo identifiqué por descarte, viendo que era el único de 16
tiles, y me equivoqué: ninguno de los 8 modos mide los 18 tiles del
bocadillo real (x=59-196 = tiles 7.4-24.5).

> Error de método: identifiqué el stream por **coincidencia de tamaño**,
> no trazando qué rutina dibuja ese bocadillo concreto. Cuando dos cosas
> tienen medidas parecidas no basta con que encajen; hay que seguir la
> ejecución.

El cambio se revierte. El stream `0x1E0D1` vuelve a su valor original.

### [HECHO] El límite de 16 lo impone el MOTOR, no el marco

Esto sí queda demostrado por la propia prueba fallida: se ensanchó un
marco y **el texto siguió cortando en el mismo sitio**. Si el límite fuera
el ancho del dibujo, habría cambiado.

### [HECHO] Qué hace el motor al pasar de 16

No trunca: hace **auto-wrap** y manda el sobrante a la línea de abajo,
que acto seguido es sobrescrita por la línea siguiente del guion. Es
exactamente lo que David observa y lo que el log ya documentaba para el
error de Jizo (líneas 2901 y 16000):

> «el texto se dibuja físicamente en más líneas, pero la rutina sigue
> creyendo que la segunda frase empieza en la línea 2, así que la
> sobrescribe»

### [HECHO] Hallazgos del desensamblado de esta ronda

Aunque el ensanchado falló, se ha mapeado el motor de dibujo:

```
$AA38  dibuja un carácter
  $AA50  JSR $D720   -> dibuja de verdad
  $AA5B  JSR $AA8C   -> ¿está en la lista de control $AAA3?
  $AA5E  BCS         -> si NO, salta el tratamiento especial

$D720  ($D6BF dibuja, luego INC $C3 / INC $C4 = contadores de columna)
  $D73F  gestiona los dakuten ゛゜ (CMP #$DE / CMP #$DF)
  $AB91  gestiona 0x01, 0x02 y 0x5C
  $AAB4  calcula la dirección del glifo

$AB91:  CMP #$5C / BEQ -> LDA $3BA6 / EOR #$01 / STA $3BA6
```

**`0x5C` alterna el MODO DE FUENTE**, no es un separador. Conmuta `$3BA6`
entre 0 y 1, que selecciona entre las dos tablas de glifos (`$9CF3` y
`$9CB3`) de la tabla de punteros `$ABAF`. Por eso el original lo pone
delante de `ゲーム`, `クリア`, `ジャンプ`: son los términos destacados.

`$AB34` es una **tabla de sustitución** de caracteres anchos:
```
20->3C   21->5C   2D->5F   B0->5F   A2->5B   A3->5D   24->3E
```

### v88 — versión funcional mientras tanto

```
pág1  ¡Primero, algo / de calentamiento
pág2  ¡Esquiva los / ñordos que caen!
pág3  ¡Ujujuy! ¡Pulsa / II y salta para
pág4  esquivarlos! / ¡Ve hacia la
pág5  derecha, hasta / la meta!
```

Ninguna línea pasa de 16 celdas. 155 B de 157.

```
test_tutorial_v88.pce
  MD5    3ba2390b2aaf0968384933ea1a74dbe5
  SHA-1  6aea8865b84d6260140c278434224a9e3a122f4d
  CRC32  8eed973b
momotaro_tutorial_v88.ips   180 B, verificado
```

### [PENDIENTE] Lo que David pide: desbordar por la derecha

Su propuesta es la correcta: que el texto **no salte de línea**, sino que
se desborde por la derecha, y después ya se centra y se amplía el marco.

Para eso hay que localizar el punto exacto donde el motor decide el salto
de línea. No está en el banco `0x0D` (buscadas todas las comparaciones con
valores 0x0E-0x1C: sólo aparece un `CMP #$18` en `$D681`, que es de otra
rutina). Probablemente esté en la rutina de escritura a VRAM, comparando
la dirección de destino contra el final de la fila.

**Necesita el emulador**: watchpoint sobre `$C3`/`$C4` (los contadores de
columna) para ver quién los compara y dónde se decide el salto.

---

## (54) [HECHO] CAUSA RAÍZ del corte: no hay contador, es la dirección VRAM

Con el dato de David (el breakpoint de `$C3` salta en la rutina de
`$E17C`) se ha desensamblado el motor completo. `$E17C` resultó ser el
bucle de espera de vblank, pero tirando del hilo se llegó a lo importante.

### El mecanismo real

```
$AA38  (dibujar un carácter)
  $AA48: LDA $C1 / STA $16      ; cursor -> puntero de destino
  $AA4C: LDA $C2 / STA $17
  $AA50: JSR $D720              ; DIBUJA y AVANZA $16/$17
  $AA53: LDA $16 / STA $C1      ; guarda el cursor avanzado
  $AA57: LDA $17 / STA $C2
```

**`$C1`/`$C2` no es un contador de columna: es la DIRECCIÓN de VRAM del
cursor**, de 16 bits. Comprobado que en toda la ROM sólo se le hace `STA`
(desde la tabla de posiciones de línea `$D2BB`) y nunca `INC`.

Por eso el texto «se corta» a los 16 caracteres: la dirección llega al
final de la fila del tilemap y **sigue escribiendo en la fila siguiente**,
que es justo lo que David ve. No hay ningún `CMP` que se pueda subir.

`$C3`/`$C4` (los que sí se incrementan en `$D737`) son contadores
auxiliares que esta ruta **no compara con nada**.

### Las tres rutinas de dibujo del juego

| rutina | contador | límite | la usa |
|---|---|---|---|
| `$D619` | `$C3` | ninguno (hasta `0x00`) | ? |
| `$D649` | `$3BB4` | **`CMP #$18`** en `$D681` (24) | ? |
| `$D686` | `$3B52` | ninguno | `$D932` |
| `$D720` | `$C3`,`$C4` | **ninguno** | **el tutorial y la intro** (vía `$AA38`) |

El tutorial llega por `$D175` -> `$AA38` -> `$D720`, la única sin límite.

> Interesante: `$D649` **sí** tiene un límite de 24 caracteres por línea.
> Si se pudiera encaminar el diálogo por esa rutina, habría 24 celdas en
> vez de 16. No investigado.

### Por qué el marco no importaba

Queda explicado el fallo de la v87: el bocadillo es un dibujo de fondo y
el texto se escribe en el tilemap por dirección absoluta. Ensanchar el
marco no cambia dónde acaba la fila del tilemap.

### Lo que haría falta para «desbordar por la derecha»

No se puede subir una constante: habría que **modificar `$D720`** para que
al avanzar el cursor no se pase de fila, o reservar en VRAM una zona de
texto más ancha. Es cirugía sobre el motor, no un cambio de dato.

Alternativa más barata: **encaminar el diálogo por `$D649`** (24 celdas).
Habría que comprobar antes qué más hace esa rutina.

## (55) [AVISO] Mesen muestra la intro corrupta y Beetle no

David reporta que en **Mesen** el texto de la intro se ve como basura,
mientras que en **Beetle PCE** se ve perfecto.

**No está diagnosticado.** Hipótesis a comprobar, por orden:

1. Mesen emula distinto el mapeo de bancos (`TAM`) o el timing de escritura
   a VRAM durante el vblank.
2. Mesen carga un `.sav`/estado previo que ensucia la RAM.
3. La ROM depende de un estado inicial de VRAM que Beetle deja de una
   forma y Mesen de otra.

**Importa**: si el fallo fuera de la ROM y no del emulador, sería un bug
real que Beetle disimula. Conviene resolverlo antes de publicar nada.
Pedir a David una captura de Mesen de la ROM **japonesa original** sin
parchear: si también se ve mal, es cosa de Mesen y no nuestra.

---

## (56) [HECHO] CAUSA del fallo en Mesen: la ruta katakana NO mapea su banco

Datos de David, que acotan el problema con precisión:

```
ROM japonesa original  -> Mesen: BIEN
v82 (mayúsculas)       -> Mesen: BIEN
v83 (minúsculas)       -> Mesen: MAL
```

### Qué cambió entre v82 y v83

Medido sobre el texto de ambas:

```
v82:   0 caracteres por ruta KATAKANA, 553 por ruta TABLA
v83: 421 caracteres por ruta KATAKANA, 134 por ruta TABLA
```

**La v82 no usaba la ruta katakana ni una sola vez.** La v83 la usa 421
veces, porque es la única por la que se alcanzan las minúsculas.

### El bug, en el código

`$AAB4`, la ruta katakana:

```
$AABD: e9 a0      SBC #$A0        ; idx = byte - 0xA0
$AABF: a8         TAY
$AAC0: ad a6 3b   LDA $3BA6       ; modo de fuente
$AAC3: 0a aa      ASL A / TAX
$AAC5: bd af ab   LDA $ABAF,X     ; puntero a la tabla ($9CF3 o $9CB3)
$AAC8: 85 14      STA $14
$AACA: bd b0 ab   LDA $ABB0,X
$AACD: 85 15      STA $15
$AACF: b1 14      LDA ($14),Y     ; <<< LEE SIN MAPEAR EL BANCO
```

La tabla `$9CF3` vive en la ventana `$8000-$9FFF` (MPR4) y está en el
**banco 0x20**. La rutina **no hace `TAM`**: da por supuesto que el banco
correcto ya está mapeado.

Compárese con la ruta de tabla, que sí lo hace (`$AAEA`: `LDA #$1E / CLC /
ADC $20 / TAM #$04`).

**Es un bug latente del juego original**, no un fallo de nuestro parche:
el juego japonés nunca llega a esa ruta desde este punto del programa, así
que nunca se manifestó. Beetle deja en MPR4 un banco que resulta ser el
correcto; Mesen deja otro.

> Esto responde a la pregunta importante: **no es un capricho de Mesen**.
> Es una dependencia real de estado no inicializado. En hardware real
> podría fallar, así que hay que arreglarlo antes de publicar.

### [DESCARTADO] «el trampolín $E37B es el culpable»
Los bytes de control (`0x20`, `0x21`, `0x5B`, `0x5D`, `0x5E`) disparan
`JSR $E37B`, que remapea cuatro bancos. Parecía sospechoso, pero **la v82
ya lo llamaba 75 veces y se ve bien**. Descartado.

### [DESCARTADO] «evitar la ruta katakana usando códigos de tabla»
Comprobado carácter a carácter: de las 26 minúsculas y los acentos,
**sólo la `o` tiene un código de tabla libre** (`0x62`). El resto no es
alcanzable por esa vía. No hay forma de escribir minúsculas sin pasar por
la ruta katakana.

### La solución: insertar el `TAM` que falta

Hay que meter en `$AAB4`, antes del `LDA ($14),Y`:

```
a9 20      LDA #$20
18         CLC
65 20      ADC $20
53 10      TAM #$10      ; banco 0x20 en MPR4 ($8000-$9FFF)
```

Son 7 bytes que no caben en el hueco actual: hay que reubicar la rutina o
saltar a un trampolín. **Es cirugía sobre el motor y no se toca sin
medirlo bien.** Queda como la siguiente tarea seria.

Mientras tanto la v83/v89 funcionan en Beetle, que es el emulador que usa
David, pero **no deben publicarse** hasta arreglar esto.

## (57) v89 — punto final tras «calentar»

David reporta que faltaba el punto. Con el límite de 16 celdas no cabe
«de calentamiento.» (17), así que se abrevia a «de calentar.» (12).

```
pág1  ¡Primero, algo / de calentar.
pág2  ¡Esquiva los / ñordos que caen!
pág3  ¡Ujujuy! ¡Pulsa / II y salta para
pág4  esquivarlos! / ¡Ve hacia la
pág5  derecha, hasta / la meta!
```

```
test_tutorial_v89.pce
  MD5    22d16ea742528dbf74f4d108a83c7341
  SHA-1  71f436c1b65f20132fb077801e26eff42e7d0391
  CRC32  435657e8
momotaro_tutorial_v89.ips   172 B, verificado
```

151 B de 157.

---

## (58) [HECHO] v90 — ARREGLADO el bug de banco de la ruta katakana

Primer parche de esta rama que **modifica código**, no datos.

### El arreglo

En `$AAC8` (9 bytes, de `$AAC8` a `$AAD0`):

```
85 14        STA $14           igual que el original
bd b0 ab     LDA $ABB0,X       igual que el original
20 58 df     JSR $DF58         <- sustituye STA $15 + LDA ($14),Y
ea           NOP               relleno
```

Trampolín en `$DF58` (22 bytes de los 168 libres del banco 0x0C):

```
85 15        STA $15           lo que hacía $AACD
43 10        TMA #$10          A = banco actual de MPR4
48           PHA               guardarlo
a9 20        LDA #$20          banco 0x20
18           CLC
65 20        ADC $20           + base del juego
53 10        TAM #$10          mapear en $8000-$9FFF
b1 14        LDA ($14),Y       LA LECTURA, ya con el banco bueno
85 13        STA $13           valor -> temporal
68           PLA               A = banco original
53 10        TAM #$10          restaurar MPR4
a5 13        LDA $13           A = valor leído
60           RTS
```

### Por qué el banco 0x0C

`$AA38` mapea el banco 0x0C en MPR6 (`$C000-$DFFF`) antes de todo el
dibujado (`LDA #$0C / CLC / ADC $20 / TAM #$40`), así que `$DF58` es
alcanzable con un `JSR` normal durante toda la rutina.

El hueco `0x19F58-0x1A000` está verificado a `0xFF`. Hay 6 direcciones de
ese rango referenciadas desde otros sitios (`$DF66`, `$DF90`, `$DF9C`,
`$DFDA`, `$DFDE`, `$DFF2`), pero apuntan a **otros bancos** que se mapean
en la misma ventana: comprobado una a una que en el banco 0x0C son `0xFF`.

### Análisis de registros

- **Y** (índice en la tabla): `TMA`, `PHA`, `PLA`, `TAM` no lo tocan.
- **X** (modo de fuente × 2): **sigue vivo**, porque `$AAF2` hace
  `LDA $AB09,X`. Por eso NO se usa `TAX` para guardar el valor, que era
  la solución obvia y habría roto el renderizado.
- **A**: se devuelve con el valor leído, como espera `$AAD1: JSR $AAF2`.
- **`$13`**: comprobado que en los tres bancos implicados sólo la tocan el
  propio trampolín y dos rutinas ajenas al dibujado (`$C365`, `$CBF4`).

### El patrón es el del propio juego

`$E5C1` hace exactamente lo mismo: `TMA #$10 / PHA … LDA #$20 / CLC /
ADC $20 / TAM #$10 … PLA / TAM #$10`. Confirma que 0x20 es el banco
correcto y que hay que sumarle la base `$20`.

### Verificaciones del constructor (aborta si falla)

- el código de `$AAC8` es exactamente el esperado antes de tocarlo;
- el hueco del trampolín está **todo a 0xFF**;
- `$AA38` sigue mapeando el banco 0x0C en MPR6;
- la tabla `$9CF3` está en el banco 0x20 (comprobado su contenido);
- el `JSR` escrito apunta exactamente al trampolín;
- el trampolín acaba en `RTS`;
- los dos `TAM` son ambos `#$10` (simétricos);
- hay **un** `PHA` y **un** `PLA`: la pila queda equilibrada;
- sólo cambian 26 bytes, todos dentro del parche y el trampolín;
- textos, tabla ASCII y fuente **intactos**.

### Entrega

```
test_tam_v90.pce
  MD5    2177a676a7f3ad18221df927607f8718
  SHA-1  c5c950bb521037d17aa607bd612ce6ed4dff86ac
  CRC32  d792d92c
momotaro_tam_v90.ips   44 B, 2 tramos, verificado
```

26 bytes modificados en total.

### Lo que hay que comprobar en pantalla
1. **En Mesen**: que la intro y el tutorial se vean bien (era el objetivo).
2. **En Beetle**: que NO se haya roto nada (el parche cambia el banco
   mapeado en MPR4 durante un instante).
3. Que el resto del juego siga igual: menús, password, mapa.

---

## (59) [DESCARTADO como causa] El parche TAM no arregla el fallo de Mesen

David prueba la v90: **Beetle bien, Mesen sigue mal**.

### Qué significa

Dos conclusiones separadas:

1. **El parche TAM es correcto y no rompe nada.** Beetle sigue perfecto
   tras modificar código, mapear un banco y restaurarlo. La cirugía está
   bien hecha.
2. **Pero el bug del banco NO era la causa** del fallo de Mesen. El
   diagnóstico de la entrada (56) era plausible y estaba bien medido —la
   ruta katakana efectivamente lee sin mapear— pero no es lo que provoca
   lo que David ve.

> Es el error de razonamiento clásico: encontré *un* bug real en la ruta
> que la v83 estrena, y di por hecho que era *el* bug. Correlación no es
> causa: que la v83 sea la primera en usar esa ruta no demuestra que el
> fallo venga de ahí.

### Lo comprobado en esta ronda

- El parche está bien escrito en la ROM (`$AAC8` y `$DF58` verificados).
- La ruta es la correcta: `$D731: JSR $AAB4`, dentro de `$D720`.
- La v83 **no** modificó la fuente: los glifos `0xE8`-`0xFD` vuelven a su
  valor de la v72 (los que cambiaban eran de la v82).
- Índices de la tabla katakana: el máximo que genera el texto es `0x5E`,
  que corresponde al byte `0xFE`... pero `0xFE` es **fin de página** y el
  motor lo intercepta antes de llegar a la tabla. **Descartado** como
  desbordamiento.

### Diferencia real entre v82 (OK) y v90 (mal)

```
sólo en v90:  21 5B 5D 5E   (bytes de la lista de control $AAA3)
              A1 A4 A5 A6 A7 A8 A9 AA AC AD AE AF B1 B2 B3 B4 B5 B6
              B8 B9 BB BC BE CA CB CC D1   (ruta katakana)
```

### Dos ROMs de diagnóstico

Preparadas en `roms/Diagnostico/` para separar las hipótesis:

**`DIAG_v90_texto82.pce`** (MD5 `2173218bb267d9d75ce7d678db2dc9cb`)
La v90 con el parche TAM puesto, pero con el texto de la v82 (mayúsculas).
- si va **bien** en Mesen -> la causa está en los bytes del texto nuevo y
  el parche no molesta;
- si va **mal** -> la causa es el propio parche TAM y hay que revertirlo.

Es la prueba que más separa las hipótesis.

**`DIAG_v90_p_directa.pce`** (MD5 `5070361c418c69cb4fc19bf9d11c2540`)
La `p` con su byte directo `0xB0` en vez del alias `0x5E`, que es de
control y dispara `JSR $E37B` (remapeo de cuatro bancos) una vez por
letra. Quita 10 de esas llamadas.
- si mejora -> la causa está en `$E37B` / la lista de control;
- si sigue igual -> descartado.

### Estado del parche TAM
**Se mantiene de momento.** Arregla un bug real y demostrado, no rompe
nada en Beetle, y la prueba 1 dirá si hay que revertirlo.

---

## (60) [RESUELTO] La causa real: `$3BA6` sin inicializar. v91

La pregunta de David lo resolvió: **«¿por qué falla el de la introducción
y no el de los ñordos?»** Ambos usan minúsculas y la misma ruta, así que
la codificación no podía ser la culpable. Tenía que ser el **estado** con
el que arranca cada pantalla.

### Resultados de las pruebas de diagnóstico

```
DIAG_v90_texto82.pce (parche TAM + texto en mayúsculas) -> Mesen BIEN
DIAG_v90_p_directa.pce (quitando 10 llamadas a $E37B)   -> Mesen MAL
```

La primera **exculpa al parche TAM**: con él puesto y texto de mayúsculas,
Mesen va bien. La segunda **descarta** el trampolín `$E37B` y la lista de
control.

### La causa

`$3BA6` es el **modo de fuente**: elige cuál de las dos tablas de glifos
usa la ruta katakana.

```
$AAC0: ad a6 3b   LDA $3BA6
$AAC3: 0a aa      ASL A / TAX
$AAC5: bd af ab   LDA $ABAF,X

  $3BA6=0 -> $9CF3   correcta
  $3BA6=1 -> $9CB3   correcta
  $3BA6>1 -> $F8AE, $BD37, $ABBD, $B68D...  BASURA
```

La rutina de arranque de la intro (`$D113`) inicializa `$BF/$C0`,
`$C1/$C2`, `$C3`, `$3CE3`, `$3CE9`, `$3CE4`, `$3CE7` y `$3CE6`...
**pero no `$3BA6`**.

### Por qué cada caso se comportaba como lo hacía

| caso | por qué |
|---|---|
| tutorial (ñordos) OK | pasa por `$D649`, que empieza con `STZ $3BA6` |
| v82 (mayúsculas) OK | ruta de tabla (`$AB1B`), que **no** consulta `$3BA6` |
| v83 (minúsculas) MAL | ruta katakana, que **sí** depende de `$3BA6` |
| Beetle OK | deja esa RAM con un valor que resulta ser 0 o 1 |
| Mesen MAL | la deja con otro |

Otro bug latente del original, del mismo tipo que el del `TAM`: el
japonés de la intro nunca usaba la ruta katakana desde ese punto.

### El arreglo: 3 bytes, sin trampolín

En `$D141` hay un `LDA $3CE6` **redundante**, justo detrás de un
`STA $3CE6`: A ya contiene ese valor.

```
$D13C: a9 04      LDA #$04
$D13E: 8d e6 3c   STA $3CE6
$D141: ad e6 3c   LDA $3CE6     <- redundante
$D144: 8d e5 3c   STA $3CE5
$D147: 60         RTS
```

Se sustituye por `STZ $3BA6` (`9c a6 3b`), que **no modifica A**, así que
el `STA $3CE5` siguiente sigue guardando `$04`.

Verificado antes de escribir:
- `$D13E` hace `STA $3CE6` justo antes (la carga es redundante);
- `$D144` hace `STA $3CE5`, que usa A, y `STZ` no la toca;
- **0 saltos absolutos y 0 ramas relativas** caen en `$D141`-`$D143`;
- la entrada 0 de `$ABAF` apunta a `$9CF3`, así que poner `$3BA6` a cero
  es exactamente lo correcto.

### Entrega

```
test_modo_v91.pce
  MD5    68758323d73740083c97b805acb5bb4a
  SHA-1  7f76364338be47d288fa84729e2d4c3868f07b28
  CRC32  97f3fef3
momotaro_modo_v91.ips   16 B, verificado
```

**3 bytes modificados.**

### Sobre el parche TAM de la v90
Se mantiene. La prueba de diagnóstico demostró que no era la causa de
esto, pero arregla un bug real y demostrado (la ruta katakana leía sin
mapear su banco) y no rompe nada. Es corrección defensiva legítima.

---

## (61) [RESUELTO] El reset al entrar en CONTINUAR: el parche TAM. v92

### El síntoma

David: «el botón de continuar nos devuelve a la pantalla de título como un
reset [...] ese problema se arrastra desde la v90. En la 89 sí podías
entrar en CARGAR.»

Su bisección apunta a la **v90**, no a la v91. Yo había empezado a
investigar la v91 por ser la última. Me corrigió a tiempo.

### La causa: trampolín en la ventana MPR equivocada

El parche TAM de la v90 sustituyó en ROM `0x42ACD` (banco `0x21`, `$AACD`):

```
85 15 b1 14      STA $15 / LDA ($14),Y     <- original
20 58 df ea      JSR $DF58 / NOP           <- parche v90
```

`$DF58` cae en la ventana **MPR6 (`$C000-$DFFF`)** y escribí el trampolín
en el banco `0x0C` (ROM `0x19F58`). Pero `$AACD` está en el banco `0x21`,
que es **código compartido**: lo llaman varios bancos, y cada uno tiene un
banco distinto en MPR6.

| banco en MPR6 | `$DF58` resuelve a | contenido |
|---|---|---|
| `0x0C` | ROM `0x19F58` | `85 15 43 10 48...` el trampolín — OK |
| `0x08` | ROM `0x11F58` | `ff ff ff ff ff...` **relleno — cuelga** |
| `0x0D` | ROM `0x1BF58` | `ff ff ff ff ff...` **relleno — cuelga** |

Llamantes de `JSR $AAB4` medidos:

```
banco 0x0C: 0x1963C, 0x19671, 0x196AF, 0x19731   intro y tutorial -> OK
banco 0x08: 0x11AF1, 0x11B8C, 0x11BA0, 0x11D7C   MENÚS -> reset
```

### [HECHO] Prueba directa de que el banco 0x08 está en su propio MPR6

Secuencia inmediatamente anterior a la llamada, en ROM `0x11AE9`:

```
48         PHA
20 0b db   JSR $DB0B
20 7e db   JSR $DB7E
68         PLA
20 b4 aa   JSR $AAB4
```

```
$DB0B con banco 0x08 en MPR6 -> ROM 0x11B0B: ad 29 3d 0a 0a 85 10   código válido
$DB0B con banco 0x0C en MPR6 -> ROM 0x19B0B: a9 fa 20 14 db 9c 50   otra rutina
$DB7E con banco 0x08 en MPR6 -> ROM 0x11B7E: a0 01 b1 bf c9 de f0   código válido
```

El llamante llama a sus propias rutinas a través de MPR6 → cuando el menú
dibuja un carácter, MPR6 tiene el banco `0x08` → `JSR $DF58` salta a `0xFF`
sin fin → se desboca → reset al título. Coincide con el síntoma.

### [DESCARTADO] Reubicar el trampolín al hueco de `0x42000`

Parecía la solución (banco `0x21`, siempre mapeado en MPR5, 24 B de ceros).
Pero **`$A000` recibe 9 `JSR`**: no está libre. Además, mi escaneo de
"saltos absolutos" por toda la ROM da falsísimos positivos, porque busca
bytes `0x20`/`0x4C` también dentro de gráficos y tablas. **No es evidencia
válida** y no la usé para decidir.

### El arreglo: revertir

Se revierten los 26 bytes del parche TAM (los 4 de la llamada y los 22 del
trampolín) y **se conserva** el `STZ $3BA6` de la v91, que está en el banco
`0x0D` a dirección fija y no depende de ninguna ventana.

El bug del `TAM` que el parche perseguía es real, pero no se manifiesta: el
código original lleva 35 años funcionando así. Si algún día hay que
arreglarlo, el trampolín tiene que ir en el **mismo banco que `$AACD`**
(el `0x21`, ventana MPR5), que está mapeado siempre que esa rutina corre.

### Entrega

```
test_menu_v92.pce
  MD5    c5131fa002d9b2ae419376aa44343f5c
  SHA-1  855e388ddc5226d58bb738bbcd41999ee849a789
  CRC32  03377037
momotaro_menu_v92.ips   44 B, aplicado a la v91 reproduce la v92 [verificado]
```

**La v92 es idéntica a la v89 salvo los 3 bytes de `0x1B141`** (verificado
byte a byte). Es decir: el tutorial y los menús vuelven al estado conocido
bueno de la v89, más el arreglo de Mesen.

### Mi error

Al colocar el trampolín comprobé que `0x19F58` era un hueco libre, pero **di
por supuesto que `$DF58` significaba lo mismo para todos los llamantes**. En
un sistema con MPR eso es justo lo que no se puede suponer. Y solo verifiqué
los llamantes del banco `0x0C`, los que yo conocía: es literalmente la
**norma 18**, que tenía escrita en este mismo diario y me salté.

### Normas nuevas

**23. Un trampolín debe vivir en el MISMO banco que el código que lo llama.**
Si la rutina parcheada es compartida (la llaman varios bancos), un hueco en
una ventana ajena —MPR6 típicamente— resuelve a un banco distinto según
quién llame. Solo la ventana del propio código está garantizada.

**24. Antes de dar por libre una dirección, comprobar quién le hace `JSR`**,
y no fiarse de un escaneo de opcodes por toda la ROM: encuentra `0x20` y
`0x4C` dentro de gráficos. Hay que acotar a los bancos que son código.

**25. Cuando David biseca una versión, esa versión es el sospechoso.**
Empecé mirando la v91 por ser la última; el fallo estaba en la v90.

---

## (62) El límite de 16 celdas era MÍO, no del motor. Medida pendiente

### Herramienta nueva: `tools/dis6280.py`

Desensamblador HuC6280 completo (`TAM/TMA`, `ST0/1/2`, `TII/TIA/TIN`,
`CSL/CSH`, `SAX/SAY/SXY`, `BSR`, `BBR/BBS`, `TST`...). Existe porque
`capstone` en 65C02 lee `TAM` como `nop` y se desincroniza (norma 12).

Validado contra código ya desensamblado a mano en este diario: `$D141`
(el `STZ $3BA6` de la v91) y `$AAB4` salen idénticos a lo documentado.

Toma la dirección de carga como argumento, que es imprescindible: el mismo
offset de ROM significa cosas distintas según la ventana MPR (lección de
la entrada 61).

### [HECHO] Qué hace de verdad el motor

`$D720`, por cada carácter: `JSR $D6BF` / `INC $C3` / `INC $C4`.

`$D6BF` empieza con `BBS0 $C3,$D700`:

```
$C3 PAR   ($D6EC)  escribe el glifo en el BYTE ALTO de la palabra
$C3 IMPAR ($D700)  escribe el glifo en el BYTE BAJO
                   y al acabar: $16 += $40   <- SOLO AQUÍ avanza la VRAM
```

**`$C3` no es un contador de columna: es el selector de mitad de un sprite
16x16.** La dirección VRAM avanza `$40` cada DOS caracteres.

El texto se dibuja en VRAM `$7000` = memoria de **patrones de sprite**. Un
patrón 16x16 del PCE ocupa 16 filas × 4 planos = 64 palabras = `$40`, que
es exactamente el avance. Cada sprite lleva **2 caracteres de 8 px**.

### [HECHO] La capacidad son 24 celdas, por dos caminos independientes

```
tabla $D2BB (posiciones Y): $7008 $7308 $7608 $7908
   separación entre líneas = $300
   $300 / $40 = 12 sprites = 24 caracteres
```

Y la ruta `$D649`, de forma independiente:
```
$D67E: LDA $3BB4
$D681: CMP #$18     -> tope 24
```

### [DESCARTADO] «El límite de ancho es 16 celdas»

Lo escribí en `texto_tutorial.py` afirmando «medido tres veces». Las tres
medidas eran capturas de pantalla, y lo que veía era el texto cortándose
**donde yo mismo lo había cortado**: `ANCHO = 16` estaba en el generador.
Nunca lo contrasté con el código. Razonamiento circular: medí mi propia
constante y la llamé medición del juego.

También escribí que el motor «hace auto-wrap y manda el resto a la línea de
abajo». No lo he visto en el desensamblado: `$D720` no compara `$C3` con
nada. Queda **sin demostrar**.

### Corrección de un error cometido en esta misma sesión

Al analizar `$D23F-$D292` escribí que el bucle `LDX #$2A / LDY #$40`
borraba 4 líneas y que «coincide exacto» con `4*$300 = 3072`. **Es falso**:
`0x2A*0x40 = 2688`, que no es 3072. Además el bucle no borra, **copia**:
programa MAWR desde `$D2BB` y MARR desde `$D2BD` y hace `LDA $0002 /
STA $0002`, es decir el scroll que sube las líneas. Lo di por bueno en un
`print` sin comprobar la aritmética.

**Norma 26. Una cuenta escrita en un `print` no es una medición.** Si digo
«coincide exacto», tengo que haber restado los dos números.

### La prueba: `test_prueba24_v93.pce`

No es versión de entrega, es una regla graduada (norma 13: medir contra la
pantalla). Sustituye el tutorial por 4 páginas de reglas con marcas cada 5
celdas, dentro del bloque original (`0x1F2C9-0x1F365`, 122 B de 157):

```
pág1  123456789.123456789.1234   24 celdas
pág2  123456789.123456789.       20
pág3  123456789.123456           16
pág4  dos líneas de 24           comprueba también la 2ª línea
```

```
MD5    74dbd0b26d20579b65e9f31607f97ae4
SHA-1  c970319c7b61df790632035f89e7b79a0b960a14
CRC32  0efe4da7
```

Lo que hay que leer en pantalla: **hasta qué carácter se ve en cada página**.
Si en la pág1 se leen los 24, el ancho útil se sube de 16 a 24 (+50%) sin
tocar una sola instrucción, y el problema pasa a ser el marco del bocadillo,
que mide 138 px = 17 celdas: el texto se desbordaría por los lados, que es
justo lo que David pidió.

---

## (63) [MEDIDO] El ancho visible son 16 y el derrame cae en la línea de ABAJO

### La medición de David con `test_prueba24_v93.pce`

```
pág1 (una línea de 24)   fila0 "123456789.123456"   fila1 "789.1234"
pág2 (una línea de 20)   fila0 "123456789.123456"   fila1 "789."
pág3 (una línea de 16)   fila0 "123456789.123456"
pág4 (dos líneas de 24)  fila0 "123456789.123456"
                         fila1 "123456789.123456"  <- reescrita desde el 1
                         fila2 "789.1234"
```

### [DESCARTADO] «El motor corta a 24, el ancho útil es 24»

Es lo que afirmé en la entrada (62) a partir de `$300/$40 = 12 sprites` y
del `CMP #$18`. **La pantalla dice que no.** El ancho VISIBLE es 16.

Lo que fallaba en mi razonamiento: deduje la capacidad de una fila de
pantalla dividiendo la separación entre CURSORES (`$300`), dando por hecho
que todo ese tramo de VRAM se veía en la misma fila. No es así.

### [HECHO] El modelo correcto, validado contra las 4 páginas

```
por cada 2 caracteres           el cursor VRAM avanza $40 (= 1 sprite 16x16)
una fila de pantalla muestra    8 sprites contiguos = $200 = 16 caracteres
el cursor salta por línea       $300  (tabla $D2BB)
$300 - $200 = $100 = 4 sprites = 8 caracteres  ->  DERRAME
```

Los caracteres 17-24 de una línea **no se pierden ni se truncan: se dibujan
en la fila de abajo, columnas 0-7.**

Y así se explica lo de la pág4: la fila 1 recibe dos escrituras — primero
el derrame de la línea 1 (`789.1234`) y después la línea 2 completa, que lo
pisa desde la columna 0. Es exactamente lo que David describió: «comienza a
sobrescribirla, empezando a contar desde el 1». Los caracteres que «suenan
pero no aparecen» son los de la línea 2 que caen más allá, ya fuera.

Simulador del modelo en `tools/modelo_vram.py`: reproduce las 4 páginas
carácter a carácter.

### Lo que esto significa para ensanchar el bocadillo

**Buena noticia:** los 4 sprites que harían falta para llegar a 24 columnas
**ya existen y ya se están dibujando**. No hay que crear sprites nuevos ni
buscar VRAM libre: están colocados en la fila de abajo, columnas 0-7.

Ensanchar = **reubicar 4 sprites por fila**: X += 128 px y Y a la fila de
arriba. Es un cambio en el SATB, no en el motor de texto.

### Pista sobre dónde se monta el SATB (sin cerrar)

```
$D5EF  carga $53/$54 = $4802   lista de sprites
$D5D3  carga $53/$54 = $47FC   otra lista
$D612  $55/$56 = $0380         patrón base (coincide con $7008>>5)
$E3EB  intérprete: registros de 4 bytes, terminador $FF en el byte 0
       byte0 = patrón relativo (ASL A, + $0380)
       byte1 = atributo (ORA $6C)
```

**[HIPÓTESIS, sin verificar]** Las listas están en `$4000-$5FFF` (MPR2), y
el banco lo fija `LDA #$xx / ADC $20 / TAM #$04`. Probé a leerlas con los
bancos `0x0F/0x17/0x1D/0x0C` y ninguno da una lista coherente: el `0x17`
tiene un `$FF` a media tabla y patrones que se salen del rango del texto.

**No sé el valor de `$20` en ejecución**, que es la base de banco del juego,
y sin él no puedo resolver a qué ROM apuntan. Deducirlo a ojo sería
adivinar offsets, que es justo lo que prohíbe el método.

### Norma 27
**La capacidad de una fila de pantalla no se deduce de la separación entre
cursores.** Son dos cosas distintas: cuánto avanza el cursor por línea y
cuánto de ese tramo muestra el hardware. La diferencia entre ambas es el
derrame.

---

## (64) [HECHO] El SATB real del tutorial. Geometría cerrada

David aportó 8 capturas del Sprite Viewer de Mesen (una por sprite) y el
save-state `test_prueba24_v93.state`. Con eso se acaba la especulación.

### El save-state, descomprimido

Formato `#RZIPv` + zlib desde el byte 24 -> 83.552 B. Secciones Mednafen
localizadas por etiqueta: `MPR` (8495), `SATB` (10334), `VRAM` (11067).
Volcado a `docs/vram.bin` (65.536 B).

### [HECHO] Los MPR reales durante el tutorial

```
MPR0 $FF   MPR1 $F8   MPR2 $02   MPR3 $1E
MPR4 $20   MPR5 $21   MPR6 $0E   MPR7 $00
```

- `MPR4=$20` y `MPR5=$21`: coinciden con lo documentado (tablas katakana y
  código compartido `$AAxx`).
- `MPR3=$1E`: la fuente de diálogo. Coincide.
- **`MPR6=$0E`, no `$0C`.** Yo venía suponiendo `$0C` para todo el motor.
  Refuerza la lección de la entrada (61): la ventana MPR6 cambia de banco
  según la pantalla, y `$D720`/`$D6BF` se ejecutan desde bancos distintos.

### [HECHO] El SATB (VRAM `$7F00`), leído del state

```
spr  Y    X    patrón   VRAM      contenido (capturas de David)
 0  120   96   $035C    $6B80     1234
 1  120  128   $0360    $6C00     5678
 2  120  160   $0364    $6C80     9.12
 3  120  192   $0368    $6D00     3456
 4  136   96   $036C    $6D80     789.
 5  136  128   $0370    $6E00     (vacío)
 6  136  160   $0374    $6E80     (vacío)
 7  136  192   $0378    $6F00     (vacío)
```

Los 8 sprites del state coinciden **uno a uno** con las 8 capturas
(`patrón * 32 = Tile address` de Mesen). Todos `32x16`, atributo `$018E`
(paleta 14).

### La geometría, ya sin hipótesis

```
sprite            32x16 px = 4 caracteres de 8 px
paso en X         32 px
sprites por fila  4  ->  4 x 4 = 16 CARACTERES POR FILA   <- el límite medido
paso de patrón    $80 palabras por sprite (= 4 patrones de $20)
fila 0            $6B80    fila 1  $6D80    separación $200
```

`$200 / $40 = 8` pasos de cursor = 16 caracteres: **la escritura es lineal
y al pasar de 16 entra exactamente en la fila de abajo.** Es justo el
"derrame" medido en la entrada (63), ahora explicado por el hardware.

### [DESCARTADO] «El tutorial usa la tabla `$D2BB` ($7008/$7308, paso $300)»

Falso. Esa tabla es de **la intro**. El tutorial vive en `$6B80/$6D80` con
paso `$200`. Mi modelo de la (63) acertaba el comportamiento visible (8
sprites visibles + derrame de 4) pero con las direcciones equivocadas y con
un tamaño de sprite equivocado (16x16 en vez de 32x16). Coincidía en
pantalla por casualidad aritmética: 8 sprites de 16 px y 4 de 32 px cubren
los mismos 128 px.

**Norma 28. Que un modelo reproduzca lo observado no lo hace correcto.**
El de la (63) predecía las 4 páginas y aun así tenía mal la base VRAM, el
paso de línea y el tamaño de sprite. Sólo el volcado del SATB lo cerró.

### [DESCARTADO] Las listas `$47FC`/`$4802` como fuente del bocadillo

Con el banco real (`MPR2=$02` -> ROM `0x047FC`) se leen `00 ff 00 ff...`:
no son registros de sprite. La pista de `$E3EB` no llevaba al bocadillo.

Las tablas de `$D07B`, `$D094`, `$D0B3` (banco `0x0E`) sí son listas de
direcciones VRAM en pasos de `$20`, pero corresponden a animaciones, no al
SATB del texto.

### Lo que queda para ensanchar

Los sprites 5, 6 y 7 (fila 1, X=128/160/192) **están vacíos**: solo se usan
cuando hay segunda línea. Y el bocadillo mide 138 px de ancho ≈ 4,3 sprites.

Para 24 caracteres por fila harían falta **6 sprites por fila** (6 x 4 = 24,
192 px). Hay 8 sprites en total; con 6+6 = 12 haría falta ampliar el SATB.
Falta localizar **el código que escribe el SATB**, que no está en las
tablas examinadas.

---

## (65) [MEDIDO] El bocadillo SÍ se reutiliza, y con 3 y 4 líneas

David: «desconozco si ese bocadillo vuelve a aparecer en otras partes del
juego. Lo que es seguro es que en dicho tutorial sólo muestra dos líneas.»

Su primera parte había que medirla, no suponerla (norma 18). Medida.

### Otros bloques con EL MISMO formato que el tutorial

Barrido del banco `0x0F` buscando cabecera `0x01` + katakana + controles
`00/FD/FE/FF`:

```
ROM        bytes  máx. líneas/página  contenido
0x1F2C9     151          2   TUTORIAL (el de los ñordos)
0x1F366     112          2   "¡Oh, bien venido, Momotaro!" + ñordos + meta
0x1F3D6     108          2   variante: romper el kusudama
0x1F442     108          2   variante: dios de la fortuna / de la pobreza
0x1F56E      55          3   "¡El canto de Jizo es incorrecto!"
0x1F838      71          4   el mismo error de Jizo, ya traducido
0x1FB6A      60          3   "Los datos guardados no son válidos"
```

### Tabla de punteros en `0x1F2BD-0x1F2C8`

```
0x1F2BD  $5442 -> 0x1F442
0x1F2BF  $53D6 -> 0x1F3D6
0x1F2C1  $5366 -> 0x1F366
0x1F2C7  $52C9 -> 0x1F2C9   <- el tutorial
```

Cuatro variantes contiguas del mismo tutorial: las tres primeras terminan
igual («¡STAAART!»), son los avisos previos a cada minijuego. El motor
elige una según el minijuego.

### [HECHO] Conclusión: los sprites 5-7 NO se pueden reutilizar

David tiene razón en que **el tutorial de los ñordos usa 2 líneas** — y las
cuatro variantes también. Pero el mismo motor de bocadillo dibuja bloques
de **3 líneas** (`0x1F56E`, `0x1FB6A`) y de **4** (`0x1F838`, el error de
Jizo ya traducido).

Y ya estaba medido en la entrada (63): `$D1A0` hace `INC $3CE3 / CMP #$04`,
es decir **el intérprete admite hasta 4 líneas**.

Por tanto los 8 sprites del SATB no son «4 usados + 4 libres»: son **4
filas de texto de las que en el tutorial sólo se llenan 2**. Reubicar los
sprites 5-7 a la primera fila rompería el error del Canto de Jizo, que es
justo lo que ya se rompió en la v74 y en la v81.

**[HIPÓTESIS, sin verificar]** Los 8 sprites del state serían las 2 filas
de ESE bocadillo, y las pantallas de 3-4 líneas usarían más sprites o un
SATB distinto. No lo he comprobado: haría falta un state del error de Jizo.

### Consecuencia para ensanchar

No hay atajo por reutilización. Ensanchar a 24 columnas exige **añadir 2
sprites por fila** (de 4 a 6, 192 px), no mover los existentes:

```
fila 0: X = 96,128,160,192  ->  añadir 224, 256   (patrones $036C, $0370)
fila 1: idem
```

Eso son 4 sprites nuevos como mínimo (2 filas), 8 si se quiere en las 4
filas. Y el bocadillo mide 138 px: habría que ensancharlo a ~200 px, que es
el problema que sigue abierto desde la (57) — el stream real del marco no
está localizado (los 8 modos de `$C499` quedaron descartados).

### Lo que hace falta para seguir

Un save-state **del error del Canto de Jizo** (3-4 líneas). Diría de una vez
si esas pantallas usan los mismos 8 sprites o más, que es lo que decide si
se puede tocar el SATB sin romperlas.

---

## (66) [HECHO] David tenía razón: el marco es por pantalla. Y localizada la lista de sprites

### La prueba de David: dos capturas, medidas en píxeles

```
japonesa (error de Jizo):  x= 73..206 = 134 px ancho,  y=105..158 = 54 px alto
v93      (error de Jizo):  x= 63..220 = 158 px ancho,  y= 89..158 = 70 px alto
                                        +24 px                     +16 px
```

`+16 px` de alto = exactamente **una línea más**. El bocadillo del error de
Jizo **está ampliado** respecto al original japonés, y el del tutorial sigue
en 138 px.

### [DESCARTADO] «Sin un save-state no se puede saber si el SATB es compartido»

Lo afirmé en la entrada (65). **Falso.** La prueba estaba en pantalla: basta
comparar la captura japonesa con la traducida. David lo vio y yo no.

Peor: el log del chat original ya lo documentaba (líneas 1556-1573) — allí se
ensanchó el stream `0x1E07A` a 14 tiles para el selector de dificultad, y el
`0x1E0D1` para el selector de Jizo, **por separado**. Tenía la respuesta en
`docs/` y no la consulté antes de afirmar lo contrario.

**Norma 29. Antes de declarar algo indemostrable, comprobar si ya está
resuelto en el log del chat original.** Son 86.463 líneas de trabajo previo.

### [HECHO] El motor de metasprites, completo

```
$E3EB (ROM 0x003EB, banco 0x00, siempre en MPR7)
    intérprete de listas de sprites. Registros de 5 bytes ($E510: ADC #$05)
    puntero a la lista en $53/$54 ; patrón base en $55/$56
    formato: [pat_rel][attr_lo][attr_hi][dx][dy]   terminador $FF
    patrón final = base + (pat_rel << 1)

$E4D5-$E504  vuelca cada sprite al SHADOW en RAM, indexado por $6A
$E55A-$E5BB  copia el shadow al SATB de VRAM ($7F00) y lanza el DMA (ST0 #$13)
```

**Shadow del SATB en RAM** (verificado contra el state, coincide exacto):

```
$26A0+i  flag        $26E0+i  Y_lo    $2720+i  Y_hi
$2860+i  X_lo        $28A0+i  X_hi
$2760+i  patrón_lo   $27A0+i  patrón_hi
$27E0+i  attr_lo     $2820+i  attr_hi
$6A = número de sprites activos (28 en el tutorial)
```

### [HECHO] LA LISTA DEL BOCADILLO DEL TUTORIAL: ROM `0x1FBF0`

```
ROM 0x1FBF0 ($5BF0 con el banco 0x0F en MPR2)
  [0] 00 0e 01 00 00   pat_rel=0 -> $035C   dx=  0  dy=0
  [1] 02 0e 01 20 00   pat_rel=2 -> $0360   dx= 32  dy=0
  [2] 04 0e 01 40 00   pat_rel=4 -> $0364   dx= 64  dy=0
  [3] 06 0e 00 60 00   pat_rel=6 -> $0368   dx= 96  dy=0
  [4] ff              FIN
```

Coincide **byte a byte** con los sprites 0-3 del SATB extraído del state
(patrones `$035C $0360 $0364 $0368`, X = 96/128/160/192). Es la fila de
texto del bocadillo: **4 sprites de 32 px = 128 px = 16 caracteres**.

### El hallazgo que resuelve el problema

Inmediatamente después, en ROM `0x1FC05`, hay otra lista con **6 sprites en
una fila**:

```
  [1] 10 0e 01 e6 10   dx= -26  dy=16
  [2] 12 0e 01 06 10   dx=   6  dy=16
  [3] 14 0e 01 26 10   dx=  38  dy=16
  [4] 16 0e 01 46 10   dx=  70  dy=16
  [5] 18 0e 01 66 10   dx= 102  dy=16
```

6 sprites × 32 px = **192 px = 24 caracteres**, con paso de patrón 2 igual
que la del tutorial. Es la prueba de que el formato admite 6 por fila.

### Orden de trabajo acordado con David

> «la longitud de la línea es lo que determinará la anchura del marco. No
> podemos modificarlo a ciegas.»

Correcto, y es lo contrario del error del chat original (ampliar el marco
primero y descubrir que el texto seguía cortado). Por tanto:

1. **primero** ampliar la lista `0x1FBF0` de 4 a 6 sprites -> 24 celdas;
2. **medir** en pantalla cuánto ocupa realmente el texto;
3. **después** ampliar el marco a la anchura ya medida.

### Pendiente antes de tocar

La lista `0x1FBF0` está seguida inmediatamente por otra (`0x1FC05`). Añadir
2 registros (10 bytes) **desplazaría** la siguiente. Hay que:
- localizar quién apunta a `$5BF0` y a `$5C05` (el barrido de `f0 5b` dio
  falsos positivos: son opcodes `BEQ`, no punteros);
- o reubicar la lista ampliada a un hueco y repuntar, sin mover nada.

---

## (67) [HECHO] Localizada la tabla de bases de línea: `$EC04`. Y dos errores míos

### La medición de David

Breakpoint de escritura en Work RAM `$00C1` (cursor VRAM) durante el tutorial
de los ñordos. Para en `$D980`, banco `0x0E` en MPR6 (ROM `0x1D980`).
Call stack: `$EB8E -> $B97D -> $D6BB -> $D939 -> $D960`.

```
1D97D  D97D  ad04ec     LDA $EC04     <- BASE DE LÍNEA
1D980  D980  85c1       STA $C1
1D982  D982  ad05ec     LDA $EC05
1D985  D985  85c2       STA $C2
1D987  D987  9ce33c     STZ $3CE3
```

### [HECHO] La tabla: ROM `0x00C04`, banco `0x00`, MPR7 (siempre mapeado)

```
$EC04: $6B84   línea 0
$EC06: $6D84   línea 1
$EC08: $6F84   línea 2
separación $200 = 8 patrones de $40 = 16 caracteres   <-- EL LÍMITE
```

Es la pieza que llevaba tres entradas buscando. Y encaja con el SATB medido
(patrones `$035C`/`$036C`/`$037C`).

### [DESCARTADO] «El tutorial usa la tabla `$D2BB`»

Falso. `$D2BB` (`$7008/$7308`, paso `$300`) es de la **intro**. El tutorial
usa `$EC04` (`$6B84/$6D84`, paso `$200`). Lo afirmé en las entradas 63 y 64
y hay que corregirlo ahí.

### [DESCARTADO] «El tutorial compone en un buffer `$313F` y vuelca por DMA»

Lo afirmé en el turno anterior tras un breakpoint en VRAM `$6B80`. **Falso, o
al menos sin demostrar.** Ese breakpoint cazó la **carga inicial de gráficos**
de la pantalla (`$861F` -> `$867F`, un descompresor RLE por bits), no el
dibujado del texto.

Lo comprobé transcribiendo el descompresor instrucción a instrucción
(`tools/descomp_8667F.py`) y ejecutándolo sobre `$50E2`: **el patrón que sale
no coincide** con el buffer real del state. La implementación puede tener un
fallo, pero el punto es que salté a una conclusión con una sola muestra y sin
validarla.

**Norma 30. Un breakpoint en la PRIMERA escritura a una dirección caza la
inicialización, no el uso.** Para ver el dibujado hay que romper durante la
escena, no al montarla.

### El obstáculo, ahora cuantificado

```
línea 0 con 24 chars -> $6B84..$6E84
línea 1 empieza en   -> $6D84          SOLAPE de $100
```

Ampliar los sprites sin más sólo haría visible el solape. Hacen falta **dos
cambios coordinados**:

1. `$EC04`: separación `$200` -> `$300` (`$6B84, $6E84, $7184`);
2. lista `0x2EC10`: de 4 a 6 sprites por fila (dx 0,32,64,96,128,160).

Riesgo principal a verificar antes de tocar: que la VRAM `$6B84-$7484` esté
libre y no pise el marco del bocadillo ni el retrato del viejo.

### Trabajo en paralelo

A propuesta de David, se prepara un encargo autocontenido para Claude
(`docs/PROMPT_CLAUDE_ensanchado.md`) con todo el análisis, las hipótesis ya
descartadas y las dos preguntas abiertas. Excepción acordada al método
habitual de trabajar en una sola rama.

---

## (68) [HECHO] v94: bocadillo del tutorial a 24 caracteres

### La verificación de VRAM: resuelta sin emulador

Claude propuso un breakpoint en `$3126` para saber si `$6B84-$7484` estaba
libre. **No hacía falta**: el save-state ya trae los 64 KB de VRAM. Tres
comprobaciones independientes:

1. **Ningún sprite ajeno.** Barrido de los 64 sprites del SATB: en
   `$6900-$7600` sólo están el texto (spr 0-7) y el retrato del viejo con su
   marco (spr 8-22), y éstos ocupan `$6900-$6BFF`, por debajo. El spr17 llega
   a `$6B7F`, justo antes de `$6B84`.
2. **Contenido vacío.** `$7340-$74C0` es todo ceros.
3. **El fondo no llega.** El BAT usa 29 tiles, máximo `$2FF` -> CG hasta
   `$2FFF`. Nada que ver.

Además, la propuesta de Claude no habría contestado la pregunta: `$3126` es
la carga genérica de gráficos, la misma que me despistó en la entrada (67). Y
no consideró el BAT, que era el único punto donde podía haber colisión real.

### [HECHO] La trampa que estuvo a punto de repetirse

Iba a cambiar la tabla `$EC04` de separación `$200` a `$300`. **Habría roto
otras pantallas.** Medición antes de tocar:

```
LDA $EC04    ROM 0x1A189 (b0D)  arranque
             ROM 0x1A315 (b0D)  SCROLL (usa $EC04 y $EC06 como orig/dest)
             ROM 0x1D97D (b0E)  arranque del TUTORIAL
LDA $EC04,X  ROM 0x1A298 (b0D)  fin de línea
             ROM 0x1A388 (b0D)  set cursor
```

`$EC04` está en el banco `0x00` (MPR7, **siempre mapeado**): es global. Y los
primeros 20 bytes de `$C189` (banco `0x0D`) y `$D97D` (banco `0x0E`) son
**idénticos byte a byte**: el mismo motor duplicado en dos bancos.

Es la misma trampa que rompió la parrilla del Jizo en la v74: tabla
compartida que parecía local.

### La solución: tabla nueva, sólo para el tutorial

**No se toca `$EC04`.** Se crea una tabla propia y se redirige únicamente el
código del banco `0x0E`.

```
1) tabla nueva en $FA1C (ROM 0x01A1C), banco 0x00:
       $6B84, $6E84, $7184        separación $300 = 24 caracteres

2) ROM 0x1D97D  LDA $EC04 -> LDA $FA1C
   ROM 0x1D982  LDA $EC05 -> LDA $FA1D

3) lista ROM 0x2EC10: de 3 filas x 4 sprites a 2 filas x 6.
   MISMA longitud (12 regs x 5 B), no se mueve nada, no hay que repuntar.
       fila 0: dx 0,32,64,96,128,160   pat_rel 00,02,04,06,08,0a
       fila 1: dx 0,32,64,96,128,160   pat_rel 0c,0e,10,12,14,16
```

### Verificación del hueco `$FA1C`

Hay 128 B de ceros en `$F9CC`, pero **no todo está libre**: dos `TIA`
(`$F9B2` y `$FA8A`) lo usan como origen de DMA, `$40` y `$50` bytes. Se deja
ese tramo intacto y se usa `$FA1C`, fuera de ambas copias.

Descartado el hueco de `$E8CB` (15 B): es una tabla indexada con **6
lectores** (`LDA $E8CB,Y` y `,X`). Parecía relleno y no lo era.

### Coherencia tabla <-> lista (verificada por programa)

```
fila 0 base $6B84: sprites en patrones $035C $0360 $0364 $0368 $036C $0370
fila 1 base $6E84: sprites en patrones $0374 $0378 $037C $0380 $0384 $0388
```
Ambas coinciden exactamente con lo que produce el cursor al avanzar `$40`
cada 2 caracteres. Sin solapes.

### Entrega

```
test_ancho_v94.pce
  MD5    5da4fc4d25cb822c600c0045966397fb
  SHA-1  d9a6046d8abd0443af6b29c71772d9b04be8647b
  CRC32  ca5d4b9d
momotaro_ancho_v94.ips
```

24 bytes de código/datos + el bloque de texto de prueba. Tabla global `$EC04`
**intacta** (verificado por el constructor).

Texto de prueba:
```
pág1  "123456789.123456789.1234"   24 celdas
      "ABCDEFGHIJKLMNOPQRSTUVWX"   24 celdas
pág2  "¡Esquiva los ñordos que"    23
      "caen! ¡Ujujuy!"             14
```

### Lo que NO hace, y es deliberado

**No amplía el marco** (sigue en 138 px). David pidió medir primero el texto
y ajustar el marco después. Con esta ROM el texto **debe desbordar el marco
por la derecha**: eso es la medición que buscamos, no un fallo.

### Predicción falsable

- si sale bien: 24 caracteres por línea, 2 líneas, texto desbordando el marco
  por la derecha unos 54 px;
- si la tabla nueva no se lee: seguiría cortando en 16 (fallaría el cambio 2);
- si las bases están mal: la línea 2 se pisaría con la 1;
- si la lista está mal: faltarían los sprites 5 y 6 de cada fila (se verían
  16 caracteres y un hueco).

---

## (69) [RESUELTO] La pieza que faltaba: `$FC43` escribe 16 palabras, no una

### Por qué falló la v94

David: «las líneas no desbordan. Sólo pasan a la línea inferior, como en las
pruebas anteriores.» Y precisó: fila 1 = `789.1234` y luego `ABCDEFGHIJKLMNOP`
sobrescribiendo. Es decir, el comportamiento de la v93 sin cambios.

Dos causas, ambas medidas:

1. **La tabla nueva `$FA1C` tenía la entrada 0 idéntica a la vieja** (`$6B84`),
   y `$D97D` solo lee la entrada 0. El parche era literalmente inocuo.
2. **Faltaba el tercer cambio.**

### La pregunta de David que lo desbloqueó

> «por qué hemos podido ampliar la ventanilla de otros textos, pero con éste
> no damos con la tecla»

Fui al log del chat original y ahí estaba, documentado desde hace semanas:

```
prompt de password:   $BA8A   LDY #$09 -> LDY #$0D
error del Canto Jizo: CE53    CPY #$18 -> #$28
```

> «El juego solo prepara/limpia los chunks previstos para el texto japonés
> original. Al traducir a frases más largas, los chunks extra no se preparan
> -> aparecen con basura gráfica.»

Son **tres** cambios coordinados, no dos. Yo llevaba tres intentos haciendo dos.

### [HECHO] La rutina de preparación: `$BA8C` (ROM `0x43A8C`)

```
LDA #$84 / STA $16 ; LDA #$6B / STA $17   -> $6B84  (base del tutorial)
MAWR = $16 & $F0 = $6B80
bucle: 00 / FF / FF / 00 vía JSR $FC43,  DEY / BPL
```

**El error que me tuvo atascado media hora:** desensamblé `$FC43` en el banco
equivocado (`0x21` en vez del `0x00`) y me salió código sin sentido. El real:

```
$FC43 (ROM 0x01C43, banco 0x00):
    LDX #$10 / STA $0002 / STA $0003 / DEX / BNE
    -> escribe DIECISÉIS palabras, no una
```

Con eso cada iteración de `$BA8C` prepara `4 x 16 = 64` palabras = **un patrón
de sprite 16x16 exacto**. Y todo cuadra:

```
LDY #$18 -> 25 patrones desde $6B80
SATB: 3 filas x 4 sprites de 32x16 = 3 x 8 = 24 patrones (+1 de margen)
```

Verificado contra la VRAM del state: de los 25 patrones, 15 conservan intacta
la firma `0000/FFFF/FFFF/0000` y 10 tienen texto escrito encima.

**Norma 31. Si una rutina "no cuadra por un factor raro", comprobar que se ha
desensamblado en el banco correcto antes de dudar del modelo.**

### [HECHO] Los cuatro llamantes tienen su propio contador

```
ROM 0x1A175 (b0D)  LDY #$18   otra pantalla
ROM 0x1A27A (b0D)  LDY #$18   otra pantalla
ROM 0x1CD09 (b0E)  LDY #$08   otra pantalla
ROM 0x1D95B (b0E)  LDY #$18   EL TUTORIAL
```
Cada uno fija `Y` antes de llamar -> tocar `0x1D95C` no afecta a los otros tres.

### [DESCARTADO] Los `dx` de la lista de sprites son sin signo

Falso, y el log lo avisaba: «los offsets X de sprites en la lista son con
signo: `$80` no es +128, sino negativo; se usó `$7F` para el límite positivo».

La v94 usaba `dx = $80` y `$A0` para las columnas 5ª y 6ª, que el hardware lee
como **−128 y −96**: esos sprites se dibujaban fuera de pantalla por la
izquierda. Aunque los otros dos cambios hubieran funcionado, no se habrían
visto. Corregido recentrando la fila: `dx = -96, -64, -32, 0, +32, +64`.

### v95: los tres cambios

```
1) bases de línea    tabla nueva $FA1C (ROM 0x01A1C) = $6B84, $6E84, $7184
                     y redirigir SOLO el banco 0x0E (ROM 0x1D97D / 0x1D982).
                     La global $EC04 no se toca (la comparten dos motores).
2) lista de sprites  ROM 0x2EC10: 2 filas x 6 sprites, dx con signo.
                     Misma longitud, sin repuntar.
3) preparación       ROM 0x1D95C: LDY #$18 -> LDY #$24
                     37 patrones = $6B80..$74C0, cubre la línea 2 ($7484).
```

### Entrega

```
test_ancho_v95.pce
  MD5    e9b4276a2f62e7d87cf547032a6888ac
  SHA-1  2c688946c29ce1f49e97b3ffbca4a82e11f79b20
  CRC32  fd36b380
momotaro_ancho_v95.ips
```

Texto definitivo de David, 157 B de 157 disponibles (justo):
```
pág1  ¡Primero, calienta      / antes de jugar!
pág2  ¡Esquiva los ñordos     / que caen! ¡Ja, ja!
pág3  ¡Pulsa II para saltar   / y esquivarlos!
pág4  ¡Ve a la derecha        / hasta la meta! ¡Ya!
```
Ninguna línea pasa de 24. Con el límite viejo de 16 se cortarían cinco.

### Predicción falsable

- **correcto**: las 4 páginas se leen enteras, 2 líneas cada una, y el texto
  desborda el marco por la derecha (el marco sigue en 138 px = 17 celdas);
- si el cambio 3 no basta: basura gráfica a partir del carácter 17;
- si el cambio 2 está mal: el texto aparece corrido a la izquierda o faltan
  sprites;
- si el cambio 1 no se lee: sigue cortando a 16 y la línea 2 pisa el derrame.

### Pendiente

Ampliar el marco del bocadillo a la anchura ya medida. Ahora sí se puede: el
orden que pidió David (primero el texto, después el marco) se cumple.

---

## (70) [RESUELTO] La pieza que faltaba: el motor está en DOS bancos. v96

### Por qué fallaron v93, v94 y v95

El motor de este bocadillo está **repartido entre dos bancos**:

```
banco 0x0E  $D960  arranque del TUTORIAL (solo pone la LÍNEA 0)
banco 0x0D  $C1AF  intérprete
            $C284  avance de línea (INC $3CE3)
            $C298  LDA $EC04,X   <-- AQUÍ se lee la base de CADA línea
            $C315  scroll
            $C388  set cursor
            $C189  arranque de la escena de los PADRES
```

Yo redirigí solo el arranque del banco `0x0E`. **El salto de línea 0->1 lo
hace `$C298`, en el otro banco.** Por eso las tres versiones se comportaron
exactamente igual: la línea 1 seguía arrancando en `$6D84`.

El dato estaba en mi barrido de la entrada (68): `$C298` y `$C388` eran los
**únicos accesos indexados** a `$EC04` y los descarté anotando «otra
pantalla» sin comprobarlo. Norma 18, por segunda vez en el mismo problema.

### [DESCARTADO] Recentrar los dx de los sprites (v95)

Los `dx` son **con signo** (el log del chat original ya lo avisaba: «`$80` no
es +128, sino negativo»). En la v95 los puse a `-96..+64` y el texto se
desplazó 96 px a la izquierda: la captura de David mostraba `¡Primero, ca`,
cortado en el carácter **12**, peor que el original.

Corregido a `-64..+96`: mismo span de 160 px, todos representables con signo,
y el conjunto queda mucho más cerca del ancla original.

### [HECHO] Las dos pantallas comparten el motor

```
JSR $EC0A desde ROM 0x1D94B (banco 0x0E)  -> tutorial de los ñordos
JSR $EC0A desde ROM 0x1A02E (banco 0x0D)  -> escena de los padres
```

David razonó: «si hay más cajas como ésta será porque contienen líneas de
longitudes similares. Siendo así, necesitaríamos alargarlas todas.»

**Verificado**: el texto de los padres (ROM `0x1F077`) ya tiene en japonés
líneas de 16 y 18 celdas (`「ヒツヨウジャロウ!」モモタロウハ`). En castellano se
pasarían de largo. Ampliar las dos es lo correcto, y además evita duplicar
código.

### [HECHO] El scroll `$C315`

```
MAWR <- $EC04 & $C0 = $6B80    destino
MARR <- $EC06 & $C0 = $6D80    origen
LDX #$10 / LDY #$40 = $400 palabras = 2 líneas de $200
```

Con separación `$300` hacen falta `$600` -> `LDX #$18`. Si no se ajusta, el
scroll arrastra basura, que es parte de lo que se veía en la captura de los
padres.

### Los SEIS cambios de la v96

```
1  0x01A1C  tabla nueva $FA1C = $6B84, $6E84, $7184  (separación $300)
2  0x1D97D/82   arranque tutorial   -> $FA1C/$FA1D
3  0x1A189/8E   arranque padres     -> $FA1C/$FA1D
4  0x1A298/9D   AVANCE DE LÍNEA     -> $FA1C,X / $FA1D,X   <-- la pieza clave
5  0x1A388/8D   set cursor          -> $FA1C,X / $FA1D,X
6  0x1A315/1D/2A/32  scroll         -> $FA1C/$FA1D/$FA1E/$FA1F
   0x1A340  LDX #$10 -> #$18        ($400 -> $600)
7  0x1D95C  prep tutorial LDY #$18 -> #$24   (37 patrones)
   0x1A27B  prep padres   LDY #$18 -> #$24
8  0x2EC10  lista de sprites: 2 filas x 6, dx -64..+96 (con signo)
```

La tabla global `$EC04` **no se toca** (verificado por el constructor).

**Error detectado por el propio constructor:** puse el `LDY` de los padres en
`0x1A276` y estaba en `0x1A27B`. La comprobación previa lo cazó antes de
escribir. Es exactamente para lo que sirve la norma de comprobar qué hay
antes de tocar.

### Entrega

```
test_ancho_v96.pce
  MD5    035f7cd345346155d7128d7de44e08d2
  SHA-1  b85666f323fef44910660c19adb1c5c4d85ba425
  CRC32  0b432be9
momotaro_ancho_v96.ips
187 bytes modificados
```

### Predicción falsable

- **correcto**: 24 caracteres por línea en el tutorial Y en la escena de los
  padres; el texto desborda el marco (138 px = 17 celdas) por la derecha;
- si sigue cortando en 16: el avance de línea no es `$C298`;
- si el texto sale corrido: los `dx` siguen mal;
- si aparece basura entre líneas: el scroll `$600` no basta.

---

## (71) [RESUELTO] La lista correcta era `0x2EA45`. v97: texto Y marco

### Lo que demostró la v96

Aparecieron **huecos** en el texto. Medidos: 5,4 celdas contra 5 predichas.

```
L1: ¡Esquiva los ñor        chars 1-16
L2: dos      que cae        "dos" = derrame (17-19) + HUECO + línea 2
```

Antes la línea 2 pisaba el derrame; ahora arranca 8 celdas más allá y el
derrame sobrevive. **Los cambios de VRAM (bases, scroll, preparación)
funcionan.** Confirmado por medición, no por teoría.

### [DESCARTADO] `0x2EC10` es la lista del bocadillo del tutorial

Falso, y la prueba es limpia: en la v96 puse `dx = -64..+96`, que habría
movido el texto **64 px a la izquierda**. El texto siguió empezando en
`x=58`. Cero efecto.

Esa lista existe y su firma `rel/dx/dy` coincidía con el SATB, pero coincidir
no es ser la fuente. Lo delataba la contradicción que arrastraba desde la
entrada (66) y nunca resolví: **12 registros frente a 8 sprites de texto**.

### [HECHO] La lista real: ROM `0x2EA45` (`$4A45`)

Se carga en el arranque del tutorial, `$D9B1` (ROM `0x1D9B1`):

```
LDA #$48 / STA $55      base de patrón = $0348
LDA #$03 / STA $56
LDA #$45 / STA $53      lista = $4A45
LDA #$4A / STA $54
STZ $52 / JMP $E3EB
```

23 registros con **texto Y marco juntos**:

```
[ 0- 3]  texto fila 0    rel 0a..10  dx -64,-32,0,32   dy 16
[ 4- 7]  texto fila 1    rel 12..18  dx -64,-32,0,32   dy 32
[ 8-12]  marco superior  rel 00,02,02,02,00            dy 0
[13-16]  laterales       rel 04      dx -80,+64        dy 16,32
[17]     rabito          rel 09      dx -8             dy 48
[18-22]  marco inferior  rel 00,02,02,02,00            dy 48
```

**Verificado 18/18** contra el SATB del save-state, con ancla del metasprite
en X=160, Y=104: coinciden Y, X y patrón en los 18 sprites comprobables.

### v97: el diseño nuevo

```
texto  6 sprites de 32 px  X = 32,64,96,128,160,192   (dx -128..+32)
marco  7 piezas de 32 px   X = 32..224
laterales X=32 y X=224
ancho del bocadillo: 224 px   (antes 138)
```

La lista pasa de 23 a 31 registros (156 B), no cabe en su sitio (detrás hay
otra lista), así que se **reubica** al hueco verificado de 1447 B en ROM
`0x2FA59` (`$5A59`, mismo banco `0x17`) y se repunta `$D9B9`.

**Error cazado por la verificación:** los laterales con `dx -144/+96` daban
X=272 y X=256, fuera de la pantalla de 256 px. Corregidos a `-128/+64`.
Comprobado por programa: 0 sprites fuera de pantalla.

### Entrega

```
test_ancho_v97.pce
  MD5    10a02442c36fa85b90e52e3a184f461a
  SHA-1  4bbae9d730bca9f54000f2de7472e8613448e544
  CRC32  b22f54a2
momotaro_ancho_v97.ips
330 bytes modificados
```

Se conservan los 16 cambios de VRAM de la v96 (ya validados en pantalla) y se
añade la lista correcta. La lista vieja `0x2EA45` queda intacta.

### Predicción falsable

- **correcto**: bocadillo de 224 px, 24 caracteres por línea, sin huecos;
- si el texto sale bien pero el marco descuadrado: fallan los `rel` del marco;
- si sigue habiendo huecos: el texto se dibuja con otra lista todavía;
- si desaparece el bocadillo: el repunte a `$5A59` es incorrecto.

---

## (72) v98: posiciones ajustadas y pantalla de título arreglada

### La v97 funcionó

Primera versión con el bocadillo realmente ampliado. David: «¡Enhorabuena!
Casi lo tenemos.» Faltaban ajustes de posición y había una regresión.

### [HECHO] Mi error del ancla

Deduje el ancla del metasprite en X=160 a partir del SATB del save-state, y
**no la revalidé al mover las piezas**. El ancla real es **X=128**. Por eso
todo salió 32 px a la izquierda: el texto empezaba en x=0, pegado al borde.

### [HECHO] Las medidas de David, verificadas

> «las esquinas dejan 11 px libres por el lado izquierdo y 43 por el derecho.
> 11+43 = 54, dividido entre 2 = 27. El bocadillo (que mide 202) tiene que ir
> en X 27.»

Comprobado y correcto:
```
ancho visible = 256 - 11 - 43 = 202 px       <- su cifra
centrado: (11+43)/2 = 27                     <- desplazar +16 px
```
Y cuadra con los sprites: 7 piezas de 32 px = 224 px de los que 202 son
visibles -> 22 px de transparencia, 11 por lado. Exactamente lo que midió.

### Texto: X=35 en vez de X=54

David propuso X=54 para centrar ópticamente la frase. Es correcto **para esa
frase** (19 celdas), pero el motor escribe desde una posición fija y el
presupuesto es de 24 celdas:
```
texto en X=54 -> 24 celdas ocupan 54..245 ; el bocadillo acaba en 228
                 se saldrían 17 px; el máximo real serían 21 celdas
```
Se elige **X=35** (8 px de margen, el que el propio David citó como
correcto). Las frases cortas quedan alineadas a la izquierda en vez de
centradas, pero ninguna puede salirse nunca.

### [RESUELTO] La pantalla de título rota

Causa medida: el bucle `$C000` (banco `0x0D`) llama a `$C2FE`, que cae en
`$C315` = el scroll. Yo había cambiado ahí `LDX #$10 -> #$18`, con lo que
copiaba 512 palabras de más de VRAM -> artefactos y texto duplicado.

`$C000` tiene **20 llamantes** en toda la ROM: es código muy compartido.

**Arreglo: revertir los 5 parches del scroll.** El tutorial no llama a
`$C315`, así que no lo necesita. Verificado que `0x1A315`, `0x1A31D`,
`0x1A32A`, `0x1A332` y `0x1A340` quedan idénticos a la v92.

### [DESCARTADO] La escena de los padres se arregla con estos parches

No: usa **otra lista de sprites** (la que carga `$C189`), que no es
`0x2EA45`. Los tres parches que le había puesto (`0x1A189`, `0x1A18E`,
`0x1A27B`) se revierten también: no servían y añadían riesgo.

### Resultado verificado por programa

```
texto:              X = 35, 67, 99, 131, 163, 195   -> ocupa 35..226
marco:              X = 16 .. 208 (7 piezas)        -> ocupa 16..239
bocadillo visible:  27..228   = 202 px    <- lo que pidió David
margen del texto:   8 px                  <- lo que pidió David
24 celdas acaban en 226 ; el bocadillo en 228 -> CABEN
0 sprites fuera de pantalla
```

### Riesgo residual documentado

`$C298` y `$C388` siguen redirigidos y los comparte el bucle `$C000`. Esas
pantallas pasan a separación `$300` mientras el scroll `$C315` sigue
asumiendo `$200`. **Solo afecta a pantallas que hagan scroll de texto**; el
tutorial no lo hace. Si aparece un descuadre en alguna escena, la solución
es duplicar `$C1AF..$C2AA` en un hueco del banco `0x0D` y que solo el
tutorial use la copia.

### Entrega

```
test_ancho_v98.pce
  MD5    3fc93dc4bb7ba3ebd714a7ca11e454e0
  SHA-1  a534924fd52793352677ce466053a9abc0eea6cd
  CRC32  8f8b6f5e
momotaro_ancho_v98.ips
316 bytes modificados
```

---

## (73) [HECHO] v99: rutina duplicada. Título intacto y 24 celdas

### Los dos problemas de la v98

**1. La pantalla de título seguía rota.** Revertir el scroll no bastaba:
`$C298` (avance de línea) y `$C388` (set cursor) también están en el banco
`0x0D`, y los usa el bucle `$C000`, que tiene **20 llamantes** en toda la ROM.

**2. Al abuelo le faltaban tiles.** Límite del PC Engine: **16 slots de 16 px
por scanline**. Medido con el SATB del state y con la lista nueva:

```
lista original   10 slots
lista v98        14-15 slots   + abuelo/Momotaro/ñordos aparte -> se pasa
```

El hardware descarta los últimos sprites. David lo intuyó sin conocer el
motivo: «perfectamente le sobra un tile». Tenía razón por partida doble: no
solo sobra estéticamente, es que **no cabe en el hardware**.

### La solución: duplicar en vez de redirigir

En el banco `0x0D` hay un hueco de **568 B a `$FF` en `$DDC8`**. Verificado
sin referencias externas reales (los 45 «accesos» del barrido eran relleno
`$FF` desensamblándose como `BBS7`, y los 3 restantes resuelven en sus
propios bancos).

```
$DDC8  copia de $C1AF (intérprete, 91 B)
       con el JMP $C284 -> JMP $DE23
$DE23  copia de $C284 (avance, 39 B)
       con LDA $EC04,X -> LDA $FA1C,X
$F9CC  copia del trampolín $EC0A, llamando a $DDC8
```

Y el tutorial (ROM `0x1D94B`) pasa a llamar a `$F9CC` en vez de a `$EC0A`.

**Verificado intactos**: `$C1AF`, `$C284`, `$C298`, `$C388`, `$C315`, `$C189`
y `$EC0A`. Las otras 20 pantallas no se enteran del cambio.

Las ramas relativas de la copia siguen siendo válidas (comprobado por
desensamblado); los `JMP` absolutos a `$C2AB`/`$C27A`/`$C261`/`$C2B7` apuntan
a rutinas compartidas que no se han movido.

### Slots reducidos

- fuera los **4 sprites laterales** (X=16 y X=208): redundantes, el interior
  blanco lo pintan los propios sprites de texto;
- marco de **6 piezas** en vez de 7.

```
y= 40.. 55  12 slots   (v98: 14)
y= 56.. 71  12 slots   (v98: 14)
y= 72.. 87  12 slots   (v98: 14)
y= 88..103  13 slots   (v98: 15)
```

3-4 slots libres en cada franja para el abuelo y los ñordos, **manteniendo
las 24 celdas**.

### Entrega

```
test_ancho_v99.pce
  MD5    493f08924ebb2a647fb169121b13cf84
  SHA-1  f487680cf3bd201fc052eb81a08202faee6b3df4
  CRC32  df147755
momotaro_ancho_v99.ips
426 bytes modificados
```

```
texto: X = 35, 67, 99, 131, 163, 195   (24 celdas, 35..226)
marco: X = 24, 56, 88, 120, 152, 184   (6 piezas, 24..215)
```

### Predicción falsable

- **correcto**: título OK, abuelo completo, 24 celdas, bocadillo un tile más
  estrecho;
- si el título sigue roto: la causa no es el banco `0x0D`;
- si al abuelo le siguen faltando tiles: hay que bajar a 5 sprites de texto;
- si el tutorial pierde el texto: la copia de `$DDC8` tiene algún salto mal.

---

## (74) [HECHO] v100: 20 celdas, laterales restaurados, bloqueo arreglado

### El bug del bloqueo de la v99

David: «al final del tutorial se queda pillado, el abuelo sigue moviendo la
boca, los controles no responden».

Causa exacta:
```
original  $C1D6  BEQ $C20A      <- manejador de FIN DE TEXTO
copia     $DDEF  BEQ $DE23      <- caia en mi copia del avance de linea
```

Copié 91 bytes (`$C1AF`-`$C209`) y el destino `$C20A` queda **un byte fuera**
del bloque. La rama relativa `+$32` se conservó y acabó apuntando justo a
donde puse el avance duplicado: el `0xFF` de fin de texto nunca se procesaba.

Verifiqué las ramas internas y los `JMP` absolutos, **pero no las ramas
relativas que salen del bloque copiado**.

**Norma 32. Al duplicar un bloque de código hay que clasificar TODAS sus
ramas relativas: las internas se conservan, las que salen del bloque hay que
recalcularlas o encaminarlas por un trampolín.**

Arreglo: un trampolín de 3 bytes detrás de la copia.
```
$DDEF  BEQ $DE4A         (desplazamiento +$59, dentro del alcance rel8)
$DE4A  JMP $C20A
```

### [DESCARTADO] Quitar los laterales del bocadillo

David: «si tu idea era quitarle los laterales, ya te digo yo que queda mal.
El contorno no puede verse truncado en los laterales.» Correcto: restaurados.

### [HECHO] 24 celdas con laterales NO caben en el hardware

```
6 sprites de texto (32 px)  = 12 slots
2 laterales (16 px)         =  2
                              14
+ el abuelo y su baston     =  4-6
                              18-20  >  16   limite del PC Engine
```

Es un techo físico, no un ajuste. Con laterales, el máximo real es **5
sprites de texto = 20 celdas** (12 slots).

La original japonesa tenía 16, así que 20 son **+25%**.

### Geometría de la v100

```
texto      X = 46, 78, 110, 142, 174   ocupa 46..205  (20 celdas)
laterales  X = 30 y 210
marco      6 piezas, X = 28..219
bocadillo  30..225 = 196 px
```

Slots: 12 / 12 / 12 / 13 (antes 14-15). Deja 3-4 libres para el abuelo.

Texto retocado: `¡Pulsa II para saltar` (21) -> `¡Pulsa II y salta` (18).

### Entrega

```
test_ancho_v100.pce
  MD5    b0ddbf68b757ca3802d8fba51b485b0e
  SHA-1  76877059ba13873a242e27b61254ac79c661e01d
  CRC32  e2a1b8ac
momotaro_ancho_v100.ips
425 bytes modificados
```

`$C1AF`, `$C284`, `$C298`, `$C388`, `$C315`, `$C189` y `$EC0A` intactos.

### Pendiente (no tocado a propósito)

- pantalla de título rota: la causa NO es el banco `0x0D` (verificado
  intacto). Hay que buscarla en otro sitio;
- la escena de los padres y el ancho de la intro.

---

## (75) v101: tres ajustes de posición

### El desfase de la segunda línea

David: «la segunda línea de todas las páginas aparece desplazada a la
derecha, unos 39 px de margen en vez de 8».

Causa: la fila 1 del texto arrancaba en `rel 0x14` cuando debe ser `0x16`.

```
base de línea 1 = $6E84  ->  patrón $6E84/32 = $0374  ->  rel $16
lo que puse:     rel $14  ->  patrón $0370  ->  VRAM $6E00
```

Un sprite de desfase = **32 px**. David midió 39−8 = **31**. Coincide.

Al reducir de 6 a 5 sprites por fila en la v100 recalculé los `dx` pero
**no el `rel` inicial de la segunda fila**, que depende de cuántos patrones
consume la primera.

### Los tres cambios

```
1  fila 1 del texto:  rel 0x14 -> 0x16
2  lateral izquierdo: X = 30 -> 29    (-1 px, alinear con las esquinas)
3  lateral derecho:   X = 210 -> 203  (-7 px)
```

### Verificado

```
fila 0: X = 46,78,110,142,174   patrones $035C $0360 $0364 $0368 $036C
fila 1: X = 46,78,110,142,174   patrones $0374 $0378 $037C $0380 $0384
laterales: X = 29 y 203
```

Los patrones iniciales de cada fila coinciden ahora con las bases de línea
de la tabla `$FA1C` (`$6B84` -> `$035C`, `$6E84` -> `$0374`).

### Entrega

```
test_ancho_v101.pce
  MD5    cbb5a908acc3bc02dbad07ec2f647105
  SHA-1  63ad0c0dd551431ebe4b874473bc8f3e050df56e
  CRC32  3fdff7bb
momotaro_ancho_v101.ips
```

---

## (76) v102: bocadillo 8 px más estrecho

### La pregunta de David

> «¿cuánto es lo mínimo que podríamos reducir el ancho del bocadillo?
> ¿Va por múltiplos de ocho?»

**No hay rejilla de 8.** El campo X del SATB es un valor absoluto en píxeles
(0-1023): los sprites se colocan de 1 en 1 px. Lo que va en bloques de 32 px
es el *contenido* de cada pieza, pero las piezas de relleno son un patrón
uniforme (línea negra arriba, blanco debajo) y **pueden solaparse sin que se
note**.

### Su predicción, verificada

> «si reducimos el ancho 8 px, aunque sea montando las piezas, aún sobrarán
> más o menos 8 px de margen a la derecha»

```
frases más largas: 19 celdas, acaban en x=196
con -8 px: interior derecho en x=204  ->  margen 8 px   <- exacto
```

### Detalle detectado al medir

Con -8 px, una línea de **20** celdas acabaría en x=205 y el interior llega a
204: se saldría 1 px. Se resuelve moviendo el texto 1 px a la izquierda, que
además es justo el ajuste del relleno blanco que pidió David.

### Los tres cambios

```
1  texto/relleno   X 46 -> 45    (-1 px)
2  esquina der     X 188 -> 180  (-8 px, solapa 8 px sobre relleno uniforme)
3  lateral der     X 203 -> 195  (-8 px)
```

### Verificado

```
bocadillo exterior: 29..210 = 182 px   (antes 190)
interior:           35..204
19 celdas -> margen 8 px
20 celdas -> margen 0 px, sin salirse
solape esquina/relleno: 8 px sobre relleno uniforme -> invisible
```

### Entrega

```
test_ancho_v102.pce
  MD5    dbab82a296515ee5992b679279eb5c5c
  SHA-1  a25fd41d9c65d99dfe93763a5d8d3c93cbc381fb
  CRC32  23d11dd5
momotaro_ancho_v102.ips
```

### Siguiente paso acordado

Mover texto y bocadillo **en bloque** (sin el rabito) para centrarlos.

---

## (77) v103: bocadillo centrado, texto con 8 px justos

### [DESCARTADO] «El relleno blanco lo pintan sprites de relleno»

David: «el relleno blanco se sale por la derecha 4 px [...] está compuesto
por sprites de 32x16, sólo habría que mover los dos de la derecha».

**No hay sprites de relleno blanco.** El blanco lo pinta el **fondo de los
propios sprites de texto**:

```
texto: X = 45..76, 77..108, 109..140, 141..172, 173..204
                                                  ^ el 5º acaba en 204
línea negra del lateral derecho: x=197-198 (medido en su captura)
```

Mover «los dos sprites blancos» habría desplazado **las letras** de esas 4
celdas 5 px respecto a las demás.

### La causa real

Al recortar 8 px en la v102 dejé el bocadillo más estrecho de lo que necesita
el texto: 160 px fijos (5 sprites de 32) contra 162 px de interior útil, de
los que el lateral se come 8. El 5º sprite de texto tapaba el lateral.

**Norma 33. Antes de recortar un contenedor, comprobar el tamaño MÍNIMO de
su contenido.** El texto no es elástico: son 5 sprites de 32 px, indivisibles.

### La solución

Revertir el recorte y **centrar el conjunto** (la segunda idea de David):

```
              v102        v103
esquinas    28, 180     32, 192      (+4, y sin el recorte de 8)
relleno     60..156     64..160      (+4)
laterales   29, 195     33, 207      (+4)
texto       45          45           (sin mover)
rabito      120         120          (SIN TOCAR, como pidió)
```

### Verificado

```
exterior:  33..222 = 190 px
márgenes:  33 izq / 33 der          CENTRADO
margen del texto: 8 px exactos
texto de 20 celdas acaba en 204; la línea negra del lateral está en 209  OK
slots: 12 / 12 / 12 / 13            dentro del límite
```

### Entrega

```
test_ancho_v103.pce
  MD5    e12dc5e8ee657e685916299b14ada39b
  SHA-1  1bb6a35920297fdc84c3c9bc734fbae31f0071cb
  CRC32  6e624cbb
momotaro_ancho_v103.ips
```

---

## (78) [RESUELTO] La pantalla de título: mi trampolín pisaba un DMA

### La causa

`$F9CC` **no es un hueco libre**. Es el **origen de dos DMA a VRAM**:

```
$F9B2:  TIA $F9CC, $0002, $0040    64 bytes de ceros -> VRAM
$FA8A:  TIA $F9CC, $0002, $0050    80 bytes de ceros -> VRAM
```

Son ceros que el juego vuelca para limpiar tiles. Desde la v99 yo tenía ahí
el trampolín del tutorial (17 bytes de código), así que esos DMA copiaban
**mi código como si fueran gráficos**: artefactos y texto duplicado en la
pantalla de título.

### Lo peor: lo tenía documentado

En la entrada (68) escribí textualmente:

> «Hay 128 B de ceros en `$F9CC`, pero **no todo está libre**: dos `TIA`
> (`$F9B2` y `$FA8A`) lo usan como origen de DMA, `$40` y `$50` bytes. Se
> deja ese tramo intacto y se usa `$FA1C`, fuera de ambas copias.»

Y al construir el trampolín en la v99 usé `0x019CC` (= `$F9CC`) igualmente.
**Me salté mi propia nota**, escrita cinco entradas antes.

**Norma 34. Antes de reutilizar un hueco, releer lo que el diario ya diga
sobre ese hueco.** El diario existe justo para esto.

### El arreglo

```
$F9CC..$FA1B   80 B   origen de los TIA        -> INTACTO, a ceros
$FA1C..$FA21    6 B   tabla de bases de línea
$FA22..$FA4B   42 B   libre -> trampolín (17 B)
```

```
ROM 0x01A22  trampolín: TMA #$40 / PHA / LDA #$0D / CLC / ADC $20 /
                        TAM #$40 / JSR $DDC8 / PLA / TAM #$40 / RTS
ROM 0x1D94B  el tutorial: JSR $EC0A -> JSR $FA22
```

Verificado que `$F9CC..$FA1B` vuelve a ser idéntico a la v92 (80 bytes a
cero).

### Estado del bocadillo (v107, aceptado por David)

> «se ve mucho mejor. Por el lado derecho había demasiado hueco en todas las
> frases. Ahora está más equilibrado visualmente.»

```
exterior   34..221 = 188 px, márgenes 34/34
esquinas   33, 191    relleno 65, 97, 129, 161
laterales  34, 206    texto 50, 82, 114, 146, 178
rabito     120 (sin tocar)
20 celdas por línea (la japonesa tenía 16)
```

### [DESCARTADO] La intro tenía el bocadillo demasiado ancho

David lo retiró tras comprobarlo: el texto corta antes del borde para no
partir palabras y respetar el margen. No hay nada que arreglar.

### Entrega

```
test_ancho_v108.pce
  MD5    e92f91121c2c2c2724e22fb23387ae10
  SHA-1  43e1bf97646d9d4f24de7c71401ef95761448084
  CRC32  c6a8b203
momotaro_ancho_v108.ips
```

### Pendiente

La escena de los padres: usa **otra lista de sprites** (la que carga `$C189`),
todavía sin localizar.

---

## (79) [RESUELTO] La pantalla de título: un terminador $FF pisado

### La bisección de David

Dos ROMs de diagnóstico separando los dos grupos de cambios de la v108:

```
DIAG_v108_solo_sprites  (lista nueva, banco 0x17)     -> titulo MAL
DIAG_v108_solo_rutina   (copia $DDC8 + trampolin)     -> titulo BIEN
```

Concluyente: **la lista de sprites**. Y David añadió el dato que lo cerró:
«no he usado el state de partida guardada. No hacía falta. El problema es de
base.»

### La causa: un byte

Busqué el hueco del banco `0x17` con «el último byte distinto de `$FF`», que
dio `0x2FA58`, y empecé la lista en `0x2FA59`. Pero ese `$FF` **no era
relleno**:

```
lista que empieza en 0x2FA45:
  reg0  0x2FA45  00 06 01 C0 F0
  reg1  0x2FA4A  02 06 01 E0 F0
  reg2  0x2FA4F  04 07 01 00 F0
  reg3  0x2FA54  06 07 01 20 F0
  fin   0x2FA59  FF            <-- SU TERMINADOR
```

`0x2FA45 + 4*5 = 0x2FA59`. Al escribir mi lista encima, esa lista dejó de
terminar y **siguió leyendo mis registros como si fueran suyos**: sprites
basura en pantalla. Y como el intérprete `$E3EB` para en el primer `$FF`, la
lista intrusa se comía también los sprites siguientes, de ahí los textos
descuadrados y las letras cortadas que David vio en las dos DIAG.

**Norma 35. El primer `$FF` tras un bloque de datos no es relleno: es su
terminador.** Un hueco empieza en el byte *siguiente* al terminador, no en
el terminador.

### El arreglo

```
LISTA_NUEVA_ROM  0x2FA59 -> 0x2FA5A
```

Un byte. Verificado:
- `0x2FA59` vuelve a valer `$FF` (idéntico a la v92);
- la lista de `0x2FA45` se lee entera y termina en su sitio;
- el puntero de `$D9B9` apunta a `$5A5A`;
- la geometría del bocadillo no cambia.

### Confirmación independiente del arreglo anterior

David: «esta última versión ha corregido unos artefactos que se veían en el
HUD durante la partida, alrededor de los indicadores de vida y dinero».

Eso confirma que lo de `$F9CC` (entrada 78) era real: esos 80 bytes de ceros
se vuelcan por DMA para limpiar tiles en varios sitios, incluido el HUD, y mi
trampolín los estaba corrompiendo.

### Entrega

```
test_ancho_v109.pce
  MD5    e618d5a111a9ad4326efdf1973b04bab
  SHA-1  02b515853b1677f06168cffdf0171d3433c00796
  CRC32  21624234
momotaro_ancho_v109.ips
```

---

## (80) v109 promocionada. Limpieza del taller

David: «podemos promocionar esta versión y hacer una limpieza prudencial de
las anteriores. Hemos dejado muchas cosas cerradas.»

### Versión de referencia

```
roms/momotaro_es_v109.pce
  MD5    e618d5a111a9ad4326efdf1973b04bab
  SHA-1  02b515853b1677f06168cffdf0171d3433c00796
  CRC32  21624234
```

Verificado que `python3 tools/build_v109.py` la reproduce byte a byte.

### Limpieza

```
antes: Momotaro 11 MB + uploads 14 MB
ahora: Momotaro 11 MB + uploads 12 KB
```

- **roms/**: se conservan solo los eslabones de la cadena (v72, v83, v89,
  v92, v109). Borradas las 16 intermedias del ensanchado (v93-v108) y las
  dos DIAG del título, ya cumplidas.
- **parches/**: solo los 4 vigentes. Los de las versiones revertidas
  (TAM v90, modo v91) a `Antiguas/`.
- **tools/**: los 16 constructores del ensanchado a `Antiguas/`. Borrado
  `descomp_8667F.py`, que implementaba un descompresor que no validó y
  correspondía a una hipótesis descartada (entrada 67).
- **uploads/**: vaciada. Las capturas ya cumplieron su función (están
  medidas y documentadas en el diario); los volcados de VRAM/RAM del
  proyecto Nekketsu y los scripts sueltos, borrados. El material de texto
  del chat original movido a `docs/chat_original/`.
- Borrado `docs/PROMPT_CLAUDE_ensanchado.md`: el encargo quedó superado por
  la investigación propia.

### Balance de la sesión

Resuelto:
- el reset al entrar en CONTINUAR (parche TAM revertido, entrada 61);
- el ensanchado del bocadillo del tutorial, de 16 a 20 celdas;
- los artefactos del HUD (`$F9CC` era origen de DMA, entrada 78);
- la pantalla de título (un terminador `$FF` pisado, entrada 79).

Herramientas nuevas: `dis6280.py` (desensamblador HuC6280 propio) y
`modelo_vram.py`.

Normas nuevas: de la 23 a la 35.

### Pendiente para la próxima

1. escena de los padres (`0x1F366`): usa otra lista de sprites, la de `$C189`;
2. el grueso del guion: mapa, tiendas, objetos;
3. acentos del menú de dificultad;
4. ゲロゲロモード.

---

## (81) v110: escena de los padres traducida y a 20 celdas

### El breakpoint de David lo resolvió

Parando en Work RAM `$00C1` durante la escena de los padres:

```
C189  LDA $EC04 = $84
C18C  STA $C1              <- para aqui
Call Stack: $C051 <- $C000 <- $EB8E
```

**La escena de los padres usa la MISMA tabla `$EC04` y la misma estructura
que el tutorial.** Lo que cambia es la ruta de entrada:

```
tutorial  ->  $D94B  JSR $FA22   (mi copia, separacion $300)
padres    ->  $C02E  JSR $EC0A   (la original, separacion $200)
```

### [DESCARTADO] «$C000 tiene 20 llamantes»

Lo dije en la entrada (72) a partir de un barrido de bytes. Desensamblando
solo en bancos de codigo son **7**, y el resto eran `20/4C 00 C0` dentro de
graficos. Y lo importante: **`$EC0A` tiene UN SOLO llamante** (`0x1A02E`).

Redirigirlo cambia todas las pantallas de esa ruta a la vez, que es lo que
queremos, pero obliga a ampliar tambien sus listas de sprites.

### Listas con base de patron `$0348`

```
$402F  ROM 0x2E02F   ESCENA DE LOS PADRES   4 sprites/fila x 3 = 16 celdas
$CD67  ROM 0x1CD67   otra pantalla          4 sprites/fila x 2 = 16 celdas
$5A5A  ROM 0x2FA5A   TUTORIAL (v109)        5 sprites/fila x 2 = 20 celdas
```

(`$5A00` aparecio en el barrido y era un falso positivo: mi busqueda asocio
mal la carga de `$53/$54`.)

### Errores cazados por la verificacion, antes de escribir

1. **Punteros mal ubicados**: puse `PAD_PTR_LO` en `0x1A2ED` y estaba en
   `0x1A2EA`. El `assert` lo paro.
2. **Los `rel` de cada fila**: use paso `+0x0A` (5 sprites) cuando con
   separacion `$300` el paso es **12 patrones = `+0x18`**. Correcto:
   `0x0A / 0x16 / 0x22`.
3. **El ancla del metasprite**: supuse X=184 y **es X=128** (medido en
   `$C2E2`: `LDX #$80`, `LDY #$18`). Con la suposicion, los `dx` negativos
   se salian del rango `[-128,+127]` y ocho sprites acababan fuera de
   pantalla.

**Norma 36. El ancla de un metasprite se lee del `LDX/LDY` que precede a la
llamada, no se deduce de las posiciones observadas.**

### Los cambios

```
1  0x1A02E   JSR $EC0A -> JSR $FA22     (la ruta $C000 usa la copia)
2  lista padres  0x2E02F -> 0x2FAE2 ($5AE2), 3 filas x 5 sprites, 171 B
3  lista $CD67   0x1CD67 -> 0x1DC88 ($DC88), 2 filas x 5 sprites, 86 B
4  texto         0x1F077 -> 0x1FEA8 ($5EA8), 202 B de 344
```

El texto no cabia en su sitio (202 B contra 149) y detras hay otro bloque
pegado, asi que se reubica y se repunta `0x1A182`, su unico cargador.

### Verificado

```
0 sprites fuera de pantalla
texto     X = 46, 78, 110, 142, 174   -> 20 celdas x 3 filas
bocadillo 30..217 = 188 px            (original 138)
filas alineadas con $FA1C: $6B80 / $6E80 / $7180   (tabla -4)
slots: 12 por scanline (limite 16)
```

Los padres son fondo (BAT), no sprites: no compiten por slots.

### El marcador `0xFB`

En la linea del importe hay tres `0xFB` seguidos antes del `0x24`. El juego
inserta ahi la cantidad en ejecucion (`50`). **Se conservan tal cual.**

El glifo `0x24` **ya es 両**, verificado volcandolo de la fuente
(ROM `0x3DB58`). En el charset la tecla es `$` pero el dibujo es el kanji,
asi que la decision de David («mantenemos 両») ya estaba implementada.

### Texto (de David, ajustado a 20 celdas)

```
p1  ¡Momotaro! ¡Para / vencer a los / demonios necesitas
p2  ¡Momotaro obtiene / [FB][FB][FB]両 obtenidos!
p3  ¡Llévate también / unos kibidango!
p4  ¡Momotaro obtiene / un kibidango!
p5  ¡Momotaro! / ¡Esfuérzate por el / bien de todos!
```

### Entrega

```
test_padres_v110.pce
  MD5    5fae7581d898260dc148a3aee1e4a109
  SHA-1  0f60f240744d3208018048ca2680667d6e700242
  CRC32  5eafc49c
momotaro_padres_v110.ips
464 bytes modificados
```

### Riesgo a vigilar

El cambio 1 afecta a **todas** las pantallas que entran por `$C000`
(7 llamantes). Si alguna usa una lista de sprites distinta de las tres
localizadas, su texto saldra con huecos. Hay que mirar el juego entero.

---

## (82) [DESCARTADA la v110] Corrección de método de David, y la v111

### Lo que rompió la v110

David: intro enlazando con el texto de los padres, segunda línea a mitad de
renglón, residuos de la tercera línea durante cinco páginas, texto
sobrescrito, y el mapa sin texto con el sprite de ubicación medio borrado.

Causa: redirigí `JSR $EC0A` (ROM `0x1A02E`), que está **dentro de `$C000`**,
el bucle de escena genérico. Todas las pantallas de diálogo pasaron a
separación `$300` mientras sus listas de sprites seguían cubriendo `$200`.

### La corrección de método

> «lo estás enfocando mal al decir que vas a medir cuántas pantallas hay que
> arreglar. Lo correcto es partir siempre de la versión que está bien y
> encontrar el modo de no cometer fallos que haya que arreglar después.»

Tiene razón, y señala el fallo exacto: **cambié una ruta compartida y luego
fui a arreglar los daños**. En la v109 lo hice bien sin darme cuenta (no
toqué `$EC0A`, dupliqué la cadena, y lo demás quedó intacto *por
construcción*). En la v110 hice justo lo contrario.

**Norma 37. Un cambio debe ser seguro por construcción, no por
comprobación.** Si hay que enumerar qué se rompe, el enfoque ya es malo.

### [HECHO] El discriminante de escena: `$269D`

`$E378` empieza con `STA $269D`: guarda el identificador de la escena.
Llamantes y sus identificadores (desensamblado en bancos de código):

```
$EBD8  LDA #$63   <- ESCENA DE LOS PADRES
$EBF4  LDA #$63   <- ESCENA DE LOS PADRES (segunda entrada)
$FBA0 #$46   $FD9D #$45   $FDB9 #$59   $FDFB #$5C   $FE0F #$5C
$C03A #$5D   $C03D #$5A   $DE63 #$5C   $CA0D #$4B   $D696 #$4A
```

**`$63` es exclusivo de la escena de los padres.**

### La bifurcación (13 bytes en `$FA33`)

```
ROM 0x1A02E:  JSR $EC0A  ->  JSR $FA33

$FA33:  LDA $269D
        CMP #$63
        BEQ $FA3D
        JMP $EC0A      <- ruta original, byte a byte la de siempre
$FA3D:  JMP $FA22      <- la copia con separación $300
```

Cualquier escena que no sea la de los padres ejecuta **el mismo `JMP $EC0A`
de siempre**. No hay nada que verificar: es el mismo código.

### Los otros dos cambios, ya locales

```
lista de sprites  0x2E02F -> 0x2FAE2 ($5AE2), 3 filas x 5 sprites, 171 B
texto             0x1F077 -> 0x1FEA9 ($5EA9), 202 B de 343
```

El texto se pone en `0x1FEA9`, no en `0x1FEA8`, dejando un `$FF` de guarda:
en la v110 la intro enlazaba con este bloque por estar pegado detrás.

La lista `$CD67` **ya no se toca**: su pantalla no es la de los padres y
sigue por la ruta original.

### Verificado

```
0 sprites fuera de pantalla
texto      X = 46,78,110,142,174 -> 20 celdas x 3 filas
bocadillo  30..217 = 188 px (original 138)
filas alineadas con $FA1C: $6B80 / $6E80 / $7180
INTACTOS: $EC0A, lista $CD67, texto original, copia $DDC8,
          trampolin $FA22, lista del tutorial
```

### Entrega

```
test_padres_v111.pce
  MD5    c13eb44f4a5beebab1997a3bd551e767
  SHA-1  3e35f9d7403bd343cd4d1dcdc47e337d33b1e50a
  CRC32  bdc69b06
momotaro_padres_v111.ips
390 bytes modificados
```

### Predicción falsable

- **correcto**: los padres a 20 celdas; intro, mapa, tutorial y demás
  escenas exactamente como en la v109;
- si alguna otra pantalla falla: `$269D` no es el discriminante que creo;
- si los padres siguen a 16: el `CMP #$63` no se cumple en esa escena;
- si el bocadillo sale descuadrado: la geometría, no la ruta.

---

## (83) v112: el texto de David, sin retocar, y los ajustes de posición

### Mi error en la v111

David: «el texto se desajustó cuando dibuja la tercera línea "demonios
necesitas dinero" [...] mi propuesta no era así».

Tenía razón: **cambié su texto sin decírselo**. Él escribió

```
¡Momotaro! ¡Para / vencer a los demonios / necesitarás dinero!
```

y yo lo reparticioné como `vencer a los` / `demonios necesitas`, dejando una
línea de 18 celdas que, con el bocadillo aún en la geometría vieja,
desbordaba y arrastraba el resto: líneas empezando a mitad de renglón,
residuo de la tercera línea durante las cinco páginas, palabras pegadas.

**Norma 38. El texto del director no se reparticiona sin avisar.** Si una
línea no cabe, se dice y se acuerda la alternativa; no se recorta por
cuenta propia.

Medido su texto original: de 12 líneas, **solo una** se pasaba de 20, y por
un carácter (`vencer a los demonios`, 21). Acordamos `vencer a los ogros`
(18).

### Los tres ajustes de posición

Tal como los pidió:

```
              v111    v112
esquinas    29,189   32,192   (+3)
relleno     61..157  64..160  (+3)
lateral izq  30       33      (+3)
lateral der 202      203      (+1)
texto        46       45      (para dejar 8 px de margen)
rabito      120      120      (sin tocar)
```

### Verificado

```
bocadillo   33..218 = 186 px ; márgenes 33 izq / 37 der
margen del texto: 8 px exactos
20 celdas acaban en 204; la línea negra del lateral está en 205  OK
0 sprites fuera de pantalla
INTACTOS: $EC0A, $CD67, texto original, copia $DDC8, lista del tutorial
```

Texto en la ROM, releído desde los bytes:

```
¡Momotaro! ¡Para / vencer a los ogros / necesitarás dinero!
¡Momotaro obtiene / ###両 ryos!
¡Llévate también / unos kibidango!
¡Momotaro obtiene / un kibidango!
¡Momotaro! / ¡Esfuérzate por el / bien de todos!
```

(`###` son los tres `0xFB` donde el juego inserta la cantidad.)

### Entrega

```
test_padres_v112.pce
  MD5    dc4b1ad631c9e6b5987a1d309870ae57
  SHA-1  bc611d1b0ca330b7512477517583eef29b9f72e1
  CRC32  9b7484a1
momotaro_padres_v112.ips
392 bytes modificados
```

---

## (84) [RESUELTO] El descuadre al pasar de página: el SCROLL. v113

### La observación de David que lo localizó

> «las tres primeras líneas, es decir, el texto de la primera página, se
> muestra correctamente, pero justo al terminar aparece la flecha para
> continuar y se descuadra todo»

La flecha marca el fin de página, y ahí `$C000` llama a `$C2FE` (ROM
`0x1A034`), que cae en `$C315`: **el scroll**.

```
$C315  lee $EC04/$EC06  (separacion $200)
       LDX #$10 / LDY #$40 = $400 palabras = 2 lineas de $200
```

Con el texto ya a separacion `$300`, el scroll copia el bloque equivocado.
Y la primera pagina se ve bien porque **todavia no ha habido scroll**.

### [DESCARTADO] «Se dibuja la lista de sprites vieja»

Lo afirme al medir el bocadillo en 44..211 cuando mi lista daba 33..218.
**Falso**: no conte la transparencia de los bordes de las piezas. Con las
esquinas en 32 y 192 y ~12 px transparentes sale 44..208, que es lo que
David midio. La lista nueva SI se usa y sus ajustes de posicion estaban
aplicados.

### El arreglo: duplicar tambien el scroll

Mismo patron que el intérprete: copia propia + despachador por `$269D`.

```
$DE4D  copia de $C2FE..$C394 (151 B), con:
         $EC04/05/06/07 -> $FA1C/1D/1E/1F
         LDX #$10 -> #$18    ($400 -> $600, 2 lineas de $300)
         LDY #$08 -> #$0C    (limpia $300 en vez de $200)
         los dos JMP $C394 -> JMP $DEE3 (el RTS de la copia)
$DEE4  despachador: LDA $269D / CMP #$63 / BEQ / JMP $C2FE / JMP $DE4D
ROM 0x1A034: JSR $C2FE -> JSR $DEE4
```

Los dos `JMP $C394` eran absolutos y apuntaban **dentro** del bloque
copiado: recalculados a `$DEE3`. Es la norma 32 aplicada a tiempo.

### Un susto en la verificacion

Mi script desensamblaba desde `+0x42` y `+0x58`, que son los **operandos**
de `LDX`/`LDY`, no los opcodes (que estan en `+0x41` y `+0x57`). Salia
`CLC` y `TSB` y parecia que el parche estaba mal. Los `assert` del
constructor si estaban bien puestos.

**Norma 39. Al verificar un byte parcheado, desensamblar desde el OPCODE,
no desde el operando.**

### Verificado

```
copia $DE4D: LDA $FA1C/1D/1E/1F, LDX #$18, LDY #$0C, JMP $DEE3, RTS en $DEE3
despachador $DEE4 -> $C2FE (original) o $DE4D (copia)
INTACTOS: scroll original $C2FE, $EC0A, lista $CD67, texto original,
          copia $DDC8, lista del tutorial, tabla $EC04
```

### Entrega

```
test_padres_v113.pce
  MD5    a771d500a25aa6287eaa2b22ed9365cc
  SHA-1  869084f5ecb57871cd1f945e805bd2179e578cf6
  CRC32  071c9b4f
momotaro_padres_v113.ips
556 bytes modificados
```

---

## (85) [RESUELTO] El renglón vacío: un `0x00` de más. v117

### La ROM virgen, por fin en el workspace

David aportó el enlace. `roms/Momotarou Katsugeki (Japan).pce`,
MD5 `ec7358edb3672a8aa8850623eec72a71` — la esperada. Con ella se puede
comparar contra el original en vez de deducir.

Primera comprobación: el scroll `$C2FE`, la tabla `$EC04` y la lista `$402F`
son **idénticos** en la virgen y en nuestra v109. Partimos de código intacto.

### [DESCARTADO] «El renglón vacío es culpa del scroll»

Estuve dos versiones ajustando cuánto limpia el scroll (`LDY #$08` -> `#$0C`
-> `#$0A` -> `#$0F`). Ninguna lo arreglaba, porque **la causa no estaba ahí**.

### [HECHO] La causa: mi codificación del texto

```
original japonés:   ... db b3 21 a3 FC        <- fin de página directo
mi codificación:    ... b2 af 21 F0 00 FC     <- un 0x00 de más
```

Ese `0x00` es fin de línea: `$D1A0` hace `INC $3CE3` y el contador pasa a la
línea 4. Después el scroll (`$C2FE`) comprueba `$3CE8` y, al verlo distinto
de cero, **sube todo un renglón**. De ahí que la tercera línea desapareciera
justo al aparecer la flecha.

Yo generaba `0xF0 0x00 0xFC` por simetría con el tutorial, sin comprobar cómo
lo hace el original en **este** bloque.

**Norma 40. Los códigos de control se copian del bloque original que se está
sustituyendo, no de otro bloque parecido.**

### Los tres cambios de la v117

```
1  fin de página:  F0 00 FC  ->  F0 FC     (quitado el 0x00)
2  limpieza del scroll: LDY #$0F -> #$0A   (10 patrones = una línea de 20)
3  línea del importe: tres 0xFB -> dos
```

El punto 3 es el sangrado que detectó David comparando `50 ryos!` con
`un kibidango!`: los tres `0xFB` reservan 3 dígitos y la cifra sale alineada
a la derecha, dejando un hueco delante. Con dos bastan para `50`.
**Si algún importe del juego llegara a 3 cifras, habría que volver aquí.**

### Verificado

```
estructura de control idéntica al original: carácter + F0 + FC, sin 0x00
texto: ¡Momotaro obtiene / ## ryos!
INTACTOS: scroll original, $EC0A, $CD67, texto original, copia $DDC8,
          lista del tutorial
```

### Entrega

```
test_padres_v117.pce
  CRC32  b20f1e51
momotaro_padres_v117.ips
559 bytes modificados
```

---

## (86) v118: tres `0xFB` (corrección) y el bocadillo 2 px arriba

### [DESCARTADO] «Con dos `0xFB` basta para una cifra de dos dígitos»

Lo hice en la v117 para quitar la sangría. **Error.** David midió el
resultado: salía `5 ryos!`, no `50`. Se perdía un dígito.

Los `0xFB` **no son un hueco donde quepa la cifra: el juego escribe un
dígito por cada `0xFB`**. Con tres, la cantidad sale alineada a la derecha
en tres celdas (` 50`), y esa sangría es **inherente al formato**, no un
fallo que se pueda quitar reduciendo marcadores.

Revertido a tres. La sangría se queda.

**Norma 41. Un marcador de sustitución no se recorta sin saber cómo lo
consume el juego.** Aquí «tres huecos» significaba «tres dígitos», no
«sitio para un número».

### El bocadillo, 2 px arriba

David: «el rabillo está tocando la imagen, e incluso se le oculta la punta
detrás. En la pantalla del error de password ya hicimos un cambio respecto
al original, al mover el bocadillo para que la estatua Jizo no solapara el
rabillo.»

Buen precedente y buen criterio. Se sube **todo el metasprite** cambiando el
ancla Y, que es un solo byte:

```
$C2E4:  LDY #$18 (24)  ->  LDY #$16 (22)     ROM 0x1A2E5
```

Mueve marco, laterales, rabito y texto a la vez, que es justo lo pedido.

Sobre la flecha: **no está en esta lista** (David la localizó en el Sprite
Viewer como sprite 8, patrón `$1A3`, aparte). La dibuja otra rutina, así que
habrá que mirarla si queda descolgada.

### Verificado

```
LDY #$16 ; filas Y = 22,38,54,70,86  (antes 24,40,56,72,88)
rabito Y=86 (antes 88)
línea del importe: fb fb fb 3c "ryos!"
INTACTOS: scroll original, $EC0A, $CD67, texto original, copia $DDC8,
          lista del tutorial, ancla X
```

### Entrega

```
test_padres_v118.pce
momotaro_padres_v118.ips
561 bytes modificados
```

---

## (87) v119: bajar la imagen en vez de subir el bocadillo

### La idea de David

> «Volvemos a bajar el bocadillo y el texto 2 px, donde estaban, y lo que
> bajamos 2 px es la imagen inferior, que además tiene más espacio libre
> debajo que el bocadillo encima.»

Mejor solución que la mía, y por un motivo concreto: **la flecha no está en
la lista del bocadillo**. La dibuja otra rutina (David la localizó en el
Sprite Viewer como sprite 8, patrón `$1A3`), probablemente compartida con
otras pantallas. Subir el bocadillo la habría dejado descolgada y arreglarla
habría obligado a duplicar otra rutina más.

Bajar la imagen no toca la flecha en absoluto.

### [HECHO] La imagen es un metasprite propio y exclusivo

```
$C126  dibuja la imagen de los padres
       ancla: LDX #$80 (128), LDY #$60 (96)   en $C12D/$C12F
       lista $4000 (ROM 0x2E000), base de patron $0280, 8 sprites
```

**`$C126` tiene UN SOLO llamante** (ROM `0x1A025`, dentro de `$C000`). El
cambio es local por construcción: ninguna otra pantalla usa esa rutina.

### El cambio: un byte

```
ROM 0x1A130:  LDY #$60 (96)  ->  LDY #$62 (98)
```

Y se revierte la subida del bocadillo de la v118 (`$C2E4` vuelve a
`LDY #$18`).

### Verificado

```
bocadillo, filas Y: 24,40,56,72,88   (como en la v109)
rabito hasta Y=103
imagen, filas Y:    98,130,162       (antes 96,128,160)
separacion rabito-imagen: 2 px mas que antes
INTACTOS: scroll original, $EC0A, $CD67, texto original, copia $DDC8,
          lista del tutorial, ancla Y del bocadillo
```

### Nota sobre los marcadores `0xFB`

David preguntó si al quitar el kanji se había eliminado un `0xFB`. **No**:
lo que se quitó fue el `0x24` (el glifo 両). La v118 y la v119 tienen los
**tres** `0xFB` del original.

Su intuición sobre los importes grandes es correcta y conviene anotarla:
**tres `0xFB` = tres dígitos (hasta 999)**. Si algún bloque del juego maneja
cantidades de 4 cifras, tendrá cuatro `0xFB`, y al traducirlo hay que
contarlos y conservarlos todos. No están ligados a una línea concreta: van
en el flujo de texto, así que se pueden reagrupar las líneas siempre que el
orden se respete.

---

## (88) La flecha: NO es compartida. Y el asunto de los `0xFB`, cerrado

### David tenía razón: yo suponía sin comprobar

> «¿No te resulta raro que en cada parte del juego en la que vuelva a
> aparecer tenga que tener exactamente las mismas coordenadas? Igual estamos
> suponiendo algo que no es.»

Suponía. Medido:

```
$C149  (ROM 0x1A149)  dibuja la flecha
   LDA $3CE7 / BEQ (si no hay flecha pendiente, sale)
   LDX #$B8 (184) / LDY #$50 (80)   <- ancla PROPIA, en $C155/$C157
   lista $4029 -> ROM 0x2E029, UN SOLO sprite (rel 03, dx=0, dy=0)
```

**`$C149` tiene UN SOLO llamante** (ROM `0x1A028`) y **una lista propia**.
Cada pantalla dibuja su flecha con su rutina y su ancla: no hay coordenadas
globales. Se puede mover sin afectar a nada más.

(Esto explica también por qué la lista `$4029` me parecía «de un solo
sprite» cuando la examiné en la entrada 81: es que lo es. Era la flecha.)

### [NO EJECUTADO] Mover la flecha

Calculé `LDX #$B8 -> #$C4` (+12 px) y al verificarlo salía en pantalla en
228..243, con el borde del bocadillo en 222: **fuera de la caja**.

La relación original era: flecha acabando 17 px antes del borde interior.
Con nuestro bocadillo (borde en 222) tocaría empezar en ~190, o sea ancla
`$9E`. Pero eso depende del offset global que `$EE86` suma (`$35`-`$38`), que
no he medido: lo deduje de una captura del Sprite Viewer.

**No se toca.** Queda localizado el byte exacto (`ROM 0x1A156`) para cuando
David mida en pantalla cuántos píxeles hay que moverla.

### El asunto de los `0xFB`, cerrado

Razonamiento de David, correcto:

> «para que viéramos 50 ryos sin esa sangría, realmente tendríamos que
> obtener 500 y borrar el último [FB]. Pero seguiríamos habiendo obtenido
> 500. Vamos, que ajo y agua.»

Exacto. Los tres `0xFB` son **tres posiciones de dígito** que el juego
rellena alineando a la derecha. La sangría es el relleno de la posición de
las centenas cuando la cifra tiene dos dígitos. Quitar un `0xFB` no quita el
hueco: quita un dígito.

La única forma de eliminarla sería modificar la rutina que sustituye los
`0xFB` para que alinee a la izquierda, y eso afectaría a todos los importes
del juego. **No compensa.** Se queda como está.

---

## (89) v121: flecha +11 px. Y la pregunta de David sobre el alineado

### La flecha

David midió en pantalla: 11 px a la derecha.

```
ROM 0x1A156:  LDX #$B8 (184)  ->  LDX #$C3 (195)
```

Un byte. `$C149` tiene un solo llamante y lista propia (`$4029`), así que es
local por construcción.

Antes había calculado +12 y al verificarlo la flecha salía en 228..243 con
el borde del bocadillo en 222: **fuera de la caja**. No la moví y pedí la
medida. Bien hecho: el cálculo dependía de un offset global que yo había
deducido de una captura, no medido.

### [HECHO] La pregunta de David sobre cambiar el alineado

> «¿estamos seguros de que no compensa? ¿nos encontraremos más situaciones
> en las que ese hueco al principio nos perjudique?»

Buena pregunta, y la respuesta cambia mi recomendación anterior. Medido
sobre la ROM virgen, buscando `0xFB` **dentro de bloques de texto reales**
(no bytes sueltos en código o gráficos):

```
0x1F0A6 (banco 0x0F)  3 marcadores   <- la escena de los padres
                                        y NINGUNO MAS en toda la ROM
```

**En todo el juego hay un solo grupo de marcadores `0xFB`.**

Los demás textos con dinero (`0x48CF0`) llevan el glifo 両 (`0x24`) pero
**sin marcadores**: la cifra va escrita en el propio texto.

```
ももたろうは100両を てに いれた
ももたろうは50両を  てに いれた
ももたろうは30両を  てに いれた
ももたろうは10両を  てに いれた
ももたろうは80両を  てに いれた
ももたろうは20両を  てに いれた
```

Seis variantes fijas, una por importe. Ahí no hay sangría posible: el
número está escrito.

### Conclusión, corrigiendo lo que dije antes

Dije que cambiar la rutina de alineado «afectaría a todos los importes del
juego». **Falso**: afectaría a **uno solo**, y es precisamente éste.

Aun así **sigo recomendando no tocarla**, pero por otro motivo: el beneficio
es cosmético (un hueco de 8 px en una línea de una pantalla) y el coste es
modificar una rutina del motor de texto sin saber todavía dónde está. Si
algún día molesta, ahora sabemos que el impacto sería mínimo.

**Norma 42. «Afecta a todo el juego» hay que contarlo, no suponerlo.**

### Entrega

```
test_padres_v121.pce
momotaro_padres_v121.ips
```

---

## (90) v122: flecha +14 px y la prueba de los `0xFB`

### La flecha

```
ROM 0x1A156:  LDX #$B8 (184)  ->  LDX #$C6 (198)
```

11 px de la v121 + 3 mas que pidio David, alineandola con el inicio de la
curva de la esquina. Referencia suya: en otros bocadillos del juego la
flecha esta incluso en plena esquina.

### La idea de David sobre los `0xFB`

> «Si dices que en otras partes del juego el dinero solo es texto, solo
> tendriamos que cargarnos esos tres [FB] y poner 50 en su lugar. Luego
> comienzo una partida y miro si tengo ese dinero.»

Es la prueba correcta y es trivial. Y tiene fundamento: en `0x48CF0` hay
**seis variantes con la cifra escrita en el texto**, sin marcadores:

```
ももたろうは100両を てに いれた
ももたろうは50両を  てに いれた
ももたろうは30両を  てに いれた
ももたろうは10両を  てに いれた
ももたろうは80両を  てに いれた
ももたろうは20両を  てに いれた
```

Si el juego resuelve asi los demas importes, es plausible que los `0xFB` de
la escena de los padres sean solo formato.

### La prueba

Los tres `0xFB` sustituidos por el texto literal `50`:

```
antes:  FB FB FB 3C "ryos!"     ->   " 50 ryos!"  (con sangria)
ahora:  "50" 3C "ryos!"         ->   "50 ryos!"   (sin sangria)
```

Verificado: **no queda ningun `0xFB` en el bloque**.

### Que mirar

**Empezar partida, pasar la escena, y comprobar el dinero:**

- **50 ryos** -> los `0xFB` eran solo formato. Sangria eliminada, cerrado.
- **0 ryos**  -> los `0xFB` **dan** el dinero (o disparan la rutina que lo
  suma). Hay que devolverlos y aceptar la sangria.

Una tercera posibilidad a vigilar: que el dinero se otorgue igual (por otra
rutina) pero el texto muestre `50` fijo aunque el importe real cambie con la
dificultad. Conviene comprobarlo en dos modos distintos si es posible.

### Entrega

```
test_padres_v122.pce
momotaro_padres_v122.ips
```

---

## (91) v123: la pantalla de carga con dos partidas — el "uá" era esto

### El diagnóstico equivocado (dos veces)

**Primer error.** Dije que la causa era que `$EBF4` usa `LDA #$63` igual que
la escena de los padres, y que por eso la pantalla de carga entraba por mis
despachadores y usaba separación `$300`. **[DESCARTADO]**: en el save-state
del bug `$269D = $46`, no `$63`. Mi condición `CMP #$63` no se cumple nunca
ahí. Tenía el state en disco desde el principio y no lo miré.

**Segundo error.** Dije que la v109 había reescalado la tabla `$C5AC` de
`$140` a `$200` "sin comprobar que esa pantalla tiene geometría propia", y
propuse revertirla. **[DESCARTADO]**: David me mandó al log antes de tocar
nada. Ese reescalado es el arreglo del solape de la pregunta (v15), y la
limpieza `#$2A` (v58) es su pareja. Iba a revertir la solución de un bug
anterior.

**Tercer error.** Conté las filas de la lista (2 en la v109, 5 en la virgen)
y concluí que faltaban tres. **[DESCARTADO]**: no crucé la lista con el
presupuesto de CG de cada ranura.

### [HECHO] La causa real

Presupuesto de CG, medido:

```
slot0 (pregunta) $7008 -> $7408 : $400 = 16 celdas = 256 px
slot1 (partida1) $7408 -> $7608 : $200 =  8 celdas = 128 px
slot2 (partida2) $7608 -> $7808 : $200 =  8 celdas = 128 px
slot3            $7808 -> $7A08 : $200 =  8 celdas = 128 px
slot4            $7A08 -> $7C08 : $200 =  8 celdas = 128 px
```

La lista `$5C05` daba **cinco** sprites de 32 px (160 px) a la fila de la
partida. El quinto (`pat_rel $18`) lee VRAM `$7600` = **slot 2**.

Volcado de `$7608` en el save-state: contiene `NORMAL 1` entero y bien
escrito. **La segunda partida nunca estuvo rota.** El quinto sprite de la
fila 1 estaba mostrando el CG de la segunda partida — de ahí el `NOM`
cortado al final de la línea de `FÁCIL 1`.

### [HECHO] El "uá" de la v45

Los sprites idx 0/7/8/9 (`pat_rel $01`, `dx = -17`, los cuatro superpuestos)
eran esos invasores, aparcados sobre el "uá" de "Cuál" para esconderlos.

Intuición de David, confirmada por medición:

> «Claramente ese bloque no está donde debería. Comenzó a verse cuando
> ensanchamos la ventanilla del texto para que no se cortara.»

Exacto. Al pasar de 3 a 5 sprites por fila (v15), el quinto se salió de su
ranura. La v45 los escondió en vez de recolocarlos. David ya dijo entonces
que no era la mejor solución y que daría problemas: los dio en cuanto
guardó una segunda partida.

### Medición de las dos capturas

|                        | japonesa      | v109          |
|------------------------|---------------|---------------|
| caja negra             | x 81..174     | x 33..222     |
| filas con texto        | y 62,78,94    | y 64,80       |
| separación             | 16 px         | 16 px         |
| pregunta               | —             | 166 px        |

`MUY DIFÍCIL 1` (caso peor) ≈ 104 px < 128. Cabe en 4 sprites.
El bocadillo **no** hay que tocarlo: lo determina la pregunta, no las
partidas. Criterio de David, verificado.

### El arreglo (opción A)

Filas de partida a **4 sprites de 32 px = 128 px**, justo lo que tiene
asignado cada ranura. No se mueve ningún destino de CG.

```
0x1FF6F  lista nueva $5F6F, 22 registros (6 pregunta + 4x4 partidas)
0x1FBAA  puntero $5BA6[2]  $5C05 -> $5F6F
0x1FBAC  puntero $5BA6[3]  $5C05 -> $5F6F
0x1A471  limpieza CG  CPY #$2A -> #$30   ($7000..$7BFF exacto)
```

Filas Y = 56, 72, 88, 104, 120. Pregunta X = 44..204 (6 sprites).
Partidas X = 51, 83, 115, 147 (4 sprites).

La limpieza sube a 48 iteraciones = `$7000..$7BFF`. **No más**: en `$7C00`
hay datos (bloques sólidos, medidos en el save-state).

### La norma 35, otra vez

El constructor abortó: iba a poner la lista en `0x1FF6E`, que es el `$FF`
**terminador** del texto de los padres, no relleno. El hueco empieza en
`0x1FF6F`. La verificación lo cazó antes de escribir la ROM.

**Norma 43. Un sprite que "sobra" no sobra: es una fila que se ha quedado
sin sitio, o uno que se ha salido de su ranura. Antes de aparcarlo, medir
el presupuesto de CG de la fila.**

**Norma 44. Contar los elementos de una lista no basta: hay que cruzarlos
con el espacio que cada uno tiene asignado.**

### Verificación

Releída la lista desde la ROM construida, siguiendo el puntero:
los 22 sprites caen **dentro** de su ranura de CG. Ranuras de 16 px por
scanline: 11 / 8 / 8 / 8 / 8 (límite 16).

Intactos: destinos CG `$C5AC`, tablas `$DC84`/`$C5E4`, lista vieja `$5C05`,
texto de los padres, intro, tutorial, despachadores.

### Entrega

```
test_carga_v123.pce   MD5 8f1c6553770428a83e216096dddb403d
momotaro_carga_v123.ips
114 bytes en 3 rangos
```

### Qué mirar

1. **Con las dos partidas**: `FÁCIL 1` y `NORMAL 1`, cada una en su línea
   (y=72 e y=88), sin `NOM` suelto al final de la primera.
2. **El "uá"**: ya no existe como apaño. Comprobar que no aparece nada raro
   sobre "Cuál" en ningún frame del parpadeo.
3. **El parpadeo** de la partida seleccionada debe seguir funcionando.
4. Password incorrecto -> volver a la carga: sin artefactos (era el v58).

---

## (92) v124: el botón II condicional — el juego ya lo hacía

### El encargo de David

> «Si entras en CONTINUAR y no tienes partida guardada, accedes directamente
> a la pantalla de passwords. Si tienes partida guardada, accedes al
> selector. [...] Se me ocurrió que se podría implementar un condicional
> para que supiera si tienes partida guardada o no.»

El chat anterior lo intentó ocho veces y acabó dejando "salir siempre al
título" (v66), que evita el bug pero pierde la ruta buena.

### [HECHO] Por qué fallaron los ocho intentos

Todos leían un flag **por su cuenta** desde dentro del stub:

```
v50  LDA $3802        con MPR1=$F8 eso es BRAM $1802: basura.
                      Beetle daba 0, Mesen 0B -> rutas distintas.
v59  LDA $2040        MPR1 no es $F8 en ese instante.
v63  + MPR1 forzado   se colgaba en Mesen.
v64  + SEI + temps    se colgaba igual (no era la IRQ).
v65  + pila y X       no colgaba, pero iba siempre al selector.
```

Causa común: el stub corre en un contexto donde el mapeo de bancos no es el
que el flag necesita, y la RAM sin inicializar difiere entre emuladores.

### [HECHO] El hallazgo: no hay que leer ningún flag

El dispatcher maestro `$EA77` (banco 0x00, MPR7, siempre mapeado) **ya trae
la bifurcación hecha**:

```
$EA87  JSR $EAE6      ; ¿hay partida guardada?
$EA8A  BCC $EA94      ;   carry claro -> NO -> se salta el selector
$EA8C  JSR $FBB3      ;   carry puesto -> SÍ -> SELECTOR
$EA8F  LDA $3811
$EA92  BNE $EA4A
$EA94  JSR $FC18      ; password
```

Y `$EAE6` devuelve el carry:

```
$EB2A  SEC ; RTS      <- hay partida (contó slots, $380A = Y != 0)
$EB33  CLC ; RTS      <- no hay
```

Esa decisión se ejecuta **cada vez que entras en CONTINUAR**: es justo la que
manda al selector si tienes partida y al password si no. Está probada por el
propio juego en cada arranque, en su contexto y con su mapeo.

Además `$EAE6` **no ejecuta ningún TAM** (verificado recorriendo sus 79
bytes), y sus ayudantes `$E9E4`/`$E9F5` se guardan y restauran MPR6 ellos
mismos. No hay que tocar MPR1 ni forzar nada: ese era el error de v59-v65.

### Dos fallos míos, cazados desensamblando

**1. Bucle infinito.** Mi primer stub saltaba a `$DCED` en la rama "con
partida". Pero `$DCF9` (donde había puesto el gancho) está **dentro** de
`$DCED`: volver allí re-ejecuta el gancho entero. Lo vi al desensamblar el
bloque completo, no el trozo. Norma 39.

**2. Parcheé una ruta muerta.** Puse el gancho en `$DCF9` dando por hecho que
era la ruta activa. Medido:

```
ACTIVA:  $C992 -> $DC1A -> $DC2C -> JMP $FF5A -> JMP $E000
MUERTA:  $DCED ... $DCF9 JMP $EA8C
         único llamante de $DCED = $FF62, dentro de la parte
         inalcanzable del propio stub viejo
```

El v66 dejó un `JMP $E000` al principio de `$FF5A`, cortocircuitando el resto
del stub de v50. Parchear `$DCF9` no habría hecho **nada**. Es la norma 24
("antes de dar por libre una dirección, comprobar quién le hace JSR")
aplicada al revés: antes de parchear una dirección, comprobar que alguien la
ejecuta.

**Norma 45. Antes de parchear una ruta, comprobar que está viva: buscar sus
llamantes reales, no suponer cuál se ejecuta.**

### El stub (sustituye al de v50/v66, mismo sitio)

```
$FF5A  20 E6 EA   JSR $EAE6     ; el juego decide (carry)
$FF5D  90 06      BCC $FF65     ; sin partida -> título
$FF5F  A2 FF      LDX #$FF      ; pila limpia para el selector
$FF61  9A         TXS
$FF62  4C 8C EA   JMP $EA8C     ; con partida -> selector
$FF65  4C 00 E0   JMP $E000     ; sin partida -> título
```

Las dos ramas son rutas **ya validadas por David** en Mesen y Beetle:
`$EA8C` -> `JSR $FBB3` -> selector (lo que hacía v62) y `$E000` -> título (lo
que hacía v61). Lo único nuevo es quién elige, y eso lo hace el juego.

El `JSR $EAE6` se ejecuta **antes** del `TXS`, con la pila del password, que
es válida. El `TXS` sólo se hace en la rama del selector, que es la que lo
necesita.

### Entrega

```
test_boton2_v124.pce   MD5 63cec5fb304bf6104f5efd9e0e70889b
momotaro_boton2_v124.ips
10 bytes, un solo rango (0x01F5A..0x01F67)
```

Intactos: `$DCED` (ruta muerta), dispatcher `$EA77`, rutina `$EAE6`, lista de
la carga v123, texto de los padres.

### Qué mirar

1. **Con partida** (tu srm): password -> II -> **selector** CANTO/CARGAR.
2. **Sin partida** (srm vacío): password -> II -> **título**.
3. Que en el caso 2 no haya forma de llegar a CARGAR.
4. Probar en **Mesen y Beetle**: aquí está la clave, porque los intentos
   anteriores divergían entre emuladores. Este no lee RAM sin inicializar,
   así que no debería divergir.

---

## (93) v125: reparticion de tres frases de los padres

### La consulta de David (y por que fue la correcta)

> «¿En japonés dice "¡Llévate también unos kibidango!" o "un kibidango"?
> La clave está en si dice sólo "kibidango" o usa la palabra "hitotsu".»

Decodificado el bloque virgen `0x1F077`:

```
「キビダンゴモ モッテイクガヨイ！」          <- la madre: SIN cantidad
モモタロウハ キビダンゴヲ ヒトツ テニイレタ！  <- obtencion: CON cantidad
```

**Las dos frases no dicen lo mismo.** La madre usa un plural indefinido (el
japones no marca numero en el sustantivo); el aviso de obtencion dice
`ヒトツ` = "uno", explicito. La pregunta de David daba justo en el punto.

Ademas el original usa la MISMA plantilla para el dinero y para el dango:

```
□□□両 テニイレタ      (los tres 0xFB)
ヒトツ テニイレタ
```

`ヒトツ` ocupa el lugar de la cifra: **es la cantidad, no relleno**. Y el
japones reparte igual que proponia David: sujeto+objeto arriba,
cantidad+verbo abajo. La propuesta reproduce el ritmo del original.

### [HECHO] La medicion que descarto una opcion

David planteo dos alternativas. Medidas:

```
¡Llévate también unos   21 celdas   NO CABE (maximo 20)
¡Llévate también un     19 celdas   cabe
```

El plural no entra por una celda, independientemente de si la segunda linea
es `kibidangos!` o `kibidango!`. Razonamiento linguistico de David, correcto:
"kibidango" es contable, asi que en castellano no vale "llévate también
kibidango". Se elige el singular, que ademas **coincide con lo que el juego
te da de verdad** (uno).

### El cambio

```
¡Momotaro obtiene      ->  ¡Momotaro obtiene 50    (20)
50 ryos!                   ryos!                    (5)

¡Llévate también       ->  ¡Llévate también un     (19)
unos kibidango!            kibidango!              (10)

¡Momotaro obtiene      ->  ¡Momotaro obtiene un    (20)
un kibidango!              kibidango!              (10)
```

Dos lineas quedan a **20/20, sin margen**. Anotado: si algun dia se cambia
el ancho o el renderizado, esas son las primeras que se cortarian.

El bloque pasa de 198 a 196 B; la cola se rellena con `$FF` para no dejar
restos del anterior. El puntero `$C181/$C185` no cambia (mismo sitio).

### Verificacion

Releido el texto **desde la ROM construida, siguiendo el puntero**
`$C181/$C185 -> $5EA9`: las cinco paginas correctas, terminador `$FF` en
`0x1FF6C`, cola limpia, guarda `0x1FEA8` intacta.

Intactos: lista de la carga (v123), stub del boton II (v124), intro,
tutorial, texto japones original.

### Entrega

```
test_padres_v125.pce   MD5 f303fa941c65ae747d44477e919e4104
momotaro_padres_v125.ips
88 bytes, un rango (0x1FEF4..0x1FF6D)
```

### [HECHO] Estado validado por David

**v124 probada a fondo en Beetle y Mesen, con partida y sin ella. Sin
problemas.** Eso valida de una vez:

- la pantalla de carga con dos partidas (v123)
- el boton II condicional (v124) en LOS DOS emuladores

El condicional por `JSR $EAE6` resuelve lo que ocho intentos del chat
anterior no lograron. La clave era no leer ningun flag.

### [HIPOTESIS] Las tiendas: hay que medirlo, no darlo por sabido

David reporta que al entrar en las tiendas hay artefactos, ruido, texto
ilegible, y que al salir el HUD queda corrompido. El chat anterior le dijo
que «era por el cambio de fuente y se solucionaria al traducir los textos».

**Eso no esta medido y no cuadra con el sintoma.** Si solo fuera fuente sin
traducir se verian glifos equivocados, no ruido ni un HUD roto DESPUES de
salir. El HUD corrupto es el mismo sintoma que ya dieron:

- `$F9CC` usado como origen de un DMA (resuelto)
- la limpieza CG corta de la v58 (resuelto)

Es decir: **estructura, no contenido**. Queda anotado como pendiente de
medir, con la explicacion anterior marcada como NO VERIFICADA.

### Plan acordado con David

1. mapa (`0x43740`)
2. menu de SELECT
3. recuadros in-game de RUN
4. bocadillos verticales -> horizontales

Sobre el 4: David observa que todos los bocadillos parecen iguales, y que
arreglado uno quedarian arreglados todos, lo que permitiria traducir el
grueso del guion en bloque con un repartidor automatico de lineas.
**Antes de disenyar nada hay que comprobar que son realmente iguales**,
contando cuantas listas de sprites comparten la estructura de `$0348`.

---

## (94) v126: el rotulo de localizacion, de 8 a 16 glifos

### El encargo

Traducir los nombres del mapa/aldeas (`0x4372D` y `0x437AF`). Los nombres en
castellano no caben: `Aldea del Florecer` son 18 caracteres y el rotulo
admite 8.

### [HECHO] Arquitectura, medida contra el save-state de la aldea

David subio un state con `たびだちの村` en pantalla. Estado en el momento:
`$BF/$C0 = $B7AF` (entrada 0 del bloque B), `$3B0D = 1`, `$3B0E = 0`.

```
$DD57  JSR $DE38            bucle de pantalla, cada frame
         $DE44  LDX #$60 / LDY #$60        ancla (96,96)
         $DE4B  lista $4A07  TEXTO   2 sprites de 32 px
         $DE60  lista $4A12  CAJA   10 sprites
         base de patron $03E0 en los dos ($DE53 / $DE68)

$AD0F  preparacion, una vez al entrar
         $AD53  JSR $F1B9   vuelca el CG de la caja a VRAM $7C00
         $AD56  $16/$17 = $7E04    destino del CG del TEXTO
         $ADA6  puntero del nombre (tabla $B79D) -> $BF/$C0
         $ADB0  JMP $AA16 -> $D619   bucle de glifos, cuenta en $C3
```

Contrastado sprite a sprite con el SATB del state: **coincide exactamente**.

```
texto  X 112..175  (64 px = 8 glifos)   VRAM $7E00, $7E80
caja   X  96..191  (96 px)              VRAM $7C00, $7C40, $7D00
```

`$D619` no tiene ningun `CMP` contra un ancho maximo: dibuja hasta el
terminador. El limite no es el bucle, es la VRAM.

### [HECHO] Zonas libres (verificadas por partida doble)

En el state de la aldea, cero bytes no nulos **y** cero referencias desde el
SATB:

```
$7000..$71FF    8 tiles   16 glifos
$74C0..$7BFF   29 tiles   58 glifos   <- se usa este
```

### El '+4' de $7E04

No es desplazamiento de tile: es **vertical dentro del tile**. Volcado el
glifo: las filas 0-3 estan vacias y la tinta empieza en la fila 4. El tile
base es `$7E00`. Al reubicar hay que conservar el `+4`.

### Tres errores mios, los tres cazados por asserts

**1. Offsets al operando, no al opcode.** Puse `CG_LO = 0x42D57`, que es el
`04` de `LDA #$04`. El opcode esta en `0x42D56`. Norma 39, otra vez.

**2. La base de patron no puede quedar por encima del CG.** El motor calcula
`patron = base + (pat_rel << 1)` con `pat_rel` **sin signo**. Con base
`$03E0` (= VRAM `$7C00`) y el texto en `$7800`, el `pat_rel` salia **-16**.
Hubo que bajar tambien la base a `$03C0` (= `$7800`), lo que obliga a
recalcular los `pat_rel` de la caja: `$10`, `$11`, `$14`.

**3. El ancla no puede irse al borde.** Puse el ancla en X=32 para que la
caja creciera hacia la derecha; el lateral derecho quedaba en `dx = 176`,
fuera del rango con signo `[-128, +127]` (norma 36). **El ancla se queda en
96** y la caja crece simetricamente a su alrededor.

**Norma 46. Al mover un CG hay que mover la base de patron con el, y
comprobar que ningun `pat_rel` queda negativo.**

**Norma 47. El ancla de un metasprite va en el CENTRO del grupo, no en el
borde: los dx son con signo.**

### La v126 (opcion B acordada con David)

Caja **fija** de 192 px y 16 glifos. Sin despachador ni variable de longitud:
eso es la v127. Motivo: `$C3` se calcula en `$AD0F` pero hace falta en
`$DE38`, y enlazarlos exige codigo nuevo. Separando las dos cosas, si algo
falla sabemos si es la geometria o el despachador.

```
0x2FB8C  lista TEXTO $5B8C   4 sprites de 32 px   X  64..191  (16 glifos)
0x2FBA1  lista CAJA  $5BA1  22 sprites            X  32..223  (192 px)
0x19E4C  ptr texto  $4A07 -> $5B8C
0x19E61  ptr caja   $4A12 -> $5BA1
0x19E54  base patron $03E0 -> $03C0  (texto)
0x19E69  base patron $03E0 -> $03C0  (caja)
0x42D5B  CG del texto  $7E04 -> $7804
```

Ranuras de 16 px por scanline (limite 16): caja 12 / 12 / 2, texto 8.

### Verificacion

Releidas las dos listas **desde la ROM, siguiendo los punteros del codigo
desensamblado**:

```
TEXTO  dy=16   X  64..191   4 sprites   8 ranuras  vram $7800..$7980
CAJA   dy= 1   X  32..223  10 sprites  12 ranuras
       dy=16   X  32..223   2 sprites   2 ranuras
       dy=31   X  32..223  10 sprites  12 ranuras
```

Todo dentro de pantalla (0..255). Intactos: listas viejas `$4A07`/`$4A12`,
CG de la caja `$51A3`, nombres japoneses, y todo lo de v123/v124/v125.

### Entrega

```
test_rotulo_v126.pce   MD5 d7701acaf6a7a71002408d0e2757be8e
momotaro_rotulo_v126.ips
137 bytes en 4 rangos
```

### Que mirar

**Esta version NO traduce todavia**: solo ensancha el continente. El texto
sigue en japones, asi que `たびだちの村` (6 glifos) deberia verse **igual
que antes pero dentro de una caja mucho mas ancha**, alineado a la izquierda.

1. Entrar en una aldea: caja ancha, nombre japones legible, sin basura.
2. El mapa: lo mismo.
3. El HUD y los sprites del personaje: que no haya artefactos (hemos movido
   CG y base de patron).
4. Si aparece ruido a la derecha del nombre, es CG sin limpiar en `$7800+`:
   habria que anyadir la limpieza, y lo sabremos por ahi.

---

## (95) v127: cerrar la fila central del rotulo — dos correcciones mias

### David tenia razon en las dos cosas

**1. «Los signos raros» NO eran un fallo.**

Dije que los glifos extranyos indicaban que los sprites leian CG ajeno.
**[DESCARTADO]**. David:

> «Cuando tradujiste la intro, el tutorial y la pantalla de los padres, se
> veia exactamente con los mismos signos raros [...] en cuanto introdujeras
> el texto traducido se veria bien, y asi ha sido.»

El motivo esta en el propio diario: los bytes japoneses `>= $A1` van por la
**ruta katakana** (glifo = byte directo), asi que con la fuente latina
cargada muestran otros glifos. Es esperado. **Norma 34**: debi releer el
diario antes de contradecirle. Van dos veces hoy.

**2. El bloque marron NO era basura.**

Dije que los patrones sin limpiar «mostraban lo que hubiera antes en esa
VRAM». **[DESCARTADO]**. David:

> «el bloque marron del tejado es precisamente eso: el tejado de la casa que
> se ve detras [...] el marco esta hueco por esa zona y vemos lo que hay
> detras, al igual que en la parte derecha vemos un cuadro verde que
> pertenece al arbol.»

Verificado en el state: los ocho patrones de `$7800..$79FF` estan **a cero**,
y el color 0 del PCE es **transparente**. No habia basura que limpiar: habia
relleno opaco que faltaba pintar. El arreglo coincide en el byte, pero el
diagnostico era otro — y la diferencia importa, porque marca si hay que
limpiar antes o pintar mas.

### [HECHO] El fallo real: dos huecos en la fila central

```
ORIGINAL (96 px)   lat(16) + TEXTO(64) + lat(16) = 96        sin huecos
MI v126 (192 px)   lat(16) + HUECO(16) + TEXTO(128) + HUECO(16) + lat(16)
```

Al ensanchar movi los laterales al borde pero deje el texto donde estaba.
Cuadra con el mapa ASCII de la captura: x42..47 blanco, x48..63 transparente,
x64+ texto. Es exactamente lo que describio David: «el lateral derecho no
llega a conectar con las esquinas superior e inferior».

### La geometria nueva

```
lateral izq   x  32.. 47    16 px
TEXTO         x  48..207   160 px = 20 glifos
lateral der   x 208..223    16 px
                            192 px, sin huecos
```

**20 glifos**, cuatro mas que la v126. Ahora caben los nombres largos:
`Aldea del Florecer` (18), `Isla de los Ogros` (17), `Aldea de Kintaro` (16).

Y la limpieza se ajusta a lo que se lee:

```
0x42D79   LDY #$03 -> #$09    10 patrones = $7800..$7A7F
          texto: 5 sprites x 2 patrones = 10.  COINCIDEN.
```

**Norma 48. Al ensanchar un contenedor de sprites hay que recolocar TODO su
contenido, no solo los bordes: los huecos intermedios son transparentes.**

**Norma 49. La limpieza de CG debe cubrir exactamente los patrones que la
lista LEE, ni uno menos.**

### Verificacion

Releidas las listas desde la ROM siguiendo los punteros del codigo:

```
dy= 1   10 sprites  12 ranuras   x 32..223  CONTINUA
dy=16    7 sprites  12 ranuras   x 32..223  CONTINUA
dy=31   10 sprites  12 ranuras   x 32..223  CONTINUA
```

Cero huecos en las tres filas. Ranuras por scanline 12 (limite 16).
Limpieza 10 patrones = los 10 que se leen.

### Entrega

```
test_rotulo_v127.pce   MD5 b443b484c07e20b11e3a4e7533326626
momotaro_rotulo_v127.ips
52 bytes en 3 rangos
```

Intactos: listas viejas, nombres japoneses, y todo lo de v123/v124/v125/v126.

### Que mirar

Sigue **sin traducir**: el texto japones se vera con glifos latinos raros, y
eso es correcto (ver arriba). Lo que hay que comprobar es el CONTINENTE:

1. La caja cerrada por los cuatro lados, sin ver el fondo a traves.
2. El lateral derecho conectando con las esquinas.
3. Sin la franja transparente entre el lateral izquierdo y el texto.

---

## (96) v128: el limite de sprites por scanline

### El sintoma

David, con una ampliacion: «en el lado derecho faltan 5 pixeles en linea
horizontal, tanto arriba como abajo, en la parte que conecta con el lateral».

Medido en su captura: `y112` e `y127` se cortan en x=207; las vecinas llegan
a x=213.

### [HECHO] La causa: 24 ranuras en dos scanlines

```
y=112 : 24 ranuras   *** EXCEDE EL LIMITE (16) ***
y=127 : 24 ranuras   *** EXCEDE EL LIMITE (16) ***
resto : 12 ranuras
```

El PCE dibuja 16 ranuras de 16 px por linea de barrido y **descarta** el
resto. Los descartados son los ultimos de la lista: lateral y esquina
derechos. Por eso faltaban pixeles siempre a la derecha y siempre en esas
dos filas.

### Por que mi verificacion no lo vio

Contaba ranuras agrupando por `dy`, y cada `dy` daba 12. Pero los sprites
son de **16 px de alto** y las filas se solapan:

```
dy= 1  ->  y  97..112
dy=16  ->  y 112..127     <- y112 esta en las DOS
dy=31  ->  y 127..142     <- y127 idem
```

En las fronteras: 12 + 12 = 24.

**Norma 50. Las ranuras por scanline se cuentan por linea de barrido, no por
fila de la lista: los sprites de 16 px de alto solapan sus bordes.**

El original no lo sufria porque con la caja de 96 px eran 6+2 = 8 ranuras en
la frontera. Al ensanchar a 192 px puse 10 sprites por fila y se disparo.

### El arreglo

```
dy = 1, 16, 31   ->   dy = 0, 16, 32

    dy= 0  ->  y  96..111
    dy=16  ->  y 112..127
    dy=32  ->  y 128..143
```

Sin solape. Verificado linea a linea: **maximo 12 de 16** en y96..143, cero
scanlines que excedan.

Efecto secundario, y hay que decirlo: la caja crece **2 px de alto**. Es
consecuencia directa de separar las filas y no se puede evitar manteniendo
los tres sprites.

### Las capturas del Sprite Viewer

David mando cuatro capturas con los sprites 15, 25, 35 y 37 seleccionados,
con sus X,Y, tile index y tile address. Confirmaron que los sprites estaban
**exactamente donde mi lista decia**. Eso descarto el error de
posicionamiento —que era mi primera hipotesis— y llevo a mirar el limite por
scanline. Sin esas capturas habria perdido una iteracion recolocando
sprites que ya estaban bien.

### Verificacion

```
ranuras por scanline  y96..143, maximo 12 de 16, ninguno excede
dy= 0 (y 96..111)  x 32..223  continua
dy=16 (y112..127)  x 32..223  continua
dy=32 (y128..143)  x 32..223  continua
```

El verificador del constructor ahora cuenta **las dos listas juntas y por
scanline**, no por `dy`.

### Entrega

```
test_rotulo_v128.pce   MD5 e2dd759588ef81e19fc475f05176b976
momotaro_rotulo_v128.ips
20 bytes, un rango (0x2FBAA..0x2FC09)
```

Intactos: v123, v124, v125, el CG de la v126 y la limpieza de la v127.

### Que mirar

Sigue sin traducir (glifos latinos raros = correcto, ruta katakana).

1. Los 5 pixeles del lado derecho, arriba y abajo: deben estar.
2. El marco cerrado por los cuatro lados.
3. La caja es 2 px mas alta que en la v127.

---

## (97) v129: los nombres de las localizaciones, traducidos

### La pregunta de David que resolvio el bloqueo

> «¿no podemos usar la fuente que ya tenemos? La de la parrilla de passwords,
> intro, tutorial, error de password, etc.»

**Si. De hecho el rotulo YA la usa.** Yo habia dicho que «la fuente del
rotulo no tiene mayusculas» y estaba equivocado en dos sentidos:

1. **El rotulo no tiene fuente propia.** `$AAB4`:

   ```
   LDA ($14),Y            indice de glifo
   ASL A / ROL $15   x3   indice * 8
   ADC #$60 / ADC #$56    + $5660
   LDA #$1E / TAM #$04    banco $1E
   ```

   `$5660` en el banco `$1E` = **ROM 0x3D660** = la fuente de dialogo del
   proyecto, la de siempre.

2. **`$9CB3`/`$9CF3` no son fuentes: son tablas de INDICES.** Confundi el
   indice con el contenido. Norma 15 aplicada al reves: no es que lo medido
   en una fuente no valga para la otra, es que **habia una sola fuente y yo
   veia dos**.

**Norma 51. Antes de declarar que a una fuente le faltan glifos, comprobar
si lo que se esta mirando es la fuente o una tabla de indices hacia ella.**

### [HECHO] Las dos rutas de codificacion

```
RUTA BAJA  $30-$65, tabla $AB5B   0-9  A-Z  b c p e o Ç
RUTA ALTA  $A0-$DF, tabla $9CB3   a-z  acentos  ¿ ¡ . , : ; - …
```

Volcados los glifos uno a uno desde `0x3D660`: la `A` es `$41`, la `K` es
`$4B`, la `M` es `$4D`. **ASCII directo.** No hubo que tocar ninguna tabla.

### [HECHO] Codigos de control ($AB91)

```
$01 = fuente 0     $02 = fuente 1     $5C = alternar fuente
```

Devuelven `CLC`, asi que `$D619` no los dibuja. Dos consecuencias:

- la cabecera de cada cadena **se conserva**: elige la tabla de indices
- el `$5C` de `カチカチ[5C]ヤマノ村` **no es un espacio**, es un cambio de
  fuente. El japones se lee de corrido: «Kachikachiyama».

El espacio se escribe `$20`, que `$AB34` remapea a `$3C`.

### La traduccion

Criterio de David: **mixto** (nombre propio cuando el japones lo usa;
descriptivo cuando nombra lugar o concepto) y **«Aldea de» completo**.

```
[0] タビダチノ村       Aldea de la Partida    19
[1] ハナサカノ村       Aldea del Florecer     18
[2] キンタロウノ村     Aldea de Kintaro       16
[3] ネタロウノ村       Aldea del Dormilón     18
[4] ウラシマノ村       Aldea de Urashima      17
[5] カチカチヤマノ村   Aldea de Kachiyama     18
[6] イッスンボウシ村   Aldea de Issun-boshi   20   <- al limite
[7] タケトリノ村       Aldea del Bambú        15
[8] オニガシマ         Isla de los Ogros      17
[-] ゲーム スタート    COMIENZA EL JUEGO      17
```

Observacion de David, correcta y asumida: «Aldea de Kachiyama omite uno de
los dos kachi's». カチカチヤマ es «el monte que hace kachi-kachi» (onomatopeya
del fuego, el cuento va de eso). `Aldea de Kachi-Kachi` y `Aldea de Monte
Kachi` miden 20 clavados; se elige Kachiyama (18) por dejar margen y por
leerse como toponimo, igual que Urashima o Kintaro. **Perdida consciente.**

`COMIENZA EL JUEGO` en mayusculas y sin exclamaciones: `ゲーム スタート` es un
prestamo del ingles en katakana, el registro es de LETRERO, no de frase.
Lleva cabecera `$02` (fuente 1) como el original.

### Donde van

No hizo falta reubicar el bloque entero: la tabla `$B79D` tiene **nueve
punteros independientes**, asi que las cadenas pueden estar dispersas.

`$D619` mapea MPR2 = banco 0x0F antes de leer `($BF),Y`, y el juego ya guarda
ahi `GAME START` (`$52B2` = ROM 0x1F2B2). Los nombres nuevos van al mismo
banco, repartidos en tres huecos:

```
0x1E25B  [0] [1]
0x1F89D  [2] [3] [4] [5] [6]
0x1F9C3  [7] [8] [-]
```

Los nombres japoneses (`0x437AF`) **no se borran**: quedan intactos, solo
dejan de apuntarse.

### Verificacion

Decodificadas las diez cadenas **desde la ROM construida**, simulando el
camino real del juego (`$D619` -> `$AB91` -> `$AB34` -> `$AAB4`/`$AB1B`) y
resolviendo cada glifo por su indice. Las diez salen correctas, con su
recuento y su fuente.

Intactos: nombres japoneses, GAME START japones, listas del rotulo (v128),
tablas `$AB5B` y `$9CB3`, la fuente `0x3D660`, y todo lo de v123-v125.

### Entrega

```
test_nombres_v129.pce   MD5 b817d910d3a9e0c2dde833c4e785bf75
momotaro_nombres_v129.ips
205 bytes en 5 rangos
```

### Que mirar

**Esta es la primera version en la que el rotulo se lee en castellano.**

1. El mapa: cada aldea con su nombre.
2. Entrar en una aldea: el rotulo interior.
3. El exterior: `COMIENZA EL JUEGO`.
4. Que ningun nombre se corte por la derecha (el critico es
   `Aldea de Issun-boshi`, 20 de 20).
5. Los acentos: `Dormilón`, `Bambú`.

### Pendiente

- La **caja variable** (David: «estoy casi seguro de que te pedire que la
  implementes»). Ahora es cosmetica: todos los nombres caben.
- El **bloque A** (`0x4372D`, tabla `$B70E`): medido que **nadie lo lee**.
  Si el mapa sale en castellano con esta version, el bloque A es residual y
  se puede ignorar.

---

## (98) v130: el rotulo del MAPA, 20 glifos con rabito fijo

### El fallo

El nombre salia cortado a 8 glifos ("Aldea de"). Medido en el state:
`$C3 = 18` — **los 18 glifos se dibujan en VRAM**; faltaban sprites que los
mostraran. La lista `$CD67` solo tiene 2 sprites de 32 px.

### [HECHO] Dos descubrimientos que condicionaron todo

**1. El mapa lee la tabla de nombres DESPLAZADA.**

```
$ADA6  LDA $B79D,X    la ALDEA
$CD13  LDA $B79F,X    el MAPA, dos bytes mas alla
```

El mapa muestra el nombre `i+1`. Confirmado: `$3CF6 = 0` y el rotulo decia
"Aldea del Florecer", que es la entrada [1]. **Es asi en el original**; lo
heredamos y no se toca. David lo vera al probar.

**2. La tabla `$CCCF` posiciona el ICONO Y el ROTULO.**

```
$CCA2  LDA $CCCF,X -> $4E    el ICONO   (rutina $CC98)
$CD44  LDA $CCCF,X -> $4E    el ROTULO  (rutina $CD3E)
```

Iba a cambiar las anclas de `$CCCF` para recolocar el rotulo: **habria
movido los ocho iconos del mapa**, cambiando la geografia. Lo cace al
comprobar quien mas lee la tabla, antes de escribir un byte. Norma 24.

Pero son dos LECTURAS distintas: con una tabla nueva para `$CD44`, el rotulo
se mueve y el icono se queda.

### Por que una sola lista no bastaba

Con la misma caja para las ocho localizaciones y las anclas actuales
(48..224), el ancho maximo que cabe en pantalla es **80 px**, menos que los
96 actuales. Con tabla de anclas propia caben **192 px**.

### La solucion, y la correccion de David

Primero propuse mover el rabito con una tabla de `dx` por localizacion.
David corrigio:

> «precisamente los rabillos ya apuntan correctamente a la aldea. Deberian
> quedarse donde estan y solo mover los bocadillos con el texto.»

Tenia razon, y ademas simplifica: en vez de tabla de `dx` + automodificacion
de la lista en ROM (que no se puede), basta con **dibujar el rabito en una
llamada aparte** usando el ancla ORIGINAL:

```
1) lista CAJA+TEXTO   con ancla = tabla_nueva[loc]     -> se coloca donde quepa
2) lista RABITO       con ancla = $CCCF[loc]           -> donde estaba siempre
```

`$E3EB` toma el ancla de `$4E/$50`, asi que llamarlo dos veces con anclas
distintas resuelve el problema sin automodificacion ni tabla de `dx`.

**Norma 52. Si dos partes de un metasprite necesitan anclas distintas, se
dibujan en dos llamadas, no se parchea la lista.**

### Geometria

```
caja    192 px, centrada en el ancla nueva
texto   5 sprites de 32 px = 160 px = 20 GLIFOS
filas   dy = 0, 16, 32   (norma 50: sin solape)

loc  icono_X  rotulo_X  caja           rabito
  0     48       96     x   0..191     x  40..55
  1    136      136     x  40..231     x 128..143
  2    192      160     x  64..255     x 184..199
  3    192      160     x  64..255     x 184..199
  4     80       96     x   0..191     x  72..87
  5    104      104     x   8..199     x  96..111
  6    160      160     x  64..255     x 152..167
  7    224      160     x  64..255     x 216..231
```

Los ocho rabitos apuntan a su icono **y** caen dentro de su caja.
Ningun sprite fuera de pantalla, ningun `dx` fuera de `[-128,+127]`,
maximo 13 ranuras por scanline.

Con 20 glifos **caben los nueve nombres** de la v129.

### El codigo

`$CD3E` pasa a `JMP $DCF6`. En `$DC88` (hueco de 888 B del banco 0x0E):

```
$DC88  tabla de anclas del rotulo (8 B)
$DC90  lista caja+texto (19 sprites, 96 B)
$DCF0  lista rabito (1 sprite, 6 B)
$DCF6  codigo (79 B): dos llamadas a $E3EB con anclas distintas
```

Desensamblado y verificado instruccion a instruccion.

### Entrega

```
test_mapa_v130.pce   MD5 cf08ceb049b74d4030b4bcaef3ea05ee
momotaro_mapa_v130.ips
189 bytes en 2 rangos
```

Intactos: tabla de iconos `$CCCF`, rutina del icono `$CC98`, lista vieja
`$CD67`, tabla de nombres, y todo lo de v123-v129.

### Que mirar

1. **El mapa**: cada aldea con su nombre completo en castellano.
2. **Los iconos NO se han movido** (es lo critico: si alguno cambia de sitio,
   revertir).
3. **El rabito** de cada rotulo sigue apuntando a su aldea.
4. Que ninguna caja se salga por los bordes ni tape el marco del mapa.
5. Que en la localizacion 0 el mapa rotule "Aldea del Florecer" y no
   "Aldea de la Partida": es el desfase `i+1` del original.

---

## (99) v131: corregir el eje Y del rotulo del mapa

### El fallo, avisado de antemano por David

Al pedir el cambio: «El eje Y de cada rotulo no hay que tocarlo, solo el X».
Al ver la v130: «se ve que el primer rotulo esta muy abajo, fuera del mapa.
Precisamente no habia que tocar Y».

Medido:

```
LISTA ORIGINAL  dy = 190, 206, 222  -> con ancla Y=216: Y = 150, 166, 182
MI LISTA v130   dy =   0,  16,  32  -> con ancla Y=216: Y = 216, 232, 248
```

Los `dy` originales usan el **desbordamiento del byte**: `216+190 = 406 mod
256 = 150`. Asi el rotulo queda POR ENCIMA del ancla, que en el mapa esta
abajo (junto al icono de la aldea).

Escribi `0/16/32` copiando el esquema del rotulo de aldea (v128), donde el
ancla esta arriba. Resultado: 66 px hacia abajo, fuera del mapa. En la
captura de David el rotulo empieza en `y=227` y se corta contra el borde.

Error de metodo: reescribi la lista entera desde cero en vez de conservar
los `dy` existentes, y no compare mi lista con la original **en el eje que
David habia marcado como intocable**.

**Norma 53. Al reescribir una lista de sprites, conservar los dy originales
salvo motivo medido: el ancla puede estar en cualquier esquina del grupo.**

### El arreglo

Un solo cambio, 20 bytes: los `dy` vuelven a **190 / 206 / 222**, y el
rabito a **222**. Todo lo demas de la v130 se conserva.

### Verificacion

```
dy v131 : [190, 206, 222]     dy original : [190, 206, 222]   COINCIDEN
rabito dy: 222 (original 222)

loc 0: ancla Y=216 -> filas Y 150/166/182   OK
loc 1: ancla Y=176 -> filas Y 110/126/142   OK
loc 2: ancla Y=200 -> filas Y 134/150/166   OK
loc 3: ancla Y=144 -> filas Y  78/ 94/110   OK
loc 4: ancla Y=152 -> filas Y  86/102/118   OK
loc 5: ancla Y=104 -> filas Y  38/ 54/ 70   OK
loc 6: ancla Y= 80 -> filas Y  14/ 30/ 46   OK
loc 7: ancla Y= 80 -> filas Y  14/ 30/ 46   OK
```

Las ocho dentro del area util (0..223). El constructor ahora comprueba el
eje Y ademas del X. Maximo 13 ranuras por scanline, igual que la v130.

### Entrega

```
test_mapa_v131.pce   MD5 a4c8dde8cb66f7cc89545817f7bb0123
momotaro_mapa_v131.ips
20 bytes, un rango (0x1DC94..0x1DCF4)
```

### Que mirar

1. El rotulo **en su sitio de siempre** en el eje Y, con el nombre completo.
2. Los iconos de las aldeas sin moverse.
3. El rabito apuntando a su aldea.
4. Los errores graficos que David vio en la captura de la v130: hay que
   comprobar si eran consecuencia del rotulo desplazado o algo aparte.

---

## (100) v132: el limite de scanlines, contado con TODA la pantalla

### El fallo de la v131

David: «vemos un cuadrado vacio a la derecha del texto. En el icono de la
aldea que hay a la derecha del bocadillo vemos que le faltan unos
recuadros.»

Contando ranuras por scanline **con todos los sprites de la pantalla**:

```
y=168..175 : 17 ranuras   *** EXCEDE 16 ***
y=184..197 : 17 ranuras   *** EXCEDE 16 ***
```

Mi verificacion de la v130/v131 contaba **solo los sprites del rotulo** (13
de 16, correcto). No sume los que ya habia en pantalla: iconos de aldea,
personajes, nubes.

**Norma 54. Las ranuras por scanline se cuentan sobre TODOS los sprites de
la pantalla, no solo los de la lista que se esta tocando.**

### El presupuesto real (medido en el state)

```
fila superior  Y 150..165   otros usan 4   -> presupuesto 12
fila del texto Y 166..181   otros usan 5   -> presupuesto 11
fila inferior  Y 182..197   otros usan 4   -> presupuesto 12
```

| caja | glifos | sup | cen | inf |
|------|--------|-----|-----|-----|
| 160  | 16     | 10  | 10  | 11  | <- cabe |
| 192  | 20     | 12  | 12  | 13  | <- se pasa |

Cuadra con lo observado. Se elige **160 px = 16 glifos**, maximo 15 de 16
ranuras, con margen.

### EL ENIGMA DEL INDICE, RESUELTO POR DAVID

Iba a "corregir" `$CD13` (`$B79F` -> `$B79D`). **Habria roto la coherencia.**

David lo verifico jugando: punto 2 = "Aldea de Kintaro" en el mapa **y**
dentro; punto 3 = "Aldea del Dormilón" en los dos. Y descubrio la clave:

> «si sigues avanzando en el primer nivel, llegas a una segunda aldea que es
> la del florecer»

Son **dos indices distintos**:

```
$3B0E  indice de la ALDEA  -> $B79D,X  -> entrada [$3B0E]
$3CF6  indice del MAPA     -> $B79F,X  -> entrada [$3CF6 + 1]
```

El `+1` compensa que la entrada [0], `タビダチノ村` (el pueblo natal de
Momotaro, donde estan sus padres), **esta dentro del primer nivel y no tiene
punto propio en el mapa**. Avanzando en ese nivel se llega a la segunda
aldea, la del Florecer, que si es el punto 1.

**No hay desfase. No se toca nada.** Otra vez: la comprobacion en pantalla
de David evito un "arreglo" que habria roto algo que funcionaba.

### Los nombres cortos

Con 16 glifos, cinco nombres no cabian. Se acorta quitando la preposicion,
que es lo que menos informacion pierde. Una sola tabla para mapa y aldea:
mantiene la coherencia que David verifico.

```
[0] Aldea de la Partida  19   <- pueblo natal, solo aparece dentro
[1] Aldea Florecer       14      [5] Aldea Kachiyama    15
[2] Aldea Kintaro        13      [6] Aldea Issunboshi   16
[3] Aldea Dormilón       14      [7] Aldea Bambú        11
[4] Aldea Urashima       14      [8] Isla Ogros         10
```

### El rabito

David: «el rabillo esta 1 px mas abajo de lo que deberia». Medido: usa
`dy=222`, **el mismo** que la fila inferior, igual que la lista original. La
relacion vertical no ha cambiado respecto al japones. Hipotesis: lo que se
veia era consecuencia del desbordamiento de scanlines (los descartados caian
justo en y=184..197, la fila inferior). Se arregla el desbordamiento primero
y se vuelve a mirar. **Un fallo cada vez.**

### Verificacion

Releidas las listas desde la ROM siguiendo los punteros del codigo, y los
nombres decodificados por el camino real del juego. Ranuras con todos los
sprites: maximo 15 de 16, ninguno excede.

### Entrega

```
test_mapa_v132.pce   MD5 ecad036b28d7553554b31719aff22ed3
momotaro_mapa_v132.ips
315 bytes
```

### Que mirar

1. El **cuadrado vacio** a la derecha del texto: debe desaparecer.
2. El **icono vecino** completo, sin recuadros mordidos.
3. El **rabito**: si sigue separado, es un fallo aparte y ya se mira solo.
4. Los nombres cortos en el mapa y `Aldea de la Partida` en el pueblo natal.

---

## (101) v133: el rabito por delante — z-index, como dijo David

### El diagnostico de David, confirmado

> «no esta despegado, sino que le falta la linea blanca que tendria que
> tapar el contorno del bocadillo, o bien, el rabillo se esta dibujando
> debajo del bocadillo en lugar de encima. Es otra vez como un z-index mal
> ordenado.»

Exacto. Medido el ORDEN de la lista original `$CD67`:

```
idx  0-1   texto              (fila centro)
idx  2-4   esquinas/relleno   (fila superior)
idx  5-6   laterales          (fila centro)
idx  7     RABITO             <- ANTES de la fila inferior
idx  8-10  esquinas/relleno   (fila inferior)
```

En el PCE el **indice BAJO del SATB tiene prioridad ALTA**. El rabito
original va delante de la fila inferior y TAPA su contorno.

En la v130-v132 el rabito se dibujaba en una SEGUNDA llamada a `$E3EB`, asi
que acababa con el indice mas alto: quedaba DETRAS de la caja entera y el
contorno de la fila inferior se veia por encima.

**Norma 55. En el SATB del PCE el indice bajo se dibuja ENCIMA. Al partir
una lista en varias llamadas hay que conservar el orden relativo original.**

### El arreglo: tres llamadas

Invertir las dos llamadas no bastaba: el rabito habria quedado encima de
TODA la caja, incluido el texto. Se parte en tres, conservando el orden:

```
1) caja SUPERIOR + CENTRO + TEXTO   ancla nueva      idx  0..10
2) RABITO                           ancla ORIGINAL   idx 11
3) caja INFERIOR                    ancla nueva      idx 12..16
```

### Verificacion

Releidas las tres listas desde la ROM siguiendo los punteros del codigo
desensamblado:

```
1) esq rel rel rel esq lat lat txt txt txt txt   idx 0..10
2) RABITO                                        idx 11
3) esq rel rel rel esq                           idx 12..16
```

El rabito va **antes** que la fila inferior, igual que el original.
Ranuras por scanline con todos los sprites: maximo 15 de 16.

Un aviso de metodo: mi primer verificador leyo la lista 3 sin respetar su
terminador y saco 28 sprites fantasma. Era el LECTOR el que estaba mal, no
la ROM. Comprobado byte a byte antes de dar la alarma.

### Entrega

```
test_mapa_v133.pce   MD5 a07a5fa926ba73da844a7c785549171b
momotaro_mapa_v133.ips
165 bytes
```

### Pendiente: la caja variable (v134)

David: «les sobra algo de bocadillo a la derecha. Tambien al COMIENZA EL
JUEGO». Medido cuanto sobra:

```
MAPA (160 px)              ALDEA (192 px)
Isla Ogros      48 px      Isla Ogros         80 px
Aldea Bambu     40 px      Aldea Bambu        72 px
Aldea Kintaro   24 px      Aldea Kintaro      56 px
                           COMIENZA EL JUEGO  24 px
```

Ya no es cosmetico: en la aldea sobran hasta 80 px, casi media caja.

Dato util de David: «COMIENZA EL JUEGO no es un mensaje que salga solo una
vez al inicio, sino que sale cada vez que empiezas a jugar». Ese rotulo se
ve constantemente.

---

## (102) v134: la CAJA VARIABLE

### El diseno

El ancho depende del numero de glifos. Cada sprite de texto son 32 px = 4
glifos, y la caja es `lat(16) + texto(N*32) + lat(16)`:

```
N=3 -> 12 glifos -> caja 128 px
N=4 -> 16 glifos -> caja 160 px
N=5 -> 20 glifos -> caja 192 px
```

Con los nueve nombres + GAME START solo hacen falta **tres anchos**. Se
precalculan las listas y se elige con un indice: sin codigo que corra cada
frame.

### MAPA: ancla por localizacion Y por ancho

El ancho condiciona donde cabe la caja, asi que la tabla de anclas se
recalcula con el ancho de cada nombre. El mapa muestra el nombre `loc+1`
(verificado por David jugando):

```
loc  nombre             caja   x0..x1     rabito
  0  Aldea Florecer     160    0..159     dentro
  1  Aldea Kintaro      160   56..215     dentro
  2  Aldea Dormilón     160   96..255     dentro
  3  Aldea Urashima     160   96..255     dentro
  4  Aldea Kachiyama    160    0..159     dentro
  5  Aldea Issunboshi   160   24..183     dentro
  6  Aldea Bambú        128   96..223     dentro
  7  Isla Ogros         128  128..255     dentro
```

Dos anchos distintos en el mapa. Ranuras con TODOS los sprites (norma 54):
13 de 16 con N=3, 15 de 16 con N=4.

El orden de dibujado conserva el de la v133 (norma 55): tres llamadas, con
el rabito entre el centro y la fila inferior.

### Un assert que evito un falso positivo

El verificador aborto con «N=5: 17 ranuras». Cierto, pero **el mapa nunca
usa N=5**: solo muestra los indices 1..8, y el unico nombre de 20 glifos es
el [0] (`Aldea de la Partida`, el pueblo natal) que solo aparece dentro de
la aldea, donde no hay sprites ajenos compitiendo. La comprobacion se
restringe a los anchos que el mapa usa de verdad.

### Un fallo mio, cazado desensamblando

Para indexar la tabla de punteros (3 punteros de 2 B = 6 B por ancho) hacia
falta `A*6`. Escribi:

```
ASL A / ASL A / STA $10 / ASL A / ADC $10    = A*4 guardado + A*8 = A*12
```

Con el indice 1 habria leido 12 bytes mas alla: fuera de la tabla. Lo correcto:

```
ASL A / STA $10 / ASL A / CLC / ADC $10      = A*2 + A*4 = A*6
```

Faltaba ademas el `CLC` antes del `ADC`. Norma 39: desensamblar lo escrito.

### Verificacion

Simulado el codigo para las ocho localizaciones, leyendo las tablas desde la
ROM y siguiendo los punteros: las ocho eligen su ancho correcto, ninguna se
sale de pantalla y los ocho rabitos caen dentro de su caja.

Aldea: caja de 192 px, 20 glifos, 12 ranuras de 16.

### Entrega

```
test_variable_v134.pce   MD5 6cf731595cb6c1745f979a3d2ed0b4af
momotaro_variable_v134.ips
645 bytes en 5 rangos
```

### Limitacion conocida

**La aldea usa de momento el ancho fijo maximo (N=5, 192 px).** Elegir el
ancho por longitud alli exige leer `$C3` (el contador de glifos) en `$DE38`,
que corre en otro momento que `$AD0F`, donde se calcula. Es el mismo
obstaculo que aplazamos en la v126 y sigue pendiente.

O sea: **el mapa ya tiene caja variable de verdad; la aldea, no todavia.**

### Que mirar

1. En el mapa: `Aldea Bambú` e `Isla Ogros` con caja mas estrecha que las
   demas, sin hueco a la derecha.
2. Los rabitos apuntando a su icono en los ocho puntos.
3. Que ninguna caja se salga ni tape el marco.
4. En la aldea, de momento sigue sobrando bocadillo: es lo esperado.

---

## (103) v135: caja variable en la aldea — el obstaculo no existia

### El argumento que veniamos repitiendo desde la v126

«Para elegir el ancho en la aldea haria falta `$C3` (el contador de glifos),
que se calcula en `$AD0F` pero se necesita en `$DE38`. Habria que guardar la
longitud en una variable de RAM y leerla despues: codigo nuevo en una
pantalla que sale constantemente.»

**Era falso.** Al mirar como `$AD91` decide QUE cadena mostrar:

```
$AD91  LDA $3B0D / BNE $ADA1
$AD96    -> GAME START (puntero fijo)
$ADA1    -> tabla $B79D[$3B0E]
```

El indice de la cadena esta en `$3B0D`/`$3B0E`, que son Work RAM y **siguen
validos cuando corre `$DE38`**. No hay que pasar nada entre rutinas: se leen
alli y se consulta una tabla de anchos, igual que el mapa con `$3CF6`.

Verificado contra el state de la aldea: `$3B0D = 1`, `$3B0E = 0`, y el
puntero medido era `$B7AF` = entrada 0. Coincide.

**Norma 56. Antes de inventar una variable para pasar un dato entre dos
rutinas, comprobar si el dato ya esta en una direccion que las dos ven.**

Este argumento nos costo diez versiones de aplazamiento. Nunca lo
comprobamos: lo dimos por bueno en la v126 y lo repetimos hasta la v134.

### Un susto con los bancos

Puse el codigo nuevo en el banco 0x17 (junto a las listas) y aborte el
constructor pensando que `$DE3D`, que vive en el banco 0x0C, no podria
saltar alli. **Si podria**: el propio `$DE3D` mapea el banco 0x17 en MPR2
antes de nada.

Aun asi se deja el codigo en el banco 0x0C (hueco de 168 B en `$DF58`), que
es donde corre `$DE38`: no depende del orden de los mapeos.

### Un fallo real: salto a media instruccion

```
$DF69  BNE +5   ->  $DF70
$DF6F  LDA $3B0E     (ocupa $DF6F..$DF71)
```

El `BNE` caia en `$DF70`, **el segundo byte** de `LDA $3B0E`. Habria
ejecutado basura. Corregido a `+4`.

**Norma 57. Los desplazamientos relativos se cuentan hasta el OPCODE
destino. Desensamblar siempre el salto escrito.**

### El resultado

```
                              v134      v135
Isla Ogros / Aldea Bambú      192 px -> 128 px
seis aldeas                   192 px -> 160 px
Partida / COMIENZA EL JUEGO   192 px    192 px
```

Los 80 px de hueco que veia David en `Isla Ogros` desaparecen.

### Verificacion

Simuladas las diez cadenas leyendo las tablas desde la ROM: las diez eligen
su ancho, ninguna se sale de pantalla, maximo 12 ranuras de 16, y la
capacidad de texto siempre alcanza para el nombre.

Intactos: bloque del mapa (v134), listas de aldea (v134), tabla de iconos,
nombres, y todo lo anterior.

### Entrega

```
test_aldea_v135.pce   MD5 06c7d70583c56d57fb01aa6edd6374ce
momotaro_aldea_v135.ips
440 bytes en 3 rangos
```

### Pendiente: el centrado

David: «lo que habria que hacer en los rotulos del mapa es centrar los
textos con los recuadros».

Y tiene respaldo en el original: los `0x20` del bloque B son **relleno de
centrado**. Hudson lo hacia exactamente asi, sin codigo:

```
[0] タビダチノ村    1 espacio delante, 1 detras
[8] オニガシマ      1 delante, 2 detras
[2] キンタロウノ村  0 y 0 (el mas largo)
```

Con la caja ya ajustada al texto el sobrante baja a 0-3 celdas, asi que el
centrado es ahora un ajuste fino. Se aplica sobre las cadenas, sin tocar
codigo. **Siguiente version.**

---

## (104) v136: sprites de 16 px, centrado, y el bug de $10

### El bug de la v135: $E3EB me pisaba la variable

David: «el rotulo de COMIENZA EL JUEGO y el del nombre de la aldea se ven
mal». Medido en su captura: una banda blanca de 16 px con el texto y **nada
de caja**, ni arriba ni abajo.

```
$DF79  STX $10        guardo el indice de la tabla
$DF91  JSR $E3EB      <-- $E3EB ESCRIBE EN $10 (cuatro veces)
$DF94  LDX $10        leo BASURA
$DF96  LDA $5CF3,X    puntero de la CAJA con indice corrupto
```

La primera llamada (texto) salia bien; la segunda (caja) leia un puntero
aleatorio. Coincide exactamente con lo observado.

Elegi `$10` sin comprobar quien mas lo usa. Barrido `$E3EB..$E5FF`: escribe
en `$10 $14 $15 $21 $53..$6C`. Se pasa la variable a **`$04`**, verificado
que ni `$E3EB` ni `$EE86` lo tocan.

**Norma 58. Antes de usar una direccion de zero page como temporal,
comprobar quien mas escribe en ella. Es la norma 24 aplicada a memoria.**

### La idea de David: graficos reutilizables

David pregunto si no seria mas economico usar graficos por letra en vez de
por nombre. **El juego ya lo hace**: la fuente de `0x3D660` guarda cada
glifo una vez (8x8 px, 1 bpp) y lo reutiliza. La `A` de `Aldea` es el mismo
dibujo en las nueve aldeas.

El problema real era la **granularidad**: el texto se dibujaba en bloques de
32 px = 4 letras, asi que el ancho saltaba de cuatro en cuatro.

### Sprites de 16 px

Cambiando a sprites de **16 px = 2 letras** el ajuste pasa a ser de dos en
dos:

```
                  32 px            16 px
Aldea Florecer    16, sobran 2     14, sobran 0
Aldea Urashima    16, sobran 2     14, sobran 0
Isla Ogros        12, sobran 2     10, sobran 0
Aldea Kintaro     16, sobran 3     14, sobran 1
```

Y **sale gratis en ranuras**: un sprite de 32 px consume 2 ranuras por
scanline; uno de 16, una sola. Las cifras del mapa bajan de 13-15 a 12-15
pese a las cajas nuevas.

Seis anchos en vez de tres: 112, 128, 144, 160, 176, 192 px.

### El centrado

El sobrante (0 o 1 celda) se reparte con espacios delante, como hacia el
original japones en el bloque `$B79D`.

### Resultado

```
                      v135      v136
Isla Ogros            128 px -> 112 px
Aldea Bambú           128 px -> 128 px
Aldea Florecer        160 px -> 144 px
Aldea Kachiyama       160 px -> 160 px
COMIENZA EL JUEGO     192 px -> 176 px
Aldea de la Partida   192 px -> 192 px
```

### Un assert con una constante mal medida

El constructor aborto con «no cabe el bloque del mapa». La causa no era el
espacio: `M_VIEJO` valia 322 y el bloque real de la v134/v135 mide **329 B**
(`0x1DC88..0x1DDD0`). La comprobacion miraba siete bytes de codigo vivo y
exigia que fueran `$FF`. Corregido tras medirlo.

### Verificacion

Simuladas las 10 cadenas de aldea y las 8 localizaciones del mapa leyendo
las tablas desde la ROM: todas eligen su ancho, ninguna se sale de pantalla,
los ocho rabitos caen dentro de su caja, y ninguna scanline pasa de 16
ranuras contando **todos** los sprites de la pantalla.

### Entrega

```
test_centrado_v136.pce   MD5 324cd2c1c1897a6ba4b3a9bf0078f9f8
momotaro_centrado_v136.ips
1259 bytes en 5 rangos
```

---

## (105) v137: las dos muescas, el centrado en la caja y el centrado en pantalla

Tres avisos de David sobre la v136, los tres reproducidos y corregidos.

### 1. «Al rotulo del mapa le faltan dos muescas»

Medido sobre su captura `_003.png` (Aldea Florecer, caja de 144 px):

```
y=162   blanco en x  15..95   y  112..128      <- falta 96..111
y=178   blanco en x  11..132                   (fila central, entera)
y=182   blanco en x  12..95   y  112..131      <- falta 96..111
```

Hueco de 16 px exactos, arriba y abajo, en la misma X. Eso son las muescas.

**Causa.** La caja del mapa se monta con esquinas de 32 px y rellenos de
32 px:

```
cubierto = 64 + ((A-64)//32)*32

A=112 -> 96   hueco 16        A=128 -> 128  hueco 0
A=144 -> 128  hueco 16        A=160 -> 160  hueco 0
A=176 -> 160  hueco 16        A=192 -> 192  hueco 0
```

La v136 introdujo anchos de 16 en 16 pero dejo el relleno en pasos de 32.
Los tres anchos que no son multiplo de 32 pierden media pieza.

Encaja con lo que se ve: de las ocho localizaciones, las cuatro de 144 y
112 px salen con muesca y las de 128 y 160 no. Verificado ademas
renderizando la **v136** con el simulador: muescas en Florecer, Kintaro,
Dormilon, Urashima e Isla Ogros; limpias Kachiyama, Issunboshi y Bambu.

La ALDEA no tenia el fallo porque alli el relleno ya iba de 16 en 16. Por
eso las capturas `_004` y `_005` muestran la caja entera.

**Arreglo.** Rellenos de 32 px mientras quepan y **uno de 16** para el
resto. El patron `$034C` esta lleno en las 16 columnas (medido: `$034A`,
`$034C` y `$034E` son el mismo dibujo), asi que la media pieza sale del
grafico que ya existe. Las ranuras no cambian: dependen del ancho en
pixeles, no de en cuantos trozos se parta.

**Norma 59. Al ensanchar un contenedor por pasos de N, el relleno tiene que
avanzar de N en N. Si el paso del contenido es la mitad del paso de la
pieza, la ultima media pieza no se dibuja.**

### 2. «El rotulo dentro de la aldea sigue alineado a la izquierda»

Medido en `_005.png` (Aldea de la Partida, 19 letras en 20 celdas):

```
caja visible  x  11..180
texto negro   x  16..164
margen izq 5     margen der 16      -> 11 px de desequilibrio
```

**Causa.** Mia, y es un error de aritmetica entera que deberia haber visto:

```python
sob = N*2 - len(txt)          # 1 celda
' ' * (sob // 2)              # 1//2 = 0 -> NINGUN espacio
```

Con sobrante de 1 celda el centrado por espacios no puede funcionar: la
unidad minima es la celda de 8 px y hace falta media. Todo el sobrante se
iba al lado derecho. La v136 imprimia «centrado» en el log y era mentira:
el log contaba el reparto teorico, no el resultado.

**Arreglo.** El centrado deja de hacerse con espacios y pasa al `dx` de los
sprites, que admite pixel suelto:

```
dx_texto = -half + 16 + (N*2 - len(txt)) * 4
```

Cuatro pixeles cuando la longitud es impar, cero cuando es par. Como el
sobrante depende del NOMBRE y el ancho de la CAJA, la lista de texto se
separa de la de caja: la caja se indexa por ancho, el texto por
(ancho, sobrante). Dos tablas de indice en vez de una.

### 3. «El COMIENZA EL JUEGO sigue sin estar centrado en la pantalla»

```
_004.png  caja x  19..172   centro 95,5
_005.png  caja x  11..180   centro 95,5
pantalla  0..255            centro 127,5
```

Las dos cajas comparten centro: no es cosa del texto, es el ancla.

**Causa.** `LDX #$60` = 96, el ancla del original japones, de cuando el
rotulo era corto. Con las cajas ensanchadas hacia los dos lados el conjunto
queda 32 px a la izquierda.

**Arreglo.** `LDX #$80` = 128. Con el ancho maximo (192 px) la caja queda en
32..223, holgada. El rotulo de aldea no lleva rabito —comprobado en el SATB
de `aldea_vram.bin`: solo los patrones $03E0/$03E2/$03E8 y el texto—, asi
que mover el ancla no descoloca nada. Afecta a los dos rotulos que pasan
por esa rutina, el nombre de aldea y COMIENZA EL JUEGO.

El ancla del MAPA **no** se centra: alli el rotulo tiene que quedarse sobre
su aldea y el rabito la señala.

### El simulador, y dos errores propios al construirlo

Para no volver a entregar sin comprobar, se ha escrito un renderizador que
lee las listas de la ROM y las pinta con los patrones reales de la VRAM.
Fallo dos veces antes de servir:

1. **Paleta inventada.** Asumi indices 1=blanco y 14=negro. Medidos: los
   patrones usan **4 y 6 = blanco, 7 = negro**. La primera tanda de
   imagenes salio en negro sobre negro.
2. **Bit de espejo mal.** Lei el flip horizontal de `alo & 0x08` cuando esta
   en el bit 11 del atributo completo (`attr & 0x0800`). Las esquinas
   derechas salian del reves y fingian una muesca donde no la habia.
3. **Sin remapeo de caracteres.** Pintaba `#` en vez de espacio: falta la
   tabla `$AB34` (`$20 -> $3C`, glifo vacio).

Los tres se detectaron porque el simulador **contradecia la captura de
David**, no al reves. Una vez corregido reproduce `_003.png` en el pixel,
incluidas las muescas de la v136.

**Norma 60. Un simulador solo vale cuando reproduce una captura conocida.
Antes de creerle un OK hay que verle reproducir el fallo.**

### Verificacion

Las 8 localizaciones del mapa y los 10 rotulos de aldea, renderizados:

```
MAPA                                            ALDEA (ancla 128)
loc 0 Aldea Florecer    120 px  desv 0          Aldea de la Partida  168 px  centro 127,5
loc 1 Aldea Kintaro     120 px  desv 0          Aldea Florecer       120 px  centro 127,5
loc 2 Aldea Dormilón    120 px  desv 0          Aldea Kintaro        120 px  centro 127,5
loc 3 Aldea Urashima    120 px  desv 0          Aldea Dormilón       120 px  centro 127,5
loc 4 Aldea Kachiyama   136 px  desv 0          Aldea Urashima       120 px  centro 127,5
loc 5 Aldea Issunboshi  136 px  desv 0          Aldea Kachiyama      136 px  centro 127,5
loc 6 Aldea Bambú       104 px  desv 0          Aldea Issunboshi     136 px  centro 127,5
loc 7 Isla Ogros         88 px  desv 0          Aldea Bambú          104 px  centro 127,5
                                                Isla Ogros            88 px  centro 127,5
ninguna muesca en las filas de borde            COMIENZA EL JUEGO    152 px  centro 127,5
```

- Los 8 rabitos caen dentro de su caja, con 4 px de margen a los bordes.
- Ranuras por scanline contando **todos** los sprites (norma 54):
  mapa 12/13/14/15 de 16; aldea 7 a 12 de 16.
- Zonas intactas: motor `$E3EB`, `$EE86`, boton II, padres, intro,
  tutorial, fuente, tabla de iconos y rutina del icono de aldea.
- `$04` sigue libre: barrido `$E3EB..$E91E` sin una sola escritura.
- Espacio: mapa 659 B de 888; datos de aldea 872 de 1140; codigo 87 de 168.

### Entrega

```
test_muescas_v137.pce   MD5    2a67702b014a7a381751394f777f95c5
                        SHA-1  85a69c58ffe59682919183eb31e6b5392a3c7107
                        CRC32  42cff2b6
momotaro_muescas_v137.ips
1531 bytes modificados
capturas/v137_simulacion.png   los 18 rotulos renderizados
```

---

## (106) v138: el hueco de 4 px, o quien pintaba el fondo

David, sobre la v137: da por buenos el tamano y la ubicacion de todos los
recuadros, incluido COMIENZA EL JUEGO. Un solo fallo: «tenemos algunos
huecos sin pintar que dejan ver el fondo», a la izquierda de la 'C' de
COMIENZA y de la 'A' de Aldea.

### La medida

Sus capturas, fila y=113 (banda central, sin letras):

```
COMIENZA EL JUEGO    blanco 51..55  |  HUECO 56..59  |  blanco 60..204
Aldea de la Partida  blanco 43..47  |  HUECO 48..51  |  blanco 52..212
Aldea Urashima       blanco continuo, sin hueco
```

Cuatro pixeles exactos. Y solo en los nombres de longitud IMPAR.

### La causa: el fondo no lo pinta la caja

La banda blanca del interior la forman DOS cosas distintas, no una:

- los sprites LATERALES ($03E8 aldea / $0350 mapa), que solo cubren 16 px
  pegados a cada esquina. Columnas del patron, medidas sobre la VRAM:

  ```
  $03E8:  ..........NWWWWW      N = borde negro, W = blanco
  ```

  Su blanco acaba en `-half+15`.

- los sprites de TEXTO, que **aportan su propio fondo**: el juego limpia su
  CG a blanco (bucle `$AD7A`, cuatro `JSR $FC43` escribiendo 00,FF,FF,00 =
  indice 6) y pinta el glifo encima.

En la v137 centre el texto desplazando su `dx` +4 px cuando el sobrante es
impar. No movi a quien pintaba el fondo:

```
lateral llega hasta   -half+15
texto empieza en      -half+16+4 = -half+20
                            ^^^^ nadie pinta estos 4 px
```

Los 4 px del hueco son exactamente el desplazamiento de centrado. Con
sobrante par el desplazamiento es 0 y no hay hueco: encaja con que
Urashima e Isla Ogros salgan limpios.

**Norma 61. Si un elemento aporta su propio fondo, moverlo mueve el fondo.
Antes de desplazar algo hay que preguntarse quien pintaba lo que tapaba.**

### El arreglo: un tapon de blanco solido

En el CG de los dos rotulos ya existe un patron 16x16 de blanco uniforme,
sin usar por ninguna lista:

```
ALDEA  $03EC   {indice 4: 256 px}
MAPA   $0354   {indice 4: 256 px}
```

Verificado que ninguna lista los referencia y que estan dentro del CG que
el juego ya carga (aparecen en `aldea_vram.bin`, `mapa_vram.bin` y
`carga_vram.bin`). Se anade un sprite de relleno en `-half+16`, solo cuando
el sobrante es impar.

Solo hace falta a la IZQUIERDA. Por la derecha el texto termina en
`half-16-1+4`, o sea que solapa con el lateral derecho: medido para las
cinco longitudes impares, siempre solapa. Un tapon por rotulo, no dos.

Descartadas: tocar la rutina de relleno del CG del juego (`$AA16` ->
`$D619`, codigo vivo de Hudson, riesgo alto) y mover el lateral (movia el
borde negro hacia dentro y estrechaba la caja por un lado).

### El z-order: el tapon se comia dos letras

Primer intento: el tapon dentro de la lista superior. En la ALDEA salio
bien; en el MAPA se leia **«dea Kintaro»**.

La razon es el orden de emision. En el mapa es
`caja_sup -> texto -> rabito -> caja_inf`: la superior sale con indice de
SATB mas bajo, y en el PCE el indice bajo se dibuja ENCIMA (norma 55). El
tapon tapaba las dos primeras letras.

Arreglado metiendo el tapon en la lista INFERIOR, que se emite la ultima y
queda detras. Un registro puede llevar cualquier `dy`, asi que va en la
lista de abajo pero se dibuja en la banda central.

### El simulador, otra vez, y tres correcciones mas

`render_rotulos.py` dijo «sin huecos» en los 18. Mentira, y por una razon
de fondo: **pintaba solo los glifos, no el fondo blanco de las celdas**.
Con esa omision el hueco era literalmente invisible para el script.

Corregido: cada celda pinta 16x16 de blanco y el glifo encima. Ademas:

1. **Z-order invertido.** Pintaba en orden de emision; en el PCE el indice
   bajo va encima, o sea que hay que pintar al reves. Sin esto el
   simulador no habria visto nunca el tapon comiendose las letras.
2. **Deteccion de huecos mal acotada.** Buscaba discontinuidades en todas
   las filas, y los glifos parten el blanco legitimamente: daba «hueco de
   2 px» en rotulos que David da por buenos. Se acota a la ultima fila de
   banda antes de las letras, que es justo donde el hueco se ve.
3. Se separa la comprobacion en `tools/check_huecos.py`, que primero se
   valida contra la v137 (debe VER los 8 huecos) y luego se aplica a la
   v138.

La norma 60 se cumplio a medias en la v137: le vi reproducir las muescas,
pero no le exigi reproducir un fallo de FONDO. Ampliada:

**Norma 62. Un verificador hay que validarlo contra la version ROTA antes
de creerle un OK en la version nueva. Si no ve el fallo conocido, no ve
nada.**

### Verificacion

```
v137 (control)   8 rotulos con hueco, en x 48..51 y 56..59   <- coincide con David
v138             NINGUN hueco de fondo en los 18
```

- Recuento de tinta por rotulo cruzado con el texto esperado: ningun
  glifo tapado, ni en mapa ni en aldea.
- Ranuras por scanline contando todos los sprites (norma 54):
  mapa 12 a 16 de 16; aldea 7 a 13 de 16. **N=8 con sobrante 1 llega
  justo a 16**: es el limite exacto, sin margen. Si aparece un sprite mas
  en esa pantalla, parpadeo. Vigilar.
- Zonas intactas: motor `$E3EB`, `$EE86`, boton II, padres, intro,
  tutorial, fuente, tabla de iconos, rutina del icono y nombres japoneses.
- Espacio: mapa 806 B de 888; datos de aldea 1073 de 1140; codigo 87 de 168.

### Entrega

```
test_tapon_v138.pce   MD5    88ff34d3699bb0b6941d085f2f091f42
                      SHA-1  684b21f7ac87525a0ff74a745285fdccf2d9ce9f
                      CRC32  54f4a307
momotaro_tapon_v138.ips
1848 bytes modificados
capturas/v138_simulacion.png    los 18 rotulos renderizados
tools/render_rotulos.py         renderizador (corregido)
tools/check_huecos.py           verificador de huecos de fondo
```

---

## (107) v139: los acentos del menú, y una conclusión falsa de hace 74 versiones

Pendiente desde la v75: el menú dice `FACIL` y `MUY DIFICIL`, sin tilde. La
entrada (33) lo llamó «opción 3, coste cero», pero era una rendición: (32)
había concluido que «no hay hueco dentro de la fuente».

**Esa conclusión era falsa, y la mía de hoy también empezó torcida.**

### El diario decía que salía basura. No es verdad

(33) afirmaba: «antes salen dos manchas de gráfico en el sitio del acento».
Renderizados los cuatro rótulos leyendo las tablas de la ROM: salen `Á` e
`Í` perfectamente legibles, sólo que **de trazo fino**, del alfabeto
pequeño del diálogo, junto a mayúsculas gruesas.

```
   A gruesa (glifo 112)      Á fina (glifo 194)
     ..###...                  ..##....
     .##.##..                  .#......
     ##...##.                  .###....
     ##...##.                  #...#...
     #######.                  #####...
```

El problema nunca fue basura: era **estilo**. Nadie lo comprobó
renderizando, y el apaño de la v75 quitó unas tildes que sí se veían.

### Mi propio error: apliqué la ruta equivocada

Razoné: «`0xC2 - 0x30 = 0x92 >= 0x54`, cae al fallback, lee la fuente del
menú fuera de rango». Es la comprobación de la ruta BAJA aplicada a un byte
que va por la ALTA. En `$AAB9`:

```
CMP #$A0 / BCC $AB1B      ; byte < 0xA0 -> ruta baja
```

`0xC2 >= 0xA0`, así que nunca llega ahí. Va por la alta, donde
`tabla[0xC2-0xA0] = 194`, que es la `Á` fina. Coincide con lo renderizado.

### (32) midió la fuente equivocada

Desensamblada la elección de fuente, `$AB1B`:

```
SBC #$30 / CMP #$54 / BCS $AB29     ; >= 0x84 -> fallback
TAX / LDA $BF9B,X                   ; tabla ROM 0x43F9B
BNE $AAD4                           ; != 0 -> fuente DIÁLOGO
```

La fuente se elige **por carácter**, mirando la tabla, no por pantalla.
`'F' = 0x46 -> idx 0x16 -> tabla = 0x75 != 0 -> fuente DIÁLOGO`.

`FÁCIL` **no usa la fuente del menú**. Todo el análisis de (32) —los 48
slots, los katakana que no cuadraban la regla de sombra, el inventario de
50 códigos— medía una fuente que estos rótulos ni tocan.

**Norma 63. La fuente que usa un texto se decide por CARÁCTER en la tabla,
no por la pantalla en la que sale. Antes de buscar hueco en una fuente hay
que comprobar que el texto la usa.**

### Y hay CUATRO tablas altas, no una

Primer intento: enganchar la `Á` nueva en el byte `0xA0` de `$9CB3`. El
render salió idéntico: no hacía nada. En `$AAC0`:

```
LDA $3BA6 / ASL / TAX / LDA $ABAF,X
   fuente 0 -> $9CF3      fuente 2 -> $F8AE
   fuente 1 -> $9CB3      fuente 3 -> $BD37
```

`FÁCIL` empieza por `01` = fuente 0 = `$9CF3`, y yo había escrito en
`$9CB3`. Norma 15 otra vez: lo medido en una tabla no vale para la otra.

La ruta BAJA, en cambio, usa `$BF9B` **fijo** (`$AB23`), sin indexar por
fuente: es común a las cuatro. Los acentos van por ahí.

### La solución

Dos glifos nuevos, dibujados con el criterio del propio Hudson. La fuente
del menú tiene una `Ó` acentuada en `0x5B` hecha por el grafista original:
tilde en las filas 0-1 y cuerpo comprimido a las filas 2-7. Se copia.

```
ranuras de glifo   254 y 255 (ROM 0x3DE50, 0x3DE58)
                   no las referencia ninguna de las 6 tablas; su contenido
                   era relleno, no letras
códigos de texto   0x3A -> Á    0x63 -> Í
                   entradas a 0 en la tabla baja, sin un solo uso en los
                   73 streams de texto del juego
```

Entradas a 0 en la tabla baja: `3A 3B 3C 40 63`. `3C` es el espacio
(16 streams) y `40` sale en uno; los otros tres están libres.

**[DESCARTADO] repuntar `0xC2`/`0xC4` a los glifos nuevos.** Habría evitado
tocar las cadenas, pero son katakana vivos: aparecen en 15 y 24 streams de
texto japonés sin traducir. Los repunta y se rompe el japonés.

### Verificación

- **22 bytes** distintos de la v138: 16 de los dos glifos, 2 de la tabla,
  4 de las tildes. El constructor aborta si son más o menos.
- Contexto completo de las cuatro cadenas comprobado antes de escribir.
- `0xC2` y `0xC4` siguen apuntando a 194/196 en **las dos** tablas altas:
  el japonés no se toca.
- Los otros 254 glifos de la fuente, byte a byte iguales.
- Intactos: fuente del menú, bloques del mapa y de aldea de la v138,
  intro, padres, botón II.
- Renderizados los cuatro rótulos antes y después con las tablas reales.

Un fallo más de mi renderizador, de paso: pintaba `0x20` sin pasar por el
remapeo `$AB34` (`$20 -> $3C`), y el espacio de `MUY DIFÍCIL` salía como un
churro. La ROM estaba bien; el visor, no. Tercera vez esta sesión.

### Entrega

```
test_acentos_v139.pce   MD5    3276f29fd51a44c8a992cb9dfebfdfd1
                        SHA-1  adc2f5e69e6795f0b15f9bce6aead408049305d2
                        CRC32  d8e512b3
momotaro_acentos_v139.ips
22 bytes modificados
capturas/v139_menu_antes_despues.png
```

---

## (108) Los niveles ocultos: dos bloques de texto nuevos, y bastante más detrás

David cae por un hueco a un nivel oculto, ve al abuelo hablar y sospecha
que la primera frase «dice otra cosa» aunque el resto se parezca al
tutorial. Pasa un `.state` de la ROM virgen.

**Tenía razón en las dos cosas.**

### El state

Formato `#RZIP v1` (Mesen): cabecera de 24 B y el resto zlib. Descomprime
a 83.552 B, un savestate de Mednafen con chunks `VRAM` (0x10000) y
`BaseRAM` (0x2000). Extraídos a `docs/oculto_vram.bin` y `oculto_ram.bin`.

### El bocadillo es el MISMO motor que el rótulo del mapa

SATB del state, 33 sprites activos:

```
fila sup   y=40   esquina $0348 + 4 rellenos $034C + esquina $0348 espejo
laterales  y=56, y=72   patrón $0350 a cada lado
TEXTO      y=56   $035C $0360 $0364 $0368 $036C   5 sprites de 32 px
           y=72   $0374 $0378 $037C $0380 $0384   5 sprites de 32 px
rabito     y=88   patrón $035A en x=120
fila inf   y=88   espejo vertical de la superior

caja x 33..222 = 190 px;  texto 160 px = 20 celdas por línea
```

Son **exactamente** los patrones del rótulo del mapa ($0348/$034C/$0350/
$035A) y la misma base de CG. La única diferencia: dos filas de texto en
vez de una. Es decir, el trabajo de las v130-v138 vale tal cual aquí.

> Nota: David describe además un bocadillo **vertical** en la esquina
> superior derecha cuando el abuelo habla al llegar a meta. Ese no está en
> este state (el state es del principio del nivel). Pendiente de capturar.

### Los dos bloques nuevos

Barrido del banco `0x1F000-0x1F600` decodificando katakana JIS X 0201:

```
0x1F2C9 .. 0x1F365   TUTORIAL              157 B   ya traducido (v89)
0x1F366 .. 0x1F3D5   ESCENA DE LOS PADRES  112 B   ya traducida (v125)
0x1F3D6 .. 0x1F441   MINIJUEGO A           108 B   *** NUEVO ***
0x1F442 .. 0x1F4AD   MINIJUEGO B           108 B   *** NUEVO ***
```

Los dos con la misma estructura: **3 páginas de 2 líneas**, separador de
página `$FD $FD $FE`, terminador `$FF`.

**BLOQUE A** — el que David ha encontrado. Minijuego de la *kusudama*
(くす玉: la bola de papel que al romperla suelta confeti):

```
オオ ヨクキタ モモタロウヨ!          15 celdas
カルイ ウント゛ウテ゛モ ト゛ウチ゛ャ!   16
クスタ゛マヲ ミコ゛ト ワッテミセイ     16
イイコトカ゛ アルソ゛! ウヒャヒャ      17
サア ヨウイハイイカ!                12
スタート チ゛ャ!                    9
```

**BLOQUE B** — otro minijuego que aún no ha visto. Va de tocar al 福の神
(dios de la fortuna) y evitar al 貧乏神 (dios de la pobreza):

```
ナント コンナトコマテ゛キタカ         14 celdas
チョット タノシンテ゛イクカ?          14
フクノカミニ サワレハ゛ヨシ           13
ヒ゛ンホ゛ウカ゛ミニ サワレハ゛        12
トニカク ソウイウコトチ゛ャ!          14
ヨウイハイイカナ スタートチ゛ャ!      18
```

Máximo 18 celdas de las 20 disponibles.

### Cotejo con las capturas de David

Sus tres capturas grandes: la primera (`おお よくきた ももたろうよ！ /
かるい うんどうでも どうぢゃ！`) es literalmente la página 1 del bloque A.
Las otras dos (`ゴールめざして…`, `おちてくる ウンチを…`) son del tutorial
ya traducido. Confirma su intuición: la primera frase es distinta, el
resto lo comparte con el tutorial porque **es el mismo motor**.

### Hay bastante más de lo que creíamos

Buscando `ウヒャヒャ` (la risa del abuelo) aparecen dos zonas fuera de este
banco, sin catalogar en el diario:

```
0x4AE25   ermitaño: «te enseñaré una técnica», un QUIZ de preguntas,
          y el juego de アッチムイテホイ (acchi muite hoi)
0x4B8E2   respuestas del acchi muite hoi: ジャンケン ポン, アイコデ ショ,
          «todavía te falta entrenamiento», etc.
```

Son minijuegos completos con su propio guion. **Se anotan, no se tocan
todavía.**

### Propuesta de traducción (pendiente del visto bueno de David)

20 celdas por línea, todas comprobadas:

```
BLOQUE A                          BLOQUE B
¡Oh! ¡Bienvenido,      17         ¡Vaya! ¿Has llegado    19
Momotaro!               9         hasta aquí?            11
¿Qué tal un poco de    19         ¿Te diviertes un       16
ejercicio suave?       16         rato conmigo?          13
¡Revienta la bola de   20         Toca al dios de la     18
un buen golpe!         14         fortuna: bien.         14
¡Habrá premio!         14         Como toques al de la   20
¡Ujujuy!                8         pobreza...             10
¿Listo? ¡Vamos allá!   20         ¡En fin, de eso va     18
¡A empezar!            11         la cosa!                8
                                  ¿Preparado?            11
                                  ¡A empezar!            11
```

El bloque A tiene 3 páginas y mi propuesta usa 5 pares de líneas: hay que
repartirlo en 3 páginas antes de construir. **Norma 38: no se reparticiona
sin que David lo vea.**

Espacio: cada bloque son 108 B en su sitio, y quedan 1891 B libres en
`0x1F89D` y 1597 en `0x1F9C3` si hiciera falta reubicar.

---

## (109) [CORRECCIÓN a (108)] El bloque que David juega es 0x1F366, no 0x1F3D6

David: «los textos que me pones no se corresponden con los que te he puesto
yo en las capturas. Lee bien el texto de las capturas y verás que tengo
razón. En este minijuego no hay ninguna bola a la que golpear. Es
exactamente como el del tutorial, pero con los ñordos distribuidos de forma
diferente».

**Tiene razón. Mi entrada (108) señalaba el bloque equivocado.**

### El error, y de dónde salió

Sus tres capturas dicen, en orden:

```
おお よくきた ももたろうよ！ / かるい うんどうでも どうぢゃ！
おちてくる ウンチを / よけるのぢゃ！
ゴールめざして みぎに すすめ！ / よーい！ スタートぢゃ！
```

Eso es **literalmente** el bloque `0x1F366`, línea por línea:

```
オオ ヨクキタ モモタロウヨ!
カルイ ウント゛ウテ゛モ ト゛ウチ゛ャ!
オチテクル !ウンチ!ヲ
ヨケルノチ゛ャ! !ウヒャヒャ!
コ゛ール!メサ゛シテ ミキ゛ニ ススメ!
ヨーイ! !スタート!チ゛ャ!
```

Yo lo había etiquetado como «escena de los padres» porque **eso ponía el
diario** en la entrada (47), y lo di por bueno sin comprobarlo. Esa etiqueta
se puso en su día sólo porque el bloque **empieza** con `オオ ヨクキタ
モモタロウヨ`, no porque se verificara a qué escena pertenece.

Comprobación que debí hacer y no hice: buscar en `0x1F366..0x1F3D5` las
palabras propias de la escena de los padres.

```
キビダンゴ (kibidango)  NO
オニ (ogro)             NO
リョウ (ryo, dinero)    NO
```

No hay ninguna. No es la escena de los padres. La de los padres es otra y
ya está traducida en `0x1FEA9` (v125), con su kibidango y sus 50 ryos.

**Norma 34 al pie de la letra, incumplida por mí: antes de reutilizar lo que
el diario diga de una dirección, hay que releerlo Y comprobarlo. Una
etiqueta heredada no es una medición.**

### El mapa real de los bloques

```
0x1F2C9 .. 0x1F365   157 B   TUTORIAL (nivel de los ñordos)   traducido v89
0x1F366 .. 0x1F3D5   112 B   NIVEL OCULTO 1 (ñordos otra vez) <- el de David
0x1F3D6 .. 0x1F441   108 B   NIVEL OCULTO 2 (kusudama)
0x1F442 .. 0x1F4AD   108 B   NIVEL OCULTO 3 (fortuna/pobreza)
```

Cuatro bloques, no dos. Y David acierta también en lo otro: **comparten
frases**. Cruzadas línea a línea, `0x1F366` reutiliza dos del tutorial
palabra por palabra (`オチテクル ウンチヲ`, `ヨーイ! スタートチ゛ャ!`) y
varía las demás. Son variaciones del mismo guion, no textos nuevos.

El bloque del tutorial tiene 4 páginas (incluye la del botón II para
saltar); los tres ocultos, 3 páginas.

### El bocadillo vertical de la meta: medido

Captura de David, 256x240, esquina superior derecha:

```
caja  x 161..239   y 10..69
texto vertical, columnas de derecha a izquierda
ももたろうは / 50両を / てに いれた
```

El texto está en `0x48D35`, y **es de ancho fijo**. Los once registros de
esa zona van seguidos sin terminador, a **18 bytes** cada uno (19 los que
llevan dakuten, que no ocupa celda):

```
0x48D23  モモタロウハ100両ヲ テニ イレタ
0x48D35  モモタロウハ 50両ヲ テニ イレタ   <- el de su captura
0x48D47  モモタロウハ 30両ヲ テニ イレタ
0x48D59  モモタロウハ 10両ヲ テニ イレタ
0x48D6B  モモタロウハコレイジョウモテナイ!
0x48D7E  モモタロウハイヌヲ  オトモニシタ
0x48D90  モモタロウハキジヲ  オトモニシタ
0x48DA3  モモタロウハサルヲ  オトモニシタ
0x48DB5  モモタロウハコウラヲ テニ イレタ
0x48DDD  モモタロウハ 80両ヲ テニ イレタ
0x48DEF  モモタロウハ 20両ヲ テニ イレタ
```

Los 11 miden **18 celdas exactas**. El separador es `0xA0` y el 両 se
codifica como `$` (`0x24`), como ya anotaba (47).

### Sobre la intuición de David acerca del dinero

Él avisa: «no podremos poner la cantidad de dinero en texto, sino que habrá
que dejar la triple (o doble) etiqueta que haya».

**Medido: el número NO es dinámico.** Hay una cadena distinta por importe,
con las cifras escritas dentro. El juego elige cuál mostrar según lo bien
que lo hayas hecho, que es justo lo que él observó jugando dos veces.

O sea: su observación del comportamiento es correcta y su deducción de que
el importe varía, también. La consecuencia técnica es **mejor** de lo que
temía: al no componerse en tiempo real, el número se puede recolocar dentro
de la frase con total libertad («Momotaro consigue 50 ryos»). No hace falta
respetar ninguna etiqueta.

Pero el aviso era pertinente: si hubiera sido dinámico, escribir el número
en el texto lo habría roto. Se comprueba antes de tocar, no después.

### Restricción real para traducir

Al ser **ancho fijo de 18 celdas sin terminador**, no se puede alargar
ninguna: si una cadena crece, se come la siguiente. Las once entran en
`0x48D23..0x48E00` y hay que respetar el paso de 18 B, o reubicar el bloque
entero y repuntar quien lo lee. Se decide al llegar a las tiendas.

### Sobre los patrones del bocadillo

David: «pensaba que compartirían los patrones del rótulo del tutorial de los
ñordos, que es igual».

Es exactamente así, y lo medido en (108) lo confirma desde el otro lado: el
bocadillo de instrucciones usa `$0348`/`$034C`/`$0350`/`$035A`, los mismos
que el rótulo del mapa. Los tres —tutorial, niveles ocultos y mapa— son el
mismo motor. Lo que dije en (108) («es el mismo motor que el rótulo del
mapa») y lo que dice él («comparte los patrones del tutorial») son la misma
frase vista desde dos sitios.

### Lo del minijuego de preguntas

David: «creo que el minijuego de las preguntas es entrando en una casa. Lo
veremos en la etapa de traducir tiendas». Anotado: `0x4AE25` (ermitaño +
quiz) y `0x4B8E2` (acchi muite hoi) se abordan con el bloque de tiendas
`0x48470`, que está en el mismo banco.

---

## (110) El tutorial en español, recuperado de la ROM, y el cruce por página

David: «no es que lo tenga apuntado en ningún sitio, pero lo tradujiste tú».
Pasa una captura con «¡Esquiva los ñordos que caen! ¡Ja, ja!».

Su texto no estaba en ningún `.md`: sólo dentro de la ROM. Recuperado
decodificando `0x1F2C9` con `CHAR_TO_CODE` invertido.

### El texto de David, tal cual está en la v139

```
pag1   18  ¡Primero, calienta        maズハ ゲームヲ タノシムタメノ
       15  antes de jugar!           ジュンビ ウンドウヂャ!
pag2   19  ¡Esquiva los ñordos       オチテクル ウンチヲ
       18  que caen! ¡Ja, ja!        ヨケルノヂャゾ! ウヒャヒャ!
pag3   17  ¡Pulsa I y salta          (I)ボタンヲ オセバ ジャンプシテ
       17  para esquivarlos!         ヨケラレルコトニ ナットル!
pag4   16  ¡Ve a la derecha          ゴール メザシテ ミギニ ススメ!
       19  hasta la meta! ¡Ya!       ヨーイ! スタートヂャ!
```

> Detalle: el `$3C` que aparece al final de «¡Pulsa I y salta » es un
> espacio ya remapeado (`$AB34` convierte `$20 -> $3C`), no un carácter
> perdido. Lo confirmé antes de darlo por bueno.

### [ERROR MÍO, corregido antes de entregar] cruzar por línea

Primer cruce automático: emparejé la lista de líneas japonesas con la de
líneas españolas **por posición**. Resultado:

```
ヨーイ! スタートヂャ!   ->  «hasta la meta! ¡Ya!»
```

Que suena a acierto pero es falso. En la página 4, David **reordenó las dos
líneas**: la idea de «meta» está en la línea 1 del japonés
(`ゴール メザシテ...`) y en la línea 2 del español. El emparejamiento por
posición mezcla una frase con la traducción de la otra.

La unidad de traducción no es la línea: es la **página**. Es lo mismo que
pasó con el reparto de la intro y de la escena de los padres — el texto se
reparte dentro de la página, no línea a línea.

**Norma 64. Al cruzar un original con su traducción, la unidad es la PÁGINA.
Emparejar línea a línea produce falsos aciertos, porque el traductor
reordena dentro de la página.**

### Reutilización real, cruzada por página

```
OCULTO 1 (0x1F366)          OCULTO 2 (0x1F3D6)     OCULTO 3 (0x1F442)
pag1  nueva                 pag1  = oculto 1       pag1  nueva
pag2  = tutorial pag2       pag2  nueva            pag2  nueva
pag3  = tutorial pag4       pag3  nueva            pag3  nueva
```

El bloque de David reutiliza **dos páginas enteras** del tutorial (la de
esquivar y la de la meta), con una variación menor: dice `ヨケルノヂャ!` en
vez de `ヨケルノヂャゾ!`. La traducción vale igual.

La página 1 (`オオ ヨクキタ モモタロウヨ / カルイ ウンドウデモ ドウヂャ`) es
común a los ocultos 1 y 2.

### Estado

Textos identificados, medidos y cruzados. Propuesta de traducción escrita
en `docs/Niveles_ocultos.md`, todas las líneas dentro de 20 celdas.
**Pendiente del visto bueno de David antes de construir** (norma 38).

---

## (111) v140: los tres niveles ocultos, y el `$FD` que se dejaron en el tintero

### El `$FD` no es una pausa: es «espera al botón»

Lo llamé «pausa dramática» en la entrada (110) sin desensamblarlo. Es una
descripción inventada a partir de lo que parecía. Medido:

```
$D1D5  (manejador de $FD)
   LDA #$01 / STA $3CE7        ; flag "esperando"
   LDA #$80 / TSB $3CE4
$D20A  (cada frame, mientras hay texto)
   LDA $3CE7 / BEQ ...         ; ¿esperando?
   LDA $44 / BIT #$01          ; <- LEE EL MANDO (botón I)
   BEQ ...                     ; sin botón: sigue esperando
   STZ $3CE7                   ; con botón: continúa
```

`$44` es el mando. `$FD` **detiene el texto hasta que el jugador pulsa**,
no cuenta frames. Por eso el fin de página normal es `$FD $FD $FE`: dos
esperas y cambio.

David preguntó si añade una flechita o es una pausa breve. Ni una cosa ni
la otra: es una espera de botón sin indicador visual. Su descripción de lo
que se ve en pantalla («dice lo que tiene que decir y antes del ¡YA! espera
un poco») era correcta; la mía de lo que hace el byte, no.

**Norma 66. Un byte de control no se describe por lo que parece en
pantalla: se desensambla su manejador.**

### Contestando a David: ¿se les olvidó?

No. Los **cuatro** bloques japoneses lo llevan (tutorial y los tres
ocultos): 9 bytes `$FD` el tutorial, 7 cada oculto. Es deliberado y
sistemático. Quien lo perdió fue **nuestra v89**: 8 en vez de 9.

Repuesto en el tutorial y puesto en los tres bloques nuevos.

### El espacio: la intro japonesa estaba muerta

El texto español no cabía: 365 B para 328 disponibles, faltaban 37.

David eligió la opción B (mudar de banco y tocar el `LDA #$0F`). No hizo
falta. Buscando en el propio banco `0x0F` aparecen **392 B** en `0x1F5A5`:
la intro japonesa original, huérfana desde la v83.

Prueba de que está muerta (norma 45):

```
virgen  $D11A:  LDA #$A5 / STA $BF / LDA #$55 / STA $C0   -> $55A5
v139    $D11A:  LDA #$5F / STA $BF / LDA #$5C / STA $C0   -> $5C5F
```

La repuntamos nosotros, y es el **único** sitio de la ROM que cargaba ese
puntero: no existe otro `LDA #$A5 / STA $BF`. El constructor lo verifica
con un `assert` antes de escribir.

> **[CORRECCIÓN a un susto propio]** A mitad de análisis creí que el
> puntero de la intro estaba en `0x05ABD` porque allí hay un `5f 5c`. Es
> ruido: ese par de bytes aparece por casualidad y es idéntico en la ROM
> virgen. El puntero real es inmediato en `$D11A`. Buscar un valor de dos
> bytes por toda la ROM no identifica un puntero — hay que encontrar la
> instrucción que lo carga.

```
zona de los 3 bloques   328 B
intro japonesa muerta   392 B
disponible              720 B   para 365 -> sobran 355
```

Todo dentro del banco `0x0F`, así que **no se toca ni una instrucción**:
los bloques se colocan reescribiendo la tabla de punteros de `0x1F2BD`,
seis bytes. La opción B sale sin cirugía.

### Reparto final

```
tabla[0] $5366 -> OCULTO 3  0x1F366  128 B
tabla[1] $53E6 -> OCULTO 2  0x1F3E6  117 B
tabla[2] $55A5 -> OCULTO 1  0x1F5A5  120 B   (en la antigua intro japonesa)
tabla[5] $52C9 -> TUTORIAL  0x1F2C9  157 B   (sin mover, con su $FD repuesto)
```

Quedan **358 B libres** en el banco para lo que venga.

### Verificación

Releídos los cuatro bloques **siguiendo la tabla de punteros**, como hace
el juego, y decodificados con el charset: las 24 líneas salen correctas,
las esperas de botón en su sitio y los cuatro terminan en `$FF`.

Intactos: intro en español, escena de los padres, menú de dificultad
(pegado detrás de la zona), botón II, fuente, tabla baja, bloques del mapa
y de aldea, cadenas de dinero, y los tres trozos de código implicados
(`$D113` cargador de la intro, `$D960` cargador de bloques, `$D1D5`
manejador de `$FD`).

### Entrega

```
test_ocultos_v140.pce   MD5    847be4be16657c0d0d9d4fe71149d06e
                        SHA-1  93ad2d16dff6ed9de807a78fb879af56e4445998
                        CRC32  22193e15
momotaro_ocultos_v140.ips
742 bytes modificados
```

---

## (112) v141: el sonido cuádruple y el bloque negro. Dos síntomas, un byte

David, probando la v140 contra la japonesa virgen:

> «en la japonesa escuchamos un sonido cuando obtenemos el dinero y el
> kibidango, pero en nuestra versión se escucha 4 veces [...] Además, ahora
> vemos un bloque negro rectangular encima del bocadillo.»

Y añade la intuición correcta: «seguramente lo llevemos arrastrando desde
que tradujimos los diálogos de los padres».

**Tenía razón. Es de la v125 y son el mismo fallo.**

### Qué es `$F0`

No está en el despachador del motor de texto (`$D174`), que sólo reconoce
`$00 $FF $FE $FD $FC`. Lo maneja **otro** despachador, `$A1DE`, que atiende
el mismo stream en la escena de los padres:

```
$A1DF  CMP #$FE / JMP $C27A
$A1E6  CMP #$FC / JMP $C261
$A1ED  CMP #$F0 / JMP $C2B7      <- aquí
       (si no)   JSR $AA38 = dibuja glifo
```

`$F0` dispara el efecto de **«obtienes un objeto»**: el sonido y la
animación de sprites.

> Dos despachadores distintos para el mismo formato de stream. Por eso el
> `$F0` no aparecía al analizar el motor de los niveles ocultos.

### El fallo

Estructura del japonés (`0x1F078`), página a página:

```
pag1  «モモタロウヤ! / オニタイジニ オカネガ / ヒツヨウジャロウ!»
pag2  モモタロウハ / ###両 テニイレタ!        F0 00 FC     <- efecto
pag3  «キビダンゴモ / モッテイクガヨイ!»
pag4  モモタロウハ キビダンゴヲ / ヒトツ テニイレタ! F0 00 FC  <- efecto
pag5  «モモタロウヤ! / ヨノタメ ヒトノタメ / ハゲムノジャ!»
```

**Dos** `$F0`, en las páginas 2 y 4: justo donde Momotaro recibe algo.

El nuestro (`0x1FEA9`, desde la v125) tiene **cuatro**, uno por página. Al
reconstruir el bloque se tomó `F0 FC` como si fuera el separador de página,
y se repitió en todas. No lo es: **`$FC` es el salto de página, `$F0` es un
efecto que casualmente aparecía antes de dos de ellos.**

Eso explica los dos síntomas a la vez:

- suena cuatro veces en vez de dos;
- el efecto se dispara donde no toca y sus sprites se solapan con el
  bocadillo. Medidos en el state de David: índices 43-46, patrones
  `$0352`/`$0356`, paletas **2 y 4** — distintas de la paleta 14 del
  bocadillo, de ahí que se vea como un bloque de color ajeno. Y salen
  **duplicados** (43=45, 44=46), coherente con dispararse de más.

### Un detalle más, cazado al verificar

El japonés escribe siempre `F0 00 FC`, con un salto de línea entre el
efecto y el fin de página. Nosotros escribíamos `F0 FC`. Reproducido el
patrón completo.

**Norma 67. Un separador de página no es lo mismo que un efecto que ocurre
al final de una página. Al reconstruir un bloque hay que copiar los
controles UNO A UNO del original, no deducir un patrón y repetirlo.**

### Sobre el `$FD` de la v140

David: «he probado la rom japonesa virgen y la v140. El comportamiento es
el mismo, pero no hay pausa de botón. Sí hay una leve pausa entre páginas,
pero es automático».

Medido en `$D20A`, `$FD` lee `$44` (el mando) y espera. Pero David observa
que avanza solo. **[HIPÓTESIS, no verificada]** hay una ruta alternativa
que también limpia `$3CE7` por tiempo, o el auto-avance vive en otro sitio
del bucle. No se ha medido y no se afirma. Lo que sí es cierto:

- el original lleva ese byte en los cuatro bloques;
- nuestra v89 lo perdió;
- reponerlo no cambia el comportamiento observado, así que es inocuo.

Queda pendiente, sin urgencia, entender por qué no bloquea.

### Verificación

```
                      japonés   v140   v141
bytes $F0                2        4      2
páginas con efecto     [2,4]   [1,2,3,4] [2,4]
secuencia F0 00 FC       2        0      2
```

Estructura de control releída byte a byte y contrastada con el original.
63 bytes cambiados respecto a la v140, todos dentro de `0x1FEE1..0x1FF3E`.

Intactos: intro, tutorial, los tres bloques ocultos, tabla de punteros,
menú de dificultad, botón II, fuente, y los dos trozos de código
implicados (`$A1DE` despachador, `$C2B7` manejador del efecto).

### Entrega

```
test_efecto_v141.pce   MD5    d6c9cbf7a54b602564e7a19a92c56230
                       SHA-1  f250a049bca534bc71f806f5e84bc5da41078ee2
                       CRC32  791f448e
momotaro_efecto_v141.ips
63 bytes modificados
```

---

## (113) v142: la línea base. Las mayúsculas iban 1 px por debajo

David, con una observación que le «lleva chirriando casi desde que
comenzamos»:

> «Las letras mayúsculas [...] están 1px más abajo que las minúsculas. Ya
> estaba así [de serie en la fuente de Hudson].»

**Medido, y es exacto.** Inventario de líneas base del charset español:

```
grupo                      filas    base
MAYÚSCULAS A-Z              1..7      7
dígitos 0-9                 1..7      7
Ñ                           0..7      7
? . ,                       1..7      7
minúsculas normales         2..6      6    <- referencia
minúsculas altas (b d f l)  0..6      6
descendentes (g p q y)      2..7     6 + cola en 7
acentuadas Á É Í Ó Ú Ü      0..6      6
```

Contrastado además contra su captura de «Aldea de la Partida»: la `A` pinta
hasta la fila 123 y `ldea` se para en la 122.

### Lo que no se veía: las colas no eran colas

Las descendentes bajan hasta la fila 7, **la misma línea donde se apoyan las
mayúsculas**. Por eso la `g` de «Ogros» no parecía tener cola: no sobresalía
de nada.

Subiendo las mayúsculas a la base 6, la fila 7 queda libre y las colas
sobresalen de verdad. El arreglo que pide David resuelve de paso un defecto
tipográfico que no había notado.

### La segunda opción de David no era viable

Él proponía, si subir no cabía, «bajar las minúsculas 1 px». No se puede:
las descendentes pasarían de 2..7 a 3..8, y la fila 8 no existe. Habría que
recortarles la cola. Su primera opción era la buena, y además cabía: las
mayúsculas tienen la fila 0 vacía por definición (empiezan en la 1).

### [ERROR MÍO] El falso desajuste de FÁCIL

A mitad del análisis anuncié que `Á É Í Ó Ú` estaban en base 6 y por tanto
`FÁCIL` ya salía descuadrado hoy. **Falso.** Esos glifos (194-198) son el
alfabeto FINO japonés; el menú no los usa, porque la v139 metió glifos
nuevos GRUESOS (254 y 255) que están en base 7 como el resto.

Rendericé `FÁCIL` desde la ROM y sale alineado. La alarma era mía por no
comprobar qué glifo emite realmente cada byte.

### [ERROR MÍO] El filtro se comió las colas

Primer intento: «subir todo lo que acabe en la fila 7». Eso incluye
`g p q y`, y les recortó la cola — justo lo contrario de lo que se busca.
Lo cazó el `assert` que exige que en la fila 7 queden **exactamente** las
colas.

### [ERROR MÍO] La Ñ perdió una fila

La `Ñ` ocupa las 8 filas (virgulilla en la 0, hueco en la 1, cuerpo en
2..7), así que no se puede desplazar: hay que rehacerla. La primera versión
copió las filas 0..6 tal cual y **le comió la fila superior del cuerpo**: se
veía una N más baja que las demás.

Corregido: lo que se sacrifica es la fila de separación, no la letra. El
cuerpo conserva sus 6 filas y la virgulilla queda pegada.

**Norma 68. Antes de mover una línea base hay que inventariar TODOS los
grupos que comparten renglón, no sólo el que canta.**

### Resultado

```
ANTES                             DESPUÉS
fila 6: 41 glifos                 fila 6: 81 glifos (todo el alfabeto)
fila 7: 44 glifos                 fila 7:  4 glifos (g p q y)
```

40 glifos desplazados y la `Ñ` rehecha. 236 bytes, todos dentro de la
fuente (`0x3D9E0..0x3DCC7`).

Intactos: fuente del MENÚ (es otra fuente, con su propia métrica y su
sombra calculada — norma 63), las tres tablas de glifos, y todos los textos.

### Entrega

```
test_base_v142.pce   MD5    e5a33dc6c4f9d39b08f6daf5a6ccae96
                     SHA-1  cfd39c5455d2ac27eeecb0ecd6ae526ef8e2e5cf
                     CRC32  8a6c0ebc
momotaro_base_v142.ips
236 bytes, 40 glifos + la Ñ
capturas/v142_lineabase.png
```

---

## (114) v143: los acentos gruesos que se quedaron abajo

David, probando la v142: «las letras con tilde salen algo descolgadas. En
la carga de partidas guardadas, donde vemos DIFÍCIL, FÁCIL, también».

Medido:

```
A  (byte $41, glifo 112)  filas 0..6    <- subida en la v142
Á  (byte $3A, glifo 254)  filas 0..7    <- NO subida
```

### La causa, y es mía

`build_v142` recorría el charset traduciendo con `CHAR_TO_CODE`, y
`CHAR_TO_CODE['Á']` vale `$C2` → glifo 194: la `Á` **fina** del alfabeto
japonés. Pero el menú no usa esa. La v139 dibujó acentos **gruesos** en los
glifos 254 y 255, alcanzables por `$3A` y `$63`, precisamente porque
`$C2`/`$C4` son katakana vivos que no se pueden repuntar.

Subí la `Á` que no se usa y dejé quieta la que sí. Y lo peor: **en la v142
llegué a detectar este desajuste, escribí que era una alarma falsa y pasé
de largo**, porque comprobé que los glifos gruesos estaban en base 7 igual
que A-Z... sin caer en que iba a mover A-Z y no a ellos.

**Norma 69. Para saber qué glifo dibuja un texto no vale la tabla de
caracteres del proyecto: hay que seguir el byte real por las tablas de la
ROM. Un mismo carácter puede tener dos glifos y sólo uno estar en uso.**

### [ERROR MÍO] El primer arreglo borró la tilde

Comprimí quitando la fila `..##....`, que es **la barra inclinada de la
tilde**. Quedaba un cuadradito de 2 px pegado al cuerpo. Visible en el
render, corregido antes de entregar.

El problema real es de espacio: tilde (2 filas) + cuerpo de la A (7 filas)
= 9, y la celda tiene 8. Hudson resolvió lo mismo en su `Ó` del menú
acortando el cuerpo a 6 filas. Se copia el criterio: tilde en 0..1, cuerpo
en 2..6. La `Á` queda con el cuerpo 2 px más corto que la `A`, pero con la
base alineada y la tilde legible.

### Verificación

Barrido completo de **todos** los glifos alcanzables desde las tres tablas
de la ROM (no desde `CHAR_TO_CODE`). Los que aún acaban en la fila 7:

```
167 176 177 185   colas de g p q y     -> correcto
158               el `!` de énfasis     -> dos trazos, se deja
159 160 218 222   kanji y katakana      -> no son nuestros
224..237 249 250  kana                  -> no son nuestros
```

Ninguna letra latina nuestra. 10 bytes modificados.

### Entrega

```
test_tildes_v143.pce   MD5 aee38fca9fc1a2bbeb1b56ec6b270e46
momotaro_tildes_v143.ips
```

---

## (115) El bloque negro: la hipótesis del SATB, DESCARTADA

### Lo que medí

State de David en la escena de los padres, SATB de 64 ranuras:

```
nivel oculto (se ve bien):  33 sprites activos
escena de los padres:       63 sprites activos
```

Las ranuras 43-62 tienen atributos imposibles (`FDDB`, `ABDD`, `5FB3`,
paletas 3, 9, 11, 15) que este juego no usa. Las 43-46 caen dentro de la
caja (`x 128..161`, `y 26..45`), justo donde David ve el rectángulo.

Lancé la hipótesis de que era basura sin limpiar destapada por nuestro
bocadillo, más grande que el japonés.

### [DESCARTADO] Y el segundo state lo tumba

Pedí a David un state de la **ROM japonesa virgen** para contrastar. El que
mandó **no es de la virgen**: es de nuestra v142. Se ve en el CG del texto,
donde la `M` de «¡Momotaro» ya tiene la línea base subida.

Pero da un dato mejor de lo que esperaba: **los dos states tienen el SATB
idéntico byte a byte**, incluidas las 20 ranuras con basura. Uno es de la
v140/v141 y el otro de la v142.

Es decir: esas ranuras están así **desde antes** y no dependen de nuestros
cambios recientes. La hipótesis de «lo hemos destapado al ensanchar» no se
sostiene con este dato: si fuera eso, el contenido variaría entre versiones.

### [DESCARTADO] «el bucle de limpieza de CG se pasa»

Primera hipótesis del día: el bucle de `0x1BEA4` (`LDY #$0A`, copia del
scroll que creamos en la v113) limpiaría 10 patrones y pisaría la caja.

Medido: la tabla `$FA1C` apunta a VRAM `$6B80`/`$6E80`/`$7180`, que son los
patrones `$035C`, `$0374` y `$038C` — las tres filas de texto. Diez
patrones desde `$038C` acaban en `$039F`, y la fila 3 usa exactamente
`$038C..$039F`. **Encaja justo, no desborda.** Descartada.

### [CORRECCIÓN a la entrada 112]

Dije que el bloque negro y el sonido cuádruple eran «el mismo fallo». El
sonido sí era el `$F0` de más y está resuelto. El bloque **no**: sigue con
dos `$F0`. Mi explicación de que sus sprites eran «el efecto disparándose
de más» fue una suposición que no comprobé.

### Estado

Pendiente. Hace falta un state de la ROM **japonesa virgen** en esa escena
para saber si esas ranuras 43-62 también están así en el original.

David dice que «la nuestra tampoco los tenía en versiones anteriores; es
algo reciente». Eso apunta a un cambio nuestro, pero los dos states que
tengo lo contradicen: el SATB es igual en la v141 y en la v142. Falta el
dato del original para cerrar el diagnóstico.

---

## (116) v144: el byte robado. El bloque negro, resuelto

### Cómo se cazó

Tres cosas de David, en este orden:

1. **La bisección**: v130, v132, v133 bien; v134 mal. Acotó el cambio.
2. **El breakpoint de escritura en `$270B`** (ranura 43 del SATB en RAM),
   que dio la pila de llamadas:

```
$C2DB  <-  $C031  <-  $C000
```

`$C2DB` es la rutina que dibuja el bocadillo de los padres.

### La causa, y es mía

`build_v122` creó la lista de sprites de ese bocadillo en `0x2FAE2`:

```
34 registros x 5 B + 1 terminador = 171 B
0x2FAE2 .. 0x2FB8C        <- el $FF final cae justo en 0x2FB8C
```

Y `build_v134` puso las tablas del rótulo de aldea en `A_DAT = 0x2FB8C`.

**El mismo byte.** Mis tablas pisaron el terminador.

El motor `$E3EB` no encuentra el `$FF`, sigue leyendo mis tablas de índices
y punteros como registros de 5 B y emite sprites arbitrarios: paletas 2, 3,
4, 9, 10, 11, 13 y 15, que en esa escena están **todas a negro**. De ahí el
rectángulo. Y como agotan las 64 ranuras del SATB, el texto se corta a la
primera letra — justo lo que David describió.

Medido:

```
lista $5AE2:   v128   39 registros    v134   76    v143  105
SATB:          v128   8+40+0  = 48    v142   8+36+19 = 63 (tope 64)
```

### Por qué no lo cazó ningún assert

`build_v134` comprobaba que desde `A_DAT` **hacia adelante** todo fuera
`$FF`. Y lo era: el terminador es un solo `$FF` y el hueco detrás también.
La comprobación no distingue «hueco libre» de «terminador de alguien».

**Norma 72. Un `$FF` puede ser el TERMINADOR de un bloque anterior, no
espacio libre. Antes de ocupar un hueco hay que comprobar dónde ACABA lo
que hay justo antes, no solo que el hueco esté a `$FF`.**

Es la norma 35 al revés: allí el peligro era leer de más; aquí, escribir
encima.

### Callejones sin salida, para que no se repitan

- **[DESCARTADO] «el bocadillo gasta demasiados sprites».** Medido: el de
  la v142 gasta 36, **cuatro menos** que el de la v128, que iba bien.
- **[DESCARTADO] «se dibuja el rótulo de aldea sobre la escena».** Sólo hay
  1 sprite con sus patrones, no 30. La cuenta 63−8−30 fue numerología.
- **[DESCARTADO] «el bucle de limpieza de CG desborda».** La tabla `$FA1C`
  apunta a `$6B80`/`$6E80`/`$7180` y los 10 patrones acaban justo.
- **[DESASTRE EVITADO]** iba a redirigir tres saltos (`$C149`, `$C187` y uno
  del banco 0x01) creyendo que entraban al rótulo. **Ninguno de esos bancos
  mapea el 0x0C**: su `$DE4B` es otra rutina. Lo paró el assert.

**Norma 71. Al buscar quién salta a una dirección lógica hay que filtrar por
los bancos que la tengan mapeada. En el PC Engine una dirección lógica no
identifica código.**

Y el breakpoint en `$DE4B` que no saltó confirmó que ese cuerpo está muerto:
un resultado negativo que ahorró seguir por ahí.

### El arreglo

Mover el bloque de aldea de `0x2FB8C` a `0x2FB8E`, restaurar el terminador
y repuntar:

- **6** direcciones inmediatas en `$DF58` (las tablas de punteros se leen
  dos veces cada una, byte bajo y alto — el assert lo cazó: esperaba 4);
- **16** punteros internos de lista.

### Verificación

```
lista del bocadillo:  34 registros y terminador OK, idénticos a la v128
bocadillo simulado:   34 sprites, 5 filas limpias, 0 con paleta rara
escena estimada:      8 + 34 = 42 sprites de 64  (antes 63)
los 10 rótulos:       caja y texto con terminador, dentro del bloque
```

Intactos: bloque del mapa, textos de padres, intro, tutorial, los tres
niveles ocultos, fuente, las tres tablas de glifos, fuente del menú, botón
II, motor `$E3EB` y la rutina `$C2DB`.

### Entrega

```
test_terminador_v144.pce   MD5    4887028c2f7d33421af89b833075a173
                           SHA-1  ea3596594e0ce0f3db814ff0854e90e6d1913c0c
                           CRC32  ac83b7b0
momotaro_terminador_v144.ips
1005 bytes modificados
```

---

## (117) Punto de partida para el menú de SELECT y el de pausa (RUN)

Anotado para la próxima sesión, sin tocar nada todavía.

Lecturas del mando (`$43` = pulsado ahora, `$44` = flanco) que comprueban
los bits de SELECT (`$04`) y RUN (`$08`):

```
SELECT   LDA $44 / BIT #$04    0x1126C   0x1B2E5   0x43B99
SELECT   LDA $43 / BIT #$04    0x19376
RUN      LDA $44 / BIT #$08    0x02949   0x1858A   0x185A9   0x1A806   0x429C9
```

Hipótesis de David, que encaja con lo que se ve en pantalla: **esas
pantallas muestran palabras japonesas correctamente, así que son gráficos
de fondo (BAT + CG), no texto por el motor de sprites.**

Si se confirma, el flujo de trabajo sería el mismo que en el Nekketsu
Soccer MD: extraer la imagen completa del fondo, que David la edite, y
reinsertarla. Él lo pidió expresamente.

Primer paso cuando se retome: capturar un state con cada menú abierto y
volcar BAT + CG para ver si el texto está en tiles de fondo o en sprites.

---

## [118] El menú SELECT: era FONDO, no sprites

### Rectificación de la entrada anterior

Dije que el state de David «no tenía el menú abierto». **Falso.** Miré el
SATB, conté 18 sprites (Momotaro y los tres animales) y deduje que faltaba
el menú. El fallo: supuse que SELECT sería de sprites **porque RUN lo es**.
Eso es justo lo que prohíbe la norma 15. David insistió — *«el state del
select que te he enviado antes sí tiene abierto el menú»* — y tenía razón.

**Norma 73. Antes de afirmar que un state "no tiene" algo, renderizar el
FONDO, no solo los sprites.**

### Lo medido

`tools/render_bg.py` (nuevo) reproduce la captura de David píxel a píxel:
BAT en `$0000` (no `$0800`), 64x32, BXR=BYR=0.

Dos clases de celda:
  - `$100..$15F` gráficos: marco, recuadros y los rótulos japoneses.
  - `$200..$2FF` fuente, con `patrón = $200 + código de carácter`.

`$D35E` (ROM 0x1B35E) sube la fuente al CG en tres tandas: códigos $30..$5F
a patrón $220 (fuente MENÚ), y $A0..$DF dos veces, a $2A0 y $260, usando las
tablas altas `$9CF3` y `$9CB3` — **las mismas de los diálogos**. Contrastado:
63/64 tiles del CG coinciden con la fuente de la v144 y solo 1/64 con la
japonesa. Es decir, **las tildes, la Ñ y la línea base ya arregladas
funcionan dentro del menú SELECT sin tocar nada más**.

Motor de texto propio, `$D41C`, distinto del `$D174` de los diálogos.
Controles: `$01`/`$02` fuente, `$5C` alterna, `$00` fin, `$DE`/`$DF`
dakuten (retroceden y escriben una fila más arriba, `$16 - $40`).

Cadenas de armas en `0x43CB6` (7) y de armaduras en `0x43CF7` (4), en claro.

### El CG comprimido, resuelto

Los 96 tiles del menú están comprimidos en `0x7F8F2..0x7FE85` (1427 B).
Descompresor `$C1CC`/`$C206` transcrito en `tools/descomp_cg.py`:
mapa de 8 bits por plano; bit 1 = literal, **bit 0 = repetir el último
literal** (no «escribir cero», que es lo que habría supuesto sin medir).

Validación: **96/96 tiles idénticos** al CG del state, y `comprime()` da
round-trip byte a byte exacto sobre los 1427 bytes. Quedan 379 bytes libres
hasta `0x80000`.

Esto reabre el intento fallido de la v83 (`descomp_8667F.py`, descartado por
no validarse). Aquel descompresor era de otra rutina; este está medido.

Detalle a respetar: los rótulos miden **12 px de alto**, cabalgando dos filas
de celdas de 8. No están alineados a la rejilla.

Documentado en `docs/menu_SELECT.md`. Nada parcheado todavía.

## [119] Restos de 2 px sobre los rótulos del menú SELECT

David, viendo la simulación: *«hay pequeños artefactos sobre VIDA, OBJETOS,
ARTES y ARMADURA, que curiosamente son las palabras que encabezan los
bloques»*. Y preguntó si era cosa de la imagen o saldría en el juego.

**Saldría en el juego.** No era un defecto del simulador.

Causa medida: los rótulos japoneses miden 12 px y no están alineados a la
rejilla de 8, así que ocupan TRES filas de celdas. La fila de arriba es la
misma celda que lleva el borde del recuadro (filas 0-5 del tile) y la punta
del kanji (filas 6-7). Yo limpiaba solo las dos filas inferiores.

Su detalle *«son las palabras que encabezan los bloques»* fue la pista: solo
los rótulos pegados a un borde superior tienen ese solapamiento.

Arreglo sin dibujar nada, porque los tiles lisos ya existen en el CG:
fila 2 -> $10B, filas 9 y 14 -> $141. 44 celdas, 17 patrones implicados.
Verificado: 0 píxeles de tinta en la banda superior tras el cambio.

**Norma 74. Un rótulo que no está alineado a la rejilla contamina la fila de
arriba: al borrarlo hay que contar TRES filas, no dos.**

Van cuatro veces que una observación visual de David detecta algo que mis
mediciones habían dado por bueno.

## [120] Acentos en el menú: la fuente gruesa no tiene huecos

Al proponer dibujar una É gruesa en el código $3C dije que estaba «libre
porque está vacío». **Error.** $3C es el destino del remapeo del ESPACIO
($20 -> $3C, tabla 0x42B4C). Está vacío porque ES el espacio.

Inventario real de la fuente MENÚ ($30-$5F, ROM 0x4000):
- $3A $3B $3D  comillas y apóstrofos (en uso)
- $3C          ESPACIO (remapeado desde $20)
- $3E $3F $40  símbolos (en uso)
- $5B $5D $5E $5F  destinos de remapeo: $A2->$5B, $A3->$5D, $2D/$B0->$5F
- $5C          está en la LISTA DE CONTROL $AAA3, no es imprimible

**No queda ni un hueco libre en la fuente gruesa.**

Dato útil: $5B **ya lo modificamos** en una versión anterior — era un
corchete japonés y ahora es una Ó gruesa con tilde. El método está probado,
lo que falta es sitio.

Las mayúsculas acentuadas $C2-$C8 caen en la RUTA ALTA y por tanto usan la
fuente DIÁLOGO (fina, 8 B). Por eso la É de TÉCNICA sale delgada entre
mayúsculas en negrita: no es un fallo, es que son dos fuentes distintas.

**Norma 75. Un glifo vacío no es un glifo libre: puede ser el destino de un
remapeo o el espacio.**

Consecuencia para el menú SELECT: escribir acentos requiere robar un código
en uso o aceptar la mezcla fina/gruesa. Pendiente de decidir con David.

## [121] Dos fuentes en el menú SELECT: rótulo vs contenido

David, viendo mi simulación: *«estás usando exactamente la misma fuente para
los nombres de las secciones y sus contenidos. Así parece que objetos,
onigiri, dango... están al mismo nivel»*. Y propuso que el contenido fuera
de cuerpo menor, con minúsculas.

**Tenía razón, y el original ya lo hace así.** Medido sobre el state:

```
CIFRAS y ROTULOS   patrones $230-$25F   fuente MENÚ (gruesa, 2 planos)
CONTENIDO          patrones $2A0-$2DF   fuente DIÁLOGO (fina, 1 plano)
```

Las tres filas del panel de objetos del state japonés usan $2C6, $2B6...
todas en el rango $2A0-$2DF. Yo lo había escrito todo en gruesa: error de
criterio, no de medición. Norma 63 mal aplicada — la fuente se decide por
carácter, y yo no había mirado qué fuente usaba el CONTENIDO del original.

### Lo que hay disponible

`$D3B3` sube al CG los códigos $A0-$DF DOS veces, con las tablas $9CF3
(fuente 0 -> CG $2A0) y $9CB3 (fuente 1 -> CG $260). **Las dos son
minúsculas finas**: la fuente 1 es un duplicado casi idéntico.

Minúsculas y acentos finos: disponibles de serie ($2A1-$2BF, con á é í ó ú ñ).
'b','c','p' viven en $5B/$5D/$5E y en el CG del menú caen en $25B/$25D/$25E,
que también son minúsculas finas. **El alfabeto en minúscula está completo.**

### Mayúsculas finas: existen pero no se suben

La fuente DIÁLOGO tiene A-Z finas en los glifos $70-$89 (verificado con el
volcado completo, `capturas/fuente_dialogo_completa.png`). No están en el CG
del menú porque la ruta alta solo sube $A0-$DF.

Se pueden inyectar sobrescribiendo el CG $260-$279 (la fuente 1, que el menú
carga pero no usa en ninguna cadena medida). Simulado en
`capturas/select_A_may_finas.png`.

**Error cometido y corregido en el acto:** al inyectarlas puse plano0=$00 y
salieron en negativo (letra clara sobre caja negra). Las minúsculas del CG
llevan **plano0=$FF** (fondo blanco) y el cuerpo en plano1. Corregido.

**Norma 76. Al inyectar un glifo en un CG ajeno, copiar la estructura de
planos de un glifo VECINO que ya funcione, no solo el mapa de bits.**

## [122] v145: los tres arreglos de fuente + la tilde sin sombra

David: *«La T 1 px a la izquierda. Tilde en la E de TÉCNICA. Fuente fina
para la letra capitular»* y, de un usuario del hilo, *«la tilde [de BOTÓN]
no tiene sombra»*.

### 1. La T ($54)
Medido el x inicial del cuerpo de las 26 mayúsculas: todas en 0 salvo
I=2, L=1, Y=1 y T=1. En la I, la L y la Y el sangrado es de diseño; en la T
no. Movida a x=0 y sombra regenerada.

### 2. É gruesa en $40
Buscado un hueco de verdad, tras el error de la entrada [120] con $3C.
$40 está en la lista de control $AAA3 (nunca llega al dibujado), aparece
**0 veces** en tutorial+ocultos, intro y padres, y **0 celdas** del state
del menú lo usan. Glifo muerto: se puede escribir.

### 3. La tilde sin sombra
Confirmado en $5B (nuestra Ó): el cuerpo de la tilde está en las filas 0-1
y el plano de sombra vale 0 ahí. Regenerada con el algoritmo de
tools/fuente_menu.py: +3 px.

**Error cometido y corregido:** la primera versión detectaba los glifos a
reparar automáticamente («tiene cuerpo en las filas 0-1 y le falta sombra»)
y tocó 7 glifos, entre ellos la A, el 3 y el 5 — donde el grafista japonés
recortó la sombra A MANO, cosa ya documentada en fuente_menu.py («34 de 36
exactos»). Los habría estropeado. Sustituido por una lista EXPLÍCITA.

Norma 42 otra vez: «afecta a todo el juego» hay que CONTARLO. Aquí el
verificador me lo contó: 7 glifos cuando esperaba 1.

v145: MD5 27d45972652f7c7789364f67488d307d, 31 bytes, todos en 0x4100-0x42B9.

## [123] La BAT no alcanza a los patrones de fuente

Al ir a escribir los rótulos traducidos comprobé el byte ALTO de las celdas
estáticas de la BAT del menú: **es $01 en todas**. La BAT comprimida de
0x1E7EA solo guarda el byte BAJO, luego solo expresa patrones $100-$1FF.

Los patrones de fuente son $2xx. **Escribir los rótulos tocando solo la BAT
es imposible**, al contrario de lo que di por bueno en menu_SELECT.md §9.
Rectificado allí. Las salidas son redibujar el CG (como en mapa y aldeas) o
añadir código que pinte esas celdas en ejecución, como ya hace $D5EE con
las cifras.

**Norma 77. La BAT comprimida solo expresa el byte BAJO del patrón:
comprobar el rango alcanzable ANTES de diseñar una solución basada en ella.**

## [124] v146: los rótulos del menú SELECT, en castellano

David entregó el gráfico (`IMG_4561.PNG`): 256x176, **solo los 7 colores de
la paleta, sin antialias**. Verificado antes de tocar nada.

Observaciones suyas, ambas correctas:
1. *«dejaste los números 8, 1 y 0, además del kanji de ryo»* — cierto: son
   texto dinámico que el juego repinta ($D5EE col 10 fila 3, $D605 col 10
   fila 5, $D5D1 cols 6-11 fila 7). Borrados antes de convertir.
2. *«los recuadros de ARMA y ARMADURA estaban mal»* — cierto, mi lienzo
   limpio se comió parte del listón. Él los reconstruyó: su ARMADURA es
   **idéntica byte a byte** al original japonés, y en ARMA solo difieren 21
   píxeles de veteado de madera, en una franja que no se toca.

### El obstáculo, medido

Las letras latinas no caen en la rejilla de 8 px, así que cada palabra
cruza varias celdas y casi ninguna se repite:

```
celdas de rótulo        145
tiles NUEVOS necesarios  91
patrones libres en $100-$15F  42     -> faltaban 49
```

Ampliar el CG a 187 tiles da 2406 B comprimidos, y en 0x7F8F2 solo quedaban
1806: **faltaban 600 B**. Y la BAT pasaba de 510 a 541 B, con datos vivos
justo detrás (0x1E9E8 en adelante), así que tampoco podía crecer.

### La solución

Hueco de 3111 B de $FF en **0xF3D9** (banco $07). Comprobado que el banco
está MUERTO: no hay un solo `LDA #$07 / TAM` en toda la ROM.

Se mueven **los dos** bloques allí, seguidos:

```
CG   0x0F3D9  2406 B  ->  lógico $53D9
BAT  0x0FD3F   541 B  ->  lógico $5D3F
total 2947 B de 3111
```

Seis bytes de código, todos verificados con assert del valor previo:

```
$D301 LDA #$0F -> #$07     banco de la BAT
$D308 LDA #$EA -> #$3F     puntero BAT lo
$D30C LDA #$47 -> #$5D     puntero BAT hi
$D32D LDA #$3F -> #$07     banco del CG
$D33C LDA #$F2 -> #$D9     puntero CG lo
$D340 LDA #$58 -> #$53     puntero CG hi
```

El cargador ya pide 256 tiles ($D34F: CLA / LDX #$01), así que los 187
entran sin tocarlo.

### Errores míos en el camino

1. Supuse que la BAT se cargaba desde `$7C00` (el puntero de `$D347`). Falso:
   ese es otro dato y `$E61E` monta un TIA a RAM. El lector real de la BAT es
   `$D308`, que carga `$47EA` = banco $0F + 0x7EA = **0x1E7EA**. Lo encontré
   buscando la pareja `LDA #$EA / STA $14 / LDA #$47 / STA $15`.
2. Mi primer verificador comparaba la simulación con el arte de David
   forzando el byte alto a $01, y daba 2129 píxeles de diferencia. El state
   tiene celdas con alto **$02** (las de texto). El fallo era del verificador,
   no de la conversión.

### Verificación

CG y BAT releídos de la ROM ya escrita y comparados con lo que se quería
escribir: idénticos. Los **siete rótulos reproducen el dibujo de David
píxel a píxel** (0 diferencias en las siete zonas).

v146: MD5 f91896bfab78dc008abd529c8c0af618

**Norma 78. Antes de dar por buena la dirección de un dato, buscar la
pareja LDA/STA que carga su puntero; un puntero cercano en el código puede
ser de otra cosa.**

## [125] v146 primer intento: pantalla destrozada. DOS errores encadenados

David probó la v146 y la pantalla salió hecha trizas, con trozos de rótulo
repetidos por el marco. Dos fallos míos, ambos por no medir.

### Error 1: corté el bloque de CG donde no acababa

Di por hecho que el bloque de `0x7F8F2` tenía **96 tiles y 1427 B**, y que
detrás quedaban 379 B libres. **Falso.** Tiene **110 tiles ($100-$16D) y
1803 B**, y llega hasta `0x7FFFD`: detrás quedan **3 bytes**, no 379.

Los 14 tiles que ignoraba son los **listones de madera del marco**. Al
escribir mis 91 tiles nuevos a partir de `$160` los pisé, y el marco se
llenó de pedazos de las letras de David. Eso es exactamente lo que vio.

Lo peor: varios pasos antes yo mismo había impreso «patrones $160-$1FF
usados por la BAT: 0x160..0x168» y **no leí mi propia salida**. Norma 34,
incumplida.

### Error 2: cambié un banco que tenía DOS punteros colgando

Para hacer sitio moví la BAT al banco `$3F`. Pero `$D301` mapea el banco
`$0F` y a continuación carga **dos** punteros de ese mismo banco:

```
$D308  $14/$15 = $47EA   -> la BAT       (ROM 0x1E7EA)
$D310  $18/$19 = $4B28   -> OTRO dato    (ROM 0x1EB28)
```

Al cambiar el banco, el segundo puntero pasó a leer basura de `0x7EB28`.
Ese es el destrozo de fondo de la captura.

**Norma 79. Antes de cambiar el banco que mapea una rutina, inventariar
TODOS los punteros que se cargan con ese banco activo, no solo el que
interesa.**

### Estado tras corregir el error 1

Con los 110 tiles respetados y los nuevos a partir de `$16E`, el CG cabe en
el hueco del banco `$07` (2642 B de 3111) y **el marco se reproduce intacto**
(0 celdas distintas). Pero la BAT sigue sin caber:

```
BAT actual   510 B en 0x1E7EA, con datos vivos justo detras (0x1E9E8)
BAT nueva    541 B   -> faltan 31
```

Medido que **no hay forma de reducirla**:
- mi compresor RLE ya es óptimo (reproduce los 510 B originales exactos);
- reciclar los 51 patrones que liberan los kanji: sigue en 541;
- alinear los rótulos a la rejilla: 86 tiles en vez de 91, pero 541;
- pegar los rótulos al borde de celda: igual, 541.

El crecimiento se reparte por las filas 2-11 y 15 (+2 a +8 cada una): al
sustituir carreras largas de `$1B` por bytes distintos, el RLE pierde.

Y no se puede mover: el banco `$0F` solo tiene 400 B de huecos sueltos, el
mayor de 273.

## [126] Por que las letras no se "reutilizan": la FASE de la rejilla

David preguntó: *«¿No se pueden reutilizar las letras de los rótulos como si
fueran instancias? ARMA y ARMADURA comparten las cuatro primeras letras.»*

**La técnica es correcta y el conversor ya la aplica** (dedupla cualquier
tile idéntico). Lo que fallaba es que los tiles NO salían idénticos.

Medido: el dibujo de la «A» es byte a byte el mismo en ARMA y en ARMADURA.
Pero:

```
ARMA     empieza en y= 79  ->  79 mod 8 = 7
ARMADURA empieza en y=118  -> 118 mod 8 = 6
```

Fase distinta dentro de la rejilla de 8 px: la rejilla parte la misma letra
por sitios diferentes y produce tiles distintos.

Alineando los siete rótulos a una fase común:

```
tal cual        91 tiles   BAT 541 B
alineado        68-75      BAT 531-534 B
145 celdas -> 75 tiles unicos  (la deduplicacion SI funciona)
```

### El tope real, cuantificado

```
suelo (area de rotulos toda en relleno)   462 B
limite (hueco disponible)                  510 B
presupuesto para los siete rotulos          48 B
```

Coste medido por rótulo, ya alineados: TECNICA +15, ARMADURA +7, VIDA +6,
ARMA +5, OBJETOS +5, ORO +4, ARTES +3. Total +45... pero el reparto real da
532 porque los costes no son independientes.

### La causa de fondo: las letras miden 10 px

```
VIDA 14  TECNICA 14  ORO 10  ARMA 10  ARMADURA 10  OBJETOS 10  ARTES 10
```

Con 10 px de alto **toda palabra ocupa dos filas de celdas**, se ponga donde
se ponga. Y aun suponiendo letras de 8 px que quepan en una sola fila, la
BAT daria **521 B**: sigue por encima de 510.

**Conclusión: el problema no es el dibujo de David, es la BAT.** No hay
solución por el lado del arte.

### Descartado: mover la BAT

- Detrás de `0x1E9E8` hay **otra BAT sin comprimir** (704 B, filas de 32
  bytes con los patrones del marco: `68 01 02 03`, `04 05 06 07`). Es otra
  pantalla. Dato vivo, no se puede pisar.
- El banco `$0F` solo tiene 400 B en huecos sueltos, el mayor de 273.
- Cambiar el banco rompe el segundo puntero `$4B28` (entrada [125]).

## [127] RECTIFICACION: las letras de David SI miden 10 px, como el japones

David: *«Yo tomé de referencia las letras en japonés del bloque de VIDA,
TÉCNICA y ORO, y te aseguro que ahí tienen exactamente la misma altura.»*

**Tenía razón y yo me equivoqué.** En la entrada [126] afirmé que VIDA y
TECNICA medían 14 px. Falso: miden **10**, igual que los kanji. El error fue
de medición, no suyo: mi ventana de análisis para VIDA llegaba hasta y=36 y
capturaba **la tilde de TECNICA**, que está justo debajo (y=34..36).

Medidas correctas, con ventanas ajustadas:

```
              DAVID          JAPONES
VIDA       y=22..31  10 px   y=22..31  10 px   <- identico
TECNICA    y=34..47  14 px   y=38..47  10 px   <- +4 por la TILDE
ORO        y=54..63  10 px   y=54..63  10 px   <- identico
ARMA       y=79..88  10 px   y=79..91  13 px   <- David MENOR
ARMADURA   y=118..127 10 px  y=118..131 14 px  <- David MENOR
OBJETOS    y=22..31  10 px   y=23..35  13 px   <- David MENOR
ARTES      y=23..32  10 px   y=23..31   9 px
```

Su arte respeta las alturas del original, y en cuatro casos es MAS compacto.

**Norma 80. Al medir la altura de un elemento, acotar la ventana al elemento
y comprobar que no invade al vecino: un rótulo de abajo puede colarse en la
medición del de arriba.**

### Lo que de verdad desborda: el ANCHO

```
celdas ocupadas por los rotulos    original 66   David 99
```

33 celdas más, porque las palabras castellanas son más anchas que los kanji.

### El dato que cierra el asunto

Simulando la BAT con distinto numero de celdas ocupadas:

```
 66 celdas -> 527 B     <- ni con las MISMAS celdas que el japones cabria
 75 celdas -> 535 B
 99 celdas -> 541 B
 limite       510 B
```

**Ni reproduciendo exactamente la ocupación del original entra.** El original
cabe en 510 porque sus 66 celdas usan patrones *consecutivos y repetidos*
($08 $09 $0A $0B $0C $0B $0B...), que es justo lo que el RLE comprime bien.
Cualquier texto nuevo rompe esas carreras.

Conclusión firme: **no hay solución por el lado del arte**. Ni acortando los
rótulos, ni bajándolos a 8 px, ni alineándolos. Hay que escribir las celdas
por código, sin tocar la BAT.

## [128] v147: los rotulos, escritos POR CODIGO. FUNCIONA

Descartadas todas las vias por BAT (entradas [125]-[127]), la solucion es
la que ya usa el propio juego para las cifras: escribir las celdas en
tiempo de ejecucion.

### Lo que se hace

1. **CG ampliado a 201 tiles** (110 originales + 91 nuevos) y movido al
   hueco muerto del banco `$07` (`0xF3D9`, 3111 B). 2642 B usados.
   Se cambia SOLO el banco del CG (`$D32D`). El de la BAT (`$D301`) **no se
   toca**: alli cuelga el segundo puntero `$4B28` que rompio la v146.
2. **La BAT queda INTACTA.** Cero riesgo por ese lado.
3. **Rutina nueva en `0x1BEF1`** (logico `$DEF1`, banco `$0D`, 271 B de `$FF`).
   Verificado que el hueco esta libre: las dos "referencias" que aparecian
   (`0x1A8C4`, `0x1BA04`) son bytes de tabla que el desensamblador lee como
   JSR, no codigo (norma 71).

### La rutina

Gancho: `$D407` empezaba con `JSR $D4C3`; ahora es `JSR $DEF1`, y la rutina
hace `JSR $D4C3` al entrar. Asi no se pisa nada: detras de `$D419` empieza
`$D41C`, el motor de texto, y no habia hueco.

Tabla de **rachas**: `[cx][cy][pat_lo][pat_hi][n]`, terminador `$FF`.
Una racha son n celdas seguidas en horizontal con patrones consecutivos.
Como los tiles nuevos se numeran en orden de aparicion, casi cada palabra
es una sola racha:

```
102 celdas -> 31 rachas x 5 B = 156 B
(4 B por celda habrian sido 409 B: no cabian)
```

74 B de codigo + 156 de tabla = 236 B de los 271 disponibles.

Zero page usada: `$10 $11 $12 $13 $1A`. Verificado por opcode de escritura
que ninguna rutina de la cadena del menu (`$D407 $D4C3 $D55A $D58F $D5EE
$D605 $D5D1 $D41C`) escribe en esas direcciones.

### Verificacion

- El codigo se ha **desensamblado desde la ROM ya escrita** (norma 39):
  saltos correctos, tabla en `$DF41`, `RTS` en `$DF3A`.
- Simulada la tabla celda a celda: 102 celdas pintadas.
- Comparado con el arte de David: **1 celda distinta de 704**, la (11,2),
  que son 7 px de veteado de madera en un tile que no se toca.
- **Marco intacto.**

v147: MD5 6c81ef8e719105fec39094d2191ce250

## [129] v148: contenidos del menu SELECT, con capitular FINA

David pidio que el contenido fuera de cuerpo menor que los rotulos y con
capitular fina, no gruesa.

### La solucion: reutilizar la FUENTE 1

El motor tiene dos fuentes seleccionables por los controles $01 y $02
(`$D4A3` -> `$3BA6`). Medido: **la fuente 1 (tabla $9CB3, CG $260) es un
duplicado byte a byte de la fuente 0** — 0 tiles distintos de 64. Los $02
que hay dentro de los nombres japoneses no cambian nada visible.

Se reapuntan **solo 14 entradas** de esa tabla a los glifos $70-$89 de la
fuente DIALOGO, que son las A-Z finas. Resultado:

```
control $01 + letra  ->  minuscula fina   (fuente 0)
control $02 + letra  ->  MAYUSCULA fina   (fuente 1)
```

### Tres errores cometidos y corregidos

1. **Mapee la 'A' al codigo $A0.** Pero $A0 es el **ESPACIO** (las cadenas
   japonesas lo usan de separador, p.ej. la de dinero en 0x48D23). La 'A'
   desaparecia. 
2. **Escribi armas y armaduras como un bloque contiguo de 97 B.** No lo es:
   la **tabla de punteros de armaduras vive EN MEDIO** (0x43CEF..0x43CF7).
   Son dos huecos de 57 y 32 B. La ultima arma y la primera armadura salian
   corruptas.
3. **Iba a redefinir las 26 entradas de la tabla.** El texto japones TAMBIEN
   usa la fuente 1: hay tres $02 en el menu de dificultad, y tras ellos
   aparecen los codigos $B9, $B0 y $B6. Redefinirlos habria cambiado kana
   por letras latinas en el modo GeroGero.
   Solucion: contar que solo hacen falta **14 mayusculas** (ABCDFGHIKOPRSV)
   y asignarlas a codigos **libres** medidos. Verificado: 0 choques.

**Norma 81. Antes de redefinir una tabla de fuente, recorrer TODOS los
bloques de texto contando que codigos usan ya esa fuente.**

### Ajustes de espacio (huecos medidos, no supuestos)

Entre las cadenas de objetos hay **codigo ejecutable** (JSR/JMP/RTS), no
espacio libre, asi que cada nombre debe caber en su hueco exacto:

```
Bokuto  -> Boku    (57 B exactos en armas)
Satsuki -> Iris    (satsuki = lirio japones de mayo; 33 B en 32)
Raquetas-> Skis    (hueco de 7 B)
Vuelo   -> Alas    (hueco de 7 B)
Oleada  -> Olas    (hueco de 7 B)
```

### Resultado

```
ARMAS     Boku Katana Byakko Hiryu Asura Fenix Valor
ARMADURAS Bambu Roja Iris Valor
OBJETOS   Onigiri Remedio Banquete Dango Bonzo Pedos
          P. solar P. hielo Skis Capa Aletas
ARTES     Alas Salto Rodar Giro Bomba Olas Azar
```

Todas releidas desde la ROM ya escrita. v148: MD5 96a1f0be33aafd7b4b8ef2beb61c24e6

## [130] v148 corregida: los nombres de David, INTACTOS

David, con razon: *«me dijiste la cantidad de caracteres que debian tener
[...] pero ahora pones BOKU, que significa "Yo" en japones coloquial. No,
tio, tenemos que luchar por mantener los nombres que habiamos definido.»*

**El error era mio de raiz**: le di los anchos en CARACTERES DE PANTALLA
(10/10/8/6) cuando el limite real es en BYTES DE ROM. Cada nombre gasta
ademas 3 B de control ($02 capitular + $01 volver + $00 final). Diseno
contra una restriccion que yo habia enunciado mal.

### Lo que permitio recuperarlos

1. **Mover la tabla de punteros de armaduras.** Estaba incrustada en medio
   del bloque de cadenas (0x43CEF..0x43CF7) y lo partia en dos huecos de 57
   y 32 B. Solo la lee UN sitio: `$D4F6 LDA $BCEF,X` (verificado buscando
   `EF BC` en toda la ROM). Movida a 0x43FEF, el bloque queda entero:
   **97 B para 92**. Recuperados BOKUTO y SATSUKI.

2. **Asignacion global de huecos.** Cada nombre lleva su propio puntero, asi
   que no tiene por que quedarse donde estaba. Se ordenan huecos y textos
   por tamano y se emparejan best-fit, devolviendo los sobrantes a la lista.
   Asi VUELO (8 B) se lleva el hueco de 11 que tenia SALTO, y OLEADA (9 B)
   el de 9. Recuperados VUELO, OLEADA y RAQUETAS.

3. **Dos reservas** de relleno real: el sobrante del bloque de armas y los
   9 B de $FF al final del banco. Verificado que no son tablas con ceros
   significativos: la zona 0x42000-0x420D9, que parecia libre, se indexa
   desde 41 sitios distintos (`LDA $A0xx,X`). No se toca.

### Unico cambio sobre lo que pidio David

`P. hielo` -> `Frio`. Hay TRES nombres de 8 B y solo DOS huecos que los
admitan; la reserva libre son 6 B. Acortando uno entran todos.
Los dos guijarros quedan `P. solar` y `Frio`.

### Verificacion

```
ARMAS     Bokuto Katana Byakko Hiryu Asura Fenix Valor
ARMADURAS Bambu Roja Satsuki Valor
OBJETOS   Onigiri Remedio Banquete Dango Bonzo Pedos
          P. solar Frio Raquetas Capa Aletas
ARTES     Vuelo Salto Rodar Giro Bomba Oleada Azar
```

Releidas de la ROM ya escrita siguiendo los punteros. **0 solapes** entre
cadenas, **0 choques** de fuente con el japones.

v148: MD5 badebcb527eda758992a0add8042accd

**Norma 82. Al dar un limite de espacio al director, expresarlo en la unidad
REAL (bytes de ROM), no en caracteres de pantalla: los bytes de control
tambien ocupan.**

## [131] v148 final: Fuego/Hielo, tildes, y la deduplicacion de 'Valor'

David pregunto por los originales de los dos guijarros:

```
objeto 7  ニチリンのつぶて  nichirin no tsubute  = guijarro del disco solar
objeto 8  ヒョウガのつぶて  hyouga no tsubute    = guijarro de glaciar
```

Son un PAR SIMETRICO: la misma arma (つぶて, guijarro arrojadizo) en dos
elementos. Mi 'P. solar' / 'Frio' rompia ese paralelismo. David: *«no me
gusta poner P. porque es como no poner nada, la gente nunca sabra lo que
es»*. Tiene razon. Quedan **FUEGO** y **HIELO**.

Tambien pidio las tildes de Fenix y Bambu. **Son gratis**: en la ruta alta
'é' ($BC) y 'ú' ($BF) ocupan 1 byte igual que las vocales simples.

### El truco que hizo que cupiera todo

Contando: cada grupo (objetos y artes) necesitaba una reserva de 8 B para un
nombre que no cabia en ningun hueco propio, y solo habia una de 9 B (final
del banco) y otra de 6 B (tras las armas).

**'Valor' es a la vez arma y armadura**, y como cada entrada de las tablas
es un PUNTERO, las dos pueden apuntar a la MISMA cadena. Deduplicando se
ahorran 8 B y la reserva de armas pasa de 6 a 14 B. Con eso entran los dos.

### Resultado final, releido de la ROM

```
ARMAS     Bokuto Katana Byakko Hiryu Asura Fénix Valor
ARMADURAS Bambú Roja Satsuki Valor        <- 'Valor' comparte cadena (0x43CE9)
OBJETOS   Onigiri Remedio Banquete Dango Bonzo Pedos
          Fuego Hielo Raquetas Capa Aletas
ARTES     Vuelo Salto Rodar Giro Bomba Oleada Azar
```

0 solapes, 0 choques de fuente con el japones, 0 bytes de codigo pisados.

v148: MD5 2d6afb1b3a6b934cd6e053427f9ed505

## [132] v149: el kanji del ryo, 1 px arriba

David: *«El kanji del ryo esta 1 px mas abajo del numero que tiene al lado.»*

Medido en el CG: digitos en las filas 0..6, ryo en las 1..7. Cierto.

### Dos despistes antes de dar con el sitio

1. Mire el glifo $3E de la fuente MENU (ROM 0x40E0). **Esta bien**, filas
   0..6. No es el que se dibuja, pero tarde en descartarlo.
2. Busque la secuencia del CG en la ROM y salio `0x40DF`, justo un byte
   antes del glifo. Parecia la respuesta ("el cargador lee desfasado"), pero
   era **casualidad**: ese $00 es el ultimo byte de la sombra del glifo $3D.

### Donde estaba

La otra coincidencia, `0x3DB58`, cae exacta en la fuente DIALOGO
(0x3D660 + 159*8) = **glifo 159 ($9F)**.

El ryo del menu va por la RUTA BAJA: el remapeo 0x42B4C hace `$24 -> $3E`,
y la tabla baja `$BF9B` (ROM 0x43F9B) manda el $3E al glifo 159. Ese glifo
tiene la fila 0 vacia y el dibujo corrido una fila hacia abajo.

Barridas las cinco tablas (fuentes 0,1,2,3 y la baja): el glifo 159 lo
referencia **solo** el codigo $3E. Sin efectos colaterales.

### El arreglo

Rotar el glifo una fila arriba. La que se pierde es $00 y la que entra
tambien: cero perdida.

```
antes  00 FE 10 FE 92 D6 FE 82   filas 1..7
ahora  FE 10 FE 92 D6 FE 82 00   filas 0..6
```

**8 bytes** modificados. v149: MD5 9249fcefd2f2253e5d454cb1c650260d

**Norma 83. Si una secuencia de bytes aparece en dos sitios de la ROM,
comprobar cual cae en un offset EXACTO de la estructura: la otra puede ser
una coincidencia a caballo entre dos registros.**

## [133] Las tiendas: el mapa del guion, medido

Al abrir la etapa de tiendas, lo primero es corregir lo que el diario daba
por sabido. El apunte antiguo decia «tiendas en 0x48470». **Impreciso.**

### Lo que hay de verdad

```
0x48000..0x480E8   TABLA de 116 punteros (87 textos distintos), base $4000,
                   banco $24. Muchas entradas repetidas: el mismo texto
                   sirve para varias situaciones.
0x480E8..0x48C71   bloque de ANCHO FIJO, 18 celdas por linea: los VITORES
                   del publico ("banzai", "momotaro", "nice guy", "peach",
                   "next stage"). No es la tienda.
0x48F91..0x4A4B9   EL GUION, 5416 B: aldeanos, ermitano, Kintaro, Urashima,
                   la liebre de Kachikachi-yama, los padres...
```

Estructura de las cadenas del guion:

```
$00  fin           $3B  salto de linea      $3D  ~
$21  !             $3F  ?                   $5C  delimitador de nombre propio
$20  espacio fino  $A0  espacio
```

Los dialogos de tienda estan DENTRO de ese bloque: entradas 2, 10, 21, 56...
No son un bloque aparte. El `0x48470` del apunte viejo cae en medio de los
vitores, no en las tiendas.

### El HUD corrupto: sigue sin medir

David confirma el sintoma: *«al salir se corrompe el HUD»*. El diario ya
avisaba (entrada de la v58) de que la explicacion del chat anterior —«es la
fuente sin traducir»— **no cuadra**: una fuente mal no produce ruido ni
rompe el HUD DESPUES de salir. Es estructura.

El HUD son SPRITES (la BAT de la aldea es todo $100 en las tres primeras
filas), asi que hay que mirar el SATB y el CG de sprites en el momento del
fallo. **Hace falta un state.**

## [134] El HUD corrupto de las tiendas: MEDIDO. No es culpa nuestra

David aporto dos states (tienda corrupta / HUD corrupto) y **un dato
decisivo**: *«cuando sales de la aldea y vuelves a entrar, el HUD vuelve a
verse bien»*. Eso descarta codigo roto y apunta a VRAM sobrescrita.

### Lo medido

```
SATB          identico en ambos states: los sprites del HUD apuntan
              correctamente a los patrones $360-$37F
paletas       identicas (12 y 14, las del HUD)
BAT           sana, y NO usa el rango $360-$37F
CG            AQUI esta el fallo
```

Dentro de la tienda, el CG de sprites `$360-$37F` contiene basura; fuera de
la tienda vuelve a estar bien (verificado byte a byte contra el state de
aldea sana: **0 de 1024 bytes distintos**).

Volcando ese CG como sprites de 16x16 se ve que **no es basura**: son los
graficos de la tienda (el tendero, los articulos del mostrador).

### La causa [RECTIFICADO — ver entrada 135]

**La tienda carga sus graficos en `$300..$51B` y en el camino pisa los 28
patrones del HUD (`$360-$37F`).**

~~El juego japones hace exactamente lo mismo: es un bug del original.~~
**FALSO Y NO MEDIDO.** Ver la entrada 135: es culpa nuestra.

Que al salir y volver se arregle encaja: al recargar la aldea se vuelve a
subir el CG del HUD.

### Consecuencia para la traduccion

**El HUD corrupto NO se arregla traduciendo textos**, al contrario de lo que
dijo el chat anterior. Es un solapamiento de CG. Las salidas serian:

1. Mover los graficos de la tienda a un rango libre. Hay 106 tiles vacios
   entre $300 y $51F, pero **fragmentados de uno en uno** (patron: uno libre
   cada cuatro), asi que no hay un bloque contiguo de 28.
2. Mover el CG del HUD a otro sitio y repuntar los sprites que lo usan.
3. Reprogramar la carga para que respete $360-$37F.
4. **Dejarlo**: es fiel al original y se corrige solo al salir.

Pendiente de decidir con David. Como es un bug del juego japones, arreglarlo
es una MEJORA opcional, no un requisito de la traduccion.

## [135] [DESCARTADO] «el HUD roto es un bug del original». Es NUESTRO

David: *«Te estás equivocando. El japonés no tiene ese problema. Se provocó
en el chat original del proyecto [...] El problema lo tenemos sólo nosotros
porque fuimos quienes lo ocasionamos.»*

**Tenía razón y mi conclusión anterior fue un fallo de método grave.** Dije
«el japonés hace exactamente lo mismo» **sin tener un solo dato del juego
original**: los dos states son de NUESTRA ROM. Afirmé como [HECHO] lo que
era una suposición, y encima David ya había enviado capturas de la japonesa
con las tiendas perfectas. La evidencia estaba delante.

### Lo que dice el log del chat original

David señaló el punto exacto del `Log_completo_hasta_v83.txt`. Buscando
«Entro en una tienda y hay corrupción gráfica por todas partes» (línea
23158) aparece que el síntoma ya existía en la **v03**, y unas líneas antes
está la causa:

```
linea 6120:  «Rótulo principal del título [...] el título principal se carga
              como un stream gráfico comprimido de sprites.
              Stream original del logo japonés: ROM 0x252C8 - 0x2617A
              Espacio disponible: 3763 bytes
              Nuevo stream español: 3652 bytes»
linea 72832: «La traducción modificó la fuente de gráficos en 0x252C9»
```

### Medido ahora

```
zona del logo     0x252C8..0x2617A = 3762 B
bytes distintos   3619
stream japones    3710 B, y el sobrante son $00
stream espanol    3115 B, y el sobrante son $FF   <- 647 B de $FF
```

**El relleno es el problema.** El chat original dejo `$FF` donde el japones
tenia `$00`, y en el descompresor `$C206` el mapa de bits `$FF` significa
«ocho literales seguidos»: 647 bytes de $FF no son espacio muerto, son una
orden de leer y escribir cientos de bytes de basura.

Ademas el stream espanol descomprime distinto: 64 tiles consumen 757 B en
la nuestra frente a 971 B en la japonesa. La rutina sigue leyendo tiles
hasta completar su cuenta, y al ir «adelantada» entra en la zona de $FF y
vuelca basura en la VRAM que sigue — incluidos los patrones $360-$37F del
HUD y todo el CG de la tienda.

Eso explica los tres sintomas a la vez:
  - tiendas ilegibles (su CG se carga sobre basura)
  - HUD roto al salir (patrones $360-$37F machacados)
  - se arregla al recargar la aldea (se vuelve a subir el CG del HUD)

**Norma 84. Al sustituir un stream comprimido por uno mas corto, el sobrante
se rellena con el MISMO byte que usaba el original. En este descompresor
$FF significa «ocho literales», no «vacio».**

Pendiente: decidir si se arregla rellenando con $00 o restaurando el logo.

## [136] [DESCARTADO] «el relleno $FF del logo es la causa». Medido: NO

Tras encontrar en el log que el chat original sustituyo el logo del titulo
(`0x252C8-0x2617A`, stream japones 3710 B -> espanol 3115 B, sobrante
relleno con `$FF` en vez de `$00`), afirme que ese `$FF` era la causa:
en el descompresor `$C206` un mapa `$FF` significa «ocho literales».

**Lo comprobe y es falso.** Medido:

```
japonesa  255 tiles -> fin en 0x26179  (el stream acaba clavado)
nuestra   255 tiles -> fin en 0x25EEF  (651 B antes)
```

El descompresor **para antes de llegar al relleno**, asi que da igual si es
`$00` o `$FF`: rellenando con `$00` el resultado es identico, fin en
0x25EEF en los dos casos. Verificado con el descompresor validado.

Ademas el CG de la tienda **no sale del stream del logo**: descomprimiendo
0x252C8 y buscando los tiles $300/$320/$360/$380 de la VRAM de la tienda,
no aparece ninguno.

Y el CG que si esta literal (`$300..$30F` desde ROM `0x38200`, banco `$1C`)
**no lo hemos tocado**: identico byte a byte en las dos ROMs.

**Norma 85. Una hipotesis sobre un formato comprimido se valida EJECUTANDO
el descompresor sobre las dos versiones, no razonando sobre el formato.**

### Estado

Sigue sin localizarse la causa. Lo que si esta firme:

- el sintoma es NUESTRO, no del original (capturas de David + log v03);
- el chat original modifico 3620 B en los bancos `$12`/`$13`, que es la
  unica alteracion grafica grande que hizo, y ya estaba en la v109;
- dentro de la tienda hay 16 sprites del HUD apuntando a `$360-$37F` con
  ese CG machacado.

### Prueba preparada para David

`roms/test_logojp_v150.pce` (MD5 cbb23df46fcb0458aae22ad3100f0c59):
la v149 con la zona del logo **restaurada tal cual de la ROM japonesa**.
Solo cambian esos 3762 B; el resto de la traduccion queda intacto.

Es un experimento de AISLAMIENTO, no un arreglo:
  - si las tiendas se ven bien -> el logo era el culpable pese a lo anterior
  - si siguen mal              -> hay que buscar en otro sitio

## [137] El logo NO era la causa. Biseccion por bancos

David probo `test_logojp_v150.pce` (logo japones restaurado): *«Se ve el
logo japonés, como has dicho, pero sigue viéndose mal»*.

**Logo descartado.** Los 3762 B de `0x252C8-0x2617A` no son la causa.

### La pista del melocoton, seguida

David: *«ese melocotón va por separado»*. Confirmado en el log (lineas
6694-6831): el logo japones no lleva el melocoton integrado, usa un sprite
aparte con **patron `$3C` y paleta propia**, y el chat original **lo movio
de sitio** para el logo espanol.

Eso hacia sospechar que tocaron la LISTA de metasprites del titulo, que
esta en otro banco. Comprobado:

```
0x1F2B0  (stream B del titulo)  modificado, pero es TEXTO del tutorial
0x1FBDC  128 B escritos por nosotros donde la japonesa tiene $FF
```

Y ese hueco **si estaba libre**: en la japonesa el relleno `$FF` va de
`0x1F838` a `0x20000` (1992 B). Escribir ahi no rompe nada.

### Lo que queda por descartar

Inventario de los 14 bancos modificados y que hay en cada uno:

```
$00    52 B  motor de sprites/VDC        $12  3250 B  LOGO (descartado)
$02    44 B  fuente MENU                 $13   370 B  LOGO (descartado)
$07  2289 B  CG del menu (nuestro v147)  $17  1778 B  bloque de aldea
$0C   111 B  rotulo de aldea             $1E   898 B  fuente DIALOGO
$0D  1141 B  menu SELECT + rutina v147   $20   124 B  tablas de fuente
$0E   799 B  mapa                        $21   420 B  nombres del menu
$0F  2995 B  textos                      $3F  1468 B  CG del menu (viejo)
```

### Dos ROMs de biseccion

En vez de seguir sondeando a ciegas, dos pruebas que parten el problema:

**A `test_bisecA_v151.pce`** (MD5 68e89674c79289ce19d2716dd5e8f23e)
nuestra ROM con los bancos GRAFICOS restaurados de la japonesa
(`$12 $13 $1E $17 $0C $0E`), conservando textos y el menu SELECT.
Se veran en japones la fuente de dialogo, el rotulo de aldea y el mapa.

**B `test_bisecB_v152.pce`** (MD5 3fcc5d28c8ea91d4385f662ca47ef614)
la ROM JAPONESA con SOLO esos bancos graficos nuestros. Todo en japones
salvo esos graficos.

Interpretacion:
```
A bien  y B mal  -> la causa esta en los bancos graficos
A mal   y B bien -> la causa esta en los otros ($00 $02 $07 $0D $0F $20 $21 $3F)
A mal   y B mal  -> hay dos causas
A bien  y B bien -> la causa es una interaccion entre grupos
```

## [138] Biseccion A/B: la causa esta en los bancos GRAFICOS

Resultados de David:

**A (`test_bisecA_v151`, bancos graficos restaurados):**
*«He entrado en una tienda y se ve bien. Al salir, el HUD también se ve
bien.»* Los textos salen como «lineas horizontales paralelas, como las de un
pentagrama» (esperado: la fuente DIALOGO volvio a la japonesa).

**B (`test_bisecB_v152`, japonesa + solo los bancos graficos nuestros):**
*«El texto del tutorial no se ve. El abuelo se queda moviendo la boca y el
juego no avanza. Momotaro se ve incompleto y con glitches.»*

```
A bien + B mal  ->  LA CAUSA ESTA EN LOS BANCOS GRAFICOS
```

Grupo sospechoso reducido de 14 bancos a 4: `$1E $17 $0C $0E`
(el logo `$12/$13` ya estaba descartado por la v150).

### Afinando

```
banco  contenido          chat original   total ahora
$1E    fuente DIALOGO       651 B          898 B
$17    bloque de aldea      552 B         1778 B
$0C    rotulo de aldea       15 B          111 B
$0E    mapa                   9 B          799 B
```

El chat original solo toco de verdad `$1E` (651 B) y `$17` (552 B).

Medido en `$1E`: **todo lo modificado son GLIFOS**, no codigo.

```
chat original -> glifos 161..253
nosotros      -> glifos 112..255
antes de la fuente (0x3C000-0x3D660): 0 bytes tocados
```

Y los bancos `$1C`/`$1D`, donde esta el CG literal de la tienda
(`0x38200`), estan **intactos**: 0 bytes modificados.

### Siguientes pruebas

**C `test_bisecC_v153.pce`** (MD5 559bedbc31e6259a2af95bbb0e6e59f6)
solo restaurado `$1E` (fuente DIALOGO).

**D `test_bisecD_v154.pce`** (MD5 7cdc2ac66e2c4d9af37e24eecdeb4c51)
solo restaurados `$17` + `$0C` + `$0E` (aldea, rotulo, mapa).

**E `test_bisecE_v155.pce`** (MD5 527fde0a40a46ea0c9ffb475c1d0fd85)
solo restaurados los glifos 161..255, conservando los nuestros (112..160).
Sirve para saber si la causa esta en la ampliacion de fuente del chat
original o en algo nuestro.

## [139] CAUSA LOCALIZADA: la tabla de fuente repuntada pisa el katakana

Resultados de David:

```
C (v153, fuente DIALOGO restaurada)   -> tienda BIEN, HUD BIEN
E (v155, glifos 161..255 restaurados) -> tienda BIEN, HUD BIEN
D (v154, aldea+rotulo+mapa)           -> tienda MAL, HUD MAL
```

C y E buenas -> la causa esta en la FUENTE DIALOGO, y concretamente en los
glifos 161..255 y/o en la tabla que los apunta.

### El mecanismo

La tabla de la fuente 0 (`$9CF3` = ROM `0x41CF3`) traduce codigo -> glifo:

```
JAPONESA:  $B0-$DF -> glifos 1..46      = KATAKANA
NUESTRA:   $B0-$DF -> glifos 176..223   = alfabeto latino
```

El chat original **repunto la tabla entera** y escribio el alfabeto en los
glifos altos. El texto de las tiendas esta en KATAKANA y usa esos codigos
`$B1-$DF`: en el original dan katakana, en la nuestra dan glifos que hemos
sobrescrito. De ahi el caos ilegible.

La fuente 1 (`$9CB3`) es, en la japonesa, **hiragana** (glifos 52..95), no
un duplicado. La entrada [129] decia que era «un duplicado byte a byte de
la fuente 0»: eso es cierto en NUESTRA rom porque el chat original la
igualo, pero **no en la japonesa**. Matiz importante.

### El dano real, cuantificado

```
glifos de la fuente DIALOGO           308
glifos que usa el juego japones       123
glifos que hemos pisado               133
   de ellos, EN USO por el japones     13   <- el problema
glifos LIBRES de verdad               185
```

**Solo 13 glifos en conflicto**, no 95 como supuse antes. Son:

```
161 (f0 $A8)   163 (f0 $A2)   164 (f0 $A3)   165 (f0+f1 $A5)
166 (f0 $AC)   167 (f0 $AD)   168 (f0 $AE)   169 (f0 $AF)
170 (f1 $AC)   171 (f1 $AD)   172 (f1 $AE)   173 (f1 $AF)
255 (tabla baja $83)
```

Los glifos 1..46 (katakana) y 52..95 (hiragana) **estan intactos**: el texto
japones se puede recuperar entero solo arreglando la TABLA.

### Plan

Hay 185 glifos libres y necesitamos 57 codigos altos. Cabe de sobra. El
arreglo consiste en:

1. mover nuestros 13 glifos en conflicto a huecos libres de verdad;
2. restaurar los 13 glifos japoneses originales;
3. repuntar la tabla para que los codigos que usa el KATAKANA vuelvan a
   apuntar a los glifos 1..46, y los nuestros a los libres.

El obstaculo real: los codigos `$A0-$DF` son solo 64 y el katakana ya ocupa
46. No caben 57 caracteres latinos ademas. Hay que decidir como convivir:
por fuente (conmutando con $01/$02) o traduciendo el guion entero.

## [140] Que fuente usa cada texto: la medicion que define el plan

```
bloque                fuente0 (katakana)   fuente1 (hiragana)
guion 5416 B               4150                    0
vitores                    2707                    0
dinero                      250                    0
armas/armaduras              72                    0
tutorial/menu                488                   20
objetos                     171                  100
artes                        67                   72
```

**El guion entero —lo que rompe las tiendas— usa SOLO la fuente 0.** Ni un
byte de hiragana. La fuente 1 la usan unicamente textos que ya hemos
traducido (objetos y artes del menu).

### El conflicto, exacto

```
codigos $A0-$DF que usa el GUION japones      57
codigos $A0-$DF que usan NUESTROS textos      51
SOLAPE                                        44
```

44 codigos piden katakana y letra latina a la vez. Imposible en una sola
tabla: **hay que separarlos por fuente**.

### Donde se fija la fuente por defecto

`$D113` (ROM 0x1B113) inicializa cada bocadillo: pone el puntero de texto y
`$D141 STZ $3BA6` -> fuente 0. Se ejecuta **una vez por bocadillo**, no por
pagina.

Dato: en la japonesa esos 3 bytes eran `LDA $3CE6`; **el chat original ya los
sustituyo** por `STZ $3BA6`. Funcionalmente equivalente porque A ya valia 4
por el `LDA #$04` anterior.

No se puede meter ahi `LDA #$01 / STA $3BA6` (5 bytes en 3), asi que el
cambio de fuente por defecto habra que hacerlo de otra forma.

### Inventario para el plan

```
glifos libres de verdad                       185
glifos que ocupa nuestro alfabeto              64
   de ellos en conflicto con el japones        13
caracteres nuestros a migrar (con fuente0)   1235
```

### Plan acordado

1. restaurar la tabla `$9CF3` (fuente 0) a la japonesa;
2. restaurar los 13 glifos japoneses pisados;
3. mover el alfabeto latino a la fuente 1 (`$9CB3`);
4. que nuestros textos emitan `$02` al empezar.

Aviso medido: las 14 mayusculas finas de la v148 viven en codigos de la
fuente 1 ($AA $AC $AE $BA $BC $BD $BF $C0 $C2 $C3 $C6 $C9 $CD $CE). Al
convertir f1 en la tabla latina completa, esos codigos pasarian a dar
minusculas. Hay que reasignarlas a glifos libres.

## [141] El guion es VERTICAL. Extraido y medido

David: *«los diálogos de los aldeanos, los del abuelo de los minijuegos
cuando los terminas, y puede que alguno más, son en vertical, con las
líneas de derecha a izquierda»*.

Confirmado y medido sobre los 87 textos. El byte `$3B` separa COLUMNAS
verticales, que se leen de derecha a izquierda:

```
caracteres por columna     maximo 9, la mayoria 5-6
columnas por texto         de 3 a 23, lo tipico 12

distribucion:  3 chars: 67 col    6 chars: 286 col
               4 chars:163 col    7 chars:  34 col
               5 chars:193 col    8 chars:  33 col
                                  9 chars:   1 col
```

**Una columna admite 6 caracteres comodos, 9 como tope.** En japones eso es
una palabra; en castellano, media. Es la restriccion que ya anticipaba el
chat original en su primer mensaje.

### Extraido

`docs/guion.json`  — 87 textos con rom, puntero, bytes, entradas y columnas
`docs/GUION_para_traducir.md` — el mismo guion en markdown, con el katakana
convertido a ancho completo y los dakuten combinados (ﾎ゛ -> ボ), listo para
que David traduzca columna a columna.

Los textos repetidos se listan una sola vez, indicando que entradas de la
tabla de punteros los usan.

## [142] EL MOTOR DE TEXTO VERTICAL, LOCALIZADO

Prioridad fijada por David: los bocadillos horizontales van PRIMERO, porque
sin ellos no se puede traducir el guion («sería como calzarse un 40 cuando
tu talla es el 45»). Y no dependen de nada anterior.

### El motor

Banco `$20` (ROM 0x40000, logico $8000). El guion vive en el banco `$24` y
se mapea en `$9768: LDA #$24 / CLC / ADC $20 / TAM #$04`. El puntero de
texto es `$92/$93`.

**Despachador `$9807`** (ROM 0x41807):

```
LDA ($92)
BEQ  -> $98C1   $00 = fin del texto
CMP #$3B / BEQ $98A3    <- NUEVA COLUMNA
CMP #$3E / BEQ $98E6
CMP #$DF / CMP #$DE -> $984A   dakuten: INC $365A, no ocupa celda
CMP #$5C -> alterna $3659 (EOR #$01)   delimitador de nombre propio
CMP #$60 / CMP #$B0 -> ruta de fuente
(si no) $984D = dibuja el caracter
```

**`$98A3` — el control `$3B`:**

```
INC $92/$93        avanza el puntero
INC $3657          cuenta COLUMNAS
LDA $3657
CMP #$03           <-- TRES COLUMNAS POR PAGINA
BCS -> fin de pagina (espera al boton)
```

**`$984D` — posicion del caracter:**

```
SBC #$20 / TAY / LDA $9C73,Y     tabla de traduccion a glifo
LDA $3657                        contador de columna
ASL / ADC $3657 / ASL / ASL      x3, x4  ->  columna * 24
ADC $3658                        + posicion dentro de la columna
ADC #$06
TAX
STA $3667,X                      buffer del bocadillo
INC $3658                        avanza VERTICALMENTE
CMP #$06                         <-- SEIS caracteres por columna
```

### Los tres numeros que definen el formato

```
$98AF   CMP #$03    columnas por pagina
$987D   CMP #$06    caracteres por columna
$986B   ASL/ASL     paso entre columnas = 24 (3 celdas de 8 px)
$3667   buffer del bocadillo
```

Un bocadillo son **3 columnas x 6 caracteres = 18 celdas**, que coincide
exactamente con los 18 bytes de ancho fijo de las cadenas de dinero
(entrada del diario sobre 0x48D23). Confirma la medida.

### Que haria falta para girarlo

El buffer `$3667` se llena con `indice = columna*24 + fila + 6`. Para
horizontal habria que invertir el calculo: `indice = fila*ancho + columna`,
y cambiar los dos limites (`#$03` y `#$06`). Es aritmetica en tres sitios,
no una reescritura.

Pendiente: localizar como se vuelca `$3667` a la VRAM y donde se dibuja el
marco del bocadillo, para poder ensancharlo.

## [143] El bocadillo vertical, ANATOMIA COMPLETA

David: *«el bocadillo de los diálogos de los aldeanos es siempre igual, así
que, arreglado uno, arreglados todos»*. Confirmado: hay UNA sola rutina y
UNA sola tabla de posiciones.

### El volcado `$9B7C` (ROM 0x41B7C)

```
LDA #$1E / TAM #$04        mapea el banco de la fuente
CLX
$9B84  LDA $3667,X         caracter del buffer
       ASL x3 con ROL $15  x8  -> desplazamiento del glifo
       ADC #$60 / ADC #$56 -> $3661/$3662 = origen del glifo en ROM
       TXA / ASL / TAY
       LDA $9BBD,Y  -> $3663/$3664   DESTINO en VRAM
       LDA $9C05,X  -> $3665         CUADRANTE (0..3)
       JSR $9D33                     escribe el cuadrante
       INX / CPX #$24                <-- 36 CELDAS
```

### Las dos tablas que definen el layout

```
$9BBD (ROM 0x41BBD)  36 words: direccion VRAM de cada celda
$9C05 (ROM 0x41C05)  36 bytes: cuadrante dentro del tile 16x16
```

Las 9 direcciones distintas son **9 tiles de 16x16**, y cada uno recibe 4
cuadrantes de 8x8 -> **36 celdas de texto = 6 filas x 6 columnas** de 8 px.

```
$6870  $68F0  $6970      +$80 words = tile a la derecha
$69B0  $69F0  $6A30
$6A70  $6AB0  $6AF0
```

Orden de llenado actual (VERTICAL, de derecha a izquierda):
celdas 0-5 la columna derecha, 6-11 la siguiente, etc.

### Los numeros del formato

```
$98AF  CMP #$03   columnas por pagina
$987D  CMP #$06   caracteres por columna
$986B  ASL/ASL    paso entre columnas (x24)
$9BB8  CPX #$24   36 celdas en total
```

### Lo importante para girarlo

**El layout esta en DATOS, no en codigo.** Para pasar a horizontal basta
con reordenar las tablas `$9BBD` y `$9C05` de modo que la celda 0 sea la de
arriba-izquierda y se avance en horizontal. El texto, los separadores `$3B`
y el resto del motor NO cambian: solo cambia donde cae cada caracter.

Eso hace el cambio mucho menos arriesgado de lo previsto: **72 bytes de
tabla** en vez de reescribir la aritmetica.

Pendiente: el marco del bocadillo (para ensancharlo y mover el rabillo) y
comprobar si el buffer `$3667` admite mas de 36 celdas.

## [144] v157: bocadillos HORIZONTALES. Solo 72 bytes de tabla

### La geometria, medida

Cada celda del bocadillo cae en (grupo, x, y):

```
+8 words    bajar 8 px dentro del tile de 16x16
+$80 words  bajar al siguiente tile (16 px)
cuadrante bit0:  0 = mitad derecha,  1 = mitad izquierda
cuadrante bit1:  +8 words (mitad inferior)

grupos de 3 tiles apilados:
  grupo 0  $6870 $68F0 $6970
  grupo 1  $69F0 $6A70 $6AF0
  grupo 2  $69B0 $6A30 $6AB0

en pantalla, de izquierda a derecha: grupo2, grupo1, grupo0
```

Cada grupo aporta 2 columnas x 6 filas = 12 celdas. Tres grupos = 36.

**Error cometido y corregido:** mi primer modelo suponia que `+$80` era un
tile a la derecha y `+$180` un salto de fila. Falso. Lo detecte simulando
el texto [1] sobre las tablas permutadas: no salian lineas horizontales
limpias. La geometria buena sale de leer el orden japones (celdas 0-5 =
una columna vertical completa) y deducir de ahi los ejes.

**Norma 86. Antes de permutar una tabla de posiciones, simular un texto
conocido sobre ella y comprobar que el resultado tiene sentido visual.**

### El cambio

Permutar las 36 entradas de `$9BBD` (words) y `$9C05` (bytes) para que la
celda k caiga en fila k//6, columna k%6. **72 bytes**, sin tocar ni el
guion, ni los separadores `$3B`, ni la aritmetica del motor.

Simulacion con el texto [1] (ブキヤ / ボウグヲ / カッテイケバ / ドンドン /
ラクチンニ / ナルノジャ):

```
ANTES                 DESPUES
|ナラドカボブ|         |ブキヤ   |
|ルクンッウキ|         |ボウグヲ  |
|ノチドテグヤ|         |カッテイケバ|
|ジンンイヲ |         |ドンドン  |
|ャニ ケ  |          |ラクチンニ |
|   バ  |            |ナルノジャ |
```

v157: MD5 294f0c20ef190860391267c330007dad

Pendiente: el marco del bocadillo sigue siendo cuadrado (96x96). Hay que
girarlo a apaisado y mover el rabillo, y despues ampliar el numero de
celdas por linea.

## [145] v157 VALIDADA. El marco del bocadillo, localizado

David: *«Buen trabajo»*, con tres capturas: el texto sale **horizontal y de
izquierda a derecha** dentro del bocadillo cuadrado. La permutacion de las
tablas funciona.

### El marco: donde esta

`$9A78` (ROM 0x41A78) dibuja el bocadillo con DOS llamadas a `$E3EB`:

```
1) lista variable segun $368F, via tabla $9ADD (ROM 0x41ADD):
      [0] $9AE5   [1] $9AEB   [2] $9AF1   [3] $9AF7
   cada una es UN solo sprite de 32 px: el RABILLO.
      var0  pat $11  x+24 y+62
      var1  pat $11  x +8 y+62   (flip H, attr $08)
      var2  pat $13  x+47 y+40   (rabillo lateral)
      var3  pat $11  x+24 y+62   (flip H)

2) lista FIJA $9AA0 (ROM 0x41AA0): 12 sprites = el CUERPO del marco
      pat 00 02 04 05 08 09 0A 0C 10 12 14 1C
      todos de 32 px de ancho
      extension total:  x 0..67   y -8..72
```

O sea: el bocadillo mide **~68 x 80 px**, y el rabillo se coloca abajo
(variantes 0/1/3) o al lado (variante 2) segun donde este el interlocutor.

### Para girarlo a apaisado

Hay que:
1. reordenar los 12 registros de `$9AA0` para formar un marco ancho y bajo;
2. ajustar el rabillo (`$9AE5`..`$9AF7`) a la nueva base;
3. ampliar las tablas `$9BBD`/`$9C05` a mas celdas por linea;
4. subir el limite `CPX #$24` del bucle de volcado y `CMP #$06`/`CMP #$03`.

Los graficos del marco son CG de sprites: para un marco mas ancho hara
falta que David edite los tiles de las esquinas y los bordes.

## [146] El marco apaisado: NO se puede girar solo con coordenadas

David pidio girar el bocadillo tal cual, sin agrandarlo, y luego traducir
algo concreto para medir con texto real.

### Lo medido

Interior del bocadillo, medido sobre la captura de David (aislando el
blanco por componentes conexas): **46 x 65 px**. El texto ocupa 6x6 celdas
de 8 px = 48x48. Es decir, ya se sale 2 px por la derecha.

El cuerpo del marco, `$9AA0`, son 12 sprites de 32 px de ancho:

```
y -8   [pat$00 x+0]        [pat$10 x+32]
y +8   [pat$04 x+0 h32]    [pat$0A x+3]     [pat$05 x+35 h32]
y+24   [pat$0C x+3 h32]    [pat$1C x+20]
y+40   [pat$08 x+0]        [pat$14 x+3]     [pat$09 x+35]
y+56   [pat$02 x+0]        [pat$12 x+32]
```

### Intento fallido y por que

Construi una v158 recolocando los 12 sprites en una rejilla 4x3 para dejar
el marco ancho y bajo. **Lo he descartado antes de entregarlo**: la
asignacion «que pieza va en que sitio» era una SUPOSICION mia, no una
medicion. No tengo un state con el bocadillo abierto, asi que no puedo
saber que dibuja cada patron.

Y hay un problema de fondo mas serio:

**Recolocar las coordenadas NO gira el dibujo.** Cada sprite lleva su
forma: una esquina superior-izquierda seguira dibujando esa esquina aunque
la ponga abajo a la derecha. Un marco apaisado necesita bordes horizontales
mas largos y esquinas en su sitio, es decir, **tiles nuevos en el CG**.

**Norma 87. Recolocar metasprites cambia DONDE se dibuja cada pieza, no QUE
dibuja. Girar un marco exige redibujar sus tiles.**

### Lo que hace falta

1. un state con un bocadillo de aldeano abierto (para volcar su CG y saber
   que dibuja cada uno de los 12 patrones);
2. con eso, una lamina para que David edite las piezas del marco apaisado.

---

## (147) El marco del bocadillo es MODULAR: no hay que redibujarlo

David pasa el state pedido: un aldeano hablando en la v157. Formato Mesen
`#RZIPv`, extraído con `tools/state.py` (nuevo, reutilizable) a
`docs/aldeano_{vram,ram,pal,sat}.bin`.

### El SATB desmiente la norma 87 para ESTE caso

Renderizado con `tools/render_sprites.py` (nuevo). El bocadillo son las
ranuras 16-28. Midiendo qué dibuja cada una POR SEPARADO:

```
ran pat   cell tam    posicion    contenido medido
 16 $035A 1AD 16x16  (129,139)   RABILLO (flip H)
 26 $0338 19C 32x16  (121, 69)   esquina SUP-IZQ diagonal + borde, filas 9..15
 24 $0358 1AC 16x16  (153, 69)   esquina SUP-DER,             filas 9..15
 22 $0340 1A0 16x32  (121, 85)   lateral IZQUIERDO, trazo de 3 px
 18 $0342 1A1 16x32  (156, 85)   lateral DERECHO,   trazo a 13 px
 20 $034C 1A6 32x16  (124, 85)   RELLENO blanco (+ texto dentro)
 19 $0350 1A8 32x32  (124,101)   RELLENO blanco (+ texto dentro)
 17 $034A 1A5 16x16  (156,117)   lateral DERECHO
 21 $0348 1A4 16x16  (121,117)   lateral IZQUIERDO
 25 $033C 19E 32x16  (121,133)   esquina INF-IZQ diagonal + borde, filas 0..6
 23 $035C 1AE 16x16  (153,133)   esquina INF-DER,             filas 0..6
 28 $0370 1B8 16x16  (141,101)   MELOCOTON (icono, no es marco)
 27 $0360         -               VACIA
```

**[HECHO] El marco NO hay que girarlo.** Los bordes superior e inferior ya
son rectos y repetibles horizontalmente (celdas `19D` y `19F`, que el
bocadillo vertical usa en su única fila), y los laterales `1A0`/`1A1` ya son
rectos y repetibles verticalmente. Volcando las columnas del marco limpio:

```
x= 0  .....##################################################
x= 1  ...###WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
x=46  ...##WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
x=47  .....#############################################W#W#
```

Las esquinas son diagonales de 3 px y ya existen las cuatro. Es decir: el
bocadillo apaisado se construye **repitiendo piezas que ya están en el CG**,
sin que David tenga que dibujar nada. La norma 87 ("girar un marco exige
redibujar sus tiles") **no aplica** porque no hay que girar nada: hay que
repetir. Se corrige mi conclusión de la v158 descartada.

Compositor con las piezas REALES en `tools/mockup_bocadillo.py`; el
original reconstruido (`capturas/mk_original.png`) coincide con la captura.

### Interior útil medido (no es lo que yo calculaba)

El interior blanco llega de x=1 a x=W-5, pero el texto necesita 3 px de aire
a cada lado. Capacidad real:

```
ancho total   caracteres por linea      lineas (interlinea 12 px)
 96 px (cx=4)        10                   cy=1 ->2  cy=2 ->3  cy=3 ->4
160 px (cx=8)        18
176 px (cx=9)        20
192 px (cx=10)       22
```

### Cuántas páginas costaría cada tamaño [HECHO, contado sobre guion.json]

87 textos, 46 kana de mediana. Estimando el español en 2,2x el kana:

```
                     paginas/texto  max   total
japones original         3,49        8     304
18x3 (160 px)            2,67        5     232
20x3 (176 px)            2,49        5     217
20x4 (176 px)            1,95        4     170
22x4 (192 px)            1,77        3     154
```

Cualquiera de ellos pasa MENOS páginas que el japonés.

### Los dos límites duros

**[HECHO] Sprites: no hay problema.** Un bocadillo de 192 px son 8 sprites y
224 px por scanline; el límite del PCE es 16 sprites / 256 px. Cabe.

**[HECHO] VRAM: no hay problema.** Quedan 31 celdas libres de 16x16 en el
banco de sprites (`1B0-1B2`, `1C0-1C7`, `1CB-1CF`, `1D4-1D7`, `1DD-1DF`,
`1EA-1EF`, `1FA-1FB`). El 22x4 necesita 13 más de las 9 actuales.

**[HECHO] El búfer de RAM es el cuello de botella.** El motor acumula el
texto en `$3667..$368A` = 36 celdas, y `$368B` **ya está en uso** (4
referencias, entre ellas `$41A66` del propio motor del bocadillo). Un 20x4
son 80 celdas: no se puede alargar el búfer en su sitio, hay que MOVERLO y
repuntar `$9861` (`STA $3667,X`) y `$9B84` (`LDA $3667,X`).

> [NO CONCLUYENTE] Busqué un hueco de 80 B en la RAM barriendo referencias
> absolutas en la ROM. El barrido cuenta como referencia cualquier par de
> bytes precedido de algo que parezca opcode, así que da falsos positivos y
> "no encuentra" huecos que probablemente existan. **No sirve como prueba.**
> Hay que resolverlo con breakpoints de escritura en Mesen sobre la zona
> candidata, no con un barrido estático.

### Lo que hace falta ahora

Decidir el tamaño con David (mockups en `capturas/escena_20x3.png`,
`escena_20x4.png`, `escena_22x4.png`) y localizar los 80 B de RAM con
breakpoints.

---

## (148) Los 80 B de RAM: encontrados cruzando 7 states (y una trampa esquivada)

En la entrada anterior deje el hueco de RAM como **[NO CONCLUYENTE]** porque
el barrido estatico de referencias daba falsos positivos. Metodo nuevo, con
evidencia: extraer `BaseRAM` de **los 7 states** que tenemos (aldeano, jp,
padres, run, select, HUD_corrupto, Tienda_corrupta) y cruzarlos.

`tools/state.py` ahora extrae cualquier seccion; los 7 volcados estan en
`docs/*_ram.bin`.

### La trampa: $20CE..$21D3 NO es un hueco, es LA PILA

El cruce daba 10 rachas a cero de 80 B o mas, y la mayor era `$20CE..$21D3`
(262 B). **Es la pila.** Medido:

```
HUD_corrupto     pila usada desde $21D4
Tienda_corrupta  pila usada desde $21D4
padres           pila usada desde $21D4
aldeano/run      pila usada desde $21D7
```

Sale "a cero" simplemente porque la pila estaba poco llena en ese instante.
Si hubiera metido ahi el buffer, lo habria machacado la primera llamada
profunda. **Norma nueva.**

### El candidato bueno: $36F1..$37A7 (183 B)

Esta a cero en los 7 states, y lo importante: **hay states que SI usan la
zona inmediatamente anterior** (`HUD_corrupto` escribe 21 bytes hasta
`$36F0`, `Tienda_corrupta` 6), o sea que la frontera es real y no es que la
zona entera este sin estrenar.

```
$3690..$36F0   lo usa el juego (HUD_corrupto, Tienda_corrupta)
$36F1..$37A7   183 B a cero en los 7 states   <- destino del buffer
```

Un bocadillo 20x4 necesita 80 celdas; caben, con 103 B de sobra.

> [PENDIENTE DE CONFIRMAR EN MESEN] 7 states siguen siendo 7 instantes. Antes
> de escribir un byte hay que poner un breakpoint de ESCRITURA en
> `$36F1-$3740` y jugar un rato (aldea, tienda, jefe, menus). Si no salta,
> la zona es nuestra.

### Corrijo un dato que di mal

Dije que mover el buffer exigia repuntar "dos instrucciones" (`$9861` y
`$9B84`). **Falso, y ademas las direcciones estaban mal.** Contadas las
referencias reales a `$3667`:

```
ROM 16A83  banco $0B  STA $3667,X   (logico $8A83)
ROM 16A96  banco $0B  STA $3667,X   (logico $8A96)
ROM 16AA4  banco $0B  STA $3667,X   (logico $8AA4)
ROM 41883  banco $20  STA $3667,X   (logico $9883)
ROM 41892  banco $20  STA $3667,X   (logico $9892)
ROM 41991  banco $20  STA $3667,X   (logico $9991)
ROM 419A4  banco $20  STA $3667,X   (logico $99A4)
ROM 41B86  banco $20  LDA $3667,X   (logico $9B86)
ROM 5F70B  banco $2F  STA $3667,Y   (logico $970B)
```

**Son 9 punteros en TRES bancos** (`$0B`, `$20`, `$2F`). El banco `$0B` y el
`$2F` son otros usuarios del mismo buffer: hay que averiguar quienes son
antes de moverlo, porque si comparten el buffer con el guion tambien les
afecta el tamaño. Aplica la norma 79.

---

## (149) Primeros 20 textos traducidos y renderizados con la fuente real

`docs/traduccion.py`: el guion en castellano en **prosa normal, sin cortar**.
El reparto en lineas lo hace `repartir()` con el ancho como parametro, asi
que cambiar de 20 a 22 caracteres no obliga a retocar ninguna frase (y no
reparticiono a mano el texto que apruebe David, norma 38).

Verificado:
- **ningun caracter se sale del juego de glifos** de la ROM (comprobado
  contra `CHAR_TO_CODE`, incluidas tildes, ñ, ¡ y ¿);
- `repartir()` lleva un `assert` que revienta si una palabra es mas larga
  que el ancho;
- los 20 textos ocupan **32 paginas** a 20x4.

Renderizados con la fuente de dialogo real de la ROM sobre la escena del
state: `capturas/tr_01_p0.png`, `tr_07_p*.png`, `tr_14_p*.png`.

### Quienes son los otros dos usuarios del buffer [HECHO]

Desensamblados los bancos `$0B` y `$2F`:

```
banco $2F  $9703  LDA $D719,X      <- OTRO productor de texto
           $970B  STA $3667,Y
           $9710  CPY #$24         36 celdas, el MISMO tope
           $9714  JMP $9B7C        <- salta al MISMO volcado del guion

banco $0B  $8A78  LDY $365D
           $8A7B  LDA $3C94,Y
           $8A80  LDA $CAD6,Y
           $8A83  STA $3667,X
```

Es decir: **tres productores distintos escriben en `$3667` y comparten el
volcado `$9B7C`**. El del banco `$2F` incluso lleva su propio `CPY #$24`.

Consecuencia para el plan: al ampliar el bocadillo no basta con tocar el
motor del guion. Hay que:

1. mover el buffer a `$36F1` y repuntar los **9** punteros;
2. subir el tope en los **dos** sitios que lo comprueban (`$987D`/`$98AF` del
   guion y `$9710` del banco `$2F`);
3. ampliar las tablas `$9BBD`/`$9C05` de 36 a 80 entradas.

Los productores de `$0B` y `$2F` seguiran emitiendo 36 celdas mientras no se
toquen: como el buffer sera mas grande, no se rompen (escriben en el primer
tercio). Pero **hay que verificar en pantalla que sus bocadillos siguen bien**,
porque el volcado compartido si cambia de geometria.

---

## (150) Los 87 textos traducidos, y el problema que destapan: NO CABEN

`docs/traduccion.py` tiene ya **los 87 textos en castellano**, en prosa sin
cortar. Verificado: ningun caracter se sale del juego de glifos de la ROM.

Uso «…» (`$CF`, un byte) en vez de tres puntos: el original hace lo mismo con
`$3D` y ahorra 2 celdas cada vez que aparece, que son muchas.

### La medida que faltaba [HECHO]

```
GUION JAPONES   5415 B
GUION ESPANOL   8773 B     +3358 B  (162 %)
```

Los que mas crecen: [85] 96->175, [83] 96->171, [78] 88->155.

Esto **no es una sorpresa evitable**: es exactamente lo que decia David con
lo del pie del 45. Pero hay que ponerle numero antes de inyectar nada.

### Cuanto espacio hay REALMENTE [HECHO]

El motor mapea el banco con `TAM #$04` = **MPR2 = `$4000-$5FFF`**, y los
punteros llegan hasta `$6446`, o sea que MPR3 (`$6000-$7FFF`) tambien esta
mapeado. La ventana total del texto es:

```
$4000-$7FFF = ROM 0x48000-0x4BFFF = 16384 B
```

Y esta asi de llena:

```
0x48000..0x480E8   tabla de 116 punteros           232 B
0x480E8..0x48C71   vitores (ancho fijo 18)        2953 B
0x48C71..0x48F91   dinero + rotulos varios         800 B
0x48F91..0x4A4B9   EL GUION                       5416 B
0x4A4B9..0x4B93B   final, creditos, quiz, minijuego 5250 B
0x4B93B..0x4C000   LIBRE ($FF)                    1733 B
```

**Faltan 3358 B y solo hay 1733 libres.** No llega ni de lejos.

> Corrijo un dato del diario: yo tenia anotado el guion como
> "0x48F91..0x4A4B9, 5415 B" y punto, como si detras hubiera relleno. **Detras
> hay 5250 B de contenido vivo** (el texto del final, los creditos, un quiz y
> un minijuego de piedra-papel-tijera en `0x4B900`). Decodificado y
> comprobado. No es hueco. Norma 72 otra vez.

### Vias medidas, ninguna suficiente por si sola

```
diccionario de 52 palabras repetidas   ahorro NETO   768 B
quitar el relleno de los vitores       ahorro       ~670 B  (exige tocar su rutina)
hueco libre al final de la ventana                  1733 B
                                       -----------------
                                       total        3171 B  < 3358 B
```

Aun sumandolo todo **sigue sin caber**, y dos de las tres vias son invasivas.

### Lo que si resuelve el problema

Sacar el guion de la ventana de 16 KB: el texto no tiene por que vivir en el
mismo banco que lo lee. Hay 19247 B de relleno `$FF` repartidos por la ROM,
con bloques grandes y limpios en `0x47C02` (1022 B, banco `$23`, **pegado a
la ventana**), `0x4B93B` (1733 B), `0x5FC43` (957 B) y `0x7EF7A` (2182 B).

La forma limpia es **anadir un byte de banco a la tabla de punteros**: pasar
de 116 entradas de 2 B a 116 de 3 B (banco + puntero), y que `$9768` cargue
el banco de la tabla en vez de la constante `#$24`. Con eso el guion puede
vivir en cualquier banco libre y deja de haber techo.

Coste: 116 B mas de tabla, y tocar `$9768` (`LDA #$24` -> `LDA banco,Y`).

> [HIPOTESIS, no medido] Que `$9768` sea el UNICO sitio que mapea el banco
> del texto. Hay que buscar todos los `TAM #$04` que preceden a una lectura
> de `($92)` antes de tocarlo. Aplica la norma 79.

### Lo que NO voy a hacer

Recortar la traduccion para que quepa. David pidio fidelidad, y ademas
recortar 3358 B es mutilar el guion, no ajustarlo. Primero se amplia el
contenedor y luego se mide otra vez.

### [DESCARTADO] "Solo hay que tocar $9768"

Lo puse como hipotesis en la entrada anterior y **es falsa**. Buscado el
patron exacto `LDA #$24 / CLC / ADC $20 / TAM #$04` en toda la ROM:

```
ROM 0219E  banco $01  $819E
ROM 106D4  banco $08  $86D4
ROM 11AD2  banco $08  $9AD2
ROM 11D53  banco $08  $9D53
ROM 1699A  banco $0B  $899A
ROM 41768  banco $20  $9768   <- el del guion
ROM 417F4  banco $20  $97F4
ROM 4195F  banco $20  $995F
```

**8 sitios en 4 bancos** mapean la ventana del texto. Y el patron que la
abre entera (`TAM #$04 / INC A / TAM #$08`, los dos bancos consecutivos)
aparece en **42 sitios**.

Esto confirma la geometria (ventana de 16 KB `$4000-$7FFF` = ROM
`0x48000-0x4BFFF`) pero **encarece mucho** la idea de meter un byte de banco
por entrada: habria que revisar los 8 puntos de mapeo, no uno.

### Alternativa mas barata, sin tocar el mapeo [HIPOTESIS a medir]

Los 5250 B de `0x4A4B9..0x4B93B` (final, creditos, quiz, minijuego) **no los
apunta la tabla de 116 punteros**: los alcanza otro codigo. Si ese contenido
se pudiera mover a un banco propio y dejar su hueco al guion, habria
`1733 + 5250 = 6983 B` para un guion que necesita 8773 - 5416 = **3358 B mas
de los que tiene**. Sobraria espacio de largo.

Antes de proponerlo en firme hay que medir QUIEN lee esos 5250 B y con que
punteros. Es lo siguiente.

---

## (151) Inventario definitivo de la ventana del texto, y por que el rastreo estatico se acaba aqui

Antes de proponer mover nada, hacia falta saber QUE hay exactamente en los
5250 B que yo habia etiquetado como "final, creditos, quiz". Desglosado
decodificando katakana y midiendo densidad de espacios:

```
INVENTARIO  ventana $4000-$7FFF = ROM 0x48000-0x4BFFF (16384 B)

tabla de 116 punteros        48000..480E8    232 B
vitores                      480E8..48C71   2953 B
dinero y varios              48C71..48F91    800 B
GUION                        48F91..4A4B9   5416 B
final + creditos             4A4B9..4A7B9    768 B
nombres de enemigos          4A7B9..4AE8A   1745 B
ARTES (13 nombres)           4AE8A..4AEE4     90 B
quiz: preguntas              4AEE4..4B439   1365 B
quiz: respuestas (rejilla)   4B439..4B8C0   1159 B
minijuego jan-ken-pon        4B8C0..4B93B    123 B
LIBRE                        4B93B..4C000   1733 B
```

### Un hallazgo util: la tabla de las ARTES [HECHO]

`ROM 0x118BE` (banco `$08`, logico `$98BE`), **13 punteros** de 2 B a
`0x4AE8A..0x4AEDE`. Verificada: las 13 entradas caen en inicio exacto de
cadena y la 14 ya es basura. Contenido:

```
[0] ジャンプ    [1] コロコロ    [2] マワシ     [3] バクハツ
[4] ツナミ      [5] パロプンテ  [6] モモヒエン
[7..12] las mismas con prefijo モモ
```

Son **los nombres de las ARTES** que ya tenemos aprobados para el menu
SELECT (Salto, Rodar, Giro, Bomba, Oleada, Azar). O sea que las artes se
nombran en DOS sitios y este no estaba en el diario. Hay que traducirlo
tambien, y con los mismos nombres, o el menu y el juego diran cosas
distintas.

### El bloque de respuestas del quiz es medio aire

`0x4B439..0x4B8C0`, 1159 B, de los que **539 son espacio (47 %)**: campos de
ancho fijo de 8-9 celdas (medido: la distancia mas frecuente entre inicios
de campo es 8, luego 9).

### [DESCARTADO] Localizar por rastreo estatico quien lee cada bloque

Lo intente de tres formas y **ninguna vale**:

1. buscar cualquier word en el rango -> 1198 candidatos en un solo banco,
   puro ruido;
2. exigir que el word caiga en inicio EXACTO de bloque -> solo encontro la
   tabla de artes (que si es real);
3. buscar el puntero de inicio como par de inmediatos `LDA #lo / LDA #hi`
   -> **cero resultados** para el quiz.

Y los dos "aciertos" del metodo 3 para final/enemigos resultaron ser
`LDA $CA67,Y` y `LDA $D664,Y` al desensamblarlos: **falsos positivos**, el
word coincidia por casualidad dentro de otra instruccion.

Conclusion honesta: **el quiz no se alcanza con una tabla de punteros de 16
bits**, se recorre secuencialmente desde algun sitio que no se localiza
mirando bytes. Esto no se resuelve leyendo la ROM: se resuelve con un
**breakpoint de lectura en Mesen** sobre `0x4AEE4` jugando al quiz.

Aplica la norma 45 al reves: antes de mover una ruta hay que comprobar que
se sabe quien la usa, y aqui **no lo se**. No se mueve nada hasta saberlo.

### Las artes SI caben, justas: 92 de 92 B [HECHO]

El bloque real es `0x4AE8A..0x4AEE6` = **92 B** (la ultima cadena termina en
`0x4AEE5`; en `0x4AEE6` ya empieza el quiz).

Como los 13 punteros de `0x118BE` son independientes, dos de ellos pueden
apuntar a la MISMA cadena — que es justo lo que hace el original, donde `[5]`
y `[12]` son ambos パロプンテ. Aprovechandolo:

```
Salto 6   Rodar 6   Giro 5   Bomba 6   Oleada 7   Azar 5
Momohien 9   MomoSalto 10   MomoRodar 10   MomoGiro 9
MomoBomba 10   MomoAzar 9
                                    total  92 B  /  92 disponibles
```

**Entra exacto, sin tocar nada mas.** Los nombres coinciden con los ya
aprobados para el menu SELECT, asi que el juego y el menu diran lo mismo.

> Ojo: "Oleada" se comparte entre `[4]` y `[12]`, igual que el japones
> compartia パロプンテ. Si David cambia ese nombre por uno mas largo, deja
> de caber y hay que reubicar el bloque.

---

## (152) Donde meter los 3358 B: tres vias medidas, y la ROM NO hay que ampliarla

### Lo primero: la ROM esta llena, pero no hace falta agrandarla [HECHO]

512 KB, 64 bancos `$00-$3F`, **ninguno vacio** (el mas libre es el `$16`, con
solo un 13 % de contenido util). El hardware HuCard admite hasta 2 MB
(el banco es un valor de 0-255 en TAM/MPR), y genere una version de 640 KB
para probarlo. **Pero no hace falta**, y ampliar el fichero es arriesgado:
cambia el mapeo, puede romper la deteccion del emulador y complica el IPS.

Sumando las colas de relleno `$FF` de todos los bancos:

```
$01 643   $03 407   $07 469   $08 305   $09 366   $0B 460
$12 269   $14 425   $16 760   $1A 699   $1B 356   $1E 345
$23 1022  $25 1733  $27 905   $2F 957   $37 288   $3F 1806
                                              TOTAL 12215 B
```

Y un empaquetado *first-fit decreasing* de los 87 textos (el mayor es de
175 B, el hueco mayor de 1806) los coloca **todos, con 3442 B de sobra**.
O sea que espacio hay; el problema es solo *como se direcciona*.

### Via A: repartir el guion por los huecos de todos los bancos

Cabe, pero **obliga al byte de banco por entrada**, y eso arrastra los 8
puntos de mapeo que encontre en la entrada 150. Es la mas potente y la mas
invasiva.

### Via B: liberar el quiz [LA BUENA]

Todo dentro de la ventana, sin tocar el mapeo de bancos:

```
espacio actual del guion                       5416 B
+ hueco libre 0x4B93B                          1733 B   -> 7149, faltan 1624
+ quiz: preguntas (1365 B)                              -> 8514, faltan  259
+ quiz completo  (preguntas + respuestas)               -> 9673, SOBRAN 900
+ y el jan-ken-pon (123 B)                              -> 9796, SOBRAN 1023
```

**Con el quiz entero liberado sobran 900 B.** El quiz se reubica en la cola
del banco `$3F` (1806 B) o del `$23` (1022 B), que le caben enteros.

### Via C: diccionario de frases [DESCARTADA como solucion unica]

La medi **aplicandola de verdad**, no estimando: algoritmo voraz que en cada
vuelta elige la subcadena que mas ahorra y la sustituye.

```
frases utiles encontradas: 20   coste del diccionario: 214 B
mejores: 'Esta es la aldea' x6, 'Dicen que' x9, 'los ogros' x8,
         'ha vuelto' x6, 'De verdad,' x5, 'el boton' x6
```

Muy lejos de los 1624 B que harian falta para evitar tocar el quiz. Sirve
como complemento, no como solucion. Y anadiria un descompresor al motor.

### Decision propuesta

**Via B.** No toca el mapeo de bancos (lo mas fragil), deja 900 B de margen
y solo mueve un contenido opcional y autocontenido. Sigue dependiendo de
saber quien lee el quiz -> breakpoint pedido a David.

> Nota: el `test_ampliada_v159.pce` (640 KB, MD5
> `e7dcb6b9e5beb7c42cca827b1cbd9799`) queda como prueba de concepto por si
> algun dia hiciera falta, pero **no forma parte del plan**.

---

## (153) Los 35 mensajes de victoria: traducidos y CABEN donde estan

`docs/traduccion_enemigos.py`. Bloque `0x4A7B9..0x4AC45`, 36 bloques
separados por `$00`; el 37 (492 B) es otra cosa (ermitano y casino) y va
aparte.

Cada mensaje es un comentario burlon + el nombre del enemigo, con `$3B` como
separador de linea, igual que el guion.

### El ancho real de esa pantalla [HECHO]

Midiendo las partes entre `$3B` de los 36 mensajes japoneses:

```
0 chars: 29    12: 4    16: 3    20: 3
8 chars:  1    13: 4    17: 4    31: 1
9 chars:  4    14: 6    18: 2    32: 3
10 chars: 1    15: 5    19: 8    33: 3
11 chars: 2                      34/38/39/41: 1 cada una
```

Hay un corte limpio: **casi todas <= 20**, y las de 31-41 son lineas que el
motor parte solo. O sea que la rejilla util es de **20 caracteres**, la
misma anchura que hemos elegido para el bocadillo.

> Me equivoque al leer esto la primera vez: mire el maximo (41) y di por
> bueno un ancho de 40 para la traduccion. El maximo no es el ancho: es una
> linea que el motor reparte. Hay que mirar la DISTRIBUCION, no el maximo.

### Resultado

```
japones   1621 B
espanol   1616 B  con reparto a 20 caracteres
```

**Cabe en su sitio, sin mover ni un byte.** Ninguna linea pasa de 20 y
ningun caracter se sale del juego de glifos.

Los nombres siguen el criterio de David: se mantiene el juego de palabras
del original (todos son «Ogro X»), y los que en japones son un chiste
concreto (エノモト36サイ = un famoso de la tele) se adaptan sin inventar.

---

## (154) Tres correcciones que salen de mirar la captura: lateral, rabillo y los puntos suspensivos

David mira la prueba y dice tres cosas. Las tres son ciertas y **dos eran
fallos mios**.

### 1. El lateral derecho iba 3 px metido [HECHO, era fallo mio]

Medido en el SATB del state:

```
SUP-DER (esquina)  x=153
LAT-DER (lateral)  x=156     <- +3
SUP-IZQ            x=121
LAT-IZQ            x=121     <-  0
```

La razon esta en el CG: en la celda `1A1` el trazo negro **vive en la columna
12 del tile, no en la 15** (el resto es blanco de relleno). Por eso el
original desplaza ese sprite +3 px, para que el trazo case con las esquinas.
Mi compositor pegaba todo alineado a la rejilla de 16 y el borde derecho
quedaba 3 px hacia dentro.

Corregido con la constante `DESP_LAT_DER = 3`. Verificado: ahora el trazo cae
en x=175 tanto en la fila del borde como en las de relleno.

### 2. El rabillo asimetrico canta en un bocadillo centrado

Tambien cierto. El sprite `1AD` es una **cuna asimetrica**: ancha arriba y
con la punta hacia un lado.

```
################
.#############..
....#########...
.......######...
.........####...
...........##...
............#...
```

En el bocadillo vertical no se notaba porque el bocadillo estaba descentrado
respecto al aldeano; en el apaisado y centrado, si.

Probe a componer una punta simetrica pegando la cuna y su espejo. **No sale
bien**: la punta esta en la columna 12, asi que las dos mitades o se solapan
o dejan una V abierta. Lo mejor que consigo es que se estreche sin llegar a
cerrar:

```
########WWWWWWWWWWWW################
.....####WWWWWWWW####...............
........##WWWWW###..................
.........#WWWWVW#...................
.........##....##...................
```

**Un rabillo simetrico de verdad hay que dibujarlo.** No lo disimulo: dejo
las dos versiones (`capturas/rabillo_A_original.png` y `_B_centrado.png`) y
una lamina ampliada (`capturas/EDITAR_rabillo.png`) por si David prefiere
editarlo el.

### 3. «...» NO existe como glifo [HECHO, era fallo mio y de los gordos]

Yo habia escrito en el diario que se usaba «...» como **un solo byte `$CF`**
para ahorrar celdas. **Falso.** Volcado el bitmap del glifo 207, que es al
que apunta `$CF`:

```
........        el codigo $CD (dos puntos) da:   ........
........                                         .##.....
.##.....                                         .##.....
.##.....                                         ........
........                                         ........
.##.....                                         .##.....
.##.....                                         .##.....
........                                         ........
```

**Son dos puntos con otro espaciado, no puntos suspensivos.** Por eso en la
captura de David se leia «Vaya: Que perro tan fuerte:».

Y no se puede repuntar: **el juego japones usa `$CF` 228 veces**. El `$3D`
del original tampoco vale: es el punto centrado japones「・」, y su glifo
(165) es uno de los 13 que el chat original piso.

Tampoco hay donde meter un glifo nuevo: los 9 glifos vacios de la fuente
**son todos destino de la tabla baja** (norma 75, otra vez).

Solucion: escribir **tres puntos normales**. Coste medido: +248 B y **+3
paginas** en todo el juego. Barato. Aplicado a los 87 textos.

---

## (155) El rabillo simetrico YA EXISTE en el juego (David tenia razon)

David propone copiar el rabillo de los bocadillos normales (intro, tutorial)
en vez de disenar uno. **Comprobado: existe, y esta en la MISMA celda.**

Volcando la celda `1AD` (patron `$035A`) de tres states distintos:

```
state "padres" (INTRO)          state "aldeano" y "run"
4444444444444444                ################
4444444444444444                .#############..
4444444444444444                ....#########...
4444444444444444                .......######...
###444444444####                .........####...
...##44444##....                ...........##...
.....#444#......                ............#...
......#4#.......                ................
.......#........
```

**Misma direccion de VRAM, contenido distinto.** El juego recarga el CG del
bocadillo segun la escena: la intro usa un triangulo **simetrico que cierra
en punta** y los dialogos de aldeano una cuna asimetrica.

Detalle util: en la version de la intro el color 4 es el relleno y el 0 la
transparencia, y la punta baja hasta la fila 8 (una fila mas que la cuna).

### Consecuencia para el plan

No hay que disenar ni editar nada, y **tampoco hace falta tocar la logica de
lados** que encontre justo antes (la rutina `$87EC`, que compara la X del
que habla con la de Momotarou y elige variante). Basta con que el bocadillo
de dialogo cargue el CG del rabillo de la intro en la celda `1AD`.

> Queda por medir DE DONDE sale ese CG (que rutina lo escribe en `1AD` en la
> intro y no en la aldea). Es una lectura de ROM con breakpoint de escritura
> en VRAM `$D68` (= celda `1AD`), para hacer junto con los otros dos.

Se descarta por tanto la idea de componer la punta pegando la cuna y su
espejo (entrada 154), que no cerraba bien. **Norma: antes de dibujar un
grafico nuevo, buscarlo en los otros states del propio juego.**

---

## (156) Los breakpoints de David: uno DESMIENTE mi propuesta y el otro la resuelve

### BREAKPOINT 1: $36F1 NO esta libre. Mi propuesta era FALSA [HECHO]

Pedi a David un breakpoint de escritura en `$36F1-$3740` para confirmar que
la zona estaba libre. **Salto.** En `$C22F` (ROM `0x1022F`, banco `$08`):

```
$C226  LDX $39B8        indice guardado en RAM
$C229  CPX #$04
$C22B  BCC $C22F
$C22D  LDX #$04         lo limita a 4
$C22F  STX $36F1        <- ESCRIBE EN MI HUECO
$C232  LDA $C28E,X / STA $36E6
$C238  LDA $C28F,X / STA $36E7
```

**Mi conclusion de la entrada 148 era falsa.** Yo habia deducido que
`$36F1..$37A7` estaba libre porque valia cero en los 7 states. El fallo de
metodo: **7 states son 7 instantes**, y ademas todos eran de situaciones
parecidas. Ninguno estaba dentro de una tienda con ese contador puesto.

David ademas observo algo muy fino: *«salta al entrar en una tienda, pero al
lado hay otra tienda en la que no salta»*. Encaja exactamente con el codigo:
`LDX $39B8` es un indice **por tienda**; con unas variantes se pasa por
`$C22F` y con otras no.

Y contandolo bien (filtrando por opcode valido), de las 80 direcciones de
`$36F1..$3740` **solo 27 no tienen ninguna referencia**, y estan sueltas. La
zona esta densamente usada por los bancos `$0A`, `$1B`, `$1F`, `$27`.

**Conclusion: el buffer de 80 celdas NO va a `$36F1`.** Hay que buscar otro
sitio, y esta vez no con states: con breakpoints o con un analisis de
verdad. Norma nueva.

### BREAKPOINT 2: el quiz se lee con un puntero de pagina cero [HECHO]

Justo lo que el rastreo estatico no podia encontrar, y por eso no lo
encontraba: **no hay tabla de punteros de 16 bits apuntando al quiz desde
otro banco**. Se lee asi:

```
$DAC5  TMA #$08 / PHA                 salva MPR3
$DAC8  LDA #$25 / ADC $20 / TAM #$08  banco $25 -> $6000-$7FFF
$DAD2  LDA #$24 / ADC $20 / TAM #$04  banco $24 -> $4000-$5FFF
$DAD9  LDA ($BF)                      <- LEE EL TEXTO
$DB80  LDA ($BF),Y
```

`$BF/$C0` es un puntero en **pagina cero**. Por eso ningun barrido de words
en la ROM lo encontraba: el puntero no esta almacenado en ROM como dato,
**se construye con inmediatos**.

Localizados los 12 sitios del banco `$08` que lo cargan
(`LDA #lo / STA $BF / LDA #hi / STA $C0`):

```
ROM 10C32 -> $6CAE     ROM 11600 -> $6DE2     ROM 1194A -> $6EE6  QUIZ
ROM 10C40 -> $6CB6     ROM 1161D -> $6DF5     ROM 119B6 -> $6D56
ROM 10F79 -> $6CE0     ROM 117BE -> $6E2D     ROM 11D1B -> $7908
ROM 10F87 -> $6CE8     ROM 117DB -> $6E32     ROM 11D26 -> $7923
```

Mas dos que indexan tablas: `$D8BC` y `$D8CA` (las de las ARTES, ya
conocidas) y `$D86C` (respuestas del quiz, `0x4B468+`).

**Y todos estan en el mismo banco `$08`.** Eso es la buena noticia: mover el
quiz es reescribir inmediatos y tablas **en un solo banco**, no tocar el
mapeo. La via B sigue en pie y ahora se sabe exactamente que hay que
repuntar.

### Y entonces, ¿donde va el buffer de 80 celdas? [MEDIDO, sin respuesta aun]

Con `$36F1` descartado, busque un hueco de 80 B en TODA la RAM `$2000-$3FFF`
con el indice inverso de referencias (filtrando por opcode valido):

**No hay ni una sola racha de 80 B sin referencias en los 8 KB.** La RAM del
juego esta llena.

Comprobado tambien si el buffer puede crecer donde esta: desde `$3667` hay
**26 bytes** contiguos antes de topar con `$3681`... que resulta ser el
propio buffer. Desensamblado `$98ED`:

```
$98ED  LDA $990D,X
$98F1  SBC #$20
$98F4  LDA $9C73,Y
$98F7  STA $3681,X      <- escribe 9 celdas
$98FB  CPX #$09
```

Es un texto fijo de 9 caracteres que se precarga en la ultima columna del
buffer. **No es un usuario ajeno**, es parte del mismo sistema.

Asi que el buffer real es `$3667..$368A` (36) y detras esta `$368B`, que si
tiene 4 usuarios externos.

### Replanteamiento

La pregunta «como amplio el buffer a 80 celdas» **puede estar mal planteada**.
El buffer no guarda la pagina: guarda **una pasada de volcado**. `$9B7C`
vuelca 36 celdas de golpe a VRAM y termina. Si el motor puede llamarse dos
veces con dos mitades, un bocadillo de 20x4 = 80 celdas cabria en pasadas de
40 sin ampliar nada... pero el bucle indexa con X de 0 a `$24` y las tablas
`$9BBD`/`$9C05` estan indexadas por esa misma X, asi que habria que
duplicarlas o parametrizarlas.

Es la via que hay que explorar antes de buscar mas RAM. **No la doy por
buena todavia: hay que medirla.**

---

## (157) El tercer breakpoint: le di a David una direccion MAL CALCULADA

David ejecuta el breakpoint de VRAM `$0D68-$0D70` que le pedi y captura dos
paradas. **Ninguna de las dos sirve, y la culpa es mia.**

### El error

```
celda del rabillo = 0x1AD
bytes en VRAM     = 0x1AD * 128 = 0xD680
WORDS en VRAM     = 0x1AD *  64 = 0x6B40   <- lo que entiende el VDC

yo le pase        = 0x1AD *   8 = 0x0D68   <- MULTIPLIQUE POR 8
```

**Confundi el factor.** Un sprite de 16x16 son 4 planos de 32 B = 128 B = 64
words, no 8. La direccion que le di apunta a tiles de FONDO, sin relacion
con el rabillo.

Lo que capturo, en consecuencia, fueron dos **bucles de relleno de VRAM**
genericos (`$C65D BNE $C655` y `$C0D5 ST1 #$00`, los dos escribiendo
`VDC_DATA_HI` en bloque). Ruido.

Direccion correcta, verificada decodificando el tile en el volcado:
**`$6B40..$6B7F`**.

### Pero ya no hace falta el breakpoint [HECHO]

Antes de pedirle otra pasada, lo busque en la ROM con el descompresor de CG
que ya teniamos (`tools/descomp_cg.py`), tomando como patron el rabillo
simetrico del state «padres»:

```
ROM 0x5292  (banco $02)   stream comprimido de 46 bytes
            descomprime a 128 B = el sprite de 16x16 completo
            identico byte a byte a la celda 0x1AD del state «padres»: True
```

```
4444444444444444
4444444444444444
4444444444444444
4444444444444444
###444444444####
...##44444##....
.....#444#......
......#4#.......
.......#........
```

El rabillo simetrico esta en `ROM 0x5292`, ocupa **46 B comprimidos** y no
hay que dibujar nada, tal como dijo David.

> Leccion: antes de gastar el tiempo del director en un breakpoint,
> comprobar si el dato se puede sacar de la ROM con las herramientas que ya
> estan escritas. Y **recalcular toda direccion de VRAM antes de darsela**.

---

## (158) La geometria del bocadillo esta en CUATRO numeros, y el buffer desperdicia la mitad

Con `$36F1` descartado, desensamble el motor entero para saber que hay que
tocar de verdad.

### El indice de celda [HECHO]

`$9863` calcula donde va cada caracter dentro del buffer:

```
LDA $3657 / ASL / ADC $3657 / ASL / ASL    = columna * 12
ADC $3658                                   + posicion
ADC #$06                                    + 6
TAX  ->  STA $3667,X
```

O sea **X = columna*12 + posicion + 6**. Con 3 columnas de 6 caracteres:

```
col 0 -> X =  6..11
col 1 -> X = 18..23
col 2 -> X = 30..35
```

**El buffer tiene 36 celdas pero el texto solo ocupa 18.** Las otras 18
(0-5, 12-17, 24-29) son el aire de una rejilla de 3x12 que el japones no
llena. Verificado en el state del aldeano: los bytes caen exactamente en las
celdas predichas y el resto estan a `$00`.

### Los cuatro parametros

```
$987D  CMP #$06   caracteres por columna   ROM 0x4187D
$98AF  CMP #$03   columnas por pagina      ROM 0x418AF
$9BB8  CPX #$24   celdas que vuelca (36)   ROM 0x41BB8
$9863  X = col*12 + pos + 6                ROM 0x41863
```

### Cuanto se puede hacer SIN tocar la RAM

Eliminando el aire, en las mismas 36 celdas caben 36 caracteres reales.
Medido sobre los 87 textos ya traducidos:

```
18x2 = 36 celdas -> 309 paginas, max 6
 9x4 = 36 celdas -> 309 paginas, max 6
12x3 = 36 celdas -> 316 paginas, max 6
                    ---
20x4 = 80 celdas -> 156 paginas, max 3
japones original -> 304 paginas, max 8
```

**No compensa**: 36 celdas dan practicamente las mismas paginas que el
japones. El salto de calidad esta en las 80.

### Buscando 80 B de RAM, con los DOS criterios cruzados

Aplicando la norma 95 (no fiarse solo de los states) **y** el indice inverso
de referencias:

```
rachas sin referencias Y a cero en los 7 states:
   $2146..$217D   56 B   <- es la PILA, descartada
   $2C51..$2C80   48 B
   $2B84..$2BAB   40 B
   $255C..$257F   36 B
```

**Ninguna llega a 80.** Y `$3248..$328E` (71 B), que parecia la mejor por
referencias, **tiene 64-69 bytes vivos en 4 de los 7 states**. Descartada.

Con 48 celdas lo mejor es `24x2` -> 231 paginas. Sigue lejos de 156.

### La via que evita la RAM por completo [HIPOTESIS, con un riesgo claro]

Desensamblando `$9D33` (el que escribe en VRAM) se ve que **no usa el
buffer**: solo necesita `$3661/$3662` (origen del glifo), `$3663/$3664`
(destino VRAM) y `$3665` (cuadrante). El buffer existe unicamente para que
`$9B7C` recorra las 36 celdas al final, de golpe.

Entonces se puede **escribir cada caracter a VRAM en el momento**, en `$9883`
(donde hoy hace `STA $3667,X`), y el buffer deja de hacer falta. Sin RAM
nueva, sin limite de 36 ni de 80.

> **[RIESGO MEDIDO]** El volcado se llama desde **8 sitios** y siempre en
> bloque, una vez por pagina. Es muy probable que este sincronizado con el
> vblank: escribir 80 veces durante el frame en vez de una rafaga podria dar
> corrupcion o parpadeo. **No se toca hasta comprobarlo**, y la forma de
> comprobarlo es un test pequeno en pantalla, no mas analisis.

Aplica la norma 45: antes de parchear, comprobar que la ruta esta viva y en
que condiciones.

### El riesgo del vblank: DESCARTADO [HECHO]

Desensamblado `$E185`, que es lo primero que hace `$9D33` en **cada celda**:

```
$9D33  PHX / CLX / JSR $E185 / PLX
$E185  LDA $0000 / AND #$40 / BNE $E185    espera al VDC
```

**El motor ya sincroniza celda a celda, no en rafaga.** Escribir cada
caracter en el momento no cambia el patron de acceso a VRAM: son las mismas
llamadas a `$9D33`, solo repartidas en el tiempo. El riesgo que anote en la
entrada 158 no existe.

### Presupuesto en el banco $20

```
LIBERA   bucle de volcado $9B7C..$9BBC     65 B
         huecos $9FE0 y $9FF1              31 B
                                        ------  96 B

NECESITA tabla $9BBD  de  72 -> 160 B     +88 B
         tabla $9C05  de  36 ->  80 B     +44 B
         rutina de escritura inmediata    ~30 B
                                        ------ ~162 B
```

Deficit de ~66 B. La salida es **calcular** el destino en vez de tabularlo.

### Por que hoy NO se puede calcular [HECHO, y es el nudo real]

Volcada la tabla `$9BBD` de la v157, los 9 tiles del bocadillo son:

```
fila 0-1:  $69B0  $69F0  $6870
fila 2-3:  $6A30  $6A70  $68F0
fila 4-5:  $6AB0  $6AF0  $6970

vertical:   +$80 constante        -> lineal
horizontal: +$40, luego -$180     -> NO lineal
```

Los tres tiles de cada fila son de **grupos distintos** del bocadillo
vertical original y no estan contiguos en VRAM. Por eso hace falta la tabla.

Un 20x4 necesita **10 tiles de ancho x 2 de alto = 20 tiles contiguos**.

### Diseno resultante (coherente, pendiente de construir)

1. reubicar el CG del bocadillo a un bloque **contiguo** de 20 tiles en VRAM
   (hay 31 celdas de 16x16 libres, sobra sitio);
2. con eso el destino se calcula: `base + fila*$80 + (col/2)*$40`, y las dos
   tablas (240 B) desaparecen;
3. escribir cada caracter en el momento en `$9883` -> el buffer de RAM deja
   de existir y **el problema de los 80 B se disuelve**;
4. ajustar los tres contadores: `$987D` a 20, `$98AF` a 4, y eliminar
   `$9BB8`.

Con las tablas fuera, el presupuesto pasa de -66 B a +200 B de sobra.

---

## (159) El 20x4 cabe: la tabla de 240 B se reduce a 20 y los sprites salen

### La formula que elimina las tablas [HECHO, validada contra la v157]

Las dos tablas del motor (`$9BBD` destino, `$9C05` cuadrante) son
redundantes. Verificado recorriendo las 36 entradas reales de la v157:

```
cuadrante = (fila & 1) * 2 + (col & 1)              exacto en las 36
destino   = colbase[col // 2] + (fila // 2) * $80   exacto en las 36
colbase de la v157 = [$69B0, $69F0, $6870]
```

`tools/geom_v158.py` lo comprueba con `assert`; si algun dia falla, salta.

Para 20x4 eso deja la tabla en **10 entradas de 2 B = 20 B**, frente a los
240 B de las dos tablas actuales. **Ahorro de 220 B**, y el presupuesto del
banco `$20` pasa de -66 B a sobrar de largo.

### La contigüidad SI importa, pero no donde yo creia

Me equivoque al decir que hacian falta «20 tiles contiguos». Lo que exige
contigüidad **no es la formula, es el SPRITE**: un sprite de 32x32 muestra 4
celdas consecutivas de VRAM alineadas a 4.

Medido en el state, el relleno actual ya lo hace asi:

```
ranura 19: pat $0350, celda 1A8, 32x32 px  -> celdas 1A8,1A9,1AA,1AB
ranura 20: pat $034C, celda 1A6, 32x16 px  -> celdas 1A6,1A7
```

### Inventario de VRAM y eleccion

Celdas disponibles (relleno del bocadillo viejo + libres): **42**.

```
bloques de 4 contiguas alineados a 4:  1A8 1C0 1C4 1CC 1D4 1EC  -> 6
pares contiguos alineados a 2:                                  -> 18
```

Un sprite de 32x32 cubre **4 caracteres de ancho x 4 lineas**, asi que para
20x4 hacen falta **5 sprites** y hay **6 bloques**. Cabe.

Presupuesto de sprites por scanline: 5 de texto + 2 laterales = 7 sprites y
192 px. El limite del PCE es 16 y 256. Holgado.

### Mapa final de las 80 celdas

```
          s0     s1     s2     s3     s4
linea 0  1A8:0  1C0:0  1C4:0  1CC:0  1D4:0
linea 1  1A8:2  1C0:2  1C4:2  1CC:2  1D4:2
linea 2  1AA:0  1C2:0  1C6:0  1CE:0  1D6:0
linea 3  1AA:2  1C2:2  1C6:2  1CE:2  1D6:2

celda = base[c//4] + (f//2)*2 + ((c%4)//2)
cuad  = (f&1)*2 + (c&1)
```

Con esto ya no hay ningun bloqueo pendiente de medida para el 20x4.

---

## (160) v158: la geometria 20x4, y un fallo de coherencia que pille a tiempo

`tools/build_v158.py` + `tools/geom_v158.py`.

### Lo aplicado y verificado byte a byte

```
ROM 4187D  CMP #$06 -> CMP #$14   caracteres por linea  (6 -> 20)
ROM 418AF  CMP #$03 -> CMP #$04   lineas por pagina     (3 -> 4)
ROM 41BBD  tabla de 10 columnas, 20 B en el hueco de 72
```

Cada parche lleva `assert` del byte esperado, y el constructor comprueba que
la fuente de dialogo, el guion y la tabla de punteros quedan intactos.

```
test_apaisado_v158.pce   MD5 7412b267e2cafa7c75f4cb7abed83432
                         22 bytes modificados
```

### El fallo que pille antes de entregar

Genere la primera version y al revisarla vi que **la tabla de columnas y el
reparto en sprites se habian disenado por separado y no casaban**:

```
columnas que salian:  1A6, 1A7, 1AF, 1CB ...
bases validas 32x32:  1A8, 1C0, 1C4, 1CC, 1D4  (alineadas a 4)
```

Cuatro de las diez columnas caian en celdas que **ningun sprite de 32x32
puede mostrar**, porque su base no esta alineada a 4. Habria dado un
bocadillo con trozos de texto invisibles.

Corregido: ahora las 10 columnas **se derivan** de los 5 bloques, que es la
restriccion dura. `columnas()` lleva un `assert` que lo garantiza.

```
col 0: 1A8/1AA -> $6A00     col 5: 1C5/1C7 -> $7140
col 1: 1A9/1AB -> $6A40     col 6: 1CC/1CE -> $7300
col 2: 1C0/1C2 -> $7000     col 7: 1CD/1CF -> $7340
col 3: 1C1/1C3 -> $7040     col 8: 1D4/1D6 -> $7500
col 4: 1C4/1C6 -> $7100     col 9: 1D5/1D7 -> $7540
```

**Norma: cuando dos calculos describen la misma cosa desde angulos
distintos, derivar uno del otro, no calcularlos por separado.**

> Nota: el bloque `1A8..1AB` tiene contenido en el state, pero es
> precisamente el relleno del bocadillo viejo que esta version sustituye.
> Los otros cuatro estan vacios.

### Lo que falta para que esto se vea en pantalla

La rutina de escritura inmediata: reescribir `$9883` (`STA $3667,X` ->
escribir la celda ya) y `$9863` (indice `col*12+pos+6` -> `fila*20+pos`).
Cabe en los mismos 18 bytes:

```
LDA $3657 / ASL / ASL        fila*4
STA tmp / ASL / ASL          fila*16
CLC / ADC tmp                fila*20
CLC / ADC $3658 / TAX        + posicion
```

**La v158 no se le pasa a David todavia**: sin esa rutina el motor sigue
volcando 36 celdas. Es un paso intermedio verificable, no una entrega.

---

## (161) v158 completa: la rutina de escritura inmediata, y un bug de salto que pille desensamblando

### Lo que faltaba, ahora hecho

`tools/rutina_v158.py` ensambla la rutina que sustituye al buffer. Va en
`$9B7C`, el hueco de 65 B que deja el bucle de volcado, mas la tabla de
cuadrantes que ya no hace falta (36 B): **101 B contiguos** para una rutina
de 97.

```
ROM 4187D  CMP #$06 -> CMP #$14      caracteres por linea
ROM 418AF  CMP #$03 -> CMP #$04      lineas por pagina
ROM 41863  indice: col*12+pos+6 -> fila*20+pos   (17 B + NOP, hueco de 18)
ROM 41B7C  rutina de escritura inmediata        (97 B)
ROM 41BDD  tabla de 10 columnas                 (20 B)
ROM 41883  STA $3667,X -> JSR $9B7C
ROM 41892  STA $3667,X -> JSR $9B7C
```

### La v158 intermedia HABRIA ROTO EL JUEGO [comprobado a tiempo]

Antes de generar el parche calcule el indice maximo con los contadores
nuevos pero el calculo viejo:

```
X = columna*12 + posicion + 6  con columna<=3 y posicion<=19
X maximo = 61  ->  STA $3667,X escribe hasta $36A4
el buffer acaba en $368A  ->  MACHACA 26 BYTES DE RAM EN USO
```

`$368B-$368F` son las **coordenadas del bocadillo** (X e Y del marco, con 20
punteros en 3 bancos). O sea que la version intermedia que estuve a punto de
pasarle a David habria corrompido la posicion del bocadillo. Aplicar solo
una parte de un cambio de geometria **no es un paso intermedio inofensivo**.

### El bug de salto

Desensamblada la rutina recien escrita (norma 7: desensamblar todo salto
hecho a mano), encontre esto:

```
$9BAF  BCC $9BBC     <- salta a INC $3664
```

Cuando NO hay acarreo no hay que sumar nada, asi que el salto tenia que ir a
`$9BBF` (`STZ $15`). Con el desplazamiento mal, la mitad de las lineas
habrian caido en la fila equivocada. Corregido a `BCC +14`.

### Verificacion

Simuladas **las 80 celdas una a una**, replicando la aritmetica de la rutina
byte a byte y comparandola con la geometria de `geom_v158.py`:

```
simulacion de las 80 celdas: TODAS CORRECTAS
```

```
test_apaisado_v158.pce  MD5 1e6171dae2393006bfae8f842ae1cdfd  135 B
parches/momotaro_apaisado_v158.ips  142 bloques, round-trip verificado
```

**Sigue faltando la prueba en pantalla**, que es lo unico que no se puede
medir desde aqui.

### Limpieza

Borradas 13 ROMs (v144-v155 y las de biseccion), 5 constructores obsoletos,
3 parches viejos y 17 capturas de trabajo. De 16 MB a 8,7 MB. Todo lo
borrado se puede regenerar con los constructores que quedan.
