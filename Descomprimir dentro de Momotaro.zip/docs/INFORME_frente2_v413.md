# Informe — Frente 2 (v413): estrechar bocadillo del abuelo + renombrar piedras

Estado: **análisis completado**, pendiente de cerrar el centrado del texto.

---

## 1. Codificación de «Piedra Solar»/«Piedra Glacial» — RESUELTO

La duda previa («los bytes ASCII `Gema` no pasan por `CHAR_TO_CODE`») quedó
resuelta: **el texto NO usa ASCII crudo**. Usa el `encode()` de
`tools/charset_oficial.py`:

- byte ≥ 0xA0 → glifo **directo** (minúsculas/tildes viven en 0xA1-0xDD)
- byte < 0xA0 → pasa por la tabla `0x43F9B` (mayúsculas, dígitos, signos)

Bytes reales en la ROM (verificados en la v410):

```
"Piedra" = 50 a9 a5 a4 b2 a1     (P=0x50 tabla, i/e/d/r/a = 0xA9/0xA5/0xA4/0xB2/0xA1 directos)
"Gema"   = 47 a5 ad a1          (G=0x47 tabla, e/m/a = 0xA5/0xAD/0xA1 directos)
```

`Gema` no lleva b/c/p, así que la sutileza de los alias (b/c/p → 0x5B/0x5D/0x5E)
**no aplica** aquí. (Ojo: la ROM usa 'c' **directo** 0xA3, p. ej. en «Glacial» =
`47 ac a1 a3 a9 a1 ac`, no el alias 0x5D — dato para el futuro, no afecta a «Gema».)

Los dos mensajes están en la tabla estática del abuelo:

| Índice | ROM | Contenido actual | Contenido nuevo |
|---|---|---|---|
| 5 | `0x48CDA` | `¡Ganas Piedra<3B>Solar!` | `¡Ganas Gema<3B>Solar!` |
| 6 | `0x48CEF` | `¡Ganas Piedra<3B>Glacial!` | `¡Ganas Gema<3B>Glacial!` |

`0x3B` = salto de línea del motor de bocadillo; `0x00` = terminador.

Longitudes: «Piedra» (6 B) → «Gema» (4 B) = **−2 B por mensaje, −4 B en total**.

---

## 2. Estructura de los 23 mensajes

- **Tabla de punteros** `$C969` (ROM `0x16969`), 23 punteros de 2 B LE,
  indexados por `$363E` (el ítem). El lector es `$C8DB` (ROM `0x168DB`):
  `LDA $363E / ASL A / TAY / LDA $C969,Y / STA $92 / LDA $C96A,Y / STA $93 / RTS`.
- Los textos son cadenas **empaquetadas** terminadas en `0x00`, en
  `0x48C7E`…`0x48E29` (doble `00 00` al final, y en `0x48E2A` empieza ya el
  diálogo «¡Oh!…»).

Al acortar los mensajes 5 y 6 (−4 B en total), **todos los mensajes 7…22 se
desplazan −4 B**. Hay que repuntar 17 punteros de la tabla `0x16969`
(el 6 baja −2, los 7…22 bajan −4). El diálogo de `0x48E2A` **no se mueve**.

No hay espacio libre en el banco `$24` (0 huelgos ≥ 16 B), así que no cabe la
alternativa «escribir en hueco y cambiar 2 punteros»; hay que desplazar.

---

## 3. Lista de sprites del bocadillo del abuelo

Elegida por `$368F=2` vía la tabla de punteros `0x47C99` → `$7CA1`
(ROM `0x47CA1`). Formato de cada registro (**5 B**):

```
[celda_delta][0x0F][flip 0x00/0x08][dX con signo][dY con signo]   terminador $FF
```

`celda = 0x170 + celda_delta`. dX/dY van **con signo** (dos complementos).

Geometría actual (18 sprites): 2 filas × **7 celdas centrales** (celdas
`0x1C4-0x1CA` / `0x1D4-0x1DA`, dX = −48…+48) + 2 laterales (`0x1DC`/`0x1DD`,
dX = ±56, sobresalen 8 px) = **128 px**, centrada en dX=0.

Geometría nueva (16 sprites): 2 filas × **6 celdas centrales** (celdas
`0x1C4-0x1C9` / `0x1D4-0x1D9`) + laterales = **112 px**. Se eliminan las
celdas `0x1CA` y `0x1DA`.

**Desplazamiento +8 px (tras la prueba de David):** todos los dX llevan **+8**
para alinear el bocadillo con el rabillo: centrales dX = −32…+48, laterales
dX = −40 / +56. El texto va horneado dentro de las celdas, así que se mueve
con ellas; no hay cambio aparte para el texto.

El bloque de 90 B se mantiene del mismo tamaño: 16 sprites (80 B) + `$FF` +
9 B de relleno `$FF`, de modo que la terminador queda en `0x47CF1` y **lo que
viene después (`0x47CFC`, datos del rabillo) NO se mueve**.

---

## 4. Centrado del texto — aparentemente OK tras la prueba

Los mensajes se guardan **sin relleno** («¡Ganas Gema» = 11 chars), así que el
centrado se hace **en tiempo de ejecución** sobre el ancho del bocadillo.
David probó la v413 y el texto quedó bien («está mucho mejor»); sólo pidió el
desplazamiento +8 px para alinear con el rabillo (ya aplicado). Queda por
confirmar en pantalla que ningún mensaje largo («El perro va contigo.», 10+8
chars) se descuadre al estrechar de 7 a 6 celdas.

---

## 5. PENDIENTE — estados de referencia desactualizados

Los 6 estados de referencia (`2_abuelo.state`, `3_Abuelo final minijuego 1.state`,
etc.) muestran el bocadillo con celdas **`0x19C-0x1AF`** (marco antiguo del
aldeano), NO las celdas `0x1C4-0x1DD` del bocadillo del abuelo actual (vía
`$368F=2`). Son de una versión **anterior a la v126-v128** (cuando se creó la
lista propia del abuelo). **No sirven para verificar el cambio**; hacen falta
estados nuevos capturados con la ROM actual.
