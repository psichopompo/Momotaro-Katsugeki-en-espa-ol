# INFORME DE TRASPASO — Momotarou Katsugeki en castellano

**Fecha:** 2026-08-31 · **Estado:** **v410 = ROM actual de trabajo** (parpadeo del
selector MUY DIFÍCIL arreglado y menú SELECT intacto, confirmado por David).

Este informe cubre **de la v406 a la v410**: la base v406 (rótulo del selector),
la **v407 retirada por David**, la **v408 retirada** (JSR que rompe el bucle),
la **v409 retirada** (stub que pisa el terminador del menú) y la **v410**
(definitiva). Sustituye a `INFORME_TRASPASO_v405.md`.

Si retomas sin contexto: lee esto entero, después `docs/PENDIENTES.md`
(registro único de tareas) y `LEEME.md` (normas 12-394).

---

## 1. El proyecto (sin cambios)

Traducción al castellano de **Momotarou Katsugeki** (PC Engine, 512 KB, HuCard).

- **Dirige: David** (*Psicopompo*, elotrolado.net).
- Repo: `https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol`
- ROM base virgen: `roms/Momotarou Katsugeki (Japan).pce` — **INTOCABLE**,
  MD5 `ec7358edb3672a8aa8850623eec72a71`.

### La ROM actual

```
roms/momotaro_es_v410.pce
MD5    f9fbbe70ba0e46e2b746e59fdc730c86
SHA-1  8611f1442e1aef437abf25eab9d9df2513d393a5
CRC32  E5866D47            524.288 B
```

Parche: `parches/momotaro_v410.ips` (delta **v406 → v410**, 49 B). El parche
completo contra la virgen es `parches/momotaro_v406.ips` (49.730 B).

### Cadena de versiones de esta tanda

```
v405 (vítores) ──► v406 (rótulo selector) ──► v407 (RETIRADA por David)
        ──► v408 (RETIRADA, JSR) ──► v409 (RETIRADA, terminador) ──► v410 (actual)
```

`roms/momotaro_es_v406.pce` es la base. Las ROM **v408** y **v409** ya **no
existen** (borradas); la **v407** no llegó a conservarse (retirada en el acto).

---

## 2. Cómo tratar con David (sin cambios)

El detalle completo está en `docs/historico/INFORME_TRASPASO_v401.md`, sección 2.
Lo esencial:

- **Siempre en castellano.** Tutear.
- Reconocer los errores propios **explícitamente**.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- **Una sola pregunta por mensaje**, al final, con `¿` de apertura.
- Capturas individuales, nunca rejillas.
- **Si David contradice el análisis, comprobarlo antes de descartarlo: ha
  tenido razón SIEMPRE.**
- **«Recuerda revisar el log. Tiene que haber información útil.»**
- **La verdad es lo que se ve en pantalla, no el hex.**
- **NUNCA partir una palabra.** **No se puede recortar texto: tiene que caber.**
- **No dejemos cosas a medias.**
- **No se genera ROM hasta ver capturas de cómo quedan los cambios.**
- **Comprender antes que modificar; prohibido escribir bytes a ciegas.**
- **No reutilizar números de versión** ni scripts retirados (norma de esta tanda).

---

## 3. Qué se ha hecho de la v406 a la v410

| Ver | Estado | Qué |
|---|---|---|
| v406 | base | rótulo del selector: «MUY DIFÍCIL» completo (ya no «MUY DIF») |
| v407 | **RETIRADA** | primer intento del parpadeo (lo retira David, no se conserva) |
| v408 | **RETIRADA** | parpadeo con `JSR $DFDC + NOP` → rompe el punto de retorno del bucle |
| v409 | **RETIRADA** | parpadeo con stub en `0x1BFDC` → pisa el terminador `$FF` del menú SELECT |
| v410 | **actual** | parpadeo con stub en `0x1BFE0` (después del terminador) — correcto |

---

## 4. La v406 — base correcta (rótulo del selector)

Cierra la primera mitad del pendiente del selector de dificultad (§6 del
informe v405): **«MUY DIFÍCIL» (11 glifos = 6 celdas) se cortaba a «MUY DIF»**.
Se reorganizan los registros de la lista del rótulo del selector (24 bytes en
`0x1FBB5–0x1FBDA`, lógico `$DBB5–$DBDA`, banco `$0D`), liberando la cola
(`0x1FBD1–0x1FBDA` a `$FF`), para que el rótulo largo quepa entero.

> Nota: no se conserva `tools/build_v406.py`; el cambio está documentado por el
> delta byte a byte `v405 → v406` (24 bytes, todos en esa lista). La v406 es la
> base sobre la que se aplican v408/v409/v410.

```
roms/momotaro_es_v406.pce
MD5    516c3fe8b53ed84369c2fd4fe0808b5f
SHA-1  12d1e34b873a8fe1337f3de5bec908bdfbae3a04
CRC32  A640D1FB
```

---

## 5. La v407 — retirada por David

Primer intento del segundo problema del selector: el **parpadeo «a medias»**.
David la retiró en el acto y **no se conserva** ni script ni ROM. Queda
registrada solo como «v407 retirada por David» en las cabeceras de v408/v409/v410
y, por la norma de esta tanda, **ese número no se reutiliza**.

---

## 6. La v408 — retirada (el `JSR` rompe el bucle)

### El problema a resolver (común a v408/v409/v410)

El parpadeo de confirmación del selector de DIFICULTAD es un rectángulo que
dibuja la rutina `$DC90` (ROM `0x1BC90`, banco `$0D`). Su bucle escribe
`7 − Y_inicial` celdas de la CG empezando por la celda base de la tabla `$C5A2`.
Con `LDY #$03` cubre **4 celdas** = «MUY DIFÍ»; el «CIL» final de «MUY DIFÍCIL»
(6 celdas) queda fuera. Es el mismo mecanismo del CANTO DE JIZO de hace un mes
(`$C633` y su copia `$DC90`).

Medido barriendo `Y_inicial = 0..6` (parcheando el LDY y mirando el parpadeo en
pantalla): **`Y_init=1` cubre 6 celdas = «MUY DIFÍCIL» completo**; `Y_init=3`
cubre 4 (el bug). DIFÍCIL/NORMAL/FÁCIL necesitan 4, así que la altura 6 **solo**
cuando el modo es MUY DIFÍCIL.

Codificación del modo (medida con los states de David):
`$3C84` = fila del cursor (0=arriba); `$3C88` = scroll (1 = vista alta).
MUY DIFÍCIL solo es visible con `$3C88=1` y en la fila 0.

### El error de la v408 [ERROR PROPIO]

Sustituí `A0 03 A9 00` (en `0x1BCB1`) por `20 DC DF EA` (JSR `$DFDC` + NOP),
**dentro** de `$DC90`. Pero el bucle de `$DC90` salta hacia atrás con
`BCC $DCB3` al `LDA #$00` que está en `$DCB3–$DCB4`. Al pisar ese byte con el
operando `$DF` del JSR, la **2.ª iteración saltaba a `$DF` y ejecutaba basura**:
el parpadeo salía en una zona equivocada y David la vio peor.

**Regla resultante:** no se puede meter un `JSR` ahí — rompe el punto de retorno
del bucle. (Ya recogida en PENDIENTES / normas.)

---

## 7. La v409 — retirada (el stub pisa el terminador del menú)

### El error de la v409 [ERROR PROPIO]

Segundo intento, esta vez **sin JSR**: el call site del modo DIFICULTAD
(`0x1A607`, `JMP $DC90`) salta a un stub nuevo `JMP $DFDC`; el `LDY #$03`
interno de `$DC90` pasa a `NOP NOP`; y el stub se puso en el espacio libre
`0x1BFDC` (lógico `$DFDC`).

Pero `0x1BFDC` es el **terminador `$FF`** de la lista de registros del **menú
SELECT** (`$DF41..$DFDB`). La rutina lectora `$DEF6` (ROM `0x1BEF6`) recorre esa
lista leyendo 5 bytes por registro hasta encontrar `$FF`. Al pisar el terminador
con el stub, siguió leyendo el código del stub como tiles y dibujó **dos líneas
corruptas** (fragmentos «NICA»/«ORO» + tiles blancos y ruido) que vio David.

**Regla resultante:** el espacio libre del banco `$0D` empieza **después** del
terminador `$FF` de `0x1BFDC`; nunca antes.

---

## 8. La v410 — la definitiva

Mismo enfoque que la v409, pero con el stub **después** del terminador:

1. Call site del modo DIFICULTAD (ROM `0x1A607`, `JMP $DC90`) → `JMP $DFE0`.
2. `LDY #$03` interno de `$DC90` (ROM `0x1BCB1`) → `NOP NOP` (el Y lo fija el stub).
3. Stub en `0x1BFE0` (lógico `$DFE0`, **después** del terminador `$FF` de `0x1BFDC`):

```
AD 84 3C   LDA $3C84        ; fila del cursor
D0 0C      BNE +$0C         ; no es fila 0 -> Y=3 (resto)
AD 88 3C   LDA $3C88        ; scroll
C9 01      CMP #$01
D0 05      BNE +$05         ; no es vista alta -> Y=3
A0 01      LDY #$01         ; MUY DIFÍCIL -> 6 celdas
4C 90 DC   JMP $DC90
A0 03      LDY #$03         ; resto -> 4 celdas (comportamiento original)
4C 90 DC   JMP $DC90
```

**No se toca:** `$C633` (CANTO DE JIZO), `$DC90` salvo el `LDY`, las tablas
`$C5A2/$C5A8/$C5AE`, la lista del selector de la v406, ni la lista del menú
(`$DF41..$DFDB`) con su terminador `$FF` en `0x1BFDC`. El script
`tools/build_v410.py` lleva asserts de cada zona intacta.

---

## 9. Verificación [HECHO]

Todo comparado contra la v406 (la base correcta):

| Prueba | Resultado |
|---|---|
| Parpadeo MUY DIFÍCIL vs `LDY #$01` (24 frames) | **0 px** de diferencia |
| Menú SELECT completo vs v406 | **0 px** |
| Selector estático vs v406 | **0 px** |
| Rutas `$3C84=1` y `$3C88=0` → `LDY #$03` | 1 hit cada una (las 2 rutas del stub OK) |

David confirmó la v410 en pantalla: parpadeo correcto **y** menú SELECT sin
líneas corruptas.

---

## 10. LO QUE TOCA AHORA

1. **A-GRAF** (en curso) — los 7 gráficos con texto que edita David:
   baños «oni no yu», bienvenida («youkoso»), cartel GOAL, posada
   «tomaru/yameru», rótulo «deguchi», «Banzai! Studio», «medetashi medetashi».
   Nuestro trabajo: **localizarlos, extraerlos a PNG y reinsertarlos** (nunca
   editar píxeles). States ya recibidos; los dos de medetashi son
   `states/Medetashi Dificil.state` y `states/Medetashi Muy dificil.state`.
2. **Vítor cha-chá (bloque 13 vs 12)** — pendiente que pidió David (ver
   INFORME_TRASPASO_v405 §5).
3. **Validar en pantalla** los 9 textos de la v403 + la decisión del T-OGRO.
4. **A-SPR** — mutilaciones por exceso de sprites por línea.
5. Resto de pendientes menores (ver `docs/PENDIENTES.md`).

---

## 11. El workspace

```
Momotaro/
  LEEME.md                   normas 12-394 + estado
  investigation.md           diario (298 entradas)
  docs/
    PENDIENTES.md            registro único de tareas
    INFORME_TRASPASO_v410.md (este fichero)
    INFORME_TRASPASO_v405.md (etapa anterior)
    historico/               informes de etapas cerradas
  roms/
    Momotarou Katsugeki (Japan).pce   virgen (INTOCABLE)
    momotaro_es_v406.pce              base correcta
    momotaro_es_v410.pce              actual
    momotaro_es_v405.pce / v402.pce / v403.pce / …   hitos
  parches/
    momotaro_v406.ips                 completo (contra la virgen)
    momotaro_v410.ips                 delta v406→v410
  states/                    savestates de David (incl. los 2 de medetashi)
  capturas/                  PNG de validación + recortes A-GRAF
  tools/                     build_v40x.py, pce.py, estados.py, sat.py, ips.py…
```

### Herramientas clave

- `tools/pce.py` — arnés de emulación (Beetle PCE/libretro) con trace.
- `tools/estados.py` — carga savestates RZIP de David.
- `tools/state.py` — vuelca secciones de un savestate (VRAM, SAT, BaseRAM, MWR…).
- `tools/sat.py` — lee la SAT y la VRAM.
- `tools/ips.py` — genera/reaplica parches IPS.
- `tools/render_sprites.py` / `render_bg.py` — renderizado.

### Lo que más ha costado en esta tanda, en una frase

Dos reglas que no estaban escritas y que ahora lo están: **(1)** no meter un
`JSR` dentro de un bucle que retrocede a una instrucción contigua (rompe el
punto de retorno); **(2)** el espacio libre del banco `$0D` empieza *después*
del terminador `$FF` de la lista del menú (`0x1BFDC`), no antes.
