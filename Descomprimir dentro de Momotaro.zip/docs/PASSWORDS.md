# Passwords secretos — Momotaro Katsugeki en castellano

Versión **v424** · MD5 `dd87ce15a3a279a53af140cfcc1e559b`

Se introducen en la pantalla **«¡Introduce el canto de Jizo!»**
(menú del título → CANTO DE JIZO → CARGAR).

> **Todo en MAYÚSCULAS y sin espacios.**
> La opción ESPACIO del menú lateral sólo se puede usar *entre* caracteres ya
> escritos, nunca al final de una palabra, así que las contraseñas van con las
> palabras pegadas.

---

## Los 8 passwords

| # | Password | Qué desbloquea |
|---|---|---|
| 1 | `IWASAKICANTAMAL` | **Sala de Sonido** (Sound Test) |
| 2 | `IWASAKIDIBUJAMAL` | **Galería de Arte** (Graphics Test) |
| 3 | `PIEDRAPAPELTIJERA` | **Minijuego oculto** de piedra, papel o tijera |
| 4 | `MOMOTAROERAFUERTE` | **Intro del título** |
| 5 | `AMUKASARIKA` | **Final Fácil** |
| 6 | `OKIHCIMATIHSOY` | **Final Normal** |
| 7 | `IKUYAKATIOT` | **Final Difícil** |
| 8 | `IJUOYIHSATUSAM` | **Final Muy Difícil** |

---

## De dónde sale cada uno

Los cuatro primeros son la **traducción** de las frases que pusieron los
programadores; los cuatro finales conservan la broma original: son **nombres
del equipo escritos al revés**.

| Password | Original japonés | Significado |
|---|---|---|
| `IWASAKICANTAMAL` | *iwasaki wa uta ga heta* | «Iwasaki canta mal» |
| `IWASAKIDIBUJAMAL` | *iwasaki wa e ga heta* | «Iwasaki dibuja mal» |
| `PIEDRAPAPELTIJERA` | *acchi muite hoi hoi* | el juego del minijuego |
| `MOMOTAROERAFUERTE` | *momotarou wa tsuyokatta* | «Momotaro era fuerte» |

| Password | Al revés | Miembro del equipo |
|---|---|---|
| `AMUKASARIKA` | AKIRASAKUMA | **Akira Sakuma** |
| `OKIHCIMATIHSOY` | YOSHITAMICHIKO | **Yoshita Michiko** |
| `IKUYAKATIOT` | TOITAKAYUKI | **Toita Kayuki** |
| `IJUOYIHSATUSAM` | MASUTASHIYOUJI | **Masuta Shiyouji** |

---

## Notas

- Los passwords **japoneses originales ya no funcionan** (`rGAPad`,
  `AKJRBLOBOB`, `BqdGlCIWÑI`…). Comprobado: se rechazan.
- La parrilla de entrada tiene 64 caracteres: `A-Z` + `Ñ`, `a-z` + `ñ`, y `0-9`.
  **No hay espacio.**
- Verificación: las 8 frases devuelven su índice correcto en `$3CD7`
  (1..8, en orden) y las contraseñas falsas devuelven 0.

---

## Dónde están en la ROM

```
tabla de 8 punteros    0x1AFC5   (direcciones CPU, banco $0D)
las 8 cadenas          0x1F61C = CPU $561C   (banco $0F)
                       123 de 273 bytes usados
comparador             $CFAD    LDA ($14),Y / CMP $3C94,Y
```
