# A-GRAF — hallazgos técnicos de extracción/reinserción (GOAL→Meta)

Estado a 2026-09-01, trabajando sobre la **v410** (`roms/momotaro_es_v410.pce`).

## Formato de los gráficos de fondo (BG) — confirmado

- La VRAM del PCE: 64 KB = 32768 words (leída con `<u2` little-endian).
- **BAT** (mapa de fondo) en **word 0**, tamaño 64×64 (4096 words, 0x0000–0x0FFF).
  Cada entrada = 16 bits: bits 0-11 = código de carácter (char), bits 12-15 = paleta.
- **CG** (tiles 8×8, 4bpp) en **word 0x1000** (byte 0x2000). Char `ch` =
  word `0x1000 + ch*16` (16 words = 32 bytes).
- Tile 8×8 = 16 words, 4 planos: words `base+0..7` = planos 0 (byte bajo) y 1
  (byte alto); words `base+8..15` = planos 2 y 3. El índice de color =
  bit0(plano0)+bit1(plano1)+bit2(plano2)+bit3(plano3).
- **Color VCE 9 bits** `GGGRRRBBB`. Expansión a RGB888 (la del core):
  `r5=(r<<2)|(r>>1); r8=(r5<<3)|(r5>>2)`, `g6=(g<<3)|g; g8=(g6<<2)|(g6>>4)`,
  `b5=(b<<2)|(b>>1); b8=(b5<<3)|(b5>>2)`. (NO es `v*36`.)
- Compresión del CG: rutina `$C1CC/$C206` → `tools/descomp_cg.py`
  (`descomprime`/`comprime`). Formato por tile: 4 planos (offsets 0,1,16,17),
  cada uno = 1 byte de máscara (8 bits) + literales (1 byte por bit=1).

## El minijuego (GOAL) — localizado Y REINSERTADO (v411)

- El cartel GOAL son los chars **0xAE–0xB5** (8 chars, 4×2 tiles = 32×16 px).
  Confirmado por coincidencia EXACTA de píxeles con el frame (4 tiles exactos,
  4 al 100% en píxeles no transparentes).
- Están en ROM **0x60000** (bloque comprimido chars 0x00–0xFF, 256 tiles,
  rutina $C1CC/$C206). Round-trip verificado.
- Reinserción a «META»: **HECHA en v411** (`build_v411.py`). Probado parcheando
  la VRAM del state y re-renderizando: el cartel pasa de «ゴール» a «META».
- Colores (paleta 0): naranja 0x0F1 (idx 1), marrón 0x0A0 (idx 2),
  brillo 0x13A (idx 3), oscuro 0x049 (idx 7), transparente idx 0.

### El CG del escenario del minijuego (para referencia)

- chars 0x100–0x1BF en ROM 0x69430 (192 tiles). Es el ESCENARIO (suelo,
  escaleras, damero), NO el cartel:
  - chars 0x100–0x10F → ROM 0x69430
  - chars 0x110–0x11F → ROM 0x69533  ← glifos katakana (texto común)
  - chars 0x199–0x19F → ROM 0x69E79

## Colores del cartel en `color_table` (paleta 0)

| idx | 9-bit | RGB | uso |
|---|---|---|---|
| 1 | 0x0F1 | (222,109,33) | naranja (cuerpo) |
| 2 | 0x0A0 | (148,73,0) | marrón (borde) |
| 3 | 0x13A | (255,146,74) | brillo |
| 7 | 0x049 | (33,36,33) | oscuro (texto) |

El naranja 0x0F1 **solo existe en paleta 0** (índice 1 de todo el color_table),
así que el cartel usa paleta de FONDO (no sprites).

## Misterio (no bloquea la reinserción)

Los chars 0xAE–0xB5 (el cartel) NO están referenciados por la BAT ni por la SAT
en el state Meta.state: se dibujan por un mecanismo aún sin trazar (probable
una escritura a la BAT o un sprite montado en el mismo frame al cruzar la meta).
PERO cambiar su CG cambia el cartel, así que la reinserción funciona igual.
Para trazar el mecanismo haría falta un state de justo ANTES de que aparezca el
cartel.

## Notas de método (para no repetir callejones)

- El core de **trace sí carga los states** (contra lo que decía el informe v405):
  `PCE(rom, trace=True)` + `carga()` funciona con Meta.state. `watch_write(0x0002)`
  captura escrituras al puerto de datos VDC.
- La VRAM del state == VRAM live (tras 3 frames) salvo ~30 words (sprites en
  0x5041–0x505C y SAT 0x7F14–0x7F1D). El cartel NO se redibuja en 3 frames.
- `BXR=0x300 (768)`, `BYR=0x108 (264)`; scroll en pixels, BAT 64×64 → sxt=768%512=256.
- `MWR=0x0050` → SCREEN=128×64 según el datasheet, pero el dato real es BAT 64×64;
  no fiarse del campo SCREEN.

## Los 7 gráficos y sus states

| # | gráfico | state | estado |
|---|---|---|---|
| T1 | baño «oni no yu» | Baño femenino.state | por reinsertar |
| T2 | bienvenida «youkoso» | Bienvenida jefe final.state | por reinsertar |
| T3 | cartel GOAL→META | Meta.state | **HECHO en v411** |
| T4 | posada tomaru/yameru | Posada 1000 Ç.state | por reinsertar |
| T5 | deguchi→salir | Salida tienda.state | por reinsertar |
| T6 | Banzai! Studio | Final Fácil/Normal.state | por reinsertar |
| T7 | medetashi | Medetashi Dificil/Muy dificil.state | por reinsertar |

Los PNG editados por David están en `/home/user/uploads/` (Baño, Bienvenido,
Colorín colorado, Estudio Banzai, Meta, Posada, Salir).

---

## REGRESIÓN v411 — causa raíz CONFIRMADA (2026-09-01)

### La hipótesis era correcta: el bloque 0x60000 es COMPARTIDO

- El bloque comprimido en **ROM 0x60000** (chars 0x00–0xFF, 256 tiles) lo cargan
  TANTO el minijuego (Meta.state) COMO las fases de acción (cayendo, 5_Ogros):
  comparación tile a tile de chars 0x00–0xFF de la VRAM de cada state contra el
  bloque descomprimido → **256/256 coinciden** en los tres.
- El cartel GOAL en pantalla es **chars 0xAE–0xB5** (verificado: render de esos
  chars con paleta 0 coincide 442/512 px con el frame; los chars 0x1AE–0x1B5
  del escenario solo 44/512).
- Por tanto, al sustituir 0xAE–0xB5 por META en v411, **las fases también ven
  META**: los chars 0xAE–0xB5 son de DOBLE USO (cartel GOAL en el minijuego +
  textura/terreno de fondo en las fases de acción). De ahí el amarillo.

### El cartel NO está en la BAT ni en la SAT (mecanismo sin trazar)

- Barrido de TODA la VRAM (32768 words) de Meta.state buscando patrón 0xAE–0xB5
  (cualquier paleta): 39 words, pero **todos** son (a) datos de píxel de los
  propios chars 0xAE–0xB5 en la zona CG, o (b) coincidencias en la SAT (p.ej.
  word 0x7F14 = Y de un sprite). **Ninguna entrada de BAT apunta a 0xAE–0xB5.**
- La SAT de Meta.state (8 sprites activos) tampoco usa celdas que mapeen a
  0xAE–0xB5 (sprites: cel 320, 196, 248×5, 249; ninguno → chars 0xAC–0xB7).
- La BAT SÍ referencia **0x1AE–0x1B5** (chars del escenario, bloque 0x69430) en
  la zona del cartel (filas 49–50, cols 56–59), pero esos chars son textura
  (índices 5,6,7), NO las letras GOAL. → El cartel (0xAE–0xB5) se dibuja por un
  mecanismo ajeno a BAT/SAT estáticas (escritura de BAT en runtime o similar).

### Consecuencia para la estrategia

- **NO se puede** cambiar el contenido de 0xAE–0xB5 en el bloque compartido
  (rompe las fases). Hay que **separar** el cartel del terreno.
- Opciones (por evaluar, en orden de limpieza):
  1. **Reubicar el META a chars libres del escenario del minijuego** (bloque
     0x69430, minijuego-específico) y repuntar el mecanismo del cartel a esos
     chars. Requiere localizar el mecanismo que dibuja el cartel.
  2. **Duplicar el bloque 0x60000**: copia con META en 0xAE–0xB5 en ROM libre y
     repuntar SOLO el cargador del minijuego. Requiere localizar el cargador.
  3. **Parche en runtime** al cargar el tile set del minijuego.
- **Bloqueo para 1/2/3**: hace falta localizar el cargador/mecanismo. Los
  cargadores están en banco 0 ($118D = descomprime 256 tiles → es el del bloque
  0x60000; $11A1 = descomprime N tiles). **No hay JSR directo a ellos** (0 refs
  "20 8D 11"/"20 A1 11"), ni punteros 16-bit limpios (los "refs" encontrados son
  falsos positivos: "8D 11" dentro de `STA $3811`, etc.). Se llaman por
  trampolín/computado aún no localizado.
- **Para trazar** se necesita un state de JUSTO ANTES de que aparezca el cartel
  (o de entrar al minijuego), para capturar con el núcleo de trace quién escribe
  los chars 0xAE–0xB5 / el cargador. Meta.state ya tiene el cartel dibujado y no
  se redibuja.

### Verificación adicional (descartado)

- El relleno de 8 bytes al final del bloque (v411: descompresión acaba en
  0x610AE + 8 B de relleno hasta 0x610B6) es inocuo: 0x610B6 en adelante es
  IDÉNTICO entre v410 y v411; solo difieren los tiles 0xAE–0xB5. El problema es
  el contenido, no el formato.

---

## MECANISMO DEL CARTEL RESUELTO — el cartel SÍ está en la BAT (2026-09-02)

### El cartel se dibuja por la BAT (no es un mecanismo misterioso)

Prueba empírica (blanking por capas sobre la VRAM serializada):
- Poner la BAT entera en blanco → **el cartel desaparece** (0 px naranja).
- Poner la SAT en blanco → el cartel sigue (203 px naranja).

→ El cartel es **fondo (BAT)**, no sprite.

### Corrección CRÍTICA del layout de VRAM (esto explica TODO)

- **La base del CG es word 0x0000 (byte 0x0000), NO 0x1000/0x2000.**
  char N → byte `N*32`. Verificado: el tile GOAL está EXACTO en byte 0x35C0
  (word 0x1AE0 = char 0x1AE), y la entrada BAT 0x01AE renderiza justo ese tile.
- El **campo de char de la BAT es 12 bits** (bits 0-11), paleta bits 12-15.
  La entrada del cartel `0x01AE` = char **0x1AE** (NO 0xAE), paleta 0.
- La BAT (word 0x0000-0x0FFF) solapa con chars 0x000-0x0FF, así que el juego
  usa chars **0x100+** para el fondo.
- **El bloque 0x60000 (256 tiles) se carga a VRAM word 0x1000**, o sea:
  - bloque char 0x00 → BG char 0x100
  - bloque char 0xAE → BG char **0x1AE**
- Por tanto, el cartel GOAL = **chars 0x1AE-0x1B5** (bloque chars 0xAE-0xB5).

### El cartel GOAL está en la BAT de Meta.state

- Entradas BAT del cartel (rows 49-50, cols 56-59): `0x01AE 0x01AF 0x01B0 0x01B1`
  / `0x01B2 0x01B3 0x01B4 0x01B5` = chars 0x1AE-0x1B5, paleta 0.
- Esto corrige el error previo de leer la BAT con char de 8 bits y base 0x2000
  (que daba la ilusión de "0 refs" y del "mecanismo misterioso").

### Alcance REAL del problema (más amplio de lo pensado)

Los chars 0x1AE-0x1B5 (tiles "GOAL") se usan en VARIAS escenas, no solo el
minijuego. Estados cuya BAT referencia 0x1AE-0x1B5 **y** cargan el bloque 0x60000:

| estado | uso |
|---|---|
| Meta, 3_Abuelo final minijuego | cartel GOAL (INTENCIONADO → META) |
| 2_abuelo, 3_Mensaje, 4_flecha azul | tutorial del abuelo (muestra el cartel) |
| Final Fácil/Normal | escena final (por confirmar contenido) |
| Japón cha-cha, japonesa, nuestra, mapa_kachiyama | por confirmar |
| cayendo, 5_Ogros | **cargan** el bloque pero NO lo muestran en BAT |

- select_v308/v309 e issunboshi referencian 0x1AE-0x1B5 en BAT pero cargan
  **OTRO contenido** (0/8 coinciden con bloque 0x60000) → NO afectados.
- **Los states NO recargan tiles**: cargar un .state con v411 NO cambia la VRAM
  (sigue GOAL). Por eso no se reproduce la corrupción desde states; hace falta
  **bootear** el juego y llegar a la fase (o el state de la fase exacta de David).

### Consecuencia para la estrategia

- NO basta con reubicar dentro del bloque compartido: los chars 0x1AE-0x1B5 se
  cargan desde 0x60000 en minijuego, acción y tutorial del abuelo.
- **Fix limpio**: localizar el cargador (o el código que escribe las 8 entradas
  0x01AE-0x01B5 de la BAT) y:
  1. duplicar el bloque 0x60000 con META en chars 0xAE-0xB5 → repuntar SOLO el
     cargador del minijuego, o
  2. meter META en 8 chars libres y repuntar SOLO las entradas BAT del cartel.
- Pista para localizar el cargador: `$C1CC/$C206` (descompresor), loaders
  `$118D` (256 tiles) y `$11A1` (N tiles) en banco 0; `$C206` se ejecuta 1024×
  en el boot pero `$C1CC` NO, así que hay OTRO cargador que llama `$C206`
  directamente (4× por tile). Falta localizarlo (trace del boot con el watch en
  `$C206` y capturar el caller).

---

## Correcciones y avances (2026-09-02, 2ª ronda)

### El state "Artefactos amarillos" es el MISMO que el anterior (minijuego)

- `Artefactos amarillos.state` y `Momotarou Katsugeki (Japan).state` son
  **idénticos byte a byte** (MD5 `c97cd7675571c783ed4268026440bdd8`, 20353 B).
  David re-subió el mismo fichero; NO es la primera fase.
- El state es el **minijuego** (pista de correr: cielo azul-violeta, cartel
  blanco central, suelo damero naranja/marrón), **capturado con v411**:
  chars 0x1AE–0x1B5 = META (8/8 coinciden con bloque v411).
- NO muestra amarillo: la paleta 0 del minijuego es naranja, no amarilla. El
  amarillo (246,252,74) es de la **primera fase** (paleta propia), que **no
  tengo en ningún state** (ningún color_table de mis states lo contiene).

### Doble uso CONFIRMADO dentro del propio minijuego

- Los chars 0x1AE–0x1B5 ("GOAL") aparecen como **tiles sueltos del suelo**
  (p.ej. en este state: BAT (50,25)=(0x1AE), (51,25)=(0x1AF), rodeados de
  0x199/0x19A/0x1AA/0x1A9 del damero) ADEMÁS del cartel 4×2 de la meta.
- O sea: el cartel GOAL NO tiene arte propio — está hecho con los mismos 8
  tiles que decoran el suelo. Cambiar esos 8 tiles en el bloque compartido
  rompe el suelo (fases → amarillo) Y decora el suelo del minijuego con letras.

### Corrección: el descompresor NO tiene "otro loader"

- `$C206` (plano) SOLO lo llama `$C1CC` (4× por tile). `$C1CC` lo llaman
  `$118D` (256 tiles) y `$C19C`. La nota anterior de "otro loader que llama
  $C206 directo" era un artefacto de medir el boot en ventanas de 600 frames
  desincronizadas (cada `watch()` reinicia el watchpoint). Descartada.
- `$118D`/`$11A1` se invocan por trampolín (sin JSR directo); los "refs 16-bit"
  eran falsos positivos (`STA $3811` = `8D 11 38`, `LDX $3B01` = `AE 01 3B`, …).

### El cartel NO está en una tabla literal de ROM

- No existe la secuencia `AE 01 … B5 01` (entradas BAT del cartel) ni en crudo
  ni RLE en la ROM. Las apariciones de `AE AF B0 B1` / `B2 B3 B4 B5` (0x41CC5,
  0x41D01/0x41D05) son una **tabla de códigos kana** (a1 a2 … a9 ab ad af b0
  b1 … b9 bb …), no el cartel.
- → El cartel se escribe **computado en runtime** (posición BAT + 0x1AE+i).
  Para localizar el código hace falta capturarlo EN VIVO en el momento de
  dibujarse (state de justo antes de la meta, o bootear y llegar).

### Conclusión de estrategia (sin cambios, pero más fundamentada)

- El arreglo limpio sigue siendo **separar el cartel del suelo**: redirigir las
  8 entradas BAT del cartel a 8 chars libres con el arte META, dejando
  0x1AE–0x1B5 como suelo original. Requiere localizar el código que escribe el
  cartel (runtime, computado).
- Pendiente de David: el state REAL de la primera fase (con amarillo) para
  confirmar la paleta y los chars exactos que se corrompen.

---

## Análisis de los states de David (2026-09-02, 3ª ronda)

### States recibidos

- `Artefactos fase 1.state` (MD5 8ef598a9…, 23635 B) — fase de acción real.
- `Minijuego antes meta.state` (MD5 d8b78d02…, 19766 B) — minijuego con el cartel
  ya dibujado en la BAT pero fuera de pantalla (BXR=664).

### «Artefactos fase 1» NO reproduce la corrupción

- chars 0x1AE–0x1B5 = META (8/8, estado capturado con v411), pero **0 refs en la
  BAT** (ni en sprites) → el cartel/terreno NO usa esos chars en esta vista.
- **Test decisivo**: render del estado tal cual (META) vs. con chars 0x1AE–0x1B5
  restaurados a GOAL → **0 píxeles de diferencia**.
- El amarillo de la fase (255,255,0 = 0x1F8, índices 8–14 de TODAS las paletas)
  lo producen los chars **0x28A–0x2B5** (terreno con detalle amarillo), que NO
  toqué. Es **idéntico en v410 y v411** (terreno legítimo).
- Las capturas de David (_001/_002, amarillo 246,252,74) parecen la MISMA escena
  con un filtro de vídeo de RetroArch (colores más oscuros); el amarillo es el
  terreno normal, no «META». → **La regresión que ve David no está en este state**
  (o es de otra fase, o de otro mecanismo). Pendiente de aclarar con David.

### El cartel se dibuja DINÁMICAMENTE (no al cargar el nivel)

- Comparación BAT «Artefactos amarillos» vs «Minijuego antes meta»: 899 entradas
  difieren. En la posición del cartel (49–50, 56–59), el primero tiene 0xF200/
  0xF100/… y el segundo 0x01AE–0x01B5. → el cartel se ESCRIBE en algún momento
  durante la partida (probable al acercarse a la meta).
- «Artefactos amarillos» no avanza con ningún botón (BXR=0, BAT inmóvil); no
  puedo alcanzar el momento del dibujo desde ese state.

### Búsqueda estática del código del cartel (sin éxito aún)

- No existe en ROM la secuencia `AE 01 … B5 01` (entradas BAT del cartel) ni en
  crudo ni RLE; la aparición de `AE AF B0 B1`/`B2 B3 B4 B5` es una tabla kana
  (0x41CC5/0x41D01).
- Tabla sospechosa en **0x7E440** (valores 16-bit que incluyen 0x01AE repetido:
  …0x019F, 0x01AE, 0x00A9, 0x01AE, 0x00A9, 0x01AE, 0x01BB, 0x01C8…), referida
  desde 0xAABA/0xAAE6/0xAB91/0xCFB3/0xD019/0x31C68. Puede ser una lista de
  códigos de tile o posiciones; sin confirmar si es el cartel.
- Pendiente: localizar el código que escribe 0x01AE–0x01B5 en la BAT. Requiere
  un state de JUSTO ANTES del dibujo (minijuego nada más empezar) o trazar el
  boot del minijuego.

### Alcance confirmado del doble uso de 0x1AE–0x1B5

BAT refs a 0x1AE–0x1B5 por estado: cartel 4×2 contiguo en minijuego (Meta,
3_Abuelo, Minijuego antes meta); decoración dispersa en 2_abuelo, 3_Mensaje,
4_flecha azul, Final Fácil/Normal, Japón cha-cha, issunboshi, mapa_kachiyama,
japonesa, nuestra, select_roto/v308/v309 (menús). Las fases (cayendo, 5_Ogros,
Artefactos fase 1) **no** los referencian.

---

## CAUSA RAÍZ DEFINITIVA (2026-09-02, 4ª ronda)

### Los tiles 0xAE–0xB5 son el GRÁFICO "ゴール" (GOAL), de doble uso

- Bloque 0x60000 tiles 0xAE–0xB5 → chars VRAM 0x1AE–0x1B5 = el rótulo **ゴール**
  (GOAL): ゴ(2×2) + ー(1×2) + ル(1×2) = 4 columnas × 2 filas = 32×16 px.
- NO es texto del motor de diálogo (no existe la cadena "ゴール" en ROM:
  `BA DE B0 D9` / `DE B0 D9` → 0 hits). Es un **gráfico precompuesto** en el
  bloque, dibujado por código con las 8 entradas BAT `0x01AE–0x01B5`.
- **Doble uso confirmado**: esos mismos 8 tiles aparecen como **decoración del
  suelo/pista** (sueltos, no en bloque 4×2) en el propio minijuego y en otras
  escenas (2_abuelo, 3_Mensaje, 4_flecha azul, Final Fácil/Normal, Japón
  cha-cha, issunboshi, mapa_kachiyama, menús select_v308/v309/roto).
- Por eso v411 (sustituir 0xAE–0xB5 por META) rompe TODOS esos usos: las fases
  y escenas que usan esos tiles como decoración muestran letras META en lugar
  de la textura original (en la fase 1, con su paleta, se ven como artefactos
  amarillos).

### Estado de la búsqueda del código que dibuja el cartel

- El cartel se escribe **dinámicamente** (en "Artefactos amarillos" la celda del
  cartel está a 0xF200; en "Minijuego antes meta" ya es 0x01AE). No se redibuja
  tras blanquearlo (600 f sin cambios) → se escribe UNA vez al cargar el nivel.
- No está en tabla literal (las 8 entradas no existen en ROM ni crudas ni RLE;
  la secuencia `AE AF B0 B1 B2 B3 B4 B5` de 0x41D01 es una tabla de glifos kana,
  no el cartel).
- Los valores se computan (base 0x1AE + offset en bucle). "LDA #$AE" aparece en
  20+ sitios; sin desambiguar cuál es el del cartel.
- Los states del minijuego no avanzan con ningún botón (BXR clavado a 0), así
  que no puedo capturar el instante del dibujo con el núcleo de trace.

### Huecos libres para el META (verificado)

- En Meta.state hay **222 chars del bloque 0x60000 (0x100–0x1FF) NO referenciados**
  por BAT ni SAT (p.ej. 0x101–0x1FF casi todos). El META (8 tiles) cabe en
  cualquiera de esos huecos; falta confirmar que el hueco elegido está libre en
  TODAS las escenas (no solo el minijuego).

### Plan de fix (sin cambios, ya ejecutable en cuanto localice el código)

1. Revertir tiles 0xAE–0xB5 del bloque 0x60000 a ゴール (deshacer v411).
2. Meter META en 8 chars libres (hay 222 candidatos).
3. Repuntar SOLO las 8 entradas BAT del cartel (base 0x1AE → char libre) en el
   código que las escribe. → Localizar ese código es el único bloqueo restante.

---

## CORRECCIÓN MAYOR — la causa real es el DESPLAZAMIENTO del flujo (2026-09-02, corrección de David)

### Lo que estaba mal en el diagnóstico previo (retractado)

1. **"8 tiles" era falso.** La v411 cambió 1194 bytes (0x60BCB–0x610B4): al
   recomprimir el bloque entero, la cadena secuencial se desplazó. 8 tiles
   serían 256 bytes; lo que hay es el flujo recomprimido de principio a fin.
2. **"Los tiles se reutilizan" era falso como causa.** El índice 0x1AE es una
   RANURA de VRAM, no un dibujo. Cada escena carga su propio contenido en las
   mismas ranuras (volcado del tile 0x1AE por escena):
   - Meta:          `00ff7faf7fc07fc0…`  (el GOAL)
   - fase 1:        `007f7faf7fc07fc0…`  (variante parecida, 14/32 B distintos)
   - issunboshi:    `06018d039a06d60e…`  (OTRO gráfico)
   - mapa_kachiyama:`06018d039a06d60e…`  (OTRO gráfico)
   - Final Normal:  `00ff00ff00ff00ff…`  (OTRO gráfico)
   Concluir "aparece en tal state" sin volcar el contenido fue el error.

### Causa real (verificada por medición propia)

- El bloque 0x60000 es una **cadena secuencial** de tiles comprimidos de
  longitud VARIABLE (no hay tabla de tamaños). El decodificador lee un tile
  tras otro.
- Mi `descomp_cg.comprime` es fiel (round-trip del bloque original idéntico),
  PERO al sustituir 0xAE–0xB5 por META cambiaron los tamaños comprimidos:

  | tile | v410 | v411 | Δ |
  |---|---|---|---|
  | 0xAE | 17 | 17 | 0 |
  | 0xAF | 18 | 15 | -3 |
  | 0xB0 | 14 | 15 | +1 |
  | 0xB1 | 19 | 23 | +4 |
  | 0xB2 | 16 | 16 | 0 |
  | 0xB3 | 19 | 20 | +1 |
  | 0xB4 | 25 | 17 | -8 |
  | 0xB5 | 24 | 21 | -3 |

  Neto **-8 bytes** → el tile 0xB6 y todos los siguientes se desplazaron -8
  bytes en el flujo (offset 0xB6: 3171 → 3163).
- Yo "compensé" añadiendo 8 bytes de relleno AL FINAL para conservar el tamaño
  total (4278) y el fin fijo 0x610B6. Eso NO corrige el desplazamiento interno:
  todo lo que el juego lee DESPUÉS de 0xAE sale de un offset equivocado →
  basura amarilla.

### REGLA PARA LA v412 (crítica, de David)

- **NO basta con que quepa / que el total no cambie.** Hay que **conservar el
  tamaño comprimido EXACTO de cada celda** (o respetar la estructura de offsets
  con la que el juego lee el bloque). Si al meter META una celda cambia de
  tamaño, el fallo se repite.
- El plan (revertir 0xAE–0xB5 → GOAL, meter META en tiles libres, repuntar solo
  el cartel) sigue siendo correcto, PERO la inserción de META debe hacerse SIN
  alterar el tamaño de ninguna celda del flujo.

### Estado

- El chat original está atacando el problema en paralelo. Yo quedo EN ESPERA
  hasta que David reparta tareas. No construir v412 todavía.
