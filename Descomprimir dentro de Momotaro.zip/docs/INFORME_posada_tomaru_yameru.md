# Informe — Rótulo de la posada «ALOJARSE / SALIR» (T-GRAF4)

Fecha: 2026-09-03. Base de trabajo: `roms/momotaro_es_v410.pce`,
`states/Posada 1000 Ç.state` y `uploads/Posada.PNG`.

ROM resultado: `roms/momotaro_es_v417.pce` (MD5 `d31db08ecb44f8b0f4255521daae9efc`),
reconstruida con `tools/build_v417b.py`.

> **Nota de color (09-03):** David quitó el rojo (222,0,0) del `Posada.png`
> y lo sustituyó por naranja (255,109,0) — 6 píxeles en la fila de acento
> inferior. La paleta resultante usa índices {9,10,11,15} (sin índice 8).
> La extracción se hace ahora con `tools/build_posada_celdas.py`, que genera
> los `.bin` por slot con las ventanas verificadas (130→x10, 131→x26,
> 12F→x42, 132→x82, 133→x98).

## Resumen ejecutivo

El rótulo de la posada NO es un gráfico de fondo (BG) como META/SALIR: es un
**rótulo de SPRITES (celdas 16×16)**. El texto original es katakana
«トマル / ヤメル» (tomaru / yameru). Se ha sustituido por el texto
**ALOJARSE** (panel izquierdo) y **SALIR** (panel derecho), manteniendo la
estructura de sprites del juego y **conservando el tamaño comprimido exacto
de cada celda** (relleno con ceros), de modo que la descompresión secuencial
del bloque no se desalinea.

## Composición final (5 celdas, sin celda nueva)

El rótulo son **dos paneles** de 48×32 px (teal `0x155`, paleta de sprite 26),
con el texto en la mitad inferior (16 px). Se dibuja con **9 entradas de SAT**
(4 fondo + 5 texto + 1 adorno).

| celda | contenido | panel |
|---|---|---|
| `0x128` | panel (teal + borde) | fondo, repetida (sin cambios) |
| `0x130` | «ALOJ» (letras A-L-O-J) | izquierdo |
| `0x131` | «ARSE» (letras A-R-S-E) | izquierdo |
| `0x12F` | «SE» (final de ALOJARSE) | izquierdo — **era la ル compartida** |
| `0x132` | «SALI» (letras S-A-L-I) | derecho |
| `0x133` | «R» (final de SALIR) | derecho |

- **ALOJARSE** = `0x130` + `0x131` + `0x12F` (48 px, lista IZQ **sin tocar**).
- **SALIR** = `0x132` + `0x133` (32 px, centrado en el panel de 48 px).
- La «ル» final era **compartida** por ambos paneles (celda `0x12F`). Como
  ahora `0x12F` es la última celda de ALOJARSE, el panel derecho ya no la
  referencia: se **neutraliza** sustituyendo su entrada en la lista DER por
  una celda de panel (redundante) y desplazando SALIR 9 px a la derecha para
  centrarlo. **No se añade ninguna celda nueva.**

## Dónde está en la ROM (medido)

Las celdas del rótulo viven en un bloque comprimido de sprites (descompresor
`$C1CC/$C206`, 1 celda = 4 tiles = 128 B), **contiguo** desde ~`0x34A00`:

| celda | offset ROM | tamaño comprimido (v410) |
|---|---|---|
| `0x128` | `0x34AB7` | 24 B (sin cambios) |
| `0x12F` | `0x34C4B` | 130 B |
| `0x130` | `0x34CCD` | 118 B |
| `0x131` | `0x34D43` | 138 B |
| `0x132` | `0x34DCD` | 108 B |
| `0x133` | `0x34E39` | 135 B |

La descompresión es **secuencial** (walk desde `0x34AB7` reproduce los
offsets/tamaños exactos de `0x128`–`0x133`). Por eso **cada celda sustituida
debe conservar su tamaño comprimido exacto**.

⚠️ **Error de la v417 anterior (ya corregido):** se acolchó con **ceros**
hasta el tamaño original, pero el descompresor avanza por los bytes que
realmente consume; al acortarse `0x12F` (130→95 B) toda la cadena se
desalineaba y `0x130`–`0x133` descomprimían basura (por eso solo se veía el
«SE» y «SALIR» salía corrupto).

**Solución (v417b):** comprimir cada celda a **exactamente** su tamaño
original **inflando** bits «repite el acumulador» → «literal con el mismo
valor» (no cambia el gráfico; +1 B por conversión). Así los offsets no se
mueven. Resultado:

| celda | comprimido real | tamaño exacto (igual al original) |
|---|---|---|
| `0x12F` | 95 B | 130 B |
| `0x130` | 80 B | 118 B |
| `0x131` | 82 B | 138 B |
| `0x132` | 91 B | 108 B |
| `0x133` | 83 B | 135 B |

**OJO:** el bloque `0x34000` contiene también las celdas `0x104`–`0x10F` donde
el otro chat metió SALIR (v415, `0x3412D`…), así que no hay que pisarlas.

## La lista de sprites (SAT) del rótulo

Las listas que colocan el rótulo están en ROM, formato 5 B por sprite
(`rel, alo, ahi, dx, dy`, terminador `0xFF`), con `celda = base + rel` y
`base = 0x104`:

| lista | offset ROM |
|---|---|
| IZQ (tomaru → ALOJARSE) | `0x4D82C` (sin cambios) |
| DER (yameru → SALIR) | `0x4D841` (modificada) |

Cambios en las listas (v410 → v417), **medidos en emulador** (pantalla real
tras entrar a la posada; los sprites tienen un bias de −32 px en x):

| lista | entrada | v410 | v417 |
|---|---|---|---|
| DER `0x4D841` | [0] | ル (rel `0x2B`) | **ELIMINADA** (lista desplazada 1 entrada) |
| DER `0x4D841` | [1] | ヤメ (rel `0x2E`, w32, dx=−25) | SALIR (rel `0x2E`, w32, dx=−14) — +11 px |
| IZQ `0x4D82C` | [0] | ル (rel `0x2B`, dx=7) | dx=10 — +3 px |
| IZQ `0x4D82C` | [1] | トマ (rel `0x2C`, w32, dx=−25) | dx=−22 — +3 px |

⚠️ **La ル derecha se ELIMINA, no se tapa.** La celda `0x12F` (ahora «SE»)
era compartida entre ambos paneles. Su entrada derecha sobra, pero **no se
puede sustituir por un panel**: esa entrada se dibuja con índice SAT menor
que SALIR (por tanto ENCIMA) y mutilaría la S (le tapaba las 3 líneas
superiores). La lista se lee hasta `0xFF`, así que basta con desplazar las
entradas restantes una posición a la izquierda y dejar el `0xFF` tras la
tercera.

Resultado medido en pantalla: **ALOJARSE** pegado a ambos bordes del panel
(0 px de margen) y **SALIR** con **8 px de margen** a cada lado, tal como
David diseñó el `Posada.PNG`.

## Verificación

1. **Byte a byte:** las celdas en `v417` descomprimen idénticas a los `.bin`
   generados (`tools/posada_celdas/{12F,130,131,132,133}.bin`) y mantienen los
   offsets/tamaños originales (padding verificado).
2. **En emulador (mock):** cargando el state de Posada con las celdas
   parcheadas en VRAM y la SAT ajustada (ル derecha oculta, SALIR +9 px) se
   renderiza correctamente **ALOJARSE** y **SALIR** centrado, sin resto de la
   ル. Ver `tools/posada_celdas/mock_emulador.png` y `recorte_rotulo.png`.
3. **En partida real (estados de David):** cargando `Pulsar arriba.state` con
   la ROM v417 y pulsando ARRIBA se entra a la posada y el rótulo se ve
   completo y bien posicionado (recarga de escena real, no mock). Capturas:
   `tools/posada_celdas/rotulo_final.png` y `pantalla_final.png`.
   `Entrando.state` es el personaje aún cruzando la puerta (el rótulo todavía
   no aparece); `Pulsar arriba.state` + ARRIBA es la forma fiable de
   reproducirlo.

## Siguientes rótulos (orden)

Bienvenido.PNG → Baño.PNG → Estudio Banzai.PNG → Colorín colorado.PNG
