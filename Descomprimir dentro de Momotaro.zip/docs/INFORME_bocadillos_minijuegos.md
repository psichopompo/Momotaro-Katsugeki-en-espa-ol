# Informe — bocadillos de minijuegos (frente 1 y 2)

Tarea asignada por David. Dos frentes sobre los bocadillos de minijuegos:

1. El minijuego «ricos y pobres» muestra «Ganas 17 ryos.» en UNA línea y SIN
   exclamaciones; el resto de minijuegos usa DOS líneas con exclamaciones
   («¡Ganas 50 / ryos!»). Pasar el rico-pobre al formato común.
2. Después sobrará espacio a la derecha; reducir los bocadillos y darles
   identificador propio (como el del abuelo, `$368F=2`) para no tocar los
   bocadillos que comparten sprites.

---

## Frente 1 — formato «¡Ganas N / ryos!»  → **HECHO (v412)**

### La fuente del texto

Hay DOS mecanismos que pintan «Ganas …»:

| Qué | Dónde | Formato | Importe |
|---|---|---|---|
| Tabla estática `$C969` | ROM `0x16969`, textos `0x48C7E…` | «¡Ganas 100`<3B>`ryos!» (dos líneas, con ¡/!) | fijo (10/20/30/50/80/100) |
| **Rutina dinámica `$C8ED`** | ROM `0x168ED` | «Ganas 17 ryos.» (una línea, sin signos) | variable (`$373B`) |

La tabla estática son los mensajes de obtención de ítem y los importes FIJOS
de dinero de los minijuegos; ya están en dos líneas con exclamaciones.

El texto del rico/pobre lo fabrica la **rutina `$C8ED`** (banco `$0B`),
alcanzada desde `$C8DB` cuando el índice `$363E` es negativo (dinero de
cantidad variable). Esa rutina:

1. `TII $C951,$3641,$0012` → copia 18 B de plantilla a RAM `$3641`.
2. Descompone `$373B` en centenas/decenas/unidades y las mete en `$3647..`.
3. Añade 6 B de `$C963` (« ryos.») tras el último dígito.

Era la ÚNICA fuente de «Ganas N ryos.» (búsqueda de «Ganas»/«ryos» en toda la
ROM: la plantilla + la tabla estática + nada más con importe variable).

### El cambio (6 parches, sin mover nada)

| Offset | Antes | Después | Qué |
|---|---|---|---|
| `0x16951` (18 B) | «Ganas» + 7 esp + 6 NUL | «¡Ganas » + 3 esp + 8 NUL | añade «¡», recupera el byte quitando un espacio y un NUL |
| `0x16963` (6 B) | `20 b2 b9 af b3 cb` (« ryos.») | `3b b2 b9 af b3 21` («`<3B>`ryos!») | salto de línea + «!» en vez de «.» |
| `0x16920`, `0x1692B`, `0x16934`, `0x1693C` | `99 47 36` (`STA $3647,Y`) | `99 48 36` (`STA $3648,Y`) | la base del dígito corre 1 para hacer hueco al «¡» |

`0x3B` es el salto de línea del motor de bocadillo (mismo byte que usa la
tabla estática); `0x00` sigue siendo el terminador. No se toca la lógica de
los dígitos, sólo la maquetación.

Resultado (simulado con `tools/simula_c8ed.py`):

```
$373B  ANTES (v410)            DESPUÉS (v412)
   7   Ganas 7 ryos.           ¡Ganas 7[BR]ryos!
  17   Ganas 17 ryos.          ¡Ganas 17[BR]ryos!
 150   Ganas 150 ryos.         ¡Ganas 150[BR]ryos!
```

ROM resultante: **`roms/momotaro_es_v412.pce`** (parte de la v410, NO toca
nada de A-GRAF). Constructor: `tools/build_v412.py`.

**Nota (pre-existente, sin tocar):** la rutina de dígitos salta el «0» de las
decenas cuando es 0, así que un importe exacto de 100 se imprimiría «10».
Es un borde del código original (los importes del rico/pobre son pequeños,
«17» según David, nunca 100 exacto); no lo he corregido para no alterar la
lógica. Si algún día importa, se avisa.

---

## Frente 2 — reducir los bocadillos + identificador propio  → **en estudio**

### Cómo se construye un bocadillo (recapitulado y verificado)

El bocadillo es un puzzle de sprites. La lista de sprites se elige por
`$368F` mediante una tabla de 4 punteros en ROM `0x47C99` (banco `$23`):

```
$FFA0  LDA $368F / ASL A / TAY
       LDA $7C99,Y / STA $53
       LDA $7C9A,Y / STA $54
       RTS
```

| `$368F` | Lista | Sprites | Geometría |
|---|---|---|---|
| 0, 1, 3 | `$7C02` (compartida) | 30 | 3 filas × 8 celdas centrales (~16 caracteres) |
| 2 | `$7CA1` (abuelo) | 18 | 2 filas × 7 celdas centrales (14×2) |

Formato de cada sprite (5 bytes): `[celda][attr 0x0F][flip][dX][dY]`,
`dX`/`dY` con signo. Terminador `$FF`.

Dónde se fija `$368F`:
- `$C7EC` (ROM `0x167EC`): lo pone a 0/1 según el lado del personaje
  (bocadillos de aldeano/PNJ).
- `$DE78` (ROM `0x17E78`): lo pone a **2** (bocadillo del abuelo = obtención
  de ítem/dinero en el mapa, vía el `JMP $C8D2` del pickup `0x16867`).
- El rabillo lo emite `$9A78` aparte, según `$368F` (4 variantes en `$9ADD`).

### Lo que hay que hacer (plan)

El bocadillo del minijuego rico/pobre hoy usa la **lista compartida**
(`$7C02`, 3 filas, ~16 caracteres). Con el texto nuevo («¡Ganas 17» / «ryos!»,
9 caracteres como mucho) sobran ~7 caracteres a la derecha. Para estrecharlo
sin romper aldeanos/Jizo:

1. **Localizar la vía del minijuego**: confirmar con qué `$368F` y por qué
   código se emite el bocadillo del rico/pobre (hoy apunta a compartida).
2. **Crear lista propia** (p. ej. 2 filas × 6 celdas = 12 caracteres, o el
   ancho que David quiera) en un hueco del banco `$23`.
3. **Añadir 1 puntero** a la tabla `0x47C99` (var 4 → lista nueva).
4. **Poner `$368F=4`** en la vía del minijuego.

Pasos 2–4 son el mismo patrón que se usó para el abuelo en la v231 (informe
`docs/historico/INFORME_v225_a_v231.md`), que documenta los 5 fallos a evitar:
no pisar el terminador `$FF` de la compartida, no usar `$3692`/`$3693` como
marcas (se indexan), no `LDX $368F` dentro del bucle de `$9B7C` (X es el
contador), y cuidar `PLX/PLA` (machacan N/Z) y `CPX/CPY` (ensucian carry).

### Pendiente antes de implementar

- Confirmar en pantalla (capturas de David) cuánto sobra exactamente y qué
  ancho final quiere David para el bocadillo del minijuego.
- Localizar la vía exacta que emite el bocadillo del rico/pobre (para el
  `$368F=4`), que aún no está aislada: la rutina de dinero (`INC/DEC $373B` en
  `0x4FA27`/`0x4FBFF`) dispara `$E37B`/`$80DA`, y el display va por `$97EE`,
  pero falta cerrar el `$368F` que queda vigente en ese momento.
