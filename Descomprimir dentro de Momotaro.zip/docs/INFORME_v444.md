# v444 — Arreglo de los 4 reportes del usuario

Versión que corrige las cuatro incidencias reportadas por un usuario,
comparando con la ROM japonesa. Base: `momotaro_es_v443.pce`.

---

## 1. Tutorial: el diálogo decía «50» fijo (BUG de la traducción) — ARREGLADO

**Causa.** En la v122 se sustituyeron los tres marcadores `0xFB` (donde el
juego escribe el importe real) por un `50` literal, creyendo que siempre se
recibían 50 ryos. El juego sigue otorgando el importe real según el tiempo del
tutorial, pero el texto ya no lo reflejaba.

**Mecanismo (verificado en la ROM japonesa).** La cantidad se calcula a
partir del tiempo `$3C49` con una tabla de umbrales (`$C0C4`, ROM `0x1A0C4`):

| tiempo | importe |
|---|---|
| ≥ 16 s | 50 |
| 11–15 s | 100 |
| 6–10 s | 200 |
| < 6 s | 300 |

Los tres `0xFB` los consume el handler `$A2C3`, que lee los dígitos de
`$380E-$3810` (centenas/decenas/unidades) y los escribe alineados a la
derecha. Toda esta maquinaria estaba **byte-idéntica** a la japonesa; solo
faltaba devolver los tres marcadores.

**Cambio.** `50` → `FB FB FB` en la línea «¡Momotaro obtiene 50⏎ryos!».
El bloque crece 1 byte, consumido del relleno `0xFF`; la lista de sprites de
la pantalla de carga (`0x1FF6F`, punteros `$5F6F`) **no se mueve**.

**Cambio adicional (1b) — el importe pasa a su propia línea.** El bocadillo
de los padres tiene **20 celdas por línea** (documentado en
`Hilo_Momotaro_v5.md`), y «¡Momotaro consigue » ya ocupa 18. Con el importe en
línea (3 celdas) la línea llegaba a 21 celdas y desbordaba la caja (el «50»
literal de 2 celdas cabía justo en 20, por eso nunca se había visto). Para
que quepan también los importes de 3 cifras (100/200/300), el importe pasa a
su propia línea, como en el japonés original «ももたろうは⏎50両»:

```
antes:  ¡Momotaro obtiene 50⏎ryos!      (21 celdas: desbordaba)
ahora:  ¡Momotaro consigue⏎
         50 ryos!                       (18 y 9 celdas)
```

El importe queda alineado a la derecha tal como viene en la tabla `$C0C4`
(`« 50»` / `«100»` / `«200»` / `«300»`), que es el alineado natural de una
columna de números y coincide con el japonés. Se intercambian el espacio
(0x20) y el salto de línea (0x00) en `0x1FEF3` y `0x1FEF7`: cero bytes de
más, sin repunte.

**Cambio adicional (6) — redacción.** A petición de David, «obtiene» pasa a
«consigue» (ambas traducen el japonés てにいれる): «¡Momotaro consigue⏎[n]
ryos!». `obtiene` (7 B) → `consigue` (8 B), +1 byte consumido del relleno
`0xFF` anterior a la lista de sprites (que sigue en `0x1FF6F`).

Resultado: «¡Momotaro consigue⏎[n] ryos!» con el importe real — 50, 100, 200
o 300 según el tiempo del tutorial.

---

## 2. Bonus: «ganas 100» informaba «10» (BUG del original) — ARREGLADO

**Causa.** La rutina de dinero variable `$C8ED` (ROM `0x168ED`) se saltaba la
decena cuando era 0, de modo que 100 → «10», 200 → «20», 300 → «30». Estaba
así en la ROM japonesa (bug del juego original).

**Cambio.** La rutina se reubicó a `$DE99` (ROM `0x17E99`, 102 bytes libres)
con la lógica corregida: la decena solo se salta cuando **la centena también
es 0**. En `$C8ED` queda un `JMP $DE99`.

Resultado (simulado): 7→7, 17→17, 50→50, **100→100, 200→200, 300→300**,
999→999. El resto de la rutina (plantilla, « ryos.», divisor 100/10) intacto.

---

## 3. «Ésta» → «Esta» y «sólo» → «solo» (tildes diacríticas) — ARREGLADO

- «Ésta»: dos ocurrencias, `0x49919` y `0x4BF2E` (la intro «Esta es la aldea
  de Issun-boshi» y un diálogo). `É` (`0xC3`) → `E` (`0x45`).
- «sólo»: tres ocurrencias, `0x3BB9A`, `0x4BB09` y `0x4BC83` (todas adverbio
  «solamente»). `ó` (`0xBE`) → `o` (`0xAF`).

Conforme a la RAE: la tilde de los demostrativos se considera falta, y en
«sólo» se retira también por coherencia con el resto de la traducción (David
autorizó quitarla).

---

## 4. Quiz, pregunta 40: «Momotaro ¿qué?» → «Momotaro en…» y «Leyenda» → «Bolas» — ARREGLADO

La pregunta original era «Este juego es / Momotaro ¿qué?» (respuestas
Leyenda/Acción/Tren). El problema de fondo: las respuestas debían encajar con
la pregunta, y «Leyenda» (guiño a *Momotaro Densetsu*) no encaja con «en».
Como el juego se llama **Momotaro en Acción**, la pregunta queda:

```
Este juego es
Momotaro en...      (respuestas: Bolas / Acción / Tren)
```

- «¿qué?» → «en…» (misma longitud, 5 B → 5 B).
- «Leyenda» → «Bolas» (campo de 8 B, 5 letras + relleno). «Bolas» es un
  distractor neutro (no rompe el «en» y no es una referencia a otro juego).

Con «en», las tres respuestas encajan gramaticalmente: «Momotaro en Acción»
(la correcta), «Momotaro en Tren» (guiño a *Momotaro Dentetsu*) y «Momotaro
en Bolas» (distractor). Sin cambios de longitud ni repunte de punteros.

---

## Ficheros

```
roms/momotaro_es_v444.pce                     ROM resultante
parches/momotaro_v444.ips / .bps              incremental v443 -> v444
parches/momotaro_es_v444_completo.ips / .bps  completo japonés -> v444
tools/build_v444.py                           constructor (verificado byte a byte)
```

Hashes de `momotaro_es_v444.pce`: MD5 `8034ed154b7e42748f700cab8388280c`,
SHA-1 `98bc3b62cf529f592a7049cf3734885d0ed4b9c0`, CRC32 `F56E39D6`.

---

## Verificación

- Constructor con verificación byte a byte de cada cambio (patrón exacto
  antes de escribir).
- Rutina `$C8ED` reubicada desensamblada y lógica de dígitos simulada.
- Mecanismo de importe de los padres (tabla de umbrales + handler `0xFB`)
  comprobado byte-idéntico a la japonesa.
- Round-trip de los 4 parches (IPS y BPS, incremental y completo).

**Pendiente de David:** prueba visual en emulador (escena de los padres con
varios tiempos de tutorial —especialmente confirmar que «consigue⏎[n] ryos!»
se ve bien con 50, 100, 200 y 300—, minijuego rico/pobre con importe 100,
intro «Esta es la aldea», quiz pregunta 40 con las nuevas respuestas).
