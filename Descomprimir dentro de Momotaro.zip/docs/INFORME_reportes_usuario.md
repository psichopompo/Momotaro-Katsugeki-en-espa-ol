# Informe — Reportes del usuario (4 incidencias)

Comparación de la ROM japonesa con la traducción (`momotaro_es_v443.pce`),
hecha a partir del código y los textos de ambas ROMs.

---

## 1. Tutorial: «ganas 300 ryo pero el diálogo dice 50» — BUG DE TRADUCCIÓN CONFIRMADO

### Qué decía el japonés

La escena de los padres (ROM `0x1F077`) tiene en la línea del importe:

```
モモタロウハ
[FB][FB][FB]両 テニイレタ!      (bytes: FB FB FB 24 3C …)
```

Los **tres `0xFB` son marcadores de dígito**: el juego escribe ahí, en tiempo
de ejecución, la **cantidad real** (centenas/decenas/unidades, alineada a la
derecha), seguida del símbolo `両` (`0x24`, que en el proyecto es `$`).

Es decir: **el japonés muestra el importe real, que es variable** según el
tiempo que tardes en el tutorial. Por eso el tester ve «300» de dinero pero
una frase que dice otra cosa.

### Qué hizo la traducción

En la v122 se sustituyeron los tres `0xFB` por el texto literal `50`:

```
JP:  … 00 FB FB FB 24 3C C3 C6 B2 DA C0 21 …     («… [FB][FB][FB]$ テニイレタ!»)
ES:  … 20 35 30 00 B2 B9 AF B3 21 …              («… 50⏎ryos!»)
```

La escena traducida vive reubicada en `0x1FEA9` (el bloque original `0x1F077`
quedó intacto como código muerto). El texto resultante es:

```
¡Momotaro obtiene 50⏎ryos!
```

### Conclusión

**Confirmado: es un bug nuestro.** Eliminamos el mecanismo de importe
dinámico (los `0xFB`) y lo sustituimos por un `50` fijo, porque en su momento
creímos que siempre se recibían 50 ryos. El juego sigue otorgando el importe
real (300 si terminas el tutorial en <6 s, etc.), pero la frase ya no lo
refleja.

### El arreglo

Devolver los tres marcadores en el sitio del `50`:

```
antes:  ¡Momotaro obtiene 50⏎ryos!
después: ¡Momotaro obtiene [FB][FB][FB]⏎ryos!
```

Cambio de 2 bytes (`35 30`) por 3 (`FB FB FB`): se añade 1 byte. Hay que
comprobar si cabe en el bloque reubicado o reubicar un poco. La sangría
inherente al alineado a la derecha (un hueco cuando la cifra es de 2 dígitos)
se acepta, tal como se documentó en su día (norma 41 del diario).

---

## 2. Bonus: «ganas 100 informa 10» (falta el 0) — BUG PREEXISTENTE DEL ORIGINAL

### Qué pasa

La rutina de dinero variable `$C8ED` (ROM `0x168ED`) descompone el importe en
centenas/decenas/unidades y las imprime, **saltándose la decena si es 0**:

```
16919  LDA $14     ; centenas
1691B  BEQ $C924   ; si 0, se salta
       …imprime…
16924  LDA $15     ; decenas
16926  BEQ $C92F   ; si 0, se salta  ← el bug
       …imprime…
1692F  LDA $10     ; unidades (siempre)
```

Para un importe exacto de **100**: centenas=1 (imprime «1»), decenas=0
(**se salta**), unidades=0 (imprime «0») → **«10»**. El simulador
`tools/simula_c8ed.py` lo reproduce: `100 → ¡Ganas 10 ryos!`.

### ¿Es nuestro o del original?

**Del original.** La rutina `$C8ED` del japonés (ROM `0x168ED`) tiene la
misma lógica byte a byte; la traducción solo cambió la maquetación (el «¡»,
el «!» y el salto de línea), no la lógica de dígitos. Está anotado en
`docs/INFORME_bocadillos_minijuegos.md`:

> «la rutina de dígitos salta el 0 de las decenas cuando es 0, así que un
> importe exacto de 100 se imprimiría “10”. … no lo he corregido para no
> alterar la lógica. Si algún día importa, se avisa.»

En su día se creyó que los importes del minijuego nunca llegaban a 100
exacto. El tester confirma que **sí ocurre** en las fases de bonus.

### El arreglo

Corregir la rutina para que la decena solo se salte cuando sea un **cero a la
izquierda** (es decir, cuando la centena también es 0), no siempre que sea 0:

```
antes:   LDA $14 / BEQ a / imprime centena
         a: LDA $15 / BEQ b / imprime decena
         b: LDA $10 / imprime unidad
después: LDA $14 / BEQ a / imprime centena / LDA $15 / imprime decena / BRA b
         a: LDA $15 / BEQ b / imprime decena
         b: LDA $10 / imprime unidad
```

El cambio alarga la rutina; habrá que reubicarla o comprimir el código
adyacente. Es un cambio de lógica del motor de texto (banco `$0B`), así que
conviene verificarlo en pantalla con varios importes (7, 17, 100, 150, 999).

---

## 3. «Ésta es la aldea» — tilde en el demostrativo

Dos ocurrencias de «Ésta» en la ROM:

| ROM | texto |
|---|---|
| `0x4BF2E` | «Ésta es la aldea / de Issun-boshi» (intro) — la que señala el tester |
| `0x49919` | «Ésta r…» (diálogo de un ermitaño/minijuego, texto vertical) |

La RAE (desde 2010) recomienda **no** acentuar los demostrativos (`esta`,
`este`, `esa`…). El tester lo marca como error.

Mi recomendación: **quitar la tilde** en ambas (`É` `0xC3` → `E` `0x45`), por
coherencia con la norma vigente y porque es lo que espera el lector. Es un
cambio de 1 byte por sitio, trivial.

*Nota:* hay también tres «sólo» (`0x3BB9A`, `0x4BB09`, `0x4BC83`) en la misma
situación (la RAE también retiró esa tilde). No los he tocado ni los tocaré
salvo que lo pidas, porque sé que prefieres conservar tildes; lo dejo anotado
por si quieres decidirlo aparte.

---

## 4. « Momotaro» con espacio delante — la pregunta 40 del quiz

El tester habla de «Este juego es…», que es la **pregunta 40 del quiz del
ermitaño** (un anciano). Localizada en la tabla de punteros del quiz
(`0x11818`), índice 41.

| | texto |
|---|---|
| **JP** | `イマヤッテイル ゲーム ノ ナマエハ モモタロウ ナニ?` → «El nombre del juego que estás jugando ahora es… Momotaro, ¿qué?» |
| **ES** | «Este juego es⏎Momotaro ¿qué?» |

Respuestas: `Leyenda` / `Acción` / `Tren` (los finales de «Momotaro Densetsu
/ Katsugeki / Dentetsu»). La correcta es «Acción» (Katsugeki).

Dos cosas:

1. **El significado se perdió.** El japonés pregunta por el **nombre** del
   juego («¿“Momotaro”… qué?»). La traducción «Este juego es…» ya no pide el
   título, y «Momotaro ¿qué?» queda raro. Habría que reformular, p. ej.
   «Este juego se llama / “Momotaro”… ¿qué?» o «El nombre del juego es /
   “Momotaro”… ¿qué?».

2. **Sobre el «espacio».** En los bytes, «Momotaro» empieza la 2ª línea (va
   justo tras el `0x80` de salto de línea) **sin espacio delante**. El hueco
   que ve el tester es el relleno de 3 espacios (`A0`) que cierra la línea 1
   hasta las 16 columnas, más el salto. No es un espacio literal delante de
   «Momotaro», pero sí se percibe como tal si el bocadillo no parte la línea
   como debería. Conviene que lo confirmes en pantalla: si el `0x80` no
   fuerza el salto en esa pantalla concreta, la frase se ve «Este juego es
   ␣␣␣Momotaro ¿qué?» con tres huecos.

   La reformulación del punto 1 probablemente elimine también esa percepción.

---

## Resumen

| # | Incidencia | Diagnóstico | ¿Nuestro? |
|---|---|---|---|
| 1 | Tutorial 300 → «50» | Se borraron los marcadores `0xFB` (importe dinámico) y se fijó «50» | **Sí** |
| 2 | Bonus 100 → «10» | La rutina de dígitos se salta la decena si es 0 | **No** (original, pendiente de arreglar) |
| 3 | «Ésta» | Tilde diacrítica desaconsejada por la RAE | Decisión de estilo |
| 4 | « Momotaro» | Pregunta 40 del quiz: significado perdido + relleno de línea | **Sí** (traducción) |
