# v445 — «c» normalizada + «obtiene» (sobre v444)

Dos cambios sobre `momotaro_es_v444.pce` (MD5 `8034ed15…`). La v445 es la
versión candidata a definitiva.

---

## 1. Quiz Q40: normalizada la «c» de «Acción»

La respuesta «Acción» tenía la `c` codificada con el **byte directo** `0xA3`,
en vez del **alias canónico** `0x5D` que usa `charset_oficial.py` para `c`.

**Qué significa.** El motor de diálogo tiene dos rutas: byte ≥ `0xA0` va por
la ruta katakana (glifo directo) y byte < `0xA0` por la tabla `0x43F9B`
(`glifo = tabla[byte−0x30]`). Verificado: `tabla[0x2D] = 0xA3`, es decir, el
alias `0x5D` apunta **al mismo glifo** que el byte directo `0xA3`. En el
motor de diálogo ambos renderizan «c»; la diferencia es que `0xA3` directo es
«no seguro» en las pantallas que solo usan la ruta de tabla (parrilla del
Canto de Jizo, menús laterales). Por coherencia con el resto de la traducción
(todo lo demás usa el alias), se normaliza.

**Cambio.** `0xA3 0xA3` → `0x5D 0x5D` en la respuesta «Acción» (`0x4B7C8`,
`0x4B7C9`). Sin cambio de longitud.

**Nota (mismo caso, sin tocar por no estar pedido).** Otra respuesta del quiz,
«Liebre», tiene la `b` con el byte directo `0xA2` (debería ser `0x5B`). Mismo
caso que «Acción»; se deja apuntado por si David quiere normalizarla también
(1 byte).

---

## 2. Padres: «consigue» → «obtiene» (redacción)

David prefiere «obtener» a «conseguir» (traducción del japonés てにいれる).
Se devuelve el verbo original de la línea del importe.

**Cambio.** `consigue` (8 B) → `obtiene` (7 B) en `0x1FEEC`; la cola del
bloque se desplaza 1 byte a la izquierda y se restaura el relleno `0xFF`
anterior a la lista de sprites (que sigue en `0x1FF6F`, punteros `$5F6F`
intactos).

```
¡Momotaro obtiene⏎
 50 ryos!                (17 y 9 celdas; cabe en la caja de 20)
```

Resultado idéntico para los 4 importes (50/100/200/300).

**Nota de interpretación.** Se mantiene la **tercera persona** («¡Momotaro
obtiene…!») para concordar con el sujeto «Momotaro», como el original japonés
`ももたろうは … てにいれた`. Si David prefería segunda persona («¡Obtienes [n]
ryos!», dirigiéndose al jugador, como el «¡Ganas…!» del minijuego), es un
cambio trivial pendiente de confirmar.

---

## Ficheros

```
roms/momotaro_es_v445.pce                     ROM resultante
parches/momotaro_v445.ips / .bps              incremental v444 -> v445
parches/momotaro_es_v445_completo.ips / .bps  completo japonés -> v445
tools/build_v445.py                           constructor (verificado byte a byte)
```

Hashes de `momotaro_es_v445.pce`: MD5 `bc73f388cc0e37e93edc2fca7c4b6c21`,
SHA-1 `25e121dfe728dd1d52f78084f1ef8c5ca1972144`, CRC32 `0160197C`.

---

## Verificación

- Constructor con verificación byte a byte de cada cambio.
- Diff v444→v445 = 130 bytes: el verbo (9 B) + la cola desplazada (119 B) +
  la «c» (2 B). Nada más.
- Render simulado de los 4 importes (50/100/200/300) con «obtiene».
- Round-trip de los 4 parches (IPS y BPS, incremental y completo).

**Pendiente de David:** prueba visual en emulador, y decidir (a) «obtiene» en
3ª vs 2ª persona y (b) si normalizar también la «b» de «Liebre».
