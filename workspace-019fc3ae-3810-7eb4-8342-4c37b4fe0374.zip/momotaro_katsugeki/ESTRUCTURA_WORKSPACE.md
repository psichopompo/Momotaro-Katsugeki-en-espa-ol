# Organización del workspace de Momotarou Katsugeki (traducción al español)

> Actualizado el 2026-08-02 tras la limpieza y preparación para migrar a un chat nuevo.
> Rutas relativas a la raíz del workspace (`/home/user`).
> Estado actual: traducción de la pantalla "¿Cuál quieres cargar?" en curso.
> **La "?" de cierre de la pregunta desaparece** al desplazar el bloque +3px (regla SAT
> descarta sprites con X≥234). Esa es la tarea pendiente que trabaja Claude.

## `/home/user/emutools/`  (16 MB — imprescindible para ejecutar/compilar el emulador)

- `beetle-pce-fast-libretro/` — fuentes del core Beetle PCE Fast **instrumentado**.
  - `libretro.c` y `mednafen/pce_fast/{huc6280.c,vdc.c}` contienen los hooks `arena_*`.
  - **Tras editar cualquier fuente, hay que recompilar**: `cd emutools/beetle-pce-fast-libretro && make -j4`.
  - El runner usa `mednafen_pce_fast_libretro.so` (resultado de la compilación).
  - No contiene `.git`; el commit de origen no se puede recuperar aquí.

## `/home/user/downloads/`  (entrada de la emulación)

- `momotaro.state` — save-state capturado justo antes de entrar a la pantalla de carga
  (la transición a la pregunta). Se carga con `Runner.load_state()`.
- `momotaro.srm` — datos guardados (BRAM) de la partida de prueba ("DIFÍCIL 1").

## `/home/user/uploads/`  (entradas del usuario / de Claude)

- `PROMPT_METODO.md` — reglas obligatorias de investigación y entrega.
- `savestate/Momotarou Katsugeki (Japan).srm` — BRAM aportado por el usuario (idéntico a `downloads/momotaro.srm`).
- `Claude*.txt` — respuestas/prompts de Claude.
- Varias capturas `*-260802-*.png` (ampliaciones recientes de la pantalla de carga).

## `/home/user/momotaro_katsugeki/`

### Documentación y seguimiento

- `investigation.md` — **diario permanente y prioritario** de toda la investigación (con todas las mediciones y hallazgos de la pantalla de carga, melocotón, etc.).
- `ESTRUCTURA_WORKSPACE.md` — este inventario.
- `reports/` — informes clave conservados:
  - `PROMPT_para_Claude_pregunta_carga_FINAL.md` (y `.md` base), `PLAN_pregunta_carga.md`,
    `ODISEA_SELECTOR_TEXTO.md`, `PROMPT_para_Claude_localizar_baseX.md`, `prompt_para_claude_selector.md`.

### ROMs y parches (los únicos conservados)

- `Roms/Original/Momotarou Katsugeki (Japan).pce` — ROM japonesa limpia de referencia. MD5 `ec7358ed…`.
- `Roms/Momotarou Katsugeki (Japan) - traduccion_v15_restaurar_bloque2.pce` — base de trabajo verificada. MD5 `beed9322…`.
- `Roms/Pruebas/test_qonerow_final.pce` — **ROM final actual** de la pantalla de carga (pregunta en una fila + DIFÍCIL alineado + melocotón). MD5 `edc45465…`.
- `Roms/Pruebas/test_qonerow_claudeQ.pce` — ROM con el glifo "¿" de Claude aplicado (referencia). MD5 `993ea16e…`.
- `Parches/momotaro_pantalla_carga_v16.ips` — parche IPS (original → `test_qonerow_final`). El único parche conservado.
- `work/Momotarou Katsugeki (Japan).pce` — ROM japonesa duplicada para las herramientas.

### Herramientas (`tools/`)

- `libretro_pce_runner.py` — **runner del emulador instrumentado** (carga ROM/state, lee VRAM/SAT/MPR/PC y expone todos los logs `arena_*`). Imprescindible.
- `dis6280/` + `dis6280_bin` — desensamblador HuC6280. **Perderá el permiso de ejecución en cada arranque; hacer `chmod +x tools/dis6280_bin` antes de usarlo.**
- `make_ips_final.py` — genera el parche IPS desde la ROM original.
- `patch_question_onerow.py` — aplica los cambios de la pantalla de carga (bloque2, C5AC, "¿").
- `apply_shift3/5/7left.py` y `apply_melopatch.py` — pasos de desplazamiento del melocotón/DIFÍCIL.
- `latin_text_tools.py`, `decode_text.py`, `measure_width.py`, `find_text_tiles.py` — utilidades de texto/anchura.
- Resto: scripts de captura/análisis puntuales (no todos se conservan; los que quedan son los relevantes).

### Datos de traducción

- `Tablas/` — tabla latina actual y propuestas.
- `translation/` — bloques de texto conocidos.
- `font_edit/` — activos y mapeos de la fuente/parrilla de contraseñas.
- `title_assets/` — activos del logotipo y menú principal.

### Evidencia visual

- `images/` — solo se conserva `test_qonerow_final.png` (captura del estado actual).
- `instrument/` — vacío tras la limpieza (los datos viejos se borraron).

## Para ponerte al día en un chat nuevo

1. **Leer primero** `momotaro_katsugeki/investigation.md` (sobre todo las entradas recientes 17-19 sobre la pantalla de carga, el melocotón y la "¿").
2. **Leer** `momotaro_katsugeki/reports/PROMPT_para_Claude_pregunta_carga_FINAL.md` y `PLAN_pregunta_carga.md`.
3. **Leer** `uploads/PROMPT_METODO.md` (reglas de investigación).
4. **Compilar el emulador** si falta el `.so`: `cd /home/user/emutools/beetle-pce-fast-libretro && make -j4`.
5. **Verificar el runner**: `cd /home/user/momotaro_katsugeki/tools && python3 -c "from libretro_pce_runner import Runner; print('ok')"`.
6. **Probar la pantalla de carga**: cargar `downloads/momotaro.state` con una ROM de `Roms/Pruebas/` (p. ej. `test_qonerow_final.pce`).
7. **Tarea pendiente inmediata**: la "?" de cierre de "¿Cuál quieres cargar?" desaparece al desplazar el bloque +3px (regla SAT X≥234). Hay que ampliar ese límite o recolocar la "?".
