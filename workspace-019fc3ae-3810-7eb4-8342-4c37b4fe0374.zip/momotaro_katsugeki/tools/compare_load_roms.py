#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
EVENTS={1790:[3],1800:[7],1820:[],1850:[3],1860:[]}
def analyze(ROM, SRM, label):
    out=Path(f'/home/user/momotaro_katsugeki/images/cmp_{label}'); out.mkdir(parents=True,exist_ok=True)
    r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
    try:
        r.run(2100, EVENTS)  # selector
        # DOWN to CARGAR
        for _ in range(25): r.buttons={5}; r.run(1,{})
        r.buttons=set()
        for _ in range(15): r.run(1,{})
        # confirm RUN
        for _ in range(25): r.buttons={3}; r.run(1,{})
        r.buttons=set()
        for _ in range(300): r.run(1,{})
        # capture image
        w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
        img=Image.new("RGB",(w,h)); px=img.load()
        for y in range(h):
            row=data[y*p:y*p+w*2]
            for x in range(w):
                b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
                r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
                px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
        img.save(out/"load.png")

        # glyphs at $7000+ (sprite CG base $3800 + tile*0x20 -> tile 0x1C0=$7000)
        vram=r.vram_words()
        def gl(addr):
            out=[]
            for y in range(8):
                row=''
                for x in range(8):
                    bit=7-x
                    v=((vram[addr+y]>>bit)&1)|(((vram[addr+8+y]>>bit)&1)<<1)|(((vram[addr+16+y]>>bit)&1)<<2)|(((vram[addr+24+y]>>bit)&1)<<3)
                    row += '#' if v else ' '
                out.append(row)
            return out
        nonempty=[a for a in range(0x7000,0x7400,0x20) if any('#' in rr for rr in gl(a))]
        print(f"[{label}] glyphs non-empty in $7000-$7400: {[hex(a) for a in nonempty]}")
        if nonempty:
            for a in nonempty[:14]:
                print(f"[{label}] glyph ${a:04x}:")
                for rr in gl(a): print("      |"+rr+"|")

        # SAT
        sat=r.sat_words()
        txt=[]
        for i in range(64):
            x=sat[i*4+1]&0x3ff; y=(sat[i*4+0]&0x3ff)-0x40
            no=(sat[i*4+2]>>1)&0x3ff
            if 0x1C0<=no<=0x1D8: txt.append((i,no,x,y))
        print(f"[{label}] load.png saved. SAT text sprites 0x1C0-0x1D8: {txt}")
        # all sprites y<200
        print(f"[{label}] all sprites:")
        for i in range(64):
            x=sat[i*4+1]&0x3ff; y=(sat[i*4+0]&0x3ff)-0x40
            no=(sat[i*4+2]>>1)&0x3ff; cg=sat[i*4+2]&1
            if x<320 and y<240:
                print(f"   spr{i:2d} x={x} y={y} tile={no:03x} cg={cg}")
    finally:
        r.close()
analyze(sys.argv[1], sys.argv[2], sys.argv[3])
