#!/usr/bin/env python3
from pathlib import Path

ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
BASE=ROOT/'work/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
OUT=ROOT/'work/Momotarou Katsugeki (Japan) - jizo_text_test.pce'
IPS=ROOT/'work/momotaro_jizo_text_test.ips'
REPORT=ROOT/'reports/prueba_insercion_jizo_controlada.md'

orig=ORIG.read_bytes()
rom=bytearray(BASE.read_bytes())  # contiene fuente/tablas latinas validadas

# Restaurar el bloque de test de repertorio para no tocar la casa inicial.
rom[0x1F078:0x1F10C]=orig[0x1F078:0x1F10C]

# Encoder basado en charset_latin_charset_test_v2.tbl
char_to_code={' ':0x20}
for i in range(10): char_to_code[str(i)]=0x30+i
for i in range(26): char_to_code[chr(ord('A')+i)]=0x41+i
char_to_code.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): char_to_code[ch]=0xA1+i
char_to_code['b']=0x5B; char_to_code['c']=0x5D; char_to_code['p']=0x5E
char_to_code.update({
    'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,
    'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,
    '¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,
    "'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,
    '&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'º':0xDC,'ª':0xDD,'Ç':0x5F,
})
def enc(s):
    return bytes(char_to_code[ch] for ch in s)

def put_segment(start,end,parts):
    # parts: list of bytes or ints; FF is forced at original end to preserve sequential boundaries.
    data=bytearray()
    for p in parts:
        if isinstance(p,int): data.append(p)
        else: data += p
    # reserve last byte for FF at original location
    if len(data)>end-start-1:
        raise ValueError((hex(start),hex(end),len(data),end-start-1))
    full = data + bytes([0x20])*(end-start-1-len(data)) + bytes([0xFF])
    assert len(full)==end-start
    rom[start:end]=full
    return full

# Original 0x1F55A-0x1F56E len 20: じぞうのうたを いれるのじゃ!
seg1=put_segment(0x1F55A,0x1F56E,[0x01, enc('Canto de Jizo!')])

# Original 0x1F56E-0x1F5A5 len 55: error + two continuation lines.
seg2=put_segment(0x1F56E,0x1F5A5,[
    0x01, enc('¡Canto incorrecto!'), 0xFD, 0xFD, 0x00,
    enc('Revísalo bien'), 0xFD, 0x00,
    enc('Prueba otra vez.'),
])

OUT.write_bytes(rom)

# IPS contra original.
new=bytes(rom); records=[]; i=0
while i<len(orig):
    if orig[i]==new[i]: i+=1; continue
    s=i; buf=bytearray()
    while i<len(orig) and orig[i]!=new[i] and len(buf)<0xFFFF:
        buf.append(new[i]); i+=1
    records.append((s,bytes(buf)))
ips=bytearray(b'PATCH')
for off,buf in records:
    ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
ips += b'EOF'
IPS.write_bytes(ips)

REPORT.write_text(f'''# Prueba de inserción controlada — pantalla de Jizo/password\n\nROM: `{OUT.name}`\n\nIPS: `{IPS.name}`\n\n## Objetivo\n\nPrimera prueba de inserción de diálogo real usando la fuente latina validada, sin repunteo todavía.\n\nSe han respetado los límites originales de los dos mensajes para no alterar posibles secuencias/punteros. Por eso se usa una adaptación más corta que la traducción final ideal.\n\n## Mensajes parcheados\n\nOriginal 1:\n\n```text\nじぞうのうたを いれるのじゃ!\n```\n\nTest español:\n\n```text\nCanto de Jizo!\n```\n\nOffset: `0x1F55A-0x1F56D`, longitud original 20 bytes.\n\nOriginal 2:\n\n```text\nじぞうのうたが ちがっとるぞ!\nちゃんと かくにんして\nもういちど いれなおすのじゃ!\n```\n\nTest español:\n\n```text\n¡Canto incorrecto!\nRevísalo bien\nPrueba otra vez.\n```\n\nOffset: `0x1F56E-0x1F5A4`, longitud original 55 bytes.\n\n## Traducción final deseada\n\nLa versión final preferida sigue siendo:\n\n```text\n¡Introduce el canto de Jizo!\n¡El canto de Jizo no es correcto!\nCompruébalo bien\ne inténtalo otra vez.\n```\n\nEsa versión no cabe en los espacios originales. Requerirá repunteo/reubicación cuando tengamos documentado el sistema de punteros de este bloque.\n\n## Regiones cambiadas\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in records)}\n''',encoding='utf-8')
print('ROM:',OUT)
print('IPS:',IPS)
print('REPORT:',REPORT)
print('seg1',seg1.hex(' '))
print('seg2',seg2.hex(' '))
print('records',len(records),'bytes',sum(len(b) for _,b in records))
