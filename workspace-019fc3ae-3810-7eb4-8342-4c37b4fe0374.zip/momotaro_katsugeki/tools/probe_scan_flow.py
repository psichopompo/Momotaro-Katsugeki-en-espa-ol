#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; SRM=sys.argv[2]
out=Path('/home/user/momotaro_katsugeki/images/flowscan'); out.mkdir(parents=True,exist_ok=True)
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
def box(r):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    def white(x,y):
        row=data[y*p:y*p+w*2]; b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
        r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
        return ((r5<<3)|(r5>>2))==255 and ((g6<<2)|(g6>>4))==255 and ((b5<<3)|(b5>>2))==255
    for yy in range(50,200,5):
        cols=[x for x in range(w) if white(x,yy)]
        if cols and len(cols)>=2:
            return (min(cols),max(cols))
    return None
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
try:
    last=None; prev=None
    for f in range(0,6000):
        r.run(1,{})
        b=box(r)
        if b!=last:
            print(f"  frame {f}: box {b}")
            last=b
            if b and b[0]<=70 and b[1]>=185 and b!=(64,191) and b!=(66,189):
                save(r, out/f"cand_{f}.png")
        if f in (100,300,600,900,1500,2200,3000,4000,5000):
            save(r, out/f"snap_{f}.png")
    print("done")
finally:
    r.close()
