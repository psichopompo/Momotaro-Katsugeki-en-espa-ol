from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path('/home/user/momotaro_katsugeki')
rom=(ROOT/'work/Momotarou Katsugeki (Japan).pce').read_bytes()
font_base=0x4000
# Original title font: index = source - 0x30; 2bpp: first 8 plane0, next 8 plane1.
def decode_glyph(data):
    pix=[]
    for y in range(8):
        b0=data[y]; b1=data[8+y]
        row=[]
        for x in range(8):
            bit=7-x
            row.append(((b0>>bit)&1)|(((b1>>bit)&1)<<1))
        pix.append(row)
    return pix

def glyph_from_rows(rows):
    pix=[]
    for r in rows:
        row=[]
        for ch in r.ljust(8,'.')[:8]:
            row.append({'.':0,'1':1,'2':2,'3':3}.get(ch,0))
        pix.append(row)
    return pix

def get_char(ch):
    idx=ord(ch)-0x30
    return decode_glyph(rom[font_base+idx*16:font_base+idx*16+16])

variants={
'A': [
    '...11...',
    '..11....',
    '.11112..',
    '1122112.',
    '112..112',
    '112..112',
    '1122112.',
    '.22222..',
],
'B': [
    '..11....',
    '.11.....',
    '..1111..',
    '.112211.',
    '112..112',
    '112..112',
    '.112211.',
    '..2222..',
],
'C': [
    '...1....',
    '..1.....',
    '.1111...',
    '11..11..',
    '11..11..',
    '11..11..',
    '.1111...',
    '..2222..',
],
'D': [
    '...11...',
    '.111112.',
    '11222112',
    '112..112',
    '112..112',
    '112..112',
    '21111122',
    '.222222.',
],
'E': [
    '..111...',
    '.111112.',
    '11222112',
    '112..112',
    '112..112',
    '112..112',
    '21111122',
    '.222222.',
],
'F': [
    '..111...',
    '.11.....',
    '.11112..',
    '1122112.',
    '112..112',
    '112..112',
    '1122112.',
    '.22222..',
],
'G': [
    '.11.....',
    '..11....',
    '.111112.',
    '11222112',
    '112..112',
    '112..112',
    '21111122',
    '.222222.',
],
'H': [
    '...11...',
    '..11....',
    '..1111..',
    '.112211.',
    '.12..12.',
    '.12..12.',
    '.112211.',
    '..2222..',
],
}
# palette approximate to title prompt: bg, front yellow, shadow orange, bright yellow/white
pal=[(0,0,80),(255,240,48),(180,104,0),(255,255,160)]
scale=4

def render_glyph(pix, scale=4):
    im=Image.new('RGB',(8*scale,8*scale),pal[0])
    for y,row in enumerate(pix):
        for x,c in enumerate(row):
            if c:
                for yy in range(scale):
                    for xx in range(scale):
                        im.putpixel((x*scale+xx,y*scale+yy),pal[c])
    return im

def render_text(text, glyph_variant, scale=3):
    chars=[]
    for ch in text:
        if ch=='Ó': chars.append(glyph_variant)
        elif ch==' ': chars.append([[0]*8 for _ in range(8)])
        else: chars.append(get_char(ch))
    im=Image.new('RGB',(len(chars)*8*scale,8*scale),pal[0])
    for i,g in enumerate(chars):
        gi=render_glyph(g,scale)
        im.paste(gi,(i*8*scale,0))
    return im

# Build sheet.
cell_w=420; cell_h=116; cols=2; rows=(len(variants)+1)//2
sheet=Image.new('RGB',(cols*cell_w,rows*cell_h),(235,235,235))
d=ImageDraw.Draw(sheet)
for idx,(name,rows_def) in enumerate(variants.items()):
    x=(idx%cols)*cell_w; y=(idx//cols)*cell_h
    d.text((x+8,y+6),f'Diseño {name}',fill=(0,0,0))
    glyph=glyph_from_rows(rows_def)
    sheet.paste(render_glyph(glyph,6),(x+8,y+24))
    sample=render_text('BOTÓN',glyph,4)
    sheet.paste(sample,(x+72,y+28))
    sample2=render_text('PULSA BOTÓN RUN',glyph,2)
    sheet.paste(sample2,(x+72,y+72))
    # Draw grid around glyph
    d.rectangle([x+8,y+24,x+8+48-1,y+24+48-1],outline=(0,0,0))
    for gx in range(1,8): d.line([x+8+gx*6,y+24,x+8+gx*6,y+24+48],fill=(120,120,120))
    for gy in range(1,8): d.line([x+8,y+24+gy*6,x+8+48,y+24+gy*6],fill=(120,120,120))
out=ROOT/'images/title_O_accent_designs.png'
sheet.save(out)
print(out)
