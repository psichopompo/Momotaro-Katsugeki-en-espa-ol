#!/usr/bin/env python3
"""Start ROM without save, capture frames to see the title/menu flow and trace txtlog."""
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]
out=Path('/home/user/momotaro_katsugeki/images/nosave'); out.mkdir(parents=True,exist_ok=True)
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=None)
try:
    r.enable_txtlog()
    # run up to 600 frames, capture at key points, press nothing first
    for f in range(600):
        r.run(1,{})
        if f in (30,60,120,180,240,300,400,500,600):
            save(r, out/f"f{f}.png")
            print(f"f{f} saved; txtlog={len(r.txtlog())}")
    print("done")
finally:
    r.close()
