#!/usr/bin/env python3
from __future__ import annotations
import ctypes as C
from pathlib import Path

# Minimal libretro frontend for beetle-pce-fast-libretro instrumentation.
RETRO_ENVIRONMENT_SET_PIXEL_FORMAT = 10
RETRO_ENVIRONMENT_GET_CAN_DUPE = 3
RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS = 11
RETRO_ENVIRONMENT_SET_VARIABLES = 16
RETRO_ENVIRONMENT_GET_VARIABLE = 15
RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME = 18
RETRO_ENVIRONMENT_SET_CONTROLLER_INFO = 35
RETRO_ENVIRONMENT_SET_GEOMETRY = 37
RETRO_ENVIRONMENT_GET_LOG_INTERFACE = 27
RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY = 9
RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY = 31
RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION = 52
RETRO_ENVIRONMENT_SET_CORE_OPTIONS = 53
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL = 54
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2 = 67
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL = 68
RETRO_ENVIRONMENT_GET_RUMBLE_INTERFACE = 23
RETRO_PIXEL_FORMAT_RGB565 = 2
RETRO_DEVICE_JOYPAD = 1
RETRO_MEMORY_SAVE_RAM = 0
RETRO_MEMORY_SYSTEM_RAM = 2

# El runner vive en <workspace>/momotaro_katsugeki/tools/.
# Resolver desde __file__ evita depender de una ruta absoluta del sandbox.
DEFAULT_CORE_PATH = (
    Path(__file__).resolve().parents[2]
    / "emutools/beetle-pce-fast-libretro/mednafen_pce_fast_libretro.so"
)

class RetroGameInfo(C.Structure):
    _fields_ = [
        ("path", C.c_char_p),
        ("data", C.c_void_p),
        ("size", C.c_size_t),
        ("meta", C.c_char_p),
    ]

class RetroSystemInfo(C.Structure):
    _fields_ = [
        ("library_name", C.c_char_p),
        ("library_version", C.c_char_p),
        ("valid_extensions", C.c_char_p),
        ("need_fullpath", C.c_bool),
        ("block_extract", C.c_bool),
    ]

class RetroSystemAVInfo(C.Structure):
    pass

class Geometry(C.Structure):
    _fields_ = [("base_width", C.c_uint), ("base_height", C.c_uint), ("max_width", C.c_uint), ("max_height", C.c_uint), ("aspect_ratio", C.c_float)]
class Timing(C.Structure):
    _fields_ = [("fps", C.c_double), ("sample_rate", C.c_double)]
RetroSystemAVInfo._fields_ = [("geometry", Geometry), ("timing", Timing)]

ENV_CB = C.CFUNCTYPE(C.c_bool, C.c_uint, C.c_void_p)
VIDEO_CB = C.CFUNCTYPE(None, C.c_void_p, C.c_uint, C.c_uint, C.c_size_t)
AUDIO_CB = C.CFUNCTYPE(None, C.c_int16, C.c_int16)
AUDIO_BATCH_CB = C.CFUNCTYPE(C.c_size_t, C.POINTER(C.c_int16), C.c_size_t)
INPUT_POLL_CB = C.CFUNCTYPE(None)
INPUT_STATE_CB = C.CFUNCTYPE(C.c_int16, C.c_uint, C.c_uint, C.c_uint, C.c_uint)

class Runner:
    def __init__(self, rom_path: str | Path, out_dir: str | Path | None = None,
                 core_path: str | Path = DEFAULT_CORE_PATH,
                 save_ram_path: str | Path | None = None):
        self.rom_path = Path(rom_path).resolve()
        self.out_dir = Path(out_dir) if out_dir else None
        if self.out_dir: self.out_dir.mkdir(parents=True, exist_ok=True)
        self.core = C.CDLL(str(Path(core_path).resolve()))
        self.buttons: set[int] = set()
        self.frame = 0
        self.last_frame = None
        self.last_w = 0; self.last_h = 0; self.last_pitch = 0
        self._keepalive = []
        self._setup_api()
        self._setup_callbacks()
        self.core.retro_init()
        info = RetroSystemInfo(); self.core.retro_get_system_info(C.byref(info))
        self.system_info = info
        # Load by full path; core advertises need_fullpath.
        game = RetroGameInfo(str(self.rom_path).encode(), None, 0, None)
        ok = self.core.retro_load_game(C.byref(game))
        if not ok:
            raise RuntimeError(f"retro_load_game failed for {self.rom_path}")
        if save_ram_path is not None:
            self.load_save_ram(save_ram_path)
        av = RetroSystemAVInfo(); self.core.retro_get_system_av_info(C.byref(av)); self.av = av

    def _setup_api(self):
        c=self.core
        c.retro_set_environment.argtypes=[ENV_CB]
        c.retro_set_video_refresh.argtypes=[VIDEO_CB]
        c.retro_set_audio_sample.argtypes=[AUDIO_CB]
        c.retro_set_audio_sample_batch.argtypes=[AUDIO_BATCH_CB]
        c.retro_set_input_poll.argtypes=[INPUT_POLL_CB]
        c.retro_set_input_state.argtypes=[INPUT_STATE_CB]
        c.retro_get_system_info.argtypes=[C.POINTER(RetroSystemInfo)]
        c.retro_get_system_av_info.argtypes=[C.POINTER(RetroSystemAVInfo)]
        c.retro_load_game.argtypes=[C.POINTER(RetroGameInfo)]; c.retro_load_game.restype=C.c_bool
        c.retro_run.argtypes=[]
        c.retro_get_memory_data.argtypes=[C.c_uint]; c.retro_get_memory_data.restype=C.c_void_p
        c.retro_get_memory_size.argtypes=[C.c_uint]; c.retro_get_memory_size.restype=C.c_size_t
        # instrumentation exports
        c.arena_vramlog_set_enabled.argtypes=[C.c_int]
        c.arena_vramlog_set_frame.argtypes=[C.c_uint]
        c.arena_vramlog_set_range.argtypes=[C.c_uint,C.c_uint]
        c.arena_vramlog_reset.argtypes=[]
        c.arena_vramlog_count_get.restype=C.c_uint
        c.arena_vramlog_ptr.restype=C.c_void_p
        c.arena_pce_get_vram.restype=C.POINTER(C.c_uint16)
        c.arena_pce_get_sat.restype=C.POINTER(C.c_uint16)
        c.arena_pce_get_satb.restype=C.c_uint16
        c.arena_pce_get_mwr.restype=C.c_uint16
        c.arena_pce_get_batr.restype=C.c_uint16
        c.arena_pce_get_bxr.restype=C.c_uint16
        c.arena_pce_get_byr.restype=C.c_uint16
        c.arena_pce_set_vram_word.argtypes=[C.c_uint32,C.c_uint16]
        c.arena_layer_set_enabled.argtypes=[C.c_int]
        c.arena_layer_set_frame.argtypes=[C.c_uint32]
        c.arena_layer_set_scanline.argtypes=[C.c_int]
        c.arena_layer_get_buf.restype=C.POINTER(C.c_uint8)
        c.arena_layer_get_sprtile.restype=C.POINTER(C.c_uint16)
        c.arena_layer_get_w.restype=C.c_uint32
        c.arena_layer_get_h.restype=C.c_uint32
        c.arena_layer_get_frame.restype=C.c_uint32
        c.arena_pce_get_mpr_ptr.restype=C.POINTER(C.c_uint8)
        c.arena_pce_get_pc.restype=C.c_uint
        c.arena_jsrlog_set_enabled.argtypes=[C.c_int]
        c.arena_jsrlog_set_frame.argtypes=[C.c_uint]
        c.arena_jsrlog_set_target.argtypes=[C.c_uint]
        c.arena_jsrlog_reset.argtypes=[]
        c.arena_jsrlog_count_get.restype=C.c_uint
        c.arena_jsrlog_ptr.restype=C.c_void_p
        c.arena_bramlog_set_enabled.argtypes=[C.c_int]
        c.arena_bramlog_set_frame.argtypes=[C.c_uint]
        c.arena_bramlog_reset.argtypes=[]
        c.arena_bramlog_count_get.restype=C.c_uint
        c.arena_bramlog_ptr.restype=C.c_void_p
        c.arena_bramlog_control_read.argtypes=[C.c_uint]
        c.arena_bramlog_control_read.restype=C.c_uint8
        c.arena_ramlog_set_enabled.argtypes=[C.c_int]
        c.arena_ramlog_set_frame.argtypes=[C.c_uint]
        c.arena_ramlog_set_range.argtypes=[C.c_uint,C.c_uint]
        c.arena_ramlog_reset.argtypes=[]
        c.arena_ramlog_count_get.restype=C.c_uint
        c.arena_ramlog_ptr.restype=C.c_void_p
        c.arena_aa16log_set_enabled.argtypes=[C.c_int]
        c.arena_aa16log_set_frame.argtypes=[C.c_uint]
        c.arena_aa16log_reset.argtypes=[]
        c.arena_aa16log_count_get.restype=C.c_uint
        c.arena_aa16log_ptr.restype=C.c_void_p
        c.arena_glyphlog_set_enabled.argtypes=[C.c_int]
        c.arena_glyphlog_set_frame.argtypes=[C.c_uint]
        c.arena_glyphlog_reset.argtypes=[]
        c.arena_glyphlog_count_get.restype=C.c_uint
        c.arena_glyphlog_ptr.restype=C.c_void_p
        c.arena_boxptrlog_set_enabled.argtypes=[C.c_int]
        c.arena_boxptrlog_set_frame.argtypes=[C.c_uint]
        c.arena_boxptrlog_reset.argtypes=[]
        c.arena_boxptrlog_count_get.restype=C.c_uint
        c.arena_boxptrlog_ptr.restype=C.c_void_p
        c.arena_splog_set_enabled.argtypes=[C.c_int]
        c.arena_splog_reset.argtypes=[]
        c.arena_splog_count_get.restype=C.c_uint
        c.arena_splog_ptr.restype=C.c_void_p
        c.arena_retlog_set_enabled.argtypes=[C.c_int]
        c.arena_retlog_reset.argtypes=[]
        c.arena_retlog_count_get.restype=C.c_uint
        c.arena_retlog_ptr.restype=C.c_void_p
        c.arena_txtlog_set_enabled.argtypes=[C.c_int]
        c.arena_txtlog_reset.argtypes=[]
        c.arena_txtlog_count_get.restype=C.c_uint
        c.arena_txtlog_ptr.restype=C.c_void_p
        c.arena_fontlog_set_enabled.argtypes=[C.c_int]
        c.arena_fontlog_reset.argtypes=[]
        c.arena_fontlog_count_get.restype=C.c_uint
        c.arena_fontlog_ptr.restype=C.c_void_p
        c.arena_dstlog_set_enabled.argtypes=[C.c_int]
        c.arena_dstlog_reset.argtypes=[]
        c.arena_dstlog_count_get.restype=C.c_uint
        c.arena_dstlog_ptr.restype=C.c_void_p
        c.arena_get_baseram.restype=C.POINTER(C.c_uint8)
        c.arena_bpx_set_enabled.argtypes=[C.c_int]
        c.arena_bpx_reset.argtypes=[]
        c.arena_bpx_count_get.restype=C.c_uint
        c.arena_bpx_ptr.restype=C.c_void_p
        c.arena_menudata_set_enabled.argtypes=[C.c_int]
        c.arena_menudata_reset.argtypes=[]
        c.arena_menudata_count_get.restype=C.c_uint
        c.arena_menudata_ptr.restype=C.c_void_p

    def _setup_callbacks(self):
        # Need stable storage for returned strings/vars.
        self._pixel_format = C.c_uint(RETRO_PIXEL_FORMAT_RGB565)
        self._can_dupe = C.c_bool(True)
        self._sysdir = C.c_char_p(str((self.out_dir or Path('/tmp')).resolve()).encode())
        self._savedir = self._sysdir

        def environ(cmd, data):
            if cmd == RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
                # core asks for RGB565/XRGB8888 etc.; accept.
                return True
            if cmd == RETRO_ENVIRONMENT_GET_CAN_DUPE:
                C.cast(data, C.POINTER(C.c_bool))[0] = True; return True
            if cmd in (RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY, RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY):
                C.cast(data, C.POINTER(C.c_char_p))[0] = self._sysdir.value; return True
            if cmd == RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
                C.cast(data, C.POINTER(C.c_uint))[0] = 2; return True
            if cmd == RETRO_ENVIRONMENT_GET_VARIABLE:
                return False
            # Accept setters by default.
            if cmd in (RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS, RETRO_ENVIRONMENT_SET_VARIABLES, RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME, RETRO_ENVIRONMENT_SET_CONTROLLER_INFO, RETRO_ENVIRONMENT_SET_GEOMETRY, RETRO_ENVIRONMENT_SET_CORE_OPTIONS, RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL, RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2, RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL):
                return True
            return False

        def video(data, w, h, pitch):
            self.last_w=int(w); self.last_h=int(h); self.last_pitch=int(pitch)
            if data:
                # RGB565 copy
                size = int(pitch)*int(h)
                self.last_frame = C.string_at(data, size)

        def audio(l, r):
            return None
        def audio_batch(data, frames):
            return frames
        def input_poll():
            return None
        def input_state(port, device, index, id):
            if port == 0 and device == RETRO_DEVICE_JOYPAD and int(id) in self.buttons:
                return 1
            return 0
        self._env_cb=ENV_CB(environ); self._video_cb=VIDEO_CB(video); self._audio_cb=AUDIO_CB(audio); self._audio_batch_cb=AUDIO_BATCH_CB(audio_batch); self._poll_cb=INPUT_POLL_CB(input_poll); self._state_cb=INPUT_STATE_CB(input_state)
        self._keepalive=[self._env_cb,self._video_cb,self._audio_cb,self._audio_batch_cb,self._poll_cb,self._state_cb]
        self.core.retro_set_environment(self._env_cb)
        self.core.retro_set_video_refresh(self._video_cb)
        self.core.retro_set_audio_sample(self._audio_cb)
        self.core.retro_set_audio_sample_batch(self._audio_batch_cb)
        self.core.retro_set_input_poll(self._poll_cb)
        self.core.retro_set_input_state(self._state_cb)

    def run(self, frames:int, events:dict[int, list[int]]|None=None, log_range:tuple[int,int]|None=None):
        events = events or {}
        if log_range:
            self.core.arena_vramlog_set_range(log_range[0], log_range[1])
            self.core.arena_vramlog_reset(); self.core.arena_vramlog_set_enabled(1)
        for _ in range(frames):
            if self.frame in events:
                self.buttons = set(events[self.frame])
            self.core.arena_vramlog_set_frame(self.frame)
            self.core.arena_jsrlog_set_frame(self.frame)
            self.core.arena_bramlog_set_frame(self.frame)
            self.core.arena_ramlog_set_frame(self.frame)
            self.core.arena_aa16log_set_frame(self.frame)
            self.core.arena_glyphlog_set_frame(self.frame)
            self.core.arena_boxptrlog_set_frame(self.frame)
            self.core.retro_run()
            self.frame += 1
        if log_range:
            self.core.arena_vramlog_set_enabled(0)

    def save_ram_size(self):
        return int(self.core.retro_get_memory_size(RETRO_MEMORY_SAVE_RAM))

    def read_save_ram(self):
        size = self.save_ram_size()
        ptr = self.core.retro_get_memory_data(RETRO_MEMORY_SAVE_RAM)
        if not ptr or not size:
            raise RuntimeError("El core no expone SaveRAM")
        return C.string_at(ptr, size)

    def read_system_ram(self):
        size = int(self.core.retro_get_memory_size(RETRO_MEMORY_SYSTEM_RAM))
        ptr = self.core.retro_get_memory_data(RETRO_MEMORY_SYSTEM_RAM)
        if not ptr or not size:
            raise RuntimeError("El core no expone System RAM")
        return C.string_at(ptr, size)

    def load_save_ram(self, path: str | Path):
        """Carga un SRM externo exactamente después de retro_load_game.

        El frontend es responsable de la persistencia de SaveRAM en libretro.
        No se guarda automáticamente nada de vuelta al fichero de origen.
        """
        src = Path(path).resolve()
        payload = src.read_bytes()
        expected = self.save_ram_size()
        if len(payload) != expected:
            raise ValueError(
                f"SRM de tamaño {len(payload)}; el core espera {expected} bytes"
            )
        ptr = self.core.retro_get_memory_data(RETRO_MEMORY_SAVE_RAM)
        if not ptr:
            raise RuntimeError("El core no expone SaveRAM")
        C.memmove(ptr, payload, expected)
        self.loaded_save_ram_path = src

    def vram_words(self):
        ptr=self.core.arena_pce_get_vram()
        return [ptr[i] for i in range(65536)]
    def sat_words(self):
        ptr=self.core.arena_pce_get_sat(); return [ptr[i] for i in range(256)]
    def sat_base(self):
        return int(self.core.arena_pce_get_satb())
    def mpr(self):
        ptr=self.core.arena_pce_get_mpr_ptr(); return [ptr[i] for i in range(8)]
    def pc(self): return int(self.core.arena_pce_get_pc())
    def vdc_regs(self):
        return dict(mwr=int(self.core.arena_pce_get_mwr()),
                    byr=int(self.core.arena_pce_get_byr()),
                    bxr=int(self.core.arena_pce_get_bxr()))
    def set_vram_word(self, addr, val):
        self.core.arena_pce_set_vram_word(int(addr), int(val))

    def enable_layer_capture(self, frame, scanline=-1):
        self.core.arena_layer_set_enabled(1)
        self.core.arena_layer_set_frame(int(frame))
        self.core.arena_layer_set_scanline(int(scanline))

    def disable_layer_capture(self):
        self.core.arena_layer_set_enabled(0)

    def get_layer_buf(self):
        w = int(self.core.arena_layer_get_w())
        h = int(self.core.arena_layer_get_h())
        ptr = self.core.arena_layer_get_buf()
        arr = C.cast(ptr, C.POINTER(C.c_uint8 * (w * h))).contents
        return [[int(arr[y * w + x]) for x in range(w)] for y in range(h)]

    def get_sprtile_buf(self):
        w = int(self.core.arena_layer_get_w())
        h = int(self.core.arena_layer_get_h())
        ptr = self.core.arena_layer_get_sprtile()
        arr = C.cast(ptr, C.POINTER(C.c_uint16 * (w * h))).contents
        return [[int(arr[y * w + x]) for x in range(w)] for y in range(h)]
    def vramlog(self):
        cnt=int(self.core.arena_vramlog_count_get())
        ptr=self.core.arena_vramlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*7))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*7+j]) for j in range(7)))
        return out
    def jsrlog(self):
        cnt=int(self.core.arena_jsrlog_count_get())
        ptr=self.core.arena_jsrlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*5))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*5+j]) for j in range(5)))
        return out

    def bramlog(self):
        cnt=int(self.core.arena_bramlog_count_get())
        ptr=self.core.arena_bramlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*7))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*7+j]) for j in range(7)))
        return out

    def enable_splog(self):
        self.core.arena_splog_set_enabled(1); self.core.arena_splog_reset()
    def disable_splog(self):
        self.core.arena_splog_set_enabled(0)
    def splog(self):
        cnt=int(self.core.arena_splog_count_get())
        ptr=self.core.arena_splog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*10))).contents if cnt else []
        return [tuple(int(arr[i*10+j]) for j in range(10)) for i in range(cnt)]

    def enable_txtlog(self):
        self.core.arena_txtlog_set_enabled(1); self.core.arena_txtlog_reset()
    def disable_txtlog(self):
        self.core.arena_txtlog_set_enabled(0)
    def txtlog(self):
        cnt=int(self.core.arena_txtlog_count_get())
        ptr=self.core.arena_txtlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*6))).contents if cnt else []
        return [tuple(int(arr[i*6+j]) for j in range(6)) for i in range(cnt)]

    def enable_fontlog(self):
        self.core.arena_fontlog_set_enabled(1); self.core.arena_fontlog_reset()
    def disable_fontlog(self):
        self.core.arena_fontlog_set_enabled(0)
    def fontlog(self):
        cnt=int(self.core.arena_fontlog_count_get())
        ptr=self.core.arena_fontlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*9))).contents if cnt else []
        return [tuple(int(arr[i*9+j]) for j in range(9)) for i in range(cnt)]


    def enable_dstlog(self):
        self.core.arena_dstlog_set_enabled(1); self.core.arena_dstlog_reset()
    def disable_dstlog(self):
        self.core.arena_dstlog_set_enabled(0)
    def dstlog(self):
        cnt=int(self.core.arena_dstlog_count_get())
        ptr=self.core.arena_dstlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*6))).contents if cnt else []
        return [tuple(int(arr[i*6+j]) for j in range(6)) for i in range(cnt)]


    def read_baseram(self):
        ptr=self.core.arena_get_baseram()
        return C.string_at(ptr, 32768)

    def enable_bpx(self):
        self.core.arena_bpx_set_enabled(1); self.core.arena_bpx_reset()
    def disable_bpx(self):
        self.core.arena_bpx_set_enabled(0)
    def bpx(self):
        cnt=int(self.core.arena_bpx_count_get())
        ptr=self.core.arena_bpx_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*8))).contents if cnt else []
        return [tuple(int(arr[i*8+j]) for j in range(8)) for i in range(cnt)]

    def enable_menudata(self):
        self.core.arena_menudata_set_enabled(1); self.core.arena_menudata_reset()
    def disable_menudata(self):
        self.core.arena_menudata_set_enabled(0)
    def menudata(self):
        cnt=int(self.core.arena_menudata_count_get())
        ptr=self.core.arena_menudata_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*18))).contents if cnt else []
        return [tuple(int(arr[i*18+j]) for j in range(18)) for i in range(cnt)]

    def ramlog(self):
        cnt=int(self.core.arena_ramlog_count_get())
        ptr=self.core.arena_ramlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*7))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*7+j]) for j in range(7)))
        return out

    def aa16log(self):
        cnt=int(self.core.arena_aa16log_count_get())
        ptr=self.core.arena_aa16log_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*6))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*6+j]) for j in range(6)))
        return out

    def glyphlog(self):
        cnt=int(self.core.arena_glyphlog_count_get())
        ptr=self.core.arena_glyphlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*8))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*8+j]) for j in range(8)))
        return out

    def boxptrlog(self):
        cnt=int(self.core.arena_boxptrlog_count_get())
        ptr=self.core.arena_boxptrlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*9))).contents if cnt else []
        out=[]
        for i in range(cnt):
            out.append(tuple(int(arr[i*9+j]) for j in range(9)))
        return out

    def reset(self):
        """Soft-reset the game (returns to title) without losing battery RAM."""
        self.core.retro_reset()

    def load_state(self, path):
        """Load a RetroArch save state (.state). Returns True on success.
        Handles both raw serialized data and the RetroArch RASTATE container."""
        import zlib
        data=Path(path).read_bytes()
        # If RASTATE container (zlib), decompress and take the MEM section (after 16-byte header)
        if data[:7]==b'RASTATE' or (len(data)>6 and data[:3]==b'#RZ'):
            try:
                raw=zlib.decompress(data[24:])
            except Exception:
                raw=data
            payload=raw[16:]
        else:
            payload=data
        buf=C.create_string_buffer(payload)
        self.core.retro_unserialize.argtypes=[C.c_void_p, C.c_size_t]
        self.core.retro_unserialize.restype=C.c_bool
        ok=self.core.retro_unserialize(C.cast(buf, C.c_void_p), len(payload))
        return bool(ok)

    def close(self):
        try: self.core.retro_unload_game(); self.core.retro_deinit()
        except Exception: pass


    def enable_retlog(self):
        self.core.arena_retlog_set_enabled(1); self.core.arena_retlog_reset()
    def disable_retlog(self):
        self.core.arena_retlog_set_enabled(0)
    def retlog(self):
        cnt=int(self.core.arena_retlog_count_get())
        ptr=self.core.arena_retlog_ptr()
        arr=C.cast(ptr, C.POINTER(C.c_uint32 * (cnt*12))).contents if cnt else []
        return [tuple(int(arr[i*12+j]) for j in range(12)) for i in range(cnt)]
if __name__ == '__main__':
    import sys
    r=Runner(sys.argv[1], '/tmp/pce_runner_test')
    r.run(10)
    print('ok', r.last_w, r.last_h, r.mpr(), hex(r.pc()))
    r.close()
