#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
SRC='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_melo.pce'
STATE='/home/user/downloads/momotaro.state'
SRM='/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm'
def probe(force):
    r=Runner(Path(SRC), Path('/tmp'), save_ram_path=SRM)
    try:
        r.load_state(STATE)
        for _ in range(40): r.run(1,{})
        for _ in range(60): r.buttons={3}; r.run(1,{})
        r.buttons=set()
        for _ in range(150): r.run(1,{})
        if force is not None:
            for _ in range(5):
                r.core.arena_get_baseram()[0x1C86]=force
                r.run(1,{})
        # SAT X of melocoton
        sat=r.sat_words()
        sx=None
        for i in range(64):
            if (sat[i*4+2]>>1)&0x3ff==0x1a0: sx=sat[i*4+1]&0x3ff
        # on-screen pixel of melocoton center
        w,h,pitch=r.last_w,r.last_h,r.last_pitch
        data=r.last_frame; img=Image.new('RGB',(w,h)); px=img.load(); stride=pitch
        for y in range(h):
            row=data[y*stride:y*stride+w*2]
            for x in range(w):
                b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
                r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
                px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
        def mel(x,y): c=px[x,y]; return c[0]>150 and 60<c[1]<170 and c[2]<170
        xs=[x for y in range(80,92) for x in range(0,256) if mel(x,y)]
        return sx,(min(xs),max(xs))
    finally: r.close()
for force,label in [(0x50,'base'),(0x27,'-41px'),(0x20,'-48px')]:
    sx,pxr=probe(force)
    print('%s: SAT_X=%s on-screen_x[%d-%d] diff=%d'%(label,sx,pxr[0],pxr[1],sx-pxr[0]))
