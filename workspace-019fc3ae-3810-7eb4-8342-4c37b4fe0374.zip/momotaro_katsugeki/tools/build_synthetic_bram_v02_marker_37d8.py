#!/usr/bin/env python3
"""BRAM sintética v02: experimento inyectado de una variable ya trazada.

Parte de la construcción estructural v01. Cambia sólo el byte BRAM $0061 para
que, tras la rutina medida D20B-D217, System RAM $37D8 sea $03 en lugar de
$02. Recalcula el checksum; no lee ningún SRM externo.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_synthetic_bram_v01 import BODY_OFFSET, RECORD_SIZE, RECORD_START, build, checksum_complement_16

BRAM_OFFSET = 0x61
KEY_OFFSET = 0x7F
TARGET_DECODED_VALUE = 0x03


def build_v02() -> bytearray:
    bram = build()
    key = bram[KEY_OFFSET]
    assert bram[BRAM_OFFSET] ^ key == 0x02

    # D20B-D217 ejecuta: $37D8,X ^= $37F6, para X=0..$15.
    bram[BRAM_OFFSET] = TARGET_DECODED_VALUE ^ key

    body = bytes(bram[BODY_OFFSET:RECORD_START + RECORD_SIZE])
    checksum = checksum_complement_16(body)
    bram[RECORD_START + 2:RECORD_START + 4] = checksum.to_bytes(2, "little")

    assert bram[BRAM_OFFSET] == 0x90
    assert bram[BRAM_OFFSET] ^ bram[KEY_OFFSET] == TARGET_DECODED_VALUE
    assert (sum(body) + checksum) & 0xFFFF == 0
    return bram


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("output", type=Path, help="Destino nuevo; se rechaza sobrescribir")
    args = ap.parse_args()
    out = args.output.resolve()
    if out.exists():
        raise SystemExit(f"El destino ya existe: {out}")
    bram = build_v02()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(bram)
    print(f"output={out}")
    print("provenance=injected synthetic experiment; decoded $37D8=$03")
    print(f"bram_0061=${bram[0x61]:02X} key_007F=${bram[0x7F]:02X}")
    print(f"checksum=${int.from_bytes(bram[0x12:0x14], 'little'):04X}")
    print(f"md5={hashlib.md5(bram).hexdigest()}")
    print(f"sha1={hashlib.sha1(bram).hexdigest()}")
    print(f"sha256={hashlib.sha256(bram).hexdigest()}")
    print(f"crc32={zlib.crc32(bram) & 0xFFFFFFFF:08x}")


if __name__ == "__main__":
    main()
