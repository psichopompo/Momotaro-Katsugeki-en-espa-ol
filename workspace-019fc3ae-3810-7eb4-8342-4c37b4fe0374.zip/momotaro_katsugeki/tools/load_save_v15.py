#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; SRM=sys.argv[2]
out=Path('/home/user/momotaro_katsugeki/images/savev15'); out.mkdir(parents=True,exist_ok=True)
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
try:
    for i in range(300):
        r.run(1,{})
        if i in (10,20,40,60,80,100,140,200,299):
            save(r, out/f"s_{i}.png")
        # dump SAT text sprites at key frames
        if i in (60,140,299):
            sat=r.sat_words()
            txt=[(j,(sat[j*4+2]>>1)&0x3ff,sat[j*4+1]&0x3ff,(sat[j*4+0]&0x3ff)-0x40) for j in range(64) if 0x1C0<=((sat[j*4+2]>>1)&0x3ff)<=0x1D9]
            print(f"frame {i} text sprites 0x1c0-0x1d9: {txt}")
    print("saved")
finally:
    r.close()
