#!/usr/bin/env python3
from pathlib import Path
import csv, sys
sys.path.append(str(Path(__file__).parent))
from decode_text import decode_bytes

ROOT=Path('/home/user/momotaro_katsugeki')
ROM=ROOT/'work/Momotarou Katsugeki (Japan).pce'
OUT=ROOT/'translation/known_text_blocks.tsv'
OUT.parent.mkdir(parents=True,exist_ok=True)
D=ROM.read_bytes()

ranges=[
    ('intro_house_tutorial_password',0x1F000,0x1F650),
    ('ending_credits',0x3B800,0x3C850),
    ('shops_items_stage_text',0x48000,0x48F50),
    ('village_dialogues_1',0x48E40,0x49F00),
    ('village_dialogues_2',0x49F00,0x4A760),
    ('ending_staff_alt',0x4A4A0,0x4A760),
    ('gambling_sennin_quiz',0x4AC40,0x4B520),
]

def score_text(bs):
    # count kana-ish / ascii letters / controls common in text
    return sum(1 for b in bs if 0xA0<=b<=0xDF or b in (0,0x20,0x3B,0x3C,0x3D,0x5C,0x21,0x3F,0xFC,0xFD,0xFE,0xFF))

def split_segments(start,end):
    # Split on FF, keep nontrivial segments. Some ranges contain long concatenated zero-separated text;
    # this is still useful as block-level extraction.
    segs=[]; s=start; i=start
    while i<end:
        if D[i]==0xFF:
            e=i+1
            raw=D[s:e]
            if len(raw)>=4 and score_text(raw)/max(1,len(raw))>0.45:
                segs.append((s,e,raw))
            s=e
        i+=1
    if s<end:
        raw=D[s:end]
        if len(raw)>=4 and score_text(raw)/max(1,len(raw))>0.45:
            segs.append((s,end,raw))
    return segs

rows=[]
for name,start,end in ranges:
    for n,(s,e,raw) in enumerate(split_segments(start,end)):
        txt=decode_bytes(raw).replace('\r','')
        # remove huge binary-looking segments by requiring at least one kana or ASCII text keyword after decode
        if not any('\u3040'<=ch<='\u309f' or 'A'<=ch<='Z' or 'a'<=ch<='z' for ch in txt):
            continue
        rows.append({
            'id':f'{name}_{n:03d}',
            'range':name,
            'start_hex':f'{s:06X}',
            'end_hex':f'{e:06X}',
            'length':e-s,
            'bank_8k':f'{s//0x2000:02X}',
            'cpu_addr_if_8000':f'{0x8000+(s%0x2000):04X}',
            'cpu_addr_if_4000':f'{0x4000+(s%0x2000):04X}',
            'jp_decoded':txt,
            'es_translation':'',
            'notes':'',
        })

with OUT.open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()),delimiter='\t')
    w.writeheader(); w.writerows(rows)
print('wrote',OUT,'rows',len(rows))
# Also markdown sample
MD=ROOT/'translation/known_text_blocks_preview.md'
with MD.open('w',encoding='utf-8') as f:
    f.write('# Preview de bloques de texto conocidos\n\n')
    for r in rows[:80]:
        f.write(f"## {r['id']} — 0x{r['start_hex']}-0x{r['end_hex']} len {r['length']}\n\n")
        f.write('```text\n'+r['jp_decoded'][:2000]+'\n```\n\n')
print('wrote',MD)
