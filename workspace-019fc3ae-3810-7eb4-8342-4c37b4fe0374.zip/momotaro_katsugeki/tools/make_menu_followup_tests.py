#!/usr/bin/env python3
from pathlib import Path

ROOT=Path('/home/user/momotaro_katsugeki')
ORIG=ROOT/'work/Momotarou Katsugeki (Japan).pce'
LATIN_BASE=ROOT/'work/Momotarou Katsugeki (Japan) - latin_charset_test_v2.pce'
orig=ORIG.read_bytes()

def write_ips(out_path, ips_path, rom):
    out_path.write_bytes(rom)
    records=[]; i=0
    while i<len(orig):
        if orig[i]==rom[i]:
            i+=1; continue
        s=i; buf=bytearray()
        while i<len(orig) and orig[i]!=rom[i] and len(buf)<0xFFFF:
            buf.append(rom[i]); i+=1
        records.append((s,bytes(buf)))
    ips=bytearray(b'PATCH')
    for off,buf in records:
        ips += off.to_bytes(3,'big')+len(buf).to_bytes(2,'big')+buf
    ips += b'EOF'
    ips_path.write_bytes(ips)
    return records

# 1) Title prompt v2: stronger Ó accent.
rom=bytearray(orig)
text=b'PULSA<BOT'+bytes([0x5B])+b'N<RUN<'
assert len(text)==16
rom[0x18E85:0x18E95]=text
# Glyph index $2B at bank02 offset $42B0. 2bpp 16 bytes, plane0 rows + plane1 rows.
rows=[
    '..33....',  # stronger visible acute/accent marker
    '.111112.',
    '11222112',
    '112..112',
    '112..112',
    '112..112',
    '21111122',
    '.222222.',
]
p0=[]; p1=[]
for r in rows:
    b0=b1=0
    for ch in r:
        c={'.':0,'1':1,'2':2,'3':3}[ch]
        b0=(b0<<1)|(c&1); b1=(b1<<1)|((c>>1)&1)
    p0.append(b0); p1.append(b1)
rom[0x42B0:0x42C0]=bytes(p0+p1)
rec1=write_ips(ROOT/'work/Momotarou Katsugeki (Japan) - start_prompt_tilde_test_v2.pce', ROOT/'work/momotaro_start_prompt_tilde_test_v2.ips', bytes(rom))

# 2) Jizo text v2: avoid auto-wrap/overlap, preserve control in fixed slots.
rom=bytearray(LATIN_BASE.read_bytes())
# Restore repertoire test area to original for clean test except font/table patches remain.
rom[0x1F078:0x1F10C]=orig[0x1F078:0x1F10C]
char_to_code={' ':0x20}
for i in range(10): char_to_code[str(i)]=0x30+i
for i in range(26): char_to_code[chr(ord('A')+i)]=0x41+i
char_to_code.update({'!':0x21,'?':0x3F,'$':0x24})
for i,ch in enumerate('abcdefghijklmnopqrstuvwxyz'): char_to_code[ch]=0xA1+i
char_to_code['b']=0x5B; char_to_code['c']=0x5D; char_to_code['p']=0x5E
char_to_code.update({
    'á':0xBB,'é':0xBC,'í':0xBD,'ó':0xBE,'ú':0xBF,'ü':0xC0,'ñ':0xC1,
    'Á':0xC2,'É':0xC3,'Í':0xC4,'Ó':0xC5,'Ú':0xC6,'Ü':0xC7,'Ñ':0xC8,
    '¿':0xC9,'¡':0xCA,'.':0xCB,',':0xCC,':':0xCD,';':0xCE,'…':0xCF,
    "'":0xD0,'"':0xD1,'-':0xD2,'/':0xD3,'(':0xD4,')':0xD5,'%':0xD6,
    '&':0xD7,'+':0xD8,'¤':0xD9,'ç':0xDA,'º':0xDC,'ª':0xDD,'Ç':0x5F,
})
def enc(s): return bytes(char_to_code[ch] for ch in s)
def put_segment(start,end,parts):
    data=bytearray()
    for p in parts:
        if isinstance(p,int): data.append(p)
        else: data += p
    if len(data)>end-start-1:
        raise ValueError((hex(start),hex(end),len(data),end-start-1))
    full=data+bytes([0x20])*(end-start-1-len(data))+bytes([0xFF])
    rom[start:end]=full
# Fits original 20-byte slot: 1 control + 15 chars + spaces + FF
put_segment(0x1F55A,0x1F56E,[0x01, enc('¡Canto de Jizo!')])
# Fits original 55-byte slot, each line <= 15 chars to avoid auto-wrap.
put_segment(0x1F56E,0x1F5A5,[0x01, enc('¡Canto erróneo!'),0x00, enc('Revísalo bien'),0x00, enc('Prueba de nuevo')])
rec2=write_ips(ROOT/'work/Momotarou Katsugeki (Japan) - jizo_text_test_v2.pce', ROOT/'work/momotaro_jizo_text_test_v2.ips', bytes(rom))

# Report
(ROOT/'reports/pruebas_menu_jizo_v2.md').write_text(f'''# Pruebas v2 — prompt de título y texto de Jizo\n\n## Prompt de título con tilde reforzada\n\nROM: `work/Momotarou Katsugeki (Japan) - start_prompt_tilde_test_v2.pce`\n\nIPS: `work/momotaro_start_prompt_tilde_test_v2.ips`\n\nTexto:\n\n```text\nPULSA BOTÓN RUN\n```\n\nCambio frente a v1: se refuerza el glyph de `Ó` en la fuente de título. La limitación es que esta fuente de 8x8 no tiene espacio real por encima; por tanto se intenta hacer la tilde más visible dentro del mismo tile.\n\nRegiones cambiadas:\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in rec1)}\n\n## Texto Jizo/password v2\n\nROM: `work/Momotarou Katsugeki (Japan) - jizo_text_test_v2.pce`\n\nIPS: `work/momotaro_jizo_text_test_v2.ips`\n\nObjetivo: evitar el auto-wrap que cortaba `incorrecto!` y hacía que `Revísalo bien` sobreescribiera la parte sobrante.\n\nTextos de prueba:\n\n```text\n¡Canto de Jizo!\n\n¡Canto erróneo!\nRevísalo bien\nPrueba de nuevo\n```\n\nCada línea está limitada a 15 caracteres o menos, que parece ser el ancho seguro del bocadillo pequeño.\n\nLa traducción final elegida sigue siendo:\n\n```text\n¡Introduce el canto de Jizo!\n¡El canto de Jizo no es correcto!\nCompruébalo bien\ne inténtalo otra vez.\n```\n\nEsa versión requerirá repunteo/reubicación y/o bocadillo más ancho.\n\nRegiones cambiadas:\n\n{chr(10).join(f'- `0x{off:06X}` len `{len(buf)}`' for off,buf in rec2)}\n''',encoding='utf-8')

print('created title recs',rec1)
print('created jizo recs',len(rec2),sum(len(b) for _,b in rec2))
