#!/usr/bin/env python3
"""Aplica: (1) DIFICIL 1px abajo (y_rel 0x0F->0x10), (2) todo +3px derecha:
   pregunta x_rel +3, dificultad x_rel +3, melocoton ROM 0x1A704 0x27->0x2A."""
import sys, hashlib
SRC='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_melo2.pce'
OUT='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_shift3.pce'
d=bytearray(open(SRC,'rb').read())

def blk(idx, x, y):
    o=0x1FC05+idx*5
    d[o+3]=x; d[o+4]=y

print("=== 1) DIFICIL 1px abajo + 3px derecha ===")
# dificultad indices 1-5
difx=[0xE6,0x06,0x26,0x46,0x66]
for i,x in enumerate(difx):
    idx=i+1
    blk(idx, (x+3)&0xff, 0x10)  # y 0x0F->0x10, x +3
    print("  dif idx%d x 0x%02x->0x%02x y->0x10"%(idx,x,(x+3)&0xff))

print("=== 2) Pregunta +3px derecha ===")
qidx=[12,13,14,10,11,6]
qx=[0xDF,0xFF,0x1F,0x3F,0x5F,0x7F]
for idx,x in zip(qidx,qx):
    blk(idx,(x+3)&0xff, 0x00)
    print("  q idx%d x 0x%02x->0x%02x"%(idx,x,(x+3)&0xff))

print("=== 3) Melocoton +3px derecha: 0x1A704 0x27->0x2A ===")
print("  0x1A704: 0x%02x->0x%02x"%(d[0x1A704],0x2A))
d[0x1A704]=0x2A

open(OUT,'wb').write(bytes(d))
print("OUT:", OUT)
print("md5:", hashlib.md5(bytes(d)).hexdigest())
