#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; SRM=sys.argv[2]
out=Path('/home/user/momotaro_katsugeki/images/savedirect'); out.mkdir(parents=True,exist_ok=True)
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
try:
    r.run(60, {})
    save(r, out/"load60.png")
    print("saved load60 for", ROM)
    # dump SAT to see if text sprites present
    sat=r.sat_words()
    textsp=[]
    for i in range(64):
        no=(sat[i*4+2]>>1)&0x3ff
        if 0x1C0<=no<=0x1D8: textsp.append((i,no))
    print("text sprites (0x1C0-0x1D8) in SAT:", textsp)
finally:
    r.close()
