#!/usr/bin/env python3
"""Aplica +5px a la derecha sobre melocoton y DIFICIL 1 (la pregunta se queda en +3).
Parte de test_qonerow_shift3.pce (donde melocoton=0x2A, DIF=+3, preg=+3)."""
import sys, hashlib
SRC='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_shift3.pce'
OUT='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_shift5.pce'
d=bytearray(open(SRC,'rb').read())

def blk(idx, x, y):
    o=0x1FC05+idx*5
    d[o+3]=x; d[o+4]=y

print("=== DIFICIL 1 +5px derecha (mantener y=0x10) ===")
difx=[0xE9,0x09,0x29,0x49,0x69]  # actuales (tras +3)
for i,x in enumerate(difx):
    idx=i+1
    nv=(x+5)&0xff
    blk(idx, nv, 0x10)
    print("  dif idx%d x 0x%02x->0x%02x"%(idx,x,nv))

print("=== Melocoton +5px: 0x1A704 0x2A->0x2F ===")
print("  0x1A704: 0x%02x->0x%02x"%(d[0x1A704],0x2F))
d[0x1A704]=0x2F

open(OUT,'wb').write(bytes(d))
print("OUT:", OUT)
print("md5:", hashlib.md5(bytes(d)).hexdigest())
