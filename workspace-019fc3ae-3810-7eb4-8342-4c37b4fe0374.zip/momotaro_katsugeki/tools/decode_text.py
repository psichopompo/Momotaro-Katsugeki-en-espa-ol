#!/usr/bin/env python3
from pathlib import Path
import sys, unicodedata

def kata_to_hira(s):
    out=[]
    for ch in s:
        o=ord(ch)
        if 0x30A1 <= o <= 0x30F6:
            out.append(chr(o-0x60))
        else:
            out.append(ch)
    return ''.join(out)

def decode_bytes(bs, show_ctrl=True):
    out=[]; i=0
    while i<len(bs):
        b=bs[i]
        # Known/control candidates
        if b==0x00:
            out.append('\n')
            i+=1; continue
        if b==0xFF:
            out.append('<FF>'); i+=1; continue
        if b==0xFE:
            out.append('<FE>'); i+=1; continue
        if b==0xFD:
            out.append('<FD>'); i+=1; continue
        if b==0xFC:
            out.append('<FC>'); i+=1; continue
        if b==0xFB:
            out.append('<FB>'); i+=1; continue
        if b==0xFA:
            out.append('<FA>'); i+=1; continue
        # half-width katakana including voiced mark
        if 0xA1 <= b <= 0xDF:
            # include following dakuten/handakuten if present
            raw=bytes([b])
            if i+1 < len(bs) and bs[i+1] in (0xDE,0xDF) and b not in (0xDE,0xDF):
                raw=bytes([b,bs[i+1]]); i+=1
            try:
                s=raw.decode('cp932')
                s=unicodedata.normalize('NFKC',s)
                s=kata_to_hira(s)
            except Exception:
                s=f'<{b:02X}>'
            out.append(s)
            i+=1; continue
        # ASCII/custom punctuation; leave printable, flag some suspected controls.
        if 0x20 <= b <= 0x7E:
            ch=chr(b)
            # Japanese ROM sometimes uses 5C as yen/format; keep visible.
            out.append(ch)
            i+=1; continue
        out.append(f'<{b:02X}>')
        i+=1
    return ''.join(out)

if __name__=='__main__':
    rom=Path(sys.argv[1]).read_bytes()
    if len(sys.argv)>=3:
        off=int(sys.argv[2],0); ln=int(sys.argv[3],0) if len(sys.argv)>=4 else 0x200
        print(decode_bytes(rom[off:off+ln]))
    else:
        # print likely text runs in whole ROM
        pass
