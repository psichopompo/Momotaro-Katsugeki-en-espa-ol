#!/usr/bin/env python3
"""Genera un parche IPS (original japones -> ROM final traducida de la pantalla de carga).
IPS guarda solo los bytes que difieren entre ROM base y ROM parcheada."""
import hashlib, sys

BASE='/home/user/momotaro_katsugeki/Roms/Original/Momotarou Katsugeki (Japan).pce'
FINAL='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_final.pce'
OUT='/home/user/momotaro_katsugeki/Parches/momotaro_pantalla_carga_v16.ips'

base=open(BASE,'rb').read()
final=open(FINAL,'rb').read()
if len(base)!=len(final):
    print("ERROR: distinta longitud"); sys.exit(1)

# calcular regiones de diferencia
diff_runs=[]
i=0
n=len(base)
while i<n:
    if base[i]!=final[i]:
        start=i
        while i<n and base[i]!=final[i]:
            i+=1
        diff_runs.append((start,i))
    else:
        i+=1

def ips_header():
    return b'PATCH'

out=bytearray(ips_header())
for (s,e) in diff_runs:
    off=s
    data=final[s:e]
    # dividir en chunks (IPS offset 3 bytes, len 2 bytes)
    pos=0
    while pos<len(data):
        # offset
        off_b=(off>>16)&0xff, (off>>8)&0xff, off&0xff
        # si es RLE (mismo byte repetido) usarlo, sino datos normales
        chunk=data[pos:pos+0xFFFF]
        out+=bytes(off_b)
        out+=bytes([(len(chunk)>>8)&0xff, len(chunk)&0xff])
        out+=chunk
        off+=len(chunk)
        pos+=len(chunk)
out+=b'EOF'

open(OUT,'wb').write(bytes(out))
print("Parche IPS:", OUT)
print("  regiones que difieren:", len(diff_runs))
print("  md5 IPS:", hashlib.md5(bytes(out)).hexdigest())
print("  size:", len(out))
