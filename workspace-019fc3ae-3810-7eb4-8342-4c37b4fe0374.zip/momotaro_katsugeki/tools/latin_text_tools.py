#!/usr/bin/env python3
"""Herramientas preliminares para insertar texto latino en Momotarou Katsugeki.

Usa la tabla validada charset_latin_charset_test_v2.tbl.
No es todavía un reinserter completo con punteros; sirve para codificar, medir y validar líneas.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

# Códigos de control observados/empleados.
CTRL = {
    '<NL>': 0x00,
    '<PAGE>': 0xFC,
    '<WAIT>': 0xFD,
    '<MODE>': 0xFE,
    '<END>': 0xFF,
}

CHAR_TO_CODE: dict[str, int] = {' ': 0x20}
for i in range(10):
    CHAR_TO_CODE[str(i)] = 0x30 + i
for i in range(26):
    CHAR_TO_CODE[chr(ord('A') + i)] = 0x41 + i
CHAR_TO_CODE.update({'!': 0x21, '?': 0x3F, '$': 0x24})
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    CHAR_TO_CODE[ch] = 0xA1 + i
# Bytes directos no seguros: A2, A3, B0. Usamos atajos por tabla ASCII.
CHAR_TO_CODE['b'] = 0x5B
CHAR_TO_CODE['c'] = 0x5D
CHAR_TO_CODE['p'] = 0x5E
CHAR_TO_CODE.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'º': 0xDC, 'ª': 0xDD, 'Ç': 0x5F,
})
CODE_TO_CHAR = {v: k for k, v in CHAR_TO_CODE.items()}
CODE_TO_CHAR.update({v: k for k, v in CTRL.items()})

@dataclass
class EncodedText:
    data: bytes
    line_lengths: list[int]
    warnings: list[str]


def encode_text(text: str, end: bool = False) -> bytes:
    """Codifica texto con \n como $00 y tokens <PAGE>/<WAIT>/<END>.

    Tokens admitidos literalmente dentro del texto: <PAGE>, <WAIT>, <MODE>, <END>, <NL>.
    """
    out = bytearray()
    i = 0
    while i < len(text):
        if text[i] == '\n':
            out.append(0x00)
            i += 1
            continue
        if text[i] == '<':
            matched = False
            for tok, code in CTRL.items():
                if text.startswith(tok, i):
                    out.append(code)
                    i += len(tok)
                    matched = True
                    break
            if matched:
                continue
        ch = text[i]
        if ch not in CHAR_TO_CODE:
            raise ValueError(f'Carácter no soportado por la tabla latina actual: {ch!r}')
        out.append(CHAR_TO_CODE[ch])
        i += 1
    if end:
        out.append(0xFF)
    return bytes(out)


def visible_len(line: str) -> int:
    """Longitud visible en tiles. Tokens de control no cuentan."""
    n = 0
    i = 0
    while i < len(line):
        if line[i] == '<':
            matched = False
            for tok in CTRL:
                if line.startswith(tok, i):
                    i += len(tok)
                    matched = True
                    break
            if matched:
                continue
        n += 1
        i += 1
    return n


def validate_text(text: str, max_cols: int | None = None, max_bytes: int | None = None, end: bool = False) -> EncodedText:
    data = encode_text(text, end=end)
    lines = text.replace('<PAGE>', '\n').replace('<END>', '').split('\n')
    lengths = [visible_len(line) for line in lines]
    warnings: list[str] = []
    if max_cols is not None:
        for idx, ln in enumerate(lengths, 1):
            if ln > max_cols:
                warnings.append(f'Línea {idx}: {ln} caracteres visibles; excede máximo {max_cols}.')
    if max_bytes is not None and len(data) > max_bytes:
        warnings.append(f'Texto codificado: {len(data)} bytes; excede máximo {max_bytes}.')
    return EncodedText(data=data, line_lengths=lengths, warnings=warnings)


def hex_bytes(data: bytes) -> str:
    return ' '.join(f'{b:02X}' for b in data)


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description='Codifica/valida texto latino de Momotarou Katsugeki.')
    ap.add_argument('text', help='Texto. Usa \\n real o tokens <PAGE>, <WAIT>, <END>.')
    ap.add_argument('--max-cols', type=int)
    ap.add_argument('--max-bytes', type=int)
    ap.add_argument('--end', action='store_true')
    args = ap.parse_args()
    # Convertimos únicamente la secuencia literal \n para no corromper UTF-8 (¡, ñ, tildes...).
    text = args.text.replace('\\n', '\n')
    res = validate_text(text, max_cols=args.max_cols, max_bytes=args.max_bytes, end=args.end)
    print('Line lengths:', res.line_lengths)
    print('Bytes:', len(res.data))
    print(hex_bytes(res.data))
    if res.warnings:
        print('WARNINGS:')
        for w in res.warnings:
            print('-', w)
