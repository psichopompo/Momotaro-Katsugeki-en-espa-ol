#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; SRM=sys.argv[2]
EVENTS={1790:[3],1800:[7],1820:[],1850:[3],1860:[]}
out=Path('/home/user/momotaro_katsugeki/images/v15full'); out.mkdir(parents=True,exist_ok=True)
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
try:
    r.run(2100, EVENTS)
    for _ in range(25): r.buttons={5}; r.run(1,{})
    r.buttons=set()
    for _ in range(15): r.run(1,{})
    for _ in range(25): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for _ in range(300): r.run(1,{})
    save(r, out/"load.png")
    # Also dump SAT + tilemap to identify text mechanism
    sat=r.sat_words()
    print("SAT sprites (load v15):")
    for i in range(64):
        x=sat[i*4+1]&0x3ff; y=(sat[i*4+0]&0x3ff)-0x40
        no=(sat[i*4+2]>>1)&0x3ff; cg=sat[i*4+2]&1
        if x<320 and y<240:
            print(f"   spr{i:2d} x={x} y={y} tile={no:03x} cg={cg}")
    vram=r.vram_words(); regs=r.vdc_regs()
    ws=[5,6,7,7][(regs["mwr"]>>4)&3]; stride=1<<ws
    print("tilemap text tiles:")
    for y in range(64):
        for x in range(64):
            ti=vram[y*stride+x]&0xFFF
            if 0x1C0<=ti<0x1D9: print(f"   r{y} c{x} tile 0x{ti:03x}")
            if 0x380<=ti<0x400: print(f"   r{y} c{x} tile 0x{ti:03x}")
finally:
    r.close()
