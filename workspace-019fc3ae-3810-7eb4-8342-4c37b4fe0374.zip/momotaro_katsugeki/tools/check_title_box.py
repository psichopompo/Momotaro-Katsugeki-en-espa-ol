#!/usr/bin/env python3
from pathlib import Path
D=Path('/home/user/momotaro_katsugeki/Roms/Momotarou Katsugeki (Japan) - traduccion_v12_texto_centrado.pce').read_bytes()
def rom_off(bank,cpu,base=0x4000): return bank*0x2000+(cpu-base)
def rle_value(data,pos,state):
    count,val=state
    if count:
        count-=1
        return val,pos,(count,val)
    a=data[pos]; pos+=1
    if a!=0xFF:
        return a,pos,(0,val)
    count=data[pos]; pos+=1
    val=data[pos]; pos+=1
    return val,pos,(count,val)
def decomp_tilemap(low_off, high_off, rows=32, cols=64):
    posL=low_off; posH=high_off; stL=(0,0); stH=(0,0)
    words=[]
    for y in range(rows):
        row=[]
        for x in range(32):
            lo,posL,stL=rle_value(D,posL,stL)
            hi,posH,stH=rle_value(D,posH,stH)
            hi=(hi+1)&0xFF
            row.append(lo | (hi<<8))
        for x in range(32):
            row.append(0)
        words.append(row)
    return words
low=rom_off(0x12,0x4FF7); high=rom_off(0x12,0x52B0)
print("low_off",hex(low),"high_off",hex(high))
tm=decomp_tilemap(low,high)
for y in range(11,17):
    print(f"r{y:02d}: "+" ".join(f"{tm[y][x]&0xFFF:03x}" for x in range(32)))
