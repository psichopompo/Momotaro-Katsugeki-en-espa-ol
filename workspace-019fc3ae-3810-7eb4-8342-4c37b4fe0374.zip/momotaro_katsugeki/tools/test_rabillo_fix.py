#!/usr/bin/env python3
"""Test edits to the LOW box stream (ROM 0x1E0D1) rabillo region and dump tilemap rows.
Edits are (byte_offset, [old_bytes], [new_bytes]) validated, then run emulator.
"""
import sys, hashlib, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner

SRC='/home/user/momotaro_katsugeki/Roms/Momotarou Katsugeki (Japan) - traduccion_v12_texto_centrado.pce'
EVENTS={1790:[3],1800:[7],1820:[],1850:[3],1860:[]}

def run_and_dump(rom, rows=(15,16), frames=2100):
    r=Runner(Path(rom), Path(rom).parent, save_ram_path="/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm")
    try:
        r.run(frames, EVENTS)
        vram=r.vram_words(); regs=r.vdc_regs()
        ws=[5,6,7,7][(regs["mwr"]>>4)&3]; stride=1<<ws
        hmask=[31,63][(regs["mwr"]>>6)&1]; bat_y=((regs["byr"]>>3)&hmask)<<ws
        for y in range(rows[0],rows[1]+1):
            row=vram[bat_y+y*stride: bat_y+y*stride+32]
            print(f"r{y:02d}: "+" ".join(f"{row[x]&0xFFF:03x}" for x in range(32)))
    finally:
        r.close()

def make_rom(edits, out):
    d=bytearray(open(SRC,'rb').read())
    orig=open(SRC,'rb').read()
    for off, old, new in edits:
        assert bytes(d[off:off+len(old)])==bytes(old), f"mismatch at {off:#x}: got {bytes(d[off:off+len(old)]).hex()} want {bytes(old).hex()}"
        d[off:off+len(new)]=bytes(new)
    open(out,'wb').write(bytes(d))
    print("made", out, hashlib.sha256(bytes(d)).hexdigest())

if __name__=='__main__':
    name=sys.argv[1]
    if name=='shiftL5':  # reduce empty before rabillo by 5 (ff 14 00 -> ff 0f 00)
        make_rom([(0x1E0F4,[0xff,0x14,0x00],[0xff,0x0f,0x00])], '/tmp/t_shiftL5.pce')
        run_and_dump('/tmp/t_shiftL5.pce')
    elif name=='combined':  # shiftL5 + widen borders 5 + compensate peach right 1
        make_rom([(0x1E0F4,[0xff,0x14,0x00],[0xff,0x0f,0x00]),
                  (0x1E0F8,[0xff,0x03,0x07],[0xff,0x05,0x07]),
                  (0x1E0FD,[0xff,0x03,0x07],[0xff,0x05,0x07]),
                  (0x1E101,[0xff,0x18,0x00],[0xff,0x19,0x00])], '/tmp/t_combined.pce')
        run_and_dump('/tmp/t_combined.pce')
    elif name=='widen_edge5':  # rabillo borders 3->5 each side, keep empties
        make_rom([(0x1E0F8,[0xff,0x03,0x07],[0xff,0x05,0x07]),
                  (0x1E0FD,[0xff,0x03,0x07],[0xff,0x05,0x07])], '/tmp/t_widen_edge5.pce')
        run_and_dump('/tmp/t_widen_edge5.pce')
    elif name=='baseline':
        run_and_dump(SRC)
