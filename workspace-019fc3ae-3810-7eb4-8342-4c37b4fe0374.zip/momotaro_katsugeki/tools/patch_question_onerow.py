#!/usr/bin/env python3
"""Rediseño de la pantalla CARGAR: pregunta en UNA fila (izquierda, separación natural 16px/tile),
dificultad movida a tiles no solapados.

Cambios:
1. $C5AC (ROM 0x1A5AC): mover dificultad [1..4] a tiles libres.
   [1]=0x7408 (SAT 0x1d0), [2]=0x7608 (0x1d8), [3]=0x7808 (0x1e0), [4]=0x7a08 (0x1e8)
2. Bloque2 (ROM 0x1FC05): 6 sprites dobles pregunta en y=0, 5 sprites dobles dificultad en y=0x20,
   resto oculto (y=0xF0, fuera de pantalla).
"""
import hashlib, sys
SRC='/home/user/momotaro_katsugeki/Roms/Momotarou Katsugeki (Japan) - traduccion_v15_restaurar_bloque2.pce'
OUT=sys.argv[1] if len(sys.argv)>1 else '/tmp/t_qonerow.pce'
d=bytearray(open(SRC,'rb').read())

# 1) C5AC table (ROM 0x1A5AC), 5 words little-endian
c5ac=0x1A5AC
def set_dest(i,val):
    d[c5ac+2*i]=val&0xff
    d[c5ac+2*i+1]=(val>>8)&0xff
set_dest(0,0x7008)
set_dest(1,0x7408)   # dificultad -> SAT 0x1d0
set_dest(2,0x7608)   # -> SAT 0x1d8
set_dest(3,0x7808)   # -> SAT 0x1e0
set_dest(4,0x7a08)   # -> SAT 0x1e8

# 1b) Fix glifo de "?" de apertura (0xC9). La "?" real del juego esta en 0x3DB49:
#   7c c6 c6 1c 30 00 30 00 (punto abajo). "?" = vol. horizontal + vertical (180°):
#   00 0c 00 0c 38 63 63 3e. Escribir SOLO en el slot 0x3DCA8.
d[0x3DCA8:0x3DCA8+8]=bytes([0x00,0x0c,0x00,0x0c,0x38,0x63,0x63,0x3e])

# 2) Bloque2 (ROM 0x1FC05), 15 entradas [code, fl_lo, fl_hi, x, y]
blk=0x1FC05
def entry(idx, code, fl_hi, x, y):
    o=blk+idx*5
    d[o]=code
    d[o+2]=fl_hi
    d[o+3]=x
    d[o+4]=y
    print(f"  [{idx:2d}] code=0x{code:02x} tile=0x{0x1c0+code:03x} fl_hi=0x{fl_hi:02x} x=0x{x:02x} y=0x{y:02x}")

print("Bloque2 nuevo:")
# Pregunta: x_final=106+x_rel. Regla: se descartan sprites con x_final>=234.
# Limite => ultima tile (simple) en x<=233 => pregunta empieza en x=73.
# 0x1c0@73(DF) 0x1c2@105(FF) 0x1c4@137(1F) 0x1c6@169(3F) 0x1c8@201(5F) 0x1ca@233(7F,simple)
entry(12,0x00,0x01,0xDF,0x00)  # 0x1c0 doble @73
entry(13,0x02,0x01,0xFF,0x00)  # 0x1c2 doble @105
entry(14,0x04,0x01,0x1F,0x00)  # 0x1c4 doble @137
entry(10,0x06,0x01,0x3F,0x00)  # 0x1c6 doble @169
entry(11,0x08,0x01,0x5F,0x00)  # 0x1c8 doble @201
entry( 6,0x0a,0x00,0x7F,0x00)  # 0x1ca SIMPLE @233 (ultimo char "?")
# Dificultad: 5 dobles en y=0x14 (linea del melocoton), X ORIGINAL (x_rel E6.. -> SAT 80,112,144,176,208)
entry( 1,0x10,0x01,0xE6,0x14)  # 0x1d0 @80
entry( 2,0x12,0x01,0x06,0x14)  # 0x1d2 @112
entry( 3,0x14,0x01,0x26,0x14)  # 0x1d4 @144
entry( 4,0x16,0x01,0x46,0x14)  # 0x1d6 @176
entry( 5,0x18,0x01,0x66,0x14)  # 0x1d8 @208
# Ocultos: apuntan a tile vacio 0x1d5 (transparente), posicion irrelevante
entry( 0,0x15,0x00,0x00,0x00)
entry( 7,0x15,0x00,0x00,0x00)
entry( 8,0x15,0x00,0x00,0x00)
entry( 9,0x15,0x00,0x00,0x00)

open(OUT,'wb').write(bytes(d))
h=hashlib.sha256(bytes(d)).hexdigest()
print("sha256:", h)
print("md5:", hashlib.md5(bytes(d)).hexdigest())
