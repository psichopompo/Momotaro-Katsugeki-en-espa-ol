#!/usr/bin/env python3
"""Construye BRAM sintética v01 sin leer ni copiar ningún SRM existente.

v01 reconstruye, desde un buffer de 2048 ceros, la estructura válida medida
para la partida de referencia: cabecera HUBM, descriptor, firma MOMOKATSU. y
payload. El checksum se calcula, no se copia como una constante.
"""
from __future__ import annotations

import argparse
import hashlib
import zlib
from pathlib import Path

BRAM_SIZE = 0x800
RECORD_START = 0x10
RECORD_SIZE = 0x90
CHECKSUM_OFFSET = RECORD_START + 2
BODY_OFFSET = RECORD_START + 4

# Bytes no nulos del payload de la estructura medida. El resto del buffer se
# construye como cero; el script no abre ni consulta el SRM real.
PAYLOAD_0060_007F = bytes((
    0x01, 0x91, 0x93, 0x93, 0x93, 0x33, 0x99, 0x3E,
    0x92, 0x93, 0x93, 0x93, 0x93, 0x93, 0x93, 0x93,
    0x97, 0x96, 0x92, 0x90, 0x93, 0x93, 0x93, 0x67,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x93,
))


def checksum_complement_16(data: bytes) -> int:
    return (-sum(data)) & 0xFFFF


def build() -> bytearray:
    bram = bytearray(BRAM_SIZE)

    # Cabecera BRAM y descriptor de archivo medidos en la ruta válida.
    bram[0x00:0x08] = b"HUBM\x00\x88\xA0\x80"
    bram[RECORD_START:RECORD_START + 2] = RECORD_SIZE.to_bytes(2, "little")

    # Cuerpo de RECORD_SIZE - 4 bytes, desde $0014 hasta $009F.
    bram[0x16:0x20] = b"MOMOKATSU."
    bram[0x60:0x80] = PAYLOAD_0060_007F

    body = bytes(bram[BODY_OFFSET:RECORD_START + RECORD_SIZE])
    checksum = checksum_complement_16(body)
    bram[CHECKSUM_OFFSET:CHECKSUM_OFFSET + 2] = checksum.to_bytes(2, "little")

    # Invariantes que se usarán también al crear versiones posteriores.
    assert len(bram) == BRAM_SIZE
    assert bram[0:4] == b"HUBM"
    assert bram[0x16:0x20] == b"MOMOKATSU."
    assert (sum(body) + checksum) & 0xFFFF == 0
    assert sum(x != 0 for x in bram) == 45
    return bram


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("output", type=Path, help="Destino nuevo; se rechaza sobrescribir")
    args = ap.parse_args()
    output = args.output.resolve()
    if output.exists():
        raise SystemExit(f"El destino ya existe: {output}")

    bram = build()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(bram)
    print(f"output={output}")
    print(f"size={len(bram)}")
    print(f"nonzero={sum(x != 0 for x in bram)}")
    print(f"checksum=${int.from_bytes(bram[0x12:0x14], 'little'):04X}")
    print(f"md5={hashlib.md5(bram).hexdigest()}")
    print(f"sha1={hashlib.sha1(bram).hexdigest()}")
    print(f"sha256={hashlib.sha256(bram).hexdigest()}")
    print(f"crc32={zlib.crc32(bram) & 0xFFFFFFFF:08x}")


if __name__ == "__main__":
    main()
