#!/usr/bin/env python3
"""Aplica el parche del melocoton a la pantalla de carga: ROM 0x1A704 (\$3C86 entrada 2)
de 0x50 a 0x27. Verifica con el SAT forzando \$3C86 (el estado no re-ejecuta \$C6D0)."""
import sys
import hashlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
SRC='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_claudeQ.pce'
OUT='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_melo.pce'
STATE='/home/user/downloads/momotaro.state'
SRM='/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm'

d=bytearray(open(SRC,'rb').read())
print("antes 0x1A6FE=%02x 0x1A704=%02x"%(d[0x1A6FE], d[0x1A704]))
d[0x1A704]=0x27   # entrada 2, \$3C86 de la CARGA: 0x50 -> 0x27
open(OUT,'wb').write(bytes(d))
print("despues 0x1A704=%02x"%(d[0x1A704]))
print("md5:", hashlib.md5(bytes(d)).hexdigest())

def melo(force):
    r=Runner(Path(OUT), Path('/tmp'), save_ram_path=SRM)
    try:
        r.load_state(STATE)
        for _ in range(40): r.run(1,{})
        for _ in range(60): r.buttons={3}; r.run(1,{})
        r.buttons=set()
        for _ in range(150): r.run(1,{})
        if force is not None:
            for _ in range(5):
                r.core.arena_get_baseram()[0x1C86]=force
                r.run(1,{})
        sat=r.sat_words()
        for i in range(64):
            if (sat[i*4+2]>>1)&0x3ff==0x1a0:
                return sat[i*4+1]&0x3ff,(sat[i*4+0]&0x3ff)-0x40
        return None
    finally:
        r.close()

print("ROM parcheada, sin forzar \$3C86 (estado viejo):", melo(None))
print("ROM parcheada, forzando \$3C86=0x27 (simula re-inicializacion):", melo(0x27))
