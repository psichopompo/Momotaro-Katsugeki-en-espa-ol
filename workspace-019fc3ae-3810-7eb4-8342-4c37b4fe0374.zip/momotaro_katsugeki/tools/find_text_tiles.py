#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; SRM=sys.argv[2]
EVENTS={1790:[3],1800:[7],1820:[],1850:[3],1860:[]}
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
try:
    r.run(2100, EVENTS)
    for _ in range(25): r.buttons={5}; r.run(1,{})
    r.buttons=set()
    for _ in range(15): r.run(1,{})
    for _ in range(25): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for _ in range(300): r.run(1,{})
    vram=r.vram_words(); regs=r.vdc_regs()
    ws=[5,6,7,7][(regs["mwr"]>>4)&3]; stride=1<<ws
    # full tilemap, find tiles >= 0x380 (text glyphs) and != 0x100
    found=[]
    for y in range(64):
        for x in range(64):
            ti=vram[y*stride+x]&0xFFF
            if ti>=0x380 and ti<0x400:
                found.append((y,x,ti))
    print(f"text glyph tiles (0x380-0x3FF) in tilemap: {len(found)}")
    for y,x,ti in found[:40]:
        print(f"  r{y} c{x} tile=0x{ti:03x}")
    # also any non-0x100 tiles
    print("=== all non-empty rows 0-40 (tile<0x380) ===")
    for y in range(0,40):
        row=vram[y*stride:y*stride+64]
        ne=[x for x in range(64) if (row[x]&0xFFF)!=0x100 and (row[x]&0xFFF)<0x380]
        if ne:
            print(f"  r{y:02d}: "+",".join(f"{x}:{row[x]&0xFFF:03x}" for x in ne[:40]))
finally:
    r.close()
