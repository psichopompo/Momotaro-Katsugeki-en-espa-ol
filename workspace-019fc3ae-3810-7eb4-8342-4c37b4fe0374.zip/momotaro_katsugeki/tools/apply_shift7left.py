#!/usr/bin/env python3
"""Aplica -7px a la izquierda sobre melocoton y DIFICIL 1 desde shift5.
Melocoton 0x2F->0x28; DIFICIL x_rel 0xEE,0x0E,0x2E,0x4E,0x6E -> -7."""
import sys, hashlib
SRC='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_shift5.pce'
OUT='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow_final.pce'
d=bytearray(open(SRC,'rb').read())

def blk(idx, x, y):
    o=0x1FC05+idx*5
    d[o+3]=x; d[o+4]=y

print("=== DIFICIL 1 -7px izquierda (mantener y=0x10) ===")
difx=[0xEE,0x0E,0x2E,0x4E,0x6E]  # actuales (tras shift3+shift5)
for i,x in enumerate(difx):
    idx=i+1
    nv=(x-7)&0xff
    blk(idx, nv, 0x10)
    print("  dif idx%d x 0x%02x->0x%02x"%(idx,x,nv))

print("=== Melocoton -7px: 0x1A704 0x2F->0x28 ===")
print("  0x1A704: 0x%02x->0x%02x"%(d[0x1A704],0x28))
d[0x1A704]=0x28

open(OUT,'wb').write(bytes(d))
print("OUT:", OUT)
print("md5:", hashlib.md5(bytes(d)).hexdigest())
