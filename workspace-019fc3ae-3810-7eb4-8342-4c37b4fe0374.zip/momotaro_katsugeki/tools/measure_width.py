#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; STATE=sys.argv[2]
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path="/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm")
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
try:
    r.load_state(STATE)
    for _ in range(40): r.run(1,{})
    for _ in range(60): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for _ in range(250): r.run(1,{})
    save(r,"/home/user/momotaro_katsugeki/images/width_meas.png")
    # medir ancho del texto visible en la caja
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    def istext(x,y):
        row=data[y*p:y*p+w*2]; b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
        r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
        return (r5,g6,b5)==(0,0,0)
    # buscar filas con texto negro dentro del box
    print("Ancho del texto por fila (y, xmin, xmax, ancho):")
    for y in range(50,130):
        cols=[x for x in range(60,200) if istext(x,y)]
        # filtrar ruido (borde del box)
        if len(cols)>5 and y%8==0:
            print(f"  y={y}: x{min(cols)}-{max(cols)} ancho={max(cols)-min(cols)}")
finally:
    r.close()
