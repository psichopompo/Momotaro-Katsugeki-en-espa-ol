#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; SRM=sys.argv[2]
EVENTS={1790:[3],1800:[7],1820:[],1850:[3],1860:[]}
out=Path('/home/user/momotaro_katsugeki/images/capnav'); out.mkdir(parents=True,exist_ok=True)
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
try:
    r.run(2100, EVENTS)
    for _ in range(25): r.buttons={5}; r.run(1,{})
    r.buttons=set()
    for _ in range(15): r.run(1,{})
    for _ in range(25): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    # capture during transition
    for i in range(60):
        r.run(1,{})
        if i in (10,20,40,60): save(r, out/f"nav_{i}.png")
    print("saved nav captures")
finally:
    r.close()
