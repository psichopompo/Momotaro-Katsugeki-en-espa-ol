#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; STATE=sys.argv[2]
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path="/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm")
try:
    r.load_state(STATE)
    for _ in range(40): r.run(1,{})
    for _ in range(60): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for _ in range(250): r.run(1,{})
    vram=r.vram_words(); regs=r.vdc_regs()
    ws=[5,6,7,7][(regs["mwr"]>>4)&3]; stride=1<<ws
    print("mwr",hex(regs["mwr"]),"stride",stride)
    # Check if BG tilemap has entries pointing to text glyphs (tile>=0x380) or text tiles
    found=[]
    for y in range(64):
        for x in range(64):
            ti=vram[y*stride+x]&0xFFF
            if ti>=0x380 or (0x1c0<=ti<0x1d9):
                found.append((y,x,ti))
    print("BG tilemap entries pointing a text tiles (>=0x380 or 0x1c0-0x1d9):", len(found))
    for y,x,ti in found[:30]:
        print(f"  r{y} c{x} tile=0x{ti:03x}")
    print()
    print("All non-empty BG tilemap rows 4-22:")
    for y in range(4,23):
        row=vram[y*stride:y*stride+64]
        ne=[x for x in range(64) if (row[x]&0xFFF)!=0x100]
        if ne:
            print(f"  r{y}: "+" ".join(f"{x}:{row[x]&0xFFF:03x}" for x in ne[:40]))
finally:
    r.close()
