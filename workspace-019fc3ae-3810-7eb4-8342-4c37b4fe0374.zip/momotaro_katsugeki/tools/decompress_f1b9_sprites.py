#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw
import argparse

def decomp_seq(data, pos):
    mask=data[pos]; pos+=1
    vals=[]
    # first bit bit7 after ASL
    a=0
    for bitpos in range(7,-1,-1):
        if (mask>>bitpos)&1:
            a=data[pos]; pos+=1
        elif bitpos==7:
            a=0
        # else repeat previous a
        vals.append(a)
    return vals,pos

def decomp_sprite(data,pos):
    out=[0]*0x80
    base=0
    for block in range(4):
        for y0 in [0,1,0x10,0x11]:
            vals,pos=decomp_seq(data,pos)
            for i,v in enumerate(vals):
                out[base+y0+i*2]=v
        base+=0x20
    return bytes(out),pos

def decomp_stream(data,off):
    count=data[off]; pos=off+1; sprites=[]
    for i in range(count):
        spr,pos=decomp_sprite(data,pos); sprites.append(spr)
    return sprites,pos

def dec_pce_tile(tile):
    pix=[]
    for y in range(8):
        b0,b1=tile[y*2],tile[y*2+1]
        b2,b3=tile[16+y*2],tile[16+y*2+1]
        row=[]
        for x in range(8):
            bit=7-x
            row.append(((b0>>bit)&1)|(((b1>>bit)&1)<<1)|(((b2>>bit)&1)<<2)|(((b3>>bit)&1)<<3))
        pix.append(row)
    return pix

def render_sprite(spr, order='tl_tr_bl_br', scale=4):
    # spr = four 32-byte tiles. Try orders.
    tiles=[spr[i*32:(i+1)*32] for i in range(4)]
    if order=='tl_tr_bl_br': positions=[(0,0),(8,0),(0,8),(8,8)]
    elif order=='tl_bl_tr_br': positions=[(0,0),(0,8),(8,0),(8,8)]
    elif order=='tl_tr_br_bl': positions=[(0,0),(8,0),(8,8),(0,8)]
    else: positions=[(0,0),(8,0),(0,8),(8,8)]
    pal=[(0,0,80),(255,109,33),(33,36,33),(148,73,0),(255,255,0),(148,109,0),(0,146,219),(255,255,255),(128,128,128),(0,255,0),(255,0,255),(0,255,255),(128,0,0),(0,128,0),(0,0,128),(200,200,200)]
    im=Image.new('RGB',(16,16),pal[0])
    px=im.load()
    for t,(ox,oy) in zip(tiles,positions):
        pix=dec_pce_tile(t)
        for y,row in enumerate(pix):
            for x,c in enumerate(row):
                px[ox+x,oy+y]=pal[c]
    return im.resize((16*scale,16*scale),Image.Resampling.NEAREST)

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--rom',default='/home/user/momotaro_katsugeki/work/Momotarou Katsugeki (Japan).pce')
    ap.add_argument('--off',type=lambda x:int(x,0),default=0x272DE)
    ap.add_argument('--out',default='/home/user/momotaro_katsugeki/images/decomp_272DE_sprites.png')
    args=ap.parse_args()
    data=Path(args.rom).read_bytes()
    sprites,end=decomp_stream(data,args.off)
    print('count',len(sprites),'end',hex(end),'len',end-args.off)
    for order in ['tl_tr_bl_br','tl_bl_tr_br','tl_tr_br_bl']:
        cols=len(sprites); scale=4
        sheet=Image.new('RGB',(cols*16*scale,16*scale+14),(230,230,230)); d=ImageDraw.Draw(sheet)
        d.text((2,1),order,(0,0,0))
        for i,spr in enumerate(sprites):
            sheet.paste(render_sprite(spr,order,scale),(i*16*scale,14))
        path=args.out.replace('.png',f'_{order}.png')
        sheet.save(path); print(path)
