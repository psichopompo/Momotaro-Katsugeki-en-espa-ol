#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; STATE=sys.argv[2]
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path="/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm")
try:
    r.load_state(STATE)
    for _ in range(40): r.run(1,{})
    for _ in range(60): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for _ in range(100): r.run(1,{})
    vram=r.vram_words()
    # The '?' glyphs are at VRAM $7000+. The inverted open-'?' (¿) is the first char.
    # Check the glyph pattern at $7000 (tile 0x380) for horizontal flip (mirror).
    def gl(addr):
        out=[]
        for y in range(8):
            row=''
            for x in range(8):
                bit=7-x
                v=((vram[addr+y]>>bit)&1)|(((vram[addr+8+y]>>bit)&1)<<1)|(((vram[addr+16+y]>>bit)&1)<<2)|(((vram[addr+24+y]>>bit)&1)<<3)
                row += '#' if v else ' '
            out.append(row)
        return out
    # The '¿' should look like an upside-down ?. If mirrored, it looks like ? reflected.
    print("Glyph at $7000 (tile 0x380) - should be inverted '¿':")
    for row in gl(0x7000): print("  |"+row+"|")
    print("Glyph at $7040 (tile 0x382):")
    for row in gl(0x7040): print("  |"+row+"|")
finally:
    r.close()
