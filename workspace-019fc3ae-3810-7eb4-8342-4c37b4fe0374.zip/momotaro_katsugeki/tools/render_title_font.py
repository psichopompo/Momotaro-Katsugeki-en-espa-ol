from pathlib import Path
from PIL import Image, ImageDraw
import math
rom=Path('/home/user/momotaro_katsugeki/work/Momotarou Katsugeki (Japan).pce').read_bytes()
base=0x4000; count=0x40; scale=4; cols=16; cell=8*scale; label=12
img=Image.new('RGB',(cols*cell, math.ceil(count/cols)*(cell+label)),(240,240,240)); d=ImageDraw.Draw(img)
# Try 2bpp NES/PCE-ish: 16 bytes: plane0 rows, plane1 rows? Render with any nonzero pixel white on black.
for i in range(count):
    off=base+i*16; bs=rom[off:off+16]
    tile=Image.new('RGB',(8,8),(0,0,0)); p=tile.load()
    for y in range(8):
        b0=bs[y]; b1=bs[8+y]
        for x in range(8):
            bit=7-x; c=((b0>>bit)&1)|(((b1>>bit)&1)<<1)
            if c: p[x,y]=(255,255,255)
    tile=tile.resize((cell,cell),Image.Resampling.NEAREST)
    x=(i%cols)*cell; y=(i//cols)*(cell+label)
    d.text((x+1,y),f'{i:02X}',(255,0,0)); img.paste(tile,(x,y+label))
img.save('/home/user/momotaro_katsugeki/images/title_font_bank02_4000.png')
