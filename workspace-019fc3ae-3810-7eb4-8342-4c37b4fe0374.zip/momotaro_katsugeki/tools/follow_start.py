#!/usr/bin/env python3
"""From load screen, follow START navigation; capture screens and trace txtlog."""
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; SRM=sys.argv[2]
out=Path('/home/user/momotaro_katsugeki/images/followstart'); out.mkdir(parents=True,exist_ok=True)
def save(r,path):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    img=Image.new("RGB",(w,h)); px=img.load()
    for y in range(h):
        row=data[y*p:y*p+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    img.save(path)
def boxes(r):
    w,h,p=r.last_w,r.last_h,r.last_pitch; data=r.last_frame
    def white(x,y):
        row=data[y*p:y*p+w*2]; b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
        r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
        return ((r5<<3)|(r5>>2))==255 and ((g6<<2)|(g6>>4))==255 and ((b5<<3)|(b5>>2))==255
    res=[]
    for yy in range(30,210,10):
        cols=[x for x in range(w) if white(x,yy)]
        if cols and len(cols)>=2: res.append((min(cols),max(cols)))
    return res
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path=SRM)
try:
    r.run(60, {})
    save(r, out/"load60.png")
    print("load60:", boxes(r))
    r.enable_txtlog()
    # START
    for f in range(60,85): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for f in range(85,250): r.run(1,{})
    print("after start1:", boxes(r))
    save(r, out/"after_start1.png")
    print("txtlog:", len(r.txtlog()))
    # START again
    for f in range(250,275): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for f in range(275,450): r.run(1,{})
    print("after start2:", boxes(r))
    save(r, out/"after_start2.png")
    print("txtlog:", len(r.txtlog()))
    # START again
    for f in range(450,475): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for f in range(475,650): r.run(1,{})
    print("after start3:", boxes(r))
    save(r, out/"after_start3.png")
    print("txtlog:", len(r.txtlog()))
    for t in r.txtlog():
        print("  TXT:", t)
    print("done")
finally:
    r.close()
