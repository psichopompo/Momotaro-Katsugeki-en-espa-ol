#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

ROM='/home/user/momotaro_katsugeki/work/Momotarou Katsugeki (Japan).pce'
D=Path(ROM).read_bytes()

def rom_off(bank,cpu,base=0x4000): return bank*0x2000+(cpu-base)

# Decompress C1CC tile stream (256 BG tiles) from bank12/13 CPU $4000.
def read_rle8(data,pos):
    mask=data[pos]; pos+=1; vals=[]; a=0
    for bit in range(7,-1,-1):
        if (mask>>bit)&1:
            a=data[pos]; pos+=1
        vals.append(a)
    return vals,pos

def decomp_bg_tiles(start_off, count=256):
    pos=start_off; tiles=[]
    for _ in range(count):
        # four substreams produce bytes at offsets: 0,1,16,17 then +2 rows
        tile=[0]*32
        for base in [0,1,16,17]:
            vals,pos=read_rle8(D,pos)
            for i,v in enumerate(vals): tile[base+i*2]=v
        tiles.append(bytes(tile))
    return tiles,pos

# Decompress tilemap streams from C5E8: low at $4FF7, high_minus_1 at $52B0 in bank12/13.
def rle_value(data,pos,state):
    count,val=state
    if count:
        count-=1
        return val,pos,(count,val)
    a=data[pos]; pos+=1
    if a!=0xFF:
        return a,pos,(0,val)
    count=data[pos]; pos+=1
    val=data[pos]; pos+=1
    return val,pos,(count,val)

def decomp_tilemap(low_off, high_off, rows=32, cols=64):
    posL=low_off; posH=high_off; stL=(0,0); stH=(0,0)
    words=[]
    for y in range(rows):
        row=[]
        for x in range(32):
            lo,posL,stL=rle_value(D,posL,stL)
            hi,posH,stH=rle_value(D,posH,stH)
            hi=(hi+1)&0xFF
            row.append(lo | (hi<<8))
        for x in range(32):
            row.append(0)
        words.append(row)
    return words,posL,posH

def dec_tile(tile):
    pix=[]
    for y in range(8):
        b0,b1=tile[y*2],tile[y*2+1]; b2,b3=tile[16+y*2],tile[16+y*2+1]
        row=[]
        for x in range(8):
            bit=7-x
            row.append(((b0>>bit)&1)|(((b1>>bit)&1)<<1)|(((b2>>bit)&1)<<2)|(((b3>>bit)&1)<<3))
        pix.append(row)
    return pix

# Palette just for visualization: 16 palettes x 16 colors, generated.
basepal=[(0,0,80),(0,0,0),(0,36,182),(0,146,219),(219,182,0),(146,73,36),(255,36,109),(255,255,255),(73,73,73),(146,146,146),(36,0,73),(36,36,73),(73,73,182),(148,219,255),(255,109,33),(255,255,0)]
# For palette number, rotate/tint slightly but keep visible.
pal=[]
for p in range(16):
    for c in range(16):
        r,g,b=basepal[c]
        # simple variation per palette
        pal.append((min(255,r+p*3),min(255,g+p*2),min(255,b+p*4)))

def render(tiles,tm,w=32,h=30):
    im=Image.new('RGB',(w*8,h*8),(0,0,0)); px=im.load()
    cache={i:dec_tile(t) for i,t in enumerate(tiles)}
    for ty in range(h):
        for tx in range(w):
            word=tm[ty][tx]
            tile_idx=word & 0x0FFF
            palno=(word>>12)&0xF
            # tile data loaded at VRAM $1000 => base tile index 0x80. But tile_idx may already include base.
            local=tile_idx-0x80
            if not (0<=local<len(tiles)):
                local=tile_idx % len(tiles)
            pix=cache[local]
            for y,row in enumerate(pix):
                for x,c in enumerate(row):
                    px[tx*8+x,ty*8+y]=pal[palno*16+c]
    return im

if __name__=='__main__':
    tile_start=rom_off(0x12,0x4000)
    tiles,end=decomp_bg_tiles(tile_start)
    print('tiles end',hex(end),'len',end-tile_start)
    low=rom_off(0x12,0x4FF7); high=rom_off(0x12,0x52B0)
    tm,endL,endH=decomp_tilemap(low,high)
    print('tilemap ends',hex(endL),hex(endH),'lowlen',endL-low,'highlen',endH-high)
    im=render(tiles,tm)
    out='/home/user/momotaro_katsugeki/images/title_bg_decoded_false_palette.png'
    im.save(out); print(out)
    # Save metadata used tile indices in visible 32x30
    used=sorted(set((tm[y][x]&0x0fff)-0x80 for y in range(30) for x in range(32)))
    print('used local tiles',len([u for u in used if 0<=u<256]), used[:20], used[-20:])
