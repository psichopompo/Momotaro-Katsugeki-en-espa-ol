#!/usr/bin/env python3
"""Breakpoint de escritura en VRAM 0x7F00-0x7F03 (palabras Y y X del melocoton).
vramlog formato: [frame, kind, addr, val, pc_logical, bank, pc_real].
Detiene/registra TODAS las escrituras en ese rango y muestra el PC real que la fija."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
ROM=sys.argv[1]; STATE=sys.argv[2]
r=Runner(Path(ROM), Path(ROM).parent, save_ram_path="/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm")
try:
    r.load_state(STATE)
    for _ in range(40): r.run(1,{})
    for _ in range(60): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    # activar vramlog en rango 0x7F00-0x7F03
    # ejecutar frame a frame, capturando escrituras al melocoton
    collected={}
    for f in range(300):
        r.run(1,{}, log_range=(0x7F00,0x7F03))
        logs=r.vramlog()
        for e in logs:
            fr,kind,addr,val,pc_log,bank,pc_real=e
            addr=int(addr)
            # si escribe en 0x7F00-0x7F03
            if 0x7F00<=addr<=0x7F03:
                key=(addr,val,pc_real)
                if key not in collected:
                    collected[key]=fr
                    print(f"  fr={fr} addr=0x{addr:04x} val=0x{val:04x} pc_log=0x{pc_log:04x} bank=0x{bank:02x} pc_real=0x{pc_real:04x}")
    print("total escrituras distintas en 0x7F00-0x7F03:", len(collected))
    print()
    print("=== escrituras al melocoton (0x7F00=X? 0x7F01=Y?) ===")
    for (addr,val,pc) in sorted(collected):
        print(f"  addr=0x{addr:04x} val=0x{val:04x} pc_real=0x{pc:04x}")
finally:
    r.close()
