#!/usr/bin/env python3
import sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
from libretro_pce_runner import Runner
SRC='/home/user/momotaro_katsugeki/Roms/Pruebas/test_qonerow.pce'
STATE='/home/user/downloads/momotaro.state'
SRM='/home/user/uploads/savestate/Momotarou Katsugeki (Japan).srm'
base=bytearray(open(SRC,'rb').read())
pattern=bytes([0x0e,0x11,0x20,0x42,0x41,0x04,0x02,0x00])
base[0x3DCA8:0x3DCA8+8]=pattern
path='/tmp/t_rot180.pce'; open(path,'wb').write(bytes(base))
r=Runner(Path(path), Path('/tmp'), save_ram_path=SRM)
try:
    r.load_state(STATE)
    for _ in range(40): r.run(1,{})
    for _ in range(60): r.buttons={3}; r.run(1,{})
    r.buttons=set()
    for _ in range(300): r.run(1,{})
    w,h,pitch=r.last_w,r.last_h,r.last_pitch
    data=r.last_frame; img=Image.new("RGB",(w,h)); px=img.load(); stride=pitch
    for y in range(h):
        row=data[y*stride:y*stride+w*2]
        for x in range(w):
            b0,b1=row[2*x],row[2*x+1]; v=(b1<<8)|b0
            r5=(v>>11)&0x1F; g6=(v>>5)&0x3F; b5=v&0x1F
            px[x,y]=((r5<<3)|(r5>>2),(g6<<2)|(g6>>4),(b5<<3)|(b5>>2))
    def wh(x,y): c=px[x,y]; return c[0]>150 and c[1]>150 and c[2]>150
    # scan x35..52, y62..78
    print("region '?' x35..52, y62..78 (rot180):")
    for y in range(62,79):
        line=''.join('#' if wh(x,y) else '.' for x in range(35,53))
        if '#' in line:
            print(' y%02d |%s|'%(y,line))
finally:
    r.close()
