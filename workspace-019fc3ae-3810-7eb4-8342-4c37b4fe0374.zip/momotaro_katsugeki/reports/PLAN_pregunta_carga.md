# Plan de rediseño — pantalla "¿Cuál quieres cargar?" (David + Arena)

## Objetivo
Que **"¿Cuál quieres cargar?"** (21 caracteres) salga en **UNA línea**, sin mezclarse
con las opciones de dificultad, dentro de un **bocadillo ancho**.

## Diagnóstico (medido con el emulador)

### El conflicto de tiles
- La **pregunta** (base `$C5AC[0]` = `0x7008`) dibuja 21 chars → **tiles `0x1c0-0x1ca`** (11 tiles, 2 chars/tile).
- La dificultad **"DIFÍCIL 1"** (base `$C5AC[1]` = `0x7148`) dibuja 10 chars → **tiles `0x1c5-0x1c9`** (5 tiles).
- **Se superponen en los tiles `0x1c5-0x1c9`** → por eso se mezclan.

### Por qué la pregunta se ve partida
- El SAT (definido por el **bloque2 `$5C05`**) muestra los 15 sprites de texto en
  **5 filas × 3 columnas** (tiles `0x1c0-0x1d8`).
- La pregunta ocupa 11 tiles, pero el SAT los reparte en varias filas → se ve cortada.

### Los dos mecanismos que hay que mover A LA VEZ (están desacoplados)
- **Destino del glifo** (`$C5AC`): dónde se dibuja el bitmap en VRAM.
- **SAT** (bloque2 `$5C05`): qué tile muestra cada sprite y en qué posición.
- Verificado: mover solo `$C5AC` no cambia el SAT; mover solo el bloque2 rompe el texto.

## Datos clave (HECHO)
- **Base del bloque2**: x=106, y=56. Cada entrada `[code, fl_lo, fl_hi, x, y]` →
  sprite en `(106+x, 56+y)`, tile `=code+0x1C0`.
- Sprite "doble" (fl_hi bit0) ocupa 2 tiles = 32px.
- Pregunta 21 chars = 11 tiles = **6 sprites dobles** para una fila.
- Bocadillo actual (box2): **11 tiles = 88px**, 10 filas interiores.
- Presupuesto tiles: `0x1c0-0x1fb` = 60 tiles. Pregunta(11) + dificultades(16) = 27 → **sobra**.
- Dificultades reales: FÁCIL(5) NORMAL(6) DIFÍCIL(7) MUY DIFÍCIL(11) = 29 chars → 15 tiles.

## Plan de cambios (3 frentes)

### Frente 1 — Reorganizar el bloque2 `$5C05` (el SAT)
Reordenar los **15 sprites** (mismo número, no añadir más) para:
- **Pregunta**: 6 sprites dobles en UNA fila (y=0x00, x=0,0x20,...,0xA0) mostrando tiles `0x1c0-0x1ca`.
- **Dificultades**: los 9 sprites restantes en 2-3 filas (y=0x20, 0x30, ...) mostrando los tiles de cada dificultad.

### Frente 2 — Reubicar destinos `$C5AC` (ROM 0x1A5AC)
Dar a cada bloque un rango de tiles SIN solapar:
- Pregunta: tiles `0x1c0-0x1d5` (base p.ej. `0x7008`).
- Dificultades: tiles libres `0x1d6-0x1fb`.
(Nota: revisar qué tiles muestra cada sprite del bloque2 y hacer que el renderizador
dibuje ahí.)

### Frente 3 — Ensanchar el bocadillo (box2, stream 0x1E0D1)
- De 11 a ~24 tiles de ancho (88px → ~192px) para que quepa la pregunta en una línea.
- Ajustar borde sup `01 9×02 03` → `01 N×02 03`.
- Ajustar interiores `04 9×09 05` → `04 M×09 05`.
- Ajustar los rellenos vacíos `ff 19 00` al nuevo ancho.
- Mantener la estructura de filas y el rabillo.

## Método (seguro)
- Trabajar **por frentes**, verificando tras cada cambio con el emulador:
  - `dstlog` → dónde se dibujan los glifos.
  - SAT → qué sprites/tiles/posiciones se muestran.
  - Imagen → resultado visual.
- Si algo rompe (selector, texto de la carga, otra pantalla), **revertir el cambio**.
- No perder el fix del selector (v08) ni el bloque2 restaurado (v15).

## Notas
- El compositor del SAT en banco 0 (`0xE540+`) está **comprimido** en ROM (se descomprime
  en runtime); por eso es más fiable iterar sobre los DATOS (bloque2, $C5AC) que sobre el código.
- La base del bloque2 (106,56) hay que respetarla; el bocadillo ancho debe centrarse respecto
  a esa base.
