# Prompt para Claude — pantalla "¿Cuál quieres cargar?" con la pregunta rota (v15)

Hola. Te paso una ROM de PC Engine (HuC6280) con una traducción al español de
Momotarou Katsugeki. Ya hemos resuelto casi todo, pero hay un problema complejo en la
pantalla de **"¿Cuál quieres cargar?"**: la pregunta sale **partida en varias líneas**,
con la **interrogación de apertura (¿) invertida/reflejada** y **mezclada con las
opciones de dificultad**. No tengo contexto previo que compartirte; te doy todo lo que
he medido con un emulador instrumentado, y te pido que localices el fix correcto.
**Es muy importante que TÚ mismo verifiques los cambios que hagas** (navega a la
pantalla y comprueba que la pregunta sale bien en una sola línea, sin romper el resto).

## Método (por favor respétalo)

- **Medir → identificar causa → arreglar → verificar**. No parchear a ciegas.
- Marca cada afirmación **[HECHO]** (medido, con evidencia) o **[HIPÓTESIS]**
  (no demostrado). Si una hipótesis se demuestra falsa, márcala **[DESCARTADO]**.
- Verifica con desensamblado real y con el emulador, no con conjeturas.
- Reconoce errores propios explícitamente.

## La ROM (v15 — la que te adjunto)

`Momotarou Katsugeki (Japan) - traduccion_v15_restaurar_bloque2.pce`

- Tamaño: 524288 bytes.
- MD5 `beed9322df14f8f20b12bdaf4f599680`
- SHA-256 `bd63d872352dd33d24d37e4f05bf08c76c34a393ac26358aec666dd4635adcf2`
- CRC32 `75ea4231`

## Cómo reproducir la pantalla "¿Cuál quieres cargar?"

El selector principal ya está bien: opción 0 = "CANTO DE JIZO", opción 1 = "CARGAR".
Para llegar a la pantalla de carga:

1. En el título pulsa **RUN** (tecla ENTER / botón START) → entra al selector.
2. Pulsa **DOWN** (flecha abajo) para mover el cursor a "CARGAR".
3. Pulsa **RUN/ENTER** → llega a la pantalla "¿Cuál quieres cargar?".

Secuencia de botones (ids de RetroArch joypad: RUN=3, RIGHT=7, DOWN=5, UP=4, A=8, B=0):
`RUN 1790-1810 → selector (estable ~1950) → DOWN → RUN → pregunta (estable ~200 frames después)`.

Si usas el **savestate** del juego (battery RAM) `uploads/savestate/Momotarou Katsugeki (Japan).srm`,
es el mismo que se usa para el selector (misma SRM sirve; el juego auto-carga).
También tengo un **.state** capturado **justo al pulsar ENTER en CARGAR** (en plena
transición a la pregunta): `uploads/momotaro.state` (formato contenedor RetroArch:
cabecera 24 bytes + zlib; los datos serializados para `retro_unserialize` son
`zlib.decompress(state[24:])[16:]`). Cargando ese .state y dejando avanzar unos ~200
frames, o pulsando RUN, se llega a la pantalla de la pregunta.

## Qué se ve ahora (HECHO, medido)

La caja (bocadillo) de esa pantalla contiene la pregunta y las opciones, pero está rota:

- La pregunta **"¿Cuál quieres cargar?"** (21 caracteres) **no cabe en una línea**: se
  parte en varias filas cortas.
- La **interrogación de apertura "¿"** se ve **invertida/reflejada** (espejada).
- El texto de la pregunta se **mezcla/colisiona con las opciones de dificultad**
  (FÁCIL / NORMAL / DIFÍCIL / MUY DIFÍCIL) y con el melocotón/puntero.
- El melocotón (puntero de selección) sigue en su sitio; es el texto el que está
  desplazado/roto.

## Datos de ROM clave (HECHO)

- **Texto de la pregunta** = ROM `0x1FB53` (CPU `$5B53`):
  bytes `01 c9 43 b5 bb ac 20 b1 b5 a9 a5 b2 a5 b3 20 5d a1 b2 a7 a1 b2 3f 00`
  = `0x01` + "¿Cuál quieres cargar?" + `0x00`. (21 caracteres; codificación latina).
- **Tabla de punteros del selector de carga** = ROM `0x1F501` (CPU `$5501`), entries
  de 2 bytes (puntero CPU al texto, banco 0x0F):
  - `[0]` = `$5B53` → la pregunta.
  - `[1]` = `$5B10` → "FÁCIL" (`01 3c 46 c2 43 49 4c 00`)
  - `[2]` = `$5B18` → "NORMAL" (`01 3c 4e 4f 52 4d 41 4c 00`)
  - `[3]` = `$5B21` → "DIFÍCIL" (`01 3c 44 49 46 c4 43 49 4c 00`)
  - `[4]` = `$5B2B` → "MUY DIFÍCIL" (`02 3c 4d 55 59 20 44 49 46 c4 43 49 4c 00`)
  - `[5]` = `$5B39` → vacío (`00`).
- **Bloque de datos de sprites de las opciones de dificultad (bloque2)** = ROM `0x1FC05`
  (CPU `$5C05`). Formato: entrada de 5 bytes `[code→tile=code+0x1C0, fl_lo, fl_hi, x, y]`,
  termina en `$FF`. Decodificado:
  ```
  pos 0: code=0f tile=0x1cf fl=0e/00 x=00 y=30
  pos 5: code=10 tile=0x1d0 DOBLE fl=0e/01 x=10 y=30
  pos10: code=12 tile=0x1d2 DOBLE fl=0e/01 x=30 y=30
  pos15: code=14 tile=0x1d4 DOBLE fl=0e/01 x=00 y=40
  pos20: code=16 tile=0x1d6 DOBLE fl=0e/01 x=20 y=40
  pos25: code=18 tile=0x1d8 fl=0e/00 x=40 y=40
  pos30: code=0a tile=0x1ca DOBLE fl=0e/01 x=00 y=20
  pos35: code=0c tile=0x1cc DOBLE fl=0e/01 x=20 y=20
  pos40: code=0e tile=0x1ce fl=0e/00 x=40 y=20
  pos45: code=05 tile=0x1c5 fl=0e/00 x=00 y=10
  pos50: code=06 tile=0x1c6 DOBLE fl=0e/01 x=10 y=10
  pos55: code=08 tile=0x1c8 DOBLE fl=0e/01 x=30 y=10
  pos60: code=00 tile=0x1c0 DOBLE fl=0e/01 x=00 y=00
  pos65: code=02 tile=0x1c2 DOBLE fl=0e/01 x=20 y=00
  pos70: code=04 tile=0x1c4 fl=0e/00 x=40 y=00
  pos75: FF (fin)
  ```
  **NOTA:** este bloque2 fue el que el fix del selector (versión v08) sobrescribió con
  `FF FF FF FF FF`, haciendo desaparecer el texto de la carga. En v15 lo restauramos.
  **No vuelvas a borrarlo** (rompería el texto de la carga de nuevo).
- **Base del CG de sprites** = VRAM `0x2000`. El patrón del tile `n` está en
  `0x2000 + n*0x20` (8x8, 4 planos, 32 bytes/tile).

## Cómo se renderiza el texto (lo que he desensamblado)

- El texto se compone como **sprites** (SAT), no tilemap. Cada carácter es un sprite.
- **Renderizador de texto:** `$AA16` (banco 0x21, ROM `0x42A16`) y subrutinas asociadas.
- El avance del cursor de texto por carácter: en banco 0x0C, ROM `0x19716` hay un
  `ADC #$40` (`69 40`, byte del operando en `0x19717` = `0x40`). **El paso es $40**
  (ancho doble, cada carácter ocupa 2 tiles). Esto limita cuántos caracteres caben por
  línea (en una caja de ~96px caben ~3 glifos dobles).
- El renderizado por glifo usa `$D6BF` (banco 0x0C).
- El SAT se reconstruye cada frame y se sube a `$7F00` (rutina `$E55A`).

### Lo que ya probé (DESCARTADO / temporal)
- Cambiar el paso de glifo de `$40` a `$20` en ROM `0x19717` hizo que la frase quepa
  mejor en una línea, **pero se ve peor** según el usuario (probablemente por colisión
  de tiles y por el doble-buffer del CG). **No lo des por bueno**: es un cambio global
  que afecta a todos los textos del juego y no ataca la colisión de glifos.

## Hipótesis (sin confirmar) — por favor verifícala

La causa más probable de la "¿" invertida y de la mezcla con las dificultades es que
**la pregunta y las opciones de dificultad comparten/colisionan los mismos tiles de
glifos en el CG de sprites** (0x1c0-0x1d8). El mismo tile 0x1c0 que en el selector se
usa para "C" (CANTO DE JIZO) se intenta reutilizar para "¿" en la pregunta, y el
contenido del CG se sobrescribe/queda corrupto.

**Preguntas que necesito que investigues y respondas:**
1. ¿Cómo genera el juego los glifos de la pregunta "¿Cuál quieres cargar?"? ¿Desde
   dónde copia los patrones de caracteres al CG de sprites? (busca el charset/fuente).
2. ¿Por qué la "¿" sale invertida? ¿El glifo del carácter `0xC9` está mal en la fuente,
   o se está aplicando un HFLIP (flag 0x0800 del SAT) por error?
3. ¿Por qué se mezcla la pregunta con las opciones de dificultad? ¿Comparten tiles, o
   hay una colisión de recursos del CG?
4. ¿Cuál es el fix correcto para que **"¿Cuál quieres cargar?" salga en una sola línea**
   dentro de la caja, sin invertirse, sin mezclarse con las opciones y sin romper el
   selector ni el resto del juego?

## Lo que necesito que me des

1. El **offset(s) ROM exacto(s)** y el **cambio de byte(s)** necesario(s).
2. La **verificación**: desensambla lo que toques y, si puedes, simula/navega a la
   pantalla para confirmar que la pregunta sale bien en una sola línea.
3. Confirmar que **no se rompe**: el selector "CANTO DE JIZO/CARGAR" y el texto de la
   carga (que v15 restauró) siguen bien.

La ROM que te adjunto (v15) es la base correcta: el selector va bien, el texto de la
carga ya vuelve a aparecer (gracias a restaurar el bloque2), y solo queda arreglar que
la pregunta salga bien en una línea. Si necesitas más datos medidos (tilemap en runtime,
SAT por frame, trazas, valores de registros), pídemelos y te los saco con el emulador
instrumentado.

Gracias.

## ACTUALIZACIÓN — Datos de runtime que pediste (medidos con el emulador instrumentado)

Capturé los valores exactos con un hook en el PC lógico `$AACF` (banco 0x21, justo donde se
ejecuta `LDA ($14),Y` — es decir, cuando ya se cargó el puntero de fuente y Y es el índice).

### 1. Valores de RAM al procesar la pregunta (HECHO)
- **`$3BA6` = 0** (variante de charset = 0).
- **`$20` = 0** (offset de relocación de banco).
- **Puntero de fuente (variante 0) = `$9CF3`**.
- **`Y` (índice del glifo) para "¿" (`$C9`) = 41 (`0x29`)**.
- **MPR4 = `0x20`** (mapea la página `$8000-9FFF`, donde vive `$9CF3`).

### 2. El byte de la tabla de fuente (HECHO)
- Tabla de fuente var0 en **ROM `0x41CF3`** (banco 0x20, offset `0x9CF3-0x8000=0x1CF3`).
- Para `Y=0x29` (índice del "¿"), el byte es **`0xC9`** (tabla de IDENTIDAD).
- La tabla var1 (`$9CB3`, ROM `0x41CB3`) también devuelve `0xC9` para `Y=0x29`.

### 3. Diagnóstico confirmado (HECHO)
- La "tabla de fuente" `$9CF3` es una **tabla de identidad**: devuelve el mismo código.
- El renderizador (tras `$AAB4`) hace: `byte_crudo × 8`, luego `ADC #$60`/`ADC #$56`,
  y `LDA #$1E; ADC $20; TAM #$02` (banco destino = `$1E`).
- Resultado para "¿" (`$C9`): **addr de glifo `$5CA8`** → **ROM `0x3DCA8`** (banco 0x1E,
  offset `0x1CA8`). Ese patrón es **BASURA** (no es una ¿).
- Resultado para "?" (`$3F`): **addr de glifo `$5858`** → **ROM `0x3D858`**. Ese patrón
  es un "?" **CORRECTO** (lo he renderizado).
- **Conclusión:** el carácter "¿" (`$C9`), que **añadimos nosotros** para el castellano,
  **no tiene un glifo válido** en la fuente de bitmaps del banco 0x1E. El cálculo lo manda
  a una dirección con otro dato, lo que explica el "espejado" y la mezcla visual.

### Fix probable (confírmalo tú)
- Escribir el **bitmap correcto de "¿"** en **ROM `0x3DCA8`** (banco 0x1E, offset `0x1CA8`),
  o re-mapear el código `0xC9` a una entrada de glifo existente/válida.
- **No tocar el renderizador** (`$AAB4`/`$D6BF`).
- No romper el selector (que usa los mismos tiles `0x1c0-0x1d8`) ni el bloque2 (texto de carga).
- Nota: el "ancho de línea" (frase partida) es un problema SEPARADO de la "¿" invertida.
  Decide si se arregla ensanchando la caja o ajustando el paso de glifo, sin afectar otros textos.

### Verificación que te pido
1. Confirma el bitmap correcto de "¿" y dime exactamente el offset y bytes a escribir.
2. Confirma si con eso la "¿" deja de salir espejada.
3. Trata luego el problema de la frase partida (que "¿Cuál quieres cargar?" quepa en una línea).

## ACTUALIZACIÓN 2 — Respuesta a tu pregunta sobre el flag HFLIP vs bitmap

Capturé el SAT en el frame de la pregunta y el glifo real del CG de sprites.

### 1. Flag SAT del sprite "¿" (HECHO)
- El sprite del "¿" es `spr13` (tile `0x1c0`, x=106, y=56):
  - `SATR3 = flags = 0x018e`
  - **HFLIP (bit 0x0800) = NO**
  - **VFLIP (bit 0x8000) = NO**
- (Los sprites con HFLIP que ves, `flags 0x0980/0x0880`, son del PERSONAJE de abajo, tiles 0x140-0x15x, NO del texto de la pregunta.)

### 2. Qué se ve en pantalla en la posición del "¿" (HECHO)
- El glifo del tile `0x1c0` del CG de sprites (base VRAM `0x2000`) renderiza este patrón:
  ```
  |        |
  |#       |
  |       #|
  |       #|
  |      # |
  |      ##|
  |     # #|
  |#    ## |
  ```
- **No es una "¿" reconocible**, ni un "?" al revés limpio. Es una forma ambigua/sin sentido
  (un punto/diagonal arriba-izquierda y un gancho abajo), no un "?" invertido correcto.
- Comparación: el glifo del tile `0x1d8` (un "?" normal) SÍ es un "?" reconocible.
  El "?" invertido verticalmente NO coincide con el tile 0x1c0.

### 3. Conclusión (HECHO)
- **Descartada la hipótesis (b)**: no hay HFLIP/VFLIP en el sprite de "¿".
- Es la **hipótesis (a)**: el **bitmap del "¿" está mal/incompleto** en la fuente.
  El cálculo lo manda a `ROM 0x3DCA8`, cuyo patrón (`30 00 30 1c c6 c6 7c 00`) no es una "¿".
- Aunque el layout de slots es secuencial y "¿" tiene su hueco reservado, el **contenido** de
  ese hueco no es un glifo de "¿" correcto.

### Lo que necesito de ti
- Dado que el bitmap es el problema y NO hay flag HFLIP: prepara el **bitmap correcto de "¿"**
  para escribir en **ROM `0x3DCA8`** (banco 0x1E, offset `0x1CA8`), en el mismo estilo/proporción
  que los glifos `á`/`e` correctos que ya confirmamos.
- Confirma que con ese bitmap la "¿" sale bien (no espejada).
- Trata luego el problema SEPARADO del ancho de línea (frase "¿Cuál quieres cargar?" partida).
