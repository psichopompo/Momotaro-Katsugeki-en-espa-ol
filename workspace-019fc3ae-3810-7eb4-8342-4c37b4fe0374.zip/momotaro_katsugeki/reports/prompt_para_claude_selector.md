# Prompt para Claude (cuenta nueva, sin contexto previo)

Estoy haciendo la traducción al español de **Momotarou Katsugeki (PC Engine / PCE)**, un juego de Hudson Soft. Necesito tu ayuda con un problema concreto del **menú selector "CANTO DE JIZO / CARGAR"**. Te adjunto la ROM actual (versión v05 de la traducción) y te describo TODO lo que ya sabemos con certeza, para que no tengas que re-descubrirlo.

## Contexto del proyecto

- Es una ROM de PC Engine de 512 KiB.
- Ya se tradujeron: título, menú principal, prompt de contraseña y mensaje de error de contraseña (esto último usando sprites de 32px). Esos funcionan.
- El problema actual está en el **selector que aparece tras el menú principal**, con dos opciones:
  - `CANTO DE JIZO`
  - `CARGAR`

## El síntoma visual (confirmado por el usuario en su emulador real)

En la pantalla del selector, el texto **no se ve correctamente**:
- Se lee aproximadamente `CANTO DTO DE` en la primera línea.
- `JIZO CZO C  ARGA` en la segunda.
- El texto **se sale del recuadro (caja/bocadillo) por la derecha**.
- El cursor (un pequeño melocotón) termina montado sobre la "J" de JIZO cuando se baja a la segunda línea.

El texto está en **y 97-122** de la pantalla (verticalmente, mitad-alta).

## Medición de mi modelo de emulación (core Beetle PCE Fast libretro)

Esto lo confirmé instrumentando el core y leyendo VRAM/BAT/SAT directamente. **El texto del selector está en el box central (y90-130)**:

- **El recuadro/caja** es un box de fondo (BG) en el tilemap: filas 11-15 del BAT, columnas 10-21 (12 tiles de ancho), con tiles de marco 101-108 e interior 109. Está en pantalla en x80-176 (~96 px de ancho interior).
- **El texto** se dibuja como **sprites** (CG de sprites en VRAM $7000+), NO en el tilemap. Los glifos están en tiles CG 0x1C0-0x1CA. Leí los tiles bit a bit: son las letras de "CANTO DE JIZO" y "CARGAR".
- **El marco del box** es además un metasprite aparte (lista de sprites): originalmente 64px de ancho, ya lo ampliamos una vez a 96px.

## El problema de fondo

- `CANTO DE JIZO` tiene **13 caracteres**. El texto se compone en **chunks de 32px** (4 caracteres cada uno), así que necesita **4 chunks = 128px** de texto, más margen de 8px a cada lado = **144px** de box.
- El box actual es de **96px**. **Faltan ~48px** de ancho.
- Por eso el texto se sale por la derecha: el box es demasiado estrecho.

## Lo que necesito que hagas

1. **Localiza la rutina/lista que dibuja el marco (caja) del selector** y amplíala de forma coherente para que quepa `CANTO DE JIZO` con un margen de 8px a cada lado (box de ~144px, centrado). Tanto el marco (BG tiles 101-109 en el tilemap) como el metasprite del marco deben quedar coherentes.
2. **Verifica que el texto deja de desbordarse** por la derecha y queda centrado.
3. Aplica el mismo criterio a la pantalla de `CARGAR` (que muestra "¿Cuál quieres cargar?" y una lista de partidas guardadas) si el desborde es análogo.

## Datos técnicos de referencia que ya confirmamos

- El texto se proyecta como **chunks de sprites de 32×16px** (cada chunk usa 2 patrones 16×16). La posición en pantalla la marca una proyección/SAT derivada del índice de tile CG.
- El tilemap en la zona del box (filas 11-15) **no contiene el texto**; solo el box (tiles 101-109) y vacío.
- El marco del box original (japonés): metasprite $4AEE en bank $17, 6 sprites, ancho 64px.
- El marco ampliado actual (v05): metasprite en ROM 0x1FBDC, 8 sprites, ancho 96px. Formato por sprite: tile, pal/attr, attr2, dx, dy. Fila superior: tile 05 dx=0, tile 06 dx=16/48, tile 08 dx=96; fila inferior: tile 00 dx=0, tile 02 dx=32/64, tile 04 dx=96.

## Advertencia importante (método)

- **No busques el texto en el tilemap**: no está ahí. El texto del selector es de sprites.
- No crees listas de sprites duplicadas (eso causó residuos en el prompt antes). Reescribe/amplía la lista existente en su sitio.
- Verifica con medición (volcado de VRAM/SAT y lectura de tiles bit a bit), no solo con la imagen.
- La pantalla visible real es de 256px de ancho.

Si tienes dudas sobre qué pantalla es, dime y te describo el flujo de navegación para llegar a ella.
