# Prompt para Claude — recuperar la "?" de cierre de "¿Cuál quieres cargar?" (pantalla de carga)

## Contexto (autocontenido)

Estamos traduciendo al español **Momotarou Katsugeki** (PC Engine / HuC6280) y ya tenemos
arreglada la **pantalla de carga de partida** (la que muestra "¿Cuál quieres cargar?" y las
partidas guardadas con su dificultad). El texto es de **sprites (SAT)**, no de fondo.

Te adjunto la **ROM de trabajo**: `test_qonerow_final.pce` (MD5 `edc454657308c8e89e9523fed063d9b8`).
También la **ROM japonesa original** `Roms/Original/Momotarou Katsugeki (Japan).pce`
(MD5 `ec7358edb3672a8aa8850623eec72a71`) por si quieres comparar. Puedes regenerar la ROM final
desde el parche `Parches/momotaro_pantalla_carga_v16.ips`.

## El problema (exacto)

La pregunta **"¿Cuál quieres cargar?"** (21 caracteres) debe aparecer **en una sola línea**.
Ya lo conseguimos, pero hay un conflicto con el **desplazamiento horizontal**:

- La pregunta usa 6 sprites del **bloque2** (tabla de datos del SAT en ROM `0x1FC05`):
  tiles `0x1c0, 0x1c2, 0x1c4, 0x1c6, 0x1c8, 0x1ca` (2 caracteres por tile de 16×16).
  El último sprite es el de la **"?" de cierre** (tile `0x1ca`), **simple (16px)**.
- **Regla medida**: la rutina que compone el SAT **descarta cualquier sprite cuya X final sea
  ≥ 234** (X_final = base_x + x_rel, mod 256; base_x efectivo ≈ 106). Lo verifiqué por sonda:
  X=233 aparece, X=234/235/236 desaparece.
- Queremos desplazar el bloque **+3 px a la derecha** para centrarlo. Con ese desplazamiento,
  la "?" pasaría a **X_final = 236** → **el sprite se descarta y la "?" desaparece** de pantalla.

En la ROM `test_qonerow_final.pce`, el bloque2 tiene:
```
[ 6] tile=0x1ca flh=0 x=0x82(130)  -> X_final=(106+130)&0xff = 236  => DESCARTADA
[10] tile=0x1c6 flh=1 x=0x42(66)   -> X_final=172
[11] tile=0x1c8 flh=1 x=0x62(98)   -> X_final=204
[12] tile=0x1c0 flh=1 x=0xe2(226)  -> X_final=76
[13] tile=0x1c2 flh=1 x=0x02(2)    -> X_final=108
[14] tile=0x1c4 flh=1 x=0x22(34)   -> X_final=140
```
Es decir, la pregunta ocupa X de 76 a 204 (sin la "?"), y la "?" iría en 236 (fuera del límite).

## Qué queremos

Que la **"?" de cierre** se vea al final de la pregunta, en su sitio correcto (después de la
"r" de "cargar", a X_final ≈ 236), a pesar de la regla que descarta sprites con X≥234.

## Qué investigar (método estricto: medir → identificar causa → arreglar → verificar)

1. **Localizar el código que compone el SAT** de esta pantalla y que decide descartar sprites
   con X_final ≥ 234. Está en **banco 0**, zona `0xE400-0xE590` (composición de sprites),
   pero ese código está **comprimido en ROM** (patrones `61 60 81 80…`) y se descomprime en
   runtime; por eso el PC de escritura (capturado por watchpoint en VRAM 0x7F00) apunta a esa
   zona. ¿Cómo se decide el descarte y se puede ampliar el límite (o evitarlo)?
2. **Alternativa**: ¿se puede colocar la "?" sin pasarse de X_final < 234 manteniendo el
   espaciado uniforme de la línea? (p. ej. mover la línea completa más a la izquierda, o usar
   otro sprite/anclaje para la "?").
3. **Verificar** con el emulador (el runner `libretro_pce_runner.py` carga ROM+state y lee el
   SAT) que la "?" aparece y que el resto de la pantalla (pregunta, "DIFÍCIL 1", melocotón)
   no se rompe.

## Datos de referencia

- **Texto de la pregunta**: ROM `0x1FB53` (CPU `$5B53`): `01 c9 43 b5 bb ac 20 b1 b5 a9 a5 b2
  a5 b3 20 5d a1 b2 a7 a1 b2 3f 00` (encoding latino; `c9`="¿", `3f`="?"). Referenciado por
  la tabla de textos `$5501[0]` (ROM `0x1F501`).
- **Tabla de destinos** `$C5AC` (ROM `0x1A5AC`): `08 70 08 74 08 76 08 78 08 7a` → 5 filas.
- **Bloque2** (SAT data): ROM `0x1FC05`, 15 entradas de 5 bytes `[code, fl_lo, fl_hi, x, y]`,
  fin `$FF`. tile = code+0x1C0. fl_hi bit0 = sprite "doble" (2 tiles = 32px).
- **Regla SAT**: X_final = base_x + x_rel (mod 256), base_x efectivo ≈ 106. Descarte si X_final ≥ 234.
- **Glifo "¿"**: ROM `0x3DCA8` = `0c 00 0c 38 63 63 3e 00` (derivado de la "?" real rotada 180°).
- **Rutina del melocotón** (cursor): `$C73A`, base_x = `$3C86` + `$35`; `$3C86` se inicializa
  desde la tabla `$C6FC` (ROM `0x1A6FC`). La carga usa la entrada 2 (`$3C86` en ROM `0x1A704`).

## Herramientas (si las necesitas)

- Emulador instrumentado en `/home/user/emutools/beetle-pce-fast-libretro/` (recompilar con
  `make -j4` si tocas fuentes). El runner está en `tools/libretro_pce_runner.py`.
- Desensamblador HuC6280: `tools/dis6280_bin` (recuerda `chmod +x`).
- Save-state para entrar a la pantalla de carga: `downloads/momotaro.state`.

## Entregable

El **offset de ROM exacto** (o banco+dirección) y el **cambio de byte(s)** necesario para que
la "?" se vea en su sitio, junto con la verificación de que la pantalla completa sigue correcta.
Preferiblemente, dame también el parche IPS o los bytes a escribir sobre `test_qonerow_final.pce`.
