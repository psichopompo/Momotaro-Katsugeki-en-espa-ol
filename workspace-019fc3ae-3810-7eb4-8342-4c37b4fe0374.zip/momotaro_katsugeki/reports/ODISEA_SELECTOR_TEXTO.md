# ODISEA: el texto del selector del menú de Momotarou Katsugeki

**Estado:** RESUELTO (2026-08-01)
**Resultado:** "CANTO DE JIZO" y "CARGAR" renderizan correctamente dentro de la caja.
**Siguiente pendiente:** el bocadillo (caja) está escalonado; falta centrar todo.

---

## 1. El síntoma

En la traducción al español del selector (menú de opciones) de Momotarou Katsugeki
(PC Engine), el texto salía corrupto: se veía "CANTO DTO DE / JIZO CZO C ARGA",
el texto se salía del recuadro por la derecha y el melocotón (puntero) se montaba
sobre el texto.

**Texto objetivo:** opción 0 = "CANTO DE JIZO", opción 1 = "CARGAR".

---

## 2. Cómo se llegó a la causa raíz (método)

Método estricto usado durante toda la investigación:
**medir → identificar causa → arreglar → verificar**. Una medición → una causa →
un arreglo → una verificación. Nunca escribir bytes a ciegas.

Herramientas construidas a medida (instrumentación del core Beetle PCE Fast):
- Registro de escrituras a VRAM (`vramlog`) con PC lógico + banco.
- Registro de generación de glifos (`glyphlog`, JSR $D6BF).
- Herramienta de capas: separa fondo vs sprites por píxel y guarda el tile de
  cada sprite (`get_sprtile_buf`).
- Registro del compositor de sprites (PC $E4E3) y del bloque de datos.

---

## 3. Lo que se descartó (con evidencia)

1. **El texto NO está en el tilemap del box central** (tilemap $0000 filas 11-16
   = solo box, tiles 100-111). [DESCARTADO por traza de escrituras]
2. **El texto NO es fondo normal** (DrawBG usa charname*16 desde VRAM 0; el tile
   109 del box usa CG $6D0, no $7000+). [DESCARTADO]
3. **Mover los destinos CG ($C5A8) no arregla el patrón visible** (parches
   v05/v07_fix). El solape visible NO era por solape de slots CG.
4. **v03 está mal analizado en varias sesiones previas**: v03 tenía el selector en
   JAPONÉS (la tabla `$54EB` apuntaba al texto japonés `$54EF/$54FA`; ROM 0x1FB3A
   vacía `$FF`). El texto español está en v07_fix/v08+.

---

## 4. Hallazgo clave: el texto del menú ES de sprites

Con la herramienta de capas se demostró que el texto del menú es de **sprites**
(SAT), no fondo. Tiles de sprite del texto: melocotón `0x1A0` + texto `0x1C0-0x1C8`.

La SAT se reconstruye cada frame del menú (frame 1886+).

---

## 5. La rutina de composición de la SAT (localizada)

Rutina genérica en **banco 0**, `0xE3EB` → `0xE55A`:
- `0xE3EB` init, `0xE417` bucle por entrada, bloque `0xE4C0` (añade sprite a la
  tabla RAM `$26A0-$28A0`), `0xE520` limpia SAT, `0xE55A` sube a SAT `$7F00`.
- **Formato de datos: 5 bytes/entrada** `[code→tile, flg_lo, flg_hi, x_rel, y_rel]`,
  fin `$FF`. El puntero avanza de 5 en 5.
- **CG tile = code + 0x1C0** (patrón RAM = `(code+0x1C0)*2`).
- Sprite **doble** (bit flg_hi 0) renderiza 2 tiles P y P+1 → exige code PAR.
- Sprite **individual** renderiza 1 tile.

---

## 6. La causa raíz: el bloque de datos de sprites

El puntero de datos del texto del menú = `$5BDC` → **ROM `0x1FBDC`** (banco 0x0F).

Contenido original (con codigos DUPLICADOS):
```
L2 "CARGAR":      codes 5, 6, 6, 8   -> tiles 0x1C5, 0x1C6, 0x1C6, 0x1C8  (0x1C6 duplicado)
L1 "CANTO DE JIZO": codes 0, 2, 2, 4  -> tiles 0x1C0, 0x1C2, 0x1C2, 0x1C4  (0x1C2 duplicado)
```

**Los codigos duplicados hacían que el MISMO tile de glifo se renderizara DOS
veces → texto solapado/garbled.**

En el ROM original japonés, ROM 0x1FBDC está todo `$FF` (este bloque lo añadió la
traducción, con los codigos mal).

### Otra sutileza: la generación inyecta un espacio inicial
La generación de glifos escribe un **espacio inicial** (byte `$3C`) antes de cada
texto. Por eso cada texto ocupa un tile más de lo que sugiere su longitud:
- Línea1 "CANTO DE JIZO" (13 letras + espacio = 14 slots) = **7 tiles** `0x1C0-0x1C6`.
- Línea2 "CARGAR" (6 letras + espacio = 7 slots) = **4 tiles** `0x1D0-0x1D3`
  (el tile 0x1D3 contiene la R final).

---

## 7. El bloque corregido (ROM 0x1FBDC)

```
L2 "CARGAR":
  10 0e 00 00 10   -> code 0x10 individual, xrel 0,  yrel 0x10 (tile 0x1D0)
  11 0e 00 10 10   -> code 0x11 individual, xrel 0x10     (tile 0x1D1)
  12 0e 00 20 10   -> code 0x12 individual, xrel 0x20     (tile 0x1D2)
  13 0e 00 30 10   -> code 0x13 individual, xrel 0x30     (tile 0x1D3)

L1 "CANTO DE JIZO":
  00 0e 01 00 00   -> code 0x00 doble,   xrel 0,   yrel 0x00 (tiles 0x1C0,0x1C1)
  02 0e 01 20 00   -> code 0x02 doble,   xrel 0x20          (tiles 0x1C2,0x1C3)
  04 0e 01 40 00   -> code 0x04 doble,   xrel 0x40          (tiles 0x1C4,0x1C5)
  06 0e 00 60 00   -> code 0x06 individual, xrel 0x60       (tile 0x1C6)
  FF
```

Nota: la línea1 usa sprites dobles con codigo PAR (0,2,4,6); la línea2 usa 4
individuales (0x10,0x11,0x12,0x13). El intento previo de usar code 0x11 (impar)
en un doble falló (renderizaba 0x1D0 y 0x1D1 en vez de 0x1D1 y 0x1D2).

---

## 8. Entregables

- **ROM final:** `Roms/Momotarou Katsugeki (Japan) - traduccion_v08_selector_fix.pce`
  - SHA-256 `e74b23bd777660012c4c57933c5be548c5fb8d0742715f64f682793f5bb04003`
  - MD5 `dfe611d1b38a22129f4bd2fb71947026`
  - SHA-1 `750e0727cd24122f8d0eb35e6331b52e41bc74ad`
  - CRC32 `0b913386`
- **Parche IPS:** `Parches/momotaro_traduccion_v08_selector_fix.ips`
  (base = v07_fix, round-trip verificado)
- Base v07_fix SHA-256: `ef31c01b0a1ac0afc1f3a90bf657c65e3fefc351ed854928b9c45728a9c48beb`

### ROMs de prueba intermedias
- `test_sprite_data_v1.pce` (SHA-256 `80422054...`) — fix línea1, línea2 incompleta.
- `test_sprite_data_v2.pce` (SHA-256 `44c5e748...`) — línea2 "CARGA" (faltaba R).
- `test_sprite_data_v3.pce` (SHA-256 `e74b23bd...`) — ambas líneas correctas
  (= ROM final).

---

## 9. Verificación final

- **[HECHO]** Emulador + captura del usuario: línea1 "CANTO DE JIZO" y línea2
  "CARGAR" correctas.
- **[HECHO]** El texto cabe dentro de la caja (no desborda por la derecha).

---

## 10. Pendiente

- **El bocadillo (caja) está escalonado** (bordes en escalera, del experimento v06
  de ensanchar el box que quedó desalineado).
- **Centrar todo** (texto y bocadillo) una vez arreglado el escalonado.
- El usuario medirá los píxeles e indicará cuándo y hacia dónde mover el texto y
  el bocadillo.
