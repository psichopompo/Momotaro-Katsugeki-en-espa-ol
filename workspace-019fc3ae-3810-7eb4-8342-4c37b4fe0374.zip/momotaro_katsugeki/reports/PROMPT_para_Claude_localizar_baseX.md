# Prompt para Claude — localizar dónde se fija la posición horizontal (base_x) del texto del menú

Hola. Te paso una ROM de PC Engine (HuC6280) con una traducción al español de
Momotarou Katsugeki. Necesito tu ayuda para localizar **dónde en el código se fija
la posición horizontal del texto del menú selector**, para poder moverlo 14 píxeles
a la izquierda. No tengo contexto previo que compartirte; te doy todo lo que he
medido con un emulador instrumentado, y te pido que me ayudes a encontrar el punto
exacto a parchear.

## Método que sigo (por favor respétalo)

- **Medir → identificar causa → arreglar → verificar**. No parchear a ciegas.
- Marca cada afirmación como **[HECHO]** (medido, con evidencia) o **[HIPÓTESIS]**
  (no demostrado). Si una hipótesis resulta falsa, márcala **[DESCARTADO]** con motivo.
- No des por hecho offsets; verifica con desensamblado.

## Contexto (todo medido)

Estoy traduciendo el **selector del menú** de Momotarou Katsugeki (PC Engine). El
texto ya renderiza correctamente: opción 0 = "CANTO DE JIZO", opción 1 = "CARGAR",
y la caja (bocadillo) ya es un rectángulo correcto. Solo falta **mover el bloque de
texto 14 píxeles a la izquierda** para centrarlo bien en la caja.

### Cómo se dibuja el texto (verificado)

- El texto del menú es de **sprites** (SAT), no fondo. Se compone con una rutina
  genérica de composición de sprites en **banco 0**, que va de `0xE3EB` a `0xE55A`.
- Esa rutina **lee** la posición base horizontal desde la **zero-page `$4E/$4F`
  (base_x)** y la vertical desde `$50/$51` (base_y), en la instrucción `LDA $4E` en
  `0xE461` (dentro de la composición).
- La composición es genérica: se usa para el texto del menú, el melocotón (cursor)
  y la caja/fondo. Cada grupo se compone con un `base_x` distinto.

### Valores de base_x medidos en runtime (HECHO)

Instrumenté el emulador para capturar la zero-page `$4E` cuando la composición lee
el base_x, y los valores por grupo de sprites son:

| grupo | base_x ($4E) | base_y ($50) | data ptr ($53) |
|---|---|---|---|
| melocotón (cursor) | `0x50` = 80 | `0x58` = 88 | `$0D4B` |
| **texto (lo que quiero mover)** | **`0x58` = 88** | `0x58` = 88 | `$5BDC` |
| caja/fondo | `0x80` = 128 | `0xD0` = 208 | `$CF4D` |

El **objetivo**: que el base_x del texto pase de **88 a 74** (= 88 − 14) para mover
el bloque 14px a la izquierda. El melocotón y la caja NO deben cambiar.

### Quién llama a la composición (HECHO)

- La composición (que lee `$4E` en `0xE461`) es invocada por un **driver del menú en
  banco $0D**, en la zona lógica `0xC3C0-0xC3EF` (ROM offset `0x1A3C0-0x1A3EF`,
  bancos de 8KB: banco `0x0D` = ROM `0x1A000-0x1BFFF`, mapeado a página 6
  `0xC000-0xDFFF`).
- Capturé la **dirección de retorno** de la composición según el grupo:
  - melocotón → retorna a `0xC3E8`
  - **texto → retorna a `0xC3EB`**
  - caja/fondo → retorna a `0xC3EE`

### Pista sobre cómo se calcula base_x (HECHO parcial)

Encontré una rutina en banco 0 en ROM `0x0E8A` (lógico `0xEE8A`) con este código:

```
_TXA                  ; A = X
_CLC
_ADC <$35             ; A = X + $35
_STA <$4E             ; $4E = X + $35   (base_x low)
_CLA
_ADC <$36
_STA <$4F             ; $4F = $36       (base_x high)
_TYA
_CLC
_ADC <$37
_STA <$50             ; $50 = Y + $37   (base_y low)
...
```

Es decir, `base_x = X + $35`. En el momento de la escritura de `$4E=0x58`, medí
`$35=0x00`, así que `X` valía 88 (el base_x venía del registro X). Pero no he podido
localizar **quién pone X=88 (ni `$35`/`$37`) para el texto del menú**, ni la
instrucción exacta que lo hace, porque la captura del PC de la escritura no coincide
con el desensamblado directo del ROM (posiblemente se ejecuta en una región
conmutable o con un mapeo de banco distinto).

### Lo que necesito que investigues

1. **Localizar la instrucción exacta** que fija el `base_x` del texto (88) en el
   driver del menú (banco $0D, ROM `0x1A000-0x1BFFF`, lógico `0xC000-0xDFFF`), o en
   cualquier rutina que invoque con `X=88` (o que ponga `$35`/`$4E` a 88) para el
   texto.
2. Determinar **qué hay que cambiar** para que el texto use `base_x=74` (88−14) sin
   afectar al melocotón (80) ni a la caja (128).
3. Preferiblemente, darme el **offset ROM exacto** y el **cambio de byte(s)**
   necesario, junto con la verificación de que no rompe otras pantallas.

La ROM es la versión más reciente (el texto ya se ve bien y la caja es un
rectángulo). Busca el driver del menú en banco $0D (ROM `0x1A3C0` en adelante, lógico
`0xC3C0`) y las rutinas que llama (`$E17C`, `$E520`, `$E55A`, `$C708`, `$C73A`,
`$C5B6`, `$BB66`, etc.), y rastrea dónde se configura `$4E`/`$35`/`X` para el texto.

Gracias. Si necesitas más datos medidos (valores de registros, trazas de banco, etc.),
pídemelos y te los saco con el emulador instrumentado.
