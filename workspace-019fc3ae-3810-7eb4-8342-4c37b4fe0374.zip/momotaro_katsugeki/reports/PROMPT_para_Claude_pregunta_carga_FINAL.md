# Prompt para Claude (APOYO, no la solución) — pantalla "¿Cuál quieres cargar?" con la pregunta rota

Hola. Te paso una ROM de PC Engine (HuC6280) con una traducción al español de
Momotarou Katsugeki. **Nosotros (el usuario y yo) ya hemos investigado mucho; te pedimos
que actúes como APOYO, verificando nuestro análisis y ayudando a implementar el fix
estructural.** No eres la única vía: lo importante es que TÚ mismo verifiques los cambios
contra la ROM y el comportamiento. Por favor marca [HECHO]/[HIPÓTESIS]/[DESCARTADO].

## La ROM (v15 — la que te adjunto)

`Momotarou Katsugeki (Japan) - traduccion_v15_restaurar_bloque2.pce`

- 524288 bytes. MD5 `beed9322df14f8f20b12bdaf4f599680`
- SHA-256 `bd63d872352dd33d24d37e4f05bf08c76c34a393ac26358aec666dd4635adcf2`
- CRC32 `75ea4231`

## Cómo reproducir la pantalla "¿Cuál quieres cargar?"

1. Título → RUN (ENTER/START) → selector (CANTO DE JIZO / CARGAR).
2. DOWN (flecha abajo) → mueve el cursor a CARGAR.
3. RUN/ENTER → pantalla "¿Cuál quieres cargar?".

Tengo un `.state` capturado **justo al pulsar ENTER en CARGAR**:
`uploads/momotaro.state`. Cargándolo y dejando avanzar ~130-200 frames (o pulsando RUN),
se llega a la pantalla de la pregunta. Los datos medidos abajo usan ese .state.

## Síntoma (lo que ve el usuario)

- La pregunta "¿Cuál quieres cargar?" (21 caracteres) sale **partida en varias líneas**,
  con la **interrogación de apertura "¿" invertida/reflejada**, y **mezclada con las
  opciones de dificultad** (FÁCIL / NORMAL / DIFÍCIL / MUY DIFÍCIL).
- El melocotón (puntero) sigue en su sitio; es el texto el que se ve mal.

## Diagnóstico NUESTRO (medido, verificado) — revísalo y confírmalo

### 1. La "¿" en la fuente es basura (la dejamos a medias) [HECHO]
- El glifo "¿" (código `$C9`) se lee en runtime de **ROM `0x3DCA8`** (banco 0x1E).
  Verificado con emulador instrumentado: el renderizador `$D6BF` lee origen `$5ca8` con
  MPR2=`$1E` → ROM `0x3DCA8`.
- El contenido actual de `0x3DCA8` es **BASURA** (`30 00 30 1c c6 c6 7c 00 ...`), NO un
  "?" invertido.
- El "?" correcto está en **ROM `0x3D858`**.
- **Fix de la "¿"**: copiar el "?" de `0x3D858` e **invertirlo verticalmente**, escribir
  en `0x3DCA8`. Ya generamos el bitmap correcto:
  `70 88 04 42 82 20 40 00 c2 24 18 08 08 04 fc 00 3e 40 40 44 42 fe 40 00 30 08 04 04 42 c2 82 00`
  (verificado visualmente como "¿" correcta).

### 2. Colisión de tiles y desborde (problema estructural) [HECHO]
- La pantalla de carga usa **sprites de texto** (SAT), no tilemap.
- El renderizador `$D6BF`/`$AA16` dibuja los glifos en VRAM `0x7000+` (tiles `0x1c0+`),
  según el destino de la tabla `$C5AC` (ROM `0x1A5AC`):
  `[0x7008, 0x7148, 0x7288, 0x73c8, 0x7508]`.
- El **bloque2** ($5C05, ROM `0x1FC05`) define los sprites de las dificultades con tiles
  `0x1c0-0x1d8` (los mismos del texto). El SAT se deriva del bloque2.
- La **pregunta** (21 chars) se dibuja de `0x7008` a `0x7288`, **invadiendo el bloque 1**
  (dificultad, base `0x7148`). Superponen en `0x7148-0x7248`. **Por eso se mezcla.**
- Aunque pongamos el "¿" correcto en `0x3DCA8`, el tile `0x1c0` se sobrescribe con una
  "C" (colisión con selector/dificultad), así que **el bitmap solo NO basta**.

### 3. El SAT no sigue al cambio de destino en $C5AC [HECHO]
- Movimos el destino de la pregunta a `0x7608` y el SAT NO cambió (sigue en tiles
  `0x1c0-0x1d8`). El SAT del texto está acoplado al bloque2.

## Lo que necesitamos de ti (revisa y propón)

1. **Confirma nuestro diagnóstico** (especialmente el mapeo tile↔VRAM y la colisión).
2. Propón el **fix estructural** para que la pregunta "¿Cuál quieres cargar?" salga en
   UNA sola línea, sin invertirse, sin mezclarse con las dificultades, y sin romper el
   selector (CANTO DE JIZO/CARGAR) ni el texto de la carga.
3. Dado el hallazgo de que el SAT del texto se deriva del **bloque2 ($5C05)** y que la
   pregunta + dificultades comparten los tiles `0x1c0-0x1d8`, valora:
   - ¿Es mejor **separar la pregunta de las dificultades** en bloques de tiles propios?
   - ¿O **ampliar el pool de tiles** (usar tiles libres `0x1d9-0x1fb`, VRAM `0x7640-0x7ef0`,
     que están libres antes del SAT en 0x7f00)?
   - ¿Qué hay que editar exactamente (bloque2, $C5AC, y/o el bitmap de "¿")?
4. Damos **offset(s) ROM exacto(s)** y **cambio(s) de byte(s)**, con verificación.

## Recursos disponibles (si los necesitas)

- Emulador instrumentado con los siguientes logs:
  - `dstlog`: captura cada glifo que se dibuja (código, destino VRAM, origen, MPR2).
  - `fontlog`: captura el byte de la tabla de fuente en `$AACF`.
  - `splog`: captura llamadas a `$E3EB` (compositor de sprites).
- Tablas y offsets ya localizados:
  - Pregunta: ROM `0x1FB53` (CPU `$5B53`).
  - Tabla textos: ROM `0x1F501` (CPU `$5501`).
  - Tabla destinos: ROM `0x1A5AC` (CPU `$C5AC`).
  - Bloque2 (sprites dificultades): ROM `0x1FC05` (CPU `$5C05`).
  - Glifo "?": ROM `0x3D858`; glifo "¿": ROM `0x3DCA8`.
  - Bucle render texto: ROM `0x1A518` (CPU `$C518`); renderizador `$AA16`/`$D6BF`.
- .state: `uploads/momotaro.state`. SRM: `uploads/savestate/Momotarou Katsugeki (Japan).srm`.

**Recordatorio:** esto es un APOYO. Confirma nuestro análisis, propón el fix estructural y
verifícalo. Nosotros (usuario + yo) lo aplicamos y comprobamos en el emulador.

## ACTUALIZACIÓN 3 — Resultado del splog: la pantalla de la pregunta NO usa $E3EB

Capturamos el `splog` (todas las llamadas a `$E3EB`) durante el bug, por las dos vías:

1. **Con el .state** (400 frames desde cargar): **0 llamadas** a `$E3EB`.
2. **Navegando desde el título** (título→RUN→selector→DOWN→CARGAR→RUN→pregunta):
   **0 llamadas** a `$E3EB` en la transición a la pregunta.
   (El selector/título sí usan `$E3EB` — desde `from=$cc22`, ptr `$43d6-$440d`, MPR2=0x17 —
   así que el splog funciona; el resultado 0 en la pregunta es real.)

### Conclusión [HECHO]
- **La pantalla de la pregunta NO usa el compositor genérico de sprites `$E3EB`.**
- El texto de la pregunta se compone con el **renderizador directo** `$C518`/`$AA16`/`$D6BF`
  (banco 0x0C y $AA16), NO con `$E3EB`.
- Por tanto NO hay un "JSR $E3EB con retorno en banco 0x0C" que desensamblar para esta pantalla.
  No pierdas tiempo con `$CC20/$D59B/$DE5D` como callers de $E3EB para el texto de la pregunta.

### Lo que SÍ sabemos del renderizador directo (para el fix estructural)
- `$C518` (ROM 0x1A518) itera los 5 bloques (pregunta + 4 dificultades), fija dest `$16/$17`
  desde la tabla `$C5AC` (ROM 0x1A5AC: `0x7008,0x7148,0x7288,0x73c8,0x7508`), y llama `$AA16`.
- `$AA16`/`$D6BF` (banco 0x0C) escribe el glifo en VRAM[dest] (dest avanza $40 por char).
- El **SAT del texto es FIJO** (tiles 0x1c0-0x1d8, posiciones 5×3), derivado del **bloque2 ($5C05)**.
- La pregunta (21 chars) se dibuja de 0x7008 a 0x7288, **invadiendo el bloque 1** (dificultad,
  base 0x7148). Superponen en 0x7148-0x7248.
- Tiles libres confirmados: 0x1d9-0x1fb (VRAM 0x7640-0x7ef0). Melocotón usa tile 0x1a0 (no choca).

### Bitmap de "¿" (ya corregido, 8 bytes)
- Slot 0xC9 = ROM 0x3DCA8 (8 bytes). Rotación 180° del "?" (0x3D858) =
  `0e 11 20 42 41 04 02 00`. Aplicado solo a ese slot (no tocar 0xCA/0xCB/0xCC).

## ACTUALIZACIÓN 4 — CORRECCIÓN IMPORTANTE: tu cuenta de tiles es incorrecta (medido)

Hemos medido el uso REAL de tiles con `dstlog` y **tu cálculo de 100 tiles está mal**. Es lo más importante que debes saber antes de seguir.

### Cómo funciona el renderizado real (HECHO)
- El renderizador (`$C518`/`$AA16`/`$D6BF`) escribe **cada 2 caracteres en 1 tile de 16×16**
  (el destino avanza `$40` = 64 bytes = 1 tile por cada 2 chars).
- Medido con `dstlog` (estado roto v15):
  - Pregunta "¿Cuál quieres cargar?" (21 chars) = **11 tiles** (destinos 0x7008-0x7288, tiles 0x1c0-0x1ca). NO 42.
  - "DIFÍCIL 1" (10 chars) = 5 tiles (0x7148-0x7248, tiles 0x1c5-0x1c9).

### Cuenta correcta de tiles (HECHO)
```
Pregunta 21 chars → 11 tiles
FÁCIL 5 → 3, NORMAL 6 → 3, DIFÍCIL 7 → 4, MUY DIFÍCIL 11 → 6
TOTAL = 27 tiles
```
Presupuesto disponible (0x1c0-0x1fb): **60 tiles**. **Sobran 33.** No falta espacio de VRAM.

### Tu error
Asumiste 1 tile por carácter. El sistema real usa **2 caracteres por tile** (tile 16×16).
Por eso tu conclusión de "faltan 40 tiles" / "hay que compartir tiles" es incorrecta.

### $DE/$DF NO son saltos de línea (HECHO)
Verifiqué el manejador `$D756`: carga puntero de `$D7CA` (DE→$5B14, DF→$5B1C) y
**copia 8 bytes de un glifo especial a VRAM**. Son glifos, NO control de cursor/línea.
Descarta la hipótesis del salto de línea por $DE/$DF.

### El problema real es de LAYOUT, no de VRAM
- La pregunta (11 tiles) excede el hueco de su bloque en `$C5AC` (20 tiles) e invade el
  bloque de la dificultad (que empieza en 0x7148, dentro del rango de la pregunta).
- Hay tiles de sobra. La solución es **repartir los bloques en `$C5AC`** y/o **rediseñar el
  bloque2 (SAT)** para que la pregunta vaya en una sola línea, y **ensanchar el bocadillo**.
- No hace falta compartir tiles entre palabras.

### Estado del rediseño (nosotros)
- Estamos intentando rediseñar el **bloque2 ($5C05, ROM 0x1FC05)** que define los 15 sprites
  del texto (tiles 0x1c0-0x1d8, posiciones 5×3), para poner la pregunta en una fila.
- Necesitamos confirmar el formato exacto del bloque2 (cómo se interpretan x/y y el flag
  "doble" fl_hi=1). Si puedes desensamblar el compositor que lee `$5C05` (referencia en
  ROM 0x1F5A7), nos ayuda a no romper el selector.
- El bitmap de "¿" ya está corregido (8 bytes, rotación 180°: `0e 11 20 42 41 04 02 00` en 0x3DCA8).

## ACTUALIZACIÓN 5 — Respuesta a tu pregunta (dato confirmado + advertencia)

### Dato que pediste (HECHO)
- El primer carácter de la pregunta se escribe en dest **0x7008**, que está **8 palabras dentro
  del tile 0x1c0** (0x7000-0x7040, tile 16×16). Confirmado con `dstlog`.
- El tile 0x1c0 es el que usa el bloque2 ($5C05) para las dificultades.
- => Tu sospecha es correcta: el arranque de la pregunta pisa el tile del bloque2 desde el primer glifo.

### PERO: he probado mover `$C5AC` y NO arregla la mezcla (HECHO, medido)
- Probé mover el bloque 0 de la pregunta a `0x7000` (alineado a inicio de tile) y a `0x7600`
  (tile libre 0x1d8). **El SAT no cambia** (sigue en tiles 0x1c0-0x1d8) y la pantalla se ve
  idéntica a la rota.
- => El dest del glifo (`$C5AC`) y el SAT (bloque2) están **desacoplados**: mover el dest no
  mueve el SAT. Los sprites del texto los define el bloque2 ($5C05) de forma fija.

### Conclusión para el fix
- Realinear `$C5AC` solo NO basta (lo medí).
- El fix real exige **rediseñar el bloque2 ($5C05)**: dar a la pregunta sus propios tiles y a las
  dificultades los suyos, y mover el dest del glifo ($C5AC) a esos mismos tiles. Dos frentes acoplados.
- Necesitamos desensamblar el compositor que lee `$5C05` para conocer el formato exacto de sus
  posiciones x/y y el flag "doble" (fl_hi=1), sin romper el selector. Referencia del puntero al
  bloque2: ROM `0x1F5A7` (y la tabla de punteros del menú).
- Bitmap de "¿" ya corregido (8 bytes, rotación 180°: `0e 11 20 42 41 04 02 00` en 0x3DCA8).

## ACTUALIZACIÓN 6 — Watchpoint SAT aplicado (tu método)

Apliqué tu método (watchpoint de escritura sobre VRAM 0x7F00+, tiles 0x1c0-0x1d8) durante la pregunta.

### Resultado (HECHO, con limitación)
- Capturé escrituras al SAT con tiles 0x1c0-0x1d8. PCs obtenidos: 0xe4aa, 0xe574, 0xe582, 0xe588,
  0xe58b, 0xe57c, 0xe585, 0xe4be, 0xe4c1, etc. — **banco 0**, todos en la región **$E500-$E590**.
- **El PC varía ±0x20 entre frames** → la captura del PC del vramlog NO es fiable (desfase de la
  instrumentación, peor que los 1-2 bytes que advertiste).
- El melocotón (tile 0x1a0) se escribe desde ~0xe4aa-0xe4c3; el texto (0x1c0-0x1d8) desde ~0xe574-0xe58e.

### Interpretación
- La composición del SAT del texto ocurre en banco 0, región $E500-$E590.
- `$E574` = `JSR $EF5F`; `$E577` = `JMP $C518` (el bucle de texto en banco 0x0C).
- El renderizador `$AA16`→`$D619`→`$D6BF` dibuja los glifos en VRAM 0x7000+ pero NO escribe el SAT
  (lo verificamos). El SAT se sube cada frame desde una tabla RAM intermedia.

### Lo que necesito de ti (contexto que solo tú puedes dar con el desfase en mente)
1. **Desensambla $C518 (banco 0x0C, ROM 0x1A518) y $AA16/$D619/$D6BF** con el desfase corregido,
   y dime **cómo se construye el SAT del texto**: ¿de dónde sale la tabla RAM intermedia que se
   sube a VRAM 0x7F00? ¿Es el bloque2 ($5C05) precargado, o el renderizador la escribe?
2. **Formato exacto del bloque2 ($5C05)**: cómo se traducen x/y a posiciones SAT, y si el flag
   "doble" (fl_hi bit0) hace que el sprite ocupe 2 tiles.
3. **Por qué el dest es 0x7008 (+8)** y si alinearlo a 0x7000 cambia algo.

Con esto rediseño el bloque2 para separar pregunta (11 tiles) y dificultades, y muevo $C5AC en
consecuencia. El bitmap de "¿" ya está corregido (8 bytes, `0e 11 20 42 41 04 02 00` en 0x3DCA8).
