"""modelo_vram.py - Modelo del renderer de texto, validado contra pantalla.

Reproduce lo que se VE en el bocadillo a partir de las lineas de texto.
Validado carater a caracter contra las 4 paginas de test_prueba24_v93.pce
medidas por David en el emulador.

EL MODELO
---------
    por cada 2 caracteres      el cursor VRAM avanza $40 = 1 sprite 16x16
    una fila de pantalla       muestra 8 sprites contiguos = $200 = 16 chars
    el cursor salta por linea  $300  (tabla $D2BB: $7008 $7308 $7608 $7908)

    $300 - $200 = $100 = 4 sprites = 8 caracteres  ->  DERRAME

Los caracteres 17-24 de una linea NO se truncan: se dibujan en la fila de
ABAJO, columnas 0-7. Si la linea siguiente tambien escribe, la pisa.

USO
---
    python3 modelo_vram.py            # ejecuta la validacion
    from modelo_vram import render
    render(['linea 1', 'linea 2'])    # -> {fila: texto}
"""

VISIBLES = 8      # sprites que muestra una fila de pantalla
POR_LINEA = 12    # sprites que abarca el salto de cursor ($300 / $40)


def render(lineas):
    """Devuelve {fila_de_pantalla: texto} tal y como se veria."""
    filas = {}
    for n, txt in enumerate(lineas):
        for i, ch in enumerate(txt):
            spr = i // 2                    # sprite dentro de la linea
            if spr >= POR_LINEA:            # mas alla pisa la linea n+2
                break
            fila = n + spr // VISIBLES      # 0-7 -> fila n ; 8-11 -> fila n+1
            col = (spr % VISIBLES) * 2 + i % 2
            filas.setdefault(fila, {})[col] = ch
    return {f: ''.join(filas[f].get(c, ' ') for c in range(max(filas[f]) + 1))
            for f in filas}


def imprime(lineas, nombre=''):
    if nombre:
        print('=== %s ===' % nombre)
    for f, s in sorted(render(lineas).items()):
        print('   fila %d: %r' % (f, s))


# --- validacion contra lo medido en el emulador ---
R24 = '123456789.123456789.1234'
R20 = '123456789.123456789.'
R16 = '123456789.123456'

MEDIDO = {
    'pag1 (24)':      ([R24],       {0: '123456789.123456', 1: '789.1234'}),
    'pag2 (20)':      ([R20],       {0: '123456789.123456', 1: '789.'}),
    'pag3 (16)':      ([R16],       {0: '123456789.123456'}),
    'pag4 (24+24)':   ([R24, R24],  {0: '123456789.123456',
                                     1: '123456789.123456',
                                     2: '789.1234'}),
}


def valida():
    ok = True
    for nombre, (lineas, esperado) in MEDIDO.items():
        obtenido = render(lineas)
        bien = obtenido == esperado
        ok &= bien
        print('%-14s %s' % (nombre, 'COINCIDE' if bien else 'NO COINCIDE'))
        if not bien:
            for f in sorted(set(esperado) | set(obtenido)):
                print('    fila %d  medido %-20r modelo %r'
                      % (f, esperado.get(f), obtenido.get(f)))
    print('\n%s' % ('MODELO VALIDADO contra las 4 paginas' if ok else 'EL MODELO FALLA'))
    return ok


if __name__ == '__main__':
    valida()
