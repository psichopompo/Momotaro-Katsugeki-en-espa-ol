"""render_bg.py - renderiza el FONDO (BAT) de un volcado de VRAM de state.

Uso:  python3 render_bg.py vram.bin pal.bin salida.png [bat_hex] [ancho] [alto]

  bat_hex : direccion de la BAT en palabras de VRAM (por defecto 0x0000)
  ancho/alto en celdas (por defecto 64x32)

VRAM del PCE: 64 KB = 32768 palabras.  La BAT guarda por celda:
    bits 0-11 = indice de patron   bits 12-15 = paleta de fondo
Cada patron ocupa 16 palabras (32 bytes): 8 filas de plano0/plano1 y
8 filas de plano2/plano3.
Color del PCE: 9 bits  GGG RRR BBB.
"""
import sys
import struct
from PIL import Image


def leer_pal(pal):
    cols = []
    n = len(pal) // 2
    for i in range(n):
        c = struct.unpack('<H', pal[i * 2:i * 2 + 2])[0]
        g = (c >> 6) & 7
        r = (c >> 3) & 7
        b = c & 7
        cols.append((r * 36, g * 36, b * 36))
    return cols


def render(vram, cols, bat=0x0000, w=64, h=32, sub=0):
    """sub=0 -> paletas de fondo (0..15); sub=16 -> paletas de sprites."""
    img = Image.new('RGB', (w * 8, h * 8))
    px = img.load()
    for cy in range(h):
        for cx in range(w):
            o = (bat + cy * w + cx) * 2
            e = struct.unpack('<H', vram[o:o + 2])[0]
            pat = e & 0x0FFF
            pal = ((e >> 12) & 0x0F) + sub
            base = pat * 32
            for y in range(8):
                b0 = vram[base + y * 2]
                b1 = vram[base + y * 2 + 1]
                b2 = vram[base + 16 + y * 2]
                b3 = vram[base + 16 + y * 2 + 1]
                for x in range(8):
                    m = 0x80 >> x
                    v = ((b0 & m) and 1) | ((b1 & m) and 2) | \
                        ((b2 & m) and 4) | ((b3 & m) and 8)
                    ci = pal * 16 + v if v else 0
                    px[cx * 8 + x, cy * 8 + y] = cols[ci] if ci < len(cols) else (255, 0, 255)
    return img


if __name__ == '__main__':
    vram = open(sys.argv[1], 'rb').read()
    cols = leer_pal(open(sys.argv[2], 'rb').read())
    bat = int(sys.argv[4], 16) if len(sys.argv) > 4 else 0
    w = int(sys.argv[5]) if len(sys.argv) > 5 else 64
    h = int(sys.argv[6]) if len(sys.argv) > 6 else 32
    render(vram, cols, bat, w, h).save(sys.argv[3])
    print('escrito', sys.argv[3])
