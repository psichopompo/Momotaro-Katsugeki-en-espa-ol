#!/usr/bin/env python3
"""
geom_v158.py - la geometria del bocadillo 20x4 y su verificacion.

IDEA CENTRAL (medida, no supuesta)
----------------------------------
Hoy el motor guarda DOS tablas indexadas por celda k:

    $9BBD  destino VRAM   2 B por celda
    $9C05  cuadrante      1 B por celda

Para 80 celdas serian 240 B, que no caben en el banco $20.

Pero verificando la tabla de la v157 se comprueba que ambas son redundantes:

    cuadrante = (fila & 1) * 2 + (col & 1)          -> SE CALCULA
    destino   = colbase[col // 2] + (fila // 2) * $80

Solo hace falta `colbase`, una entrada de 2 B por cada COLUMNA DE TILES:
10 columnas = 20 B. Ahorro: 220 B.

Y lo importante: **no exige que los tiles sean contiguos en VRAM**. Cada
columna puede estar donde haya hueco, que es justo lo que tenemos (la mayor
racha libre es de 8 celdas, pero hay 42 celdas disponibles sueltas).

GEOMETRIA
---------
    1 tile de 16x16 = 2 celdas de texto de ancho x 2 de alto
    20 caracteres de ancho -> 10 tiles
     4 lineas de alto      ->  2 tiles
                              -----
                              20 tiles

    +$80 words = +256 B = +2 celdas de 128 B  -> la fila de abajo del mismo
    grupo esta en celda+2.
"""

ANCHO = 20          # caracteres por linea
LINEAS = 4          # lineas por pagina
CELDAS = ANCHO * LINEAS

# celdas de VRAM reutilizables (relleno del bocadillo viejo + libres),
# medidas en docs/aldeano_vram.bin
RELLENO_VIEJO = [0x19D, 0x19F, 0x1A2, 0x1A3, 0x1A6, 0x1A7, 0x1A8, 0x1A9,
                 0x1AA, 0x1AB, 0x1AF]
LIBRES = [0x1B0, 0x1B1, 0x1B2, 0x1C0, 0x1C1, 0x1C2, 0x1C3, 0x1C4, 0x1C5,
          0x1C6, 0x1C7, 0x1CB, 0x1CC, 0x1CD, 0x1CE, 0x1CF, 0x1D4, 0x1D5,
          0x1D6, 0x1D7, 0x1DD, 0x1DE, 0x1DF, 0x1EA, 0x1EB, 0x1EC, 0x1ED,
          0x1EE, 0x1EF, 0x1FA, 0x1FB]


# los 5 sprites de 32x32 del area de texto. Un sprite de 32x32 muestra
# CUATRO celdas consecutivas de VRAM y su base debe estar ALINEADA A 4.
# Medido en docs/aldeano_vram.bin: hay 6 bloques asi disponibles y hacen
# falta 5.
BLOQUES = [0x1A8, 0x1C0, 0x1C4, 0x1CC, 0x1D4]


def columnas(n=ANCHO // 2):
    """Las 10 columnas de tiles, DERIVADAS de los 5 sprites.

    OJO: en la primera version calcule las columnas por un lado y el
    reparto en sprites por otro, y no casaban (salian bases como $1A6 o
    $1CB, que no estan alineadas a 4 y por tanto ningun sprite de 32x32
    puede mostrarlas). Ahora todo se deriva de BLOQUES, que es la
    restriccion dura.

    columna de texto c -> sprite s = c//4, mitad m = (c%4)//2
        celda arriba = BLOQUES[s] + m
        celda abajo  = BLOQUES[s] + m + 2      (= +$80 words)
    """
    cols = []
    for b in BLOQUES:
        for m in (0, 1):
            cols.append((b + m, b + m + 2))
    assert len(cols) == n, 'salen %d columnas y hacen falta %d' % (len(cols), n)
    for a, _ in cols:
        assert a // 4 * 4 in BLOQUES, 'columna %03X fuera de un bloque' % a
    return cols


def colbase(cols=None):
    """Direccion VRAM (en words) de cada columna de tiles."""
    cols = cols or columnas()
    # celda -> word: celda * 128 bytes / 2 = celda * 64
    return [a * 64 for a, _ in cols]


def destino(k, base=None):
    """Para la celda de texto k devuelve (word_destino, cuadrante)."""
    base = base or colbase()
    fila, col = k // ANCHO, k % ANCHO
    w = base[col // 2] + (fila // 2) * 0x80
    q = (fila & 1) * 2 + (col & 1)
    return w, q


def verificar_contra_v157():
    """La formula tiene que reproducir EXACTAMENTE la tabla de la v157."""
    rom = open('roms/test_horizontal_v157.pce', 'rb').read()
    base157 = {}
    for k in range(36):
        d = rom[0x41BBD + k * 2] | (rom[0x41BBD + k * 2 + 1] << 8)
        q = rom[0x41C05 + k]
        fila, col = k // 6, k % 6
        assert q == (fila & 1) * 2 + (col & 1), \
            'cuadrante no calculable en k=%d' % k
        cb = d - (fila // 2) * 0x80
        if col // 2 in base157:
            assert base157[col // 2] == cb, 'colbase inconsistente en k=%d' % k
        base157[col // 2] = cb
    return [base157[i] for i in sorted(base157)]


if __name__ == '__main__':
    b = verificar_contra_v157()
    print('formula validada contra la tabla real de la v157')
    print('  colbase de la v157 (3 columnas):', [hex(x) for x in b])
    print()
    cols = columnas()
    print('columnas elegidas para el 20x4 (%d):' % len(cols))
    for i, (a, c) in enumerate(cols):
        print('   col %2d: celdas %03X y %03X  -> word $%04X' % (i, a, c, a * 64))
    print()
    print('tabla nueva: %d B  (frente a %d B de las dos tablas actuales)'
          % (len(cols) * 2, CELDAS * 3))
    print()
    print('mapa de las 80 celdas:')
    for f in range(LINEAS):
        fila = []
        for c in range(0, ANCHO, 4):
            w, q = destino(f * ANCHO + c)
            fila.append('$%04X:%d' % (w, q))
        print('   linea %d  %s ...' % (f, '  '.join(fila)))
