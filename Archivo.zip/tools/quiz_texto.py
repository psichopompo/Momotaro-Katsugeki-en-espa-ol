#!/usr/bin/env python3
"""quiz_texto.py - Los 40 bloques del QUIZ del ermitanyo, traducidos.

GEOMETRIA MEDIDA EN EL CODIGO (no deducida del relleno)
-------------------------------------------------------
    $DD53  bucle de la PREGUNTA:   LDA $3D28 / CMP #$20 / BCC  -> 32 columnas
           $DD93 (byte $80):       LDA #$10 / STA $3D28  -> salta a la col 16
           => 2 lineas de 16 columnas EXACTAS

    $DAC0  bucle de la OPCION:     LDA $3D28 / CMP #$08 / BCC  -> 8 columnas
           se llama 4 veces con $3D29 = 0,1,2,3
           => linea 0 = rotulo, lineas 1-3 = las tres opciones
           => la columna 0 la tapa el cursor  ->  7 CARACTERES UTILES

    $DB0B / $DD9F comparten la tabla de posiciones VRAM $78E8 (ROM 0x4B8E8),
    16 words. No hay hueco para una 5a columna: el ancho es INAMPLIABLE.

Cada entrada: (linea1, linea2, opcion1, opcion2, opcion3)
El ORDEN de las opciones NO se puede tocar: la respuesta correcta se
identifica por indice.
"""

ROTULO = 'Elige:'          # 8 columnas, sin sangria (el cursor no llega)

COLS_PREGUNTA = 16   # el motor cuenta 16, pero SOLO SE VEN 15 (medido)         # x2 lineas
VISIBLES = 15        # la columna 16 no se pinta: David vio la P4 y la P10
                     # perder el «?» final teniendo 16 caracteres
COLS_OPCION = 8            # 1 de sangria + 7 utiles
UTILES = COLS_OPCION - 1

# (#, linea1, linea2, op1, op2, op3, japones de referencia)
QUIZ = [
    (1,  '¿Qué se trajo', 'Urashima?',
         'Joyero', 'Sustos', 'Plumier',
         'tamatebako / bikkuribako / fudebako'),
    (2,  '¿En qué monte', 'nació Kintaro?',
         'Kintoki', 'Fuji', 'Everest',
         'Ashigara-yama / Yamamoto-yama / Chomolungma'),
    (3,  '¿Qué brotó de', 'la tumba?',
         'Pino', 'Bambú', 'Ciruelo',
         'matsu / take / ume'),
    (4,  '¿De dónde salió', 'la ceniza?',
         'Cebolla', 'Mortero', 'Salsa',
         'nasu / usu / soosu'),
    (5,  '¿Quién le quitó', 'el bulto?',
         'Kappa', 'Ogro', 'Médico',
         'kappa / oni / oishasan'),
    (6,  '¿Adónde volvió', 'Kaguya?',
         'Sol', 'Marte', 'Luna',
         'taiyou / kasei / tsuki'),
    (7,  '¿Qué usó de', 'espada Issun?',
         'Palitos', 'Aguja', 'Palillo',
         'ohashi / hari / tsumayouji'),
    (8,  '¿Qué comió el', 'gorrión goloso?',
         'Pollo', 'Trigo', 'Engrudo',
         'yakitori / mugi / nori'),
    (9,  '¿Qué había en', 'el cesto?',
         'Duendes', 'Leña', 'Cuervos',
         'obake / takigi / karasu'),
    (10, '¿Cuántos viven', 'en tu aldea?',
         '6', '7', '8',
         '6 nin / 7 nin / 8 nin'),
    (11, '¿Qué había en', 'el agujero?',
         'Mamut', 'Topo', 'Ratones',
         'zou / mogura / nezumi'),
    (12, '¿Quién castigó', 'al tanuki?',
         'Zorro', 'Conejo', 'Jirafa',
         'kitsune / usagi / kirin'),
    (13, '¿Qué le tiró al', 'cangrejo?',
         'Caqui', 'Piedra', 'Bola',
         'kaki / ishi / boorinku-dama'),
    (14, '¿Qué recogió', 'el cangrejo?',
         'Semilla', 'Onigiri', 'Dinero',
         'kakinotane / omusubi / okane'),
    (15, '¿Quién era la', 'tetera mágica?',
         'Zorro', 'Camello', 'Tanuki',
         'kitsune / kaba / tanuki'),
    (16, '¿En qué árbol', 'brotó la flor?',
         'Pino', 'Cerezo', 'Abedul',
         'matsu / sakura / shirakaba'),
    (17, '¿Qué hacía el', 'chas-chas?',
         'Tablas', 'Reloj', 'Sílex',
         'hyoushigi / tokei / hiuchiishi'),
    (18, '¿Quién cubrió', 'a los Jizo?',
         'Abuelo', 'Abuela', 'Niño',
         'ojiisan / obaasan / kodomo'),
    (19, '¿Contra quién', 'luchó Ushiwaka?',
         'Ogro', 'Tengu', 'Benkei',
         'oni / karasutengu / benkei'),
    (20, '¿Contra quién', 'luchó al sumo?',
         'Asashio', 'Oso', 'Tigre',
         'asashio / kuma / tora'),
    (21, '¿Qué llevaba', 'Orochi dentro?',
         'Caca', 'Valor', 'Espada',
         'unchi / yuuki-no-ken / kusanagi-no-ken'),
    (22, '¿Cómo se llama', 'la princesa?',
         'Toyo', 'Otohime', 'Peach',
         'toyotamahime / otohime / piichi-hime'),
    (23, '¿Qué pez tragó', 'el anzuelo?',
         'Platija', 'Besugo', 'Luna',
         'hirame / tai / manbou'),
    (24, '¿Qué dios mató', 'a Orochi?',
         'Izanagi', 'Susanoo', 'Pobreza',
         'izanagi / susanoo / binbougami'),
    (25, '¿A qué isla fue', 'el conejo?',
         'Sakura', 'Sado', 'Oki',
         'sakurajima / sadogashima / okinoshima'),
    (26, '¿Cuándo vendió', 'los gorros?',
         'Mayores', 'Fin año', 'Navidad',
         'keirou-no-hi / oomisoka / kurisumasu'),
    (27, '¿Qué deporte', 'hizo Kintaro?',
         'Aeróbic', 'Lucha', 'Sumo',
         'shintaisou / puroresu / sumou'),
    (28, '¿Cuánto valen', 'los momos?',
         '100$', '200$', '300$',
         '100 ryo / 200 ryo / 300 ryo'),
    (29, '¿De qué nació', 'Kaguya?',
         'Pino', 'Bambú', 'Col',
         'matsu / take / kyabetsu'),
    (30, '¿Quién no entró', 'en el zodiaco?',
         'Perro', 'Gato', 'Lagarto',
         'inu / neko / tokage'),
    (31, 'Con el gorro,', '¿qué más puso?',
         'Peluca', 'Medias', 'Toalla',
         'aderansu / sutokkingu / tenugui'),
    (32, '¿Quién compró', 'la tetera?',
         'Señor', 'Bonzo', 'Artista',
         'tonosama / oshou / tabigeinin'),
    (33, '¿Qué le untó al', 'tanuki?',
         'Chile', 'Wasabi', 'Ajo',
         'tougarashi-miso / neri-wasabi / oroshi-ninniku'),
    (34, '¿En qué navegó', 'Issunboshi?',
         'Plato', 'Copita', 'Cuenco',
         'osara / ochoko / owan'),
    (35, '¿Con qué creció', 'Issunboshi?',
         'Porra', 'Mazo', 'Tacones',
         'tonkachi / uchide-no-kozuchi / haihiiru'),
    (36, 'La rata, ¿con', 'quién se casó?',
         'Sol', 'Muro', 'Ratón',
         'ohisama / kabe / nezumi'),
    (37, '¿Qué cazó Ikkyu', 'en el biombo?',
         'Mamut', 'Tigre', 'Lagarto',
         'zou / tora / erimaki-tokage'),
    (38, '¿Qué enseñó el', 'viejo al ogro?',
         'Calva', 'Culo', 'Baile',
         'hage / oshiri / odori'),
    (39, 'En la carrera,', '¿quién ganó?',
         'Liebre', 'Tortuga', 'Empate',
         'usagi / kame / soukyoudai'),
    (40, 'Este juego es', 'Momotaro ¿qué?',
         'Leyenda', 'Acción', 'Tren',
         'densetsu / katsugeki / dentetsu'),
]

def comprueba():
    """Falla ruidosamente si algo no cabe."""
    errores = []
    if len(ROTULO) > COLS_OPCION:
        errores.append('rotulo de %d columnas' % len(ROTULO))
    for n, l1, l2, o1, o2, o3, _jp in QUIZ:
        for etiqueta, txt in (('L1', l1), ('L2', l2)):
            if len(txt) > VISIBLES:
                errores.append('P%d %s: %d columnas  «%s»'
                               % (n, etiqueta, len(txt), txt))
        for i, op in enumerate((o1, o2, o3), 1):
            if len(op) > UTILES:
                errores.append('P%d op%d: %d caracteres  «%s»'
                               % (n, i, len(op), op))
    return errores


if __name__ == '__main__':
    errs = comprueba()
    if errs:
        print('NO CABEN:')
        for e in errs:
            print('  ' + e)
        raise SystemExit(1)
    print('40 preguntas y 120 opciones: todo cabe.')
    print('preguntas  %4d B  (2 x 16 columnas)' % (40 * 32))
    print('respuestas %4d B  (3 x  8 columnas)' % (40 * 24))
