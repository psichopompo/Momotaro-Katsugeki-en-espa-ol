"""texto_es_v83.py - La intro en MAYÚSCULAS Y MINÚSCULAS.

Usa el codificador oficial del proyecto (`charset_oficial.py`), el mismo
con el que David tradujo la pantalla de «El canto de Jizo no es correcto».

CLAVE: las minúsculas y los acentos son bytes >= 0xA0, que van por la
RUTA KATAKANA (glifo = byte, directo). NO pasan por la tabla 0x43F9B, así
que no pueden romper la parrilla del Canto de Jizo ni el menú lateral.

Sólo tres caracteres del texto usan la ruta de la tabla, y con las
entradas que YA trae la ROM base (no se modifica ninguna):
    'b' -> 0x5B -> glifo 0xA2
    'c' -> 0x5D -> glifo 0xA3
    'p' -> 0x5E -> glifo 0xB0

El '!' se codifica 0x21, igual que en la pantalla de error de contraseña,
donde se ve correctamente.

=> ESTA VERSIÓN NO TOCA NI UN BYTE DE LA TABLA 0x43F9B NI DE LA FUENTE.
   Sólo reescribe el texto. Es imposible que rompa otra pantalla.
"""
from charset_oficial import CHAR_TO_CODE

ANCHO = 24
LINEAS_POR_PAGINA = 4

FRASES = [
    ("¡Hola a los que se os dan mal los juegos de acción!", False),
    ("Y a los que se os dan bien... estooo, hola.", False),
    ('¡Esto es "Momotaro en acción", un juego que cualquiera puede superar!',
     True),
    ("¡Si jamás has conseguido terminar un juego de acción, "
     "selecciona el Modo Fácil!", True),
    ("¡No pasa nada si te caes a los barrancos!", False),
    ("¡Tampoco pierdes dinero al morir!", True),
    ("Si vas comprando armas y armaduras, te lo pasarás seguro.", False),
    ("¡Venga, saborea por fin lo que es terminar un juego!", True),
    ("¡Disfruta de la diversión del juego en el Modo Fácil!", True),
    ("¡Y conviértete en todo un experto!", False),
    ("Cuando mejores, ¡prueba también con los demás juegos de Hudson!", True),
]


def _parte(frase, ancho=ANCHO):
    lineas, cur = [], ''
    for palabra in frase.split(' '):
        cand = (cur + ' ' + palabra).strip()
        if len(cand) <= ancho:
            cur = cand
        else:
            if not cur:
                raise ValueError(f'palabra > {ancho}: {palabra!r}')
            lineas.append(cur)
            cur = palabra
    if cur:
        lineas.append(cur)
    return lineas


def paginas():
    pags, actual = [], []
    for frase, nueva in FRASES:
        ls = _parte(frase)
        if len(ls) > LINEAS_POR_PAGINA:
            raise ValueError(f'frase de {len(ls)} líneas: {frase!r}')
        if actual and (nueva or len(actual) + len(ls) > LINEAS_POR_PAGINA):
            pags.append(actual)
            actual = []
        actual.extend(ls)
    if actual:
        pags.append(actual)
    return pags


def n_paginas():
    return len(paginas())


def codifica():
    out = bytearray()
    pags = paginas()
    for p, pagina in enumerate(pags):
        for i, linea in enumerate(pagina):
            for ch in linea:
                if ch not in CHAR_TO_CODE:
                    raise ValueError(f'carácter no soportado: {ch!r}')
                out.append(CHAR_TO_CODE[ch])
            if i != len(pagina) - 1:
                out.append(0x00)
        if p != len(pags) - 1:
            out.append(0xFE)
    out.append(0xFF)
    return bytes(out)


def comprueba(ancho_max=ANCHO, lineas_max=LINEAS_POR_PAGINA):
    problemas = []
    for p, pagina in enumerate(paginas()):
        if len(pagina) > lineas_max:
            problemas.append(f'pág {p+1}: {len(pagina)} líneas')
        for i, linea in enumerate(pagina):
            if len(linea) > ancho_max:
                problemas.append(
                    f'pág {p+1} línea {i+1}: {len(linea)} car. -> {linea!r}')
    return problemas
