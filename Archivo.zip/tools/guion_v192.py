"""guion_v192.py - lee y reescribe el guion comprimido de la rama del otro chat.

Formato (desensamblado de $793B, banco $25):
  $00        fin de cadena (o retorno del diccionario)
  $3B        salto de linea
  $60-$8F    entrada del diccionario: puntero en la tabla $7A13 (48 entradas)
  otro       caracter literal
Solo hay UN nivel de recursion ($DE/$DF guardan el puntero de vuelta).
"""
B24 = 0x48000 - 0x4000      # banco $24 en MPR2
B25 = 0x4A000 - 0x6000      # banco $25 en MPR3
TABLA = 0x4BA13
PUNTEROS = 0x48000
N_TEXTOS = 116


def off(a):
    return (B24 + a) if a < 0x6000 else (B25 + a)


def dic(rom, code):
    p = rom[TABLA + (code - 0x60) * 2] | (rom[TABLA + (code - 0x60) * 2 + 1] << 8)
    return off(p)


def _expande(rom, j, out, prof=0):
    """Copia una entrada del diccionario, expandiendo las anidadas.

    El motor real solo guarda UN puntero de vuelta ($DE/$DF), asi que en la
    ROM solo hay un nivel; la recursion aqui es por seguridad y aborta si
    apareciera mas.
    """
    assert prof < 4, 'diccionario anidado demasiado profundo'
    while rom[j] != 0x00:
        b = rom[j]
        j += 1
        if 0x60 <= b <= 0x8F:
            _expande(rom, dic(rom, b), out, prof + 1)
        else:
            out.append(b)


def leer(rom, o):
    """Descomprime una cadena. Devuelve (bytes_expandidos, fin)."""
    out = bytearray()
    i = o
    while True:
        b = rom[i]
        i += 1
        if b == 0x00:
            return bytes(out), i
        if 0x60 <= b <= 0x8F:
            _expande(rom, dic(rom, b), out)
        else:
            out.append(b)


def punteros(rom):
    return [rom[PUNTEROS + k * 2] | (rom[PUNTEROS + k * 2 + 1] << 8)
            for k in range(N_TEXTOS)]
