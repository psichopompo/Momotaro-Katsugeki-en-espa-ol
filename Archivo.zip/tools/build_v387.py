#!/usr/bin/env python3
"""build_v387.py - Arregla el bug del cuadrado sobre los cerezos (vítores).

DIAGNÓSTICO (medido, ver investigation.md 231-234)
--------------------------------------------------
El gráfico del cerezo son 43 tiles en ROM 0x04900-0x04E60 (banco $02),
que el juego copia a VRAM tile a tile con un TIA montado en RAM ($2580).

La traducción metió DOS cosas dentro de ese bloque:

  a) 0x4B0F y 0x4C07  datos de un gancho ($DFAE) que NO SE EJECUTA NUNCA
  b) 0x4920-0x496F    los glifos Á É Í Ó Ú de la fuente del MENÚ

Lo (b) no es descuido de la traducción: la fuente del menú ocupa
0x4000-0x4CFF y el árbol empieza en 0x4900, o sea que **el solape ya existe
en la ROM japonesa**. El japonés no lo nota porque no usa glifos altos.

ARREGLO
-------
PASO 1 - quitar el gancho muerto y devolver esos bytes al árbol.
PASO 2 - mover los 43 tiles del árbol al hueco libre del banco $3F y
         reapuntar el cargador. Así el árbol deja de compartir espacio con
         la fuente, y los glifos de David se quedan donde están.

El cargador está en $DB60 (ROM 0x19B60) y mapea el banco con
    LDA #$02 / CLC / ADC $20 / TAM #$04
Basta cambiar ese #$02 por #$3F y ajustar la base de la dirección
($DBD2: ADC #$44) para que apunte al árbol en su nueva casa.
"""
import hashlib
import zlib

SRC = 'roms/Momotaro Katsugeki (Español).pce'
JP = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v387.pce'

ARBOL_INI, ARBOL_FIN = 0x04900, 0x04E60      # 43 tiles x 32 B = 1376 B
DESTINO = 0x7F900                            # banco $3F, alineado a 32 B

rom = bytearray(open(SRC, 'rb').read())
jp = open(JP, 'rb').read()
orig = bytes(rom)

# ---- PASO 1: el gancho muerto -------------------------------------------
assert bytes(rom[0x1D955:0x1D958]) == bytes([0x20, 0xAE, 0xDF]), 'firma $D955'
rom[0x1D955:0x1D958] = bytes([0x20, 0xE2, 0xBA])     # JSR $DFAE -> JSR $BAE2
assert rom[0x1D95C] == 0x24, 'firma LDY'
rom[0x1D95C] = 0x18                                   # LDY #$24 -> LDY #$18
assert all(b != 0xFF for b in rom[0x1DFAE:0x1DFB0])
rom[0x1DFAE:0x1DFDE] = b'\xFF' * 0x30                 # borrar la cueva

for a, b in ((0x4B0F, 0x4B54), (0x4C07, 0x4C76)):     # devolver al árbol
    rom[a:b] = jp[a:b]

# ---- PASO 2: mover el árbol ----------------------------------------------
# OJO: el árbol se copia de la ROM JAPONESA, no de la nuestra. La nuestra
# lo tiene contaminado con los glifos del menú (0x4920-0x496F), que es
# justo lo que queremos dejar atrás. Copiar de rom[] se lleva el bug.
arbol = bytes(jp[ARBOL_INI:ARBOL_FIN])
assert len(arbol) == 1376, len(arbol)

# el hueco tiene que estar libre de verdad
assert all(b == 0xFF for b in rom[DESTINO:DESTINO + len(arbol)]), 'hueco ocupado'
assert DESTINO % 32 == 0, 'destino sin alinear a 32 B'
assert DESTINO + len(arbol) <= 0x80000

rom[DESTINO:DESTINO + len(arbol)] = arbol

# el banco que se mapea en MPR2: #$02 -> #$3F
assert bytes(rom[0x19B60:0x19B66]) == bytes([0xA9, 0x02, 0x18, 0x65, 0x20, 0x53])
rom[0x19B61] = 0x3F

# la base de la dirección CPU: $DBD2 ADC #$44.
#   original: ROM 0x04900 -> CPU $4900 con el banco $02 en MPR2
#   ahora:    ROM 0x7F900 -> CPU $5900 con el banco $3F en MPR2
#             ($3F*0x2000 = 0x7E000; 0x7F900-0x7E000 = 0x1900 -> $4000+$1900)
nueva_base = 0x4000 + (DESTINO - 0x3F * 0x2000)       # = $5900
delta = (nueva_base - 0x4900) >> 8                    # desplazamiento alto
assert rom[0x19BD3] == 0x44, hex(rom[0x19BD3])
rom[0x19BD3] = (0x44 + delta) & 0xFF

# el árbol viejo deja de usarse; se rellena con lo que tenía la japonesa
# (así los glifos de David en 0x4920-0x496F siguen intactos donde la fuente
#  los espera, y el resto vuelve a su contenido original)
# NO se toca: la fuente del menú vive ahí.

open(DST, 'wb').write(bytes(rom))

d = sum(1 for i in range(len(rom)) if rom[i] != orig[i])
print('%s  %d B' % (DST, len(rom)))
print('  paso 1: gancho $DFAE eliminado, 2 tramos devueltos al árbol')
print('  paso 2: árbol movido 0x%05X -> 0x%05X (%d B)' % (ARBOL_INI, DESTINO, len(arbol)))
print('          banco $02 -> $3F   base $44 -> $%02X' % rom[0x19BD3])
print('  bytes cambiados: %d' % d)
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
