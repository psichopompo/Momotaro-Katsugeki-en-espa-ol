#!/usr/bin/env python3
"""build_v381.py - Los dos menus secretos: Sound Test y Graphics Test.

BASE: v379 (c4f83eedc60e15ecec889ed69b69553c)

    Sound Test     «SALA DE SONIDO»
    Graphics Test  «GALERIA DE ARTE»   (con I acentuada), centrado y sin
                   los dos dakuten que dejaba el japones

Eran los dos ultimos sitios del juego que seguian en kana. No se veian
como japones sino como basura (`//u.s ua"vx e`), porque las tablas de
glifos $9CB3 y $9CF3 se reescribieron para el alfabeto latino desde antes
de la v306. En la ROM japonesa virgen se leen perfectamente; en la nuestra
no, asi que traducirlos los arregla.

LOS DOS USAN MOTORES DISTINTOS **Y CHARSETS DISTINTOS**
--------------------------------------------------------
Error mio al montarlo la primera vez: use los codigos de TILE (A=$70) en
el Sound Test, y ese va por el motor de rotulos, que usa **ASCII**
(A=$41). Se veia basura. Verificado en pantalla escribiendo A..Q en ASCII:
se lee «ABCDEFGHIJKLMNOP» perfecto.

    Sound Test     motor de rotulos $AAB4  ->  ASCII        A=$41 S=$53
    Graphics Test  volcado directo al BAT  ->  codigo tile  A=$70 S=$82

1) SOUND TEST - ROM 0x1F1E3, banco $0F
   Cadena normal del motor de rotulos: $01 + texto + $00.
   Hueco medido: **17 bytes** (0x1F1E4..0x1F1F4). Detras empieza una tabla
   de datos (`14 52 14 52 ...`), asi que no puede crecer.
   Medido en pantalla: de esos 17 se pintan **16 columnas**, el byte 17 no
   se ve. La cadena arranca en la columna 8 de 32.

2) GRAPHICS TEST - ROM 0x0291A, banco $01
   NO es una cadena: son codigos de tile crudos que un bucle vuelca al
   BAT, incrustados detras de un RTS.

       C8E6  CLX
       C8E7  LDA $C91A,X      <- operando en ROM 0x028E8
       C8EA  STA $0002        <- puerto VDC
       C8F2  INX
       C8F3  CPX #$0D         <- el 13, en ROM 0x028F4
       C8F5  BCC $C8E7

   El limite de 13 es ese `$0D`, no el hueco. Como detras de los 13 bytes
   empieza codigo real (`LDA $37F8`), la cadena se **repunta** al hueco
   libre de $DE73 y se sube el contador a 15.

EL HUECO $DE73 ESTA LIBRE (comprobado, no supuesto)
---------------------------------------------------
397 bytes de $FF consecutivos desde ROM 0x03E73, identicos al japones.
Barrido de los 512 KB buscando punteros LE en $DE73..$DF00: 14
coincidencias, **las 14 byte a byte iguales a la ROM japonesa**, o sea
ruido dentro de datos y no referencias. Ninguna apunta a $DE73 como
puntero real.

POR QUE NO «SALA DE MUSICA»
---------------------------
Cabia, pero la U acentuada sale **minuscula**: en esta pantalla `$3BA6`
vale **1** (medido en vivo), y con esa tabla ($9CB3) el codigo $C6 no da
la U de David sino el glifo $7F, que es la u minuscula. Sale «SALA DE
MuSICA».

Se descartaron dos arreglos por riesgo:
  - cambiar la entrada [38] de $9CB3: rompe la **P** en otros textos.
  - reutilizar un codigo duplicado libre ($E6): aparece **74 veces** en
    zonas de texto del juego.

David eligio «SALA DE SONIDO», que ademas describe mejor el contenido
(no solo musica: tambien efectos).

CENTRADO
--------
32 columnas de pantalla, la cadena arranca en la columna 8.

    SALA DE SONIDO   14 -> (32-14)//2 = 9  -> 1 espacio delante, col 9..22
    GALERIA DE ARTE  15 -> (32-15)//2 = 8  -> sin espacio,        col 8..22

Se centran **sin tocar el destino VRAM**: basta el espacio dentro de la
propia cadena.

LA FUENTE ES LA MISMA QUE LA DE LA v379
---------------------------------------
Comprobado tile a tile contra la VRAM: A=$70, S=$82, M=$7C, C=$72...
coinciden con la fuente de dialogo 0x3D660. Las vocales acentuadas que
dibujo David en la v379 salen tambien aqui.
"""
import hashlib
import sys
import zlib

BASE = 'roms/momotaro_es_v379.pce'
MD5_BASE = 'c4f83eedc60e15ecec889ed69b69553c'

# --- Sound Test ---
SND_CMD = 0x1F1E3           # el $01 que abre
SND_INI = 0x1F1E4
SND_FIN = 0x1F1F5           # el $00 terminador
SND_HUECO = SND_FIN - SND_INI               # 17

# --- Graphics Test ---
GFX_VIEJO = 0x0291A         # los 13 tiles originales
GFX_OPERANDO = 0x028E8      # los 2 B del LDA $C91A,X
GFX_CPX = 0x028F4           # el $0D de CPX #$0D
GFX_NUEVO = 0x03E73         # hueco libre, CPU $DE73
GFX_NUEVO_CPU = 0xDE73
GFX_ST1 = 0x028DC           # operando de ST1 #$0A: columna del texto
GFX_DAK = 0x0290A           # operando de LDA #$96: el tile del dakuten

TEXTO_SND = ' SALA DE SONIDO'      # 15 -> se rellena a 17
TEXTO_GFX = 'GALERÍA DE ARTE'      # 15 exactos

# Graphics Test: codigos de TILE (los de la fuente de dialogo 0x3D660)
COD = {' ': 0x00}
for _i, _c in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    COD[_c] = 0x70 + _i
COD.update({'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6})

# Sound Test: motor de rotulos -> ASCII puro
COD_SND = {' ': 0x20}
for _i, _c in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
    COD_SND[_c] = 0x41 + _i

INTACTAS = [
    (0x00000, 0x028DC, 'todo lo anterior a la columna'),
    (0x028DD, 0x028E8, 'entre la columna y el operando'),
    (0x028EA, 0x028F4, 'entre el operando y el CPX'),
    (0x028F5, 0x0290A, 'entre el CPX y el dakuten'),
    (0x0290B, 0x0291A, 'entre el dakuten y la cadena vieja'),
    (0x02927, 0x03E73, 'del codigo del banco $01 al hueco'),
    (0x03E82, 0x1F1E4, 'del hueco al Sound Test: TODO el juego'),
    (0x1F1F5, 0x80000, 'del Sound Test al final: quiz, creditos, finales'),
]


def enc(txt, tabla):
    return bytes(tabla[c] for c in txt)


def main(salida):
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v379'
    assert len(rom) == 524288, 'la ROM no mide 512 KB'

    # ---------- 0. el estado de partida es el que creo -------------------
    assert rom[SND_CMD] == 0x01, 'el Sound Test no abre con $01'
    assert rom[SND_FIN] == 0x00, 'el Sound Test no cierra con $00'
    assert SND_HUECO == 17, 'el hueco del Sound Test no mide 17'
    # el japones que vamos a sustituir
    assert rom[SND_INI:SND_INI + 3] == b'\x20\xd3\xd3', \
        'en 0x1F1E4 no esta el japones que espero'

    viejo = bytes([0x23, 0x23, 0x10, 0x2B, 0x03, 0x00, 0x1B,
                   0x0C, 0xA7, 0x12, 0x00, 0x0C, 0x12])
    assert rom[GFX_VIEJO:GFX_VIEJO + 13] == viejo, \
        'en 0x0291A no estan los 13 tiles japoneses'
    assert rom[GFX_OPERANDO - 1] == 0xBD, 'en 0x028E7 no hay un LDA abs,X'
    assert rom[GFX_OPERANDO:GFX_OPERANDO + 2] == b'\x1a\xc9', \
        'el operando no apunta a $C91A'
    assert rom[GFX_CPX - 1] == 0xE0, 'en 0x028F3 no hay un CPX #imm'
    assert rom[GFX_CPX] == 0x0D, 'el contador no vale 13'
    assert rom[GFX_ST1 - 1] == 0x13, 'en 0x028DB no hay un ST1'
    assert rom[GFX_ST1] == 0x0A, 'la columna del texto no es 10'
    assert rom[GFX_DAK - 1] == 0xA9, 'en 0x02909 no hay un LDA #imm'
    assert rom[GFX_DAK] == 0x96, 'el tile del dakuten no es $96'
    # el hueco esta limpio
    assert all(b == 0xFF for b in rom[GFX_NUEVO:GFX_NUEVO + 32]), \
        'el hueco de $DE73 no esta limpio'

    # ---------- 1. Sound Test: cadena de 17, centrada --------------------
    s = enc(TEXTO_SND, COD_SND)
    assert len(s) <= SND_HUECO, 'el texto del Sound Test mide %d' % len(s)
    s = s + bytes([0x20] * (SND_HUECO - len(s)))     # rellenar con espacios
    assert len(s) == 17
    rom[SND_INI:SND_FIN] = s

    # ---------- 2. Graphics Test: repuntar y ampliar el contador ---------
    g = enc(TEXTO_GFX, COD)
    assert len(g) == 15, 'el texto del Graphics Test mide %d' % len(g)
    rom[GFX_NUEVO:GFX_NUEVO + len(g)] = g
    rom[GFX_OPERANDO] = GFX_NUEVO_CPU & 0xFF
    rom[GFX_OPERANDO + 1] = GFX_NUEVO_CPU >> 8
    rom[GFX_CPX] = len(g)

    # ---------- 2b. centrar: la columna la fija ST1 #$0A -----------------
    # VRAM $010A = fila 4, columna 10. Para 15 caracteres el centro de una
    # pantalla de 32 columnas es (32-15)//2 = 8  ->  VRAM $0108.
    col = (32 - len(g)) // 2                 # 8 para 15 caracteres
    rom[GFX_ST1] = (4 * 64 + col) & 0xFF     # fila 4 -> VRAM $0108

    # ---------- 2c. borrar los DAKUTEN del japones -----------------------
    # La rutina de C8F7 escribe DOS VECES el tile $96 en VRAM $00D0
    # (fila 3, columnas 16 y 17): son los dos puntitos de «bijutsu». En
    # castellano sobran y se ven como unas comillas encima de la palabra.
    # Se neutraliza poniendo el tile vacio ($00), sin tocar la estructura.
    rom[GFX_DAK] = 0x00
    # la cadena vieja queda muerta: se deja como estaba (es inofensiva y
    # tocarla seria pisar bytes sin necesidad)

    # ---------- VERIFICACION --------------------------------------------
    assert len(rom) == 524288, 'la ROM cambio de tamanyo'

    # releer el Sound Test siguiendo su estructura
    assert rom[SND_CMD] == 0x01 and rom[SND_FIN] == 0x00
    rel = rom[SND_INI:SND_FIN]
    inv = {v: k for k, v in COD_SND.items()}
    txt = ''.join(inv.get(b, '?') for b in rel)
    assert txt.strip() == TEXTO_SND.strip(), 'el Sound Test releido es %r' % txt

    # releer el Graphics Test siguiendo el operando
    dst = rom[GFX_OPERANDO] | (rom[GFX_OPERANDO + 1] << 8)
    assert dst == GFX_NUEVO_CPU, 'el operando no quedo repuntado'
    off = 0x02000 + (dst - 0xC000)
    assert off == GFX_NUEVO, 'el operando no resuelve al hueco'
    n = rom[GFX_CPX]
    assert n == 15, 'el contador no quedo en 15'
    assert rom[GFX_ST1] == 0x08, 'la columna no quedo en 8'
    assert rom[GFX_DAK] == 0x00, 'el dakuten no quedo neutralizado'
    inv2 = {v: k for k, v in COD.items()}
    txt2 = ''.join(inv2.get(b, '?') for b in rom[off:off + n])
    assert txt2 == TEXTO_GFX, 'el Graphics Test releido es %r' % txt2

    # no queda kana suelto en las dos zonas
    assert rom[SND_INI:SND_FIN].count(0xD3) == 0, 'queda kana en el Sound Test'

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    open(salida, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % salida)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print('  Sound Test    «%s»' % txt)
    print('  Graphics Test «%s»' % txt2)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '/tmp/v380.pce')
