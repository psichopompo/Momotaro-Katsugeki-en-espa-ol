#!/usr/bin/env python3
"""v401 - el baño, con la estructura REAL de la pantalla (2 páginas de 34 B).

QUÉ SE APRENDIÓ CON LA CAPTURA DE LA PÁGINA 2 (la que faltaba)
--------------------------------------------------------------
Yo trataba el bloque como 4 líneas contiguas. **No lo es.** Es una pantalla
de DOS PÁGINAS, y cada página ocupa **34 bytes**, de los que sólo se ven los
**32 primeros** como 2 líneas de 16. Los 2 bytes de cola no se pintan.

    página 1   0x4AC45 + 0    líneas en +0  y +16
    página 2   0x4AC45 + 34   líneas en +34 y +50

Verificado contra las TRES capturas de David, dos ROMs distintas:

    v399 (yo escribía a 17)  pág.2 -> '¡Suerte, hermano' / '!¡Je, je! ¡Je, j'
    v400 (yo escribía a 16)  pág.2 -> 'uerte, chaval!¡J' / 'e, je, je, je!  '

En los dos casos el modelo de 34 reproduce **exactamente** lo que se ve, y
el de 32 (4 líneas contiguas) no. Por eso en la v400 la página 2 salía
desplazada 2 caracteres y comida por la izquierda: el ancho de 16 era
correcto, lo que estaba mal era **dónde empieza cada página**.

TEXTO (redacción de David)
--------------------------
    pág.1   ¡Sí existía el / baño femenino!
    pág.2   ¡Qué suerte, / chaval! ¡Gufufu!

Sus razones: «¡Suerte, chaval!» parecía que le desearan suerte, cuando le
están diciendo que es afortunado; y la risa japonesa es «gufufu», no «je,
je». La primera frase, además, quedaba coja partida en dos páginas.
"""
import hashlib, sys
sys.path.insert(0, 'tools')
import texto

BASE = "roms/momotaro_es_v400.pce"
SAL  = "roms/momotaro_es_v401.pce"
MD5_BASE = "6bb6c9cb1bd4bf88506804132e6f590f"

INI, PAG, ANCHO, FIN = 0x4AC45, 34, 16, 0x4AC8B

PAGINAS = [("¡Sí existía el", "baño femenino!"),
           ("¡Qué suerte,",   "chaval! ¡Gufufu!")]

DIRECTO = {0x5B: 0xA2, 0x5D: 0xA3, 0x5E: 0xB0, 0x5F: 0xDE}


def sin_alias(b):
    return bytes(DIRECTO.get(x, x) for x in b)


def main():
    d = bytearray(open(BASE, "rb").read())
    assert hashlib.md5(d).hexdigest() == MD5_BASE, "la base no es la v400"
    orig = bytes(d)

    assert INI + len(PAGINAS) * PAG <= FIN, "no caben las páginas"

    for p, (l1, l2) in enumerate(PAGINAS):
        for l in (l1, l2):
            assert len(l) <= ANCHO, "línea de más de %d: %r" % (ANCHO, l)
        base = INI + p * PAG
        for k, l in enumerate((l1, l2)):
            e = sin_alias(texto.codifica(l))
            assert not any(x in (0x5B, 0x5D, 0x5E) for x in e), "alias en %r" % l
            d[base + k*ANCHO: base + (k+1)*ANCHO] = e + b"\xA0" * (ANCHO - len(e))
        # los 2 bytes de cola de la página: no se ven, se dejan en blanco
        d[base + 2*ANCHO: base + PAG] = b"\xA0" * (PAG - 2*ANCHO)

    # cola sobrante hasta el quiz
    d[INI + len(PAGINAS)*PAG: FIN] = b"\xA0" * (FIN - (INI + len(PAGINAS)*PAG))

    # ------------- comprobaciones -------------
    assert texto.decodifica(d, d[FIN:FIN+17]) == "¡Acierta y ganas ", "el quiz se ha movido"
    assert not any(x in (0x5B, 0x5D, 0x5E) for x in d[INI:FIN]), "queda un alias"
    # nada fuera de la zona del baño
    dif = [i for i in range(len(d)) if d[i] != orig[i]]
    for i in dif:
        assert INI <= i < FIN, "byte fuera de la zona del baño: 0x%X" % i
    assert d[:0x48000] == orig[:0x48000], "se ha tocado código"
    # Capa y Kaguya, intactas (las aprobó David)
    assert d[0x48A16:0x48A2A] == orig[0x48A16:0x48A2A], "la Capa ha cambiado"
    assert d[0x4A403:0x4A484] == orig[0x4A403:0x4A484], "Kaguya ha cambiado"

    open(SAL, "wb").write(d)
    print("%s   %d bytes" % (SAL, len(dif)))
    print("  MD5   ", hashlib.md5(d).hexdigest())
    print("  SHA-1 ", hashlib.sha1(bytes(d)).hexdigest())
    print()
    for p in range(len(PAGINAS)):
        b = INI + p*PAG
        print("  página %d:" % (p+1))
        for k in range(2):
            print("     %r" % texto.decodifica(d, d[b+k*ANCHO:b+(k+1)*ANCHO]))

main()
