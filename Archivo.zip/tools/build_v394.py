#!/usr/bin/env python3
r"""build_v394.py - A-VIT2: quita los cuadrados blancos de la transición de los cerezos.

EL BUG
------
Antes de que los cerezos aparezcan bien se ven 2-3 frames con **cuadrados
blancos** sobre las copas. Medido con `states/vitores_jp_david.state`,
contando tiles del árbol rellenos de $FF (blanco sólido):

    JP        384:[ff 0] 385:[ff 0] 386:[ff 0] 387:[ff 0] 388:[ff 0]
    ES v393   384:[ff 0] 385:[ff 0] 386:[ff 0] 387:[ff 4] 388:[ff21]

**La japonesa NUNCA tiene ninguno; la nuestra llega a 21.**

LA CAUSA (entrada 262)
----------------------
El cargador del árbol (`$DB60`, ROM 0x19B60) recorre TRES listas de 48
slots, una por frame, y calcula el origen con una **fórmula lineal**
(`$DBC0`): `origen_CPU = ($54 << 8) + t*32`, con `t` = índice de tile.

Las listas usan **t = 0..82: OCHENTA Y TRES tiles**, no 43:

    pase 0  ($DBF9)  t =  0..11
    pase 1  ($DC29)  t = 12..39
    pase 2  ($DC59)  t = 40..82

El bloque completo son 83*32 = 2656 B: ROM `0x04400`-`0x04E60`.

**La v388 movió al banco `$3F` sólo los 43 últimos** (`0x04900`-`0x04E60`,
t=40..82), porque eran los únicos que la traducción había ensuciado. Los
40 primeros (t=0..39) se quedaron sin copiar, y como la base `$54` sitúa
t=0 en ROM `0x7F400`, los pases 0 y 1 leían de `0x7F400`-`0x7F900`, que
estaba a `$FF`. De ahí los cuadrados blancos.

El pase 2 (t=40..82) sí encuentra sus tiles y **reescribe por encima**, así
que el resultado final es correcto: el bug es sólo visible durante la
transición. Por eso se catalogó como «2 frames de artefactos».

EL ARREGLO: SÓLO REMAPEAR ÍNDICES, SIN TOCAR UN BYTE DE GRÁFICO
----------------------------------------------------------------
[DESCARTADO] El primer intento copiaba los 40 tiles que faltan a `0x7F400`,
escribiendo sólo donde había `$FF`. **Rompía el bocadillo de la intro**: los
`$FF` de `0x7F800`-`0x7F8F1` NO son hueco, son parte del **CG comprimido**
del bocadillo. Norma 375.

Y resultó innecesario. Medido:

**El pase 2 reescribe TODOS los destinos de los pases 0 y 1**:

    destinos pase0 \ pase2 = {}   (vacío)
    destinos pase1 \ pase2 = {}   (vacío)

O sea: los pases 0 y 1 son **sólo la animación de aparición progresiva**; el
contenido definitivo lo pone el pase 2, cuyos 43 tiles (t=40..82) SÍ están
completos y limpios en 0x7F900.

Así que no hace falta espacio nuevo: basta con que los pases 0 y 1 lean de
la zona buena. Para cada slot se sustituye su índice `t` por el índice del
pase 2 que escribe **en el mismo destino VRAM**:

    pase 0:  t0->t55  t1->t56  t2->t57  t3->t58  t4->t63 ...   (12 slots)
    pase 1:  t12->t41 t13->t42 t14->t43 t15->t44 t16->t47 ...  (28 slots)

**40 bytes cambiados, 0 bytes de espacio nuevo.** La animación conserva
exactamente el mismo ritmo (mismos slots, mismos destinos, mismo número de
copias por frame): lo único que cambia es de DÓNDE se leen los píxeles.

Con esto los 16 tiles incompletos dejan de importar: nadie los lee.

NO se toca:
  - el árbol movido en `0x7F900` (los 43 tiles de la v388)
  - `0x19B61` = $3F y `0x19BD3` = $54 (el repunte del cargador)
  - el gancho `$DFAE` ni el marco del bocadillo de minijuegos
  - los 459 B de datos de la traducción que viven en la zona

DESCARTADO POR EL CAMINO
------------------------
Primero creí que la causa era otra: la traducción metió TRES CADENAS de
texto dentro de las propias listas de slots, en bytes que en la japonesa
son `$FF` (`0x19BF9` «0 momos», `0x19C1F` «¡Puaj!», `0x19C50` «Objetos»).
Como el criterio de «slot vacío» es el bit 7 (`BMI` en `$DB87`) y nuestros
caracteres son < $80, el cargador se los tragaba como índices de tile:
**20/32/43 slots válidos en vez de 12/28/43.**

Es un bug real y se arregla aquí también, pero **NO era la causa de los
cuadrados blancos**: sacando las cadenas, los $FF seguían saliendo (20).
Se corrige igualmente porque hace que el cargador copie 12 tiles basura.
"""
import hashlib
import re
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_oficial as co

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v393
DST = 'roms/momotaro_es_v394.pce'
JPR = 'roms/Momotarou Katsugeki (Japan).pce'

BANCO = 0x0C
def cpu(off):
    assert BANCO * 0x2000 <= off < (BANCO + 1) * 0x2000
    return 0xC000 + (off - BANCO * 0x2000)

# --- las tres cadenas metidas dentro de las listas ------------------------
CADENAS = [
    ('0 momos', 0x19BF9, 9),    # pase 0, Y=0..8
    ('¡Puaj!',  0x19C1F, 8),    # pase 0, Y=38..45
    ('Objetos', 0x19C50, 9),    # pase 1, Y=39..47
]
HUECO_A = (0x19A65, 18)     # $DA65, hueco de $00 libre
HUECO_B = (0x197FA, 13)     # $D7FA, hueco de $00 libre
LISTAS = [('pase0', 0x19BF9), ('pase1', 0x19C29), ('pase2', 0x19C59)]


rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
jp = open(JPR, 'rb').read()

# ---- 0. el estado de partida es el que creo ------------------------------
for nom, off, n in CADENAS:
    esperado = bytes([0x01]) + bytes(co.CHAR_TO_CODE[c] for c in nom) + b'\x00'
    assert bytes(rom[off:off + n]) == esperado, (
        'en 0x%05X no está «%s»' % (off, nom))
    assert all(b == 0xFF for b in jp[off:off + n]), (
        'en la japonesa 0x%05X no es relleno $FF' % off)
for off, n in (HUECO_A, HUECO_B):
    assert all(b == 0x00 for b in rom[off:off + n]), 'hueco 0x%05X sucio' % off

assert rom[0x19B61] == 0x3F and rom[0x19BD3] == 0x54, (
    'el cargador no apunta al banco $3F: la v388 no está aplicada')
assert bytes(rom[0x7F900:0x7FE60]) == jp[0x04900:0x04E60], (
    'los 43 tiles de la v388 no están intactos')

def validos(buf, off):
    return sum(1 for x in buf[off:off + 48] if x < 0x80)

antes = [validos(rom, o) for _, o in LISTAS]
jp_ok = [validos(jp, o) for _, o in LISTAS]
assert antes == [20, 32, 43], 'slots válidos inesperados: %s' % antes
assert jp_ok == [12, 28, 43], 'la japonesa no da 12/28/43: %s' % jp_ok

# ---- 1. sacar las cadenas de las listas ----------------------------------
#
# PUNTEROS VERIFICADOS UNO A UNO (entrada 263). El barrido automático de
# words dio SEIS candidatos y CUATRO eran falsos positivos que reventaron la
# v394: `0x18532` y `0x18F43` son código (`20 dc` = el opcode JSR más el byte
# bajo del destino), y `0x47BBA`/`0x47BF2` son el operando de `LDA $DBFA,Y`
# en el banco $23, que ahí es una tabla de índices (`00 01 02 01 00 03 04 03`),
# no nuestro texto. Escribir en 0x18532 destrozó un `JSR $C6DC` del bucle
# principal y la ROM arrancaba en negro.
#
# Los tres punteros REALES, desensamblados y comprobados:
#
#   «0 momos»  ->  0x199BC / 0x199C0   partido en dos LDA # (norma 369):
#                  $199BB  A9 F9  LDA #$F9 / 85 BF  STA $BF
#                  $199BF  A9 DB  LDA #$DB / 85 C0  STA $C0
#   «¡Puaj!»   ->  0x19A61   word en tabla del banco $0C
#   «Objetos»  ->  0x197F2   word en tabla del banco $0C
#
# NO se busca con `re`: se escriben a mano y se comprueba el byte esperado.
PUNTEROS = {
    '0 momos': [('split', 0x199BC, 0x199C0)],   # LDA #lo en +0, LDA #hi en +4
    '¡Puaj!':  [('word', 0x19A61)],
    'Objetos': [('word', 0x197F2)],
}

destinos = {}
cur, fin = HUECO_A[0], HUECO_A[0] + HUECO_A[1]
for nom, off, n in CADENAS:
    if cur + n > fin:
        cur, fin = HUECO_B[0], HUECO_B[0] + HUECO_B[1]
    assert cur + n <= fin, 'no cabe «%s»' % nom
    rom[cur:cur + n] = orig[off:off + n]
    destinos[nom] = cur
    print('«%s» 0x%05X -> 0x%05X  ($%04X -> $%04X)'
          % (nom, off, cur, cpu(off), cpu(cur)))
    cur += n

for nom, off, n in CADENAS:
    rom[off:off + n] = jp[off:off + n]          # relleno $FF, como la JP

despues = [validos(rom, o) for _, o in LISTAS]
assert despues == jp_ok, 'los slots no cuadran con la JP: %s' % despues
print('slots válidos por pase: %s -> %s   (JP %s)' % (antes, despues, jp_ok))

# repuntar, comprobando SIEMPRE el byte que había antes
for nom, off, n in CADENAS:
    viejo, nuevo_off = cpu(off), cpu(destinos[nom])
    for tipo, *args in PUNTEROS[nom]:
        if tipo == 'word':
            r = args[0]
            assert rom[r] == (viejo & 0xFF) and rom[r + 1] == (viejo >> 8), (
                'en 0x%05X no está el word $%04X' % (r, viejo))
            rom[r], rom[r + 1] = nuevo_off & 0xFF, nuevo_off >> 8
            print('  word 0x%05X: $%04X -> $%04X' % (r, viejo, nuevo_off))
        else:
            rlo, rhi = args
            assert rom[rlo - 1] == 0xA9 and rom[rhi - 1] == 0xA9, (
                'en 0x%05X/0x%05X no hay dos LDA #' % (rlo, rhi))
            assert rom[rlo] == (viejo & 0xFF) and rom[rhi] == (viejo >> 8), (
                'los LDA # no cargan $%04X' % viejo)
            rom[rlo], rom[rhi] = nuevo_off & 0xFF, nuevo_off >> 8
            print('  LDA# 0x%05X/0x%05X: $%04X -> $%04X'
                  % (rlo, rhi, viejo, nuevo_off))

# ---- 2b. remapear los índices de los pases 0 y 1 a los tiles del pase 2 --
# El pase 2 reescribe todos sus destinos, así que los pases 0 y 1 pueden
# leer de la zona buena (0x7F900) en vez de la incompleta (0x7F400).
dest_tab = jp[0x19C89:0x19C89 + 48]
p2 = {}
lst2 = jp[0x19C59:0x19C59 + 48]
for y in range(48):
    if lst2[y] < 0x80:
        p2[dest_tab[y]] = lst2[y]

# comprobación previa: todo destino de los pases 0 y 1 lo cubre el pase 2
for nom, off in (('pase0', 0x19BF9), ('pase1', 0x19C29)):
    l = jp[off:off + 48]
    faltan = {dest_tab[y] for y in range(48) if l[y] < 0x80} - set(p2)
    assert not faltan, '%s tiene destinos que el pase 2 no reescribe: %s' % (
        nom, sorted(faltan))

remap = 0
for off in (0x19BF9, 0x19C29):
    for y in range(48):
        if rom[off + y] < 0x80:
            nuevo = p2[dest_tab[y]]
            assert 40 <= nuevo <= 82, 'el tile %d no es del pase 2' % nuevo
            rom[off + y] = nuevo
            remap += 1
print('índices remapeados a los tiles del pase 2: %d' % remap)
assert remap == 40, 'esperaba 40 remapeos, hice %d' % remap

# el ritmo de la animación no cambia: mismos slots ocupados que la japonesa
for nom, off in LISTAS:
    assert [x < 0x80 for x in rom[off:off + 48]] == \
           [x < 0x80 for x in jp[off:off + 48]], 'cambió el patrón de slots en %s' % nom

# ---- 3. nada ajeno se ha tocado -----------------------------------------
tocado = set(range(0x19BF9, 0x19BF9 + 48)) | set(range(0x19C29, 0x19C29 + 48))
for nom, off, n in CADENAS:
    tocado |= set(range(off, off + n))
    tocado |= set(range(destinos[nom], destinos[nom] + n))
    for tipo, *args in PUNTEROS[nom]:
        tocado |= {args[0], args[0] + 1} if tipo == 'word' else set(args)
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos <= tocado, sorted(distintos - tocado)[:8]

# NORMA 375: la zona 0x7F400-0x7F900 NO se toca. Sus $FF no son hueco:
# 0x7F800-0x7F8F1 es CG comprimido del bocadillo de la intro y lleva $FF
# DENTRO como dato. Escribir ahí dejaba el bocadillo rayado.
assert bytes(rom[0x7F400:0x7F900]) == orig[0x7F400:0x7F900], (
    'tocada la zona 0x7F400: ahí vive el CG del bocadillo de la intro')
# el árbol de la v388 y el repunte del cargador, intactos
assert bytes(rom[0x7F900:0x7FE60]) == jp[0x04900:0x04E60], 'el árbol se ha tocado'
assert rom[0x19B61] == 0x3F and rom[0x19BD3] == 0x54, 'repunte del árbol perdido'
# el pase 2 queda intacto; los pases 0 y 1 sólo con los índices remapeados
assert bytes(rom[0x19C59:0x19C59 + 48]) == jp[0x19C59:0x19C59 + 48], 'pase2 tocado'
for off in (0x19BF9, 0x19C29):
    for y in range(48):
        if jp[off + y] >= 0x80:
            assert rom[off + y] == jp[off + y], 'slot vacío tocado en 0x%05X' % (off + y)
# y la tabla del cargador NO se ha repuntado
assert bytes(rom[0x19BF3:0x19BF9]) == b'\xf9\xdb\x29\xdc\x59\xdc', (
    'la tabla del cargador $DBF3 se ha tocado: %s' % rom[0x19BF3:0x19BF9].hex())

# ---- 3b. NORMA 374: el código no se ha tocado ---------------------------
# La v394 rota escribió dentro de un `JSR` y la ROM arrancaba en negro.
for r in (0x18532, 0x18F43, 0x47BBA, 0x47BF2):
    assert rom[r:r + 2] == orig[r:r + 2], (
        'falso positivo escrito en 0x%05X: eso es CÓDIGO' % r)
assert rom[0x18530:0x18536] == orig[0x18530:0x18536], 'JSR $C6DC pisado'

# ---- 4. las cadenas se releen bien desde el puntero (norma 370) ----------
inv = {v: k for k, v in co.CHAR_TO_CODE.items()}
for nom, off in destinos.items():
    i, txt = off + 1, ''
    while rom[i] != 0x00:
        txt += inv.get(rom[i], '{%02X}' % rom[i])
        i += 1
    assert txt == nom, 'en 0x%05X se lee %r, no %r' % (off, txt, nom)
print('las tres cadenas se releen correctas desde su nueva dirección')

open(DST, 'wb').write(bytes(rom))
print()
print('%s  %d B' % (DST, len(rom)))
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
