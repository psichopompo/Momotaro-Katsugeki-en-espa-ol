#!/usr/bin/env python3
"""
maquetar.py - reparte un texto en paginas de bocadillo.

El problema que planteo David: un reparto voraz («mete palabras hasta que no
quepan») deja el hueco al final, y en un dialogo corto que el jugador lee
muchas veces se ve fatal:

    voraz                        equilibrado
    +--------------------+       +--------------------+
    |Vaya... Que perro   |       |Vaya... Que perro   |
    |tan fuerte...       |       |tan fuerte...       |
    |¿Sabias que los     |       |¿Sabias que los     |
    |perros de ahora     |       |perros de ahora     |
    +--------------------+       +--------------------+
    +--------------------+       +--------------------+
    |lanzan bombas       |       |lanzan bombas       |
    |de mano?            |       |de mano?            |
    +--------------------+       +--------------------+

Dos reglas:

1. **Equilibrar las lineas** (algoritmo de Knuth-Plass simplificado):
   minimiza la suma de los huecos AL CUADRADO, no el numero de lineas. Elevar
   al cuadrado penaliza mucho una linea muy corta y poco varias medio llenas,
   que es justo lo que se quiere.

2. **Repartir las lineas entre paginas a partes iguales**: si un texto ocupa
   5 lineas y la pagina admite 4, no se hace 4+1 sino 3+2. Asi no queda
   nunca una pagina con una palabra suelta.

Nada de esto toca el texto: solo decide DONDE se corta.
"""
import math

INF = float('inf')


def _coste(w, i, j, ancho):
    L = sum(len(x) for x in w[i:j]) + (j - i - 1)
    return INF if L > ancho else (ancho - L) ** 2


def lineas_minimas(texto, ancho):
    """Numero minimo de lineas que ocupa el texto (reparto voraz)."""
    n, ln = 0, ''
    for p in texto.split():
        if not ln:
            ln = p
        elif len(ln) + 1 + len(p) <= ancho:
            ln += ' ' + p
        else:
            n += 1
            ln = p
    return n + (1 if ln else 0)


def en_n_lineas(texto, ancho, nlineas):
    """Parte el texto en EXACTAMENTE nlineas minimizando los huecos^2.
    Devuelve None si es imposible."""
    w = texto.split()
    n = len(w)
    if nlineas > n:
        return None
    dp = [[INF] * (nlineas + 1) for _ in range(n + 1)]
    nx = [[n] * (nlineas + 1) for _ in range(n + 1)]
    dp[n][0] = 0
    for k in range(1, nlineas + 1):
        for i in range(n - 1, -1, -1):
            for j in range(i + 1, n + 1):
                c = _coste(w, i, j, ancho)
                if c == INF:
                    break
                if c + dp[j][k - 1] < dp[i][k]:
                    dp[i][k] = c + dp[j][k - 1]
                    nx[i][k] = j
    if dp[0][nlineas] == INF:
        return None
    out, i, k = [], 0, nlineas
    while k:
        j = nx[i][k]
        out.append(' '.join(w[i:j]))
        i = j
        k -= 1
    return out


def maquetar(texto, ancho=20, por_pagina=4):
    """Devuelve lista de paginas; cada pagina es lista de lineas.

    Reparte las lineas a partes iguales entre las paginas necesarias, para
    que ninguna quede con una sola palabra."""
    minimo = lineas_minimas(texto, ancho)
    paginas = max(1, math.ceil(minimo / por_pagina))
    # cuantas lineas usar en total: las minimas, pero repartidas por igual
    # entre las paginas; probamos desde el minimo hasta llenar las paginas
    for total in range(minimo, paginas * por_pagina + 1):
        r = en_n_lineas(texto, ancho, total)
        if r is None:
            continue
        # repartir 'total' lineas en 'paginas' grupos lo mas iguales posible
        base, resto = divmod(total, paginas)
        cortes, i = [], 0
        for p in range(paginas):
            n = base + (1 if p < resto else 0)
            cortes.append(r[i:i + n])
            i += n
        # ninguna pagina puede pasarse del limite
        if all(len(c) <= por_pagina for c in cortes):
            return cortes
    # ultimo recurso: voraz
    ls, ln = [], ''
    for p in texto.split():
        if not ln:
            ln = p
        elif len(ln) + 1 + len(p) <= ancho:
            ln += ' ' + p
        else:
            ls.append(ln)
            ln = p
    if ln:
        ls.append(ln)
    return [ls[i:i + por_pagina] for i in range(0, len(ls), por_pagina)]


def informe(texto, ancho=20, por_pagina=4):
    pgs = maquetar(texto, ancho, por_pagina)
    huecos = [ancho - len(l) for pg in pgs for l in pg]
    return {
        'paginas': len(pgs),
        'lineas': sum(len(p) for p in pgs),
        'hueco_medio': sum(huecos) / len(huecos),
        'hueco_max': max(huecos),
    }


if __name__ == '__main__':
    import sys
    sys.path.insert(0, 'docs')
    import traduccion as T
    peor = []
    for tid in sorted(T.TEXTOS):
        for t in T.TEXTOS[tid]:
            inf = informe(t)
            peor.append((inf['hueco_medio'], tid, inf))
    peor.sort(reverse=True)
    print('los 10 textos con mas hueco (tras equilibrar):')
    for h, tid, inf in peor[:10]:
        print('  [%2d] %d pag, %d lineas, hueco medio %.1f, max %d'
              % (tid, inf['paginas'], inf['lineas'], h, inf['hueco_max']))
    tot = sum(informe(t)['paginas'] for ps in T.TEXTOS.values() for t in ps)
    med = sum(informe(t)['hueco_medio'] for ps in T.TEXTOS.values() for t in ps) / 87
    print('\ntotal paginas: %d   hueco medio global: %.1f caracteres' % (tot, med))
