"""check_huecos.py - Comprueba el hueco de fondo comparando con la geometria.

Metodo directo: para cada rotulo se toma la FILA DE BANDA superior (la
primera fila entre el borde redondeado y las letras) y se exige que el
blanco sea CONTINUO de borde a borde. Es exactamente lo que David ve.
"""
import sys, os
import numpy as np
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
from render_rotulos import Render, escenas


def fila_banda(img):
    a = np.array(img.convert('RGB'))
    w = (a[:, :, 0] > 240) & (a[:, :, 1] > 240) & (a[:, :, 2] > 240)
    k = (a[:, :, 0] < 40) & (a[:, :, 1] < 40) & (a[:, :, 2] < 40)
    fil = [y for y in range(a.shape[0]) if w[y].sum() > 60]
    y0, y1 = fil[0], fil[-1]
    # filas con glifo: las que tienen negro en el interior de la caja
    xs = np.where(w[(y0 + y1) // 2])[0]
    bi, bd = int(xs.min()), int(xs.max())
    con_glifo = [y for y in range(y0, y1 + 1) if k[y, bi + 12:bd - 11].any()]
    g0 = min(con_glifo) if con_glifo else y1
    y = g0 - 1                      # ultima fila de banda antes de las letras
    xs = np.where(w[y])[0]
    d = np.diff(xs)
    hue = [(int(xs[i]) + 1, int(xs[i + 1]) - 1) for i in np.where(d > 1)[0]]
    return y, int(xs.min()), int(xs.max()), hue


if __name__ == '__main__':
    lay = {'M': 0x1DC88, 'ncaj_m': int(sys.argv[2]) if len(sys.argv) > 2 else 4,
           'A': 0x2FB8C, 'ncaj_a': int(sys.argv[3]) if len(sys.argv) > 3 else 6}
    R = Render(sys.argv[1])
    malos = 0
    for nom, img in escenas(R, lay):
        y, x0, x1, hue = fila_banda(img)
        if hue:
            malos += 1
            det = 'HUECO ' + ', '.join('x %d..%d (%d px)' % (a, b, b - a + 1) for a, b in hue)
        else:
            det = 'blanco continuo %d..%d' % (x0, x1)
        print('%-28s %s' % (nom, det))
    print('\n%s' % ('%d rotulos con hueco' % malos if malos else 'NINGUN hueco de fondo'))
