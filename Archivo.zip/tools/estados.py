"""estados.py - Carga los savestates de David (RetroArch, comprimidos RZIP).

Los .state de David NO son un MDFNSVST plano: son
    "#RZIPv\\x01#" + 16 B de cabecera + zlib
y una vez descomprimidos, el bloque que traga el core empieza en el
offset 16. Medido, no supuesto.
"""
import glob
import zlib


def descomprime(path):
    raw = open(path, 'rb').read()
    assert raw[:8] == b'#RZIPv\x01#', 'no es un savestate RZIP: %s' % path
    return zlib.decompress(raw[24:])


def carga(p, path):
    """Carga el savestate en la instancia PCE. Devuelve True si entra."""
    d = descomprime(path)
    n = len(p.state())
    i = d.find(b'MDFNSVST')
    for off in ([i] if i >= 0 else []) + [16, 0, 32]:
        if off < 0:
            continue
        if p.load_state(d[off:off + n]):
            return True
    return False


def busca(patron, carpeta='/home/user/descargas/finales'):
    """Los nombres llevan tildes descompuestas: filtrar por substring."""
    for f in sorted(glob.glob(carpeta + '/*.state')):
        base = f.rsplit('/', 1)[-1]
        if all(t in base for t in patron.split()):
            return f
    raise FileNotFoundError(patron)
