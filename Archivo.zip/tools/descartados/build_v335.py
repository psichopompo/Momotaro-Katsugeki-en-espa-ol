#!/usr/bin/env python3
"""build_v335.py - La tabla de presentacion de enemigos, repuntada.

EL BUG QUE VIO DAVID
--------------------
David: «tiene partes traducidas (la presentacion de los enemigos) y estan
mal cortadas y no estan sincronizadas con los enemigos que van saliendo,
van como un enemigo o dos despues».

Reproducido en el emulador con su savestate «Final Normal»: sale
«ñeco Gigante!» mientras en pantalla hay un pulpo.

MI PRIMER DIAGNOSTICO FUE FALSO
-------------------------------
Dije que faltaba un `$00` y que los bloques se habian fusionado (35 en vez
de 36). **No.** Los 38 textos estan enteros y bien escritos.

Lo que pasa es que hay una **TABLA DE PUNTEROS** en `0x24DE`, con entradas
de 8 bytes, y **sigue apuntando a los offsets JAPONESES**:

    entrada  puntero   apunta a          deberia
    ------------------------------------------------
      4      $67C3     media frase       $67C5
      8      $6856     «o, mejor ...»    $684C
     17      $6983     «Nieve!»          $698B
     18      $69A0     «ñeco Gigante!»   $69AF
     24      $6A57     cadena vacia      $6A7F

Los textos castellanos tienen otras longitudes, asi que cada puntero cae a
media palabra. El desfase crece hasta 40 bytes.

**Es exactamente el mismo bug que las 14 tecnicas de la v326** (norma 304:
bloque troceado por $00, comprobar si hay tabla que lo indexa y repuntarla).
Van dos veces con el mismo patron, en dos zonas distintas.

ARREGLO
-------
Se trocea el bloque real por `$00` y se reescriben los 38 punteros. Ni un
byte de texto se toca.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402

BASE = 'roms/momotaro_es_v334.pce'
SALIDA = 'roms/momotaro_es_v335.pce'
MD5_BASE = '7608edb92eeccae3eed71f8c618d1a0e'

TABLA = 0x24DE          # 38 entradas de 8 B; el puntero son los 2 primeros
N = 38
PASO = 8
TEXTOS = 0x4A739        # primer texto de la seccion
CPU_BASE = 0x6000
ROM_BASE = 0x4A000

INTACTAS = [
    (0x00000, 0x024DE, 'todo lo anterior a la tabla'),
    (0x02606 + 2, 0x80000, 'todo lo posterior'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v334'
    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    # --- trocear los textos REALES por $00 -------------------------------
    textos = []
    ini = TEXTOS
    for o in range(TEXTOS, 0x4AC60):
        if rom[o] == 0x00:
            if o > ini:
                textos.append(ini)
            ini = o + 1
    assert len(textos) >= N, 'solo hay %d textos, esperaba %d' % (len(textos), N)
    textos = textos[:N]

    # --- comprobar que la tabla es la que creo ---------------------------
    p0 = rom[TABLA] | rom[TABLA + 1] << 8
    assert p0 == CPU_BASE + TEXTOS - ROM_BASE, \
        'la entrada 0 apunta a $%04X, esperaba $%04X' % (
            p0, CPU_BASE + TEXTOS - ROM_BASE)
    # las 38 entradas tienen que estar en rango
    for i in range(N):
        p = rom[TABLA + i * PASO] | rom[TABLA + i * PASO + 1] << 8
        assert 0x6700 <= p <= 0x6C60, 'entrada %d fuera de rango: $%04X' % (i, p)

    # --- repuntar ---------------------------------------------------------
    cambios = 0
    for i, off in enumerate(textos):
        cpu = CPU_BASE + off - ROM_BASE
        a = TABLA + i * PASO
        if (rom[a] | rom[a + 1] << 8) != cpu:
            cambios += 1
        rom[a] = cpu & 0xFF
        rom[a + 1] = cpu >> 8

    # --- VERIFICACION -----------------------------------------------------
    # cada puntero tiene que caer en el PRINCIPIO de un texto, y ese texto
    # debe empezar por letra o signo de apertura (no a media palabra)
    for i in range(N):
        p = rom[TABLA + i * PASO] | rom[TABLA + i * PASO + 1] << 8
        off = ROM_BASE + p - CPU_BASE
        assert off == textos[i], 'entrada %d mal repuntada' % i
        # el byte de delante tiene que ser el $00 terminador (o el inicio)
        assert off == TEXTOS or rom[off - 1] == 0x00, \
            'entrada %d no cae tras un $00' % i
        e = off
        while rom[e] != 0x00:
            e += 1
        txt = ''.join(' ' if x == 0xA0 else rv.get(x, '?')
                      for x in rom[off:e]).strip()
        assert txt, 'entrada %d apunta a texto vacio' % i
        # Las entradas 0..3 siguen EN JAPONES (no se han traducido nunca):
        # su texto no pasa el filtro de mayuscula inicial. Se comprueban
        # solo las traducidas.
        if i >= 4:
            assert not txt[0].islower(), \
                'entrada %d empieza en minuscula: «%s»' % (i, txt[:30])

    # el texto, intacto
    assert rom[TEXTOS:0x4AC60] == original[TEXTOS:0x4AC60], 'texto tocado'

    for a2, b2, nombre in INTACTAS:
        assert rom[a2:b2] == original[a2:b2], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados, %d punteros corregidos' % (dif, cambios))
    print()
    for i in range(N):
        p = rom[TABLA + i * PASO] | rom[TABLA + i * PASO + 1] << 8
        off = ROM_BASE + p - CPU_BASE
        e = off
        while rom[e] != 0x00:
            e += 1
        txt = ''.join(' ' if x == 0xA0 else rv.get(x, '?') for x in rom[off:e])
        print('   %2d $%04X %s' % (i, p, txt[:46]))


if __name__ == '__main__':
    main()
