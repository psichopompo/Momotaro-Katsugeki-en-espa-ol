#!/usr/bin/env python3
"""build_v336.py - El FINAL LARGO traducido (0x3B800, 104 bloques).

LA ZONA
-------
    0x3B7DE .. 0x3B800    34 B libres ($00) delante
    0x3B800 .. 0x3BF83  1923 B, 104 bloques, INTEGRAMENTE EN JAPONES
    0x3BF83 .. 0x3C001   126 B libres ($FF) detras
                        ------
                        2083 B utilizables

GEOMETRIA [HECHO, medido EN EL EMULADOR]
----------------------------------------
El motor lee **en SECUENCIA**, no por tabla. Verificado siguiendo el cursor
`$20BF` de la RAM mientras corre el final con el savestate de David:

    $5800 -> $5805 -> $580F -> $5818 -> $5824 -> $582C -> ...

`$00` cierra pagina, `;` ($3B) salta de linea. Al no haber tabla, **las
longitudes son libres** mientras se conserve el NUMERO y el ORDEN de los
`$00`. Esto es lo contrario del bug de la v335, donde si habia tabla.

Se escribe desde 0x3B7DE para aprovechar los 34 B de delante.

DECISIONES DE DAVID
-------------------
- Nombres propios japoneses TAL CUAL, sin -kun ni -san.
- `製作` -> «Desarrollo».
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402
from finales_texto import construye                                   # noqa: E402


def enc(txt):
    """Codifica para el motor de FINALES.

    - La 'p' va con el ALIAS $5E ($B0 pintaria una Ç aqui).
    - El marcador «~» se traduce a **$5C**, que CONMUTA EL COLOR
      (amarillo del cargo <-> blanco del nombre). El japones lleva 162 y
      la v336 los habia quitado todos: por eso los creditos salian con el
      nombre metido en la linea amarilla del cargo.
    """
    out = bytearray()
    for c in txt:
        if c == '~':
            out.append(0x5C)
        elif c == 'p':
            out.append(0x5E)
        else:
            out.append(cv.CHAR_TO_CODE[c])
    return bytes(out)

BASE = 'roms/momotaro_es_v335.pce'
SALIDA = 'roms/momotaro_es_v336.pce'
MD5_BASE = 'a594ed1b37b39401cd5aaaa515208910'

INICIO = 0x3B7DE        # 34 B libres antes del bloque original
FIN = 0x3C000           # 0x3C000 ya son datos de otra cosa
ORIG = 0x3B800          # donde empieza el bloque japones
ORIG_FIN = 0x3BF84      # incluye el $00 terminador del ultimo bloque

NL = 0x3B                # ';' salto de linea
FF = 0xFF

# el bloque 72 lleva un $FF en medio, entre «HUDSON SOFT» y el rotulo
B72_CON_FF = 72

INTACTAS = [
    (0x00000, 0x3B7DE, 'todo lo anterior'),
    (0x3C000, 0x80000, 'todo lo posterior'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v335'
    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    # ---- comprobar el terreno antes de escribir -------------------------
    assert all(rom[i] == 0x00 for i in range(INICIO, ORIG)), \
        'los 34 B de delante no estan libres'
    assert all(rom[i] == 0xFF for i in range(ORIG_FIN, FIN)), \
        'la cola de $FF no esta libre'
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    assert rom[ORIG:ORIG_FIN] == jp[ORIG:ORIG_FIN], \
        'el bloque ya no es el japones original'
    n_jp = sum(1 for i in range(ORIG, ORIG_FIN) if jp[i] == 0x00)

    bloques = construye()
    assert len(bloques) == 104, 'esperaba 104 bloques, hay %d' % len(bloques)

    # ---- montar ---------------------------------------------------------
    d = bytearray()
    for i, lineas in enumerate(bloques):
        if i == B72_CON_FF:
            # «  HUDSON SOFT» $FF «Colaboradores»
            d += enc(lineas[0]) + bytes([FF]) + enc(lineas[1])
        else:
            # El salto de linea de esta zona es $5C (el «~»), NO el $3B:
            # el japones no usa $3B ni una sola vez aqui y el motor lo
            # pinta como «,.» (lo vio David en pantalla).
            #
            # OJO: cada $5C alterna $3BA6, y con $3BA6=1 las letras
            # j/l/n/z salen como A/B/C/D. Por eso, si una linea que va a
            # quedar en estado 1 lleva alguna de esas letras, se mete un
            # $5C EXTRA para volver a 0. Dos $5C seguidos saltan una linea
            # y dejan el estado limpio.
            estado = 0
            for k, l in enumerate(lineas):
                if k:
                    d.append(0x5C)
                    estado ^= 1
                if estado == 1 and any(c in 'jlnz' for c in l):
                    d.append(0x5C)          # vuelve a la tabla buena
                    estado = 0
                d += enc(l)
                estado ^= l.count('~') & 1
        d.append(0x00)

    hueco = FIN - INICIO
    assert len(d) <= hueco, 'el final ocupa %d B y hay %d' % (len(d), hueco)
    rom[INICIO:FIN] = d + bytes([FF]) * (hueco - len(d))

    # ---- VERIFICACION ----------------------------------------------------
    # 1. mismo numero de $00 que el japones
    n_es = sum(1 for i in range(INICIO, INICIO + len(d)) if rom[i] == 0x00)
    assert n_es == len(bloques), 'hay %d $00, esperaba %d' % (n_es, len(bloques))
    assert n_es == n_jp, \
        'el japones tenia %d paginas y el nuestro %d' % (n_jp, n_es)

    # 2. relectura: trocear lo escrito y comparar con lo pedido
    leidos = []
    ini = INICIO
    for o in range(INICIO, INICIO + len(d)):
        if rom[o] == 0x00:
            leidos.append((ini, o))
            ini = o + 1
    assert len(leidos) == 104, 'releidos %d bloques' % len(leidos)
    for i, (a, b) in enumerate(leidos):
        crudo = rom[a:b]
        # el $FF del B72 se lee como separador
        txt = ''.join('|' if x == FF else
                      ('p' if x == 0x5E else
                       ('~' if x == 0x5C else rv.get(x, '?'))) for x in crudo)
        # el salto de linea ES el $5C, o sea que se lee como «~».
        # El «~~» de los saltos con correccion de $3BA6 se normaliza.
        esperado = ('~'.join(bloques[i]) if i != B72_CON_FF
                    else '|'.join(bloques[i]))
        txt = txt.replace('~~', '~')
        assert txt == esperado, \
            'bloque %d leido «%s» != «%s»' % (i, txt, esperado)

    # 3. cero japones: todos los bytes tienen que ser de nuestro charset
    validos = set(cv.CHAR_TO_CODE.values()) | {0x00, NL, FF, 0x5E, 0x5C}
    malos = [i for i in range(INICIO, INICIO + len(d)) if rom[i] not in validos]
    assert not malos, 'bytes ajenos en %s' % ['%06X' % x for x in malos[:8]]

    # 4. cero alias (este motor los pinta como ©)
    # $5E es la 'p' y $5C el conmutador de color: los dos son obligatorios.
    alias = [i for i in range(INICIO, INICIO + len(d))
             if rom[i] in (0x5B, 0x5D)]
    assert not alias, 'alias en %s' % ['%06X' % x for x in alias[:8]]
    # el $3B esta PROHIBIDO en los creditos: se pinta como «,.»
    assert NL not in rom[INICIO:INICIO + len(d)], \
        'hay un $3B: saldria «,.» en pantalla'
    assert 0xB0 not in rom[INICIO:INICIO + len(d)], \
        'queda un $B0: pintaria una Ç'

    for a2, b2, nombre in INTACTAS:
        assert rom[a2:b2] == original[a2:b2], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print('  final: %d B de %d  (sobran %d)' % (len(d), hueco, hueco - len(d)))
    print('  104 bloques, %d paginas $00 (igual que el japones)' % n_es)


if __name__ == '__main__':
    main()
