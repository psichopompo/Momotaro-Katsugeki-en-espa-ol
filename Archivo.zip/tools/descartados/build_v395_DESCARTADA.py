#!/usr/bin/env python3
r"""build_v395.py - A-CASA (B1): la casa mutilada del mapa de Kachiyama.

EL BUG
------
En el mapa de la Aldea Kachiyama, la casa gris de arriba sale con el tejado
cortado: pierde una franja de 6 px. Medido con `states/mapa_kachiyama.state`:

    scanlines y=120..127   16/16 ranuras   SATURADAS
    sprite 32 (celda $14C, 32x32, y=120)   pierde las filas 128..133

LA CAUSA (entrada 264)
----------------------
El límite del VDC es de 16 ranuras por scanline, y un sprite de 32 px de
ancho cuesta DOS (norma 144). En la banda y=120..127 se juntan:

    i15  y=118..133  $1AD  16x16  coste 1
    i16  y=118..133  $1A4  32x16  coste 2   \
    i17  y=118..133  $1A6  32x16  coste 2    |
    i18  y=118..133  $1A6  32x16  coste 2    |  borde inferior del
    i19  y=118..133  $1A6  32x16  coste 2    |  rótulo de la aldea
    i20  y=118..133  $1A4  32x16  coste 2   /
    i27  y=120..135  $146  16x16  coste 1
    i31  y=112..143  $14C  32x32  coste 2
    i32  y=120..151  $14C  32x32  coste 2   <- la casa, la última: se cae
                                            ----
                                            16

Comparado con la japonesa:

    JP:  24 sprites,  12 ranuras en y=120..127,  pico 13,  0 pérdidas
    ES:  35 sprites,  16 ranuras en y=120..127,  pico 16,  6 filas

La fila inferior del marco usa 3 sprites de 32 px en japonés (96 px, 6
ranuras) y 5 en el nuestro (160 px, 10 ranuras). **+4 ranuras: 12+4 = 16.**
El rótulo ancho es nuestro (v126-v128) y Kachiyama es el único mapa donde el
fondo ya iba al límite.

EL ARREGLO: UN BYTE
-------------------
Subir el rótulo entero 8 px en ESE mapa. Simulado sobre el SATB real:

    $CCD0[4]=152 (actual)  pico=16  rótulo y=[86,102,118]  i32 pierde 7 filas
    $CCD0[4]=148 (-4)      pico=16  rótulo y=[82, 98,114]  i32 pierde 3
    $CCD0[4]=146 (-6)      pico=16  rótulo y=[80, 96,112]  i32 pierde 1
    $CCD0[4]=144 (-8)      pico=16  rótulo y=[78, 94,110]  NINGUNA PÉRDIDA
    $CCD0[4]=136 (-16)     pico=15  rótulo y=[70, 86,102]  NINGUNA PÉRDIDA

Con 8 px basta y es el mínimo que deja el marco limpio. El rótulo pasa de
y=86..134 a y=78..126: no se sale por arriba (la pantalla empieza en y=0) y,
al moverse las tres filas juntas, el marco no se descuadra.

DÓNDE (lo que costó encontrar)
------------------------------
    $CCCF (ROM 0x1CCCF), banco $0E: 16 mapas x 4 bytes
        byte 0 = X del rótulo    byte 1 = Y del rótulo
    Se lee en $DF71 (`LDA $CCCF,X` con X = $3CF6*4) y va a $4E.

    mapa 4 = Kachiyama -> ROM 0x1CCDF: 50 98 13 12
                                          ^^ la Y que se toca

**Cada mapa tiene sus 4 bytes propios**: tocar el del mapa 4 no afecta a los
otros 15. Y la tabla es idéntica a la japonesa, así que el byte es original,
no algo que metiera la traducción.

Rutas descartadas por el camino (entrada 264): reordenar la SAT y subir sólo
la fila inferior del marco. Las dos fallan; la entrada 178 las daba por
buenas sobre una celda que suponía vacía y no lo estaba (norma 377).
"""
import hashlib
import sys
import zlib

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v394
DST = 'roms/momotaro_es_v395.pce'
JPR = 'roms/Momotarou Katsugeki (Japan).pce'

TABLA = 0x1CCCF          # $CCCF, banco $0E: 16 mapas x 4 bytes
MAPA = 4                 # Kachiyama
Y_OFF = TABLA + MAPA * 4 + 1
SUBIR = 8

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
jp = open(JPR, 'rb').read()

# ---- 0. el estado de partida es el que creo ------------------------------
assert bytes(rom[TABLA + MAPA * 4:TABLA + MAPA * 4 + 4]) == b'\x50\x98\x13\x12', (
    'el registro del mapa 4 no es «50 98 13 12»: %s'
    % rom[TABLA + MAPA * 4:TABLA + MAPA * 4 + 4].hex())
assert rom[Y_OFF] == 0x98, 'en 0x%05X no está la Y esperada ($98)' % Y_OFF
# la tabla es original: no la tocó la traducción
assert bytes(rom[TABLA:TABLA + 64]) == jp[TABLA:TABLA + 64], (
    'la tabla $CCCF ya está modificada respecto a la japonesa')

# ---- 1. subir el rótulo de Kachiyama 8 px --------------------------------
rom[Y_OFF] = rom[Y_OFF] - SUBIR
assert rom[Y_OFF] == 0x90, 'la Y no quedó en $90'

# ---- 2. nada más se ha tocado -------------------------------------------
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos == {Y_OFF}, 'se ha tocado algo más: %s' % sorted(distintos)
# los otros 15 mapas, intactos
for k in range(16):
    if k == MAPA:
        continue
    o = TABLA + k * 4
    assert bytes(rom[o:o + 4]) == orig[o:o + 4], 'tocado el mapa %d' % k

open(DST, 'wb').write(bytes(rom))
print('%s  %d B' % (DST, len(rom)))
print('  0x%05X  Y del rótulo del mapa %d: $98 (%d) -> $%02X (%d)'
      % (Y_OFF, MAPA, 0x98, rom[Y_OFF], rom[Y_OFF]))
print('  el rótulo sube %d px SÓLO en Kachiyama' % SUBIR)
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
