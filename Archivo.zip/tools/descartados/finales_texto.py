#!/usr/bin/env python3
"""finales_texto.py - El texto del FINAL LARGO (0x3B800), 104 bloques.

GEOMETRIA [HECHO, medido en el emulador]
----------------------------------------
El motor lee **en SECUENCIA**, sin tabla de punteros. Verificado siguiendo
el cursor `$20BF` en la RAM mientras corre el final:

    $5800 -> $5805 -> $580F -> $5818 -> $5824 -> ...

Avanza por trozos: `$00` cierra pagina y `;` ($3B) salta de linea. Como no
hay tabla, **las longitudes se pueden cambiar libremente** mientras se
respete el numero de `$00` y su orden.

Espacio: 0x3B800..0x3BF83 = 1923 B, y detras 124 B libres de $FF
(0x3BF84..0x3C000) => 2048 B utilizables.

CRITERIO
--------
- Nombres propios japoneses TAL CUAL, sin `-kun` ni `-san` (decision de
  David, norma 315).
- Los cargos se traducen.
- `製作` -> «Desarrollo» (decision de David).
- Charset de vitores, BYTES DIRECTOS: nada de alias $5B/$5D/$5E.

Cada entrada es una lista de lineas; el constructor las une con `;` y
cierra con `$00`.
"""

# EL $5C ES EL SALTO DE LINEA DE ESTA ZONA [HECHO]
# ------------------------------------------------
# En los creditos (0x3B800) el japones **NO usa NUNCA el $3B**: 0 veces en
# 1923 bytes. Lo comprobo David sin saberlo: «sale una especie de coma y
# punto ,. cada dos por tres». Ese «,.» es mi $3B, que aqui NO es salto de
# linea sino un caracter imprimible.
#
# El salto lo hace el **$5C**, que ademas conmuta el color:
#
#     $5C  cargo (12 col, rellenas)  $5C  nombre
#     -------- linea 1, amarilla --------  -- linea 2, blanca --
#
# Medido en B84/B93/B95: el tramo entre los dos $5C ocupa SIEMPRE
# 12 columnas. Ese relleno es lo que empuja el nombre abajo.
#
# Se marca con «~» y el constructor lo traduce a $5C. **Prohibido el $3B
# en esta zona.**
SW = '~'

# LAS CUATRO LETRAS QUE SE ROMPEN [HECHO — el origen comun que buscaba David]
# --------------------------------------------------------------------------
# $3BA6 elige la tabla de glifos y **se alterna con CADA $5C** ($AB91 hace
# EOR #$01). Con $3BA6=1 (tabla $9CB3) cuatro minusculas cambian:
#
#     j -> A       l -> B       n -> C       z -> D
#
# Eso es «IiDuka» (Iizuka), «IDawa» (Izawa) y la Ç de la 'p' que llevamos
# arrastrando desde hace versiones: **no es un charset roto, es $3BA6 que
# queda sucio**. El japones no lo notaba porque el katakana es igual en las
# dos tablas; nuestro alfabeto no.
#
# Regla: tras un numero IMPAR de $5C, no puede haber j/l/n/z.
# Como cada bloque de credito lleva «~cargo ~nombre», el nombre va con
# $3BA6=0 (dos $5C) y el CARGO con $3BA6=1 (un $5C): el cargo no puede
# llevar esas cuatro letras.
ROTAS = 'jlnz'


def sin_rotas(txt):
    """Comprueba que un texto es seguro con $3BA6=1."""
    return not any(c in ROTAS for c in txt)

# los 22 colaboradores del concurso de ideas, en el orden original
# ORDEN OCCIDENTAL (nombre y luego apellido), decision de David.
# Y con INICIAL cuando el nombre completo no quepa en las ~13 columnas
# utiles: «M. Kuya» en vez de «Masakazu Hakuya».
COLABORADORES = [
    'N. Noda', 'T. Tsukahara', 'T. Yoshida',
    'S. Miyazaki', 'K. Yoshida', 'S. Matoba',
    'Y. Igarashi', 'K. Sato', 'K. Kawai', 'T. Terada',
    'H. Kobori', 'S. Naganawa', 'M. Sato',
    'K. Noda', 'Y. Tagata', 'K. Hiwatari',
    'D. Tsunoda', 'K. Matsuo', 'Y. Kurusu',
    'Y. Morimoto', 'K. Tahara', 'K. Miyashita',
]

# BLOQUES 0..71 — la parte con texto
CABECERA = [
    ['¡Enhorabuena!', '¡Gracias!'],                      # B0
    ['Has terminado.'],                                  # B1
    ['Demuestras'],                                      # B2
    ['lo acaba', 'cualquiera.'],                          # B3
    ['Gracias.'],                                        # B4
    ['Repito:'],                                         # B5
    ['¡Muchas gracias!'],                                # B6
    ['Ahora,'],                                          # B7
    ['el equipo de'],                                    # B8
    ['Momotaro', 'Katsugeki.'],                          # B9
    ['¡Ahí van!'],                                       # B10
    ['El director, por', 'fin ascendido:'],               # B11
    ['¡Ahí va!'],                                        # B12
    ['S. Masuda'],                                       # B13
    ['La música que', 'llega al alma:'],                  # B14
    ['Gracias por', 'esos temas.'],                      # B15
    ['M. Yoshida'],                                      # B16
    ['Personajes, a ver', 'si halla esposa.'],            # B17
    ['¡3000 ryos!'],                                     # B18
    ['T. Doi'],                                          # B19
    ['Programador jefe:'],                               # B20
    ['H. Okuno'],                                        # B21
    ['Programación:'],                                   # B22
    ['Y. Kosaka'],                                       # B23
    ['Diseño:'],                                         # B24
    ['F. Takaoka'],                                      # B25
    ['A. Kakutani'],                                     # B26
    ['K. Fujimoto'],                                     # B27
    ['Sonido:'],                                         # B28
    ['T. Takimoto'],                                     # B29
    ['K. Hoshi'],                                        # B30
    ['Dirección:'],                                      # B31
    ['S. Fujiwara'],                                     # B32
    ['Los ganadores', 'del concurso:'],                   # B33
    ['¡Gracias!'],                                       # B34
]

CIERRE = [
    ['¡Gracias!'],                                       # B57
    ['Supervisión:'],                                    # B58
    ['¡Yo! A. Sakuma'],                                  # B59
    ['Sólo la cabeza.'],                                 # B60
    ['Y quien hace'],                                    # B61
    ['el juego bueno', 'es...'],                          # B62
    ['¡Momotaro!'],                                      # B63
    ['Sin él no habría'],                                # B64
    ['Momotaro', 'Katsugeki.'],                          # B65
    ['Cuidadlo mucho,'],                                 # B66
    ['por favor.'],                                      # B67
    ['¡Gracias!'],                                       # B68
    ['Hasta la próxima.'],                               # B69
    ['¡Nos vemos con', 'Momotaro!'],                     # B70
    ['      Desarrollo'],                                # B71
]

# B72 lleva un $FF en medio (separa «HUDSON SOFT» del rotulo siguiente)
B72 = ('  HUDSON SOFT', 'Colaboradores')

# BLOQUES 73..83 — los 22 colaboradores en DOS COLUMNAS, 11 lineas
# el original pone 21 espacios entre columna y columna contando desde el
# principio de la linea; se respeta la rejilla.
ANCHO = 17   # MEDIDO en el emulador con una regla ABCDEFGHIJKLMNOPQRS:
             # se ven 17 caracteres y se pierden la R y la S.


def dos_columnas(izq, der, ancho=21):
    """Empareja dos columnas SIN pasar de ANCHO."""
    hueco = max(1, ancho - len(izq))
    s = izq + ' ' * hueco + der
    if len(s) > ANCHO:                       # recortar la sangria
        s = izq + ' ' + der
    return s


# BLOQUES 84..103 — la lista final, cargo + nombre en dos columnas
LISTA_FINAL = [
    # Los CARGOS van con $3BA6=1 (un solo $5C delante), asi que NO pueden
    # llevar j/l/n/z. Se ponen en MAYUSCULAS: se ven perfectas en esa tabla
    # y ademas distinguen mejor el cargo del nombre.
    ('PROG. JEFE', 'H. Okuno'),                          # B84
    ('PROGRAMA', 'Y. Kosaka'),                           # B85
    ('DISEÑO', 'F. Takaoka'),                            # B86
    ('DISEÑO', 'A. Kakutani'),                           # B87
    ('DISEÑO', 'K. Fujimoto'),                           # B88
    ('SONIDO', 'T. Takimoto'),                           # B89
    ('SONIDO', 'K. Hoshi'),                              # B90
    ('DIRECCIÓN', 'S. Fujiwara'),                        # B91
    ('DESARROLLO', 'HUDSON SOFT'),                       # B92
    ('AYUDA', 'H. Iizuka'),                              # B93
    ('AYUDA', 'M. Hakuya'),                              # B94
    ('AYUDA', 'T. Hattori'),                             # B95
    ('AYUDA', 'H. Araki'),                               # B96
    ('AYUDA', 'S. Kuniyake'),                            # B97
    ('AYUDA', 'H. Izawa'),                               # B98
    ('AYUDA', 'T. Ooi'),                                 # B99
    ('DIRECTOR', 'S. Masuda'),                           # B100
    ('PERSONAJES', 'T. Doi'),                            # B101
    ('MÚSICA', 'M. Yoshida'),                            # B102
    ('SUPERVISA', 'A. Sakuma'),                          # B103
]


def construye():
    """Devuelve la lista de 104 bloques, cada uno lista de lineas."""
    b = []
    b += CABECERA                       # B0..B34   (35)
    for n in COLABORADORES:             # B35..B56  (22)
        b.append([n])
    b += CIERRE                         # B57..B71  (15)
    b.append(list(B72))                 # B72       (lleva $FF, ver builder)
    # B73..B83: el original los pone en dos columnas de 22 col y el motor
    # las envuelve. Con 17 utiles se parten en DOS LINEAS, que se lee mejor.
    for i in range(0, 22, 2):           # B73..B83  (11)
        izq, der = COLABORADORES[i], COLABORADORES[i + 1]
        b.append([SW + izq.ljust(12)[:12], der])
    # B84..B103. El japones NO usa ';' aqui: pone
    #     ~cargo  <relleno $A0 hasta 14>  ~nombre
    # y el motor salta de linea solo al llegar al ancho. El ';' que puse en
    # la v336 forzaba un salto que descolocaba el color.
    # Se devuelve UNA sola linea con el relleno dentro.
    for cargo, nom in LISTA_FINAL:      # B84..B103 (20)
        # 12 columnas EXACTAS antes del 2o ~, como el japones: es ese
        # relleno el que empuja el nombre a la linea de abajo.
        b.append([SW + cargo.ljust(12)[:12], nom])
    return b


if __name__ == '__main__':
    import sys
    sys.path.insert(0, 'tools')
    import charset_vitores as cv
    bl = construye()
    print('bloques: %d' % len(bl))
    total = 0
    for i, lineas in enumerate(bl):
        n = sum(len(cv.encode(l.replace(SW, ''))) + l.count(SW)
                for l in lineas) + len(lineas) - 1 + 1
        total += n
    print('bytes necesarios: %d' % total)
    print('disponibles:      %d  (0x3B800..0x3C000)' % (0x3C000 - 0x3B800))
    print('%s' % ('CABE' if total <= 0x3C000 - 0x3B800 else 'NO CABE'))
