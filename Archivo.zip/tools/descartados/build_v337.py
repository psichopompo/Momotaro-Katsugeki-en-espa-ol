#!/usr/bin/env python3
"""build_v337.py - El FINAL CORTO (0x4A446..0x4A7C5), 28 bloques.

LO QUE HABIA
------------
La zona estaba a medias y **con la cuenta de paginas rota**:

    japones: 28 terminadores ($00/$01/$03)
    nuestro: 43            <- 15 de mas

Los 15 sobrantes son `$00` de relleno que dejo una traduccion antigua en
`0x4A476..0x4A483`: al acortar el discurso del abuelo se rellenaron con
ceros en vez de con `$A0`, y cada cero **abre una pagina nueva**. Por eso
el motor iba desincronizado en este final igual que en el otro.

Es la norma 323 («al acortar un texto, rellenar la celda ENTERA») pero con
un agravante: aqui el relleno equivocado no es invisible, **rompe la
estructura**.

LOS 28 BLOQUES, con su terminador exacto
----------------------------------------
    $00  fin de pagina normal
    $01  fin con pausa
    $03  fin de linea de creditos
    $02  al PRINCIPIO de algunos bloques: efecto de entrada. Se conserva.

Se reescribe el tramo entero respetando numero, orden y tipo de los 28
terminadores, y el `$02` inicial donde lo lleva el original.

GEOMETRIA
---------
Mismo motor que el final largo: `;` ($3B) salta de linea y la ventana da
**17 columnas** (medido con regla en la v336). La 'p' va con el alias `$5E`.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402

BASE = 'roms/momotaro_es_v336.pce'
SALIDA = 'roms/momotaro_es_v337.pce'
MD5_BASE = '49e5ba2b3783d27978281425c7c5aa84'

INICIO = 0x4A446
FIN = 0x4A7C5           # aqui empieza «Ni atacan...», ya traducido
NL = 0x3B               # ';'
ANCHO = 17

# (lineas, terminador, prefijo_02)
BLOQUES = [
    (['Casi todos los', 'aldeanos han', 'huido ya.',
      'Momotaro, la', 'esperanza de la', 'gente está en ti.',
      'Derrota a Enma', 'y trae la paz.'], 0x00, False),          # 0
    (['¡Enhorabuena!', '¡Lo has logrado!'], 0x03, False),         # 1
    (['Esperamos que', 'hayas disfrutado', 'de esta aventura.'],
     0x01, False),                                                # 2
    (['Y ahora, te', 'presento a los', 'enemigos.'], 0x01, True),  # 3
    ([], 0x00, False),                                            # 4  vacio
    (['¡El equipo de', 'Momotaro!'], 0x01, True),                 # 5
    (['Diseño adjunto:', 'Iizuka Hiroyuki'], 0x03, True),         # 6
    (['Hakuya Masagasu'], 0x03, False),                           # 7
    (['Hattori Takahiko'], 0x03, False),                          # 8
    (['Araki Hitoshi'], 0x03, False),                             # 9
    (['Kuniyake Santa'], 0x03, False),                            # 10
    (['Izawa Hiroshi'], 0x03, False),                             # 11
    (['Ooi Tomoo'], 0x01, False),                                 # 12
    (['¡Y el gran equipo', 'de Hudson!'], 0x01, True),            # 13
    (['Programador jefe:', 'Okuno Hitoshi'], 0x03, False),        # 14
    (['Programación:', 'Kosaka Yasuhiro'], 0x03, False),          # 15
    (['Diseño:', 'Takaoka Fumie'], 0x03, False),                  # 16
    (['Kakutani Atsushi'], 0x03, False),                          # 17
    (['Bushimoto Kayo'], 0x03, False),                            # 18
    (['Sonido:', 'Takimoto Toshiaki'], 0x03, False),              # 19
    (['Hoshi Keita'], 0x03, False),                               # 20
    (['Dirección:', 'Bushiwara Jikeki'], 0x01, False),            # 21
    (['¡Gracias a todos!', 'No olvides nunca', 'el amor y valor',
      'de Momotaro.', '¡Hasta pronto!'], 0x01, True),  # 22
    (['   Desarrollo', 'HUDSON SOFT'], 0x00, True),               # 23
    (['Feliz con su', 'onigiri', '¡Ogro Cesto!'], 0x00, False),   # 24
    (['Paseaba y ya', '¡Ogro Andarín!'], 0x00, False),            # 25
    (['Pegajoso y', 'resultón', '¡Ogro Seta!'], 0x00, False),     # 26
    (['¿Para qué tanta', 'dentadura?', '¡Ogro Bocah!'], 0x00, False),  # 27
]

INTACTAS = [
    (0x00000, 0x4A446, 'todo lo anterior'),
    (0x4A7C5, 0x80000, 'todo lo posterior'),
]


def enc(txt):
    """BYTES DIRECTOS, la 'p' con $B0.

    OJO: es al reves que en el final LARGO (v336), donde la 'p' necesita el
    alias $5E. Medido en el emulador: aqui el $5E pinta una «@» y el $B0
    sale bien; alli era justo lo contrario. **Son motores distintos aunque
    el texto se parezca.**
    """
    return cv.encode(txt)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v336'
    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    # ---- el japones manda la estructura ---------------------------------
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    terms_jp = [jp[o] for o in range(INICIO, FIN) if jp[o] in (0x00, 0x01, 0x03)]
    assert len(terms_jp) == 28, 'el japones tiene %d bloques' % len(terms_jp)
    assert len(BLOQUES) == 28, 'tengo %d bloques' % len(BLOQUES)
    for i, (_l, t, _p) in enumerate(BLOQUES):
        assert t == terms_jp[i], \
            'bloque %d: terminador $%02X, el japones usa $%02X' % (
                i, t, terms_jp[i])

    # ---- montar ----------------------------------------------------------
    d = bytearray()
    for lineas, term, pref02 in BLOQUES:
        if pref02:
            d.append(0x02)
        for k, l in enumerate(lineas):
            assert len(l) <= ANCHO, '«%s» son %d columnas' % (l, len(l))
            if k:
                d.append(NL)
            d += enc(l)
        d.append(term)

    hueco = FIN - INICIO
    assert len(d) <= hueco, 'ocupa %d B y hay %d' % (len(d), hueco)
    rom[INICIO:FIN] = d + bytes([0xA0]) * (hueco - len(d))

    # ---- VERIFICACION ----------------------------------------------------
    # 1. el relleno NO puede llevar $00: abriria paginas fantasma
    cola = rom[INICIO + len(d):FIN]
    assert 0x00 not in cola, 'el relleno lleva $00 (paginas fantasma)'

    # 2. mismo numero y tipo de terminadores que el japones
    terms = [rom[o] for o in range(INICIO, FIN) if rom[o] in (0x00, 0x01, 0x03)]
    assert terms == terms_jp, \
        'terminadores: %d nuestros vs %d japoneses' % (len(terms), len(terms_jp))

    # 3. relectura bloque a bloque
    leidos = []
    ini = INICIO
    for o in range(INICIO, INICIO + len(d)):
        if rom[o] in (0x00, 0x01, 0x03):
            leidos.append((ini, o))
            ini = o + 1
    assert len(leidos) == 28, 'releidos %d' % len(leidos)
    for i, (a, b) in enumerate(leidos):
        crudo = rom[a:b]
        if BLOQUES[i][2]:
            assert crudo[:1] == b'\x02', 'bloque %d sin el $02 inicial' % i
            crudo = crudo[1:]
        txt = ''.join('\n' if x == NL else rv.get(x, '?') for x in crudo)
        assert txt == '\n'.join(BLOQUES[i][0]), \
            'bloque %d leido «%s»' % (i, txt)

    # 4. cero japones y cero alias prohibidos
    validos = set(cv.CHAR_TO_CODE.values()) | {0x00, 0x01, 0x02, 0x03, NL, 0xA0}
    malos = [i for i in range(INICIO, FIN) if rom[i] not in validos]
    assert not malos, 'bytes ajenos en %s' % ['%06X' % x for x in malos[:8]]
    # aqui los alias estan PROHIBIDOS, incluido el $5E (pinta «@»)
    for b in (0x5B, 0x5D, 0x5C, 0x5E):
        assert b not in rom[INICIO:FIN], 'alias $%02X prohibido aqui' % b

    for a2, b2, nombre in INTACTAS:
        assert rom[a2:b2] == original[a2:b2], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print('  final corto: %d B de %d (sobran %d)' % (len(d), hueco, hueco - len(d)))
    print('  28 bloques, terminadores identicos al japones')
    print('  quitados los 15 $00 de relleno que rompian las paginas')


if __name__ == '__main__':
    main()
