"""sat.py - leer la SAT (tabla de sprites) y la VRAM de una instancia PCE.

El core de libretro NO expone la VRAM por retro_get_memory_data (devuelve 0
bytes). Hay que sacarla del savestate serializado, seccion 'VRAM' (64 KB).

FORMATO DEL SAT (norma 346): el word 2 es el patron POR DOS.
    celda = (word2 >> 1) & 0x3FF
Leerlo como patron directo lleva a inventar un "envolvimiento de VRAM" que
NO existe.

USO
---
    from pce import PCE
    from sat import vram, sat, celda
    v = vram(p)
    for d in sat(v):
        print(hex(d['cel']), d['x'], d['y'])
"""
import struct
import state as _st

SATB_WORD = 0x7F00
BYTES_POR_CELDA = 128


def vram(p):
    """64 KB de VRAM de la instancia PCE, via savestate."""
    return _st.buscar(p.state(), 'VRAM', 65536)


def celda(v, c):
    """Los 128 B de una celda de sprite (16x16, 4bpp)."""
    return v[c * BYTES_POR_CELDA:(c + 1) * BYTES_POR_CELDA]


def sat(v):
    """Lista de sprites activos. y/x ya descontado el borde."""
    w = struct.unpack('<%dH' % (len(v) // 2), v)
    out = []
    for i in range(64):
        y, x, pat, at = w[SATB_WORD + i * 4:SATB_WORD + i * 4 + 4]
        if y == 0 and x == 0 and pat == 0:
            continue
        out.append(dict(i=i, y=y - 64, x=x - 32,
                        cel=(pat >> 1) & 0x3FF, at=at,
                        w32=bool(at & 0x100),
                        alt={0: 16, 1: 32, 2: 32, 3: 64}[(at >> 12) & 3],
                        pal=at & 0xF))
    return out


def visibles(v, ymax=240):
    return [d for d in sat(v) if 0 <= d['y'] <= ymax]
