#!/usr/bin/env python3
"""build_v390.py - Arregla el submenú de las raquetas SIN romper su nombre.

QUÉ PASÓ CON LA v389
--------------------
La v389 cambió 0x430F0 de $00 a $AC para reparar el puntero del campo $0A de
la ficha del objeto $09 (raquetas), que apuntaba a código en vez de a la
tabla de textos. El submenú quedó bien... y el NOMBRE se rompió: pasó a
verse «Raquetas mqL q·L≡».

LA RAZÓN (entrada 248)
----------------------
Ese byte hace DOS trabajos a la vez:

    - es el terminador $00 del nombre «Raquetas»
    - es el byte bajo del puntero $B1AC del campo $0A

En la japonesa no hay conflicto porque el nombre es «かんじき» (4 kana) y
deja tres bytes de margen ($00 $00 $00) antes del puntero. Comparar con el
objeto $08, que sí tiene ese margen:

    obj $08:  02 BD 01 | AC A1 A3 A9 A1 B2 | 00 00 00 | 03 C0 ...
    obj $09:  02 C9 01 | A1 B1 B5 A5 B4 A1 B3 | AC B1 | 03 02 ...
              prefijo  | "aquetas" (7 letras)  ^^ sin terminador

«Raquetas» ocupa una letra de más y se come el $00.

EL ARREGLO
----------
Acortar el nombre a «Raqueta» (singular) para devolver el terminador, y
entonces sí reparar el puntero:

    0x430E9-0x430EF   "aquetas" -> "aqueta" + $00
    0x430F0           $00 -> $AC

La 'R' inicial va en el prefijo ($C9), así que en pantalla se lee «Raqueta».
"""
import hashlib
import zlib

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v389
JP = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v390.pce'

NOMBRE = 0x430E9          # las 7 letras tras el prefijo
PUNTERO = 0x430F0         # byte bajo del campo $0A

rom = bytearray(open(SRC, 'rb').read())
jp = open(JP, 'rb').read()
orig = bytes(rom)

# partimos de la v389: el puntero ya está en $AC y el nombre sin terminador
assert rom[PUNTERO] == 0xAC, 'esperaba la v389 (puntero ya reparado)'
assert bytes(rom[NOMBRE:NOMBRE + 7]) == bytes([0xA1, 0xB1, 0xB5, 0xA5, 0xB4, 0xA1, 0xB3]), \
    'en 0x430E9 no está "aquetas"'

# "aqueta" + terminador
rom[NOMBRE:NOMBRE + 7] = bytes([0xA1, 0xB1, 0xB5, 0xA5, 0xB4, 0xA1, 0x00])

# el puntero tiene que seguir apuntando a la tabla de textos, no a código
assert rom[PUNTERO] == 0xAC and rom[PUNTERO + 1] == 0xB1
dest = 0x42000 + (0xB1AC & 0x1FFF)
assert rom[dest:dest + 2] == bytes([0xD4, 0xB1]), 'el destino no es la tabla de textos'

# el nombre ahora termina en $00 y mide 6 letras
assert rom[NOMBRE + 6] == 0x00, 'no quedó el terminador'

# nada más se ha movido
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos == {NOMBRE + 6}, sorted(distintos)[:10]

open(DST, 'wb').write(bytes(rom))
print('%s  %d B' % (DST, len(rom)))
print('  0x%05X  "aquetas" -> "aqueta" + $00   (en pantalla: «Raqueta»)' % NOMBRE)
print('  0x%05X  $AC  (puntero $B1AC, ya venía de la v389)' % PUNTERO)
print('  bytes cambiados respecto a la v389: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
