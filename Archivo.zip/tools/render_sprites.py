#!/usr/bin/env python3
"""
Renderiza los sprites de un savestate del PC Engine a partir de VRAM + paletas.

VRAM se lee como words little-endian. El SATB esta en VRAM $7F00 (word) =
byte 0x7F00*2 = 0xFE00, 64 ranuras de 4 words:
    w0 = Y (+64 = borde superior de pantalla)
    w1 = X (+32)
    w2 = patron: base = (w2 & 0x7FE) * 32   (unidades de 16 B... ver abajo)
    w3 = atributos: bit11 = ancho 32, bits 13-12 = alto (16/32/64),
         bit15 = flip V, bit11.. bit7 = flip H, bits 3-0 = paleta de sprite

Un sprite de 16x16 son 4 planos de 32 B = 128 B; en words, 64 words.
base_word = (patron & 0x7FF) * 64  ... en realidad el patron cuenta de 64 en
64 words (0x40 words = 128 B), y el bit0 del patron se ignora para 32 px de
ancho.
"""
import sys, struct
from PIL import Image

SATB_WORD = 0x7F00


def leer_words(vram):
    return struct.unpack('<%dH' % (len(vram) // 2), vram)


def paletas(pal):
    """color_table: 512 words de 9 bits GGGRRRBBB. Devuelve lista de 32x16 RGB."""
    cols = struct.unpack('<512H', pal[:1024])
    out = []
    for c in cols:
        g = (c >> 6) & 7
        r = (c >> 3) & 7
        b = c & 7
        out.append((r * 36, g * 36, b * 36))
    return out


def tile16(w, base_word, plano_off=0):
    """Devuelve matriz 16x16 de indices 0-15 de un sprite cell de 16x16."""
    px = [[0] * 16 for _ in range(16)]
    for y in range(16):
        p0 = w[base_word + y]
        p1 = w[base_word + 16 + y]
        p2 = w[base_word + 32 + y]
        p3 = w[base_word + 48 + y]
        for x in range(16):
            b = 15 - x
            v = ((p0 >> b) & 1) | (((p1 >> b) & 1) << 1) | \
                (((p2 >> b) & 1) << 2) | (((p3 >> b) & 1) << 3)
            px[y][x] = v
    return px


def sat(vram):
    w = leer_words(vram)
    out = []
    for i in range(64):
        y, x, pat, at = w[SATB_WORD + i * 4: SATB_WORD + i * 4 + 4]
        out.append((i, y, x, pat, at))
    return out


def dibujar(vram, pal, ancho=256, alto=240, solo=None, fondo=(255, 0, 255)):
    w = leer_words(vram)
    cols = paletas(pal)
    img = Image.new('RGB', (ancho, alto), fondo)
    px = img.load()
    # indice bajo se dibuja ENCIMA -> pintar de mayor a menor
    for i, y, x, pat, at in reversed(sat(vram)):
        if solo is not None and i not in solo:
            continue
        sy = y - 64
        sx = x - 32
        cgx = 1 if (at & 0x100) else 0          # ancho 32
        alt = (at >> 12) & 3                     # 0=16,1=32,3=64
        nfil = {0: 1, 1: 2, 2: 2, 3: 4}[alt]
        flipH = bool(at & 0x0800)
        flipV = bool(at & 0x8000)
        palnum = 16 + (at & 0xF)
        ncol = 2 if cgx else 1
        cell = (pat >> 1) & 0x3FF          # celda de 16x16 = 64 words
        if ncol == 2:
            cell &= ~1
        if nfil >= 2:
            cell &= ~(2 if nfil == 2 else 6)
        for fy in range(nfil):
            for fx in range(ncol):
                cy = (nfil - 1 - fy) if flipV else fy
                cx = (ncol - 1 - fx) if flipH else fx
                bw = (cell + cy * 2 + cx) * 64
                if bw + 64 > len(w):
                    continue
                t = tile16(w, bw)
                for yy in range(16):
                    ty = 15 - yy if flipV else yy
                    for xx in range(16):
                        tx = 15 - xx if flipH else xx
                        v = t[ty][tx]
                        if v == 0:
                            continue
                        px_x = sx + fx * 16 + xx
                        px_y = sy + fy * 16 + yy
                        if 0 <= px_x < ancho and 0 <= px_y < alto:
                            px[px_x, px_y] = cols[palnum * 16 + v]
    return img


if __name__ == '__main__':
    vram = open(sys.argv[1], 'rb').read()
    pal = open(sys.argv[2], 'rb').read()
    if len(sys.argv) > 3 and sys.argv[3] == 'sat':
        for i, y, x, pat, at in sat(vram):
            if y == 0 and x == 0 and pat == 0:
                continue
            print('%2d  y=%4d(%4d) x=%4d(%4d) pat=%04X at=%04X' %
                  (i, y, y - 64, x, x - 32, pat, at))
    else:
        dibujar(vram, pal).save(sys.argv[3])
        print('ok')
