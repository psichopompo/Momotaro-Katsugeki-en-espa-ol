#!/usr/bin/env python3
"""
build_v270.py - dougu, jutsu, tsukaemasen, y el «Nada» de las aldeas.

LOS CUATRO ARREGLOS
===================

**1. El bug del «Nada» dentro de las aldeas (el que veia David).**

David: *«estando fuera de la aldea, si selecciono la segunda opcion pone
"Nada", pero dentro de la aldea salen los tipicos signos raros.»*

Medido en 0x42ED9 y 0x42F45:

```
virgen:  01 | b1 d8 cf be dd | 00      $01 + ｱﾘﾏｾﾝ (5) + $00 = 7 B
v269:    01 | 01 4e a1 a4 a1 | 00      $01 + $01 + «Nada» (4) + $00 = 7 B
              ^^ EL $01 ESTA DUPLICADO
```

Quien tradujo esas dos cadenas escribio `01 Nada 00` **dentro** de una
cadena que ya empezaba por `$01`. El motor lee `[01][01]` = dos saltos de
linea seguidos, y luego «Nada». Por eso en el bocadillo de la aldea (que
tiene 4 filas y usa `$3657`) la linea sale descuadrada, y fuera de la aldea
no se nota.

Arreglo: quitar el `$01` sobrante y recolocar. Quedan `01 4e a1 a4 a1 00`
(6 B) en un hueco de 7, con el ultimo byte a `$00`.

**2, 3 y 4. dougu, jutsu y tsukaemasen.**

```
ROM 0x436F9 ($B6F9) 11 B  ﾄﾞｳｸﾞ ﾎｼｲ    dougu hoshii   -> «Objetos»
ROM 0x4360C ($B60C) 11 B  ｼﾞｭﾂ ﾎｼｲ     jutsu hoshii   -> «Poderes»
ROM 0x4372E ($B72E)  8 B  ﾂｶｴﾏｾﾝ       tsukaemasen    -> «No vale»
```

Los tres tienen tabla de punteros, verificada:

```
0x436EB  tabla dougu  -> [0] $B6F9
0x435FE  tabla jutsu  -> [0] $B60C
0x43712  tabla tienda -> [0] y [3] $B72E   (entrada repetida: es puntero)
```

**OJO (norma 226):** en esas tablas **solo la entrada [0] es un puntero
real**; las words siguientes son codigo o datos. Se toca [0] y nada mas.

«Objetos» (9 B) y «Poderes» (9 B) caben en los huecos de 11 B sin moverse.
«Inútil» ocupa 8 B y entra justo en el hueco de 8 de tsukaemasen, sin
moverla. «No vale» (9 B) NO cabia: ningun hueco recuperado del banco llega
a 9 B (el mayor es de 5) y una cadena no se puede partir. Medido, no
supuesto.

Uso:  python3 tools/build_v270.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import encode, CHAR_TO_CODE          # noqa: E402

BASE = 'roms/momotaro_es_v269.pce'
SALIDA = 'roms/momotaro_es_v270.pce'
IPS = 'parches/momotaro_v270.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '0687a09590aaca90804e976ad23f57a7'

BANCO_INI, BANCO_FIN, CPU_INI = 0x42000, 0x44000, 0xA000

# --- 1. el «Nada» con el $01 duplicado -------------------------------
NADA = [0x42ED9, 0x42F45]        # inicio de la cadena (el $01 bueno)
NADA_MAL = bytes([0x01, 0x01, 0x4E, 0xA1, 0xA4, 0xA1, 0x00])
NADA_VIRGEN = bytes([0x01, 0xB1, 0xD8, 0xCF, 0xBE, 0xDD, 0x00])
TXT_NADA = 'Nada'

# --- 2/3/4. las tres cadenas con tabla -------------------------------
#   (tabla, offset_cadena, hueco, texto nuevo)
CADENAS = [
    (0x436EB, 0x436F9, 11, 'Objetos'),      # dougu
    (0x435FE, 0x4360C, 11, 'Poderes'),      # jutsu
    (0x43712, 0x4372E, 8, 'Inútil'),        # tsukaemasen
]

# huecos recuperados libres (verificados sin referencias [cmd][word])
HUECOS = [
    (0x42F7D, 0x42F81),      # 4 B
    (0x42FAA, 0x42FAF),      # 5 B
    (0x4300E, 0x43011),      # 3 B
    (0x43094, 0x43098),      # 4 B
    (0x430C2, 0x430C5),      # 3 B
    (0x4311A, 0x4311F),      # 5 B
    (0x43173, 0x43178),      # 5 B
    (0x43432, 0x43436),      # 4 B
]


def cpu(off):
    return CPU_INI + (off - BANCO_INI)


def cadena(txt):
    return bytes([0x01]) + encode(txt) + bytes([0x00])


def refs_cmd(rom, lo, hi):
    """Referencias [cmd][word] que caen en [lo, hi)."""
    out = []
    for x in range(BANCO_INI, BANCO_FIN - 2):
        if rom[x] in (0x01, 0x02, 0x03, 0x04):
            w = rom[x + 1] | (rom[x + 2] << 8)
            if lo <= w < hi:
                out.append(x)
    return out


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v269'
    print('base %s  OK' % BASE)

    inv = {v: k for k, v in CHAR_TO_CODE.items()}

    # ==================================================================
    # 1. el «Nada» con el $01 duplicado
    # ==================================================================
    print('\n--- 1. el bug del «Nada» en las aldeas')
    nueva = cadena(TXT_NADA)                      # 01 4e a1 a4 a1 00 = 6 B
    for o in NADA:
        assert bytes(rom[o:o + 7]) == NADA_MAL, \
            'en 0x%05X no esta el «Nada» con el $01 duplicado: %s' \
            % (o, bytes(rom[o:o + 7]).hex(' '))
        assert bytes(orig[o:o + 7]) == NADA_VIRGEN, \
            'en 0x%05X la virgen no tiene ｱﾘﾏｾﾝ' % o
        print('    0x%05X  %s  ->  %s'
              % (o, bytes(rom[o:o + 7]).hex(' '),
                 (nueva + bytes([0x00])).hex(' ')))
        rom[o:o + 7] = nueva + bytes([0x00])      # 6 B + relleno
        # se relee para comprobar que el motor vera lo correcto
        assert rom[o] == 0x01 and rom[o + 1] != 0x01, \
            'sigue habiendo dos $01 seguidos'
        f = o + 1
        while rom[f] != 0x00:
            f += 1
        leido = ''.join(inv.get(x, '[%02X]' % x) for x in rom[o + 1:f])
        assert leido == TXT_NADA, 'leido %r' % leido
        print('        releido: %r  OK' % leido)

    # ==================================================================
    # 2/3/4. dougu, jutsu, tsukaemasen
    # ==================================================================
    print('\n--- las tres cadenas del menu, con su tabla')
    libres = [[a, b] for a, b in HUECOS]
    for tabla, off_cad, hueco, txt in CADENAS:
        cod = cadena(txt)
        w_actual = rom[tabla] | (rom[tabla + 1] << 8)
        assert w_actual == cpu(off_cad), \
            'la tabla 0x%05X[0] no apunta a la cadena (apunta a $%04X)' \
            % (tabla, w_actual)
        # el hueco fisico declarado tiene que coincidir con la ROM
        f = off_cad + 1
        while rom[f] not in (0x00, 0xFF):
            f += 1
        assert f + 1 - off_cad == hueco, \
            'el hueco de 0x%05X mide %d, no %d' % (off_cad,
                                                   f + 1 - off_cad, hueco)

        if len(cod) <= hueco:
            destino = off_cad
            rom[off_cad:off_cad + hueco] = cod + bytes(hueco - len(cod))
            print('    %-8s cabe en su sitio: ROM %05X, %d B en hueco de %d'
                  % (txt, off_cad, len(cod), hueco))
        else:
            # se reubica: hueco libre mas ajustado que la admita
            cand = [z for z in libres if z[1] - z[0] >= len(cod)]
            assert cand, \
                '«%s» (%d B) no cabe: hueco propio %d, libres %s' \
                % (txt, len(cod), hueco,
                   [z[1] - z[0] for z in libres])
            z = min(cand, key=lambda z: z[1] - z[0])
            destino = z[0]
            rom[destino:destino + len(cod)] = cod
            z[0] += len(cod)
            rom[tabla] = cpu(destino) & 0xFF
            rom[tabla + 1] = cpu(destino) >> 8
            # la cadena vieja se borra, para no dejar japones suelto
            rom[off_cad:off_cad + hueco] = bytes(hueco)
            print('    %-8s REUBICADA a ROM %05X ($%04X), %d B; tabla '
                  '0x%05X actualizada'
                  % (txt, destino, cpu(destino), len(cod), tabla))

        # relectura desde la tabla, como hace el juego
        w = rom[tabla] | (rom[tabla + 1] << 8)
        o = BANCO_INI + (w - CPU_INI)
        assert rom[o] == 0x01, 'la cadena no empieza por $01'
        f = o + 1
        while rom[f] != 0x00:
            f += 1
        leido = ''.join(inv.get(x, '[%02X]' % x) for x in rom[o + 1:f])
        assert leido == txt, 'leido %r, esperado %r' % (leido, txt)
        print('        tabla 0x%05X -> $%04X -> %r  OK' % (tabla, w, leido))

    # ==================================================================
    # verificacion global
    # ==================================================================
    intactas = [
        ('tabla $B1AC menu RUN', 0x431AC, 0x431B4),
        ('tabla $B1CC aliados', 0x431CC, 0x431D4),
        ('verbos del menu RUN', 0x431B4, 0x431CC),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla de glifos', 0x43F9B, 0x44000),
        ('bucle del canto', 0x16A73, 0x16AD6),
        ('password $DE69', 0x17E69, 0x17E78),
        ('nombres del inventario', 0x42F4C, 0x42F7D),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    # no puede quedar ningun [01][01] en las zonas que hemos tocado
    for o in NADA:
        assert not (rom[o] == 0x01 and rom[o + 1] == 0x01), \
            'sigue el $01 duplicado en 0x%05X' % o

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v269' % len(dif))

    open(SALIDA, 'wb').write(d)

    # --- IPS con round-trip ---
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
