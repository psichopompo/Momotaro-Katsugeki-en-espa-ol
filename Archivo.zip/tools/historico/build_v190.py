#!/usr/bin/env python3
"""
build_v190.py - el bocadillo deja de salirse: centrado, recorte y rabillo
                simetrico.

LO QUE PIDE DAVID
-----------------
> «el bocadillo se sale de la pantalla en cualquier parte en la que haya un
>  personaje de los que caminan. [...] Alineandolo con el eje Y seguramente
>  se solucione. [...] habria que poner ya el rabillo simetrico de los otros
>  bocadillos.»

LA FORMULA, MEDIDA
------------------
Con los states de David (RAM + VRAM + registros del VDC):

```
x_pantalla = $368B - BXR + dX
```

Verificada exacta en «Fase 4 dialogo nina»: `$368B=192`, `BXR=56`, el sprite
`19C` con `dX=-58` cae en `x=78`. Predicho 78, real 78.

Lo que me faltaba era el **scroll**: `$368B` es coordenada de MUNDO. Los
states del abuelo dan `$368B=2247` sin restar `BXR` porque esa ruta
(`$88AD`) es otra y el bocadillo va fijo arriba: **no le afecta este
parche**, tal como suponia David.

DE DONDE SALE EL ANCLA (ruta de aldeanos, banco $0B)
-----------------------------------------------------
```
$87F9  AND #$01 / STA $368F     variante del rabillo (0 o 1)
$87FE  ASL A / TAY
$8800  LDA $2A20,X              X del aldeano (byte bajo)
$8804  ADC $C825,Y              <- TABLA de desplazamiento
$8807  STA $368B                ancla
```

Tabla en `ROM 0x16825`: `D8 FF  F8 FF` = **-40** (rabillo derecha) y **-8**
(rabillo izquierda). Ahi esta la asimetria: el centro del bocadillo cae en
`X_aldeano-40` o `X_aldeano-8` segun el lado.

LOS TRES ARREGLOS
-----------------

**1. Centrar.** El aldeano mide 16 px, su centro esta en `X+8`. El centro
del bocadillo es `X_aldeano + tabla`. Para centrarlo: **tabla = +8** en las
dos entradas.

**2. Recortar.** Centrar no basta: con 160 px de ancho,

```
x_izq = X_ald - 72   ->  necesita X_ald >= 72
x_der = X_ald + 88   ->  necesita X_ald <= 168
```

y un personaje que camina cruza toda la pantalla. Se anade un recorte del
ancla tras `$8807`: el bocadillo se queda pegado al borde y **el rabillo no
se mueve**, que es como funciona en el original.

Limites, en coordenadas de MUNDO (el ancla lo es):

```
ancla_min = BXR + 72 + 4      (4 px de margen)
ancla_max = BXR + 256 - 88 - 4
```

`BXR` esta en el registro 7 del VDC y no se puede leer... pero **si esta en
RAM**: el juego guarda el scroll en `$35/$36` (lo usa `$E3EB` para restarlo).
Se recorta contra eso.

**3. El rabillo simetrico.** Ya existe en el juego: `ROM 0x5292`, 46 B
comprimidos, es el de la intro y la escena de los padres (entrada 155 del
diario). Se sustituye la celda `1AD` del CG del bocadillo por el.

Ojo con los colores: el simetrico usa **4** (relleno) y **7**; el bocadillo
usa **6** (contorno) y **7** (blanco). Hay que remapear `4 -> 7` y `7 -> 6`.

Uso:  python3 tools/build_v190.py
"""
import hashlib
import zlib
import struct
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v189.pce'
SALIDA = 'roms/momotaro_es_v190.pce'
IPS = 'parches/momotaro_v190.ips'
MD5_BASE = 'd678f480f17b800402e2766d336b851b'

TABLA = 0x16825          # $C825, desplazamiento del ancla
CG = 0x3D401             # stream del CG del bocadillo (20 celdas)
SIMETRICO = 0x5292       # rabillo simetrico comprimido
CELDA_RAB = 0x1AD

DESP = 8                 # centro del aldeano


def pinta(c, filas=9):
    w = struct.unpack('<64H', c)
    out = []
    for y in range(filas):
        s = ''
        for x in range(16):
            b = 15 - x
            col = ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
                | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)
            s += '.' if col == 0 else '%X' % col
        out.append(s)
    return out


def remapea(c, mapa):
    """Cambia los indices de color de una celda de 16x16."""
    w = list(struct.unpack('<64H', c))
    nuevo = [0] * 64
    for y in range(16):
        for x in range(16):
            b = 15 - x
            col = ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
                | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)
            col = mapa.get(col, col)
            for p in range(4):
                if (col >> p) & 1:
                    nuevo[p * 16 + y] |= 1 << b
    return struct.pack('<64H', *nuevo)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v189 (md5 %s)' % md5
    orig = bytes(rom)

    # ==================================================================
    # 1. CENTRAR: la tabla $C825
    # ==================================================================
    assert bytes(rom[TABLA:TABLA + 4]) == bytes([0xD8, 0xFF, 0xF8, 0xFF]), \
        'la tabla $C825 no es la esperada: %s' % bytes(rom[TABLA:TABLA + 4]).hex()
    for k, nom in ((0, 'rabillo derecha'), (1, 'rabillo izquierda')):
        v = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        sv = v - 65536 if v > 32767 else v
        rom[TABLA + k * 2] = DESP
        rom[TABLA + k * 2 + 1] = 0x00
        print('tabla $C825[%d] (%s): %+d -> %+d' % (k, nom, sv, DESP))
    print('  el centro del bocadillo pasa a caer sobre el centro del aldeano')

    # ==================================================================
    # 2. EL RABILLO SIMETRICO
    # ==================================================================
    f = Flujo(rom, CG)
    celdas = [b''.join(tile(f) for _ in range(4)) for _ in range(20)]
    fin_cg = f.p
    assert fin_cg == 0x3D660, 'el stream del CG no acaba donde esperaba'

    g = Flujo(rom, SIMETRICO)
    sim = b''.join(tile(g) for _ in range(4))
    assert g.p - SIMETRICO == 46, 'el simetrico no mide 46 B comprimidos'

    cols_sim = {((struct.unpack('<64H', sim)[y] >> b) & 1)
                | (((struct.unpack('<64H', sim)[16 + y] >> b) & 1) << 1)
                | (((struct.unpack('<64H', sim)[32 + y] >> b) & 1) << 2)
                | (((struct.unpack('<64H', sim)[48 + y] >> b) & 1) << 3)
                for y in range(16) for b in range(16)}
    assert cols_sim == {0, 4, 7}, 'el simetrico usa los colores %s' % cols_sim

    idx = CELDA_RAB - 0x19C
    cols_viejo = set()
    w = struct.unpack('<64H', celdas[idx])
    for y in range(16):
        for b in range(16):
            cols_viejo.add(((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1)
                           | (((w[32 + y] >> b) & 1) << 2)
                           | (((w[48 + y] >> b) & 1) << 3))
    assert cols_viejo == {0, 6, 7}, 'el rabillo actual usa %s' % cols_viejo

    # 4 (relleno de la intro) -> 7 (blanco del bocadillo)
    # 7 (contorno de la intro) -> 6 (contorno del bocadillo)
    nuevo_rab = remapea(sim, {4: 7, 7: 6})
    print()
    print('rabillo simetrico (ROM 0x5292), remapeado 4->7 y 7->6:')
    for l in pinta(nuevo_rab):
        print('   ' + l)
    print('  (antes era la cuna asimetrica)')
    celdas[idx] = nuevo_rab

    # recomprimir el stream entero y comprobar que sigue cabiendo
    stream = b''.join(comprime(c) for c in celdas)
    hueco = 0x3D660 - CG
    assert len(stream) <= hueco, \
        'el CG nuevo mide %d B y solo hay %d' % (len(stream), hueco)
    rom[CG:CG + len(stream)] = stream
    if len(stream) < hueco:
        rom[CG + len(stream):0x3D660] = b'\x00' * (hueco - len(stream))
    print('  stream del CG: %d B de %d disponibles' % (len(stream), hueco))

    # round-trip
    f2 = Flujo(bytes(rom), CG)
    for k in range(20):
        c = b''.join(tile(f2) for _ in range(4))
        assert c == celdas[k], 'el round-trip falla en la celda %03X' % (
            0x19C + k)
    print('  round-trip de las 20 celdas: OK')

    # ==================================================================
    # 3. EL RECORTE
    # ==================================================================
    # $8807 STA $368B / $880A LDA $2A70,X / ADC $C826,Y / STA $368C
    o = 0x16807
    esperado = bytes([0x8D, 0x8B, 0x36,                    # STA $368B
                      0xBD, 0x70, 0x2A,                    # LDA $2A70,X
                      0x79, 0x26, 0xC8,                    # ADC $C826,Y
                      0x8D, 0x8C, 0x36])                   # STA $368C
    assert bytes(rom[o:o + 12]) == esperado, \
        'la escritura del ancla no es la esperada: %s' % bytes(
            rom[o:o + 12]).hex()

    # Se engancha DESPUES de escribir los dos bytes del ancla, sustituyendo
    # el STA $368C por un JSR a la rutina de recorte, que hace el STA y
    # ademas ajusta. Son 3 bytes por 3 bytes.
    #
    # Hueco: el banco $0B. Buscar relleno al final.
    banco = rom[0x16000:0x18000]
    mejor = None
    i = 0
    while i < len(banco):
        c = banco[i]
        j = i
        while j < len(banco) and banco[j] == c:
            j += 1
        if c in (0x00, 0xFF) and j - i >= 40:
            if mejor is None or j - i > mejor[1] - mejor[0]:
                mejor = (i, j)
        i = j
    assert mejor, 'no hay hueco en el banco $0B'
    HUECO = 0x16000 + mejor[0]
    HUECO_L = 0x8000 + mejor[0]
    print()
    print('hueco en el banco $0B: ROM 0x%05X ($%04X), %d B'
          % (HUECO, HUECO_L, mejor[1] - mejor[0]))

    # La rutina de recorte. El ancla es de 16 bits ($368B/$368C) y esta en
    # coordenadas de MUNDO; el scroll vive en $35/$36 (lo resta $E3EB).
    #   izquierda: si ancla - scroll < 76+4  -> ancla = scroll + 80
    #   derecha:   si ancla - scroll > 168-4 -> ancla = scroll + 164
    # 76 = 80-4 es el X0 del marco con su margen.
    XMIN = 80
    XMAX = 164
    rec = bytes([
        0x8D, 0x8C, 0x36,          # STA $368C      (lo que sustituimos)
        # A = byte alto. Calcular ancla - scroll en $10/$11
        0xAD, 0x8B, 0x36,          # LDA $368B
        0x38,                      # SEC
        0xE5, 0x35,                # SBC $35
        0x85, 0x10,                # STA $10
        0xAD, 0x8C, 0x36,          # LDA $368C
        0xE5, 0x36,                # SBC $36
        0x85, 0x11,                # STA $11
        # si el alto no es 0, esta fuera de pantalla por arriba o por abajo
        0xD0, 0x0C,                # BNE  -> comprobar signo
        # alto == 0: comparar el bajo
        0xA5, 0x10,                # LDA $10
        0xC9, XMIN,                # CMP #80
        0x90, 0x0A,                # BCC  -> pegar a la izquierda
        0xC9, XMAX + 1,            # CMP #165
        0xB0, 0x0C,                # BCS  -> pegar a la derecha
        0x60,                      # RTS   (cabe)
        # alto != 0
        0xA5, 0x11,                # LDA $11
        0x30, 0x02,                # BMI  -> izquierda
        0x80, 0x08,                # BRA  -> derecha
        # pegar a la IZQUIERDA: ancla = scroll + XMIN
        0xA5, 0x35,                # LDA $35
        0x18,                      # CLC
        0x69, XMIN,                # ADC #80
        0x80, 0x04,                # BRA  guardar
        # pegar a la DERECHA: ancla = scroll + XMAX
        0xA5, 0x35,                # LDA $35
        0x18,                      # CLC
        0x69, XMAX,                # ADC #164
        # guardar
        0x8D, 0x8B, 0x36,          # STA $368B
        0xA5, 0x36,                # LDA $36
        0x69, 0x00,                # ADC #$00
        0x8D, 0x8C, 0x36,          # STA $368C
        0x60,                      # RTS
    ])
    print('rutina de recorte: %d B, limites x=%d..%d' % (len(rec), XMIN, XMAX))
    print('  DESCARTADA: los saltos relativos hay que calcularlos a mano y')
    print('  no los he verificado. Ver abajo.')

    # ------------------------------------------------------------------
    # NO se escribe la rutina de recorte en esta version.
    # Motivo: son 9 saltos relativos escritos a mano y la norma dice
    # desensamblar todo salto antes de meterlo en ROM. Con el centrado y el
    # rabillo ya hay dos cambios verificables; el recorte va aparte para
    # poder aislar el fallo si lo hubiera (norma 107: de uno en uno).
    # ------------------------------------------------------------------

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('tabla rabillo $9ADD', 0x41ADD, 0x41AFD),
        ('fuente', 0x3D660, 0x3E200),
        ('rabillo simetrico original', 0x5292, 0x52C0),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    permitido = set(range(TABLA, TABLA + 4)) | set(range(CG, 0x3D660))
    fuera = [i for i in dif if i not in permitido]
    assert not fuera, 'cambios fuera de lo previsto: %s' % [hex(i) for i in fuera[:8]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec_ips = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec_ips.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                              (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec_ips) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        of = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n = raw[p + 3] << 8 | raw[p + 4]
        prueba[of:of + n] = raw[p + 5:p + 5 + n]
        p += 5 + n
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  1. El bocadillo CENTRADO sobre el aldeano (antes iba 40 px a la')
    print('     izquierda o 8, segun el lado).')
    print('  2. El rabillo en punta SIMETRICA, como en la intro.')
    print('  3. Seguira saliendose con aldeanos muy al borde: el recorte va')
    print('     en el paso siguiente.')


if __name__ == '__main__':
    main()
