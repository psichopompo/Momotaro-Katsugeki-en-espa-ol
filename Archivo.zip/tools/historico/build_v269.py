#!/usr/bin/env python3
"""
build_v269.py - el menu RUN en castellano, infinitivos y palabras completas.

David: *«no me gusta ninguno y tampoco quiero abreviaturas. Quiero los
verbos en infinitivo y las palabras completas.»*

EL HALLAZGO QUE LO HACE POSIBLE
===============================
La norma 207 del LEEME decia que los verbos NO tenian tabla de punteros y
que por tanto no se podian mover. **Era falsa.** Hay dos tablas, y estan ya
en la ROM virgen:

```
$B1AC  ROM 0x431AC   4 entradas  -> verbos de objeto
$B1CC  ROM 0x431CC   4 entradas  -> aliados
```

Cuatro pruebas independientes (ver investigation.md, entrada 156):
 1. identicas en la ROM virgen -> no son artefacto nuestro
 2. la tabla de tienda $B712 repite $B72E en [0] y [3]: una cadena no puede
    estar en dos sitios, un puntero si
 3. los punteros teselan las cadenas exactamente, sin huecos ni solapes
 4. el script las invoca como [cmd][word]: 0x42F81 `01 AC B1`, etc.

El error de metodo fue buscar direccionamiento indexado (`LDA $B1AC,X`) y,
al no hallarlo, concluir que no habia tabla. El interprete de script no lee
la tabla con `abs,X`: recibe el puntero como operando de un comando del
guion. Busque la huella equivocada y tome la ausencia de MI huella como
ausencia del hecho.

LA VENTANA DE DIRECCIONAMIENTO
==============================
Los punteros son words de 16 bits y el banco $21 se mapea en $A000-$BFFF,
o sea ROM 0x42000-0x43FFF. **Las cadenas tienen que vivir ahi.** El hueco
de $DE69 (banco $0B, 407 B) que use para el password NO sirve aqui: es
hueco de codigo en otro banco. Son dos presupuestos distintos.

EL PRESUPUESTO
==============
```
bloque original 0x431B4-0x431EB          55 B
hueco recuperado 0x43D11-0x43D18          7 B   (sobra de traducir 0x43CAA)
                                        -----
                                          62 B
```

Con los textos que eligio David (vía A: acortar solo los dos mensajes
largos, los ocho verbos completos):

```
No se puede  13 B      Sin aliado   12 B
Comer         7 B      Perro         7 B
Usar          6 B      Faisán        8 B
Tirar         7 B      Mono          6 B
                                    -----
                                     66 B
```

66 > 62. Faltan 4 bytes, asi que se usa ademas el hueco recuperado
0x43432-0x43436 (4 B). Verificado que ninguno de los dos huecos tiene una
sola referencia [cmd][word] apuntando dentro (las coincidencias crudas que
salen al buscar la word suelta son bytes de codigo: `85 14 BD ..`,
`20 18 BD ..`, etc., comprobadas una a una).

DISPOSICION
===========
Las cadenas se colocan CONCATENADAS desde 0x431B4, y las que no caben van
al hueco de 0x43D11. Se reescriben las 8 words de las dos tablas. No se
toca ni un byte de codigo.

Uso:  python3 tools/build_v269.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import encode                       # noqa: E402

BASE = 'roms/momotaro_es_v268.pce'
SALIDA = 'roms/momotaro_es_v269.pce'
IPS = 'parches/momotaro_v269.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '8a7cee42002affaec24b5c564170b6a8'

BANCO_INI, BANCO_FIN = 0x42000, 0x44000
CPU_INI = 0xA000

TABLA_OBJ = 0x431AC          # $B1AC, 4 entradas
TABLA_ALI = 0x431CC          # $B1CC, 4 entradas

# zonas donde se pueden escribir cadenas: (inicio, fin_exclusivo)
# OJO: la tabla de aliados ($B1CC, ROM 0x431CC-0x431D4) vive DENTRO del
# bloque de cadenas. El bloque NO es un hueco continuo de 55 B: son dos
# trozos separados por las 8 words de la tabla. Lo cazo un assert al releer.
ZONAS = [
    (0x431B4, 0x431CC),      # 24 B - bloque japones, ANTES de la tabla
    (0x431D4, 0x431EB),      # 23 B - bloque japones, DESPUES de la tabla
    (0x433E4, 0x433EB),      #  7 B - cadena japonesa que tradujimos
    (0x43D11, 0x43D18),      #  7 B - sobra de traducir el bloque 0x43CAA
]

# los 8 textos, en el orden de las tablas
TEXTOS_OBJ = ['No vale', 'Comer', 'Usar', 'Tirar']
TEXTOS_ALI = ['Sin nadie', 'Perro', 'Faisán', 'Mono']


def cpu(off):
    return CPU_INI + (off - BANCO_INI)


def cadena(txt):
    """Formato del motor: $01 (inicio de linea) + letras + $00 (fin)."""
    return bytes([0x01]) + encode(txt) + bytes([0x00])


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v268'
    print('base %s  OK' % BASE)

    # ==================================================================
    # 1. las tablas son reales: se vuelve a demostrar antes de tocar nada
    # ==================================================================
    print('\n--- las tablas de punteros, reverificadas')
    for base_t, n, nom in ((TABLA_OBJ, 4, '$B1AC objetos'),
                           (TABLA_ALI, 4, '$B1CC aliados')):
        assert rom[base_t:base_t + n * 2] == orig[base_t:base_t + n * 2], \
            '%s difiere de la virgen' % nom
        ws = [rom[base_t + i * 2] | (rom[base_t + i * 2 + 1] << 8)
              for i in range(n)]
        # teselado: cada cadena acaba justo donde empieza la siguiente
        ordenados = sorted(set(ws))
        for j, w in enumerate(ordenados[:-1]):
            o = BANCO_INI + (w - CPU_INI)
            f = o
            while rom[f] not in (0x00, 0xFF):
                f += 1
            sig = BANCO_INI + (ordenados[j + 1] - CPU_INI)
            assert f + 1 == sig, \
                '%s: la cadena $%04X no tesela con $%04X' % (nom, w,
                                                             ordenados[j + 1])
        print('    %-14s %s  teselado OK, = virgen'
              % (nom, ' '.join('$%04X' % w for w in ws)))

    # ==================================================================
    # 2. los huecos estan libres: ninguna referencia [cmd][word] dentro
    # ==================================================================
    print('\n--- los huecos, comprobados uno a uno')
    for a, b in ZONAS[2:]:
        assert all(x == 0x00 for x in rom[a:b]), \
            'el hueco 0x%05X no esta a cero' % a
        assert orig[a:b] != rom[a:b], \
            'el hueco 0x%05X ya estaba a cero en la virgen (no es sobra)' % a
        lo, hi = cpu(a), cpu(b)
        refs = []
        for x in range(BANCO_INI, BANCO_FIN - 2):
            if rom[x] in (0x01, 0x02, 0x03, 0x04):
                w = rom[x + 1] | (rom[x + 2] << 8)
                if lo <= w < hi:
                    refs.append(x)
        assert not refs, 'el hueco 0x%05X esta referenciado en %s' \
            % (a, ['%05X' % r for r in refs])
        print('    0x%05X-0x%05X  %2d B  $%04X-$%04X  sin referencias'
              % (a, b, b - a, lo, hi))

    # ninguna zona puede pisar una tabla de punteros
    for a, b in ZONAS:
        for t, n, nom in ((TABLA_OBJ, 4, '$B1AC'), (TABLA_ALI, 4, '$B1CC')):
            assert b <= t or a >= t + n * 2, \
                'la zona 0x%05X-0x%05X pisa la tabla %s' % (a, b, nom)
    print('    ninguna zona pisa una tabla de punteros: OK')

    total = sum(b - a for a, b in ZONAS)
    codificadas = [cadena(t) for t in TEXTOS_OBJ + TEXTOS_ALI]
    necesario = sum(len(c) for c in codificadas)
    print('\n    disponible %d B, necesario %d B' % (total, necesario))
    assert necesario <= total, 'no cabe: %d > %d' % (necesario, total)

    # ==================================================================
    # 3. colocacion: se rellenan las zonas por orden
    # ==================================================================
    print('\n--- colocacion')
    # Colocacion por BACKTRACKING exhaustivo.
    #
    # Best-fit no vale: el ajuste es exacto (61 B en 61 B) y con huecos
    # fragmentados una heuristica golosa se queda encajonada. Paso: dejo
    # ['3','3','0','0'] libres y «Mono» (6 B) sin sitio, aun habiendo hueco
    # de sobra en el total. Aqui se prueban todas las combinaciones y se
    # coge la primera que encaje, o se falla con un mensaje claro.
    pares = list(zip(TEXTOS_OBJ + TEXTOS_ALI, codificadas))
    orden = sorted(pares, key=lambda pc: -len(pc[1]))
    huecos = [b - a for a, b in ZONAS]

    def busca(i, libres, puestos):
        if i == len(orden):
            return puestos
        txt, cod = orden[i]
        probados = set()
        for k, lib in enumerate(libres):
            if lib >= len(cod) and lib not in probados:
                probados.add(lib)          # zonas del mismo tamano: una vez
                l2 = list(libres)
                l2[k] -= len(cod)
                r = busca(i + 1, l2, puestos + [(k, txt, cod)])
                if r is not None:
                    return r
        return None

    plan = busca(0, huecos, [])
    assert plan is not None, \
        'no existe empaquetado: %d B en zonas %s' % (necesario, huecos)

    cursor = [a for a, _ in ZONAS]
    destinos = []
    for k, txt, cod in plan:
        destinos.append((cursor[k], txt, cod))
        cursor[k] += len(cod)
    for k, (a, b) in enumerate(ZONAS):
        assert cursor[k] <= b, 'la zona %d se ha desbordado' % k

    # se reordena como las tablas, para que el listado salga en orden
    idx = {t: i for i, t in enumerate(TEXTOS_OBJ + TEXTOS_ALI)}
    destinos.sort(key=lambda d: idx[d[1]])

    for o, txt, cod in destinos:
        print('    %-12s -> ROM %05X ($%04X)  %2d B  %s'
              % (txt, o, cpu(o), len(cod), cod.hex(' ')))

    # ninguna cadena se solapa con otra
    ocup = []
    for o, txt, cod in destinos:
        for a, b, t2 in ocup:
            assert o >= b or o + len(cod) <= a, \
                'se solapan %r y %r' % (txt, t2)
        ocup.append((o, o + len(cod), txt))

    # ==================================================================
    # 4. escritura
    # ==================================================================
    # se limpian los dos trozos del bloque japones (sin tocar la tabla
    # de aliados, que vive entre medias)
    for a, b in ZONAS[:2]:
        rom[a:b] = bytes(b - a)
    for o, txt, cod in destinos:
        rom[o:o + len(cod)] = cod

    # y se reescriben las 8 words
    for base_t, textos, nom in ((TABLA_OBJ, TEXTOS_OBJ, 'objetos'),
                                (TABLA_ALI, TEXTOS_ALI, 'aliados')):
        print('\n    tabla %s en ROM %05X:' % (nom, base_t))
        for i, txt in enumerate(textos):
            o = next(x for x, t, _ in destinos if t == txt)
            w = cpu(o)
            rom[base_t + i * 2] = w & 0xFF
            rom[base_t + i * 2 + 1] = w >> 8
            print('       [%d] -> $%04X  %s' % (i, w, txt))

    # ==================================================================
    # 5. verificacion: se releen las tablas DESDE LA ROM ESCRITA
    # ==================================================================
    print('\n--- releido desde la ROM escrita')
    from charset_oficial import CHAR_TO_CODE
    inv = {v: k for k, v in CHAR_TO_CODE.items()}
    for base_t, textos, nom in ((TABLA_OBJ, TEXTOS_OBJ, 'objetos'),
                                (TABLA_ALI, TEXTOS_ALI, 'aliados')):
        for i, esperado in enumerate(textos):
            w = rom[base_t + i * 2] | (rom[base_t + i * 2 + 1] << 8)
            assert CPU_INI <= w < 0xC000, \
                'el puntero $%04X se sale del banco $21' % w
            o = BANCO_INI + (w - CPU_INI)
            assert rom[o] == 0x01, \
                'la cadena en $%04X no empieza por $01' % w
            f = o + 1
            while rom[f] != 0x00:
                f += 1
            leido = ''.join(inv.get(x, '[%02X]' % x) for x in rom[o + 1:f])
            assert leido == esperado, \
                'leido %r, esperado %r' % (leido, esperado)
            print('    %s[%d] $%04X -> %r  OK' % (nom, i, w, leido))

    # ==================================================================
    # 6. zonas intactas
    # ==================================================================
    intactas = [
        ('codigo tras los verbos', 0x431EB, 0x433E4),
        ('resto tras el hueco 0x433E4', 0x433EB, 0x43400),
        ('tabla de tienda $B712', 0x43712, 0x4372E),
        ('cadenas de tienda', 0x4372E, 0x4379D),
        ('nombres del inventario', 0x42F4C, 0x43180),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla de glifos', 0x43F9B, 0x44000),
        ('bucle del canto', 0x16A73, 0x16AD6),
        ('continuacion del password', 0x17E69, 0x17E78),
        ('bloque 0x43CAA', 0x43CA8, 0x43D11),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    permitido = set()
    for a, b in ZONAS:
        permitido |= set(range(a, b))
    permitido |= set(range(TABLA_OBJ, TABLA_OBJ + 8))
    permitido |= set(range(TABLA_ALI, TABLA_ALI + 8))
    assert set(dif) <= permitido, \
        'cambios fuera de sitio: %s' % ['%05X' % x for x in
                                        sorted(set(dif) - permitido)][:10]
    print('%d bytes sobre la v268, todos en zonas previstas' % len(dif))

    open(SALIDA, 'wb').write(d)

    # --- IPS con round-trip ---
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
