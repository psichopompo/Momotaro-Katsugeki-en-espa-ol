#!/usr/bin/env python3
"""build_v329.py - «¡Yo soy el ermitaño Vuelo!» y la P4 bien formulada.

1. LA FRASE DEL ERMITANYO, COMPLETA
   --------------------------------
   David, literal: «no me jodas. En japones dice "Washi wa hiensen nin ja!".
   Tendria que decir "¡Yo soy el ermitaño Hien!"».

   Y tiene razon dos veces. Yo habia escrito «Soy Vuelo.», que se come la
   palabra ERMITAÑO entera. Peor: dije que «ermitaño no esta traducido en
   ninguna parte» y David me tapo la boca con una captura. Comprobado:

       0x491D4  «El ermitaño vive en lo alto. Deberias pedirle que te enseñe»

   Estaba traducido desde hace versiones. Me bastaba con BUSCARLO.

   El problema real era el hueco: prefijo 4 B + sufijo 8 B = 12 utiles, y
   «¡Yo soy el ermitaño » son 20. La solucion no es rebajar el texto, es
   REPUNTAR: el prefijo se carga inmediato en $D7BE (LDA #$2D / LDA #$6E),
   asi que basta cambiar dos bytes y llevarlo a espacio libre.

       0x4B7D3   168 bytes de $A0 libres al final de la zona del quiz
                 (CPU $77D3, mismo banco $25, misma ventana)

   Queda:  |¡Yo soy el      | + |ermitaño | + <TECNICA> + |!|

2. LA P4, QUE NO SE ENTENDIA
   -------------------------
   «¿Al quemar qué / salió ceniza?» no se entiende. En el cuento, al viejo
   le dan ceniza al quemar el MORTERO (usu). La pregunta correcta es de
   donde salio esa ceniza.
       ->  «La ceniza, ¿de / qué salio?»
   Revisadas de paso las 40 buscando la misma pega.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402
from quiz_texto import QUIZ, VISIBLES                                  # noqa: E402

BASE = 'roms/momotaro_es_v328.pce'
SALIDA = 'roms/momotaro_es_v329.pce'
MD5_BASE = '936a68d560b4e9ef325add0490be0c34'

# ---- 1. la frase del ermitanyo -----------------------------------------
LDA_PREFIJO = 0x117BE       # A9 2D 85 BF A9 6E 85 C0  -> $6E2D
PREFIJO_VIEJO = 0x4AE2D
MARCADOR = 0x4AE31
SUFIJO = 0x4AE32
FIN = 0x4AE3A

NUEVO = 0x4B85D             # al FINAL de la zona del quiz, CPU $785D
#                             (el quiz ocupa hasta 0x4B7D6; aqui sobran 30 B)
CPU_BASE = 0x6000
ROM_BASE = 0x4A000

L1 = '¡Yo soy el'           # linea 1, se rellena a 16
L2 = 'ermitaño '            # linea 2, el nombre se pega detras
SUF = '!'                   # cierra tras el nombre

COLS = 16
RELLENO = 0xA0

# ---- 2. las preguntas que no se entendian ------------------------------
#   P1  «¿Qué le dio / Otohime a él?»   el «a él» no tiene antecedente
#   P4  «¿Al quemar qué / salió ceniza?» no se entiende (la que mando David)
#   P9  «¿Qué había en / el cesto?»     faltaba que el cesto era el PESADO
#   P13 «El mono, ¿qué / le tiró?»      no decia a quien
#   P17 «¿Qué hacía el / chas-chas?»    «hacer un chas-chas» no se dice
#   P20 «¿Quién luchó a / sumo con él?» «con él» sin antecedente
#   P34 «¿En qué barco / iba Issun?»    «Issun» a secas
# Todas en quiz_texto.py. Aqui se reescribe la zona ENTERA.
ZONA_INI = 0x4AEEE
COLS_PREG = 16
UTILES = 7

TABLA = 0x11818
ZONA_FIN = 0x4B87B

INTACTAS = [
    (0x00000, 0x10000, 'bancos 00-07'),
    (0x12000, 0x4A000, 'bancos 09-24'),
    (0x4A000, 0x4AE2D, 'dados, cierre del quiz'),
    (0x4AE3B, 0x4AEE6, 'quiz/ppt y las 14 tecnicas'),
    (0x4B87B, 0x4C000, 'cierre del quiz'),
    (0x4C000, 0x80000, 'bancos 26-3F'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v328'
    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    # ============ 1. la frase completa ==================================
    assert rom[LDA_PREFIJO:LDA_PREFIJO + 8] == bytes(
        [0xA9, 0x2D, 0x85, 0xBF, 0xA9, 0x6E, 0x85, 0xC0]), \
        'en %06X no esta el LDA del prefijo' % LDA_PREFIJO
    # el destino tiene que estar libre de verdad
    largo = COLS + len(cv.encode(L2)) + 1        # 16 + 9 + el $00
    assert all(rom[NUEVO + i] == RELLENO for i in range(largo + 4)), \
        'el hueco de %06X no esta libre' % NUEVO
    assert NUEVO + largo < ZONA_FIN, 'se sale de la zona'

    d = (cv.encode(L1) + bytes([RELLENO]) * (COLS - len(L1)) + cv.encode(L2))
    rom[NUEVO:NUEVO + len(d)] = d
    rom[NUEVO + len(d)] = 0x00                   # marcador de sustitucion

    cpu = CPU_BASE + NUEVO - ROM_BASE
    assert 0x6000 <= cpu < 0x8000
    rom[LDA_PREFIJO + 1] = cpu & 0xFF
    rom[LDA_PREFIJO + 5] = cpu >> 8

    # el sufijo, en su sitio de siempre
    ds = cv.encode(SUF)
    rom[SUFIJO:FIN] = ds + bytes([RELLENO]) * (FIN - SUFIJO - len(ds))
    rom[FIN] = 0x80

    # el hueco viejo queda muerto: a relleno, respetando su $00 y su $80
    rom[PREFIJO_VIEJO:MARCADOR] = bytes([RELLENO]) * (MARCADOR - PREFIJO_VIEJO)
    rom[MARCADOR] = 0x00

    # ============ 2. la P4 ==============================================
    def blq(i):
        c = rom[TABLA + 2 * i] | rom[TABLA + 2 * i + 1] << 8
        return ROM_BASE + c - CPU_BASE

    bloques = []
    for _n, l1, l2, _o1, _o2, _o3, _jp in QUIZ:
        assert len(l1) <= VISIBLES and len(l2) <= VISIBLES, (l1, l2)
        bloques.append(cv.encode(l1) + bytes([RELLENO]) * (COLS - len(l1)) +
                       bytes([0x80]) +
                       cv.encode(l2) + bytes([RELLENO]) * (COLS - len(l2)))
    for _n, _l1, _l2, o1, o2, o3, _jp in QUIZ:
        r = b''
        for op in (o1, o2, o3):
            assert len(op) <= UTILES, op
            r += (bytes([RELLENO]) + cv.encode(op) +
                  bytes([RELLENO]) * (UTILES - len(op)))
        bloques.append(r)

    # el prefijo del ermitanyo vive al final de la zona: no lo pisamos
    tope = NUEVO
    total = sum(len(b) for b in bloques)
    assert ZONA_INI + total <= tope, 'el quiz (%d B) pisaria el prefijo' % total

    pos = ZONA_INI
    for i, b in enumerate(bloques):
        rom[pos:pos + len(b)] = b
        c = CPU_BASE + pos - ROM_BASE
        rom[TABLA + 2 * (i + 2)] = c & 0xFF
        rom[TABLA + 2 * (i + 2) + 1] = c >> 8
        pos += len(b)
    rom[pos:tope] = bytes([RELLENO]) * (tope - pos)

    # ============ VERIFICACION ==========================================
    def lee(cpu_, hasta=(0x00, 0x80, 0xFF)):
        o = ROM_BASE + cpu_ - CPU_BASE
        e = o
        while rom[e] not in hasta:
            e += 1
        return ''.join(' ' if x == RELLENO else rv.get(x, '?') for x in rom[o:e])

    # la frase, montada como la monta $D7AE: prefijo + tecnica + sufijo
    pref = lee(rom[LDA_PREFIJO + 1] | rom[LDA_PREFIJO + 5] << 8)
    suf = lee(0x6E32)
    for i, tec in enumerate(('Vuelo', 'Salto', 'Parapunte')):
        frase = (pref + tec + suf).rstrip()
        assert 'ermitaño' in frase, 'falta «ermitaño»: «%s»' % frase
        assert frase.startswith('¡Yo soy el'), frase
        assert frase.endswith('!'), frase
        # y el nombre va PEGADO a «ermitaño », sin hueco
        assert 'ermitaño ' + tec + '!' in frase, frase
    print('  frase: «%s»' % (pref + 'Vuelo' + suf).replace('  ', ' ').strip())

    # las 14 tecnicas siguen enteras
    esperados = ['Vuelo', 'Salto', 'Rodar', 'Giro', 'Bomba', 'Ola', 'Parapunte',
                 '+Vuelo', '+Salto', '+Rodar', '+Giro', '+Bomba', '+Ola',
                 'Parapunte']
    for i, nombre in enumerate(esperados):
        c = rom[0x118BC + 2 * i] | rom[0x118BC + 2 * i + 1] << 8
        assert lee(c, (0x00, 0x80)).strip() == nombre, 'tecnica [%d] rota' % i

    # el limpiador, intacto
    assert rom[0x4AD56:0x4AD76] == bytes([0x20]) * 32, 'limpiador tocado'

    # las 40 preguntas y las 120 opciones, releidas por puntero
    for i, (_n, l1, l2, o1, o2, o3, _jp) in enumerate(QUIZ):
        a = blq(i + 2)
        assert rom[a + COLS] == 0x80, 'P%d sin $80' % (i + 1)
        g1 = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                     for x in rom[a:a + COLS]).rstrip()
        g2 = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                     for x in rom[a + COLS + 1:a + 2 * COLS + 1]).rstrip()
        assert (g1, g2) == (l1, l2), 'P%d «%s»/«%s»' % (i + 1, g1, g2)
        b = blq(i + 42)
        for k, op in enumerate((o1, o2, o3)):
            cel = rom[b + k * 8:b + (k + 1) * 8]
            assert cel[0] == RELLENO, 'P%d op%d sin sangria' % (i + 1, k + 1)
            g = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                        for x in cel).strip()
            assert g == op, 'P%d op%d «%s» != «%s»' % (i + 1, k + 1, g, op)

    # cero alias en la zona del quiz
    malos = [i for i in range(0x4AD76, ZONA_FIN)
             if rom[i] in (0x5B, 0x5D, 0x5E, 0x5C)]
    assert not malos, 'alias en %s' % ['%06X' % x for x in malos[:5]]

    # toda pregunta cierra su interrogacion
    for q in range(40):
        o = blq(q + 2)
        t = ''.join(' ' if x == RELLENO else rv.get(x, '')
                    for x in rom[o:o + 33] if x != 0x80)
        assert t.count('¿') == t.count('?'), 'P%d: «%s»' % (q + 1, t)

    for a2, b2, nombre in INTACTAS:
        assert rom[a2:b2] == original[a2:b2], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print('  prefijo repuntado $6E2D -> $%04X (ROM %06X)' % (cpu, NUEVO))
    print('  quiz reescrito: %d B, tope %06X' % (total, tope))
    for q in (1, 4, 9, 13, 17, 20, 34):
        n, l1, l2 = QUIZ[q - 1][0], QUIZ[q - 1][1], QUIZ[q - 1][2]
        print('    P%-2d |%-15s| |%s|' % (n, l1, l2))


if __name__ == '__main__':
    main()
