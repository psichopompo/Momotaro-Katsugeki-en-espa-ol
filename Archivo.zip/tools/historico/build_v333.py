#!/usr/bin/env python3
"""build_v333.py - «la isla de los ogros» y «¡A por los ogros!».

1. LA ISLA (decision de David)
   ---------------------------
   El rotulo del mapa dice «Isla Ogros», pero el resto del guion trata
   «ogros» como nombre comun en minuscula («para vencer a los ogros»,
   «Ogros no te ven»). David elige la forma natural:

       PAGINA 2   |¡Ve a la isla   |de los ogros!   |

2. «¡A por ogros!» -> «¡A por los ogros!»
   --------------------------------------
   Esta en la ranura $4834 de la tabla de tiendas (ROM 0x48834), que
   comparten las cuatro posadas (t5..t8, ranuras [2], [4] y [5]).

   **La ranura mide 40 bytes, no 32.** El siguiente puntero USADO es $485C
   (0x4885C), y el japones ocupaba las 40 columnas:

       オハヨウゴザイマス!      \\オニ\\タイジ ガンバッテクダサイネ
       «buenos dias! ... derrota a los ogros, esfuerzate!»

   Nosotros solo escribimos 32 y los 8 ultimos bytes SEGUIAN EN JAPONES
   («ッテクダサイネ»). No se veian porque el motor corta antes, pero ahi
   estaban. Con 40 B caben tres lineas de 16 y «¡A por los ogros!» entra
   partido en dos, que es como lo pinta el motor de todos modos.

   HALLAZGO: hay 8 bytes de japones sin traducir que nadie habia visto.
   Se anota en PENDIENTES por si aparecen mas casos iguales.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402

BASE = 'roms/momotaro_es_v332.pce'
SALIDA = 'roms/momotaro_es_v333.pce'
MD5_BASE = '9de8abb9f2197a1f1cafdb235ce846ae'

RELLENO = 0xA0
COLS = 16

# ---- 1. la isla ---------------------------------------------------------
PAGINA2 = (0x4AD9A, 0x4ADBC, ['¡Ve a la isla', 'de los ogros!'])

# ---- 2. la posada -------------------------------------------------------
POSADA = 0x48834            # ranura $4834, 40 B hasta $485C
POSADA_FIN = 0x4885C
POSADA_TXT = ['¡Buenos días!', '¡A por los', 'ogros!']

INTACTAS = [
    (0x00000, 0x10000, 'bancos 00-07'),
    (0x10000, 0x48834, 'bancos 08-23 y principio del 24'),
    (0x4885C, 0x4AD9A, 'resto del banco 24 y el cierre'),
    (0x4ADBC, 0x4C000, 'fallo, premio, quiz y diccionario'),
    (0x4C000, 0x80000, 'bancos 26-3F'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v332'
    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    def escribe(a, b, lineas, etiqueta):
        """Rellena cada linea a 16 columnas; la ULTIMA solo hasta el final
        del hueco, que puede ser mas corto (la ranura de la posada son 40 B
        = 2 lineas de 16 + 8)."""
        d = b''
        for i, l in enumerate(lineas):
            ancho = COLS if i < len(lineas) - 1 else (b - a) - len(d)
            assert len(l) <= ancho, '%s: «%s» son %d y la linea da %d' % (
                etiqueta, l, len(l), ancho)
            d += cv.encode(l) + bytes([RELLENO]) * (ancho - len(l))
        assert len(d) <= b - a, '%s: %d B y hay %d' % (etiqueta, len(d), b - a)
        rom[a:b] = d + bytes([RELLENO]) * (b - a - len(d))

    # ---- 1. la isla -----------------------------------------------------
    a, b, lineas = PAGINA2
    escribe(a, b, lineas, 'pagina 2')

    # ---- 2. la posada ---------------------------------------------------
    # antes de tocar: comprobar que la ranura llega de verdad hasta $485C
    assert POSADA_FIN - POSADA == 40, 'la ranura no mide 40 B'
    viejo = cv.encode('¡Buenos días!')
    assert rom[POSADA:POSADA + len(viejo)] == viejo, \
        'en %06X no esta «¡Buenos días!»' % POSADA
    # y que los 8 ultimos son el japones que nadie habia traducido
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    assert rom[POSADA_FIN - 8:POSADA_FIN] == jp[POSADA_FIN - 8:POSADA_FIN], \
        'los 8 ultimos bytes ya no son los japoneses'
    escribe(POSADA, POSADA_FIN, POSADA_TXT, 'posada')

    # ---- VERIFICACION ---------------------------------------------------
    def lee(a, b):
        return ''.join(' ' if x == RELLENO else rv.get(x, '?')
                       for x in rom[a:b])

    # la pagina 2, linea a linea
    t = lee(*PAGINA2[:2])
    for i, l in enumerate(PAGINA2[2]):
        assert t[i * COLS:(i + 1) * COLS].rstrip() == l, \
            'pagina 2 linea %d: «%s»' % (i, t[i * COLS:(i + 1) * COLS])

    # la posada
    t = lee(POSADA, POSADA_FIN)
    for i, l in enumerate(POSADA_TXT):
        trozo = t[i * COLS:(i + 1) * COLS] if i < 2 else t[2 * COLS:]
        assert trozo.rstrip() == l, 'posada linea %d: «%s»' % (i, trozo)
    # Cero japones en la ranura. OJO: comparar rom[i]==jp[i] NO sirve, los
    # bytes de nuestro charset pisan el rango katakana ($AF es «o» aqui y
    # ッ alli). Ya me dio un falso positivo en la v324. La prueba buena es
    # que la relectura devuelva EXACTAMENTE el texto castellano y que no
    # quede ningun byte fuera de nuestro juego de caracteres.
    validos = set(cv.CHAR_TO_CODE.values()) | {RELLENO}
    malos = [i for i in range(POSADA, POSADA_FIN) if rom[i] not in validos]
    assert not malos, 'bytes ajenos en %s' % ['%06X' % x for x in malos]

    # las cuatro posadas siguen apuntando a la ranura
    T = 0x10854
    for t_i in (5, 6, 7, 8):
        ps = [rom[T + t_i * 12 + 2 * k] | rom[T + t_i * 12 + 2 * k + 1] << 8
              for k in range(6)]
        assert ps[2] == 0x4834, 't%d ranura [2] = $%04X' % (t_i, ps[2])

    # el limpiador y la pagina 1, intactos
    assert rom[0x4AD56:0x4AD76] == bytes([0x20]) * 32, 'limpiador tocado'
    assert rom[0x4AD76:0x4AD9A] == original[0x4AD76:0x4AD9A], 'pagina 1 tocada'

    for a2, b2, nombre in INTACTAS:
        assert rom[a2:b2] == original[a2:b2], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  pagina 2:  %s' % ' / '.join('|%s|' % x for x in PAGINA2[2]))
    print('  posada:    %s' % ' / '.join('|%s|' % x for x in POSADA_TXT))
    print('  + 8 bytes de japones sin traducir, eliminados de la ranura')


if __name__ == '__main__':
    main()
