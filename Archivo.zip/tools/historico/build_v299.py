#!/usr/bin/env python3
"""v299 = v296 + SOLO los dos cambios que David ha validado en pantalla.

REVERSION de la v298 (norma 107: volver al ultimo estado bueno, no parchear
el parche). La v298 movia 47 glifos y rompia media ROM; ver la entrada 171
del diario para la causa.

Se conservan unicamente:

1) 0x3DBE8  $00 -> $18   contador de bloques del CG del bocadillo de TIENDA.
   Validado por David: «al salir de la tienda el HUD se ve bien» y
   «ya se ven bien las tiendas».

2) 0x04100  glifo 16 de la fuente del titulo = el simbolo (c).
   Validado por David: «la (c) ha vuelto».

Es exactamente la v297, que David probo y dio por buena, mas la (c).
NO se toca ni un glifo de la fuente DIALOGO ni ninguna tabla.
"""
import hashlib, zlib, sys

SRC = 'roms/momotaro_es_v296.pce'
JP  = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v299.pce'
CO  = 0x04100

rom  = bytearray(open(SRC, 'rb').read())
jp   = open(JP, 'rb').read()
orig = bytes(rom)

assert len(rom) == 512 * 1024
assert hashlib.md5(orig).hexdigest() == '781fb22da4b5cba725ca73afc6f6a1bf', 'la v296 no es la esperada'

# --- 1. contador del CG de tienda -----------------------------------------
assert rom[0x3DBE8] == 0x00, 'byte 0x3DBE8 inesperado: %02X' % rom[0x3DBE8]
assert jp[0x3DBE8] == 0x18
rom[0x3DBE8] = 0x18

# --- 2. la (c) del titulo --------------------------------------------------
rom[CO:CO + 16] = jp[CO:CO + 16]

# --- lo que NO se puede haber tocado ---------------------------------------
permitido = set([0x3DBE8]) | set(range(CO, CO + 16))
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and i not in permitido]
assert not fuera, 'cambios fuera de zona: %s' % [hex(x) for x in fuera][:20]

# las tablas de fuente, INTACTAS respecto a la v296
assert rom[0x41CF3:0x41D33] == orig[0x41CF3:0x41D33], 'tabla f0 tocada'
assert rom[0x41CB3:0x41CF3] == orig[0x41CB3:0x41CF3], 'tabla f1 tocada'
# las tres tablas de indice DIRECTO de glifo (norma 267)
for nom, o in (('parrilla', 0x1BBBA), ('Jizo', 0x16AD6), ('canto GO', 0x1F7B6)):
    assert rom[o:o + 64] == orig[o:o + 64], 'tabla %s tocada' % nom
# los glifos de la fuente DIALOGO, intactos salvo el byte del contador
# (0x3DBE8 es a la vez el ultimo byte del glifo 177 y el contador de bloques)
assert rom[0x3D660:0x3DBE8] == orig[0x3D660:0x3DBE8], 'glifos < 177 tocados'
assert rom[0x3DBE9:0x3E000] == orig[0x3DBE9:0x3E000], 'glifos > 177 tocados'
# la T y la O acentuada del titulo siguen siendo nuestras
assert rom[0x04240:0x04250] != jp[0x04240:0x04250], 'la T se ha revertido'
assert rom[0x042B0:0x042C0] != jp[0x042B0:0x042C0], 'la O acentuada se ha revertido'

open(DST, 'wb').write(rom)

# --- relectura siguiendo el puntero como hace el motor --------------------
v = open(DST, 'rb').read()
sys.path.insert(0, 'tools')
from descomp_cg2 import bloque, F
n = v[0x3DBE8]
f = F(v, 0x3DBE9)
[bloque(f) for _ in range(n)]
assert n == 24
assert 0x0EC + n - 1 == 0x103 < 0x1B0, 'sigue pisando el HUD'
print('relectura CG tienda: %d celdas, $0EC..$%03X  (HUD $1B0 a salvo)' % (n, 0x0EC + n - 1))
assert v[CO:CO + 16] == jp[CO:CO + 16], 'la (c) no esta'

b = bytes(v)
print(DST)
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xffffffff))
print('  %d bytes cambiados respecto a la v296' % len([i for i in range(len(v)) if v[i] != orig[i]]))
