#!/usr/bin/env python3
"""build_v327.py - Todo junto: el ©, las preguntas, y las frases japonesas.

1. EL «©» — CAUSA ENCONTRADA
   -------------------------
   Dato de David que lo resolvio: «en las tiendas y dialogos de los
   aldeanos se ve bien. Solo parece pasar en el quiz.»

   Las tiendas usan `charset_vitores` = BYTES DIRECTOS ($A2 $A3 $B0).
   El quiz lo escribi con `charset_oficial` = ALIAS ($5B $5D $5E).

   Los dos acaban en el mismo numero de glifo, PERO por rutas distintas
   dentro de $AAB4, y cada ruta deja mapeado un banco distinto en MPR4:

       byte >= $A0   $AAC5 tabla $ABAF -> $AAD4 -> $AAEA  banco $1E
       byte <  $A0   $AB23 tabla $BF9B -> $AAD4 -> ...
                     y si la entrada es 0: $AB29 -> banco $02

   Verificado contra la captura de David de la P8: en «¿Qué comió el /
   gorrión goloso?» falla EXACTAMENTE el byte $5D (la c) y la linea 2,
   que no tiene ningun alias, sale perfecta.

   Arreglo: en el quiz, bytes DIRECTOS. Se codifica con charset_vitores.

2. LAS CUATRO PREGUNTAS QUE NO SE ENTIENDEN
   ----------------------------------------
   David: 13, 19, 31, 36 (esta ultima ademas sin el «se»), y una sin
   cierre de interrogacion. Su idea: repartir distinto entre las dos
   lineas de 16. Aplicada; revisadas TODAS las 40 de paso.

3. LAS DOS FRASES JAPONESAS DEL FINAL DEL QUIZ
   -------------------------------------------
   Al acertar todo salia japones. Son otra CONCATENACION de tres trozos
   (norma 303), leida en $D5F6:

       $D600  ptr $6DE2  «sasuga wa Momotaro ja!»
       $D610  tabla $D8CA[tecnica]
       $D61D  ptr $6DF5  «wo sazukeyou zo!»

   Y el camino de fallo, $D639 -> ptr $6DBC «mada mada shugyou ga taran!»

   Los tres mensajes de 0x4AD5E son de 32 columnas (2 lineas de 16), como
   las preguntas: los pinta el mismo $DD42.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402
from quiz_texto import QUIZ, ROTULO, COLS_PREGUNTA, UTILES, VISIBLES  # noqa: E402

BASE = 'roms/momotaro_es_v326.pce'
SALIDA = 'roms/momotaro_es_v328.pce'
MD5_BASE = '20bdaae7ff13351c08f577e54d35638c'

TABLA = 0x11818
ZONA_INI = 0x4AEEE
ZONA_FIN = 0x4B87B
CPU_BASE = 0x6000
ROM_BASE = 0x4A000
ROTULO_QUIZ = 0x4AEE6

RELLENO = 0xA0
SALTO = 0x80
FINFF = 0xFF

# ---- los tres mensajes del cierre, 2 lineas de 16 -----------------------
#   0x4AD5E  36 B   «Momotaro! ya te enseñe una tecnica...»
#   0x4AD9C  32 B   «...ve a la isla de los ogros!»
#   0x4ADBC  38 B   «aun te falta entrenamiento! vuelve otro dia»
#   0x4ADE2  19 B   «bien hecho, Momotaro!» + $80   <- frase del premio
#   0x4ADF5  11 B   «te concedo ...!»            + $FF
#   0x4AE01   8 B   «te concedo ...»             + $FF
#  Estos bloques NO llevan $80: el motor salta de linea solo al llegar a la
#  columna 16. Son un FLUJO continuo, no lineas sueltas. Se rellena cada
#  linea a 16 con $A0 para forzar el salto donde queremos.
#  El bloque 0x4AD5E es de 62 B = 3 lineas de 16 + 14 de cola.
#  0x4AD56..0x4AD76 son 32 bytes de $20 que NO son texto: son el bloque que
#  $DD31 usa para BORRAR el bocadillo. En la v327 escribi encima y cada vez
#  que el juego «limpiaba» pintaba mi frase. Ese era el texto fugaz que veia
#  David. Se restauran a $20 y el texto empieza en 0x4AD76.
LIMPIADOR = (0x4AD56, 0x4AD76)
CIERRE = [
    (0x4AD76, 0x4ADBC, ['¡Momotaro! Ya', 'te enseñé un', 'arte. ¡Corre a',
                        'la Isla Ogros!']),
    (0x4ADBC, 0x4ADE2, ['¡Aún te falta', 'entrenamiento!']),
]
PREMIO1 = (0x4ADE2, 0x4ADF4, ['¡Bien hecho!'])
PREMIO2 = (0x4ADF5, 0x4AE00, 'Toma: ')      # 11 B  +$FF en 0x4AE00
PREMIO3 = (0x4AE01, 0x4AE09, 'Toma: ')      #  8 B  +$FF en 0x4AE09

INTACTAS = [
    (0x00000, 0x10000, 'bancos 00-07'),
    (0x12000, 0x4A000, 'bancos 09-24'),
    (0x4A000, 0x4AD56, 'creditos y dados'),
    (0x4AE0A, 0x4AEE6, 'ermitanyo y tecnicas (v326)'),
    (0x4B87B, 0x4C000, 'cierre del quiz y diccionario'),
    (0x4C000, 0x80000, 'bancos 26-3F'),
]


def enc(txt):
    """Bytes DIRECTOS: es lo que funciona en tiendas y dialogos."""
    return cv.encode(txt)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v326'

    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    # ============ 1+2. el quiz, con bytes DIRECTOS ======================
    # OJO: el $00 de 0x4AEE1 es el TERMINADOR de la tecnica [13]. En la ROM
    # japonesa el terminador esta en 0x4AEE5, pegado al rotulo; en la nuestra
    # «Parapunte» es mas corto y el $00 quedo en 0x4AEE1, dejando 4 bytes
    # libres delante del rotulo. Si se rellenan con $A0 el motor de tecnicas
    # se come el rotulo entero. Se respeta el $00 y se rellena DESDE 0x4AEE2.
    assert rom[0x4AEE1] == 0x00, 'falta el terminador de la tecnica [13]'
    r = enc(ROTULO)
    hueco_rot = ZONA_INI - ROTULO_QUIZ
    assert len(r) <= hueco_rot
    rom[ROTULO_QUIZ:ZONA_INI] = r + bytes([RELLENO]) * (hueco_rot - len(r))
    rom[0x4AEE2:ROTULO_QUIZ] = bytes([RELLENO]) * (ROTULO_QUIZ - 0x4AEE2)
    assert rom[0x4AEE1] == 0x00, 'se perdio el terminador'

    bloques = []
    for _n, l1, l2, _o1, _o2, _o3, _jp in QUIZ:
        assert len(l1) <= VISIBLES and len(l2) <= VISIBLES
        bloques.append(enc(l1) + bytes([RELLENO]) * (COLS_PREGUNTA - len(l1)) +
                       bytes([SALTO]) +
                       enc(l2) + bytes([RELLENO]) * (COLS_PREGUNTA - len(l2)))
    for _n, _l1, _l2, o1, o2, o3, _jp in QUIZ:
        resp = b''
        for op in (o1, o2, o3):
            assert len(op) <= UTILES, '«%s» son %d' % (op, len(op))
            resp += (bytes([RELLENO]) + enc(op) +
                     bytes([RELLENO]) * (UTILES - len(op)))
        bloques.append(resp)

    total = sum(len(b) for b in bloques)
    assert total <= ZONA_FIN - ZONA_INI, 'el quiz ocupa %d' % total

    punteros = []
    p = ZONA_INI
    for b in bloques:
        punteros.append(p)
        rom[p:p + len(b)] = b
        p += len(b)
    rom[p:ZONA_FIN] = bytes([RELLENO]) * (ZONA_FIN - p)

    for i, off in enumerate(punteros):
        cpu = CPU_BASE + off - ROM_BASE
        assert 0x6000 <= cpu < 0x8000
        rom[TABLA + 2 * (i + 2)] = cpu & 0xFF
        rom[TABLA + 2 * (i + 2) + 1] = cpu >> 8
    # El rotulo NO se apunta por tabla: $D94A lo carga INMEDIATO
    # (LDA #$E6 / LDA #$6E -> $6EE6). Y los indices 82..95 de esta misma
    # tabla son las 14 TECNICAS, no el rotulo.
    # En la v324/v325 escribi el rotulo en el indice 95 y con eso machaque
    # la tecnica [13]. Lo caza el assert de relectura de tecnicas.
    assert rom[TABLA + 2 * 95] | rom[TABLA + 2 * 95 + 1] << 8 == 0x6ED8, \
        'el indice 95 debe seguir siendo la tecnica [13]'

    # ============ 3. las frases del cierre ==============================
    # restaurar el bloque limpiador que rompi en la v327
    a, b = LIMPIADOR
    rom[a:b] = bytes([0x20]) * (b - a)

    for a, b, lineas in CIERRE:
        hueco = b - a
        d = b''
        for l in lineas:
            assert len(l) <= VISIBLES, '«%s» son %d columnas' % (l, len(l))
            d += enc(l) + bytes([RELLENO]) * (COLS_PREGUNTA - len(l))
        assert len(d) <= hueco, '%s ocupa %d y hay %d' % (lineas, len(d), hueco)
        rom[a:b] = d + bytes([RELLENO]) * (hueco - len(d))

    # el premio: «¡Bien hecho, / Momotaro!» + $80, y «Te concedo » + tecnica
    a, b, lineas = PREMIO1
    d = b''
    for l in lineas:
        assert len(l) <= VISIBLES
        d += enc(l) + bytes([RELLENO]) * (COLS_PREGUNTA - len(l))
    assert len(d) <= b - a, 'premio1 ocupa %d y hay %d' % (len(d), b - a)
    rom[a:b] = d + bytes([RELLENO]) * (b - a - len(d))

    for a, b, txt in (PREMIO2, PREMIO3):
        d = enc(txt)
        assert len(d) <= b - a, '«%s» ocupa %d y hay %d' % (txt, len(d), b - a)
        rom[a:b] = d + bytes([RELLENO]) * (b - a - len(d))
        rom[b] = FINFF

    # ============ VERIFICACION ==========================================
    def lee(idx):
        cpu = rom[TABLA + 2 * idx] | rom[TABLA + 2 * idx + 1] << 8
        return ROM_BASE + cpu - CPU_BASE

    # cero alias en TODA la zona reescrita
    assert rom[LIMPIADOR[0]:LIMPIADOR[1]] == bytes([0x20]) * 32, \
        'el bloque limpiador $6D56 no son 32 espacios'
    for a, b, nom in ((ROTULO_QUIZ, ZONA_FIN, 'quiz'),
                      (0x4AD76, 0x4AE0A, 'cierre')):
        malos = [i for i in range(a, b) if rom[i] in (0x5B, 0x5D, 0x5E, 0x5C)]
        assert not malos, 'quedan alias en %s: %s' % (
            nom, ['%06X' % x for x in malos[:8]])

    for i, (_n, l1, l2, _o1, _o2, _o3, _jp) in enumerate(QUIZ):
        a = lee(i + 2)
        d = rom[a:a + 33]
        assert d[COLS_PREGUNTA] == SALTO, 'P%d sin $80' % (i + 1)
        g1 = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                     for x in d[:COLS_PREGUNTA]).rstrip()
        g2 = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                     for x in d[COLS_PREGUNTA + 1:]).rstrip()
        assert g1 == l1, 'P%d L1 «%s» != «%s»' % (i + 1, g1, l1)
        assert g2 == l2, 'P%d L2 «%s» != «%s»' % (i + 1, g2, l2)
        # toda pregunta que abre ¿ debe cerrar ?
        junta = l1 + ' ' + l2
        assert junta.count('¿') == junta.count('?'), \
            'P%d: %d «¿» y %d «?»' % (i + 1, junta.count('¿'), junta.count('?'))

    for i, (_n, _l1, _l2, o1, o2, o3, _jp) in enumerate(QUIZ):
        a = lee(i + 42)
        for k, op in enumerate((o1, o2, o3)):
            cel = rom[a + k * 8:a + (k + 1) * 8]
            assert cel[0] == RELLENO, 'P%d op%d sin sangria' % (i + 1, k + 1)
            g = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                        for x in cel).strip()
            assert g == op, 'P%d op%d «%s» != «%s»' % (i + 1, k + 1, g, op)

    # las respuestas correctas, intactas
    corr = rom[0x11CD0:0x11CD0 + 40]
    assert list(corr) == list(original[0x11CD0:0x11CD0 + 40])
    assert all(c < 3 for c in corr)

    # las 14 tecnicas de la v326, intactas y bien apuntadas
    esperados = ['Vuelo', 'Salto', 'Rodar', 'Giro', 'Bomba', 'Ola', 'Parapunte',
                 '+Vuelo', '+Salto', '+Rodar', '+Giro', '+Bomba', '+Ola',
                 'Parapunte']
    for i, nombre in enumerate(esperados):
        cpu = rom[0x118BC + 2 * i] | rom[0x118BC + 2 * i + 1] << 8
        o = ROM_BASE + cpu - CPU_BASE
        e = o
        while rom[e] not in (0x00, 0x80):
            e += 1
        leido = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                        for x in rom[o:e]).strip()
        assert leido == nombre, 'tecnica [%d] es «%s», esperaba «%s»' % (
            i, leido, nombre)

    # la frase del premio, montada como la monta $D5F6
    def sigue(cpu, hasta=(0x00, 0x80, 0xFF)):
        o = ROM_BASE + cpu - CPU_BASE
        e = o
        while rom[e] not in hasta:
            e += 1
        return ''.join(rv.get(x, '') for x in rom[o:e] if x != RELLENO)

    frase = sigue(0x6DE2) + 'Vuelo' + sigue(0x6DF5)
    assert 'Bien hecho' in frase and 'Vuelo' in frase, frase

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  1. quiz reescrito con BYTES DIRECTOS: cero alias, adios al ©')
    print('  2. 40 preguntas revisadas (13, 19, 31, 36 reformuladas)')
    print('  3. cierre del quiz traducido:')
    for _a, _b, lineas in CIERRE:
        print('       %s' % ' / '.join('|%s|' % x for x in lineas))
    print('       %s + «<TECNICA>»' % ' / '.join('|%s|' % x for x in PREMIO1[2]))
    print('       «%s» + <TECNICA>' % PREMIO2[2])


if __name__ == '__main__':
    main()
