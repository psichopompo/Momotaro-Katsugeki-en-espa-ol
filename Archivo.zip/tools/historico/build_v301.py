#!/usr/bin/env python3
"""v301 = v300 con la p y la q arregladas.

David, sobre la v300:
  «La p esta alineada ahora, pero por arriba parece mas alta de lo que
   deberia. [...] La q tiene el rabillo 1 px mas abajo [...] la g y la y
   tambien tienen el rabillo mas abajo y se ven bien. Si, volvamos a bajar
   la p, pero la q sigue teniendo un palito arriba.»

Tenia razon en las dos cosas, y la segunda destapa algo importante.

1) LA P VUELVE A SU SITIO. Medido: g, y y q llevan el cuerpo en las filas
   2..5 y el rabillo en 6..7. La p original hacia lo mismo. Subirla la
   dejaba 1 px por encima del resto. Se revierte el cambio de la v300:
       00 F0 88 88 F0 80 80 00  ->  00 00 F0 88 88 F0 80 80

2) EL "PALITO" DE LA Q NO ES UN GLIFO MAL DIBUJADO: es el CONTADOR.
   `0x3DBE8` es a la vez el byte que lee `LDX $5BE8` (ROM 0x105FA, el
   numero de bloques del CG del bocadillo de tienda) y la FILA 0 del
   glifo 177, que es la q. Al ponerlo a $18 para arreglar las tiendas,
   ese $18 se dibuja como `...##...` encima de la q.

   Arreglo: MOVER EL CONTADOR a un byte que no sea de nadie.
       0x3DEA7 esta libre ($FF) -- es el final del stream de tienda de la
       japonesa, y despues hay 345 B de relleno hasta el fin del banco.
       logico $5EA7.
       0x105FA  AE E8 5B  (LDX $5BE8)  ->  AE A7 5E  (LDX $5EA7)
   Verificado que `$5BE8` tiene UN SOLO lector en toda la ROM.

   Con eso la fila 0 de la q vuelve a $00 y las tiendas siguen leyendo 24.
"""
import hashlib, zlib, sys

SRC = 'roms/momotaro_es_v300.pce'
DST = 'roms/momotaro_es_v301.pce'

BASE  = 0x3D660
P     = BASE + 176 * 8      # 0x3DBE0  la p
Q     = BASE + 177 * 8      # 0x3DBE8  la q  (fila 0 = el contador viejo)
LDX   = 0x105FA             # LDX $5BE8
NUEVO = 0x3DEA7             # nuevo contador, logico $5EA7

rom  = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)

assert len(rom) == 512 * 1024
assert hashlib.md5(orig).hexdigest() == 'cf332e143a329605bbc1c94109cb27a6', 'la v300 no es la esperada'

# --- 1. la p vuelve a bajar ------------------------------------------------
SUBIDA = bytes([0x00, 0xF0, 0x88, 0x88, 0xF0, 0x80, 0x80, 0x00])
ORIGINAL = bytes([0x00, 0x00, 0xF0, 0x88, 0x88, 0xF0, 0x80, 0x80])
assert rom[P:P + 8] == SUBIDA, 'la p no esta como la dejo la v300'
rom[P:P + 8] = ORIGINAL

# --- 2. mover el contador para liberar la fila 0 de la q -------------------
assert rom[LDX:LDX + 3] == bytes([0xAE, 0xE8, 0x5B]), 'no es LDX $5BE8'
assert rom[Q] == 0x18, 'la fila 0 de la q no lleva el contador'
assert rom[NUEVO] == 0xFF, 'el destino del contador no esta libre'
assert all(b == 0xFF for b in rom[NUEVO:0x3E000]), 'la cola no es relleno'

rom[NUEVO] = 0x18                     # el contador, en su sitio nuevo
rom[LDX:LDX + 3] = bytes([0xAE, 0xA7, 0x5E])   # LDX $5EA7
rom[Q] = 0x00                         # la q recupera su fila 0 en blanco

# --- lo que no se puede tocar ----------------------------------------------
permitido = set(range(P, P + 8)) | {Q, NUEVO} | set(range(LDX, LDX + 3))
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and i not in permitido]
assert not fuera, 'cambios fuera de zona: %s' % [hex(x) for x in fuera][:10]

# el stream del CG de tienda no se ha tocado
assert rom[0x3DBE9:0x3DEA7] == orig[0x3DBE9:0x3DEA7], 'stream tocado'
# las cinco tablas de indices de glifo, intactas (norma 267)
for nom, o, n in (('f0', 0x41CF3, 64), ('f1', 0x41CB3, 64), ('parrilla', 0x1BBBA, 64),
                  ('Jizo', 0x16AD6, 64), ('canto GO', 0x1F7B6, 128)):
    assert rom[o:o + n] == orig[o:o + n], 'tabla %s tocada' % nom
# la (c) del titulo sigue puesta
jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
assert rom[0x04100:0x04110] == jp[0x04100:0x04110], 'la (c) se ha perdido'

open(DST, 'wb').write(rom)

# --- relectura como hace el motor -----------------------------------------
v = open(DST, 'rb').read()
sys.path.insert(0, 'tools')
from descomp_cg2 import bloque, F

lo, hi = v[LDX + 1], v[LDX + 2]
dirlog = (hi << 8) | lo
off = 0x3C000 + dirlog - 0x4000
n = v[off]
print('LDX $%04X -> ROM %#07x = %d bloques' % (dirlog, off, n))
assert n == 24, 'el contador ya no lee 24'
f = F(v, 0x3DBE9)
[bloque(f) for _ in range(n)]
assert 0x0EC + n - 1 == 0x103 < 0x1B0, 'pisa el HUD'
print('CG tienda: 24 celdas, $0EC..$103  (HUD $1B0 a salvo)')

def filas(g):
    o = BASE + g * 8
    return [r for r in range(8) if v[o + r]]
print('p (176): filas %s' % filas(176))
print('q (177): filas %s' % filas(177))
print('g (167): filas %s' % filas(167))
print('y (185): filas %s' % filas(185))
assert filas(176) == [2, 3, 4, 5, 6, 7], 'la p no ha vuelto a su sitio'
assert filas(177) == [2, 3, 4, 5, 6, 7], 'la q sigue con el palito'
assert filas(176) == filas(177) == filas(167), 'p, q y g no estan alineadas'

b = bytes(v)
print(DST)
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xffffffff))
