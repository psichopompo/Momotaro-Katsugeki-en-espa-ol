#!/usr/bin/env python3
"""
build_v271.py - el menu RUN DE VERDAD: banco $0C, no banco $21.

POR QUE LA v270 NO CAMBIO NADA EN PANTALLA
==========================================
David: *«No, no se ha traducido nada.»* Y tenia razon.

En la v270 traduje `ﾄﾞｳｸﾞ ﾎｼｲ` (0x436F9) y `ｼﾞｭﾂ ﾎｼｲ` (0x4360C) del banco
$21. Encajaban con los nombres que dio David (dougu, jutsu) y di por hecho
que eran esas. **No lo eran**: llevan `ﾎｼｲ` (*hoshii*, «quiero») al final,
o sea que son cadenas de dialogo, no las etiquetas del menu.

Las etiquetas reales viven en el **banco $0C** (ROM 0x18000-0x1A000), que
se mapea en **$C000-$DFFF** — la misma ventana que el banco $0B del
password (`0x16A73` = `$CA73`, que llevamos usando toda la sesion).

Error de metodo: confundir «esto coincide con lo que busco» con «esto es lo
que busco». La confirmacion tenia que venir de seguir el codigo, no del
parecido del texto.

Y ademas le di a David un breakpoint en `$9A65` que nunca podia saltar,
porque calcule la direccion CPU suponiendo que el banco $0C se mapea en
$8000. La direccion buena es `$DA65`. Tercera vez que doy por supuesta una
ventana MPR sin comprobarla (antes: $DE69 y 0x4379D). Norma 232.

LO QUE HAY EN EL BANCO $0C, MEDIDO
==================================
```
tabla 0x197F2 (menu principal)
  [0] $D7FA -> 0x197FA  7 B  ﾄﾞｳｸﾞ        dougu
  [1] $D801 -> 0x19801  6 B  ｼﾞｭﾂ         jutsu
  [2] $D807 -> 0x19807  9 B  ﾊﾟｽﾜｰﾄﾞ      password   NO SE TOCA
  [3] $D810 -> 0x19810  9 B  ﾃﾞﾊﾞｯｸﾞ      debug      NO SE TOCA

tabla 0x19A61 (mensajes de error)
  [0] $DA65 -> 0x19A65 10 B  ﾀﾍﾞﾗﾚﾏｾﾝ     taberaremasen
  [1] $DA6F -> 0x19A6F  8 B  ﾂｶｴﾏｾﾝ       tsukaemasen
```

Password y debug se dejan en japones por indicacion de David: *«ni password
ni debug aparecen durante el juego.»*

Otras tres cadenas del mismo banco NO tienen tabla: el codigo carga su
direccion con **LDA inmediato**, verificado desensamblando:

```
0x199BB  LDA #$CD / STA $BF / LDA #$D9 / STA $C0   -> $D9CD  ﾜｻﾞﾉﾓﾓｶﾞﾅｲ
0x199C4  LDA #$D9 / STA $BF / LDA #$D9 / STA $C0   -> $D9D9  ﾂｶｴﾏｾﾝ
0x199EF  LDA #$F8 / STA $BF / LDA #$D9 / STA $C0   -> $D9F8  ﾃﾞｷﾏｾﾝ
```

Para reubicarlas hay que tocar los **operandos inmediatos**, no una tabla.
Es un puntero igual, solo que partido en dos instrucciones.

EL PRESUPUESTO
==============
Huecos de $FF al final del banco $0C, identicos en la ROM virgen:
```
0x19BF9  18 B ($DBF9)      0x19C50  10 B ($DC50)
0x19C1F  12 B ($DC1F)      0x19FAF  81 B ($DFAF)
                                    ------
                                     121 B
```

Ninguna cadena nueva cabe en su hueco original, asi que **todas se
reubican** y se repuntan. Con 121 B libres sobra de largo.

LOS TEXTOS
==========
```
ﾄﾞｳｸﾞ         -> «Objetos»        9 B
ｼﾞｭﾂ          -> «Poderes»        9 B
ﾀﾍﾞﾗﾚﾏｾﾝ      -> «No se come»    12 B
ﾂｶｴﾏｾﾝ (x2)   -> «No se puede»   13 B
ﾃﾞｷﾏｾﾝ        -> «No se puede»   13 B  (comparten cadena)
ﾜｻﾞﾉﾓﾓｶﾞﾅｲ    -> «Faltan momos»  15 B
```

Las dos copias de `ﾂｶｴﾏｾﾝ` y el `ﾃﾞｷﾏｾﾝ` apuntan a la MISMA cadena nueva:
tres punteros, un solo texto. Ahorra 26 B.

Uso:  python3 tools/build_v271.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import encode, CHAR_TO_CODE          # noqa: E402

BASE = 'roms/momotaro_es_v270.pce'
SALIDA = 'roms/momotaro_es_v271.pce'
IPS = 'parches/momotaro_v271.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'bcf5cdb328f91c3cf30bdc1b91be70a7'

BANCO_INI, BANCO_FIN, CPU_INI = 0x18000, 0x1A000, 0xC000

# --- textos nuevos ----------------------------------------------------
TEXTOS = {
    'objetos': 'Objetos',
    'poderes': 'Poderes',
    'nocome': 'No se come',
    'nopuede': 'No se puede',
    'faltan': 'Faltan momos',
}

# --- punteros de TABLA: (offset_tabla, cadena_vieja, hueco, clave) ----
TABLAS = [
    (0x197F2, 0x197FA, 7, 'objetos'),      # dougu
    (0x197F4, 0x19801, 6, 'poderes'),      # jutsu
    (0x19A61, 0x19A65, 10, 'nocome'),      # taberaremasen
    (0x19A63, 0x19A6F, 8, 'nopuede'),      # tsukaemasen
]

# --- punteros INMEDIATOS: (off_lo, off_hi, cadena_vieja, hueco, clave)
# el codigo hace LDA #lo / STA $BF / LDA #hi / STA $C0
INMEDIATOS = [
    (0x199BC, 0x199C0, 0x199CD, 12, 'faltan'),    # waza no momo ga nai
    (0x199C5, 0x199C9, 0x199D9, 8, 'nopuede'),    # tsukaemasen (2a copia)
    (0x199F0, 0x199F4, 0x199F8, 8, 'nopuede'),    # dekimasen
]

# --- huecos de $FF, verificados identicos en la virgen ----------------
HUECOS = [
    (0x19BF9, 0x19C0B),      # 18 B
    (0x19C1F, 0x19C2B),      # 12 B
    (0x19C50, 0x19C5A),      # 10 B
    (0x19FAF, 0x1A000),      # 81 B
]


def cpu(off):
    return CPU_INI + (off - BANCO_INI)


def cadena(txt):
    return bytes([0x01]) + encode(txt) + bytes([0x00])


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v270'
    print('base %s  OK' % BASE)
    inv = {v: k for k, v in CHAR_TO_CODE.items()}

    # ==================================================================
    # 1. verificar TODO antes de escribir
    # ==================================================================
    print('\n--- punteros de tabla, comprobados contra la ROM')
    for tabla, off_cad, hueco, clave in TABLAS:
        w = rom[tabla] | (rom[tabla + 1] << 8)
        assert w == cpu(off_cad), \
            'la tabla 0x%05X no apunta a 0x%05X (apunta a $%04X)' \
            % (tabla, off_cad, w)
        f = off_cad + 1
        while rom[f] not in (0x00, 0xFF):
            f += 1
        assert f + 1 - off_cad == hueco, \
            'el hueco de 0x%05X mide %d, no %d' % (off_cad, f + 1 - off_cad,
                                                   hueco)
        print('    0x%05X -> $%04X (0x%05X, %d B) -> %r'
              % (tabla, w, off_cad, hueco, TEXTOS[clave]))

    print('\n--- punteros inmediatos (LDA #lo / LDA #hi), desensamblados')
    for off_lo, off_hi, off_cad, hueco, clave in INMEDIATOS:
        assert rom[off_lo - 1] == 0xA9, \
            'en 0x%05X no hay un LDA inmediato' % (off_lo - 1)
        assert rom[off_hi - 1] == 0xA9, \
            'en 0x%05X no hay un LDA inmediato' % (off_hi - 1)
        w = rom[off_lo] | (rom[off_hi] << 8)
        assert w == cpu(off_cad), \
            'el par inmediato 0x%05X/0x%05X da $%04X, no $%04X' \
            % (off_lo, off_hi, w, cpu(off_cad))
        print('    LDA #$%02X / LDA #$%02X = $%04X (0x%05X, %d B) -> %r'
              % (rom[off_lo], rom[off_hi], w, off_cad, hueco, TEXTOS[clave]))

    print('\n--- huecos, comprobados a $FF tambien en la virgen')
    for a, b in HUECOS:
        assert all(x == 0xFF for x in rom[a:b]), \
            'el hueco 0x%05X no esta a $FF' % a
        assert all(x == 0xFF for x in orig[a:b]), \
            'el hueco 0x%05X no esta a $FF en la virgen' % a
        print('    0x%05X-0x%05X  %2d B  ($%04X)' % (a, b, b - a, cpu(a)))

    # ==================================================================
    # 2. colocar las cadenas (una sola vez cada texto)
    # ==================================================================
    codificadas = {k: cadena(t) for k, t in TEXTOS.items()}
    necesario = sum(len(c) for c in codificadas.values())
    libre = sum(b - a for a, b in HUECOS)
    print('\n--- %d cadenas, %d B; hueco libre %d B'
          % (len(codificadas), necesario, libre))
    assert necesario <= libre, 'no cabe: %d > %d' % (necesario, libre)

    # backtracking, como en la v269
    orden = sorted(codificadas.items(), key=lambda kv: -len(kv[1]))
    tam = [b - a for a, b in HUECOS]

    def busca(i, libres, puestos):
        if i == len(orden):
            return puestos
        clave, cod = orden[i]
        vistos = set()
        for k, lib in enumerate(libres):
            if lib >= len(cod) and lib not in vistos:
                vistos.add(lib)
                l2 = list(libres)
                l2[k] -= len(cod)
                r = busca(i + 1, l2, puestos + [(k, clave, cod)])
                if r is not None:
                    return r
        return None

    plan = busca(0, tam, [])
    assert plan is not None, 'no existe empaquetado'

    cursor = [a for a, _ in HUECOS]
    destino = {}
    for k, clave, cod in plan:
        destino[clave] = cursor[k]
        rom[cursor[k]:cursor[k] + len(cod)] = cod
        cursor[k] += len(cod)
    for k, (a, b) in enumerate(HUECOS):
        assert cursor[k] <= b, 'la zona 0x%05X se ha desbordado' % a

    print('\n--- colocacion')
    for clave in TEXTOS:
        o = destino[clave]
        print('    %-13s -> ROM %05X ($%04X)  %2d B'
              % (TEXTOS[clave], o, cpu(o), len(codificadas[clave])))

    # ==================================================================
    # 3. repuntar
    # ==================================================================
    print('\n--- repunte')
    for tabla, off_cad, hueco, clave in TABLAS:
        w = cpu(destino[clave])
        rom[tabla] = w & 0xFF
        rom[tabla + 1] = w >> 8
        rom[off_cad:off_cad + hueco] = bytes(hueco)      # borra el japones
        print('    tabla 0x%05X -> $%04X  (%r)' % (tabla, w, TEXTOS[clave]))

    for off_lo, off_hi, off_cad, hueco, clave in INMEDIATOS:
        w = cpu(destino[clave])
        rom[off_lo] = w & 0xFF
        rom[off_hi] = w >> 8
        if rom[off_cad] != 0x00:                          # solo la 1a vez
            rom[off_cad:off_cad + hueco] = bytes(hueco)
        print('    LDA #$%02X/#$%02X en 0x%05X/0x%05X -> $%04X  (%r)'
              % (w & 0xFF, w >> 8, off_lo, off_hi, w, TEXTOS[clave]))

    # ==================================================================
    # 4. relectura: se sigue cada puntero como hace el juego
    # ==================================================================
    print('\n--- releido desde la ROM escrita')

    def lee(w):
        o = BANCO_INI + (w - CPU_INI)
        assert rom[o] == 0x01, 'la cadena en $%04X no empieza por $01' % w
        f = o + 1
        while rom[f] != 0x00:
            f += 1
        return ''.join(inv.get(x, '[%02X]' % x) for x in rom[o + 1:f])

    for tabla, _, _, clave in TABLAS:
        w = rom[tabla] | (rom[tabla + 1] << 8)
        got = lee(w)
        assert got == TEXTOS[clave], 'leido %r' % got
        print('    tabla 0x%05X -> $%04X -> %r  OK' % (tabla, w, got))
    for off_lo, off_hi, _, _, clave in INMEDIATOS:
        w = rom[off_lo] | (rom[off_hi] << 8)
        got = lee(w)
        assert got == TEXTOS[clave], 'leido %r' % got
        print('    inmediato 0x%05X -> $%04X -> %r  OK' % (off_lo, w, got))

    # password y debug intactos, y siguen apuntando a su japones
    for tabla, off_cad, nom in ((0x197F6, 0x19807, 'password'),
                                (0x197F8, 0x19810, 'debug')):
        w = rom[tabla] | (rom[tabla + 1] << 8)
        assert w == cpu(off_cad), '%s ha cambiado de sitio' % nom
        assert bytes(rom[off_cad:off_cad + 9]) == base[off_cad:off_cad + 9], \
            '%s ha sido modificado' % nom
        print('    %-8s $%04X intacto (en japones, por indicacion de David)'
              % (nom, w))

    # ==================================================================
    # 5. zonas intactas
    # ==================================================================
    intactas = [
        ('menu RUN del banco $21 (v269)', 0x431AC, 0x431EB),
        ('«Nada» de las aldeas (v270)', 0x42ED9, 0x42EE0),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla de glifos', 0x43F9B, 0x44000),
        ('bucle del canto', 0x16A73, 0x16AD6),
        ('password $DE69', 0x17E69, 0x17E78),
        ('codigo del banco $0C hasta el menu', 0x18000, 0x197F2),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v270' % len(dif))

    open(SALIDA, 'wb').write(d)

    # --- IPS con round-trip ---
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
