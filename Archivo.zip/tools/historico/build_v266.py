#!/usr/bin/env python3
"""
build_v266.py - el password en pagina limpia, DE VERDAD. Y los verbos.

POR QUE LA v265 NO FUNCIONO
===========================
David: *«Lo del password no se ha solucionado, sigue igual.»* Y su captura
lo confirma: la pregunta sigue arriba.

**Mi fallo:** el bocadillo tiene 4 filas de texto, pero el buffer solo tiene
32 celdas = 2 filas. Cual de las dos mitades se pinta lo decide `calc_alto`
(`$9FE0`) a partir de `$3657`:

```
$3657 = 1 o 2   ->  (x-1)&2 = 0  ->  filas A (lineas 1 y 2)   la PREGUNTA
$3657 = 3, 4, 0 ->  (x-1)&2 = 2  ->  filas B (lineas 3 y 4)   el PASSWORD
```

Mi rutina hacia `JSR $9C29` + `JSR $9B7C` **sin tocar `$3657`**, asi que
borraba solo la mitad que estuviera seleccionada en ese momento — y al
entrar al canto `$3657` conserva el valor que dejo la pregunta. Borraba las
filas del password, no las de la pregunta. De ahi que no se notara nada.

LA CORRECCION
=============
Hay que borrar **las dos mitades**: poner `$3657=1`, volcar el buffer
vacio, poner `$3657=3` y volcar otra vez.

En version literal son 28 bytes y el hueco de `$CABD` tiene 25. Se compacta
con un bucle de dos vueltas (1 -> 3):

```
$CABD  JSR $9C29        buffer a cero, UNA vez
       LDA #$01
bucle  STA $3657
       PHA
       JSR $9B7C        vuelca el buffer vacio -> BORRA esa mitad
       PLA
       CLC / ADC #$02   1 -> 3
       CMP #$05
       BCC bucle
       STZ $3657        deja la linea a 0 para el bucle del canto
       RTS
```

24 bytes. El buffer sigue a cero entre las dos vueltas porque `$9B7C` solo
lee, no escribe en el.

LOS VERBOS DEL MENU RUN
=======================
David: *«no me gusta ninguno y tampoco quiero abreviaturas. Quiero los
verbos en infinitivo y las palabras completas.»*

Medido hueco por hueco (`hueco = del $01 al $00 inclusive`, letras = hueco-2):

```
offset    japones      caben   infinitivo   cabe?
0x431B4   ﾂｶｴﾏｾﾝ        6      -            no ("No se puede usar")
0x431BC   ﾀﾍﾞﾙ          4      Comer  (5)   NO por 1
0x431C2   ﾂｶｳ           3      Usar   (4)   NO por 1
0x431C7   ｽﾃﾙ           3      Tirar  (5)   NO por 2
0x431D4   ｵﾄﾓｶﾞｲﾅｲ      8      -            no ("No hay aliado")
0x431DE   ｲﾇ            2      Perro  (5)   NO por 3
0x431E2   ｷｼﾞ           3      Faisan (6)   NO por 3
0x431E7   ｻﾙ            2      Mono   (4)   NO por 2
0x43736   ﾂｶｳ           3      Usar   (4)   NO por 1
0x4373B   ﾔﾒﾙ           3      Volver (6)   NO por 3
```

**Ninguno cabe en su hueco**, y no hay tabla de punteros que permita
moverlos (verificado: nadie lee `$B1AC` con direccionamiento indexado, o sea
que son las cadenas en si, no punteros).

Por eso esta version **NO toca los verbos**. Hacerlo exige reubicar el
bloque entero y repuntar los llamantes, que es justo el tipo de cambio que
rompio las versiones v254 y v259. Va aparte, con su propia medicion.

Uso:  python3 tools/build_v266.py
"""
import hashlib
import zlib
import subprocess

BASE = 'roms/momotaro_es_v264.pce'          # se rehace desde la v264
SALIDA = 'roms/momotaro_es_v266.pce'
IPS = 'parches/momotaro_v266.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '695965973173f0a960eb3c0095f8cef0'

BUCLE = 0x16A73                 # $CA73, JSR $9C29
NOPS = 0x16ABD                  # $CABD, 25 NOPs
FUENTE = 0x3D660


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v264'
    print('base %s  OK  (se rehace la v265 entera)' % BASE)

    assert all(b == 0 for b in rom[FUENTE:FUENTE + 8]), \
        'el glifo 0 no es todo ceros'
    n = 0
    while rom[NOPS + n] == 0xEA:
        n += 1
    print('hueco en $CABD: %d NOPs' % n)

    # --- la rutina, ensamblada con el salto calculado -----------------
    trozos = [
        [0x20, 0x29, 0x9C],          # JSR $9C29   buffer a cero
        [0xA9, 0x01],                # LDA #$01
        ['bucle'],                   # etiqueta
        [0x8D, 0x57, 0x36],          # STA $3657
        [0x48],                      # PHA
        [0x20, 0x7C, 0x9B],          # JSR $9B7C   vuelca vacio -> borra
        [0x68],                      # PLA
        [0x18],                      # CLC
        [0x69, 0x02],                # ADC #$02    1 -> 3
        [0xC9, 0x05],                # CMP #$05
        ['BCC', 'bucle'],
        [0x9C, 0x57, 0x36],          # STZ $3657
        [0x60],                      # RTS
    ]
    pos = {}
    off = 0
    for t in trozos:
        if t[0] == 'bucle':
            pos['bucle'] = off
        elif t[0] == 'BCC':
            off += 2
        else:
            off += len(t)
    rut = bytearray()
    for t in trozos:
        if t[0] == 'bucle':
            continue
        if t[0] == 'BCC':
            rel = pos[t[1]] - (len(rut) + 2)
            assert -128 <= rel <= 127, 'salto fuera de rango'
            rut += bytes([0x90, rel & 0xFF])
        else:
            rut += bytes(t)
    assert len(rut) <= n, 'no cabe: %d > %d' % (len(rut), n)
    print('\nrutina de %d B (hueco %d)' % (len(rut), n))

    # el salto, comprobado (se localiza el BCC, no se supone su indice)
    i_bcc = rut.index(0x90)
    assert rut[i_bcc] == 0x90
    destino = i_bcc + 2 + (rut[i_bcc + 1] - 256 if rut[i_bcc + 1] > 127
                           else rut[i_bcc + 1])
    assert destino == pos['bucle'], \
        'el BCC salta a +%d y el bucle esta en +%d' % (destino, pos['bucle'])
    print('   BCC en +%d -> +%d (el bucle): OK' % (i_bcc, destino))

    esp = bytes([0x20, 0x29, 0x9C])
    assert bytes(rom[BUCLE:BUCLE + 3]) == esp, 'en $CA73 no esta el JSR $9C29'
    rom[NOPS:NOPS + len(rut)] = rut
    addr = 0xC000 + (NOPS - 0x16000)
    rom[BUCLE:BUCLE + 3] = bytes([0x20, addr & 0xFF, addr >> 8])
    print('   $CA73  JSR $9C29 -> JSR $%04X' % addr)

    # --- simulacion del efecto ----------------------------------------
    print('\n--- que borra, simulado')
    for v in (1, 3):
        q = (v - 1) & 2
        print('   $3657=%d -> calc_alto=%d -> filas %s'
              % (v, q, 'A (lineas 1-2, LA PREGUNTA)' if q == 0
                 else 'B (lineas 3-4)'))
    print('   -> se borran LAS CUATRO lineas')

    # --- verificacion --------------------------------------------------
    tmp = '/tmp/_v266.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM')
    for o, nb, carga, nom in [(BUCLE, 6, 0xCA73, 'entrada del bucle'),
                              (NOPS, len(rut), addr, 'borrado de pagina')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % o,
                            str(nb), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    assert bytes(rom[BUCLE + 3:NOPS]) == base[BUCLE + 3:NOPS], \
        'se ha tocado el cuerpo del bucle'
    intactas = [
        ('cuerpo del bucle', BUCLE + 3, NOPS),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla del canto', 0x16AD6, 0x16B16),
        ('cadena Capa', 0x43140, 0x43148),
        ('verbos del menu', 0x431B4, 0x431EB),
        ('parrilla del password', 0x1BBBA, 0x1BC00),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v264' % len(dif))
    assert all(BUCLE <= i < BUCLE + 3 or NOPS <= i < NOPS + len(rut)
               for i in dif), 'cambios fuera de sitio'

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
