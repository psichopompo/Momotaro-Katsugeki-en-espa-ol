#!/usr/bin/env python3
"""v298 = v296 + arreglo COMPLETO de las tiendas + la (c) del titulo.

Tres cambios, todos medidos (ver docs/HALLAZGO_HUD_tiendas.md):

1) Los 47 glifos 177..223 (el alfabeto latino alto, codigos $B1..$DF) viven
   encima del stream comprimido del CG del bocadillo de TIENDA
   (0x3DBE8..0x3DEA7). Se MUEVEN a los glifos 2..48, que estan libres:
   son katakana del original al que ya no apunta ninguna tabla.

2) Se restaura el stream de tienda 0x3DBE8..0x3DEA7 tal cual de la japonesa,
   contador incluido ($18 = 24 bloques). Con el $00 que habia, el bucle
   'LDX $5BE8 / ... / DEX / BNE' daba 256 vueltas y arrasaba la VRAM de
   $0EC a $1EB, incluido el HUD ($1B0-$1BF).

3) 0x04100: el glifo 16 de la fuente del TITULO (codigo $40) lo habian
   reaprovechado para una 'E' con tilde, pero ese codigo lo usa la cadena
   del copyright. Salia "E1990 HUDSON SOFT". Se restaura el simbolo (c).

Las tablas f0 ($9CF3 = 0x41CF3) y f1 ($9CB3 = 0x41CB3) se repuntan a los
glifos nuevos. Son las UNICAS referencias: verificado barriendo las 128
entradas.
"""
import hashlib, zlib, sys

SRC = 'roms/momotaro_es_v296.pce'
JP  = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v298.pce'

BASE   = 0x3D660          # glifo 0 de la fuente DIALOGO (logico $5660)
F0     = 0x41CF3          # tabla fuente 0, 64 entradas
F1     = 0x41CB3          # tabla fuente 1, 64 entradas
STREAM = (0x3DBE8, 0x3DEA7)   # CG del bocadillo de tienda, en la japonesa
CO     = 0x04100          # glifo 16 de la fuente del titulo = (c)

rom  = bytearray(open(SRC, 'rb').read())
jp   = open(JP, 'rb').read()
orig = bytes(rom)

assert len(rom) == 512 * 1024
assert hashlib.md5(orig).hexdigest() == '781fb22da4b5cba725ca73afc6f6a1bf', 'la v296 no es la esperada'

def off(g):
    return BASE + g * 8

# --- comprobaciones previas ------------------------------------------------
viejos = list(range(177, 224))          # 47 glifos a mover
nuevos = list(range(2, 2 + len(viejos)))  # destino: glifos 2..48

f0 = list(rom[F0:F0 + 64])
f1 = list(rom[F1:F1 + 64])

# los destinos tienen que estar libres (nadie los referencia) y ser katakana jp
for g in nuevos:
    assert g not in f0 and g not in f1, 'el glifo destino %d esta en uso' % g
    o = off(g)
    assert rom[o:o + 8] == jp[o:o + 8], 'el glifo destino %d no es virgen' % g

# los origenes tienen que caer dentro del stream que hay que liberar
for g in viejos:
    o = off(g)
    assert STREAM[0] <= o < STREAM[1] + 8, 'el glifo %d no solapa el stream' % g

# --- 1. copiar los glifos a su nuevo sitio ---------------------------------
dibujos = {g: bytes(rom[off(g):off(g) + 8]) for g in viejos}
for viejo, nuevo in zip(viejos, nuevos):
    rom[off(nuevo):off(nuevo) + 8] = dibujos[viejo]

# --- 2. restaurar el stream de tienda --------------------------------------
rom[STREAM[0]:STREAM[1]] = jp[STREAM[0]:STREAM[1]]
assert rom[0x3DBE8] == 0x18, 'el contador no ha quedado en $18'

# --- 3. repuntar las tablas ------------------------------------------------
mapa = dict(zip(viejos, nuevos))
cambios_tabla = 0
for t in (F0, F1):
    for i in range(64):
        v = rom[t + i]
        if v in mapa:
            rom[t + i] = mapa[v]
            cambios_tabla += 1

# no debe quedar ninguna referencia a los glifos viejos
for t in (F0, F1):
    for i in range(64):
        assert rom[t + i] not in mapa, 'queda una referencia sin repuntar'

# --- 4. la (c) del titulo --------------------------------------------------
rom[CO:CO + 16] = jp[CO:CO + 16]
# los otros dos glifos retocados del titulo siguen siendo NUESTROS
assert rom[0x04240:0x04250] != jp[0x04240:0x04250], 'la T se ha revertido'
assert rom[0x042B0:0x042C0] != jp[0x042B0:0x042C0], 'la O acentuada se ha revertido'

# --- zonas que NO se pueden tocar ------------------------------------------
permitido = set()
for g in nuevos:
    permitido |= set(range(off(g), off(g) + 8))
permitido |= set(range(STREAM[0], STREAM[1]))
permitido |= set(range(F0, F0 + 64)) | set(range(F1, F1 + 64))
permitido |= set(range(CO, CO + 16))
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and i not in permitido]
assert not fuera, 'cambios fuera de zona: %s' % [hex(x) for x in fuera][:20]

# el motor de texto y las tiendas traducidas, intactos
assert rom[0x41B0B:0x41B40] == orig[0x41B0B:0x41B40], 'tocado el lector $9B0B'
assert rom[0x484C0:0x48B7A] == orig[0x484C0:0x48B7A], 'tocados los textos de tienda'

open(DST, 'wb').write(rom)

# --- relectura siguiendo el puntero, como hace el motor --------------------
v = open(DST, 'rb').read()
sys.path.insert(0, 'tools')
from descomp_cg2 import bloque, F

n = v[0x3DBE8]
f = F(v, 0x3DBE9)
cel = [bloque(f) for _ in range(n)]
assert n == 24, 'el contador no lee 24'
assert f.p == 0x3DEA7, 'el stream no acaba donde la japonesa: %#07x' % f.p
assert 0x0EC + n - 1 == 0x103 < 0x1B0, 'sigue pisando el HUD'
print('relectura CG tienda: %d celdas, $0EC..$%03X, fin ROM %#07x  (HUD $1B0 a salvo)'
      % (n, 0x0EC + n - 1, f.p))

# y los glifos movidos se leen bien en su nuevo sitio
for viejo, nuevo in zip(viejos, nuevos):
    assert v[off(nuevo):off(nuevo) + 8] == dibujos[viejo], 'glifo %d mal copiado' % viejo
print('%d glifos movidos (177..223 -> 2..48), %d entradas de tabla repuntadas'
      % (len(viejos), cambios_tabla))

# la cadena del copyright, releida
s = v[0x18E75:0x18E75 + 21]
print('cadena del titulo: %r  (el $40 ya dibuja la (c) japonesa)' % bytes(s))
assert v[CO:CO + 16] == jp[CO:CO + 16]

b = bytes(v)
print(DST)
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xffffffff))
