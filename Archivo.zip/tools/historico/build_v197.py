#!/usr/bin/env python3
"""
build_v197.py - LA CAUSA DE VERDAD de las lineas que faltan.

POR QUE LA v196 NO ARREGLO NADA
-------------------------------
David: «He probado la rom. No ha cambiado nada.»

Tenia razon. Lo que quite en la v196 (el volcado del cargador) era un
volcado inofensivo — pintaba blanco sobre blanco — asi que no cambio el
comportamiento. El fallo estaba en otro sitio y lo tenia delante.

EL FALLO, MEDIDO
----------------
El motor incrementa `$3657` **en `$98A9`, al procesar un `$3B`** (salto de
linea). Y el maquetador mete `$3B` **entre** lineas, no detras de la ultima.

O sea: **la ultima linea de un dialogo nunca incrementa `$3657`**.

Los tres sitios que vuelcan llegan con valores distintos:

```
                        $3657   fila que toca
mitad de pagina ($9ACD)    2         A
fin de pagina   ($98BE)    4         B
fin de dialogo  ($98C9)   L-1        A si L<=2, B si L>=3
```

Con `L=3` el fin de dialogo llega con `$3657 = 2`... **el mismo valor que
la mitad de pagina, que necesita la fila contraria**. Ninguna formula sobre
`$3657` puede acertar en los dos casos: el problema era irresoluble tal como
estaba planteado, y por eso los parches de la v195 y la v196 no bastaron.

De ahi los tres sintomas de David:

- dialogo 7, pagina 2 de 2 lineas: sale solo «manera...»
- dialogo 48, pagina 2 de 2 lineas: sale solo «que es verdad...»
- una pagina de 1 linea aparece abajo en vez de arriba

EL ARREGLO
----------
Igualar los tres casos: que el fin de dialogo **tambien** incremente
`$3657` antes de volcar, como hacen los otros dos. Asi la formula que ya
tiene `calc_alto` acierta siempre:

```
              $3657 al volcar    (x-1)&2   fila
mitad                 2             0       A
fin de pagina         4             2       B
fin de dialogo L=1    1             0       A
               L=2    2             0       A
               L=3    3             2       B
               L=4    4             2       B
```

Verificado para paginas de 1 a 4 lineas y dialogos de 1 a 12.

```
$98C9   JSR $9B7C   ->   JSR $9FD9
$9FD9   INC $3657 / JMP $9B7C        (en el hueco de 4 B... son 6)
```

Como el hueco de `$9FD9` tiene 4 bytes y hacen falta 6, se usa `$9FEB`
(5 B) + el `RTS` compartido: en realidad se resuelve con `INC $3657` en
`$9FEB` y dejando que caiga en `$9FF1`, que ya existe... no. Se usa el
hueco de `$9251` (5 B) con `INC $3657 / JMP $9B7C` = 6 B. Tampoco.

Solucion final: `$98C9 JSR $9B7C` se sustituye por `$98C9 JSR $9FD9`, y en
`$9FD9` van `INC $3657` (3 B) + `JMP $9B7C` (3 B) = 6 B, ocupando
`$9FD9..$9FDE`. El hueco medido va de `$9FD9` a `$9FDC` (4 B de ceros), pero
`$9FDD..$9FDF` tambien esta libre: lo comprueba el constructor.

Uso:  python3 tools/build_v197.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v196.pce'
SALIDA = 'roms/momotaro_es_v197.pce'
IPS = 'parches/momotaro_v197.ips'
MD5_BASE = '174d8797245d6e270781bb5f7fb03d2a'

FIN_DIALOGO = 0x418C9      # $98C9  JSR $9B7C
VOLCAR = 0x41ACB           # los 2 NOP + volcar_y_restaurar
VOLCAR_L = 0x9ACB
VOLCAR_FIN = 0x41ADD       # empieza la tabla del rabillo


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v196 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # 1. comprobar los tres puntos de volcado
    # ------------------------------------------------------------------
    # el INC $3657 solo ocurre al procesar un $3B
    assert bytes(rom[0x418A9:0x418AC]) == bytes([0xEE, 0x57, 0x36]), \
        '$98A9 no es INC $3657'
    # mitad de pagina
    assert bytes(rom[0x41FF1:0x41FFB]) == bytes(
        [0xC9, 0x02, 0xD0, 0x03, 0x20, 0xCD, 0x9A, 0x4C, 0x01, 0x98]), \
        '$9FF1 no es el volcado de mitad de pagina'
    # fin de pagina
    assert bytes(rom[0x418BE:0x418C1]) == bytes([0x4C, 0x7C, 0x9B]), \
        '$98BE no es JMP $9B7C'
    # fin de dialogo
    assert bytes(rom[FIN_DIALOGO:FIN_DIALOGO + 3]) == bytes(
        [0x20, 0x7C, 0x9B]), \
        '$98C9 no es JSR $9B7C sino %s' % bytes(
            rom[FIN_DIALOGO:FIN_DIALOGO + 3]).hex()
    # calc_alto, tal como lo dejo la v195
    assert bytes(rom[0x41FE0:0x41FEB]) == bytes(
        [0xAD, 0x57, 0x36, 0x3A, 0x29, 0x02, 0x18, 0x79, 0xBE, 0x9B, 0x60]), \
        'calc_alto no es ($3657-1)&2'
    print('los tres puntos de volcado verificados:')
    print('  $9FF5  JSR $9ACD   mitad de pagina, llega con $3657=2')
    print('  $98BE  JMP $9B7C   fin de pagina,   llega con $3657=4')
    print('  $98C9  JSR $9B7C   fin de dialogo,  llega con $3657=L-1')
    print('  (la ultima linea no lleva $3B detras, asi que no incrementa)')

    # ------------------------------------------------------------------
    # 2. volcar_y_restaurar gana una SEGUNDA entrada, 3 bytes antes
    # ------------------------------------------------------------------
    # No hay ningun hueco de 6 bytes libre en el banco $20 (el de $9FD9 es
    # una tabla de datos referenciada desde tres bancos, y $9A59 es la cola
    # del bitmap de la flecha, norma 137). Pero volcar_y_restaurar tiene
    # 2 NOP delante y 2 bytes libres detras, asi que cabe desplazandolo.
    esperado_vol = bytes([0xEA, 0xEA,                       # $9ACB
                          0x20, 0x7C, 0x9B,                 # JSR $9B7C
                          0x20, 0x29, 0x9C,                 # JSR $9C29
                          0xA9, 0x24, 0x18, 0x65, 0x20,     # rehace MPR2
                          0x53, 0x04,
                          0x60])                            # RTS
    assert bytes(rom[VOLCAR:VOLCAR + 16]) == esperado_vol, \
        'volcar_y_restaurar no es el esperado: %s' % bytes(
            rom[VOLCAR:VOLCAR + 16]).hex()
    assert bytes(rom[VOLCAR + 16:VOLCAR_FIN]) == bytes([0x18, 0xFF]), \
        'los 2 bytes tras volcar_y_restaurar no son los esperados'
    # nadie salta a $9ADB/$9ADC
    for a in (VOLCAR_L + 16, VOLCAR_L + 17):
        pp = bytes([a & 0xFF, a >> 8])
        for i in range(len(orig) - 2):
            if orig[i] in (0x20, 0x4C) and orig[i + 1:i + 3] == pp:
                raise AssertionError('$%04X referenciado en 0x%05X' % (a, i))

    nuevo_vol = bytes([0xEE, 0x57, 0x36,        # $9ACB  INC $3657   <- entrada B
                       0x20, 0x7C, 0x9B,        # $9ACE  JSR $9B7C   <- entrada A
                       0x20, 0x29, 0x9C,        # $9AD1  JSR $9C29
                       0xA9, 0x24, 0x18, 0x65, 0x20, 0x53, 0x04,
                       0x60])                   # $9ADB  RTS
    assert len(nuevo_vol) == 17, 'mide %d' % len(nuevo_vol)
    assert VOLCAR + len(nuevo_vol) <= VOLCAR_FIN, 'no cabe'
    rom[VOLCAR:VOLCAR + len(nuevo_vol)] = nuevo_vol
    rom[VOLCAR + len(nuevo_vol)] = 0xFF          # el byte que sobra

    ENTRADA_MITAD = VOLCAR_L + 3                 # $9ACE
    print()
    print('  $%04X  INC $3657 / (cae en la de abajo)   <- fin de dialogo'
          % VOLCAR_L)
    print('  $%04X  JSR $9B7C / JSR $9C29 / rehace MPR2 / RTS  <- mitad'
          % ENTRADA_MITAD)

    # el volcado de mitad ($9FF5) apuntaba a $9ACD: ahora a $9ACE
    assert bytes(rom[0x41FF5:0x41FF8]) == bytes([0x20, 0xCD, 0x9A]), \
        'el JSR de $9FF5 no apunta a $9ACD'
    rom[0x41FF6] = ENTRADA_MITAD & 0xFF
    rom[0x41FF7] = ENTRADA_MITAD >> 8
    print('  $9FF5  JSR $9ACD -> JSR $%04X' % ENTRADA_MITAD)

    # el clon tambien llamaba a $9ACD
    assert bytes(rom[0x419B6:0x419B9]) == bytes([0x20, 0xCD, 0x9A]), \
        'el clon no llama a $9ACD'
    rom[0x419B7] = ENTRADA_MITAD & 0xFF
    rom[0x419B8] = ENTRADA_MITAD >> 8
    print('  clon $99B6  JSR $9ACD -> JSR $%04X' % ENTRADA_MITAD)

    # y el fin de dialogo entra por arriba, para que haga el INC
    rom[FIN_DIALOGO + 1] = VOLCAR_L & 0xFF
    rom[FIN_DIALOGO + 2] = VOLCAR_L >> 8
    print('  $98C9  JSR $9B7C -> JSR $%04X   (INC $3657 y luego vuelca)'
          % VOLCAR_L)

    # ------------------------------------------------------------------
    # 4. la tabla de verdad completa
    # ------------------------------------------------------------------
    print()
    print('  caso                   $3657   (x-1)&2   fila   toca')
    filas = []
    for nom, v, toca in (('mitad de pagina', 2, 'A'),
                         ('fin de pagina', 4, 'B'),
                         ('fin dialogo L=1', 1, 'A'),
                         ('fin dialogo L=2', 2, 'A'),
                         ('fin dialogo L=3', 3, 'B'),
                         ('fin dialogo L=4', 4, 'B')):
        f = (v - 1) & 2
        r = 'A' if f == 0 else 'B'
        print('  %-20s   %d       %d        %s      %s   %s'
              % (nom, v, f, r, toca, 'OK' if r == toca else 'MAL'))
        assert r == toca, 'la formula falla en %s' % nom
        filas.append(r)

    # y simulado sobre dialogos completos de 1 a 12 lineas
    for n in range(1, 13):
        l = 0
        for k in range(1, n + 1):
            ultima = (k == n)
            if not ultima:
                l += 1
                if l == 2:
                    assert ((2 - 1) & 2) == 0, 'mitad mal'
                elif l == 4:
                    assert ((4 - 1) & 2) == 2, 'fin de pagina mal'
                    l = 0
        # fin de dialogo: el INC nuevo lo sube a l+1
        v = l + 1
        f = (v - 1) & 2
        # la ultima linea es la numero l+1 de su pagina
        toca = 0 if (l + 1) <= 2 else 2
        assert f == toca, \
            'dialogo de %d lineas: $3657=%d da fila %d y toca %d' % (
                n, v, f >> 1, toca >> 1)
    print('  simulados dialogos de 1 a 12 lineas: correcto')

    # ------------------------------------------------------------------
    intactas = [
        ('guion', 0x48000, 0x4C000),
        ('CG del bocadillo', 0x3D3D4, 0x3D660),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('calc_alto', 0x41FE0, 0x41FEB),
        ('cargador del CG', 0x41AAE, 0x41ACB),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    permitido = set(range(VOLCAR, VOLCAR + 18)) \
        | {FIN_DIALOGO + 1, FIN_DIALOGO + 2, 0x41FF6, 0x41FF7,
           0x419B7, 0x419B8}
    fuera = [i for i in dif if i not in permitido]
    assert not fuera, 'cambios fuera de lo previsto: %s' % [hex(i) for i in fuera]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        o2 = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n2 = raw[p + 3] << 8 | raw[p + 4]
        prueba[o2:o2 + n2] = raw[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  Dialogo 7  pagina 2: "derrote a 1000 ogros / de esta manera..."')
    print('  Dialogo 48 pagina 2: "el autor del juego, / asi que es verdad..."')
    print('  Una pagina de una sola linea, ARRIBA del todo.')


if __name__ == '__main__':
    main()
