#!/usr/bin/env python3
"""
build_v267.py - el password: 3 lineas, una pagina, arriba del todo.

LO QUE FALTABA EN LA v266
=========================
David: *«Primero nos salen las dos primeras lineas, dejando las lineas 1 y 2
de la pagina vacias. Y luego, la tercera linea aparece en una nueva pagina.
Resumen: las dos primeras lineas del password tienen que estar dos lineas
mas arriba, y la tercera linea tiene que estar en esa misma pagina.»*

Dos fallos, los dos medibles:

**1. Empezaba en las filas B.** Mi rutina terminaba con `STZ $3657`, y
`calc_alto` hace `(0-1)&2 = 2` -> filas B (lineas 3-4). Por eso las dos
primeras lineas del canto salian abajo.

**2. Cortaba pagina a las 31 celdas.** `$CAA6 CPX #$1F / BCC` y luego
`$CAAA JMP $9B7C`: vuelca y sale, obligando a pulsar para ver la 3a linea.

LOS DOS ARREGLOS
================

**(a) Dejar `$3657 = 1` al salir del borrado.**
En vez de gastar bytes en un `LDA #$01 / STA $3657` final, se **invierte el
bucle**: empieza en 3 y baja a 1, asi la ultima escritura ya deja el valor
bueno.

```
$CABD  JSR $9C29          buffer a cero
       LDA #$03
bucle  STA $3657
       PHA
       JSR $9B7C          vuelca vacio -> borra esa mitad
       PLA
       SEC / SBC #$02     3 -> 1
       CMP #$01
       BCS bucle
       RTS                y $3657 se queda en 1 = filas A
```

Simulado: toma los valores 3 (borra B) y 1 (borra A), y sale con 1.
21 bytes, cuando antes eran 24.

**(b) Continuar en la misma pagina al llegar a la celda 31.**
`$CAAA JMP $9B7C` pasa a `JMP $DE69`, una rutina nueva en el relleno del
banco `$0B`:

```
$DE69  JSR $9B7C          vuelca las lineas 1-2
       JSR $9C29          limpia el buffer
       LDA #$03
       STA $3657          -> filas B, la linea 3
       CLX                X = 0, el buffer se rellena desde el principio
       JMP $CA78          sigue el bucle SIN salir
```

El bucle continua, y cuando el canto se acaba (`$CA7F BMI $CAAD`) hace el
`JSR $9B7C` final, que ya vuelca con `$3657=3` -> la tercera linea.

EL HUECO
========
`0x17E69` = `$DE69`, **407 bytes a `$FF`**, identicos en la ROM virgen. Si
algo saltara ahi, el juego original ejecutaria `$FF` y se colgaria: es
relleno (norma 164).

Uso:  python3 tools/build_v267.py
"""
import hashlib
import zlib
import subprocess

BASE = 'roms/momotaro_es_v264.pce'
SALIDA = 'roms/momotaro_es_v267.pce'
IPS = 'parches/momotaro_v267.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '695965973173f0a960eb3c0095f8cef0'

BUCLE = 0x16A73                 # $CA73  JSR $9C29
CORTE = 0x16AAA                 # $CAAA  JMP $9B7C  (fin de pagina)
NOPS = 0x16ABD                  # $CABD  25 NOPs
CONT = 0x17E69                  # $DE69  407 B de relleno
FUENTE = 0x3D660


def ens(trozos):
    """Ensambla con etiquetas; los saltos se calculan."""
    pos, off = {}, 0
    for t in trozos:
        if isinstance(t[0], str) and t[0].startswith('@'):
            pos[t[0]] = off
        elif isinstance(t[0], str):
            off += 2
        else:
            off += len(t)
    out = bytearray()
    OPS = {'BCS': 0xB0, 'BCC': 0x90, 'BNE': 0xD0, 'BEQ': 0xF0}
    for t in trozos:
        if isinstance(t[0], str) and t[0].startswith('@'):
            continue
        if isinstance(t[0], str):
            rel = pos[t[1]] - (len(out) + 2)
            assert -128 <= rel <= 127, 'salto fuera de rango'
            out += bytes([OPS[t[0]], rel & 0xFF])
        else:
            out += bytes(t)
    return bytes(out), pos


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v264'
    print('base %s  OK  (se rehace desde la v264)' % BASE)
    assert all(b == 0 for b in rom[FUENTE:FUENTE + 8]), \
        'el glifo 0 no es todo ceros'

    # ==================================================================
    # (a) el borrado, con el bucle invertido
    # ==================================================================
    borra, _ = ens([
        [0x20, 0x29, 0x9C],          # JSR $9C29
        [0xA9, 0x03],                # LDA #$03
        ['@b'],
        [0x8D, 0x57, 0x36],          # STA $3657
        [0x48],                      # PHA
        [0x20, 0x7C, 0x9B],          # JSR $9B7C
        [0x68],                      # PLA
        [0x38],                      # SEC
        [0xE9, 0x02],                # SBC #$02
        [0xC9, 0x01],                # CMP #$01
        ['BCS', '@b'],
        [0x60],                      # RTS
    ])
    n = 0
    while rom[NOPS + n] == 0xEA:
        n += 1
    assert len(borra) <= n, 'el borrado no cabe: %d > %d' % (len(borra), n)
    print('\n(a) borrado: %d B en $CABD (hueco %d)' % (len(borra), n))

    # simulacion del bucle
    A, vals = 3, []
    for _ in range(6):
        vals.append(A)
        A = (A - 2) & 0xFF
        if not (A >= 1 and A < 0x80):
            break
    assert vals == [3, 1], 'el bucle no recorre 3 y 1: %s' % vals
    print('    $3657 toma %s y sale con %d -> filas A (lineas 1-2)'
          % (vals, vals[-1]))
    for v in vals:
        print('       $3657=%d -> filas %s'
              % (v, 'A (1-2)' if ((v - 1) & 2) == 0 else 'B (3-4)'))

    esp = bytes([0x20, 0x29, 0x9C])
    assert bytes(rom[BUCLE:BUCLE + 3]) == esp, 'en $CA73 no esta el JSR $9C29'
    rom[NOPS:NOPS + len(borra)] = borra
    a_borra = 0xC000 + (NOPS - 0x16000)
    rom[BUCLE:BUCLE + 3] = bytes([0x20, a_borra & 0xFF, a_borra >> 8])
    print('    $CA73  JSR $9C29 -> JSR $%04X' % a_borra)

    # ==================================================================
    # (b) continuar en la misma pagina
    # ==================================================================
    esp = bytes([0x4C, 0x7C, 0x9B])          # JMP $9B7C
    assert bytes(rom[CORTE:CORTE + 3]) == esp, \
        'en $CAAA no esta el JMP $9B7C: %s' % bytes(rom[CORTE:CORTE + 3]).hex()
    libre = 0
    while rom[CONT + libre] == 0xFF:
        libre += 1
    assert all(b == 0xFF for b in orig[CONT:CONT + libre]), \
        'el hueco no esta a $FF en la ROM virgen'
    print('\n(b) hueco en $DE69: %d B, a $FF tambien en la virgen' % libre)

    cont = bytes([
        0x20, 0x7C, 0x9B,            # JSR $9B7C   vuelca lineas 1-2
        0x20, 0x29, 0x9C,            # JSR $9C29   limpia el buffer
        0xA9, 0x03,                  # LDA #$03
        0x8D, 0x57, 0x36,            # STA $3657   -> filas B (linea 3)
        0x82,                        # CLX
        0x4C, 0x78, 0xCA,            # JMP $CA78   sigue el bucle
    ])
    assert len(cont) <= libre, 'no cabe'
    rom[CONT:CONT + len(cont)] = cont
    a_cont = 0xC000 + (CONT - 0x16000)
    rom[CORTE:CORTE + 3] = bytes([0x4C, a_cont & 0xFF, a_cont >> 8])
    print('    rutina de %d B en $%04X' % (len(cont), a_cont))
    print('    $CAAA  JMP $9B7C -> JMP $%04X' % a_cont)

    # ==================================================================
    # verificacion
    # ==================================================================
    tmp = '/tmp/_v267.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM')
    for o, nb, carga, nom in [(BUCLE, 6, 0xCA73, 'entrada'),
                              (CORTE, 6, 0xCAAA, 'corte de pagina'),
                              (NOPS, len(borra), a_borra, 'borrado'),
                              (CONT, len(cont), a_cont, 'continuacion')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % o,
                            str(nb), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    print('\n--- secuencia completa esperada')
    print('   1. pulsar SI -> $CA73 -> JSR $%04X' % a_borra)
    print('      borra filas B, borra filas A, deja $3657=1')
    print('   2. el bucle escribe el canto en las filas A (lineas 1 y 2)')
    print('   3. al llegar a la celda 31 -> JMP $%04X' % a_cont)
    print('      vuelca 1-2, limpia, $3657=3, X=0, sigue')
    print('   4. al acabar el canto -> $CAAD JSR $9B7C vuelca la linea 3')
    print('   => 3 lineas, UNA pagina, empezando arriba')

    intactas = [
        ('cuerpo del bucle', BUCLE + 3, CORTE),
        ('cola del bucle', CORTE + 3, NOPS),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla del canto', 0x16AD6, 0x16B16),
        ('cadena Capa', 0x43140, 0x43148),
        ('verbos del menu', 0x431B4, 0x431EB),
        ('parrilla del password', 0x1BBBA, 0x1BC00),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v264' % len(dif))
    ok = (set(range(BUCLE, BUCLE + 3)) | set(range(CORTE, CORTE + 3))
          | set(range(NOPS, NOPS + len(borra)))
          | set(range(CONT, CONT + len(cont))))
    assert set(dif) <= ok, 'cambios fuera de sitio'

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
