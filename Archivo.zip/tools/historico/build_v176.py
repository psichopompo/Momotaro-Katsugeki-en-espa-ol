#!/usr/bin/env python3
"""
build_v176.py - PASO 1 de la reconstruccion por pasos seguros.

David tiene razon: en Nekketsu acordamos no parchear parches, sino volver al
ultimo estado correcto e ir anadiendo cosas de una en una. Se abandona la
via de arreglar la v173/v175 del otro chat.

PUNTO DE PARTIDA
----------------
    v158  =  bocadillo BIEN (vertical), texto como cuadros tipo QR

UN SOLO CAMBIO EN ESTE PASO
---------------------------
El texto salia como cuadros porque los destinos de mi tabla apuntaban al
INICIO de la celda, y el motor escribe el glifo en el PLANO 3.

Medido en la v157 (la que funciona): **las 36 entradas de $9BBD acaban en
+48 words**, sin excepcion.

    una celda de sprite = 64 words = 4 planos de 16
        words  0-15  plano 0
        words 16-31  plano 1
        words 32-47  plano 2
        words 48-63  plano 3   <- el motor escribe AQUI

    color = p0 | p1<<1 | p2<<2 | p3<<3
        fondo  p0..p2=1, p3=0  ->  7  = blanco
        texto  p0..p2=1, p3=1  -> 15  = negro

Mi tabla de la v158 daba resto 0: escribia el glifo en el plano 0, y el
resultado eran bloques de color. De ahi el aspecto de QR.

Este paso **solo** suma 48 a las diez entradas de la tabla. Nada mas: ni
sprites, ni relleno de fondo, ni tocar rutinas compartidas.

QUE ESPERAR
-----------
El bocadillo seguira siendo el VERTICAL de la v158 (los sprites no se
tocan), pero el texto deberia dejar de ser cuadros: se vera algo legible,
aunque descolocado y probablemente con las celdas nuevas en sucio, porque
su fondo aun no esta inicializado.

Uso:  python3 tools/build_v176.py
"""
import hashlib
import zlib

BASE = 'roms/test_apaisado_v158.pce'
SALIDA = 'roms/momotaro_es_v176.pce'
MD5_BASE = '1e6171dae2393006bfae8f842ae1cdfd'

TABLA = 0x41BDD          # tabla de 10 parejas de la v158
N = 10
PLANO3 = 48              # offset del plano 3, en words


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v158 (md5 %s)' % md5
    orig = bytes(rom)

    # comprobar que la referencia sigue siendo cierta: en la v157 TODOS los
    # destinos acaban en +48
    v157 = open('roms/test_horizontal_v157.pce', 'rb').read()
    restos = {(v157[0x41BBD + k * 2] | (v157[0x41BBD + k * 2 + 1] << 8)) % 64
              for k in range(36)}
    assert restos == {PLANO3}, \
        'la v157 no usa el plano 3 uniformemente: restos %s' % restos
    print('verificado en la v157: las 36 entradas apuntan al plano 3 (+48)')
    print()

    for i in range(N):
        off = TABLA + i * 2
        w = rom[off] | (rom[off + 1] << 8)
        assert w % 64 == 0, \
            'la entrada %d ya tiene resto %d, no es la tabla cruda' % (i, w % 64)
        nuevo = w + PLANO3
        rom[off] = nuevo & 0xFF
        rom[off + 1] = nuevo >> 8
        print('  [%d] $%04X -> $%04X   celda %03X, plano 3'
              % (i, w, nuevo, w // 64))

    # nada mas puede haber cambiado
    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    assert len(dif) <= N * 2, 'se han tocado %d bytes' % len(dif)
    assert all(TABLA <= i < TABLA + N * 2 for i in dif), \
        'hay cambios fuera de la tabla'
    print()
    print('cambios: %d bytes, todos dentro de la tabla' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    print()
    print(SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
