#!/usr/bin/env python3
"""
build_v185.py - el MARCO de 16x4, que es lo que faltaba en la v184.

EL FALLO DE LA v184 (mio, y de los tontos)
------------------------------------------
David: «el texto ha desaparecido y el bocadillo sigue igual».

Medido en la propia v184:

```
tabla $9BBD  -> el motor escribe en  170 171 172 ... 177
lista $7C02  -> el marco DIBUJA      19C 19D 1AC 1A0 1A1 19E 19F 1AE
                                     1A6 1A7 1A8 1A9 1AA 1AB
celdas en comun: NINGUNA
```

El texto se estaba escribiendo en celdas que **ningun sprite muestra**. Por
eso desaparecio, y por eso el bocadillo seguia midiendo lo mismo: no toque
la lista de sprites.

Es **exactamente la norma 101**, que escribi yo mismo hace sesiones:

> 101. Cambiar donde se ESCRIBE el texto no cambia donde se DIBUJA el marco.

La escribi despues de tropezar con esto en la v158, y he vuelto a tropezar
igual. El constructor lleva ahora un `assert` que compara las dos listas y
aborta si no coinciden (norma 128), para que no pueda repetirse.

LA GEOMETRIA
------------
```
texto  16 glifos x 8 px = 128 px de ancho
        4 lineas x 8 px =  32 px de alto

relleno: 8 celdas por fila, 2 filas
   fila A (lineas 1-2): 170..177
   fila B (lineas 3-4): 178..17F

marco: 16 (lat izq) + 128 (texto) + 16 (lat der) = 160 px de ancho
       16 (borde sup) + 32 (texto) + 16 (borde inf) = 64 px de alto
```

Sprites: 9 arriba + 9 abajo + 4 laterales + 16 de relleno = **38**.

Comprobado que caben: en el state de David con bocadillo, el SATB tiene 64
ranuras, 44 con `y=$FFBF x=$FFDF cel=3FF` (aparcadas fuera de pantalla) y
solo **20 sprites visibles ademas del bocadillo**. El bocadillo ocupa hoy
21 ranuras (16..36); pasar a 38 deja 64 - 20 - 38 = 6 de margen.

Y en la lista del banco `$23` caben: 38 x 5 + 1 = 191 B de los 1022.

LO QUE ESTE PASO **NO** HACE
----------------------------
No toca todavia el volcado de la 2a mitad (lineas 3-4). El motor sigue
escribiendo 16x2 en la fila A. Las celdas de la fila B (`178-17F`) se
dibujan **en blanco**, y ahi es donde ira el texto en el paso siguiente.

Asi el paso se puede verificar solo: si se ve un bocadillo grande, con dos
lineas de texto arriba y espacio en blanco abajo, la geometria es correcta
y solo falta el segundo volcado.

Uso:  python3 tools/build_v185.py
"""
import hashlib
import zlib
import sys
import os

BASE = 'roms/momotaro_es_v184.pce'
SALIDA = 'roms/momotaro_es_v185.pce'
IPS = 'parches/momotaro_v185.ips'
MD5_BASE = 'e461db40da6a06d0ba60760318150890'

LISTA = 0x47C02
LISTA_FIN = 0x48000
TABLA = 0x41BBD

# La BASE del patron de sprite. $E3EB calcula patron = $55/$56 + b[0]*2, y
# $9A7B la fija con inmediatos a $0338 = celda 0x19C. Como b[0] es de 8 bits
# SIN signo, desde esa base solo se alcanzan las celdas 0x19C..0x29B: las
# nuevas (0x170-0x17F) quedan POR DEBAJO y son inalcanzables.
# Se baja la base a la celda 0x170 y se corrigen todos los b[0] (+44).
BASE_OFF = 0x41A7B          # LDA #$38 / STA $55 / LDA #$03 / STA $56
BASE_CELDA = 0x170
RABILLO = 0x41ADD           # tabla de 4 variantes

# celdas del CG del bocadillo
ESQ_SI, BORDE_S, ESQ_SD = 0x19C, 0x19D, 0x1AC
ESQ_II, BORDE_I, ESQ_ID = 0x19E, 0x19F, 0x1AE
LAT_I, LAT_D = 0x1A0, 0x1A1

CELDA0 = 0x170          # relleno nuevo, 16 celdas contiguas
COLS = 16
ANCHO_TXT = COLS * 8    # 128
FILAS_CEL = 2           # 2 filas de celdas de relleno = 4 lineas de texto

# El lateral izquierdo solo dibuja 3 px (columnas 0-2): el relleno arranca
# en +3, no en +16 (regla 3 de las siete del bocadillo).
DESP = 3

# David: el rabillo esta en su sitio; el resto del bocadillo se baja para
# unirlo. En la v177 se fijo Y0=32 con un bocadillo de 32 px de alto. Ahora
# mide 64, asi que para que el BORDE INFERIOR siga cayendo donde caia hay
# que subir el origen 32 px.
Y0 = 0


def reg(celda, b1, b2, dx, dy):
    b0 = celda - BASE_CELDA
    assert 0 <= b0 <= 255, 'celda %03X fuera del alcance de la base %03X' % (
        celda, BASE_CELDA)
    return [b0, b1, b2, dx & 0xFF, dy & 0xFF]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v184 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # donde escribe el motor, segun la tabla que dejo la v184
    # ------------------------------------------------------------------
    escribe = sorted({(rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)) // 64
                      for k in range(32)})
    print('el motor escribe en: %s' % ' '.join('%03X' % c for c in escribe))
    assert escribe == list(range(CELDA0, CELDA0 + 8)), \
        'la tabla de la v184 no apunta a 170-177'

    # ------------------------------------------------------------------
    # bajar la BASE del patron de la celda 0x19C a la 0x170
    # ------------------------------------------------------------------
    esperado = bytes([0xA9, 0x38, 0x85, 0x55, 0xA9, 0x03, 0x85, 0x56])
    assert bytes(rom[BASE_OFF:BASE_OFF + 8]) == esperado, \
        'la base del patron no es la esperada: %s' % bytes(
            rom[BASE_OFF:BASE_OFF + 8]).hex()
    pat = BASE_CELDA * 2
    rom[BASE_OFF + 1] = pat & 0xFF
    rom[BASE_OFF + 5] = pat >> 8
    desp = 0x19C - BASE_CELDA
    print('base del patron: $0338 (celda 19C) -> $%04X (celda %03X), '
          'desplazamiento %d celdas' % (pat, BASE_CELDA, desp))

    # la tabla del rabillo usa la MISMA base: hay que sumar el desplazamiento
    # a sus b[0]. Son 4 variantes, cada una con un solo sprite.
    for v in range(4):
        p = rom[RABILLO + v * 2] | (rom[RABILLO + v * 2 + 1] << 8)
        off = 0x40000 + (p - 0x8000)
        b0 = rom[off]
        celda = 0x19C + b0
        assert celda in (0x1AD, 0x1AF), \
            'variante %d del rabillo apunta a %03X, no al rabillo' % (v, celda)
        rom[off] = b0 + desp
        assert 0x170 + rom[off] == celda, 'el rabillo %d cambia de celda' % v
        print('  rabillo %d: b0 %d -> %d (sigue siendo la celda %03X)'
              % (v, b0, rom[off], celda))

    # ------------------------------------------------------------------
    # la lista de sprites nueva
    # ------------------------------------------------------------------
    X0 = -(ANCHO_TXT + 32) // 2         # centrado: -80
    nueva = []

    # --- borde superior: esquina de 32 + bordes de 16 + esquina de 16 ---
    nueva.append(reg(ESQ_SI, 0x0F, 0x01, X0, Y0))
    x = X0 + 32
    while x < X0 + 16 + ANCHO_TXT:
        nueva.append(reg(BORDE_S, 0x0F, 0x00, x, Y0))
        x += 16
    nueva.append(reg(ESQ_SD, 0x0F, 0x00, X0 + 16 + ANCHO_TXT, Y0))
    n_sup = len(nueva)

    # --- laterales y relleno, una fila de celdas por cada 2 lineas ---
    for fila in range(FILAS_CEL):
        y = Y0 + 16 + fila * 16
        nueva.append(reg(LAT_I, 0x0F, 0x00, X0, y))
        nueva.append(reg(LAT_D, 0x0F, 0x00, X0 + 16 + ANCHO_TXT + DESP, y))
        for k in range(8):
            celda = CELDA0 + fila * 8 + k
            nueva.append(reg(celda, 0x0F, 0x00, X0 + DESP + k * 16, y))

    # --- borde inferior ---
    yb = Y0 + 16 + FILAS_CEL * 16
    nueva.append(reg(ESQ_II, 0x0F, 0x01, X0, yb))
    x = X0 + 32
    while x < X0 + 16 + ANCHO_TXT:
        nueva.append(reg(BORDE_I, 0x0F, 0x00, x, yb))
        x += 16
    nueva.append(reg(ESQ_ID, 0x0F, 0x00, X0 + 16 + ANCHO_TXT, yb))

    print('sprites: %d superior, %d inferior, %d laterales, %d relleno = %d'
          % (n_sup, n_sup, FILAS_CEL * 2, FILAS_CEL * 8, len(nueva)))

    # ------------------------------------------------------------------
    # NORMA 101: las celdas donde escribe el motor TIENEN que estar en la
    # lista de sprites. Este assert es el que faltaba en la v184.
    # ------------------------------------------------------------------
    dibuja = {r[0] + BASE_CELDA for r in nueva}
    faltan = set(escribe) - dibuja
    assert not faltan, \
        'NORMA 101: el motor escribe en %s y ningun sprite las dibuja' % \
        sorted('%03X' % c for c in faltan)
    print('norma 101 verificada: las 8 celdas de texto estan en la lista')

    # los sprites de 32 px de ancho tienen que usar celda PAR (norma 112)
    for r in nueva:
        celda = r[0] + BASE_CELDA
        if r[2] & 0x01:
            assert celda % 2 == 0, \
                'sprite de 32 px con celda impar %03X' % celda
        dx = r[3] - 256 if r[3] > 127 else r[3]
        dy = r[4] - 256 if r[4] > 127 else r[4]
        assert -128 <= dx <= 127, 'dX fuera de rango: %d' % dx
        assert -128 <= dy <= 127, 'dY fuera de rango: %d' % dy

    # los bordes no se solapan entre si
    for y in (Y0, yb):
        t = sorted((r[3] - 256 if r[3] > 127 else r[3],
                    (r[3] - 256 if r[3] > 127 else r[3]) + (32 if r[2] & 1 else 16))
                   for r in nueva
                   if (r[4] - 256 if r[4] > 127 else r[4]) == y)
        for i in range(len(t) - 1):
            assert t[i][1] <= t[i + 1][0], \
                'solape en la fila y=%d: %s con %s' % (y, t[i], t[i + 1])
    print('sin solapes en los bordes; celdas de 32 px todas pares')

    # el borde tiene que cubrir el ancho entero, sin huecos
    for y in (Y0, yb):
        t = sorted((r[3] - 256 if r[3] > 127 else r[3],
                    (r[3] - 256 if r[3] > 127 else r[3]) + (32 if r[2] & 1 else 16))
                   for r in nueva
                   if (r[4] - 256 if r[4] > 127 else r[4]) == y)
        for i in range(len(t) - 1):
            assert t[i][1] == t[i + 1][0], \
                'hueco en el borde y=%d entre %s y %s' % (y, t[i], t[i + 1])
        assert t[0][0] == X0 and t[-1][1] == X0 + 32 + ANCHO_TXT, \
            'el borde y=%d no cubre de %d a %d' % (y, X0, X0 + 32 + ANCHO_TXT)
    print('bordes continuos de %d a %d px' % (X0, X0 + 32 + ANCHO_TXT))

    # ------------------------------------------------------------------
    # escribir
    # ------------------------------------------------------------------
    assert LISTA + len(nueva) * 5 + 1 <= LISTA_FIN, 'la lista no cabe'
    off = LISTA
    for r in nueva:
        rom[off:off + 5] = bytes(r)
        off += 5
    rom[off] = 0xFF
    # limpiar lo que quedaba de la lista vieja
    resto = orig[off + 1:LISTA_FIN]
    print('lista escrita: 0x%05X..0x%05X (%d B), terminador $FF'
          % (LISTA, off, off - LISTA + 1))

    # ------------------------------------------------------------------
    # el bocadillo es mas alto: 64 px en vez de 32
    # ------------------------------------------------------------------
    print()
    print('bocadillo: %d x %d px  (antes 118 x 48)'
          % (32 + ANCHO_TXT, 32 + FILAS_CEL * 16))
    print('  dX de %d a %d ; dY de %d a %d'
          % (X0, X0 + 32 + ANCHO_TXT, Y0, yb + 16))

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('cargador del CG', 0x41AAE, 0x41ACD),
        ('stream nuevo', 0x3D214, 0x3D3D4),
        ('fuente', 0x3D660, 0x3E200),
        ('flecha', 0x419E2, 0x419F3),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('intactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    permitido = set(range(LISTA, LISTA_FIN + 1)) | {BASE_OFF + 1, BASE_OFF + 5}
    for v in range(4):
        p = orig[RABILLO + v * 2] | (orig[RABILLO + v * 2 + 1] << 8)
        permitido.add(0x40000 + (p - 0x8000))
    fuera = [i for i in dif if i not in permitido]
    assert not fuera, 'cambios fuera de lo previsto: %s' % [hex(i) for i in fuera[:8]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        o2 = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n2 = raw[p + 3] << 8 | raw[p + 4]
        prueba[o2:o2 + n2] = raw[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B, %d registros)' % (len(raw), len(rec)))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  Un bocadillo GRANDE (160x64) con DOS lineas de texto arriba y')
    print('  la mitad de abajo en BLANCO. Eso es lo correcto en este paso:')
    print('  el segundo volcado (lineas 3-4) es el paso siguiente.')
    print('  Si el texto se ve, la norma 101 esta cumplida.')


if __name__ == '__main__':
    main()
