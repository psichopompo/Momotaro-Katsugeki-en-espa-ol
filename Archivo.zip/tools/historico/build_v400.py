#!/usr/bin/env python3
"""v400 - arregla los TRES fallos de la v399 (Kaguya, baño) y mantiene N1.

Se construye sobre la **v398**, no sobre la v399: la v399 queda retirada.

FALLO 1 - los «©»: ALIAS vs BYTES DIRECTOS
    charset_oficial usa alias de la zona ASCII para b/c/p ($5B/$5D/$5E)
    porque en el bocadillo de diálogo la tabla $43F9B los traduce a
    $A2/$A3/$B0. **Pero la pantalla de Kaguya y la del baño NO pasan por
    esa tabla**: pintan el byte directo, y el glifo directo de $5E es un
    recuadro -el «©» que ve David-.
    MEDIDO: el bloque del quiz (0x4AC8B), que lleva años bien, usa
    $A2/$A3/$B0 y NO usa ningún $5B/$5D/$5E. El texto de Kaguya de la v398
    tampoco. Aquí se escriben BYTES DIRECTOS.

FALLO 2 - Kaguya sólo mostraba la primera página
    Creí que $00 era «fin de página». **Es fin de BLOQUE.** El texto de la
    v398 no tiene ni un $00 intermedio: son 11 líneas separadas por $3B y
    **el motor pagina solo, cada 4 líneas** (CMP #$04 en 0x418AF).
    Mis dos $00 cortaban el texto tras la página 1.
    Reparto: 4 + 4 (la última vacía) + 2.

FALLO 3 - el baño es de 16 columnas, no de 17
    La «prueba» de 17 era falsa: probé sólo dos alineaciones. Barriendo
    inicio y ancho, **muchas combinaciones encajan exacto**, así que
    «encaja» no demuestra nada (norma 378).
    Lo que sí lo demuestra: en japonés el dakuten $DE y el handakuten $DF
    **no ocupan columna**. Contando así, el bloque JP da 4 líneas de 16
    exactas desde 0x4AC45. Y David lo vio en pantalla antes que yo.
"""
import hashlib, sys
sys.path.insert(0, 'tools')
import texto

BASE = "roms/momotaro_es_v398.pce"
SAL  = "roms/momotaro_es_v400.pce"
MD5_BASE = "68ffe9bcf98d169d1e63c30a9ee072bd"

CAPA_OFF, CAPA_LEN = 0x48A16, 20
CAPA_TXT = "Nadie te verá."

BANO_OFF, BANO_W = 0x4AC45, 16
BANO = ["¡Sí que existía!",
        "¡Baño femenino!",
        "¡Suerte, chaval!",
        "¡Je, je, je, je!"]

KAG_OFF, KAG_LEN = 0x4A403, 129
KAGUYA = ["La princesa", "Kaguya ha", "aprendido hace", "poco a apostar.",
          "Dicen que anda", "probando suerte", "por todos lados.", "",
          "¿Y si lo intento", "yo también?"]

DIRECTO = {0x5B: 0xA2, 0x5D: 0xA3, 0x5E: 0xB0, 0x5F: 0xDE}


def sin_alias(b):
    """Sustituye los alias ASCII por el byte directo que pinta el glifo."""
    return bytes(DIRECTO.get(x, x) for x in b)


def main():
    d = bytearray(open(BASE, "rb").read())
    assert hashlib.md5(d).hexdigest() == MD5_BASE, "la base no es la v398"
    orig = bytes(d)

    # ---------------- N1 CAPA ----------------
    assert d[CAPA_OFF:CAPA_OFF+CAPA_LEN] == texto.codifica("Los ogros no te ven.")
    assert texto.decodifica(orig, orig[CAPA_OFF+CAPA_LEN:CAPA_OFF+CAPA_LEN+7]) == "Aletas:"
    b = sin_alias(texto.codifica(CAPA_TXT))
    assert len(b) <= CAPA_LEN
    d[CAPA_OFF:CAPA_OFF+CAPA_LEN] = b + b"\xA0" * (CAPA_LEN - len(b))

    # ---------------- N2 BAÑO, 16 columnas ----------------
    # testigo: el quiz de detrás usa bytes directos y NINGÚN alias
    q = orig[0x4AC8B:0x4ACF0]
    assert not any(x in (0x5B, 0x5D, 0x5E) for x in q), \
        "el quiz usa alias: la teoría del byte directo se cae"
    assert any(x in (0xA2, 0xA3, 0xB0) for x in q), "el quiz no usa bytes directos"
    for i, l in enumerate(BANO):
        assert len(l) <= BANO_W, "línea %d del baño se pasa de %d: %r" % (i+1, BANO_W, l)
        e = sin_alias(texto.codifica(l))
        assert not any(x in (0x5B, 0x5D, 0x5E) for x in e), "ha quedado un alias"
        d[BANO_OFF+i*BANO_W:BANO_OFF+(i+1)*BANO_W] = e + b"\xA0" * (BANO_W - len(e))
    assert BANO_OFF + 4*BANO_W <= 0x4AC8B, "el baño pisa el quiz"
    # el bloque JP ocupa 70 B (0x4AC45..0x4AC8B) y el nuestro 64: quedaban
    # 6 bytes de katakana sin pisar (ノフ! + relleno). Se limpian a espacio.
    cola_ini = BANO_OFF + 4*BANO_W
    assert orig[cola_ini:0x4AC8B].hex() == "c9cc21202020", \
        "la cola del baño no es la que creo: %s" % orig[cola_ini:0x4AC8B].hex()
    d[cola_ini:0x4AC8B] = b"\xA0" * (0x4AC8B - cola_ini)

    # ---------------- N3 KAGUYA ----------------
    assert orig[0x4A475:0x4A484] == b"\x00" * 15, "el relleno de Kaguya cambió"
    # el original NO tiene ningún $00 intermedio: $00 es fin de bloque
    assert 0x00 not in orig[0x4A403:0x4A475], "la v398 sí tenía $00 intermedios"
    for l in KAGUYA:
        assert len(l) <= 16, "línea de Kaguya se pasa de 16: %r" % l
    t = "\n".join(KAGUYA)
    k = sin_alias(texto.comprime(orig, t))
    assert texto.decodifica(orig, k) == t, "round-trip del diccionario FALLA"
    assert 0x00 not in k, "se ha colado un fin de bloque en medio"
    assert len(k) <= KAG_LEN, "Kaguya no cabe: %d > %d" % (len(k), KAG_LEN)
    # 10 líneas -> páginas de 4: 4 + 4 + 2
    pgs = [KAGUYA[i:i+4] for i in range(0, len(KAGUYA), 4)]
    assert [len(p) for p in pgs] == [4, 4, 2], "el reparto de páginas cambió"
    d[KAG_OFF:KAG_OFF+KAG_LEN] = k + b"\x00" * (KAG_LEN - len(k))

    # ------------- nada fuera de las tres zonas -------------
    dif = [i for i in range(len(d)) if d[i] != orig[i]]
    zonas = [(CAPA_OFF, CAPA_OFF+CAPA_LEN), (BANO_OFF, 0x4AC8B),
             (KAG_OFF, KAG_OFF+KAG_LEN)]
    for i in dif:
        assert any(a <= i < b for a, b in zonas), "byte fuera de zona: 0x%X" % i
    assert d[:0x48000] == orig[:0x48000], "se ha tocado código"
    assert d[0x4BA13:0x4BF40] == orig[0x4BA13:0x4BF40], "diccionario tocado"
    # y ni un alias en todo lo escrito
    for a, bb in zonas:
        assert not any(x in (0x5B, 0x5D, 0x5E) for x in d[a:bb]), \
            "queda un alias en 0x%X" % a

    open(SAL, "wb").write(d)
    print("%s   %d bytes cambiados" % (SAL, len(dif)))
    print("  MD5   ", hashlib.md5(d).hexdigest())
    print("  SHA-1 ", hashlib.sha1(bytes(d)).hexdigest())
    print()
    print("  Capa  : %r" % CAPA_TXT)
    print("  Baño  : 4 x 16 col")
    for l in BANO: print("            %-16s %2d" % (repr(l), len(l)))
    print("  Kaguya: %d/%d B, páginas 4+4+2" % (len(k), KAG_LEN))

main()
