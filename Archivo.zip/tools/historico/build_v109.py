"""build_v109.py - 24 celdas SIN romper nada. Rutina duplicada + slots ajustados.

BASE: roms/test_menu_v92.pce  (MD5 c5131fa002d9b2ae419376aa44343f5c)

LOS DOS PROBLEMAS DE LA v98
---------------------------
1. LA PANTALLA DE TITULO SEGUIA ROTA.
   Revertir el scroll no bastaba: $C298 (avance de linea) y $C388 (set
   cursor) tambien estan en el banco 0x0D, y los usa el bucle $C000, que
   tiene VEINTE llamantes en toda la ROM (titulo, escenas, endings...).
   Al redirigirlos a $FA1C, todas esas pantallas pasaban a separacion $300
   mientras su scroll seguia asumiendo $200.

2. AL ABUELO LE FALTABAN TILES.
   Limite del PC Engine: 16 slots de 16 px por scanline. Medido:
       lista original   10 slots
       lista v98        14-15 slots
   Y el abuelo, Momotaro y los nordos van aparte. Al pasarse, el hardware
   descarta los ultimos sprites.
   David lo intuyo sin saber el motivo: «perfectamente le sobra un tile».

LA SOLUCION
-----------
A) DUPLICAR la rutina de avance de linea en un hueco del banco 0x0D
   ($DDC8, 568 B de $FF, verificado sin referencias externas reales) y que
   SOLO el tutorial use la copia. Asi $C284/$C298/$C388 quedan INTACTOS y
   las otras 20 pantallas no se enteran.

   La copia es identica salvo que lee $FA1C,X en vez de $EC04,X.
   El interprete $C1AF hace `JMP $C284` en ROM 0x1A1D1. Ese JMP se cambia a
   `JMP $DDC8`... pero $C1AF lo comparten las dos rutas.

   -> En su lugar se duplica TAMBIEN el punto de entrada: el trampolin
      $EC0A (ROM 0x00C0A) llama a $C1AF. Se crea $EC2C que llama a una copia
      de $C1AF con el JMP cambiado, y el tutorial (ROM 0x1D94B) llama a esa.

   Como $C1AF..$C209 son 90 bytes y el hueco tiene 568, cabe de sobra.

B) REDUCIR SLOTS para que el abuelo se vea:
   - quitar los 4 sprites laterales (X=16 y X=208): son redundantes, el
     interior blanco lo pintan los propios sprites de texto;
   - marco de 6 piezas en vez de 7 (lo que pidio David: «le sobra un tile»).
   Resultado: 12 slots en las lineas de texto, 12 en el marco.

C) AJUSTES DE POSICION pedidos por David:
   - bocadillo centrado (ya lo estaba: 26/27 px);
   - relleno blanco 3 px a la izquierda;
   - un tile menos de ancho.
"""
import hashlib, zlib, os, sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
from charset_oficial import CHAR_TO_CODE

SRC = os.path.join(RAIZ, 'roms', 'test_menu_v92.pce')
DST = os.path.join(RAIZ, 'roms', 'test_ancho_v109.pce')
IPS = os.path.join(RAIZ, 'parches', 'momotaro_ancho_v109.ips')
MD5_SRC = 'c5131fa002d9b2ae419376aa44343f5c'

# ---------------------------------------------------------------- tabla
TABLA_ROM = 0x01A1C                      # $FA1C, banco 0x00 (MPR7)
BASES = (0x6B84, 0x6E84, 0x7184)         # separacion $300 = 24 celdas
TABLA_NUEVA = b''.join(bytes([b & 0xFF, b >> 8]) for b in BASES)

# ------------------------------------------------- copia en el banco 0x0D
COPIA_ROM = 0x1BDC8                      # $DDC8
COPIA_LOG = 0xDDC8

# $C1AF..$C209 (interprete) copiado tal cual, con el JMP $C284 -> JMP <avance>
INT_SRC, INT_LEN = 0x1A1AF, 0x5B         # 0x1A1AF..0x1A209
INT_LOG = 0xC1AF
# $C284..$C2AA (avance de linea) copiado, con $EC04,X -> $FA1C,X
AV_SRC, AV_LEN = 0x1A284, 0x27
AV_LOG = 0xC284

# ------------------------------------------------------------ sprites
LISTA_VIEJA_ROM = 0x2EA45
LISTA_NUEVA_ROM = 0x2FA5A
LISTA_NUEVA_LOG = 0x4000 + (LISTA_NUEVA_ROM - 0x17 * 0x2000)   # $5A59
PTR_LO, PTR_HI = 0x1D9BA, 0x1D9BE

ANCLA_X = 128                            # medido: el ancla real, no 160


def reg(rel, a_lo, a_hi, dx, dy):
    return bytes([rel, a_lo, a_hi, dx & 0xFF, dy & 0xFF])


# texto: 6 sprites de 32 px = 24 celdas, a partir de X=35 (8 px de margen)
# texto: 5 sprites de 32 px = 160 px = 20 celdas
#   bocadillo = 160 (texto) + 16 (margenes 8+8) + 12 (laterales) = 188 px
#   centrado en 256 -> empieza en x=34; interior en x=46
TX0 = 50
DXT = [TX0 - ANCLA_X + 32 * i for i in range(5)]
# marco sup/inf: 6 piezas de 32 px cubren 192 px desde x=28
MX0 = 33
DXM = [MX0 - ANCLA_X + 32 * i for i in range(6)]
# esquina derecha 2 px a la izquierda (propuesta de David)
DXM[5] -= 2
# laterales de 16 px: izquierda en x=30, derecha en x=210
LAT_IZQ = 34 - ANCLA_X
LAT_DER = 206 - ANCLA_X

LISTA = b''.join(
    # texto: 2 filas x 5 sprites de 32 px = 20 celdas
    [reg(0x0A + 2 * i, 0x0E, 0x01, DXT[i], 0x10) for i in range(5)] +
    [reg(0x16 + 2 * i, 0x0E, 0x01, DXT[i], 0x20) for i in range(5)] +
    # marco superior
    [reg(0x00, 0x0E, 0x01, DXM[0], 0x00)] +
    [reg(0x02, 0x0E, 0x01, DXM[i], 0x00) for i in range(1, 5)] +
    [reg(0x00, 0x0E, 0x09, DXM[5], 0x00)] +
    # laterales (16 px), imprescindibles para cerrar el contorno
    [reg(0x04, 0x0E, 0x00, LAT_IZQ, 0x10), reg(0x04, 0x0E, 0x00, LAT_IZQ, 0x20),
     reg(0x04, 0x0E, 0x08, LAT_DER, 0x10), reg(0x04, 0x0E, 0x08, LAT_DER, 0x20)] +
    # rabito
    [reg(0x09, 0x0E, 0x00, -8, 0x30)] +
    # marco inferior
    [reg(0x00, 0x0E, 0x81, DXM[0], 0x30)] +
    [reg(0x02, 0x0E, 0x81, DXM[i], 0x30) for i in range(1, 5)] +
    [reg(0x00, 0x0E, 0x89, DXM[5], 0x30)]
) + b'\xFF'

PAGINAS = [
    ["¡Primero, calienta", "antes de jugar!"],
    ["¡Esquiva los ñordos", "que caen! ¡Ja, ja!"],
    ["¡Pulsa II y salta", "para esquivarlos!"],
    ["¡Ve a la derecha", "hasta la meta! ¡Ya!"],
]
INI, FIN = 0x1F2C9, 0x1F365


def codifica(paginas):
    out = bytearray([0x01])
    for p, pag in enumerate(paginas):
        for i, l in enumerate(pag):
            assert len(l) <= 20, '%r = %d celdas (max 20)' % (l, len(l))
            for ch in l:
                out.append(CHAR_TO_CODE[ch])
            if i != len(pag) - 1:
                out.append(0x00)
        out += bytes([0xFD, 0xFD])
        if p != len(paginas) - 1:
            out.append(0xFE)
    out.append(0xFF)
    return bytes(out)


def main():
    rom = bytearray(open(SRC, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_SRC, 'la base no es la v92'
    tocados = set()

    def poke(off, viejo, nuevo, desc):
        real = bytes(rom[off:off + len(viejo)])
        assert real == viejo, '%s: 0x%05X tiene %s, esperaba %s' % (
            desc, off, real.hex(), viejo.hex())
        assert len(nuevo) == len(viejo)
        rom[off:off + len(nuevo)] = nuevo
        tocados.update(range(off, off + len(nuevo)))

    # 1. tabla de bases
    poke(TABLA_ROM, b'\x00' * 6, TABLA_NUEVA, 'tabla $FA1C')

    # 2. arranque del tutorial (banco 0x0E) -> tabla nueva
    poke(0x1D97D, bytes.fromhex('ad04ec'), bytes.fromhex('ad1cfa'), 'tut arranque lo')
    poke(0x1D982, bytes.fromhex('ad05ec'), bytes.fromhex('ad1dfa'), 'tut arranque hi')

    # 3. preparacion de patrones del tutorial: 25 -> 37 patrones
    poke(0x1D95C, bytes([0x18]), bytes([0x24]), 'prep tutorial LDY')

    # 4. COPIA de interprete + avance en el hueco $DDC8
    hueco_len = INT_LEN + AV_LEN
    assert all(b == 0xFF for b in rom[COPIA_ROM:COPIA_ROM + hueco_len]), \
        'el hueco $DDC8 no esta libre'

    interp = bytearray(rom[INT_SRC:INT_SRC + INT_LEN])
    avance = bytearray(rom[AV_SRC:AV_SRC + AV_LEN])

    # la copia del avance lee la tabla nueva
    for pos, viejo, nuevo in ((0x14, b'\xbd\x04\xec', b'\xbd\x1c\xfa'),
                              (0x19, b'\xbd\x05\xec', b'\xbd\x1d\xfa')):
        assert bytes(avance[pos:pos + 3]) == viejo, 'avance: offset %02X' % pos
        avance[pos:pos + 3] = nuevo

    # colocacion: interprete en $DDC8, avance justo detras
    AV_NEW_LOG = COPIA_LOG + INT_LEN
    # dentro del interprete, el JMP $C284 (en $C1D1 = offset 0x22) apunta a la copia
    off_jmp = 0x1A1D1 - INT_SRC
    assert bytes(interp[off_jmp:off_jmp + 3]) == b'\x4c\x84\xc2', 'no encuentro JMP $C284'
    interp[off_jmp:off_jmp + 3] = bytes([0x4C, AV_NEW_LOG & 0xFF, AV_NEW_LOG >> 8])

    # las ramas internas del interprete son relativas -> se mantienen.
    # los JMP absolutos internos ($D1FF etc.) apuntan fuera: se conservan.
    # el BEQ $C20A (offset 0x27) sale del bloque: apuntarlo a un trampolin
    TRAMP2_LOG = COPIA_LOG + INT_LEN + AV_LEN
    off_beq = 0x1A1D6 - INT_SRC
    assert bytes(interp[off_beq:off_beq + 2]) == b'\xf0\x32', 'no encuentro BEQ $C20A'
    d_ = TRAMP2_LOG - (COPIA_LOG + off_beq + 2)
    assert 0 <= d_ <= 127, 'el trampolin no esta al alcance: %d' % d_
    interp[off_beq + 1] = d_

    rom[COPIA_ROM:COPIA_ROM + INT_LEN] = interp
    rom[COPIA_ROM + INT_LEN:COPIA_ROM + INT_LEN + AV_LEN] = avance
    rom[COPIA_ROM + INT_LEN + AV_LEN:COPIA_ROM + INT_LEN + AV_LEN + 3] = \
        bytes([0x4C, 0x0A, 0xC2])          # JMP $C20A
    hueco_len += 3
    tocados.update(range(COPIA_ROM, COPIA_ROM + hueco_len))

    # 5. trampolin nuevo: el tutorial llama a la copia, no a $C1AF
    #    $EC0A original: TMA #$40 / PHA / LDA #$0D / CLC / ADC $20 / TAM #$40
    #                    JSR $C1AF / PLA / TAM #$40 / RTS
    #    Basta cambiar el operando del JSR dentro de ESE trampolin... pero lo
    #    comparte la otra pantalla. Se duplica el trampolin en $F9CC (banco 0).
    TRAMP_ROM = 0x01A22
    tramp = bytes(rom[0x00C0A:0x00C1B])          # 17 bytes
    assert tramp[-1] == 0x60, 'el trampolin no acaba en RTS'
    assert bytes(rom[TRAMP_ROM:TRAMP_ROM + len(tramp)]) == b'\x00' * len(tramp), \
        'el hueco $FA22 no esta libre'
    t = bytearray(tramp)
    j = t.index(b'\x20\xaf\xc1')                 # JSR $C1AF
    t[j:j + 3] = bytes([0x20, COPIA_LOG & 0xFF, COPIA_LOG >> 8])
    rom[TRAMP_ROM:TRAMP_ROM + len(t)] = t
    tocados.update(range(TRAMP_ROM, TRAMP_ROM + len(t)))

    # el tutorial (ROM 0x1D94B) pasa a llamar al trampolin nuevo
    TR_LOG = 0xFA22
    poke(0x1D94B, bytes([0x20, 0x0A, 0xEC]),
         bytes([0x20, TR_LOG & 0xFF, TR_LOG >> 8]), 'tut JSR trampolin')

    # 6. lista de sprites reubicada
    n = len(LISTA)
    assert all(b == 0xFF for b in rom[LISTA_NUEVA_ROM:LISTA_NUEVA_ROM + n]), \
        'el hueco de la lista no esta libre'
    rom[LISTA_NUEVA_ROM:LISTA_NUEVA_ROM + n] = LISTA
    tocados.update(range(LISTA_NUEVA_ROM, LISTA_NUEVA_ROM + n))
    poke(PTR_LO, bytes([0x45]), bytes([LISTA_NUEVA_LOG & 0xFF]), 'ptr lista lo')
    poke(PTR_HI, bytes([0x4A]), bytes([LISTA_NUEVA_LOG >> 8]), 'ptr lista hi')

    # 7. texto
    datos = codifica(PAGINAS)
    assert len(datos) <= FIN - INI + 1, 'el texto no cabe'
    rom[INI:INI + len(datos)] = datos
    for i in range(INI + len(datos), FIN + 1):
        rom[i] = 0xFF
    tocados.update(range(INI, FIN + 1))

    # --- verificaciones finales ---
    assert bytes(rom[0x00C04:0x00C0A]) == bytes.fromhex('846b846d846f'), 'tocada $EC04'
    for off, nm in ((0x1A284, 'avance original'), (0x1A298, '$C298'),
                    (0x1A388, '$C388'), (0x1A315, 'scroll'), (0x1A189, 'arranque padres'),
                    (0x00C0A, 'trampolin original')):
        base_ = open(SRC, 'rb').read()
        assert rom[off:off + 8] == base_[off:off + 8], '%s modificado' % nm

    base = open(SRC, 'rb').read()
    dif = [i for i in range(len(rom)) if rom[i] != base[i]]
    fuera = set(dif) - tocados
    assert not fuera, 'tocado fuera: %s' % sorted('0x%05X' % x for x in fuera)[:10]

    open(DST, 'wb').write(bytes(rom))
    rec = []
    for a, b in ((TABLA_ROM, 6), (0x1D97D, 3), (0x1D982, 3), (0x1D95C, 1),
                 (COPIA_ROM, hueco_len), (TRAMP_ROM, len(t)), (0x1D94B, 3),
                 (LISTA_NUEVA_ROM, n), (PTR_LO, 1), (PTR_HI, 1), (INI, FIN - INI + 1)):
        d_ = bytes(rom[a:a + b])
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF, b >> 8, b & 0xFF]) + d_)
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')

    d = bytes(rom)
    print('test_ancho_v109.pce')
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08x' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes modificados' % len(dif))
    print()
    print('  copia del interprete+avance en $DDC8 (%d B)' % hueco_len)
    print('  trampolin nuevo en $F9CC; el tutorial lo usa en vez de $EC0A')
    print('  $C284/$C298/$C388/$C315 INTACTOS  [verificado]')
    print('  texto: X = %s' % ', '.join(str(ANCLA_X + d_) for d_ in DXT))
    print('  marco: X = %s' % ', '.join(str(ANCLA_X + d_) for d_ in DXM))


if __name__ == '__main__':
    main()
