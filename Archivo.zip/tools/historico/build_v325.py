#!/usr/bin/env python3
"""build_v325.py - La v324 con las cuatro correcciones de David.

1. EL «Vuelo.» QUE SOBRA  -- arreglo de CODIGO, no de texto
   ------------------------------------------------------
   La entrada del ermitanyo ($D7AE, ROM 0x117AE) hace:

       $D7B8  JSR $C5F3      limpia el bocadillo
       $D7BB  JSR $DD31
       $D7BE  LDA #$2D / #$6E   -> $6E2D = ROM 0x4AE2D  «Soy <tecnica>.»
       $D7C6  JSR $DD42         <-- LO PINTA. ESTE SOBRA.
       $D7C9  ...               -> segundo mensaje, el bueno

   O sea: el juego pinta SIEMPRE la presentacion «yo soy el ermitanyo
   Vuelo» antes de «Acierta todas y te dare un don». En japones el viejo
   se presentaba; en castellano queda un bocadillo suelto que estorba.

   Llevo TRES versiones (v318, v322, v323) intentando redactar mejor ese
   texto. El error de razonamiento: di por hecho que un texto que aparece
   es un texto que hay que traducir, sin preguntarme QUIEN lo llama.
   El arreglo es neutralizar el JSR con tres NOP.

   Comprobado que $D7C6 NO lo comparte nadie: las 10 llamadas a $DD42
   estan en $D325 $D347 $D37B $D38A $D608 $D61A $D625 $D7C6 $D7D8 $D7E3,
   y solo $D7C6 cuelga de la entrada del ermitanyo ($D7AE, llamada una
   sola vez desde $CFA1).

2. «Aldea Bambú» en vez de «Aldea Taketori»
   ----------------------------------------
   David: el texto se corta en el mapa y en el rotulo. Y ademas hay que
   tocar el DIALOGO de la aldeana, que dice «Ésta es la aldea de
   Taketori.» (0x4A3F8, motor de vitores) — es la incoherencia exacta de
   la que David se quejo en la v318, al reves.

   Tres sitios:
       0x1F8DF  rotulo, banco $0F, charset_rotulos   «Aldea Taketori»
       0x43783  menu RUN, banco $21, charset_oficial «Taketori»
       0x4A3F8  dialogo, banco $25, charset_vitores  «Taketori.»

3. EL QUIZ ENTERO
   --------------
   40 preguntas (2 lineas de 16 columnas) y 120 opciones (8 columnas,
   7 utiles por el cursor). Tabla de punteros en 0x11818, banco $08.

   Motor $AAB4 con la ruta de $3BA6=0 -> tabla de glifos $9CF3.

   EL CHARSET ES `charset_oficial`, no `charset_rotulos`. Medido:
   el renderer tiene dos rutas ($AAB9  CMP #$A0  BCC):

       byte >= $A0  -> ruta katakana: el glifo ES el byte
       byte <  $A0  -> ruta tabla:    glifo = $BF9B[byte-$30]

   y en la tabla $BF9B (ROM 0x43F9B) estan $5B->$A2 'b', $5D->$A3 'c',
   $5E->$B0 'p', que son exactamente los tres alias de charset_oficial.
   Los alias e=$3D / o=$62 de charset_rotulos dan los glifos $A5 y $AF,
   que valen para el motor de rotulos pero NO son la 'e' y la 'o' de este.

   Me equivoque en el primer intento: escribi un enc_quiz que forzaba
   e/o/b/c a ASCII puro. El assert de repunteo lo cazo.

CAMBIOS RESPECTO A LA v324 (todos de TEXTO, ni un byte de codigo)
-----------------------------------------------------------------
P21  la pregunta no se entendia. David: «No se entiende la pregunta.»
     «Del cuerpo de / Orochi, ¿que?»  ->  «¿Que llevaba / Orochi dentro?»
P35  «Magico» es un adjetivo y no dice QUE objeto es. David propone
     sustituir la falsa por «Porra»:  Maza/Magico  ->  Porra/Mazo
     (la correcta es la 2: uchide-no-kozuchi, el mazo que concede deseos)
P28  el simbolo NO era un dolar. El '$' pasa por la tabla $AB34
     ($24 -> $3E) y acaba en el glifo $FF, el MISMO que usa el japones
     («100» + $3E): el simbolo del ryo que ya sale en todo el juego.
     Lo que estaba mal era mi comentario, que ademas decia «mon».
     Corregido a «ryo» en la columna de referencia.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
from quiz_texto import QUIZ, ROTULO, COLS_PREGUNTA, UTILES, comprueba  # noqa: E402
import charset_oficial                                                 # noqa: E402
import charset_rotulos                                                 # noqa: E402
import charset_vitores                                                 # noqa: E402

BASE = 'roms/momotaro_es_v323.pce'
SALIDA = 'roms/momotaro_es_v325.pce'
MD5_BASE = '7056a5c3eaac15e5fdef6a2839912ef3'

# ---- 1. el JSR que sobra -------------------------------------------------
JSR_SOBRA = 0x117C6          # JSR $DD42 en la entrada del ermitanyo
JSR_BYTES = bytes([0x20, 0x42, 0xDD])
NOP3 = bytes([0xEA, 0xEA, 0xEA])

# ---- 2. Aldea Bambú ------------------------------------------------------
ROTULO_TAKETORI = 0x1F8DF    # banco $0F, [$01] texto [$FF]
MENU_TAKETORI = 0x43783      # banco $21, 8 B «Taketori»
DIALOGO_TAKETORI = 0x4A3F9   # banco $25, «Taketori.» TRAS el marcador $63
#                              (el $63 vive en 0x4A3F8 y expande a
#                               «Ésta es la aldea de »: no se toca)

# ---- 3. el quiz ----------------------------------------------------------
TABLA = 0x11818              # banco $08, 84 punteros, base CPU $6000
ZONA_INI = 0x4AEEE           # primer byte reescribible (tras el rotulo)
ZONA_FIN = 0x4B87B           # ultimo byte de la zona del quiz
CPU_BASE = 0x6000
ROM_BASE = 0x4A000

ROTULO_QUIZ = 0x4AEE6        # «オコタエハ?» -> «Elige:», 6 B en el sitio

RELLENO = 0xA0
SALTO = 0x80                 # el motor lo lee como «salta a la columna 16»

INTACTAS = [
    (0x00000, 0x10000, 'bancos 00-07'),
    (0x12000, 0x1E000, 'bancos 09-0E'),
    (0x20000, 0x42000, 'bancos 10-20'),
    (0x44000, 0x48000, 'bancos 22-23'),
    (0x4B87B, 0x4BA13, 'cierre del quiz y ppt'),
    (0x4BA13, 0x4C000, 'diccionario y dialogos'),
    (0x4C000, 0x80000, 'bancos 26-3F'),
]


def enc_quiz(txt):
    """Codifica para el motor $AAB4. Es el charset OFICIAL, con sus alias."""
    return charset_oficial.encode(txt)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v323'

    errs = comprueba()
    assert not errs, 'el texto no cabe: %s' % errs

    # ================= 1. el JSR que sobra ===============================
    assert rom[JSR_SOBRA:JSR_SOBRA + 3] == JSR_BYTES, \
        'en %06X no hay JSR $DD42, hay %s' % (
            JSR_SOBRA, rom[JSR_SOBRA:JSR_SOBRA + 3].hex())
    # el LDA #$2D / #$6E de delante confirma que es el del ermitanyo
    assert rom[JSR_SOBRA - 8:JSR_SOBRA] == bytes(
        [0xA9, 0x2D, 0x85, 0xBF, 0xA9, 0x6E, 0x85, 0xC0]), \
        'el contexto de %06X no es el del ermitanyo' % JSR_SOBRA
    rom[JSR_SOBRA:JSR_SOBRA + 3] = NOP3

    # ================= 2. Aldea Bambú ====================================
    # 2a. el rotulo del mapa y de la entrada
    vieja = charset_rotulos.rotulo('Aldea Taketori')
    nueva = charset_rotulos.rotulo('Aldea Bambú')
    assert rom[ROTULO_TAKETORI:ROTULO_TAKETORI + len(vieja)] == vieja, \
        'en %06X no esta «Aldea Taketori»' % ROTULO_TAKETORI
    assert len(nueva) <= len(vieja)
    rom[ROTULO_TAKETORI:ROTULO_TAKETORI + len(vieja)] = (
        nueva + bytes([0xFF]) * (len(vieja) - len(nueva)))

    # 2b. el menu RUN (motor de menu: charset OFICIAL)
    v2 = charset_oficial.encode('Taketori')
    n2 = charset_oficial.encode('Bambú')
    assert rom[MENU_TAKETORI:MENU_TAKETORI + 8] == v2, \
        'en %06X no esta «Taketori»' % MENU_TAKETORI
    rom[MENU_TAKETORI:MENU_TAKETORI + 8] = n2 + bytes([0xFF]) * (8 - len(n2))

    # 2c. el dialogo de la aldeana: «Ésta es la aldea de Taketori.»
    v3 = charset_vitores.encode('Taketori.')
    n3 = charset_vitores.encode('Bambú.')
    assert rom[DIALOGO_TAKETORI:DIALOGO_TAKETORI + len(v3)] == v3, \
        'en %06X no esta «Taketori.»' % DIALOGO_TAKETORI
    rom[DIALOGO_TAKETORI:DIALOGO_TAKETORI + len(v3)] = (
        n3 + bytes([RELLENO]) * (len(v3) - len(n3)))

    # ================= 3. el quiz ========================================
    # 3a. el rotulo de la ventana de opciones, en su sitio original
    r = enc_quiz(ROTULO)
    hueco_rot = ZONA_INI - ROTULO_QUIZ          # 8 B
    assert len(r) <= hueco_rot, 'el rotulo ocupa %d y hay %d' % (
        len(r), hueco_rot)
    rom[ROTULO_QUIZ:ZONA_INI] = r + bytes([RELLENO]) * (hueco_rot - len(r))

    # 3b. los 80 bloques, uno detras de otro, apuntando cada uno
    bloques = []
    for _n, l1, l2, o1, o2, o3, _jp in QUIZ:
        preg = (enc_quiz(l1) + bytes([RELLENO]) * (COLS_PREGUNTA - len(l1)) +
                bytes([SALTO]) +
                enc_quiz(l2) + bytes([RELLENO]) * (COLS_PREGUNTA - len(l2)))
        bloques.append(('P', preg))
    for _n, _l1, _l2, o1, o2, o3, _jp in QUIZ:
        resp = b''
        for op in (o1, o2, o3):
            # 1 columna de sangria para el cursor + hasta 7 utiles
            resp += (bytes([RELLENO]) + enc_quiz(op) +
                     bytes([RELLENO]) * (UTILES - len(op)))
        bloques.append(('R', resp))

    total = sum(len(b) for _t, b in bloques)
    hueco = ZONA_FIN - ZONA_INI
    assert total <= hueco, 'el quiz ocupa %d B y hay %d' % (total, hueco)

    punteros = []
    p = ZONA_INI
    for _t, b in bloques:
        punteros.append(p)
        rom[p:p + len(b)] = b
        p += len(b)
    # el resto de la zona, a relleno
    rom[p:ZONA_FIN] = bytes([RELLENO]) * (ZONA_FIN - p)

    # 3c. reescribir la tabla: indices 2..81
    for i, off in enumerate(punteros):
        cpu = CPU_BASE + off - ROM_BASE
        assert 0x6000 <= cpu < 0x8000, 'puntero fuera de ventana: $%04X' % cpu
        t = TABLA + 2 * (i + 2)
        rom[t] = cpu & 0xFF
        rom[t + 1] = cpu >> 8
    # el rotulo lo apunta el indice 95
    cpu_rot = CPU_BASE + ROTULO_QUIZ - ROM_BASE
    rom[TABLA + 2 * 95] = cpu_rot & 0xFF
    rom[TABLA + 2 * 95 + 1] = cpu_rot >> 8

    # ================= VERIFICACION ======================================
    # -- relectura SIGUIENDO EL PUNTERO, como hace el motor (norma 287) ---
    rv = {}
    for ch in ('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
               '0123456789 !?.,:;¡¿áéíóúüñÁÉÍÓÚÜÑ-$'):
        try:
            rv.setdefault(enc_quiz(ch)[0], ch)
        except ValueError:
            pass

    def lee(idx):
        t = TABLA + 2 * idx
        cpu = rom[t] | rom[t + 1] << 8
        return ROM_BASE + cpu - CPU_BASE

    for i, (_n, l1, l2, _o1, _o2, _o3, _jp) in enumerate(QUIZ):
        a = lee(i + 2)
        d = rom[a:a + 33]
        assert d[COLS_PREGUNTA] == SALTO, \
            'P%d: falta el $80 de salto de linea' % (i + 1)
        g1 = ''.join(rv.get(b, '') for b in d[:COLS_PREGUNTA]).rstrip()
        g2 = ''.join(rv.get(b, '') for b in d[COLS_PREGUNTA + 1:]).rstrip()
        assert g1 == l1, 'P%d L1 leida «%s» != «%s»' % (i + 1, g1, l1)
        assert g2 == l2, 'P%d L2 leida «%s» != «%s»' % (i + 1, g2, l2)

    for i, (_n, _l1, _l2, o1, o2, o3, _jp) in enumerate(QUIZ):
        a = lee(i + 42)
        for k, op in enumerate((o1, o2, o3)):
            cel = rom[a + k * 8:a + (k + 1) * 8]
            assert cel[0] == RELLENO, \
                'P%d op%d: falta la sangria del cursor' % (i + 1, k + 1)
            g = ''.join(rv.get(b, '') for b in cel).strip()
            assert g == op, 'P%d op%d leida «%s» != «%s»' % (
                i + 1, k + 1, g, op)

    # -- las respuestas correctas siguen apuntando a lo mismo -------------
    corr = rom[0x11CD0:0x11CD0 + 40]
    assert list(corr) == list(original[0x11CD0:0x11CD0 + 40]), \
        'se ha tocado la tabla de respuestas correctas'
    assert all(c < 3 for c in corr), 'la tabla de correctas esta corrupta'

    # -- cero japones en la zona ------------------------------------------
    # OJO: comparar rom[i]==jp[i] NO sirve. Los bytes de nuestro charset
    # pisan el rango katakana ($BC es «é» aqui y «シ» alli), asi que da
    # falsos positivos. Lo que de verdad prueba que no queda japones es
    # que la zona entera este cubierta por bloques nuestros y que la
    # relectura por puntero (arriba) devuelva el texto castellano exacto.
    cubierto = bytearray(ZONA_FIN - ZONA_INI)
    q = ZONA_INI
    for _t, b in bloques:
        for k in range(len(b)):
            cubierto[q - ZONA_INI + k] = 1
        q += len(b)
    for i in range(q, ZONA_FIN):
        assert rom[i] == RELLENO, 'basura sin limpiar en %06X' % i
        cubierto[i - ZONA_INI] = 1
    assert all(cubierto), 'hay huecos sin reescribir en la zona del quiz'

    # -- el NOP y el rotulo ------------------------------------------------
    assert rom[JSR_SOBRA:JSR_SOBRA + 3] == NOP3
    assert b'Taketori' not in bytes(
        rom[0x1F800:0x1F900]), 'queda «Taketori» en los rotulos'

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  1. JSR $DD42 de %06X -> NOP NOP NOP  (adios al «Vuelo.»)' %
          JSR_SOBRA)
    print('  2. «Aldea Bambú» en rotulo, menu RUN y dialogo de la aldeana')
    print('  3. quiz: %d B de %d disponibles, sobran %d' %
          (total, hueco, hueco - total))


if __name__ == '__main__':
    main()
