#!/usr/bin/env python3
"""build_v318.py - Menu RUN: destinos, verbos y la linea del ermitanyo.

QUE ENTRA
---------
1. Los **10 destinos** del teletransporte, compartidos por las DOS tablas.
2. Los verbos **Usar** y **Dejar**.
3. La **linea del ermitanyo** con el marcador `$00` de sustitucion.

LAS DOS TABLAS COMPARTEN CADENAS
--------------------------------
    A)  tabla 0x43712 (14 entradas)  -> el MENU de destinos
    B)  tabla 0x4379D ( 9 entradas)  -> el rotulo AL VIAJAR

La tabla A **ya comparte**: sus entradas [0] y [3] apuntan las dos a
`$B72E`. O sea que el motor no exige cadenas distintas. Apuntando las dos
tablas a las mismas 10 cadenas, el coste se parte por dos:

    presupuesto 0x43737..0x4380A   211 B
    lo que se escribe               95 B     sobran 116 B

Con eso no hacen falta abreviaturas por espacio. El unico limite es el
ancho: la ventana mide **8 celdas exactas** (medido sobre la lista B, que
centra con espacios y da 8 justas en todas sus entradas).

DIFERENCIA ENTRE LAS DOS TABLAS
-------------------------------
La B llevaba los nombres centrados a mano con espacios. Al compartir
cadenas se pierde ese centrado: los nombres quedaran alineados a la
izquierda, que es el criterio del proyecto para texto latino.

CUIDADO CON EL BYTE DE COMANDO
------------------------------
Cada cadena empieza por `$01` o `$02` (elige el juego de glifos). Las
japonesas con `\\` interno usaban `$02`; en castellano todas van con `$01`.
"""
import hashlib
import struct
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode, RELLENO   # noqa: E402

BASE = 'roms/momotaro_es_v317.pce'
SALIDA = 'roms/momotaro_es_v318.pce'
MD5_BASE = 'ed42393598926fe107e11a6121c32099'

TABLA_A = 0x43712      # 14 entradas, ventana $A000
TABLA_B = 0x4379D      # 9 entradas
ZONA_INI = 0x43737     # donde empiezan los verbos japoneses
ZONA_FIN = 0x4380A     # fin de la segunda lista
ANCHO_VENTANA = 8

# Los 10 destinos, en el orden de la tabla
DESTINOS = [
    'Partida',      # tabidachi no mura
    'Florecer',     # hanasaka no mura
    'Kintaro',      # kintarou no mura
    'Dormilón',     # netarou no mura
    'Urashima',     # urashima no mura
    'Kachi',        # kachikachiyama no mura
    'Issun',        # issunboushi mura
    'Bambú',        # taketori no mura
    'Ogros',        # onigashima
    'Jizo',         # saigo no jizo
]
VERBOS = ['Usar', 'Dejar']

# La linea del ermitanyo: 2 lineas x 16, con $00 de sustitucion en L2
ERMITANYO = 0x4AE18
ERM_L1 = '¡Nada de eso!'
ERM_L2_PRE = 'Soy '        # antes del nombre insertado
ERM_L2_POST = '.'          # despues

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x16000, 0x18000, 'banco $0B: tablas de los vitores'),
    (0x1E000, 0x20000, 'banco $0F: tabla de escenas (arreglo v314)'),
    (0x48000, 0x4A000, 'banco $24: tiendas, guion, vitores'),
    (0x4AE3B, 0x4AEE6, 'ermitanyo bloques 0-1 y tecnicas'),
    (0x4AEE6, 0x4C000, 'el QUIZ'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v317'

    # ---- comprobaciones PREVIAS -----------------------------------------
    for n in DESTINOS:
        assert len(n) <= ANCHO_VENTANA, \
            '«%s» son %d celdas, la ventana mide %d' % (n, len(n), ANCHO_VENTANA)

    # la tabla A ya comparte cadenas: [0] y [3] iguales. Se comprueba.
    a0 = struct.unpack('<H', rom[TABLA_A:TABLA_A + 2])[0]
    a3 = struct.unpack('<H', rom[TABLA_A + 6:TABLA_A + 8])[0]
    assert a0 == a3, 'la tabla A ya no comparte [0] y [3]; revisar el supuesto'

    # ---- construir el bloque nuevo --------------------------------------
    bloque = bytearray()
    off_verbo = {}
    for v in VERBOS:
        off_verbo[v] = ZONA_INI + len(bloque)
        bloque += b'\x01' + encode(v) + b'\x00'
    off_dest = []
    for n in DESTINOS:
        off_dest.append(ZONA_INI + len(bloque))
        bloque += b'\x01' + encode(n) + b'\xff'

    presupuesto = ZONA_FIN - ZONA_INI
    assert len(bloque) <= presupuesto, \
        'ocupa %d B y hay %d' % (len(bloque), presupuesto)
    sobra = presupuesto - len(bloque)
    rom[ZONA_INI:ZONA_FIN] = bytes(bloque) + bytes([RELLENO]) * sobra

    # ---- repuntar las DOS tablas a las mismas cadenas -------------------
    def cpu(off):
        """offset ROM -> direccion CPU en ventana $A000, banco $21."""
        assert 0x42000 <= off < 0x44000
        return 0xA000 + (off - 0x42000)

    # tabla A: [0][3] = «no se puede usar» (se deja como esta, ya traducida)
    #          [1] = Usar, [2] = Dejar, [4..13] = los 10 destinos
    rom[TABLA_A + 2:TABLA_A + 4] = struct.pack('<H', cpu(off_verbo['Usar']))
    rom[TABLA_A + 4:TABLA_A + 6] = struct.pack('<H', cpu(off_verbo['Dejar']))
    for i, o in enumerate(off_dest):
        p = TABLA_A + (4 + i) * 2
        rom[p:p + 2] = struct.pack('<H', cpu(o))

    # tabla B: 9 entradas -> los 9 primeros destinos (no lleva «Jizo»)
    for i in range(9):
        p = TABLA_B + i * 2
        rom[p:p + 2] = struct.pack('<H', cpu(off_dest[i]))

    # ---- la linea del ermitanyo -----------------------------------------
    l1 = encode(ERM_L1) + bytes([RELLENO]) * (16 - len(ERM_L1))
    l2 = encode(ERM_L2_PRE) + b'\x00' + encode(ERM_L2_POST)
    # el $80 final del bloque original es el terminador: se conserva
    assert original[ERMITANYO + 34] == 0x80, 'no esta el $80 terminador'
    nuevo = l1 + l2
    assert len(nuevo) <= 34, 'la linea del ermitanyo ocupa %d B' % len(nuevo)
    nuevo += bytes([RELLENO]) * (34 - len(nuevo)) + b'\x80'
    assert len(nuevo) == 35
    rom[ERMITANYO:ERMITANYO + 35] = nuevo

    # ---- VERIFICACION: seguir los punteros como hace el motor -----------
    for i in range(14):
        p = struct.unpack('<H', rom[TABLA_A + i * 2:TABLA_A + i * 2 + 2])[0]
        assert 0xA000 <= p < 0xC000, 'tabla A[%d] = $%04X fuera de ventana' % (i, p)
        o = 0x42000 + p - 0xA000
        assert rom[o] in (0x01, 0x02), 'tabla A[%d] no apunta a comando' % i
    for i in range(9):
        p = struct.unpack('<H', rom[TABLA_B + i * 2:TABLA_B + i * 2 + 2])[0]
        assert 0xA000 <= p < 0xC000, 'tabla B[%d] fuera de ventana' % i
        o = 0x42000 + p - 0xA000
        assert rom[o] == 0x01, 'tabla B[%d] no apunta a comando' % i

    # releer los 10 destinos desde la tabla A y comparar con lo pedido
    for i, esperado in enumerate(DESTINOS):
        p = struct.unpack('<H', rom[TABLA_A + (4 + i) * 2:TABLA_A + (4 + i) * 2 + 2])[0]
        o = 0x42000 + p - 0xA000
        e = rom.find(b'\xff', o)
        assert rom[o + 1:e] == encode(esperado), \
            'destino %d releido no coincide' % i
    # y desde la B
    for i in range(9):
        p = struct.unpack('<H', rom[TABLA_B + i * 2:TABLA_B + i * 2 + 2])[0]
        o = 0x42000 + p - 0xA000
        e = rom.find(b'\xff', o)
        assert rom[o + 1:e] == encode(DESTINOS[i]), \
            'destino %d de la tabla B no coincide' % i

    # los verbos
    for v in VERBOS:
        o = off_verbo[v]
        e = rom.find(b'\x00', o)
        assert rom[o + 1:e] == encode(v), 'verbo %s no cuadra' % v

    # el ermitanyo: el $00 de sustitucion sigue ahi
    seg = rom[ERMITANYO:ERMITANYO + 35]
    assert seg.count(0x00) == 1, 'el marcador $00 no es unico'
    assert seg[-1] == 0x80, 'se perdio el terminador $80'

    # ---- zonas intactas --------------------------------------------------
    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  bloque de textos: %d B de %d, %d de relleno' %
          (len(bloque), presupuesto, sobra))
    for v in VERBOS:
        print('    %06X  %s' % (off_verbo[v], v))
    for o, n in zip(off_dest, DESTINOS):
        print('    %06X  %-10s %d celdas' % (o, n, len(n)))
    print()
    print('  ermitanyo %06X: |%s| / |%s<<T>>%s|' %
          (ERMITANYO, ERM_L1, ERM_L2_PRE, ERM_L2_POST))


if __name__ == '__main__':
    main()
