#!/usr/bin/env python3
"""v308 = v307 + la posada que faltaba + «Cura ambos» concretado.

Dos cosas, las dos vistas por David en pantalla:

1) LA TABLA DE TIENDAS TIENE NUEVE ENTRADAS, NO OCHO.
   `0x10854` + 9*12 = `0x108C0`. La novena (`0x108B4`) es la posada de 100
   monedas. Sus ranuras [1]-[5] comparten puntero con las otras posadas y
   por eso ya salian traducidas; la ranura [0] (`$4C57`, ROM 0x48C57)
   tiene texto propio y seguia en japones.
   Error mio: di por hecho que eran 8 sin comprobar donde acaba la tabla.

2) «Cura ambos.» es ambiguo. El japones dice
   `カラダト ワザガソレゾレ 1コ カイフク` = «recupera 1 de cuerpo y 1 de
   tecnica». Se concreta a «Cura vida y momo», que cabe en 16.

Formato: 2 lineas de 16, relleno $A0 (ver build_v307.py).
"""
import hashlib, sys, zlib
sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE

SRC = 'roms/momotaro_es_v307.pce'
JP  = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v308.pce'

TABLA   = 0x10854
MAESTRA = 0x10929
RELLENO = 0xA0
ALIAS   = {0x5B: 0xA2, 0x5D: 0xA3, 0x5E: 0xB0}


def cod(s):
    out = bytearray()
    for ch in s:
        if ch not in CHAR_TO_CODE:
            raise ValueError('caracter no soportado: %r' % ch)
        b = CHAR_TO_CODE[ch]
        out.append(ALIAS.get(b, b))
    if len(out) > 16:
        raise ValueError('%d caracteres: %r' % (len(out), s))
    return bytes(out) + bytes([RELLENO] * (16 - len(out)))


rom  = bytearray(open(SRC, 'rb').read())
jp   = open(JP, 'rb').read()
orig = bytes(rom)
assert len(rom) == 512 * 1024
assert hashlib.md5(orig).hexdigest() == '442161df13429b5af286cebbc6749dc1', 'la base no es la v307'

# --- 1. la novena tienda ---------------------------------------------------
# comprobar que la entrada 8 de la tabla es plausible y la 9 ya no
def ranuras(t):
    o = TABLA + t * 12
    return [rom[o + i * 2] | (rom[o + i * 2 + 1] << 8) for i in range(6)]

assert all(0x4000 <= w < 0x6000 for w in ranuras(8)), 'la tienda 8 no es valida'
assert not all(0x4000 <= w < 0x6000 for w in ranuras(9)), 'hay una decima tienda'
POSADA100 = ranuras(8)[0]
assert POSADA100 == 0x4C57, 'la ranura [0] de la tienda 8 no es $4C57'
R = 0x48000 + (POSADA100 - 0x4000)
assert rom[R:R + 32] == jp[R:R + 32], 'la posada 100 ya estaba tocada'

rom[R:R + 32] = cod('¡Pío, pío!') + cod('Posada: 100.')

# las otras tres posadas dicen lo mismo con su cifra: comprobacion cruzada
for t, cifra in ((5, '300'), (6, '500'), (7, '1000')):
    w = ranuras(t)[0]
    r = 0x48000 + (w - 0x4000)
    assert rom[r:r + 16] == cod('¡Pío, pío!'), 'la posada %s no cuadra' % cifra
    assert rom[r + 16:r + 32] == cod('Posada: %s.' % cifra), 'la posada %s no cuadra' % cifra

# --- 2. la descripcion del Banquete ---------------------------------------
o = MAESTRA + 2 * 4
w = rom[o] | (rom[o + 1] << 8)
RB = 0x48000 + (w - 0x4000)
assert rom[RB:RB + 16] == cod('Banquete:'), 'la entrada 2 no es el Banquete'
assert rom[RB + 16:RB + 32] == cod('Cura ambos.'), 'la 2a linea no es la esperada'
rom[RB + 16:RB + 32] = cod('Cura vida y momo')

# --- zonas intactas --------------------------------------------------------
permitido = set(range(R, R + 32)) | set(range(RB + 16, RB + 32))
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and i not in permitido]
assert not fuera, 'cambios fuera de zona: %s' % [hex(x) for x in fuera[:10]]
assert rom[TABLA:TABLA + 108] == orig[TABLA:TABLA + 108], 'tabla de tiendas tocada'
assert rom[MAESTRA:MAESTRA + 96] == orig[MAESTRA:MAESTRA + 96], 'tabla maestra tocada'
assert rom[0x48401:0x4847D] == jp[0x48401:0x4847D], 'bloque de vitores tocado'
assert rom[0x2C05A:0x2C319] == orig[0x2C05A:0x2C319], 'stream del CG tocado'
assert rom[0x3D660:0x3E000] == orig[0x3D660:0x3E000], 'glifos tocados'
assert rom[0x1F9C4:0x1FA00] == orig[0x1F9C4:0x1FA00], 'rotulo/Game Over tocado'
assert rom[0x47CFB] == 0xFF, 'terminador del abuelo pisado'
# el texto que va DESPUES de la posada no se ha desbordado.
# OJO: no se compara contra la japonesa, porque ahi ya hay texto nuestro de
# una version anterior («¡Ganas el Onigiri!»). Se compara contra la BASE.
assert rom[R + 32:R + 48] == orig[R + 32:R + 48], 'desbordada la posada 100'

open(DST, 'wb').write(rom)

# --- relectura por el puntero, como hace el motor -------------------------
v = open(DST, 'rb').read()
inv = {val: k for k, val in CHAR_TO_CODE.items()}
T = dict(inv); T[0xA2], T[0xA3], T[0xB0], T[0xDE] = 'b', 'c', 'p', 'Ç'
des = lambda b: ''.join('' if x == RELLENO else T.get(x, '{%02X}' % x) for x in b)

print('las NUEVE tiendas, releidas por la tabla:')
for t in range(9):
    o = TABLA + t * 12
    w = v[o] | (v[o + 1] << 8)
    r = 0x48000 + (w - 0x4000)
    print('  tienda %d [0] $%04X  |%s| / |%s|' % (t, w, des(v[r:r + 16]), des(v[r + 16:r + 32])))
assert des(v[R:R + 16]) == '¡Pío, pío!' and des(v[R + 16:R + 32]) == 'Posada: 100.'

o = MAESTRA + 2 * 4
w = v[o] | (v[o + 1] << 8)
r = 0x48000 + (w - 0x4000)
print()
print('Banquete: |%s| / |%s|' % (des(v[r:r + 16]), des(v[r + 16:r + 32])))
assert des(v[r + 16:r + 32]) == 'Cura vida y momo'

for x in (R, RB):
    assert 0x8B not in v[x:x + 32], 'hay un $8B (©)'
print('sin ningun $8B')

b = bytes(v)
print()
print('%s  (%d bytes cambiados)' % (DST, sum(1 for i in range(len(b)) if b[i] != orig[i])))
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xFFFFFFFF))
