#!/usr/bin/env python3
"""build_v314.py - Repara la tabla de ESCENAS 0x1ED6E.

EL BUG (v237, mio)
------------------
En la v237 crei que `0x1ED6E` era una tabla de punteros de TEXTO y repunte
sus registros [5][6][7] para partir el dialogo del Jizo. Es una tabla de
**datos de escena**: posiciones y tipos de los elementos activos de cada
mundo. Al apuntarla a relleno, la subfase del jefe de Kintaro se queda sin
jefe y sin objetos, y Momotaro entra con coordenadas invalidas.

POR QUE ME CONFUNDI (norma 288)
-------------------------------
Dos bancos distintos dan la MISMA direccion CPU:

    ROM 0x48E2A  banco $24  offset 0xE2A  ventana $4000 -> $4E2A   TEXTO
    ROM 0x1EE2A  banco $0F  offset 0xE2A  ventana $4000 -> $4E2A   ESCENAS

Busque "quien apunta a $4E2A", encontre `0x1ED76` y di por hecho que era el
puntero del texto. Nunca comprobe el CONTENIDO de lo apuntado: son bytes
pequenyos (`04 1a 40 00 00 07 01 01`), no katakana.

EL TEXTO DEL JIZO NO SE PIERDE
------------------------------
Verificado: el dialogo vive entero en `0x48E2A`, 235 B, con terminador `$00`
en `0x48F15`, y acaba en «En fin, ve con cuidado.». Lo lee la tabla `$CCF1`
del banco $0E (`$CC0C: LDA $4E2A,Y`), que NUNCA se toco.

La supuesta "parte 2" de `0x4BF70` esta HUERFANA: su unico apuntador era
`0x1ED78`, la tabla de escenas. Nunca se ha mostrado en pantalla. Se deja
en la ROM (es relleno inocuo) para no tocar mas de lo necesario.

EL ARREGLO
----------
6 bytes en `0x1ED78..0x1ED7D`, restaurados a los valores japoneses.
Nada mas. No se toca el banco $24 (textos), ni el $25, ni el menu SI/NO.
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v313.pce'
JAP = 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = 'roms/momotaro_es_v314.pce'

TABLA = 0x1ED6E          # tabla de escenas, 8 words, banco $0F
OFF = 0x1ED78            # registros [5][6][7]
N = 6

# Valores japoneses correctos y los rotos que dejo la v237
BUENOS = bytes.fromhex('67 4e 98 4e c9 4e')
ROTOS = bytes.fromhex('70 7f e7 7f e7 7f')

# Zonas que NO se pueden mover ni un byte
INTACTAS = [
    (0x48000, 0x4A000, 'banco $24: tiendas, guion, vitores'),
    (0x4A000, 0x4C000, 'banco $25: creditos, quiz, hueco del Jizo'),
    (0x41900, 0x41920, 'menu SI/NO $990D'),
    (0x0F3D9, 0x0FE2B, 'CG del menu SELECT'),
    (0x1BBB9, 0x1BFDC, 'tabla del menu SELECT'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    jap = open(JAP, 'rb').read()
    original = bytes(rom)

    # --- asserts PREVIOS -------------------------------------------------
    assert len(rom) == 524288, 'tamanyo de ROM inesperado'
    assert hashlib.md5(original).hexdigest() == \
        '5fccbebdc0520496dd6135dcd6835527', 'la base no es la v313'
    assert rom[OFF:OFF + N] == ROTOS, \
        'los 6 bytes no son los rotos: %s' % rom[OFF:OFF + N].hex(' ')
    assert jap[OFF:OFF + N] == BUENOS, \
        'la japonesa no trae los valores esperados'

    # el texto del Jizo tiene que estar entero ANTES de tocar nada
    assert rom[0x48F15] == 0x00, 'el terminador del Jizo no esta en 0x48F15'
    jizo_antes = bytes(rom[0x48E2A:0x48F16])
    assert len(jizo_antes) == 236

    # --- el cambio: 6 bytes ----------------------------------------------
    rom[OFF:OFF + N] = BUENOS

    # --- verificacion SIGUIENDO EL PUNTERO como hace el motor (norma 287)
    # $4836: LDA $3B00 / ASL / TAX / LDA $4D6E,X -> $14/$15 / LDA ($14)
    # MPR2 = banco $0F  =>  CPU $4000..$5FFF  =  ROM 0x1E000..0x20000
    for mundo in range(8):
        x = mundo * 2
        ptr = rom[TABLA + x] | (rom[TABLA + x + 1] << 8)
        assert 0x4000 <= ptr < 0x6000, \
            'mundo %d: $%04X fuera de la ventana MPR2 del banco $0F' % (mundo, ptr)
        off = 0x1E000 + ptr - 0x4000
        primero = rom[off]
        assert primero != 0xFF, \
            'mundo %d: el registro empieza en $FF (relleno)' % mundo
        # $3B02 = primer byte; en el state bueno de David valia $03
        assert 0 < primero < 0x40, \
            'mundo %d: primer byte $%02X no parece dato de escena' % (mundo, primero)

    # el mundo 5 (subfase del jefe de Kintaro) es el del bug
    ptr5 = rom[TABLA + 10] | (rom[TABLA + 11] << 8)
    assert ptr5 == 0x4E67, 'el registro [5] no quedo en $4E67'
    assert rom[0x1E000 + 0x4E67 - 0x4000] == 0x03, \
        '$3B02 no valdra $03, que es lo que muestra el state bueno de David'

    # --- zonas intactas ---------------------------------------------------
    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'se toco una zona intacta: %s' % nombre

    # el dialogo del Jizo, byte a byte
    assert bytes(rom[0x48E2A:0x48F16]) == jizo_antes, 'el Jizo cambio'

    # --- solo 6 bytes en toda la ROM --------------------------------------
    dif = [i for i in range(len(rom)) if rom[i] != original[i]]
    assert dif == list(range(OFF, OFF + N)), \
        'cambiados %d bytes, se esperaban los 6 de la tabla' % len(dif)

    # --- y ahora identico a la japonesa en esa tabla ----------------------
    assert bytes(rom[TABLA:TABLA + 16]) == jap[TABLA:TABLA + 16], \
        'la tabla no quedo igual que la japonesa'

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados sobre la v313' % len(dif))
    print()
    print('  tabla de escenas 0x1ED6E:')
    for m in range(8):
        p = d[TABLA + m * 2] | (d[TABLA + m * 2 + 1] << 8)
        print('    mundo %d -> $%04X  ROM %06X  primer byte $%02X'
              % (m, p, 0x1E000 + p - 0x4000, d[0x1E000 + p - 0x4000]))


if __name__ == '__main__':
    main()
