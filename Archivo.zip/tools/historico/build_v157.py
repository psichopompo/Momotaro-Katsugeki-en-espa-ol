"""build_v157.py - bocadillos de dialogo en HORIZONTAL.

Parte de test_ryo_v149.pce (MD5 9249fcefd2f2253e5d454cb1c650260d).

EL MOTOR (banco $20, ROM 0x40000, logico $8000)
------------------------------------------------
    $9807   despachador:  $00 fin,  $3B nueva columna,  $5C nombre propio
    $98A3   control $3B:  INC $3657 (contador de columna), CMP #$03 -> pagina
    $984D   dibuja:       indice = columna*24 + fila + 6  -> buffer $3667
    $9B7C   volcado:      recorre 36 celdas (CPX #$24) y para cada una lee
                            $9BBD,Y  -> direccion VRAM   (2 B por celda)
                            $9C05,X  -> cuadrante 0..3   (1 B por celda)
    $9D33   escribe el cuadrante en VRAM con MAWR

GEOMETRIA MEDIDA
----------------
Direccion final = tabla + 8 words si (cuadrante & 2). El bit 0 del
cuadrante elige la mitad izquierda o derecha del tile.

    18 direcciones distintas x 2 mitades = 36 celdas

El texto japones llena COLUMNAS de 6 celdas, de derecha a izquierda:

    celdas  0-5   columna 1 (la mas a la derecha)
    celdas  6-11  columna 2
    ...
    celdas 30-35  columna 6 (la mas a la izquierda)

EL CAMBIO
---------
El layout esta en DATOS. Basta permutar las dos tablas para que la celda
0 sea la de arriba-izquierda y se avance en horizontal:

    orden viejo   celda i  ->  columna i//6, fila i%6
    orden nuevo   celda i  ->  fila    i//6, columna i%6

Es decir, transponer la matriz 6x6 e invertir el eje horizontal (porque
el japones va de derecha a izquierda y el castellano al reves).

NO se toca el guion, ni los separadores $3B, ni la aritmetica del motor:
solo cambia DONDE cae cada caracter.
"""
import os
import sys
import struct
import hashlib
import zlib

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(RAIZ, 'roms', 'test_ryo_v149.pce')
SALIDA = os.path.join(RAIZ, 'roms', 'test_horizontal_v157.pce')
MD5_BASE = '9249fcefd2f2253e5d454cb1c650260d'

TAB_DIR = 0x41BBD      # 36 words: direccion VRAM
TAB_CUA = 0x41C05      # 36 bytes: cuadrante
N = 36


def main():
    rom = bytearray(open(BASE, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v149'

    # leer las tablas originales
    viejo = []
    for i in range(N):
        w = struct.unpack('<H', rom[TAB_DIR + i * 2:TAB_DIR + i * 2 + 2])[0]
        q = rom[TAB_CUA + i]
        viejo.append((w, q))

    assert viejo[0] == (0x6870, 1), 'la tabla no es la esperada: %s' % (viejo[0],)
    assert rom[0x41BB8] == 0xE0 and rom[0x41BB9] == 0x24, 'el bucle no es CPX #$24'

    # ---- geometria REAL, medida ----
    # Cada celda cae en (grupo, x, y):
    #   grupo = cual de los 3 bloques de 3 tiles apilados
    #   +8 words   = bajar 8 px dentro del tile
    #   +$80 words = bajar al siguiente tile (16 px)
    #   cuadrante bit0: 0 = mitad derecha, 1 = mitad izquierda
    #
    # El japones llena celdas 0-5 = columna vertical completa, y avanza de
    # DERECHA a IZQUIERDA. En pantalla los grupos van, de izquierda a
    # derecha: grupo2, grupo1, grupo0.
    GRUPO = {0x6870: 0, 0x68F0: 0, 0x6970: 0,
             0x69F0: 1, 0x6A70: 1, 0x6AF0: 1,
             0x69B0: 2, 0x6A30: 2, 0x6AB0: 2}
    RAIZ_G = {0: 0x6870, 1: 0x69F0, 2: 0x69B0}
    ORDEN_X = {2: 0, 1: 1, 0: 2}      # grupo -> posicion horizontal

    coord = {}
    for i, (w, q) in enumerate(viejo):
        g = GRUPO[w]
        y = ((w - RAIZ_G[g]) // 0x80) * 2 + (1 if q & 2 else 0)
        # dentro del grupo: bit0=1 -> mitad derecha
        x = ORDEN_X[g] * 2 + (1 if q & 1 else 0)
        coord[i] = (x, y)
        assert 0 <= x < 6 and 0 <= y < 6

    assert len(set(coord.values())) == N, 'dos celdas en la misma posicion'

    # nueva tabla: la celda k debe caer en fila k//6, columna k%6
    porpos = {v: k for k, v in coord.items()}
    nuevo = [None] * N
    for k in range(N):
        fila, col = k // 6, k % 6
        nuevo[k] = viejo[porpos[(col, fila)]]

    assert sorted(nuevo) == sorted(viejo), 'la permutacion pierde celdas'
    assert len(set(nuevo)) == N, 'hay celdas repetidas'

    for i, (w, q) in enumerate(nuevo):
        rom[TAB_DIR + i * 2:TAB_DIR + i * 2 + 2] = struct.pack('<H', w)
        rom[TAB_CUA + i] = q

    # verificacion: releer y comprobar que la celda 0 es arriba-izquierda
    w0 = struct.unpack('<H', rom[TAB_DIR:TAB_DIR + 2])[0]
    q0 = rom[TAB_CUA]
    assert (w0, q0) == viejo[porpos[(0, 0)]], 'la celda 0 no es arriba-izquierda'

    open(SALIDA, 'wb').write(bytes(rom))
    print('escrito', SALIDA)
    print('MD5  ', hashlib.md5(rom).hexdigest())
    print('SHA1 ', hashlib.sha1(rom).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
    print()
    print('tablas permutadas: %d celdas, 72 bytes' % N)
    print('  celda 0: $%04X cuad %d' % (w0, q0))
    print('  formato: 6 filas x 6 caracteres, izquierda -> derecha')


if __name__ == '__main__':
    main()
