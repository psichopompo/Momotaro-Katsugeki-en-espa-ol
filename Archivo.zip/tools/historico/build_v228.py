#!/usr/bin/env python3
"""
build_v228.py - el bocadillo del abuelo, terminado. Desde la v225.

Rehace la v227 entera (norma 107: no se parchean parches) con las cuatro
correcciones que pidio David tras probarla:

> - Hay que mover el bocadillo del abuelo 8 px a la derecha.
> - El rabillo 3 px hacia abajo.
> - El bocadillo no tiene marco inferior ni esquinas inferiores.
> - Seguimos sin ver las traducciones insertadas.

=====================================================================
EL MARCO INFERIOR: por que faltaba
=====================================================================
**El marco NO es un sprite aparte: esta DIBUJADO dentro de las celdas de
texto.** Volcando el CG de la v225:

```
1C4..1CB  (fila 1)  borde SUPERIOR en la fila 1 de la celda
1CC..1D3  (fila 2)  sin bordes, solo texto
1D4..1DB  (fila 3)  borde INFERIOR en la fila 14 de la celda
1DC       lateral con borde arriba Y abajo
1DD       lateral con borde arriba Y abajo
1A0/1A1   laterales SIN bordes
```

En la v227 puse la fila 2 del abuelo en `1CB..1D1`, celdas que **no tienen
borde inferior**. De ahi que el bocadillo saliera abierto por abajo.

Y hay un dato que lo cambia todo: **`1D4..1DB` no reciben texto**. La tabla
de volcado `$9BBD` solo cubre `1C4..1D3` (16 celdas = 2 filas). Comprobado
en los states: esas celdas tienen 0 px de color 15.

  -> El bocadillo compartido es **2 filas de texto + 1 fila de solo borde**.
     El del abuelo tiene que ser igual.

=====================================================================
LA GEOMETRIA QUE SI CABE
=====================================================================
Tres filas de sprites (2 de texto + 1 de borde) son 48 px, y con el ancla
del abuelo eso llega a `y=90`, dentro de la franja de los ogros (que gastan
12 ranuras desde `y=81`).

La salida es **subir el conjunto**. Medido sobre el state:

```
dYs            pico   y_top..y_bot
[20,36,52]      21     43..90     <- la v227, SE PASA
[12,28,44]      17     35..82     se pasa por 1
[8,24,40]       13     31..78     OK, margen 3
[4,20,36]       13     27..74     OK, margen 3
[0,16,32]       16     23..70     OK justo (roza el HUD)
```

Se elige **[8,24,40]**: pico 13, y el borde inferior acaba en `y=78`,
3 px antes de los ogros.

=====================================================================
LOS 23 TEXTOS
=====================================================================
Tabla `$C969` -> ROM `0x16969`, 23 punteros al banco `$24`, terminador
`$A0`. Se reescriben en el hueco que dejan (los japoneses ocupan mas).

Nombres de objeto: los que YA estan en el menu, elegidos por David segun lo
que cabia (`Onigiri`, `Manjar`, `Banquete`, `Dango`, `Pedos`, `Solar`,
`Glacial`, `Capa`, `Bonzo`). Moneda: **ryo/ryos**.

Uso:  python3 tools/build_v228.py
"""
import hashlib
import zlib
import struct
import subprocess
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime
from charset_oficial import CHAR_TO_CODE

BASE = 'roms/momotaro_es_v225.pce'
SALIDA = 'roms/momotaro_es_v228.pce'
IPS = 'parches/momotaro_v228.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'a1ecc337b9bb1e4f5c5b44dcad45744e'

BASE_PATRON = 0x170
LISTA = 0x47C02
TERMINADOR = 0x47C98
HUECO = 0x47C99
GLACIAR = 0x430C1
PTR_LO = 0x41AA0
PTR_HI = 0x41AA4
TABLA_TXT = 0x16969             # los 23 punteros del abuelo
BANCO24 = 0x48000 - 0x4000

DX_ABUELO = +8                  # David: 8 px a la derecha
RAB_DX = -10
RAB_DY = +1 + 3                 # v227 pedia +1; ahora 3 mas

# dY de las tres filas: 2 de texto + 1 de borde inferior
DY_FILAS = [8, 24]
DY_BORDE = 40

TEXTOS = [
    'Coges el Onigiri', 'Coges el Manjar', 'Coges el Banquete',
    'Coges un Dango', 'Coges los Pedos', 'Coges la Solar',
    'Coges la Glacial', 'Coges la Capa',
    'Ganas 100 ryos', 'Ganas 50 ryos', 'Ganas 30 ryos', 'Ganas 10 ryos',
    'No puedes llevar mas', 'El perro te acompana',
    'El faisan te acompana', 'El mono te acompana',
    'Coges el Caparazon', 'Coges el Bonzo',
    'Ganas 80 ryos', 'Ganas 20 ryos',
    'Menudo idiota!', 'Sigue hacia arriba', 'Sigue a la derecha',
]

COLS = 14


def voraz(t, c):
    out, cur = [], ''
    for w in t.split():
        if not cur:
            cur = w
        elif len(cur) + 1 + len(w) <= c:
            cur += ' ' + w
        else:
            out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    return out


def codifica(lineas):
    """Lineas -> bytes, con $3B de salto y $A0 de terminador."""
    out = bytearray()
    for i, l in enumerate(lineas):
        if i:
            out.append(0x3B)
        for ch in l:
            if ch not in CHAR_TO_CODE:
                raise AssertionError('caracter no codificable: %r' % ch)
            out.append(CHAR_TO_CODE[ch])
    out.append(0xA0)
    return bytes(out)


def rota_izq(celda):
    w = struct.unpack('<64H', celda)
    src = [[0] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            b = 15 - x
            src[y][x] = ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
                | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)
    dst = [[0] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            dst[15 - x][y] = src[y][x]
    out = [0] * 64
    for y in range(16):
        for x in range(16):
            b = 15 - x
            v = dst[y][x]
            for pl in range(4):
                if v & (1 << pl):
                    out[pl * 16 + y] |= (1 << b)
    return struct.pack('<64H', *out)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v225'
    print('base %s  OK  (se rehace la v227 entera)' % BASE)
    assert rom[TERMINADOR] == 0xFF, 'no esta el terminador de la compartida'

    # ---- 1. Glaciar -> Glacial --------------------------------------
    assert bytes(rom[0x430BC:0x430C2]) == bytes(
        [0xAC, 0xA1, 0xA3, 0xA9, 0xA1, 0xB2]), 'no pone "laciar"'
    rom[GLACIAR] = 0xAC
    print('\n1. "Glaciar" -> "Glacial"')

    # ---- 2. el rabillo ----------------------------------------------
    ptr = rom[0x41C3D] | (rom[0x41C41] << 8)
    cnt = rom[0x41C4F] | (rom[0x41C50] << 8)
    CG = 0x3C000 + (ptr - 0x4000)
    CN = 0x3C000 + (cnt - 0x4000)
    n = rom[CN]
    f = Flujo(bytes(rom), CG)
    celdas = [b''.join(tile(f) for _ in range(4)) for _ in range(n)]
    fin = f.p
    prim = (rom[0x41C45] | (rom[0x41C4A] << 8)) // 64
    celdas[0x1AF - prim] = rota_izq(celdas[0x1AD - prim])
    stream = comprime(b''.join(celdas))
    hueco_cg = fin - CG
    if len(stream) > hueco_cg:
        extra = len(stream) - hueco_cg
        libre = 0
        o = CN - 1
        while rom[o] == 0xFF:
            libre += 1
            o -= 1
        assert libre >= extra + 8, 'no hay relleno delante del CG'
        ncg = CG - extra
        ncnt = ncg - 1
        assert all(b == 0xFF for b in rom[ncnt:CN]), 'zona ocupada'
        rom[ncnt] = n
        rom[ncg:ncg + len(stream)] = stream
        pn = 0x4000 + (ncg - 0x3C000)
        cn2 = 0x4000 + (ncnt - 0x3C000)
        rom[0x41C3D] = pn & 0xFF
        rom[0x41C41] = pn >> 8
        rom[0x41C4F] = cn2 & 0xFF
        rom[0x41C50] = cn2 >> 8
        CG = ncg
    else:
        rom[CG:CG + len(stream)] = stream
        rom[CG + len(stream):fin] = b'\xFF' * (hueco_cg - len(stream))
    f2 = Flujo(bytes(rom), CG)
    assert [b''.join(tile(f2) for _ in range(4))
            for _ in range(n)] == celdas, 'round-trip del CG'
    RAB = 0x41ADD
    p2 = rom[RAB + 4] | (rom[RAB + 5] << 8)
    o2 = 0x40000 + (p2 - 0x8000)
    dx = rom[o2 + 3] - 256 if rom[o2 + 3] > 127 else rom[o2 + 3]
    dy = rom[o2 + 4] - 256 if rom[o2 + 4] > 127 else rom[o2 + 4]
    rom[o2 + 3] = (dx + RAB_DX + DX_ABUELO) & 0xFF
    rom[o2 + 4] = (dy + RAB_DY) & 0xFF
    print('2. rabillo rotado; dX %d -> %d, dY %d -> %d'
          % (dx, dx + RAB_DX + DX_ABUELO, dy, dy + RAB_DY))

    # ---- 3. la lista del abuelo -------------------------------------
    ncel = COLS // 2                       # 7 celdas
    X0 = -(ncel * 16) // 2 + DX_ABUELO     # texto centrado, +8 a la derecha
    fila1 = [0x1C4 + k for k in range(ncel)]        # con borde superior
    fila2 = [0x1CC + k for k in range(ncel)]        # sin bordes
    borde = [0x1D4 + k for k in range(ncel)]        # con borde inferior

    regs = bytearray()
    nsp = 0
    for celdas_fila, dY, lat_i, lat_d in [
            (fila1, DY_FILAS[0], (0x1DC, 0x00), (0x1DC, 0x08)),
            (fila2, DY_FILAS[1], (0x1A0, 0x00), (0x1A1, 0x00)),
            (borde, DY_BORDE, (0x1DD, 0x00), (0x1DD, 0x08))]:
        for k, c in enumerate(celdas_fila):
            regs += bytes([c - BASE_PATRON, 0x0F, 0x00,
                           (X0 + k * 16) & 0xFF, dY & 0xFF])
            nsp += 1
        ci, fi = lat_i
        regs += bytes([ci - BASE_PATRON, 0x0F, fi,
                       (X0 - 8) & 0xFF, dY & 0xFF])
        cd, fd = lat_d
        regs += bytes([cd - BASE_PATRON, 0x0F, fd,
                       (X0 + ncel * 16 - 8) & 0xFF, dY & 0xFF])
        nsp += 2
    regs += b'\xFF'
    print('\n3. lista del abuelo: %d sprites' % nsp)
    print('   fila 1 (texto+borde sup) dY=%d   celdas %03X..%03X'
          % (DY_FILAS[0], fila1[0], fila1[-1]))
    print('   fila 2 (texto)           dY=%d   celdas %03X..%03X'
          % (DY_FILAS[1], fila2[0], fila2[-1]))
    print('   fila 3 (SOLO borde inf)  dY=%d   celdas %03X..%03X'
          % (DY_BORDE, borde[0], borde[-1]))
    print('   ancho %d px, dX %d..%d, %d ranuras por fila'
          % (8 + ncel * 16 + 8, X0 - 8, X0 + ncel * 16 + 7, ncel + 2))

    libre = 0
    while HUECO + libre < 0x48000 and rom[HUECO + libre] == 0xFF:
        libre += 1
    TABLA = HUECO
    LISTA_AB = HUECO + 8
    assert 8 + len(regs) <= libre, 'no cabe'
    p_comp = 0x7C02
    p_ab = 0x6000 + (LISTA_AB - 0x46000)
    p_tabla = 0x6000 + (TABLA - 0x46000)
    for k, p in enumerate([p_comp, p_comp, p_ab, p_comp]):
        rom[TABLA + k * 2] = p & 0xFF
        rom[TABLA + k * 2 + 1] = p >> 8
    rom[LISTA_AB:LISTA_AB + len(regs)] = regs

    # ---- 4. el selector ---------------------------------------------
    SEL = 0x1FA0
    while rom[SEL] != 0xFF:
        SEL += 1
    sel_addr = 0xE000 + SEL
    selector = bytes([
        0xAD, 0x8F, 0x36, 0x0A, 0xA8,                      # LDA $368F/ASL/TAY
        0xB9, p_tabla & 0xFF, p_tabla >> 8, 0x85, 0x53,
        0xB9, (p_tabla + 1) & 0xFF, (p_tabla + 1) >> 8, 0x85, 0x54,
        0x60,
    ])
    rom[SEL:SEL + len(selector)] = selector
    assert rom[PTR_LO - 1] == 0xA9 and rom[PTR_LO] == 0x02
    rom[PTR_LO - 1] = 0x20
    rom[PTR_LO] = sel_addr & 0xFF
    rom[PTR_LO + 1] = sel_addr >> 8
    for k in range(3, 8):
        rom[PTR_LO - 1 + k] = 0xEA
    print('\n4. selector en $%04X (relee $368F)' % sel_addr)

    # ---- 5. LOS 23 TEXTOS -------------------------------------------
    print('\n5. los 23 textos del abuelo')
    ptrs = [rom[TABLA_TXT + k * 2] | (rom[TABLA_TXT + k * 2 + 1] << 8)
            for k in range(23)]
    ini = BANCO24 + min(ptrs)
    finz = BANCO24 + max(ptrs)
    while rom[finz] != 0xA0 and rom[finz] != 0x00:
        finz += 1
    finz += 1
    disponible = finz - ini
    codificados = [codifica(voraz(t, COLS)) for t in TEXTOS]
    total = sum(len(c) for c in codificados)
    print('   zona 0x%05X..0x%05X = %d B ; necesito %d B'
          % (ini, finz, disponible, total))
    assert total <= disponible, 'los textos no caben'
    for t, c in zip(TEXTOS, codificados):
        li = voraz(t, COLS)
        assert len(li) <= 2, 'el texto %r necesita %d lineas' % (t, len(li))
    o = ini
    for k, c in enumerate(codificados):
        p = o - BANCO24
        rom[TABLA_TXT + k * 2] = p & 0xFF
        rom[TABLA_TXT + k * 2 + 1] = p >> 8
        rom[o:o + len(c)] = c
        o += len(c)
    if o < finz:
        rom[o:finz] = b'\xA0' * (finz - o)
    print('   escritos %d B, sobran %d' % (total, disponible - total))
    for k, t in enumerate(TEXTOS):
        print('     [%2d] %s' % (k, ' / '.join(voraz(t, COLS))))

    # ---- verificacion ------------------------------------------------
    tmp = '/tmp/_v228.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado')
    for off, nb, carga, nom in [(0x41A9B, 16, 0x9A9B, 'emisor'),
                                (SEL, len(selector), sel_addr, 'selector')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % off,
                            str(nb), '%X' % carga], capture_output=True,
                           text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    assert bytes(rom[LISTA:TERMINADOR + 1]) == base[LISTA:TERMINADOR + 1], \
        'SE HA TOCADO LA LISTA COMPARTIDA'
    print('\nlista compartida (aldeanos/Jizo): INTACTA, terminador en 0x%05X'
          % TERMINADOR)

    # releer los textos de la ROM
    print('\n--- textos releidos de la ROM')
    C2C = {v: k for k, v in CHAR_TO_CODE.items()}
    for k in range(23):
        p = rom[TABLA_TXT + k * 2] | (rom[TABLA_TXT + k * 2 + 1] << 8)
        o = BANCO24 + p
        s = ''
        while rom[o] != 0xA0:
            s += '/' if rom[o] == 0x3B else C2C.get(rom[o], '?')
            o += 1
        print('    [%2d] $%04X  %s' % (k, p, s))

    intactas = [('fuente', 0x3D660, 0x3E200),
                ('cabecera', 0x1FE0, 0x2000),
                ('guion', 0x48F91, 0x4A484)]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    print('%d bytes sobre la v225'
          % sum(1 for i in range(len(d)) if d[i] != base[i]))
    open(SALIDA, 'wb').write(d)

    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
