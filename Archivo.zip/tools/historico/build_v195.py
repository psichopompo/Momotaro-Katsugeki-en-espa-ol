#!/usr/bin/env python3
"""
build_v195.py - EL FALLO DE LAS LINEAS QUE FALTAN, el marco estrecho y el
                rabillo centrado.

=====================================================================
1. LAS LINEAS QUE DESAPARECEN  (el grave)
=====================================================================
David:
> «uno de los aldeanos de barba dice en la pagina 1: "Salta con el / boton I
>  y ataca / con el boton / II... Yo mismo". Y en la pagina 2, dice:
>  "manera...". Falta toda esa parte...»

El texto en la ROM esta **completo y bien maquetado**; el fallo es al
volcarlo. La culpa es de `calc_alto` ($9FE0), que puse en la v187:

```
LDA $3657 / LSR A / AND #$02
```

Eso elige la fila de celdas (A o B) a partir de la linea actual. Funciona
cuando la pagina se llena, pero **no cuando el dialogo se acaba a media
pagina**:

```
 $3657   LSR&2   fila     deberia
   2       0       A         A      fin de la mitad A     OK
   3       0       A         B      <-- 3 lineas: MAL
   4       2       B         B                            OK
```

Con tres lineas, la tercera se escribe en la mitad B del buffer, pero el
volcado final la manda a la **fila A**, machacando las dos primeras. De ahi
que solo se vea la ultima linea.

La formula correcta es `($3657 - 1) AND 2`. Comprobada para dialogos de 1 a
8 lineas, en los volcados intermedios y en el final: **correcta en los 15
casos**.

```
$9FE0  LDA $3657 / DEC A / AND #$02 / CLC / ADC $9BBE,Y / RTS
```

`DEC A` (`$3A`) ocupa un byte, asi que la rutina sigue midiendo 11 B.

=====================================================================
2. EL MARCO, 8 px MAS ESTRECHO POR LADO
=====================================================================
> «El bocadillo se podria estrechar al menos 8 px por cada lado.»

El ancho tiene que ser `32 + N*16 + 16` para que los bordes encajen:

```
N=7 -> 160 px  (lo que hay)
N=6 -> 144 px  (-8 por lado)   <- exacto lo que pide
```

Con 144 el texto (128 px) queda con **8 px de margen** a cada lado, y el
lateral derecho solapa 8 px sobre el ultimo relleno, asi que no aparece
hueco. Siguen siendo **10 ranuras** por scanline.

=====================================================================
3. EL RABILLO CENTRADO
=====================================================================
> «el rabillo sale a veces desplazado a la derecha... Tiene una version
>  espejada que en nuestra modificacion sera el mismo rabillo simetrico.
>  ¿Se podra hacer que ambas versiones apunten a las mismas coordenadas?»

Exacto, y es justo lo que pasa: las variantes 0 y 1 de `$9ADD` estan en
`dX=+7` y `dX=-9`, 16 px de diferencia, porque el rabillo original era
asimetrico y apuntaba a un lado u otro. **Con el simetrico las dos deben ir
al mismo sitio**: al centro del bocadillo.

```
marco de 144: centro en 0 ; el rabillo mide 16 -> dX = -8
variantes 0, 1 y 3:  +7 y -9  ->  -8
variante 2 (lateral del abuelo): INTACTA
```

Uso:  python3 tools/build_v195.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v194.pce'
SALIDA = 'roms/momotaro_es_v195.pce'
IPS = 'parches/momotaro_v195.ips'
MD5_BASE = 'e94a42f592a51917c3d0e1671930bff2'

CALC = 0x41FE0           # $9FE0, calc_alto
LISTA = 0x47C02
RABILLO = 0x41ADD
BASE_CELDA = 0x170

ESQ_SI, BORDE_S, ESQ_SD = 0x19C, 0x19D, 0x1AC
ESQ_II, BORDE_I, ESQ_ID = 0x19E, 0x19F, 0x1AE
LAT_I, LAT_D = 0x1A0, 0x1A1
CELDA0 = 0x170

N_BORDES = 6                          # 32 + 6*16 + 16 = 144
ANCHO = 32 + N_BORDES * 16 + 16
ANCHO_TXT = 128
MARGEN = (ANCHO - ANCHO_TXT) // 2     # 8
X0 = -(ANCHO // 2)                    # -72
Y0 = 12                               # como la v191/v194
FILAS_CEL = 2


def reg(celda, b1, b2, dx, dy):
    b0 = celda - BASE_CELDA
    assert 0 <= b0 <= 255, 'celda %03X fuera de la base' % celda
    return [b0, b1, b2, dx & 0xFF, dy & 0xFF]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v194 (md5 %s)' % md5
    orig = bytes(rom)

    # ==================================================================
    # 1. calc_alto: ($3657) & 2  ->  ($3657 - 1) & 2
    # ==================================================================
    esperado = bytes([0xAD, 0x57, 0x36,      # LDA $3657
                      0x4A,                  # LSR A
                      0x29, 0x02,            # AND #$02
                      0x18,                  # CLC
                      0x79, 0xBE, 0x9B,      # ADC $9BBE,Y
                      0x60])                 # RTS
    assert bytes(rom[CALC:CALC + 11]) == esperado, \
        'calc_alto no es el de la v194: %s' % bytes(rom[CALC:CALC + 11]).hex()
    nuevo = bytes([0xAD, 0x57, 0x36,         # LDA $3657
                   0x3A,                     # DEC A      <- ($3657-1)
                   0x29, 0x02,               # AND #$02
                   0x18,                     # CLC
                   0x79, 0xBE, 0x9B,         # ADC $9BBE,Y
                   0x60])                    # RTS
    assert len(nuevo) == 11
    rom[CALC:CALC + 11] = nuevo
    print('calc_alto $9FE0: (linea)&2 -> (linea-1)&2')

    # comprobar la formula en todos los casos de fin de dialogo
    for n in range(1, 13):
        vol = [(l, 'mitad') for l in range(1, n + 1) if l % 4 == 2 and l < n]
        vol.append((n, 'fin'))
        for l, _ in vol:
            fila = (l - 1) & 2
            toca = (((l - 1) % 4) // 2) * 2
            assert fila == toca, \
                'dialogo de %d lineas: al volcar con $3657=%d sale la fila ' \
                '%d y toca la %d' % (n, l, fila >> 1, toca >> 1)
    print('  verificada para dialogos de 1 a 12 lineas, en los volcados')
    print('  intermedios y en el final')

    # ==================================================================
    # 2. el marco, de 160 a 144 px
    # ==================================================================
    nueva = []
    nueva.append(reg(ESQ_SI, 0x0F, 0x01, X0, Y0))
    for i in range(N_BORDES):
        nueva.append(reg(BORDE_S, 0x0F, 0x00, X0 + 32 + i * 16, Y0))
    nueva.append(reg(ESQ_SD, 0x0F, 0x00, X0 + 32 + N_BORDES * 16, Y0))

    # ORDEN: en el SATB el indice bajo se dibuja ENCIMA (norma 55). Desde
    # la v192 los laterales llevan BLANCO en todo su ancho, asi que si van
    # antes que el relleno TAPAN la primera y la ultima columna del texto.
    # Se ponen DESPUES: su blanco queda debajo y solo asoma por los huecos.
    LAT_D_X = X0 + ANCHO - 16        # su trazo esta en la columna 15
    for fila in range(FILAS_CEL):
        y = Y0 + 16 + fila * 16
        for k in range(8):
            nueva.append(reg(CELDA0 + fila * 8 + k, 0x0F, 0x00,
                             X0 + MARGEN + k * 16, y))
        nueva.append(reg(LAT_I, 0x0F, 0x00, X0, y))
        nueva.append(reg(LAT_D, 0x0F, 0x00, LAT_D_X, y))

    yb = Y0 + 16 + FILAS_CEL * 16
    # el borde inferior lleva el dibujo al fondo de la celda desde la v194,
    # asi que su dY va 9 px por encima
    DESP_INF = 9
    nueva.append(reg(ESQ_II, 0x0F, 0x01, X0, yb - DESP_INF))
    for i in range(N_BORDES):
        nueva.append(reg(BORDE_I, 0x0F, 0x00, X0 + 32 + i * 16, yb - DESP_INF))
    nueva.append(reg(ESQ_ID, 0x0F, 0x00, X0 + 32 + N_BORDES * 16,
                     yb - DESP_INF))

    print('\nmarco: %d px (antes 160), margen del texto %d px'
          % (ANCHO, MARGEN))
    print('  %d sprites, X0=%d' % (len(nueva), X0))

    # --- verificaciones ---
    dibuja = {r[0] + BASE_CELDA for r in nueva}
    TABLA = 0x41BBD
    escribe = {(rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)) // 64
               for k in range(32)}
    faltan = escribe - dibuja
    assert not faltan, 'NORMA 101: %s no se dibujan' % sorted(
        '%03X' % c for c in faltan)
    print('  norma 101: las 8 celdas de texto se dibujan')

    for r in nueva:
        celda = r[0] + BASE_CELDA
        if r[2] & 0x01:
            assert celda % 2 == 0, 'sprite de 32 px con celda impar %03X' % celda
        dx = r[3] - 256 if r[3] > 127 else r[3]
        dy = r[4] - 256 if r[4] > 127 else r[4]
        assert -128 <= dx <= 127 and -128 <= dy <= 127, 'dX/dY fuera de rango'

    # bordes continuos
    for y in (Y0, yb - DESP_INF):
        t = sorted((r[3] - 256 if r[3] > 127 else r[3],
                    (r[3] - 256 if r[3] > 127 else r[3])
                    + (32 if r[2] & 1 else 16))
                   for r in nueva
                   if (r[4] - 256 if r[4] > 127 else r[4]) == y)
        for i in range(len(t) - 1):
            assert t[i][1] == t[i + 1][0], 'hueco en el borde y=%d' % y
        assert t[0][0] == X0 and t[-1][1] == X0 + ANCHO
    print('  bordes continuos de %d a %d' % (X0, X0 + ANCHO))

    # sin fondo a la vista en la fila de texto
    fin_txt = X0 + MARGEN + ANCHO_TXT
    assert LAT_D_X <= fin_txt, \
        'hueco de %d px entre el texto y el lateral' % (LAT_D_X - fin_txt)
    print('  el lateral derecho solapa %d px sobre el texto: sin hueco'
          % (fin_txt - LAT_D_X))
    assert LAT_D_X + 15 == X0 + ANCHO - 1, 'los trazos derechos no se alinean'

    # los laterales NO pueden ir antes que el relleno: los taparian
    orden = [r[0] + BASE_CELDA for r in nueva]
    for fila in range(FILAS_CEL):
        prim = orden.index(CELDA0 + fila * 8)
        for lat in (LAT_I, LAT_D):
            ult = len(orden) - 1 - orden[::-1].index(lat)
            assert ult > prim, \
                'el lateral %03X se dibuja ENCIMA del texto (norma 55)' % lat
    print('  los laterales van despues del relleno: no tapan el texto')

    # ranuras por scanline
    filas = {}
    for r in nueva:
        dy = r[4] - 256 if r[4] > 127 else r[4]
        filas[dy] = filas.get(dy, 0) + (2 if (r[2] & 1) else 1)
    print('  ranuras por linea: %s' % dict(sorted(filas.items())))
    assert max(filas.values()) <= 10, 'se pasa de 10 ranuras'

    off = LISTA
    for r in nueva:
        rom[off:off + 5] = bytes(r)
        off += 5
    rom[off] = 0xFF
    for k in range(off + 1, LISTA + 220):
        rom[k] = 0xFF

    # ==================================================================
    # 3. el rabillo, al centro
    # ==================================================================
    centro = X0 + ANCHO // 2 - 8
    print('\nrabillo: centro del bocadillo -> dX = %+d' % centro)
    for v in range(4):
        p = rom[RABILLO + v * 2] | (rom[RABILLO + v * 2 + 1] << 8)
        o = 0x40000 + (p - 0x8000)
        celda = BASE_CELDA + rom[o]
        dx = rom[o + 3]
        sdx = dx - 256 if dx > 127 else dx
        if celda == 0x1AF:
            print('  variante %d: celda %03X (lateral del abuelo) INTACTA'
                  % (v, celda))
            continue
        assert celda == 0x1AD, 'la variante %d apunta a %03X' % (v, celda)
        rom[o + 3] = centro & 0xFF
        print('  variante %d: dX %+d -> %+d' % (v, sdx, centro))

    # las tres variantes del rabillo tienen que quedar en el mismo sitio
    xs = set()
    for v in range(4):
        p = rom[RABILLO + v * 2] | (rom[RABILLO + v * 2 + 1] << 8)
        o = 0x40000 + (p - 0x8000)
        if BASE_CELDA + rom[o] == 0x1AD:
            xs.add(rom[o + 3])
    assert len(xs) == 1, 'las variantes del rabillo no coinciden: %s' % xs
    print('  las tres variantes apuntan al mismo punto')

    # ==================================================================
    intactas = [
        ('guion', 0x48000, 0x4C000),
        ('CG del bocadillo', 0x3D3D4, 0x3D660),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('clon $9952', 0x4199A, 0x419C6),
        ('fin de linea', 0x418A9, 0x418C1),
        ('fuente', 0x3D660, 0x3E200),
        ('ancla $C825', 0x16825, 0x16829),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        o2 = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n2 = raw[p + 3] << 8 | raw[p + 4]
        prueba[o2:o2 + n2] = raw[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  1. Los dialogos COMPLETOS: ya no se pierden lineas cuando la')
    print('     ultima pagina tiene 1 o 3 lineas.')
    print('  2. El bocadillo 16 px mas estrecho (8 por lado).')
    print('  3. El rabillo siempre en el centro, hables por donde hables.')


if __name__ == '__main__':
    main()
