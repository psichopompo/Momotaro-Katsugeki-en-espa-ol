#!/usr/bin/env python3
"""
build_v290.py - menu de Game Over: SE ACABO / Continuar / Terminar / Guardar.

LA LISTA REAL (v289 la localizo)
================================
`$D76B` (ROM 0x1B76B) mapea el **banco $17** y usa la lista `$5812` =
ROM 0x2F812, 13 registros, `$FF` en 0x2F853. Verificada: 13 de 13 coinciden
con el Sprite Viewer de David.

Formato: `[rel][$0E][$01][dx][dy]`, `tile = $1C0 + rel`, `$01` = 32x16 =
**4 glifos**. Pantalla: `x = $40+dx`, `y = $28+dy`.

QUE HACE ESTA VERSION
=====================
1. **La lista se muda al banco $23** (0x47CFB, 773 B a $FF). No cabia en el
   $17: la nueva son 96 B y el unico hueco del banco era de 66.
   Se tocan 3 bytes de `$D76B`: el banco y el puntero.

2. **Cada opcion pasa de 1 a 3 sprites** (4 -> 12 glifos). El titulo se
   queda en 2 (8 glifos), que es justo lo que mide «SE ACABO».

3. **Los destinos VRAM se reparten sin solapes** (norma: el motor `$D619`
   escribe hasta el `$00` y lo que sobra se derrama en el bloque siguiente).

```
           VRAM    glifos  celdas        sprites
titulo     $7008     8     $1C0-$1C3        2
op1        $7108    12     $1C4-$1C9        3
op2        $7288     8     $1CA-$1CD        2
op3        $7388     8     $1CE-$1D1        2
password   $7488    32     $1D2-$1E1        8
                                          ----
                                           17 -> 86 B
```

4. **La Ó se redibuja gruesa.** El glifo $C5 es una `ó` fina de cuerpo bajo
   entre mayusculas gruesas (lo aviso el informe). Se redibuja con el mismo
   trazo que la `O` del glifo $7E. Solo lo usa `Ó`, asi que mejora en todo
   el juego.

RIESGO ASUMIDO
==============
El password pasa a acabar en la celda `$1E1` (antes `$1D9`): 8 celdas mas.
David dijo «tira directamente». Si algo pinta ahi, se vera en pruebas.
"""
import hashlib, zlib, sys
sys.path.insert(0,'tools')
from charset_oficial import encode, CHAR_TO_CODE

BASE='roms/momotaro_es_v288.pce'; SALIDA='roms/momotaro_es_v293.pce'
IPS='parches/momotaro_v293.ips'; VIRGEN='roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE='4a835482df509fb1132b18748c8aec88'

LISTA_VIEJA=0x2F812; FIN_VIEJA=0x2F853
NUEVA=0x47CFC                      # banco $23 -> CPU $5CFB
BANCO_OFF=0x1B76C                  # LDA #$17
PTR_LO=0x1B77A; PTR_HI=0x1B77E     # $53=$12 / $54=$58
DEST=0x1B75F; DEST_PWD=0x1B767
PUNTEROS=0x1F72D
TEX=[(0x1F739,0x02,'SE ACABÓ'),(0x1F745,0x01,'Continuar'),
     (0x1F74C,0x01,'Terminar'),(0x1F751,0x02,'Guardar')]

# (vram, glifos, x de cada sprite, y)
PLAN=[('titulo',0x7008, 8,[96,128],       40),
      ('op1',   0x7108,12,[96,128,160],  56),
      ('op2',   0x7288, 8,[95,127],      72),   # -1 px: la T ($83) tiene la col 0 vacia
      ('op3',   0x7388, 8,[96,128],      88),
      ('pwd1',  0x7488,16,[58,94,130,166],104),
      ('pwd2',  None,  16,[58,94,130,166],120)]

# Cuerpo en las filas 2..6, que es donde acaba la O normal ($7E).
# La version de la v291 lo puso en 3..7 y quedaba 1 px mas abajo.
O_GRUESA=["..##....",".##.....","######..","##...##.",
          "##...##.","##...##.",".#####..","........"]

def main():
    rom=bytearray(open(BASE,'rb').read()); orig=open(VIRGEN,'rb').read()
    base=bytes(rom)
    assert hashlib.md5(rom).hexdigest()==MD5_BASE,'la base no es la v288'
    print('base %s  OK'%BASE)

    # --- 1. la lista vieja es la que creemos --------------------------
    a=LISTA_VIEJA; vieja=[]
    while rom[a]!=0xFF: vieja.append(tuple(rom[a:a+5])); a+=5
    assert a==FIN_VIEJA and len(vieja)==13,'la lista vieja no es la esperada'
    assert rom[BANCO_OFF]==0x17 and rom[PTR_LO]==0x12 and rom[PTR_HI]==0x58
    print('\n--- lista vieja: 13 registros, banco $17, $5812  OK')

    # --- 2. construir la lista nueva ----------------------------------
    regs=[]; celda=0x1C0
    for nom,vram,ng,xs,y in PLAN:
        for x in xs:
            rel=celda-0x1C0
            dx=(x-0x40)&0xFF; dy=y-0x28
            assert 0<=dy<256
            regs.append((rel,0x0E,0x01,dx,dy))
            celda+=2
    nueva=b''.join(bytes(r) for r in regs)+b'\xFF'
    print('--- lista nueva: %d registros, %d B'%(len(regs),len(nueva)))
    for i,(rel,at,ath,dx,dy) in enumerate(regs):
        print('    [%2d] tile $%03X  x=%3d y=%3d'%(i,0x1C0+rel,(0x40+dx)&0xFF,0x28+dy))
    assert celda-1<=0x1E1,'se pasa de la celda $1E1'

    libre=0
    while rom[NUEVA+libre]==0xFF: libre+=1
    assert len(nueva)<=libre,'no cabe: %d > %d'%(len(nueva),libre)
    assert orig[NUEVA:NUEVA+libre]==rom[NUEVA:NUEVA+libre],'el hueco no es virgen'
    print('    hueco 0x%05X: %d B libres  OK'%(NUEVA,libre))

    rom[NUEVA:NUEVA+len(nueva)]=nueva
    cpu=0x4000+(NUEVA-0x46000)
    rom[BANCO_OFF]=0x23; rom[PTR_LO]=cpu&0xFF; rom[PTR_HI]=cpu>>8
    rom[LISTA_VIEJA:FIN_VIEJA+1]=b'\xFF'*(FIN_VIEJA+1-LISTA_VIEJA)
    print('    $D76B -> banco $23, lista $%04X'%cpu)

    # --- 3. destinos VRAM ---------------------------------------------
    print('\n--- destinos VRAM')
    for i,(nom,vram,ng,xs,y) in enumerate(PLAN[:4]):
        rom[DEST+i*2]=vram&0xFF; rom[DEST+i*2+1]=vram>>8
        print('    %-7s $%04X  %2d glifos -> $%04X'%(nom,vram,ng,vram+ng*0x20))
    rom[DEST_PWD]=0x7488&0xFF; rom[DEST_PWD+1]=0x7488>>8
    print('    %-7s $7488  32 glifos -> $7888'%'pwd')
    lim=[0x7008,0x7108,0x7288,0x7388,0x7488]
    for i in range(4):
        assert lim[i]+PLAN[i][2]*0x20<=lim[i+1],'solape en %s'%PLAN[i][0]
    print('    sin solapes  OK')

    # --- 4. la Ó gruesa -------------------------------------------------
    g=0xC5
    rom[0x3D660+g*8:0x3D660+g*8+8]=bytes(
        int(''.join('1' if c=='#' else '0' for c in f),2) for f in O_GRUESA)
    def ultima_fila(g):
        o=0x3D660+g*8
        return max(i for i in range(8) if rom[o+i])
    assert ultima_fila(0xC5)==ultima_fila(0x7E), \
        'la Ó acaba en la fila %d y la O en la %d'%(ultima_fila(0xC5),ultima_fila(0x7E))
    print('\n--- glifo $C5 (Ó): cuerpo alineado con la O, ambas acaban en la fila %d'
          %ultima_fila(0x7E))

    # --- 4b. el melocoton (cursor) a la izquierda del texto ---------
    CUR=0x2F854
    assert bytes(rom[CUR:CUR+5])==bytes([0x00,0x00,0x00,0x02,0x04]), \
        'el registro del cursor no es el esperado: %s'%bytes(rom[CUR:CUR+5]).hex(' ')
    rom[CUR+3]=0xF1          # x = $60-15 = 81, ~4 px de hueco hasta el texto
    print('\n--- cursor: x %d -> %d (~4 px de hueco hasta el texto en 96)'%(0x60+2,0x60-15))

    # --- 4c. la pantalla de «¡Guardado!» -----------------------------
    # $D94F carga la cadena $57AA y el destino VRAM $7008, y $D965 monta
    # su lista de sprites: $58AB banco $17 = ROM 0x2F8AB.
    # En la VIRGEN esa lista son 2 registros y un $FF en 0x2F8B5. En
    # nuestras ROMs (desde antes de la v264) el $FF esta PISADO por datos
    # sueltos, asi que la lista sigue leyendo basura: 20 sprites en vez de
    # 2. Eso es lo que David ve como artefactos.
    # Verificado que nadie referencia 0x2F8B5-0x2F910 con [cmd][word].
    GUA=0x2F8AB
    assert bytes(rom[GUA:GUA+10])==bytes([0x00,0x0E,0x01,0x20,0x00,
                                          0x02,0x0E,0x01,0x40,0x00]), \
        'los 2 registros buenos de la lista de guardado no estan'
    assert set(orig[GUA+10:0x2F910])=={0xFF}, 'en la virgen no era relleno'
    n_bas=sum(1 for i in range(GUA+10,0x2F910) if rom[i]!=0xFF)
    # tercer sprite para que quepan los 10 glifos de «¡Guardado!»
    rom[GUA+10:GUA+15]=bytes([0x04,0x0E,0x01,0x60,0x00])   # tile $1C4, x=160
    rom[GUA+15:0x2F910]=b'\xFF'*(0x2F910-GUA-15)
    print('\n--- pantalla de «¡Guardado!»')
    print('    lista 0x%05X: habia %d bytes de basura tras los 2 registros'%(GUA,n_bas))
    print('    3 registros + $FF en 0x%05X  (x=96,128,160 -> 12 glifos)'%(GUA+15))

    GTX=0x1F7AA
    cod=bytes([0x02])+encode('¡Guardado!')+b'\x00'
    assert len(cod)<=12,'«¡Guardado!» no cabe en 12 B'
    rom[GTX:GTX+len(cod)]=cod
    rom[GTX+len(cod):0x1F7B5]=b'\x00'*(0x1F7B5-GTX-len(cod))
    rom[0x1F7B5]=0xFF   # el $FF que cierra el bloque, intacto
    assert rom[0x1F7B5]==0xFF,'se ha comido el $FF que cierra'
    print('    texto 0x%05X: %r (%d glifos en 12)'%(GTX,'¡Guardado!',len(encode('¡Guardado!'))))

    # --- 5. los textos ---------------------------------------------------
    # El bloque original (0x1F739-0x1F757) son 31 B y hacen falta 40, pero
    # hay TABLA DE PUNTEROS: las cadenas se reubican al hueco de 0x1F61C
    # (273 B a $FF, justo antes de la tabla) y se repuntan las 4 words.
    # 0x1F61C parecia libre (273 B a $FF) pero es texto japones que
    # borramos nosotros, y AUN TIENE DOS PUNTEROS VIVOS ($5713 desde
    # 0x1E4B4 y $56CA desde 0x1F366). El assert de "virgen" lo cazo.
    # Se usa 0x1F9D5, que SI esta a $FF en la ROM original.
    CAD=0x1F9D5
    n=0
    while rom[CAD+n]==0xFF: n+=1
    assert set(orig[CAD:CAD+n])=={0xFF},'el hueco de cadenas no es virgen'
    refs=[x for x in range(0x1E000,0x20000-2) if rom[x] in (1,2,3,4)
          and 0x4000+(CAD-0x1E000)<=(rom[x+1]|(rom[x+2]<<8))<0x4000+(CAD+n-0x1E000)]
    assert not refs,'el hueco esta referenciado: %s'%['%05X'%r for r in refs]
    print('\n--- textos (reubicados a 0x%05X, %d B libres)'%(CAD,n))
    cur=CAD
    for i,((off,pref,txt),(nom,vram,ng,xs,y)) in enumerate(zip(TEX,PLAN[:4])):
        cod=bytes([pref])+encode(txt)+b'\x00'
        assert len(encode(txt))<=ng,'«%s» no cabe en %d glifos'%(txt,ng)
        assert cur+len(cod)<=CAD+n,'no caben las cadenas'
        rom[cur:cur+len(cod)]=cod
        w=0x4000+(cur-0x1E000)
        rom[PUNTEROS+i*2]=w&0xFF; rom[PUNTEROS+i*2+1]=w>>8
        print('    %-7s 0x%05X ($%04X) %-11r %2d glifos de %d'%(nom,cur,w,txt,len(encode(txt)),ng))
        cur+=len(cod)
    # el bloque viejo se limpia y se deja su $FF final
    rom[0x1F739:0x1F757]=b'\x00'*(0x1F757-0x1F739)

    # --- 6. relectura ---------------------------------------------------
    inv={v:k for k,v in CHAR_TO_CODE.items()}
    print('\n--- releido siguiendo los punteros')
    for i,(off,pref,txt) in enumerate(TEX):
        w=rom[PUNTEROS+i*2]|(rom[PUNTEROS+i*2+1]<<8)
        o=0x1E000+(w-0x4000)
        f=o+1
        while rom[f]!=0x00: f+=1
        got=''.join(inv.get(x,'[%02X]'%x) for x in rom[o+1:f])
        assert got==txt,'leido %r'%got
        print('    [%d] $%04X -> %r  OK'%(i,w,got))

    assert rom[0x47CFB]==0xFF,'PISADO el terminador de la lista B (el bug de la v290)'
    print('terminador $FF de la lista B en 0x47CFB: INTACTO')
    intactas=[('tabla del canto GO',0x1F7B6,0x1F836),
              ('lista B del abuelo',0x47CA1,0x47CFC),
              ('parrilla',0x1BBBA,0x1BC00),('tabla Jizo',0x16AD6,0x16B16),
              ('menu RUN $0C',0x197F0,0x19810),
              ('lista del cursor salvo su dx',0x2F858,0x2F8A8)]
    for nom,x,y in intactas:
        assert bytes(rom[x:y])==base[x:y],'se ha tocado %s'%nom
    print('\nintactas: %s'%', '.join(n for n,_,_ in intactas))

    d=bytes(rom); open(SALIDA,'wb').write(d)
    print('%d bytes sobre la v288'%sum(1 for i in range(len(d)) if d[i]!=base[i]))

    difv=[i for i in range(len(d)) if d[i]!=orig[i]]
    rec=[];i=0
    while i<len(difv):
        s=difv[i];j=i
        while j+1<len(difv) and difv[j+1]<=difv[j]+8: j+=1
        e=difv[j]+1
        rec.append(bytes([s>>16&0xFF,s>>8&0xFF,s&0xFF,(e-s)>>8,(e-s)&0xFF])+d[s:e])
        i=j+1
    p=b'PATCH'+b''.join(rec)+b'EOF'; open(IPS,'wb').write(p)
    t=bytearray(orig); q=5
    while p[q:q+3]!=b'EOF':
        o2=p[q]<<16|p[q+1]<<8|p[q+2]; n2=p[q+3]<<8|p[q+4]
        t[o2:o2+n2]=p[q+5:q+5+n2]; q+=5+n2
    assert bytes(t)==d,'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)'%len(p))
    print('\n%s\n  MD5    %s\n  SHA-1  %s\n  CRC32  %08X'%(SALIDA,
        hashlib.md5(d).hexdigest(),hashlib.sha1(d).hexdigest(),zlib.crc32(d)&0xFFFFFFFF))

main()
