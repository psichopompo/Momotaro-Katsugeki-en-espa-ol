#!/usr/bin/env python3
"""build_v319.py - Tres arreglos que caza David en la v318.

1. **DADOS rehechos.** El troceo de la v316 estaba desplazado UNA LINEA:
   empece en `0x4AC9C` cuando el bloque empieza en `0x4AC8B`. Cada
   «mensaje» que traduje era la 2a linea de uno y la 1a del siguiente.
   Ademas las lineas de OPCIONES van en columnas fijas 1 y 9, en una
   ventana lateral estrecha, no en el bocadillo.

2. **«poco a.»** El punto partia «a apostar» y ademas «apostar» llevaba
   exclamacion. Correcto: «...hace poco a / apostar. Dicen...».

3. **Vitores CENTRADOS.** El japones los centra; yo los alinee a la
   izquierda aplicando el criterio de los bocadillos de dialogo. El
   criterio depende del CONTENEDOR: una pancarta es un cartel.

ESTRUCTURA DE LOS DADOS (medida linea a linea)
----------------------------------------------
    L0+L1   bocadillo    0x4AC8B  0x4AC9C
    L2      OPCIONES     0x4ACAE   <- columnas 1 y 9
    L3+L4   bocadillo    0x4ACBE  0x4ACD0
    L5      OPCIONES     0x4ACE0   <- columnas 1 y 9
    L6+L7   bocadillo    0x4ACF0  0x4AD00
    L8+L9   bocadillo    0x4AD10  0x4AD22
    L10+L11 bocadillo    0x4AD34  0x4AD44

Las lineas NO son todas de 16 B: el japones gasta 17 o 18 cuando lleva
dakuten. Se respeta el hueco ORIGINAL de cada una rellenando con `$A0`,
porque van encadenadas y escribir de menos descuadraria al lector.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode, RELLENO   # noqa: E402
import vitores                                 # noqa: E402

BASE = 'roms/momotaro_es_v318.pce'
SALIDA = 'roms/momotaro_es_v319.pce'
MD5_BASE = '7291a7d8a56733916ad4fada899198e4'
COLS = 16

# (offset, hueco_en_bytes, texto)   texto None = linea de opciones
DADOS = [
    (0x4AC8B, 17, '¡Acierta y ganas'),
    (0x4AC9C, 18, 'el gordo! ¿Vas?'),
    (0x4ACAE, 16, None),                  # OPCIONES  Sí / No
    (0x4ACBE, 18, '¡Así me gusta!'),
    (0x4ACD0, 16, '¿Par o non?'),
    (0x4ACE0, 16, None),                  # OPCIONES  Par / Non
    (0x4ACF0, 16, '¡Vaya suerte que'),
    (0x4AD00, 16, 'tienes! ¡Vuelve!'),
    (0x4AD10, 18, '¡Qué lástima!'),
    (0x4AD22, 18, '¡Hasta la vista!'),
    (0x4AD34, 16, '¡Qué rácano!'),
    (0x4AD44, 18, '¡Largo de aquí!'),
]
# opciones: (offset, col1_texto, col9_texto)
OPCIONES = [(0x4ACAE, 'Sí', 'No'), (0x4ACE0, 'Par', 'Non')]
COL_A, COL_B = 1, 9

# «poco a. / ¡apostar!» -> «poco a / apostar.»
FRASE_OFF = 0x4A429
FRASE_VIEJA = 'a.'          # + $3B + '¡apostar!'
FRASE_NUEVA = 'a'           # + $3B + 'apostar.'

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x1E000, 0x20000, 'banco $0F: tabla de escenas'),
    (0x42000, 0x44000, 'banco $21: menu RUN de la v318'),
    (0x4AE18, 0x4AEE6, 'ermitanyo y tecnicas'),
    (0x4AEE6, 0x4C000, 'el QUIZ'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v318'

    # ---------- 1. DADOS --------------------------------------------------
    # el bloque tiene que empezar donde digo y las lineas encadenar
    total = sum(h for _o, h, _t in DADOS)
    assert DADOS[0][0] == 0x4AC8B
    p = DADOS[0][0]
    for off, h, _t in DADOS:
        assert off == p, 'las lineas no encadenan en %06X' % off
        p += h
    assert p == 0x4AD56, 'el bloque no acaba en 0x4AD56 sino en %06X' % p

    for off, h, txt in DADOS:
        if txt is None:
            continue
        assert len(txt) <= COLS, '«%s» son %d columnas' % (txt, len(txt))
        datos = encode(txt) + bytes([RELLENO]) * (COLS - len(txt))
        # rellenar hasta el hueco original: van encadenadas
        datos += bytes([RELLENO]) * (h - COLS)
        assert len(datos) == h
        rom[off:off + h] = datos

    for off, a, b in OPCIONES:
        linea = [0x20] * COLS
        for i, c in enumerate(encode(a)):
            linea[COL_A + i] = c
        for i, c in enumerate(encode(b)):
            linea[COL_B + i] = c
        assert COL_A + len(a) <= COL_B, 'la opcion A pisa la columna 9'
        assert COL_B + len(b) <= COLS, 'la opcion B se sale'
        h = dict((o, hh) for o, hh, _ in DADOS)[off]
        rom[off:off + h] = bytes(linea) + bytes([RELLENO]) * (h - COLS)

    # ---------- 2. «poco a.» ---------------------------------------------
    viejo = encode('a.') + b'\x3b' + encode('¡apostar!')
    nuevo = (encode('a') + bytes([RELLENO]) + b'\x3b' +
             encode('apostar.') + bytes([RELLENO]))
    assert rom[FRASE_OFF:FRASE_OFF + len(viejo)] == viejo, \
        'en %06X no esta «a. / ¡apostar!»' % FRASE_OFF
    assert len(nuevo) == len(viejo), 'la correccion cambia la longitud'
    rom[FRASE_OFF:FRASE_OFF + len(nuevo)] = nuevo

    # ---------- 3. VITORES centrados --------------------------------------
    offs = vitores.offsets(rom)
    centrados = []
    for i, off in enumerate(offs):
        nuevo_bloque = bytearray()
        for fila in range(2):
            a = off + fila * 18
            cruda = rom[a:a + 18]
            # quitar el relleno de la derecha para saber el texto real
            txt = bytes(cruda).rstrip(bytes([RELLENO]))
            sangria = (18 - len(txt)) // 2
            nuevo_bloque += (bytes([RELLENO]) * sangria + txt +
                             bytes([RELLENO]) * (18 - sangria - len(txt)))
        assert len(nuevo_bloque) == 36
        rom[off:off + 36] = nuevo_bloque
        centrados.append((i, off))

    # ---------- VERIFICACION ----------------------------------------------
    # dados: cada linea consume su hueco y el bloque acaba donde acababa
    p = 0x4AC8B
    for off, h, _t in DADOS:
        assert p == off
        p += h
    assert p == 0x4AD56

    # los textos releidos
    for off, h, txt in DADOS:
        if txt is None:
            continue
        assert rom[off:off + len(txt)] == encode(txt), \
            'linea %06X no cuadra al releer' % off

    # las opciones, en sus columnas
    for off, a, b in OPCIONES:
        assert rom[off + COL_A:off + COL_A + len(a)] == encode(a), \
            'opcion A de %06X fuera de la columna %d' % (off, COL_A)
        assert rom[off + COL_B:off + COL_B + len(b)] == encode(b), \
            'opcion B de %06X fuera de la columna %d' % (off, COL_B)

    # vitores: siguen consumiendo 36 B leidos por el motor
    for i, off in centrados:
        _buf, fin = vitores.render(rom, off)
        assert fin - off == 36, 'vitor %d consume %d B' % (i, fin - off)

    # zonas intactas
    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  DADOS:')
    for off, h, txt in DADOS:
        if txt is None:
            o = dict((x[0], x) for x in OPCIONES)[off]
            print('    %06X  OPCIONES  col%d=«%s»  col%d=«%s»'
                  % (off, COL_A, o[1], COL_B, o[2]))
        else:
            print('    %06X  |%-16s|' % (off, txt))
    print()
    print('  «poco a. / ¡apostar!» -> «poco a / apostar.»')
    print('  19 vitores centrados')


if __name__ == '__main__':
    main()
