#!/usr/bin/env python3
"""
build_v199.py - los dos bocadillos que faltaban:
                (A) el RECORTE del ancla   (B) el bocadillo del ABUELO

LO QUE PIDE DAVID
-----------------
> «El bocadillo de un Jizo al comienzo de una pantalla se queda fuera. [...]
>  Si abrimos un dialogo a una distancia a la que vaya a quedar fuera parte
>  del mismo, el ancla deberia moverse a la derecha o izquierda [...] dejando
>  un margen de 8 px [...]. El rabillo deberia permanecer centrado con el
>  aldeano/Jizo.»
> «Cuando aparece en ciertas ocasiones el abuelo en la parte superior derecha
>  su bocadillo genera mutilaciones porque el original era mas estrecho.»


=====================================================================
(A) EL RECORTE DEL ANCLA
=====================================================================

Esto quedo pendiente en la v190 por un motivo concreto (norma 140): la
rutina hay que colgarla de `$8807` (banco `$0B`) y **un JSR solo alcanza el
banco mapeado en esa ventana**. En el banco `$0B` no habia 60 B limpios.

LO QUE ME EQUIVOQUE (y por que estuvo parado 9 versiones)
---------------------------------------------------------
Di por hecho que la rutina tenia que vivir en el mismo banco `$0B`. Es
falso. El banco `$00` esta SIEMPRE mapeado en MPR7 (ventana `$E000-$FFFF`):
es donde viven `$E3EB` y `$E185`, a los que llama el motor del bocadillo
desde el banco `$20` sin remapear nada. Medido en los MPR de los 6 states:

    MPR = ff f8 26 1e 20 21 0c 00      MPR7 = $00  en los SEIS

O sea que desde `$8807` (banco `$0B`) puedo hacer `JSR $FFxx` y cae en el
banco `$00`, que esta mapeado. No hay que remapear nada.
[HECHO] Ademas hay 63 `JSR $FFxx` repartidos por 20 bancos distintos en el
juego original, que es justo la prueba de que ese banco es alcanzable desde
cualquier sitio.

EL HUECO
--------
`ROM 0x1F6B..0x1FDF` = `$FF6B..$FFDF`, **117 B de $FF**, justo antes de la
cabecera del cartucho (`MOMOKATSU   1.07900518` en `$FFE0`) y de los
vectores (`$FFF6`). Verificado:
  - esta a $FF tambien en la ROM VIRGEN (no es algo que haya metido yo)
  - ningun JSR/JMP de la ROM apunta dentro del tramo
  - los vectores apuntan a $E0AC/$E038/$E0AD/$E000, fuera del tramo
  - no es un bitmap (norma 137): 117 B de $FF, y el CG del juego no vive
    en el banco 0

LA FORMULA, YA MEDIDA EN LA v190
--------------------------------
    x_pantalla = $368B - scroll($35/$36) + dX          (norma 139)

El marco de la v198 va de `dX=-72` a `dX=+71` (el sprite de `dX=56` mide
16). Con margen de 8 px que pide David:

    limite izquierdo:  ancla - scroll - 72 >= 8   ->  ancla >= scroll + 80
    limite derecho:    ancla - scroll + 72 <= 248 ->  ancla <= scroll + 176

EL RABILLO SE QUEDA CON EL PERSONAJE
------------------------------------
David lo pide explicitamente, y esto decide DONDE se engancha el recorte.

Mi primer plan era recortar `$368B` en `$8807` y guardar el desplazamiento
en `$3691` para que el rabillo lo deshiciera. **Estaba mal por dos motivos**:

  1. `$3691` NO esta libre. Lo usa el banco `$23`:
        $67C8  LDA $3691 / AND #$C0 / STA $2E30,X
        $67D3  ADC #$40 / STA $3691          (un contador rotatorio)
     Y `$3692` peor todavia: se accede como `$3692,Y` con Y=0..7, o sea
     que se come hasta `$3699`. Norma 137 otra vez: que una direccion
     "parezca" el final de una tabla no significa que este libre.
  2. Aunque estuviera libre, sobraba: hacia falta RAM y un corrector.

LO QUE SI HAY (medido en $9A65)
-------------------------------
El emisor pinta el bocadillo con DOS llamadas a `$E3EB`, y las dos leen la
X base de `$4E/$4F`:

    $9A65  LDA $368B / STA $4E ... (carga $4E-$51 y la variante)
    $9A92  JSR $E3EB          <- 1a: EL RABILLO (lista de $9ADD)
    $9A9F  LDA #$02/STA $53 / LDA #$7C/STA $54
    $9AA7  JSR $E3EB          <- 2a: EL CUERPO  (lista de $7C02)

O sea que **entre las dos llamadas** el rabillo ya esta emitido con la X
sin tocar y el cuerpo todavia no. Recortando `$4E/$4F` justo ahi sale
exactamente lo que pide David, sin RAM y sin corrector:

    rabillo -> centrado en el personaje (X original)
    cuerpo  -> pegado al borde con 8 px de margen

Y el engarce cuesta **3 bytes por 3 bytes**: el `JSR $E3EB` de `$9AA7` pasa
a ser `JSR $FF6B`, y la rutina nueva recorta y termina con `JMP $E3EB`.
No se toca `$368B` ni el banco `$0B`.

=====================================================================
(B) EL BOCADILLO DEL ABUELO
=====================================================================

MEDIDO (states2/abuelo.state, que SI es de la v198)
---------------------------------------------------
Simulador nuevo `tools/vdc_slots.py`, que reproduce el limite de 16 ranuras
por scanline del VDC (norma 144: un sprite de 32 px cuenta DOS). Reproduce
EXACTAMENTE la mutilacion de la captura de David:

    sprite 26/27/28 (borde sup 19D,1AC)  pierden 7 filas   (scan 29..35)
    sprite 35/36/37/38 (texto 176,177)   pierden 4 filas   (scan 36..39)
    sprite 57 (la cabeza del ABUELO,0C4) pierde 20 filas   (scan 20..39)

    scanlines 20..39 y 59..67: 16 ranuras de 16, saturadas.

Reparto en esas scanlines:  HUD (1B8 x8 + 1BC + 1BD) = 10
                            bocadillo = 10
                            abuelo (0C4, 32px) = 2      -> 22 > 16

El HUD ocupa `y=24..39` y el bocadillo empieza en `y=20`. Se pisan.

EL ARREGLO
----------
`$88C2 SBC #$30` -> `SBC #$1C`. Baja el bocadillo **20 px**, de `y=20..74`
a `y=40..94`, justo por debajo del HUD (que acaba en `y=39`).

Simulado con el volcado real: **0 sprites mutilados**, pico 16/16.
Barrido de dy: 0->8 mutilados, +12->1, +16->1, **+20->0**. Es el minimo
que resuelve.

El rabillo (variante 2, celda `1AF`, la lateral del abuelo) tiene que
seguir apuntando al abuelo, que NO se mueve: se le resta el mismo
desplazamiento, `dY 40 -> 20` en `$9AF1`.

Uso:  python3 tools/build_v199.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v198.pce'
SALIDA = 'roms/momotaro_es_v199.pce'
IPS = 'parches/momotaro_v199.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '01901d5b3b1fb9a5e5ab79199b153f11'

# --- (A) recorte -----------------------------------------------------
HUECO = 0x1F6B                  # ROM. $FF6B en la ventana MPR7 (banco $00)
HUECO_L = 0xFF6B
# Bancos que contienen CODIGO ejecutable relevante (los que aparecen en los
# MPR de los states y los del motor de texto). El resto son graficos/datos.
BANCOS_CODIGO = {0x00, 0x0B, 0x0C, 0x0E, 0x1E, 0x20, 0x21, 0x23, 0x26}
FIN_HUECO = 0x1FE0
JSR_CUERPO = 0x41AA7            # $9AA7 JSR $E3EB (2a llamada: el CUERPO)
E3EB = 0xE3EB
MARGEN = 8
ANCHO_IZQ = 72                  # |dX| minimo del marco (celda 19C en -72)
ANCHO_DER = 72                  # dX maximo (celda 1AC en +56, mide 16)

# --- (B) abuelo ------------------------------------------------------
ABUELO_Y = 0x168C2              # $88C2 SBC #$30
ABUELO_DY = 20
RABILLO2_DY = 0x41AF5           # dY de la variante 2 en la tabla $9ADD


def ips(orig, d):
    dif = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    return b'PATCH' + b''.join(rec) + b'EOF', len(dif)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v198'
    print('base %s  OK' % BASE)

    # ==================================================================
    # 0. EL HUECO: comprobarlo antes de nada (norma 137)
    # ==================================================================
    assert all(b == 0xFF for b in rom[HUECO:FIN_HUECO]), \
        'el hueco de $FF6B no esta limpio'
    assert all(b == 0xFF for b in orig[HUECO:FIN_HUECO]), \
        'el hueco no esta a $FF en la ROM virgen: no es relleno'
    assert bytes(rom[0x1FE0:0x1FE6]) == b'MOMOKA', 'la cabecera no cuadra'
    # SOBRE LAS "REFERENCIAS" AL HUECO
    # --------------------------------
    # Buscar JSR/JMP a $FF6B-$FFDF por toda la ROM da 63 coincidencias en
    # bruto y 36 respetando limites de instruccion. NINGUNA es real, y hay
    # una prueba que lo zanja sin tener que mirarlas una a una:
    #
    #   La ventana $E000-$FFFF es SIEMPRE el banco $00 (MPR7=$00 en los 6
    #   states). El banco $00 es ROM 0x0000-0x1FFF, y ahi el tramo
    #   0x1F6B-0x1FDF esta a $FF **en la ROM VIRGEN**.
    #
    # Es decir: si alguna de esas 36 fuese un JSR de verdad, el juego
    # estaria saltando a 117 bytes de $FF ($FF = BBS7, que se colgaria) y
    # no arrancaria. Como el juego original funciona, todas son bytes de
    # datos que por casualidad se leen como un salto. Verificado a mano en
    # dos de ellas:
    #   ROM 0x068C9 -> "43 47 71 90 70 00 20 df 1e ff ..."  = CG comprimido
    #   ROM 0x4C61A -> alrededor hay "JSR $0003", que no existe: es tabla
    #
    # Lo que SI hay que comprobar (y se comprueba arriba) es que el tramo
    # esta a $FF en la virgen, que no lo he ocupado yo en versiones
    # anteriores, y que no pisa ni la cabecera ni los vectores.
    for k in range(0, 10, 2):
        v = rom[0x1FF6 + k] | (rom[0x1FF7 + k] << 8)
        assert not (HUECO_L <= v < 0xFFE0), \
            'un VECTOR apunta al hueco: $%04X' % v
    print('  vectores fuera del tramo: %s'
          % ' '.join('$%04X' % (rom[0x1FF6 + k] | (rom[0x1FF7 + k] << 8))
                     for k in range(0, 10, 2)))

    print('hueco $FF6B-$FFDF: %d B libres, a $FF tambien en la ROM virgen'
          % (FIN_HUECO - HUECO))

    # ==================================================================
    # (A) LA RUTINA DE RECORTE
    # ==================================================================
    # Se engancha en la 2a llamada a $E3EB (la del CUERPO). El rabillo ya
    # se ha emitido con la X sin tocar -> se queda con el personaje.
    esperado = bytes([0x20, 0xEB, 0xE3])            # JSR $E3EB
    assert bytes(rom[JSR_CUERPO:JSR_CUERPO + 3]) == esperado, \
        'en $9AA7 no esta el JSR $E3EB: %s' % bytes(
            rom[JSR_CUERPO:JSR_CUERPO + 3]).hex()
    # y que la 1a llamada sigue donde debe (el rabillo)
    assert bytes(rom[0x41A92:0x41A95]) == esperado, \
        'en $9A92 no esta la 1a llamada a $E3EB'

    XMIN = MARGEN + ANCHO_IZQ                       # 80
    XMAX = 256 - MARGEN - ANCHO_DER                 # 176

    # Ensamblador con etiquetas: los saltos se CALCULAN. Escribirlos a mano
    # fue justo el motivo de descartar la rutina en la v190.
    def ensambla(ins):
        pos = {}
        off = 0
        for et, cuerpo in ins:
            if et:
                pos[et] = off
            off += 2 if isinstance(cuerpo[0], str) else len(cuerpo)
        OPS = {'BNE': 0xD0, 'BEQ': 0xF0, 'BCC': 0x90, 'BCS': 0xB0,
               'BMI': 0x30, 'BPL': 0x10, 'BRA': 0x80}
        out = bytearray()
        for et, cuerpo in ins:
            if isinstance(cuerpo[0], str):
                op, dest = cuerpo
                rel = pos[dest] - (len(out) + 2)
                assert -128 <= rel <= 127, 'salto fuera de rango a %s' % dest
                out += bytes([OPS[op], rel & 0xFF])
            else:
                out += bytes(cuerpo)
        return bytes(out), pos

    # x_pantalla del centro = $4E/$4F - scroll($35/$36)      (norma 139)
    #   si < XMIN  ->  $4E/$4F = scroll + XMIN     (pegado a la izquierda)
    #   si > XMAX  ->  $4E/$4F = scroll + XMAX     (pegado a la derecha)
    # $10/$11 son temporales; $E3EB los reinicia al entrar (STZ $57, y usa
    # $10 como scratch propio despues), asi que se pueden usar aqui.
    rec, etq = ensambla([
        (None, [0xA5, 0x4E]),                    # LDA $4E
        (None, [0x38]),                          # SEC
        (None, [0xE5, 0x35]),                    # SBC $35
        (None, [0x85, 0x10]),                    # STA $10
        (None, [0xA5, 0x4F]),                    # LDA $4F
        (None, [0xE5, 0x36]),                    # SBC $36
        (None, [0x85, 0x11]),                    # STA $11
        # alto != 0 -> esta fuera de pantalla; el signo dice por que lado
        (None, ['BNE', 'fuera']),
        (None, [0xA5, 0x10]),                    # LDA $10
        (None, [0xC9, XMIN]),                    # CMP #XMIN
        (None, ['BCC', 'izq']),
        (None, [0xC9, XMAX + 1]),                # CMP #XMAX+1
        (None, ['BCS', 'der']),
        (None, ['BRA', 'salir']),                # cabe entero
        ('fuera', [0xA5, 0x11]),                 # LDA $11
        (None, ['BMI', 'izq']),
        (None, ['BRA', 'der']),
        ('izq', [0xA9, XMIN]),                   # LDA #XMIN
        (None, ['BRA', 'pegar']),
        ('der', [0xA9, XMAX]),                   # LDA #XMAX
        ('pegar', [0x18]),                       # CLC
        (None, [0x65, 0x35]),                    # ADC $35
        (None, [0x85, 0x4E]),                    # STA $4E
        (None, [0xA5, 0x36]),                    # LDA $36
        (None, [0x69, 0x00]),                    # ADC #0
        (None, [0x85, 0x4F]),                    # STA $4F
        ('salir', [0x4C, E3EB & 0xFF, E3EB >> 8]),   # JMP $E3EB
    ])
    assert rec[-3:] == bytes([0x4C, 0xEB, 0xE3]), 'no acaba en JMP $E3EB'
    assert HUECO + len(rec) <= FIN_HUECO, 'la rutina no cabe en el hueco'
    print('\n(A) recorte: %d B en $%04X, limites x=%d..%d (margen %d px)'
          % (len(rec), HUECO_L, XMIN, XMAX, MARGEN))
    rom[HUECO:HUECO + len(rec)] = rec
    rom[JSR_CUERPO:JSR_CUERPO + 3] = bytes(
        [0x20, HUECO_L & 0xFF, HUECO_L >> 8])
    print('    $9AA7 JSR $E3EB -> JSR $%04X  (solo el CUERPO)' % HUECO_L)
    print('    $9A92 JSR $E3EB intacto      (el RABILLO no se recorta)')
    print('    hueco usado: %d/%d B' % (len(rec), FIN_HUECO - HUECO))
    # ==================================================================
    # (B) EL BOCADILLO DEL ABUELO
    # ==================================================================
    esp = bytes([0x38, 0xE9, 0x30])                 # SEC / SBC #$30
    assert bytes(rom[ABUELO_Y - 1:ABUELO_Y + 2]) == esp, \
        'en $88C1 no esta el SBC #$30: %s' % bytes(
            rom[ABUELO_Y - 1:ABUELO_Y + 2]).hex()
    rom[ABUELO_Y + 1] = 0x30 - ABUELO_DY            # $30 -> $1C
    print('\n(B) abuelo: $88C2 SBC #$30 -> SBC #$%02X  (baja %d px)'
          % (0x30 - ABUELO_DY, ABUELO_DY))

    esp = bytes([0x3F, 0x0F, 0x00, 0x2F, 0x28, 0xFF])
    assert bytes(rom[RABILLO2_DY - 4:RABILLO2_DY + 2]) == esp, \
        'la variante 2 del rabillo no es la esperada: %s' % bytes(
            rom[RABILLO2_DY - 4:RABILLO2_DY + 2]).hex()
    rom[RABILLO2_DY] = 0x28 - ABUELO_DY             # dY 40 -> 20
    print('    rabillo variante 2 (celda 1AF): dY 40 -> %d'
          % (0x28 - ABUELO_DY))

    # ==================================================================
    # VERIFICACION: desensamblar lo escrito DESDE LA ROM
    # ==================================================================
    print('\n--- desensamblado de lo escrito (desde la ROM ya construida)')
    import subprocess
    tmp = '/tmp/_v199.pce'
    open(tmp, 'wb').write(bytes(rom))
    for off, n, carga, nom in [
            (HUECO, len(rec), HUECO_L, 'recorte'),
            (0x41A92, 24, 0x9A92, 'las dos llamadas a $E3EB'),
            (0x168AD, 20, 0x88AD, 'ancla del abuelo'),
            (0x41AF1, 6, 0x9AF1, 'rabillo variante 2')]:
        print('\n  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp,
                            '%X' % off, str(n), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    # zonas que NO se pueden haber tocado
    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('lista de sprites', 0x47C02, 0x47CB6),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('fuente', 0x3D660, 0x3E200),
        ('cabecera y vectores', 0x1FE0, 0x2000),
        ('CG del bocadillo', 0x3D214, 0x3D660),
    ]
    base198 = open(BASE, 'rb').read()
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base198[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    d = bytes(rom)
    dif198 = [i for i in range(len(d)) if d[i] != base198[i]]
    print('%d bytes sobre la v198' % len(dif198))

    open(SALIDA, 'wb').write(d)
    parche, n = ips(orig, d)
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B, %d bytes sobre la virgen)'
          % (len(parche), n))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
