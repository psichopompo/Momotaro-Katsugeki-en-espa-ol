#!/usr/bin/env python3
"""
build_v193.py - LA MAQUETACION A 16 COLUMNAS + el rabillo que no roba
                scanlines.

LO QUE PIDE DAVID
-----------------
> «Siguen cortandose partes de las cabezas, y Sprite Viewer parece revelar
>  que es por el rabillo, que debajo de su parte visible tiene cuerpo vacio
>  que entra en las lineas de los sprites de los personajes. Se me ocurre
>  que el rabillo deberia ir en la parte mas baja de su sprite, y luego
>  subirlo para alinearlo con el bocadillo.»
>
> «pon ya la maquetacion del texto en este mismo paso»

=====================================================================
1. EL RABILLO
=====================================================================
Medido: la celda `1AD` **solo dibuja en las filas 0..8**. Las filas 9..15
estan vacias, y el sprite esta en `dY=62`, asi que ocupa los scanlines
62..77 y **gasta una ranura hasta el 77 sin pintar nada por debajo del 70**.

La solucion de David es exacta: mover el dibujo al fondo de la celda y subir
el sprite lo mismo.

```
dibujo: filas 0..8   ->   filas 7..15
dY:     62           ->   55
```

Pinta en los mismos scanlines (62..70) pero ocupa 55..70, y las filas
vacias caen **dentro** del bocadillo, donde ya hay sprites del marco.

=====================================================================
2. LA MAQUETACION A 16 COLUMNAS
=====================================================================
El guion venia repartido a 12 columnas de la rama del otro chat. Se
descomprime, se vuelve a prosa, se remaqueta a **16x4** con `maquetar.py`
(Knuth-Plass + reparto equilibrado entre paginas) y se recomprime.

```
              paginas   lineas
a 12 columnas   246       857
a 16 columnas   193       636
```

**El descompresor y su formato NO se tocan.** Solo cambian los datos: las
87 cadenas, la tabla de 48 punteros del diccionario y sus cadenas.

### El formato, desensamblado de $793B (banco $25)

```
$00        fin de cadena
$60-$8F    entrada del diccionario (tabla de 48 punteros en $7A13)
otro       literal
```

Un detalle que hubo que medir: **las entradas del diccionario pueden
contener a su vez codigos `$60-$8F`**. El motor lo permite con un solo
nivel (`$DE/$DF` guardan el puntero de vuelta). Mi primer lector los
copiaba crudos y salian caracteres raros.

### Un bug de mi compresor, cazado antes de escribir

El selector voraz marca con `\\x00` lo ya sustituido, y las candidatas de la
vuelta siguiente **incluian esa marca**: entraban entradas como `l\\x00ogr`,
que no son texto. Al filtrarlas, el guion pasa de 6867 a **6309 B**.

### El espacio

```
guion       0x48F91..0x4A484   5363
dicc viejo  0x4BA13..0x4BF40   1325
hueco       0x4BF40..0x4C000    192
                               ----
                               6880

necesario: 6309 (cadenas) + 353 (diccionario) = 6662   -> sobran 218
```

Los punteros del guion son **absolutos**, asi que las cadenas no tienen que
ir seguidas: se reparten por los tres huecos.

**No se tocan** los bloques de vitores, dinero, final, enemigos, artes,
quiz ni jan-ken-pon.

Uso:  python3 tools/build_v193.py
"""
import hashlib
import zlib
import struct
import sys
import os
import re

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime
from charset_oficial import CHAR_TO_CODE
from guion_v192 import leer, off, punteros, dic
import maquetar
import comprime_guion

BASE = 'roms/momotaro_es_v192.pce'
SALIDA = 'roms/momotaro_es_v193.pce'
IPS = 'parches/momotaro_v193.ips'
MD5_BASE = '33049b0ea61ca86e517ce8b082266b79'

COD = dict(CHAR_TO_CODE)
COD['b'], COD['c'], COD['p'] = 0xA2, 0xA3, 0xB0
COD['\n'] = 0x3B
INV = {v: k for k, v in CHAR_TO_CODE.items()}
INV[0xA2], INV[0xA3], INV[0xB0] = 'b', 'c', 'p'

CG_INI = 0x3D660 - 609
RABILLO = 0x41ADD
TABLA_DIC = 0x4BA13
PUNTEROS = 0x48000
COLS, LINEAS = 16, 4

HUECOS = [(0x48F91, 0x4A484), (0x4BA13, 0x4BF40), (0x4BF40, 0x4C000)]
B24 = 0x48000 - 0x4000
B25 = 0x4A000 - 0x6000


def log(o):
    """ROM -> direccion logica (MPR2 para el banco $24, MPR3 para el $25)."""
    if o < 0x4A000:
        return o - B24
    return o - B25


def setp(c, x, y, col):
    w = list(struct.unpack('<64H', bytes(c)))
    b = 15 - x
    for p in range(4):
        if (col >> p) & 1:
            w[p * 16 + y] |= 1 << b
        else:
            w[p * 16 + y] &= ~(1 << b) & 0xFFFF
    c[:] = struct.pack('<64H', *w)


def getp(c, x, y):
    w = struct.unpack('<64H', bytes(c))
    b = 15 - x
    return ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
        | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v192 (md5 %s)' % md5
    orig = bytes(rom)

    # ==================================================================
    # 1. EL RABILLO: dibujo al fondo de la celda, sprite 7 px mas arriba
    # ==================================================================
    f = Flujo(rom, CG_INI)
    cg = [bytearray(b''.join(tile(f) for _ in range(4))) for _ in range(20)]
    fin_cg = f.p

    rab = cg[0x1AD - 0x19C]
    filas = [y for y in range(16)
             if any(getp(rab, x, y) for x in range(16))]
    assert filas == list(range(9)), \
        'el rabillo dibuja en las filas %s, esperaba 0..8' % filas
    DESP = 15 - max(filas)          # 7
    print('rabillo: dibuja en las filas 0..%d, %d vacias abajo'
          % (max(filas), DESP))

    copia = [[getp(rab, x, y) for x in range(16)] for y in range(16)]
    for y in range(16):
        for x in range(16):
            setp(rab, x, y, copia[y - DESP][x] if y >= DESP else 0)
    nuevas = [y for y in range(16) if any(getp(rab, x, y) for x in range(16))]
    assert nuevas == list(range(DESP, 16)), \
        'tras mover, el dibujo esta en %s' % nuevas
    print('  dibujo movido a las filas %d..15' % DESP)

    # recomprimir el CG
    stream = b''.join(comprime(bytes(c)) for c in cg)
    ini = 0x3D660 - len(stream)
    assert ini - 1 >= 0x3D3D4, 'el CG nuevo no cabe'
    rom[ini:0x3D660] = stream
    rom[ini - 1] = 20
    rom[0x3D3D4:ini - 1] = b'\xFF' * (ini - 1 - 0x3D3D4)
    for o, nom in ((0x41C3C, 'puntero $9C32'), (0x41C4E, 'cuenta $9C4E')):
        pass
    lg = 0x4000 + (ini - 0x3C000)
    rom[0x41C3D] = lg & 0xFF
    rom[0x41C41] = lg >> 8
    lc = 0x4000 + (ini - 1 - 0x3C000)
    rom[0x41C4F] = lc & 0xFF
    rom[0x41C50] = lc >> 8
    print('  CG: %d B en 0x%05X, cuenta en 0x%05X' % (len(stream), ini, ini - 1))

    # y subir el sprite
    for v in range(4):
        p = rom[RABILLO + v * 2] | (rom[RABILLO + v * 2 + 1] << 8)
        o = 0x40000 + (p - 0x8000)
        celda = 0x170 + rom[o]
        if celda != 0x1AD:
            continue
        dy = rom[o + 4]
        sdy = dy - 256 if dy > 127 else dy
        rom[o + 4] = (sdy - DESP) & 0xFF
        print('  variante %d: dY %d -> %d (dibuja igual, ocupa %d..%d)'
              % (v, sdy, sdy - DESP, sdy - DESP, sdy - DESP + 15))

    # ==================================================================
    # 2. LA MAQUETACION
    # ==================================================================
    ps = punteros(orig)
    uniq = []
    for p in ps:
        if p not in uniq:
            uniq.append(p)
    assert len(uniq) == 87, 'hay %d textos distintos, esperaba 87' % len(uniq)

    textos = []
    for p in uniq:
        d, _ = leer(orig, off(p))
        falta = sorted({c for c in d if c != 0x3B and c not in INV})
        assert not falta, 'codigos sin traducir en el texto $%04X: %s' % (
            p, [hex(c) for c in falta])
        s = ''.join(' ' if c == 0x3B else INV[c] for c in d)
        textos.append(re.sub(r'\s+', ' ', s).strip())
    print('\n%d textos leidos del guion, sin codigos desconocidos' % len(textos))

    maq = []
    for t in textos:
        pags = maquetar.maquetar(t, COLS, LINEAS)
        for pg in pags:
            for l in pg:
                assert len(l) <= COLS, 'linea de %d caracteres: %r' % (len(l), l)
        maq.append('\n'.join('\n'.join(pg) for pg in pags))
    print('remaquetado a %dx%d: %d paginas, %d lineas'
          % (COLS, LINEAS,
             sum(len(maquetar.maquetar(t, COLS, LINEAS)) for t in textos),
             sum(m.count('\n') + 1 for m in maq)))

    ent = comprime_guion.elegir(maq, 48, 3, 24)
    assert len(ent) == 48, 'el diccionario tiene %d entradas' % len(ent)
    assert not any(comprime_guion.MARCA in e for e in ent), \
        'una entrada lleva la marca interna del selector'
    for e in ent:
        for ch in e:
            assert ch in COD, 'la entrada %r tiene el caracter %r' % (e, ch)

    cadenas = [comprime_guion.codifica(t, ent, COD) + b'\x00' for t in maq]
    # round-trip de la compresion, contra el propio formato del motor
    def expande(b):
        out = bytearray()
        for x in b[:-1]:
            if 0x60 <= x <= 0x8F:
                for ch in ent[x - 0x60]:
                    out.append(COD[ch])
            else:
                out.append(x)
        return bytes(out)
    for k, (c, m) in enumerate(zip(cadenas, maq)):
        esperado = bytes(COD[ch] for ch in m)
        assert expande(c) == esperado, 'round-trip roto en el texto %d' % k
    print('  round-trip de los 87 textos: OK')

    datos = bytearray()
    off_ent = []
    for e in ent:
        off_ent.append(len(datos))
        datos += bytes(COD[ch] for ch in e) + b'\x00'
    total = sum(len(c) for c in cadenas) + len(datos) + 96
    cap = sum(b - a for a, b in HUECOS)
    print('  cadenas %d B + diccionario %d B + tabla 96 B = %d (caben %d)'
          % (sum(len(c) for c in cadenas), len(datos), total, cap))
    assert total <= cap, 'no cabe por %d B' % (total - cap)

    # colocar: primero el diccionario en el hueco de la tabla vieja
    for a, b in HUECOS:
        rom[a:b] = b'\x00' * (b - a)
    libre = [[a, b] for a, b in HUECOS]

    def reservar(n):
        for h in libre:
            if h[1] - h[0] >= n:
                o = h[0]
                h[0] += n
                return o
        raise AssertionError('sin sitio para %d B' % n)

    # La tabla del diccionario TIENE que quedarse en $7A13 (0x4BA13): la
    # referencian $79BE y $79C3 con LDA $7A13,Y absoluto. Se reserva a mano
    # en su hueco, no con el asignador.
    assert TABLA_DIC == 0x4BA13
    h = [x for x in libre if x[0] == 0x4BA13]
    assert h, 'el hueco del diccionario no empieza en 0x4BA13'
    base_tabla = h[0][0]
    h[0][0] += 96
    assert bytes(orig[0x4B9BE:0x4B9C1]) == bytes([0xB9, 0x13, 0x7A]), \
        'el LDA $7A13,Y de $79BE no es el esperado'
    o_datos = reservar(len(datos))
    rom[o_datos:o_datos + len(datos)] = datos
    for k, d in enumerate(off_ent):
        a = log(o_datos + d)
        rom[base_tabla + k * 2] = a & 0xFF
        rom[base_tabla + k * 2 + 1] = a >> 8

    pos = {}
    for k, c in enumerate(cadenas):
        o = reservar(len(c))
        rom[o:o + len(c)] = c
        pos[uniq[k]] = log(o)
    for k, p in enumerate(ps):
        a = pos[p]
        rom[PUNTEROS + k * 2] = a & 0xFF
        rom[PUNTEROS + k * 2 + 1] = a >> 8
    print('  colocado; libre: %s'
          % ['0x%05X..0x%05X' % (h[0], h[1]) for h in libre if h[1] > h[0]])

    # releer con el lector real y comparar
    import importlib
    import guion_v192
    importlib.reload(guion_v192)
    for k, p in enumerate(ps):
        a = rom[PUNTEROS + k * 2] | (rom[PUNTEROS + k * 2 + 1] << 8)
        d, _ = guion_v192.leer(bytes(rom), guion_v192.off(a))
        s = ''.join('\n' if c == 0x3B else INV.get(c, '?') for c in d)
        assert s == maq[uniq.index(p)], 'el texto %d no se relee bien' % k
    print('  releidos los 116 punteros con el descompresor real: OK')

    # ==================================================================
    intactas = [
        ('vitores', 0x480E8, 0x48C71),
        ('dinero', 0x48C71, 0x48F91),
        ('final y creditos', 0x4A484, 0x4A7B9),
        ('nombres de enemigos', 0x4A7B9, 0x4AE8A),
        ('artes', 0x4AE8A, 0x4AEE6),
        ('quiz', 0x4AEE6, 0x4B8C0),
        ('jan-ken-pon', 0x4B8C0, 0x4B93B),
        ('descompresor', 0x4B93B, 0x4BA13),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        o2 = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n2 = raw[p + 3] << 8 | raw[p + 4]
        prueba[o2:o2 + n2] = raw[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  1. El texto usando las 16 columnas: menos paginas y lineas')
    print('     mas largas (246 -> 193 paginas).')
    print('  2. Las cabezas completas: el rabillo ya no roba scanlines')
    print('     por debajo del bocadillo.')


if __name__ == '__main__':
    main()
