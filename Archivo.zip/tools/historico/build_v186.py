#!/usr/bin/env python3
"""
build_v186.py - los tres arreglos que pide David sobre la v185.

LO QUE REPORTA DAVID (con capturas)
-----------------------------------
1. «Hay que bajar 8 px el bocadillo para que se alinee con el rabillo
   (que quedaría 1 px superpuesto para tapar la línea de contorno).»
2. «El texto tiene un margen izquierdo de 3 px. Lo ideal son 8 px.»
3. «Tenemos un recuadro transparente dentro del bocadillo que deja ver
   el fondo.»

LOS TRES SON EL MISMO ERROR MIO
-------------------------------
Medida la v185:

```
 y= 0: -80..-48(19C) -48..-32(19D) ... 64..80(1AC)
 y=16: -80..-64(1A0) -77..51(relleno 170-177) 67..83(1A1)
                          ^^^^^^^^^^^^^^^^^^  ^^
                          acaba en 51         empieza en 67
                                    -> 16 px TRANSPARENTES
```

Arrastre `DESP = 3` de la v177, donde el relleno iba pegado al lateral
izquierdo. Con el marco de 160 px y el texto de 128, eso deja el texto
a 3 px del borde (David pide 8) y **16 px sin relleno** a la derecha:
el recuadro transparente.

LA GEOMETRIA BUENA, MEDIDA PIEZA A PIEZA
----------------------------------------
Del CG volcado (`docs/aldeano_vram.bin`):

```
1A0 lateral izq: dibuja las columnas 0-2 (el trazo). 3-15 transparentes.
1A1 lateral der: BLANCO en 0-11, trazo en la 12, 13-15 transparentes.
1AC esquina sup der: el trazo en la columna 15.
```

El ancho del marco tiene que ser `32 + N*16 + 16` para que los bordes
encajen sin huecos. Con el texto de 128 px y margen de 8 a cada lado:

```
N=6 -> marco de 144 px, margen 8   <- EXACTO, lo que pide David
N=7 -> marco de 160 px, margen 16  <- lo que hay hoy
```

Asi que el marco **encoge de 160 a 144** y el texto queda con sus 8 px.

```
X0 = -72
borde sup: 19C(-72..-40) 19D x6 (-40..56) 1AC(56..72)     continuo
texto:     -64 .. 64   (8 celdas de 16)
lat izq:   1A0 en -72, trazo en -72..-69   -> margen 8 hasta el texto
lat der:   1A1 en  59, blanco 59..71, trazo en 71
           el trazo de 1AC cae en 71: ALINEADOS
           su blanco solapa 5 px sobre el relleno -> NO hay hueco
```

Y el orden importa: en el SATB el indice bajo se dibuja ENCIMA (norma 55),
asi que el lateral derecho va **despues** del relleno en la lista, para que
el relleno no le tape el trazo... al reves: va ANTES, para que su blanco
quede por encima del ultimo relleno y tape la union. Se pone antes.

EL DESCENSO DE 8 PX
-------------------
`Y0 = 0` -> `Y0 = 8`. El bocadillo entero baja 8 px y el borde inferior
queda 1 px por debajo del rabillo, que lo tapa (norma 55: el rabillo se
emite en la 1a llamada a `$E3EB`, indice menor, va encima).

Uso:  python3 tools/build_v186.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v185.pce'
SALIDA = 'roms/momotaro_es_v186.pce'
IPS = 'parches/momotaro_v186.ips'
MD5_BASE = 'cf63eadf75b4b6462bf55552b3d15988'

LISTA = 0x47C02
LISTA_FIN = 0x48000
TABLA = 0x41BBD
BASE_CELDA = 0x170

ESQ_SI, BORDE_S, ESQ_SD = 0x19C, 0x19D, 0x1AC
ESQ_II, BORDE_I, ESQ_ID = 0x19E, 0x19F, 0x1AE
LAT_I, LAT_D = 0x1A0, 0x1A1
TAPON = 0x1A6                # relleno blanco del CG original

CELDA0 = 0x170
COLS = 16
ANCHO_TXT = COLS * 8         # 128
FILAS_CEL = 2                # 2 filas de celdas = 4 lineas

N_BORDES = 7                 # marco de 32 + 7*16 + 16 = 160
ANCHO = 32 + N_BORDES * 16 + 16
MARGEN = 8                           # David: 8 px desde el trazo
X0 = -(ANCHO // 2)                   # -72
Y0 = 8                               # David: bajar 8 px

# el trazo del lateral derecho esta en su columna 12; el de la esquina
# superior derecha, en la 15. Para alinearlos:
TRAZO_DER = X0 + ANCHO - 1           # 71
LAT_D_X = TRAZO_DER - 12             # 59


def reg(celda, b1, b2, dx, dy):
    b0 = celda - BASE_CELDA
    assert 0 <= b0 <= 255, 'celda %03X fuera del alcance' % celda
    return [b0, b1, b2, dx & 0xFF, dy & 0xFF]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v185 (md5 %s)' % md5
    orig = bytes(rom)

    escribe = sorted({(rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)) // 64
                      for k in range(32)})
    assert escribe == list(range(CELDA0, CELDA0 + 8))

    print('marco: %d px de ancho (32 + %d*16 + 16), margen del texto %d px'
          % (ANCHO, N_BORDES, MARGEN))
    print('  X0=%d  Y0=%d (baja 8 px)' % (X0, Y0))
    assert MARGEN == 8, 'el margen sale %d, no 8' % MARGEN
    # los 16 glifos tienen que caber ENTEROS antes del lateral derecho.
    # Con el marco de 144 el texto acababa en x=64 y el blanco del lateral
    # empezaba en 59: las dos ultimas columnas quedaban tapadas. Se vio en
    # el mockup, no en los numeros.
    fin_txt = X0 + MARGEN + ANCHO_TXT
    assert fin_txt <= LAT_D_X, \
        'los %d glifos no caben: el texto acaba en %d y el lateral derecho ' \
        'tapa desde %d (%d px perdidos)' % (COLS, fin_txt, LAT_D_X,
                                            fin_txt - LAT_D_X)
    print('  los %d glifos caben enteros: texto hasta %d, lateral desde %d'
          % (COLS, fin_txt, LAT_D_X))

    nueva = []

    # --- borde superior ---
    nueva.append(reg(ESQ_SI, 0x0F, 0x01, X0, Y0))
    for i in range(N_BORDES):
        nueva.append(reg(BORDE_S, 0x0F, 0x00, X0 + 32 + i * 16, Y0))
    nueva.append(reg(ESQ_SD, 0x0F, 0x00, X0 + 32 + N_BORDES * 16, Y0))

    # --- filas de texto ---
    # el lateral DERECHO va antes que el relleno: su blanco (12 px) tiene
    # que quedar POR ENCIMA del ultimo relleno para tapar la union
    # (norma 55: indice bajo = se dibuja encima).
    for fila in range(FILAS_CEL):
        y = Y0 + 16 + fila * 16
        nueva.append(reg(LAT_I, 0x0F, 0x00, X0, y))
        nueva.append(reg(LAT_D, 0x0F, 0x00, LAT_D_X, y))
        for k in range(8):
            nueva.append(reg(CELDA0 + fila * 8 + k, 0x0F, 0x00,
                             X0 + MARGEN + k * 16, y))
        # TAPON del hueco izquierdo. El lateral 1A0 solo dibuja 3 px
        # (columnas 0-2) y el resto es transparente; al subir el margen de 3
        # a 8 quedaban 5 px de fondo a la vista, que es lo que se veia en el
        # mockup. Se cubre con una celda de relleno blanco puesta en X0+3,
        # AL FINAL de la lista (indice mayor = se dibuja DEBAJO, norma 55):
        # solo asoma por el hueco, el resto lo tapa el relleno del texto.
        # 1A6 es una celda de relleno blanco del CG original y el motor ya
        # no escribe en ella (la tabla apunta a 170-177).
        nueva.append(reg(TAPON, 0x0F, 0x00, X0 + 3, y))
        # y el mismo tapon a la DERECHA: el texto acaba antes de que empiece
        # el blanco del lateral derecho, y entre medias asomaria el fondo.
        nueva.append(reg(TAPON, 0x0F, 0x00, LAT_D_X - 16, y))

    # --- borde inferior ---
    yb = Y0 + 16 + FILAS_CEL * 16
    nueva.append(reg(ESQ_II, 0x0F, 0x01, X0, yb))
    for i in range(N_BORDES):
        nueva.append(reg(BORDE_I, 0x0F, 0x00, X0 + 32 + i * 16, yb))
    nueva.append(reg(ESQ_ID, 0x0F, 0x00, X0 + 32 + N_BORDES * 16, yb))

    print('sprites: %d' % len(nueva))

    # --- verificaciones -------------------------------------------------
    dibuja = {r[0] + BASE_CELDA for r in nueva}
    faltan = set(escribe) - dibuja
    assert not faltan, 'NORMA 101: %s no las dibuja nadie' % sorted(
        '%03X' % c for c in faltan)
    print('norma 101: las 8 celdas de texto se dibujan')

    for r in nueva:
        celda = r[0] + BASE_CELDA
        if r[2] & 0x01:
            assert celda % 2 == 0, 'sprite de 32 px con celda impar %03X' % celda
        dx = r[3] - 256 if r[3] > 127 else r[3]
        dy = r[4] - 256 if r[4] > 127 else r[4]
        assert -128 <= dx <= 127 and -128 <= dy <= 127, 'dX/dY fuera de rango'

    # bordes continuos y del ancho exacto
    for y in (Y0, yb):
        t = sorted((r[3] - 256 if r[3] > 127 else r[3],
                    (r[3] - 256 if r[3] > 127 else r[3]) + (32 if r[2] & 1 else 16))
                   for r in nueva
                   if (r[4] - 256 if r[4] > 127 else r[4]) == y)
        for i in range(len(t) - 1):
            assert t[i][1] == t[i + 1][0], 'hueco en el borde y=%d: %s %s' % (
                y, t[i], t[i + 1])
        assert t[0][0] == X0 and t[-1][1] == X0 + ANCHO, \
            'el borde y=%d cubre %d..%d, esperaba %d..%d' % (
                y, t[0][0], t[-1][1], X0, X0 + ANCHO)
    print('bordes continuos de %d a %d' % (X0, X0 + ANCHO))

    # el tapon tiene que ser blanco puro y no estar en la tabla de texto
    import struct as _s
    _v = open('docs/aldeano_vram.bin', 'rb').read()
    _w = _s.unpack('<64H', _v[TAPON * 128:TAPON * 128 + 128])
    assert all(_w[y] == 0xFFFF and _w[16 + y] == 0xFFFF and _w[32 + y] == 0xFFFF
               for y in range(16)), 'la celda %03X no es blanco puro' % TAPON
    assert TAPON not in escribe, 'el motor escribe en el tapon %03X' % TAPON
    # y tiene que cubrir el hueco entero
    assert X0 + 3 <= X0 + MARGEN and X0 + 3 + 16 >= X0 + MARGEN, \
        'el tapon no cubre el hueco'
    print('tapon %03X en x=%d: cubre el hueco de %d px entre el trazo y el texto'
          % (TAPON, X0 + 3, MARGEN - 3))

    # no puede quedar fondo a la vista en NINGUN punto de la fila de texto.
    # Se comprueba cubriendo el intervalo [X0+3, trazo derecho] con los
    # tramos BLANCOS de cada sprite de la fila (el relleno cubre sus 16 px;
    # el lateral derecho, sus 12 primeros; el tapon, 16).
    fin_relleno = X0 + MARGEN + 8 * 16
    tramos = [(X0 + MARGEN + k * 16, X0 + MARGEN + k * 16 + 16)
              for k in range(8)]
    tramos.append((X0 + 3, X0 + 19))                 # tapon izquierdo
    tramos.append((LAT_D_X - 16, LAT_D_X))           # tapon derecho
    tramos.append((LAT_D_X, LAT_D_X + 12))           # blanco del lateral der
    tramos.sort()
    x = X0 + 3
    for a, b in tramos:
        if a > x:
            raise AssertionError(
                'fondo a la vista de %d a %d en la fila de texto' % (x, a))
        x = max(x, b)
    assert x >= LAT_D_X + 12, 'la fila de texto no llega al trazo derecho'
    print('fila de texto cubierta de %d a %d, sin fondo a la vista'
          % (X0 + 3, x))

    # el trazo derecho alineado con el de la esquina
    assert LAT_D_X + 12 == X0 + ANCHO - 1, 'los trazos derechos no se alinean'
    print('trazo derecho alineado en x=%d (lateral y esquina)' % (LAT_D_X + 12))

    # margen izquierdo real
    assert (X0 + MARGEN) - X0 == 8, 'el margen izquierdo no es 8'
    print('margen izquierdo: %d px desde el trazo' % MARGEN)

    # --- escribir --------------------------------------------------------
    assert LISTA + len(nueva) * 5 + 1 <= LISTA_FIN
    off = LISTA
    for r in nueva:
        rom[off:off + 5] = bytes(r)
        off += 5
    rom[off] = 0xFF
    for k in range(off + 1, LISTA + 220):
        rom[k] = 0xFF
    print('lista: 0x%05X..0x%05X (%d sprites)' % (LISTA, off, len(nueva)))

    print()
    print('bocadillo: %d x %d px, de y=%d a y=%d'
          % (ANCHO, 16 + FILAS_CEL * 16 + 16, Y0, yb + 16))

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('cargador del CG', 0x41AAE, 0x41ACD),
        ('tabla rabillo', 0x41ADD, 0x41AFD),
        ('base del patron', 0x41A7B, 0x41A83),
        ('fuente', 0x3D660, 0x3E200),
        ('flecha', 0x419E2, 0x419F3),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('intactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    fuera = [i for i in dif if not (LISTA <= i < LISTA + 220)]
    assert not fuera, 'cambios fuera de la lista: %s' % [hex(i) for i in fuera[:8]]
    print('%d bytes modificados, todos en la lista de sprites' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    a, b = min(dif), max(dif) + 1
    rec = bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                 (b - a) >> 8, (b - a) & 0xFF]) + d[a:b]
    open(IPS, 'wb').write(b'PATCH' + rec + b'EOF')
    prueba = bytearray(orig)
    prueba[a:b] = d[a:b]
    assert bytes(prueba) == d
    print('IPS round-trip OK')

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('LOS TRES ARREGLOS')
    print('  1. bajado 8 px (Y0=0 -> 8)')
    print('  2. margen izquierdo 3 -> 8 px (marco de 160 -> 144)')
    print('  3. recuadro transparente: eliminado, el lateral derecho solapa')
    print('     5 px sobre el relleno')


if __name__ == '__main__':
    main()
