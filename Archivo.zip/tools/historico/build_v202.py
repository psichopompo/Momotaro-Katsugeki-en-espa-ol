#!/usr/bin/env python3
"""
build_v202.py - LA MUDANZA: el buffer de texto sale de 170-17F.

EL BUG QUE MATA
---------------
Los cuadros verdes sobre el arma proyectil, sobre el jefe final y el cuadro
que le falta a la bola del minijuego son EL MISMO BUG, y es culpa mia.

En la v185 movi la base de patron del bocadillo de $0338 a $02E0 para meter
las 16 celdas de texto en 170-17F. Verifique que nadie usaba ese tramo...
pero solo en los states que tenia ENTONCES. El juego lo usa para el
proyectil y para parte del jefe final.

Prueba (states `Disparo cuadro verde` y `Recuadro verde sobre enemigo`, los
dos con $3654=0, o sea SIN dialogo abierto):

    celda 173 = un cuadrado macizo de color 7 (el blanco del bocadillo)
    celda 170 = se leen LETRAS en color F sobre fondo 7

Son los restos del ultimo bocadillo. Por eso David dice «a ese jefe ya me lo
habia pasado antes y no tenia ese bug»: solo aparece DESPUES de hablar.

EL DESTINO, AUDITADO
--------------------
`tools/audita_vram.py` sobre 22 volcados, contando SAT + patrones de BAT +
**el espacio que la BAT OCUPA** (la BAT es 64x64 = words $0000-$0FFF = las
celdas 000-03F; en el estado anterior las di por libres por error) + el
SATB (word $7F00 = celda 1FC).

```
040-0BF  fondo          0C0-16F  sprites del juego
170-17F  TEXTO (aqui esta el bug)     180-18D  jefe final (con huecos)
18E-19B  LIBRE (14)     19C-1AF  marco del bocadillo (20 cargadas, 10 usadas)
```

Hacen falta **16 celdas contiguas** porque el cargador de celdas blancas
(`$9AAE`) hace `LDX #$10` con autoincremento. En `18E-19B` solo hay 14.

**La salida**: el marco carga 20 celdas (`19C-1AF`) pero solo usa 10. Las
`1A2-1AB` son el relleno viejo, muerto desde la v193. Repaquetando el marco
a 10 celdas se libera sitio y todo encaja:

```
TEXTO : 18E-19D  (16 contiguas)      <- base de patron nueva
MARCO : 19E-1A7  (10)
libre : 1A8-1AF  (8, de propina)
```

Los dos sprites de 32 px (`19C` y `19E`) caen en `19E` y `1A0`, los dos
**pares**, que es obligatorio: el VDC ignora el bit 0 del patron en los
sprites anchos.

LAS CINCO PIEZAS QUE HAY QUE TOCAR
----------------------------------
1. `$9A7B`  base de patron: `$02E0` -> `$031C`   (celda * 2)
2. `$9AB6`  destino del cargador de blancas: word `$5C00` -> `$6380`
3. `$9BBD`  tabla de 36 destinos VRAM (word = celda*64, +$30 de fila)
4. `$7C02`  lista de sprites: `b0 = celda - base` para las 36 entradas
5. `$9ADD`  tabla de rabillos: los `b0` de las 4 variantes
6. el CG del marco se recomprime en el orden nuevo

Uso:  python3 tools/build_v202.py
"""
import hashlib
import zlib
import struct
import subprocess
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v201.pce'
SALIDA = 'roms/momotaro_es_v202.pce'
IPS = 'parches/momotaro_v202.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '9a2dff6245c99b3f5a81b77ecf7b7f72'

VIEJA = 0x170                   # base de patron actual
NUEVA = 0x18E                   # base nueva: el texto va a 18E-19D

# el marco: celda vieja -> celda nueva (repaquetado, 20 -> 10)
MARCO = {0x19C: 0x19E, 0x19D: 0x19F, 0x19E: 0x1A0, 0x19F: 0x1A1,
         0x1A0: 0x1A2, 0x1A1: 0x1A3, 0x1AC: 0x1A4, 0x1AD: 0x1A5,
         0x1AE: 0x1A6, 0x1AF: 0x1A7}

PAT_LO = 0x41A7C                # operando del $9A7B LDA #$E0
PAT_HI = 0x41A80                # operando del      LDA #$02
BLA_LO = 0x41AB7                # operando del $9AB6 LDA #$00  (destino word)
BLA_HI = 0x41ABC                # operando del      LDA #$5C
TABLA = 0x41BBD                 # 36 words de destino
LISTA = 0x47C02                 # lista de sprites del cuerpo
RABILLOS = 0x41ADD              # 4 punteros + 4 listas de 1 sprite
CG_PTR_LO = 0x41C3D             # $9C3C LDA #lo  -> puntero del CG
CG_PTR_HI = 0x41C41
CG_CNT = 0x41C4F                # $9C4E LDX abs -> cuenta de celdas
BANCO_1E = 0x3C000


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v201'
    print('base %s  OK' % BASE)
    print('\nmudanza: TEXTO %03X-%03X -> %03X-%03X   MARCO -> %03X-%03X'
          % (VIEJA, VIEJA + 15, NUEVA, NUEVA + 15,
             min(MARCO.values()), max(MARCO.values())))

    # los sprites de 32 px tienen que caer en celda PAR
    for v in (0x19C, 0x19E):
        assert MARCO[v] % 2 == 0, \
            'la celda %03X es de 32 px y va a %03X, que es IMPAR' % (
                v, MARCO[v])
    # nadie se pisa
    destinos = set(range(NUEVA, NUEVA + 16)) | set(MARCO.values())
    assert len(destinos) == 26, 'hay celdas que se solapan'
    print('  sin solapes, y los sprites de 32 px caen en celda par')

    # ==================================================================
    # 1. base de patron  ($9A7B)
    # ==================================================================
    assert rom[PAT_LO - 1] == 0xA9 and rom[PAT_HI - 1] == 0xA9, \
        'el prologo de $9A7B no tiene la forma esperada'
    viejo = rom[PAT_LO] | (rom[PAT_HI] << 8)
    assert viejo == VIEJA * 2, \
        'la base de patron es $%04X, esperaba $%04X' % (viejo, VIEJA * 2)
    nuevo = NUEVA * 2
    rom[PAT_LO] = nuevo & 0xFF
    rom[PAT_HI] = nuevo >> 8
    print('\n1. base de patron $9A7B: $%04X -> $%04X' % (viejo, nuevo))

    # ==================================================================
    # 2. cargador de las 16 celdas blancas ($9AB6)
    # ==================================================================
    assert rom[BLA_LO - 1] == 0xA9 and rom[BLA_HI - 1] == 0xA9, \
        'el cargador de blancas no tiene la forma esperada'
    dv = rom[BLA_LO] | (rom[BLA_HI] << 8)
    assert dv == VIEJA * 64, \
        'el destino de las blancas es $%04X, esperaba $%04X' % (
            dv, VIEJA * 64)
    dn = NUEVA * 64
    rom[BLA_LO] = dn & 0xFF
    rom[BLA_HI] = dn >> 8
    print('2. destino de las 16 blancas: word $%04X -> $%04X' % (dv, dn))

    # ==================================================================
    # 3. tabla de destinos VRAM ($9BBD, 36 words)
    # ==================================================================
    print('3. tabla $9BBD:')
    cambios = 0
    for i in range(36):
        o = TABLA + i * 2
        w = rom[o] | (rom[o + 1] << 8)
        celda, resto = divmod(w, 64)
        assert VIEJA <= celda <= VIEJA + 15, \
            'la entrada %d apunta a la celda %03X, fuera del buffer' % (
                i, celda)
        nw = (celda - VIEJA + NUEVA) * 64 + resto
        rom[o] = nw & 0xFF
        rom[o + 1] = nw >> 8
        cambios += 1
    print('   %d entradas repuntadas ($%04X.. -> $%04X..)'
          % (cambios, VIEJA * 64 + 0x30, NUEVA * 64 + 0x30))

    # ==================================================================
    # 4. lista de sprites del cuerpo ($7C02)
    # ==================================================================
    print('4. lista de sprites $7C02:')
    i = LISTA
    n = 0
    while rom[i] != 0xFF:
        celda = VIEJA + rom[i]
        if VIEJA <= celda <= VIEJA + 15:
            nc = celda - VIEJA + NUEVA          # el texto
        else:
            assert celda in MARCO, \
                'la entrada %d usa la celda %03X, que no se donde va' % (
                    n, celda)
            nc = MARCO[celda]
        rom[i] = nc - NUEVA
        assert 0 <= rom[i] <= 0xFF, 'b0 fuera de rango'
        i += 5
        n += 1
    assert n == 36, 'esperaba 36 sprites, hay %d' % n
    print('   %d entradas: b0 = celda - $%03X' % (n, NUEVA))

    # ==================================================================
    # 5. tabla de rabillos ($9ADD)
    # ==================================================================
    print('5. tabla de rabillos $9ADD:')
    for k in range(4):
        p = rom[RABILLOS + k * 2] | (rom[RABILLOS + k * 2 + 1] << 8)
        o = 0x40000 + (p - 0x8000)
        celda = VIEJA + rom[o]
        assert celda in MARCO, \
            'la variante %d usa la celda %03X' % (k, celda)
        rom[o] = MARCO[celda] - NUEVA
        print('   variante %d: celda %03X -> %03X  (b0 %02X)'
              % (k, celda, MARCO[celda], rom[o]))

    # ==================================================================
    # 6. el CG del marco, reordenado
    # ==================================================================
    ptr = rom[CG_PTR_LO] | (rom[CG_PTR_HI] << 8)
    cnt = rom[CG_CNT] | (rom[CG_CNT + 1] << 8)
    CG = BANCO_1E + (ptr - 0x4000)
    CN = BANCO_1E + (cnt - 0x4000)
    assert rom[CN] == 20, 'la cuenta no es 20 sino %d' % rom[CN]
    f = Flujo(bytes(rom), CG)
    celdas = [b''.join(tile(f) for _ in range(4)) for _ in range(20)]
    fin = f.p
    print('6. CG: 20 celdas en ROM 0x%05X..0x%05X (%d B)'
          % (CG, fin, fin - CG))

    # el stream carga consecutivamente desde 19C. Con el marco repaquetado
    # a 10 celdas consecutivas desde 19E, hay que reordenar y recortar.
    orden = sorted(MARCO, key=lambda c: MARCO[c])
    nuevas = [celdas[c - 0x19C] for c in orden]
    print('   nuevo orden: %s' % ' '.join('%03X' % c for c in orden))
    print('   de 20 celdas a %d' % len(nuevas))

    stream = comprime(b''.join(nuevas))
    hueco = fin - CG
    assert len(stream) <= hueco, \
        'no cabe: %d > %d' % (len(stream), hueco)
    rom[CN] = len(nuevas)
    rom[CG:CG + len(stream)] = stream
    if len(stream) < hueco:
        rom[CG + len(stream):fin] = b'\xFF' * (hueco - len(stream))
    print('   recomprimido: %d B (hueco %d, sobran %d)'
          % (len(stream), hueco, hueco - len(stream)))

    # ...y el destino del cargador del marco ($9C44): word de la celda 19E
    d = rom[0x41C45] | (rom[0x41C4A] << 8)
    assert rom[0x41C44] == 0xA9 and rom[0x41C49] == 0xA9, \
        'el cargador del marco no tiene la forma esperada'
    assert d == 0x19C * 64, \
        'el destino del marco es $%04X, esperaba $%04X' % (d, 0x19C * 64)
    dn2 = MARCO[0x19C] * 64
    rom[0x41C45] = dn2 & 0xFF
    rom[0x41C4A] = dn2 >> 8
    print('   destino del marco: word $%04X -> $%04X' % (d, dn2))

    # ==================================================================
    # verificacion
    # ==================================================================
    tmp = '/tmp/_v202.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM construida')
    for off, nb, carga, nom in [(0x41A7B, 8, 0x9A7B, 'base de patron'),
                                (0x41AB6, 8, 0x9AB6, 'cargador de blancas'),
                                (0x41C44, 12, 0x9C44, 'cargador del marco')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % off,
                            str(nb), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    # el CG, releido de la ROM final
    ptr2 = rom[CG_PTR_LO] | (rom[CG_PTR_HI] << 8)
    f2 = Flujo(bytes(rom), BANCO_1E + (ptr2 - 0x4000))
    rel = [b''.join(tile(f2) for _ in range(4)) for _ in range(rom[CN])]
    assert rel == nuevas, 'el round-trip del CG falla'
    print('\n  round-trip del CG (%d celdas): OK' % len(rel))

    # y la lista, releida
    print('\n--- lista de sprites (celda absoluta, desde la ROM)')
    i = LISTA
    vistas = []
    while rom[i] != 0xFF:
        vistas.append(NUEVA + rom[i])
        i += 5
    from collections import Counter
    c = Counter(vistas)
    print('    %s' % ' '.join('%03X x%d' % (k, v)
                              for k, v in sorted(c.items())))
    assert all(NUEVA <= x <= max(MARCO.values()) for x in vistas), \
        'hay celdas fuera del rango nuevo'

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('rutina de recorte $FF6B', 0x1F6B, 0x1FE0),
        ('fuente', 0x3D660, 0x3E200),
        ('cabecera y vectores', 0x1FE0, 0x2000),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('texto Jizo sin traducir', 0x48F18, 0x48F91),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v201' % len(dif))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
