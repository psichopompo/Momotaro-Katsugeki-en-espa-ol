"""build_v148.py - contenidos del menu SELECT en castellano.

Parte de test_codigo_v147.pce (MD5 6c81ef8e719105fec39094d2191ce250).

QUE HACE
--------
1. Convierte la FUENTE 1 en MAYUSCULAS FINAS.
   La fuente 1 (tabla $9CB3, CG $260) es un DUPLICADO byte a byte de la
   fuente 0 (tabla $9CF3, CG $2A0): verificado, 0 tiles distintos en los 64.
   Los $02 que hay dentro de los nombres japoneses conmutan a ella y no
   cambian nada visible: son un vestigio.
   Se reapunta su tabla a los glifos $70-$89 de la fuente DIALOGO, que son
   las A-Z finas, de modo que:
        control $01 + letra  -> minuscula fina   (fuente 0)
        control $02 + letra  -> MAYUSCULA fina   (fuente 1)
   Asi la capitular sale FINA, como pidio David, y no gruesa.

2. Reescribe las 11 armas/armaduras, los 11 objetos y las 7 artes.

FORMATO DE LAS CADENAS
----------------------
Cada nombre empieza con $01 (fuente 0) y termina en $00. Para la capitular
se emite $02, la letra, y $01 para volver a minuscula.
El codigo de cada letra es el de charset_oficial (ruta alta, >= $A0).
"""
import os
import sys
import struct
import hashlib
import zlib

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
from charset_oficial import CHAR_TO_CODE

BASE = os.path.join(RAIZ, 'roms', 'test_codigo_v147.pce')
SALIDA = os.path.join(RAIZ, 'roms', 'test_contenidos_v148.pce')
MD5_BASE = '6c81ef8e719105fec39094d2191ce250'

BK = 0x42000 - 0xA000          # banco $21: logico $A000 -> ROM 0x42000
TAB_F1 = 0x41CB3               # tabla de la fuente 1
GLIFO_MAY = 0x70               # 'A' fina en la fuente DIALOGO

# 'Boku' en vez de 'Bokuto': el hueco de armas es de 57 B EXACTOS y con
# Bokuto salian 59. Mantiene la raiz japonesa (bokuto = sable de madera).
# 'Iris' en vez de 'Satsuki': satsuki es el lirio japones de mayo, asi que
# es fiel, y ademas deja 2 B de margen (Satsuki daba 33 en 32).
# Codigos LIBRES de la ruta alta (no los usa ningun texto con fuente 1),
# asignados a las 14 mayusculas que necesitamos.
MAY = {c: k for c, k in zip('ABCDFGHIKOPRSV',
       [0xAA, 0xAC, 0xAE, 0xBA, 0xBC, 0xBD, 0xBF, 0xC0,
        0xC2, 0xC3, 0xC6, 0xC9, 0xCD, 0xCE])}

ARMAS = ['Bokuto', 'Katana', 'Byakko', 'Hiryu', 'Asura', 'Fénix', 'Valor']
ARMADURAS = ['Bambú', 'Roja', 'Satsuki', 'Valor']
# Tres nombres van acortados porque su hueco es de 7 B y no se puede
# ampliar: entre las cadenas de objetos hay CODIGO EJECUTABLE (JSR/JMP/RTS),
# no espacio libre, y los 3 ceros tras 'Vuelo' los referencia el registro
# 0x433D8. Medido, no supuesto.
#   Raquetas -> Skis   (kanjiki, raquetas de nieve)
#   Vuelo    -> Alas   (momo-hien, la golondrina)
#   Oleada   -> Olas   (momo-tsunami)
# Los dos guijarros arrojadizos del original son un par simetrico:
#   nichirin no tsubute  (日輪の礎)  guijarro del disco solar
#   hyouga   no tsubute  (氷河の礎)  guijarro de glaciar
# Se traducen como FUEGO / HIELO: mantiene el paralelismo, se entiende sin
# manual y evita abreviaturas del tipo 'P.' que no dicen nada.
# Las tildes son GRATIS: e/u acentuadas ocupan 1 byte igual que las simples.
OBJETOS = ['Onigiri', 'Remedio', 'Banquete', 'Dango', 'Bonzo', 'Pedos',
           'Fuego', 'Hielo', 'Raquetas', 'Capa', 'Aletas']
ARTES = ['Vuelo', 'Salto', 'Rodar', 'Giro', 'Bomba', 'Oleada', 'Azar']

# Reserva para las cadenas que no caben en su hueco original. Se llena de
# abajo arriba y se repunta el registro correspondiente.
# Dos reservas, ambas de relleno REAL (no tablas con ceros significativos):
#   0x43D0C..0x43D18  12 B de $00 tras el bloque de armas
#   0x43FF7..0x44000   9 B de $FF al final del banco (tras la tabla movida)
POOLS = [None, (0x43FF7, 0x44000)]   # el 1o se calcula tras escribir armas

ANCHO = {'arma': 10, 'armadura': 10, 'objeto': 8, 'arte': 6}


def codifica(txt):
    """Texto -> bytes del motor $D41C.  Capitular en fuente 1 (mayus fina)."""
    # $D41C hace STZ $3BA6 al arrancar cada cadena: la fuente 0 ya esta
    # puesta, asi que el $01 inicial es redundante. Ahorra 1 B por nombre.
    out = bytearray()
    modo = 1                                  # 1 = fuente 0 (minuscula)
    for ch in txt:
        if ch == ' ':
            out.append(0xA0)
            continue
        if ch.isupper():
            if modo != 2:
                out.append(0x02); modo = 2
            assert ch in MAY, 'falta codigo para la mayuscula %r' % ch
            k = MAY[ch]
        else:
            if modo != 1:
                out.append(0x01); modo = 1
            k = CHAR_TO_CODE[ch]
            # 'b','c','p' viven en $5B/$5D/$5E: el motor los dibuja como
            # patron $200+cod y en el CG del menu SON minusculas finas
            # (verificado). El resto debe ir por la ruta alta.
            assert k >= 0xA0 or k in (0x5B, 0x5D, 0x5E), \
                '%r (cod $%02X) no da minuscula fina' % (ch, k)
        out.append(k)
    out.append(0x00)
    return bytes(out)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v147'

    # ---- 1. fuente 1 -> mayusculas finas ----
    assert rom[TAB_F1:TAB_F1 + 0x40] == rom[0x41CF3:0x41CF3 + 0x40], \
        'la fuente 1 ya no es un duplicado de la 0'
    tabla = bytearray(rom[TAB_F1:TAB_F1 + 0x40])
    # OJO 1: $A0 es el ESPACIO (separador en las cadenas japonesas).
    # OJO 2: el texto japones TAMBIEN usa la fuente 1 (hay tres $02 en el
    #        menu de dificultad). Si redefino los codigos que el usa, le
    #        cambio los kana por letras latinas. Medido: usa 38 de los 64.
    # Por eso solo se tocan los codigos LIBRES, y solo los 14 que hacen
    # falta para las mayusculas de nuestros nombres.
    for ch, k in MAY.items():
        tabla[k - 0xA0] = GLIFO_MAY + (ord(ch) - ord('A'))
    rom[TAB_F1:TAB_F1 + 0x40] = tabla

    # ---- 2. las cadenas ----
    # ARMAS y ARMADURAS
    # -----------------
    # Mapa original:
    #   0x43CA8..0x43CB6  tabla ARMAS      (7 punteros)
    #   0x43CB6..0x43CEF  cadenas de armas      57 B
    #   0x43CEF..0x43CF7  tabla ARMADURAS  (4 punteros)  <- EN MEDIO
    #   0x43CF7..0x43D17  cadenas de armaduras  32 B
    #
    # La tabla de armaduras parte el espacio en dos y por eso los nombres de
    # David no cabian. Solo la lee UN sitio, $D4F6 (LDA $BCEF,X), verificado
    # buscando la pareja de bytes EF BC en toda la ROM y descartando las
    # coincidencias que caen en graficos.
    #
    # Se mueve a 0x43FEF (17 B de $FF libres al final del banco) y el bloque
    # 0x43CB6..0x43D17 queda entero: 97 B para 92.
    TABLA_ARM_NUEVA = 0x43FEF
    assert all(b == 0xFF for b in rom[TABLA_ARM_NUEVA:TABLA_ARM_NUEVA + 8]), \
        'el destino de la tabla de armaduras no esta libre'
    log_tabla = TABLA_ARM_NUEVA - BK
    assert rom[0x1B4F6] == 0xBD and rom[0x1B4F7] == 0xEF and rom[0x1B4F8] == 0xBC, \
        '$D4F6 no es LDA $BCEF,X'
    assert rom[0x1B4FB] == 0xBD and rom[0x1B4FC] == 0xF0 and rom[0x1B4FD] == 0xBC, \
        '$D4FB no es LDA $BCF0,X'
    rom[0x1B4F7] = log_tabla & 0xFF
    rom[0x1B4F8] = log_tabla >> 8
    rom[0x1B4FC] = (log_tabla + 1) & 0xFF
    rom[0x1B4FD] = (log_tabla + 1) >> 8

    base, tope = 0x43CB6, 0x43D18
    # Las cadenas se DEDUPLICAN: 'Valor' es a la vez arma y armadura, y como
    # cada entrada es un puntero, las dos pueden apuntar a la misma cadena.
    # Ahorra 8 B, que es justo lo que hacia falta para que la reserva admita
    # un nombre de 8 B en cada grupo.
    datos = bytearray()
    offs = []
    vistos = {}
    for t in ARMAS + ARMADURAS:
        if t in vistos:
            offs.append(vistos[t])
            continue
        vistos[t] = len(datos)
        offs.append(len(datos))
        datos += codifica(t)
    assert len(datos) <= tope - base, \
        'armas+armaduras: %d B y solo hay %d' % (len(datos), tope - base)
    rom[base:tope] = bytes(datos) + b'\x00' * (tope - base - len(datos))
    for i in range(7):
        rom[0x43CA8 + i * 2:0x43CA8 + i * 2 + 2] = struct.pack('<H', base + offs[i] - BK)
    for i in range(4):
        rom[TABLA_ARM_NUEVA + i * 2:TABLA_ARM_NUEVA + i * 2 + 2] = \
            struct.pack('<H', base + offs[7 + i] - BK)
    print('armas+armaduras: %d B de %d' % (len(datos), tope - base))
    print('tabla armaduras movida a 0x%05X (logico $%04X)' % (TABLA_ARM_NUEVA, log_tabla))

    # OBJETOS y ARTES: cada nombre esta suelto; se reescribe EN SU SITIO
    # (cada uno tiene su propio hueco, verificado abajo)
    def sustituye(tabla_off, textos, tipo, pool):
        """Reescribe los nombres.  Cada uno tiene su propio puntero, asi que
        los que no caben en su hueco se realojan y se repunta el registro.

        Los huecos NO son ampliables: entre las cadenas hay codigo
        ejecutable (JSR/JMP/RTS) y datos de los registros. Medido."""
        sitios = []
        for i, t in enumerate(textos):
            p_ = struct.unpack('<H', rom[tabla_off + (i + 1) * 2:
                                         tabla_off + (i + 1) * 2 + 2])[0]
            reg = BK + p_
            q = struct.unpack('<H', rom[reg:reg + 2])[0]
            a = BK + q
            n = 0
            while rom[a + n] != 0:
                n += 1
            sitios.append((reg, a, n + 1))

        # Asignacion GLOBAL: los nombres no tienen por que quedarse en su
        # hueco original, cada uno lleva su propio puntero. Se ordenan los
        # huecos y los textos por tamano y se emparejan de mayor a menor,
        # que es lo que permite que 'Vuelo' (8 B) se lleve el hueco de 11.
        pares = sorted(zip(textos, [codifica(t) for t in textos]),
                       key=lambda x: -len(x[1]))
        huecos = sorted([(h, a) for (_, a, h) in sitios], reverse=True)
        libre_extra = list(pool)
        asign = {}
        for t, nuevo_b in pares:
            colocado = False
            # best-fit: el hueco mas ajustado, y el sobrante vuelve a la lista
            cand = [(h, k) for k, (h, a) in enumerate(huecos) if h >= len(nuevo_b)]
            if cand:
                _, k = min(cand)
                h, a = huecos.pop(k)
                asign[t] = a
                sobra = h - len(nuevo_b)
                if sobra >= 6:
                    huecos.append((sobra, a + len(nuevo_b)))
                    huecos.sort(reverse=True)
                colocado = True
            if not colocado:
                for k, (i_, f) in enumerate(libre_extra):
                    if i_ + len(nuevo_b) <= f:
                        asign[t] = i_
                        libre_extra[k] = (i_ + len(nuevo_b), f)
                        colocado = True
                        break
            if not colocado:
                raise SystemExit('%r: sin sitio para %d B' % (t, len(nuevo_b)))

        # limpiar todos los huecos originales y escribir en el destino
        for (_, a, h) in sitios:
            rom[a:a + h] = b'\x00' * h
        for i, t in enumerate(textos):
            nuevo_b = codifica(t)
            d = asign[t]
            rom[d:d + len(nuevo_b)] = nuevo_b
            reg = sitios[i][0]
            rom[reg:reg + 2] = struct.pack('<H', d - BK)
            if d != sitios[i][1]:
                print('   %-9s movido a 0x%05X (%d B)' % (t, d, len(nuevo_b)))
        pool[:] = libre_extra


    # La reserva grande es lo que sobra tras las cadenas de armas y
    # armaduras, hasta el final de su zona (0x43D18).
    POOLS[0] = (0x43CB6 + len(datos), 0x43D18)
    for a_, b_ in POOLS:
        assert all(x in (0x00, 0xFF) for x in rom[a_:b_]), \
            'la reserva 0x%05X no esta libre' % a_
    POOL_LIBRE = list(POOLS)
    # Reparto de reservas, medido:
    #   OBJETOS: sus huecos suman 118 y necesitan 104, pero hay TRES nombres
    #     de 8 B y solo DOS huecos que los admitan -> uno va a la reserva.
    #   ARTES:   sus huecos suman 59 y necesitan 55, con el mismo problema.
    # Se les da una reserva a cada uno.
    sustituye(0x42F4C, OBJETOS, 'objeto', POOL_LIBRE[:1])
    sustituye(BK + 0xB3A5, ARTES, 'arte', POOL_LIBRE[1:])


    open(SALIDA, 'wb').write(bytes(rom))
    print('escrito', SALIDA)
    print('MD5  ', hashlib.md5(rom).hexdigest())
    print('SHA1 ', hashlib.sha1(rom).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
    print()
    print('fuente 1 -> MAYUSCULAS finas (26 entradas)')
    print('objetos: %d   artes: %d' % (len(OBJETOS), len(ARTES)))


if __name__ == '__main__':
    main()
