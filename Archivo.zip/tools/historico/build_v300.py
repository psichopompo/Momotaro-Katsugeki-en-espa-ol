#!/usr/bin/env python3
"""v300 = v299 + la 'p' del password subida 1 px.

v299 = v296 + los dos unicos cambios que David valido en pantalla:
  0x3DBE8 $00 -> $18   contador del CG del bocadillo de tienda
  0x04100              el simbolo (c) de la pantalla de titulo

Aqui se anade el ajuste que pidio David:
  «al fin me ha salido la 'p' minuscula en un password, pero hay que
   subirla 1 px, porque esta mas abajo que el resto de letras.»

La 'p' del password NO sale de la tabla de fuente f0/f1: la parrilla
(0x1BBBA) y la tabla del Jizo (0x16AD6) llevan indices de glifo DIRECTOS,
y en la posicion 37 la del Jizo apunta al glifo 176 (ROM 0x3DBE0).

Medido:
    glifo 175 ('o')  cuerpo en filas 2..6
    glifo 176 ('p')  cuerpo en filas 2..5 + descendente en 6..7
Subir 1 px = desplazar el dibujo una fila hacia arriba:
    00 00 F0 88 88 F0 80 80  ->  00 F0 88 88 F0 80 80 00
"""
import hashlib, zlib, sys

SRC = 'roms/momotaro_es_v299.pce'
JP  = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v300.pce'

BASE = 0x3D660
P    = BASE + 176 * 8      # 0x3DBE0

rom  = bytearray(open(SRC, 'rb').read())
jp   = open(JP, 'rb').read()
orig = bytes(rom)

assert len(rom) == 512 * 1024
assert hashlib.md5(orig).hexdigest() == '8c01552682a40be9ece2d04e738cee86', 'la v299 no es la esperada'
assert P == 0x3DBE0

ANTES  = bytes([0x00, 0x00, 0xF0, 0x88, 0x88, 0xF0, 0x80, 0x80])
DESPUES = bytes([0x00, 0xF0, 0x88, 0x88, 0xF0, 0x80, 0x80, 0x00])
assert rom[P:P + 8] == ANTES, 'la p no es la esperada: %s' % rom[P:P + 8].hex()

rom[P:P + 8] = DESPUES

# el byte siguiente es el CONTADOR del CG de tienda: NO se puede tocar
assert rom[0x3DBE8] == 0x18, 'el contador se ha movido'

# nada mas cambia
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and not (P <= i < P + 8)]
assert not fuera, 'cambios fuera de la p: %s' % [hex(x) for x in fuera][:10]

# las tablas siguen apuntando al glifo 176 (no se ha movido de sitio)
assert rom[0x16AD6 + 37] == 176, "la tabla del Jizo ya no apunta al glifo 176"
assert rom[0x41CF3:0x41D33] == orig[0x41CF3:0x41D33], 'tabla f0 tocada'
assert rom[0x41CB3:0x41CF3] == orig[0x41CB3:0x41CF3], 'tabla f1 tocada'

open(DST, 'wb').write(rom)

# --- relectura como hace el motor -----------------------------------------
v = open(DST, 'rb').read()
g = v[0x16AD6 + 37]
o = BASE + g * 8
filas = [r for r in range(8) if v[o + r]]
print('glifo %d (la p del password) ROM %#07x  filas con tinta: %s' % (g, o, filas))
assert filas == [1, 2, 3, 4, 5, 6], 'la p no ha subido bien'
o175 = BASE + 175 * 8
print('glifo 175 (la o)                            filas con tinta: %s'
      % [r for r in range(8) if v[o175 + r]])

sys.path.insert(0, 'tools')
from descomp_cg2 import bloque, F
n = v[0x3DBE8]
f = F(v, 0x3DBE9)
[bloque(f) for _ in range(n)]
assert n == 24 and 0x0EC + n - 1 < 0x1B0
print('CG tienda: %d celdas, $0EC..$%03X  (HUD a salvo)' % (n, 0x0EC + n - 1))

b = bytes(v)
print(DST)
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xffffffff))
