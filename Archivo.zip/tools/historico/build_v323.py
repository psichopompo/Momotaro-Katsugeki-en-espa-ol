#!/usr/bin/env python3
"""build_v323.py - El ermitanyo, BIEN esta vez. Y arregla lo que rompi en v322.

EL BUG QUE SIGUE VIENDO DAVID
-----------------------------
La v322 muestra «. / Vuelo» en vez de «Soy Vuelo.».

LA ESTRUCTURA, POR FIN MEDIDA BIEN
----------------------------------
    0x4AE0A .. 0x4AE2C   «kuregure mo muri wa kinmotsu ja! ujuju!» + $00
                         = «¡sobre todo, nada de excesos! ¡ujuju!»
                         Es OTRO mensaje, no el del ermitanyo.
    0x4AE2D .. 0x4AE31   «washi wa » + $00   <- EL mensaje del ermitanyo
    0x4AE32 .. 0x4AE3A   «sennin ja!» + $80

    frase = «washi wa » + <<TECNICA>> + «sennin ja!»
          = «yo soy el ermitanyo <<TECNICA>>»

**El `$00` de `0x4AE2C` es el terminador del bloque anterior; el de
`0x4AE31` SI es el marcador de sustitucion.** En la v322 confundi los dos:
escribi mi texto en el bloque equivocado y machaque «washi wa » con un
punto suelto. De ahi el «. / Vuelo».

Tercera vez que me equivoco de offset en esta misma zona. La prueba que lo
resolvio estaba en la captura de David desde el principio: la ROM japonesa
muestra «washi wa HIEN sennin ja!» en UNA linea, o sea que el mensaje es
corto y no puede empezar en 0x4AE0A.

EL REPARTO
----------
    0x4AE2D  5 B  «Soy » + $00      (4 letras + marcador)
    0x4AE32  8 B  «.» + relleno     (cierra tras el nombre insertado)
    0x4AE0A 34 B  el otro mensaje, con el texto de la v322 que SI vale
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode, RELLENO   # noqa: E402

BASE = 'roms/momotaro_es_v322.pce'
SALIDA = 'roms/momotaro_es_v323.pce'
MD5_BASE = 'a286de61353582b79b2a206063528ecd'

BLOQUE = 0x4AE0A          # 39 B de texto
MARCADOR = 0x4AE31        # $00: aqui se inserta el nombre de la tecnica
CIERRE = 0x4AE32          # 8 B tras el nombre
FIN = 0x4AE3A             # $80

COLS = 16
# 39 B = 2 lineas de 16 + 7 de cola. El texto acaba en «Soy » para que el
# nombre de la tecnica se pegue detras.
L1 = '¡Sin excesos!'
L2 = '¡Jujú! Soy '        # acaba en espacio: el nombre va justo detras
CIERRE_TXT = '.'          # cierra la frase tras el nombre

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x1E000, 0x20000, 'banco $0F: escenas y rotulos'),
    (0x42000, 0x44000, 'banco $21: menu RUN'),
    (0x48000, 0x4A000, 'banco $24: tiendas, guion, vitores'),
    (0x4AC80, 0x4AE0A, 'dados y lo anterior'),
    (0x4AE3B, 0x4AEE6, 'ermitanyo quiz/ppt y tecnicas'),
    (0x4AEE6, 0x4BA13, 'el QUIZ'),
    (0x4BA15, 0x4C000, 'diccionario y dialogos'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v322'

    # ---- la geometria japonesa que hay que respetar ---------------------
    assert jp[MARCADOR] == 0x00, 'no hay marcador en %06X' % MARCADOR
    assert jp[FIN] == 0x80, 'no hay $80 en %06X' % FIN
    # en la v322 el marcador se movio a 0x4AE2C: ese es el bug
    assert rom[0x4AE2C] == 0x00, 'la v322 no tiene el $00 en 0x4AE2C'
    assert rom[MARCADOR] != 0x00, 'el marcador ya esta en su sitio'

    hueco1 = MARCADOR - BLOQUE      # 39
    hueco2 = FIN - CIERRE           # 8
    assert hueco1 == 39 and hueco2 == 8, '%d / %d' % (hueco1, hueco2)

    # ---- escribir ---------------------------------------------------------
    assert len(L1) <= COLS and len(L2) <= COLS
    d = (encode(L1) + bytes([RELLENO]) * (COLS - len(L1)) +
         encode(L2))
    assert len(d) <= hueco1, 'el texto ocupa %d y hay %d' % (len(d), hueco1)
    d += bytes([RELLENO]) * (hueco1 - len(d))
    rom[BLOQUE:MARCADOR] = d
    rom[MARCADOR] = 0x00

    dc = encode(CIERRE_TXT)
    assert len(dc) <= hueco2
    rom[CIERRE:FIN] = dc + bytes([RELLENO]) * (hueco2 - len(dc))
    rom[FIN] = 0x80

    # ---- VERIFICACION -----------------------------------------------------
    rv = {}
    from charset_vitores import CHAR_TO_CODE
    for k, v in CHAR_TO_CODE.items():
        rv.setdefault(v, k)
    assert rom[MARCADOR] == 0x00, 'se perdio el marcador'
    assert rom[FIN] == 0x80, 'se perdio el $80'
    # no debe quedar ningun otro $00 dentro del bloque
    extras = [i for i in range(BLOQUE, MARCADOR) if rom[i] == 0x00]
    assert not extras, 'hay $00 de mas en %s' % [hex(x) for x in extras]
    # el texto acaba en «Soy » para que el nombre se pegue
    cola = ''.join(rv.get(b, '') for b in rom[BLOQUE + COLS:MARCADOR]
                   if b != RELLENO)
    assert cola.strip().endswith('Soy'), \
        'el texto no acaba en «Soy»: «%s»' % cola
    leido2 = ''.join(rv.get(b, '') for b in rom[CIERRE:FIN] if b != RELLENO).strip()
    assert leido2 == '.', 'el cierre es «%s»' % leido2
    # cero japones
    quedan = [i for i in range(BLOQUE, FIN)
              if rom[i] == jp[i] and jp[i] not in (0x20, 0xA0, 0x00, 0x80)]
    assert not quedan, 'queda japones en %s' % [hex(x) for x in quedan]

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = [i for i in range(len(rom)) if rom[i] != original[i]]
    assert all(BLOQUE <= i <= FIN for i in dif), 'bytes fuera de la zona'

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % len(dif))
    print()
    print('  %06X  |%-16s|' % (BLOQUE, L1))
    print('          |%-16s|<<TECNICA>>' % L2)
    print('  %06X  «%s»' % (CIERRE, CIERRE_TXT))
    print()
    print('  en pantalla:  «¡Sin excesos! / ¡Jujú! Soy Vuelo.»')


if __name__ == '__main__':
    main()
