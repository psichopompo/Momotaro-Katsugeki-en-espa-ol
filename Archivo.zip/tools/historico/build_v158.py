#!/usr/bin/env python3
"""
build_v158.py - bocadillo APAISADO de 20x4 caracteres.

QUE HACE
--------
La v157 dejo el texto en horizontal pero con la geometria japonesa: 6x6
celdas repartidas en 3 grupos de tiles no contiguos. Esta version lo lleva a
**20 caracteres x 4 lineas**, que es el formato que David eligio tras ver
los mockups.

EL PROBLEMA QUE RESUELVE
------------------------
El motor guardaba el texto en un buffer de RAM de 36 celdas ($3667..$368A) y
lo volcaba de golpe con $9B7C. Para 80 celdas hacia falta ampliarlo, y
**no hay 80 bytes libres en los 8 KB de RAM** (comprobado cruzando el indice
de referencias con los 7 states; ademas el breakpoint de David tumbo el
candidato $36F1, que lo escribe una tienda).

La salida no es buscar mas RAM: es **quitar el buffer**. Medido:

  - $9D33 escribe UNA celda en VRAM usando solo $3661/$3662 (origen del
    glifo), $3663/$3664 (destino) y $3665 (cuadrante). NO toca el buffer.
  - $9D33 llama a $E185 al entrar, que espera al VDC (LDA $0000 / AND #$40 /
    BNE). O sea que el motor YA sincroniza celda a celda, no en rafaga:
    escribir en el momento no cambia el patron de acceso a VRAM.

Y las dos tablas ($9BBD destino, $9C05 cuadrante) son redundantes. Validado
contra las 36 entradas reales de la v157 en tools/geom_v158.py:

    cuadrante = (fila & 1) * 2 + (col & 1)
    destino   = colbase[col // 2] + (fila // 2) * $80

240 B de tablas -> 20 B. Con eso el presupuesto del banco $20 cuadra.

ESTADO
------
Este constructor deja aplicados los CAMBIOS DE DATOS que estan medidos y
verificados byte a byte (los tres contadores y la tabla de columnas). La
rutina de escritura inmediata NO se inyecta todavia: exige reescribir $9883
y $9863, y eso se prueba en pantalla antes de darlo por bueno.

Uso:  python3 tools/build_v158.py
"""
import hashlib
import zlib
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from geom_v158 import columnas, verificar_contra_v157, ANCHO, LINEAS
from rutina_v158 import ensamblar

BASE = 'roms/test_horizontal_v157.pce'
SALIDA = 'roms/test_apaisado_v158.pce'
MD5_BASE = '294f0c20ef190860391267c330007dad'

# --- sitios a parchear, con el byte que TIENE que haber ahora -------------
PARCHES = [
    # (offset, esperado, nuevo, descripcion)
    (0x4187D, b'\xC9\x06', b'\xC9' + bytes([ANCHO]),
     'CMP #$06 -> CMP #%d : caracteres por linea' % ANCHO),
    (0x418AF, b'\xC9\x03', b'\xC9' + bytes([LINEAS]),
     'CMP #$03 -> CMP #%d : lineas por pagina' % LINEAS),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v157 (md5 %s)' % md5
    assert len(rom) == 512 * 1024, 'tamano de ROM inesperado'

    # la formula tiene que seguir reproduciendo la tabla real
    base157 = verificar_contra_v157()
    print('formula validada contra la v157: colbase = %s'
          % [hex(x) for x in base157])

    # --- 1. los contadores de geometria ---------------------------------
    for off, esperado, nuevo, desc in PARCHES:
        real = bytes(rom[off:off + len(esperado)])
        assert real == esperado, \
            'ROM %05X: esperaba %s y hay %s' % (off, esperado.hex(), real.hex())
        rom[off:off + len(nuevo)] = nuevo
        print('  %05X  %s' % (off, desc))

    # --- 2. el indice de celda: col*12+pos+6  ->  fila*20+pos ---------
    # cabe en los mismos 18 B ($9863..$9874)
    idx = bytes([
        0xAD, 0x57, 0x36,   # LDA $3657   fila
        0x0A, 0x0A,         # ASL ASL     *4
        0x85, 0x13,         # STA $13
        0x0A, 0x0A,         # ASL ASL     *16
        0x18, 0x65, 0x13,   # CLC ADC $13 *20
        0x18, 0x6D, 0x58, 0x36,  # CLC ADC $3658
        0xAA,               # TAX
        0xEA,               # NOP (relleno)
    ])
    assert len(idx) == 18, 'el indice ocupa %d B, el hueco son 18' % len(idx)
    orig_idx = bytes(rom[0x41863:0x41875])
    assert orig_idx.hex() == 'ad57360a186d57360a0a186d5836186906aa', \
        'el calculo del indice no es el esperado: %s' % orig_idx.hex()
    rom[0x41863:0x41875] = idx
    print('  41863  indice de celda -> fila*20 + posicion (18 B)')

    # --- 3. la rutina de escritura inmediata --------------------------
    RUT, TAB = 0x9B7C, 0x9B7C + 97
    rutina = ensamblar(tabla=TAB)
    assert len(rutina) == 97, 'la rutina mide %d B' % len(rutina)
    off = 0x40000 + (RUT - 0x8000)
    # el area libre va de $9B7C a $9C29 (bucle de volcado + las dos tablas)
    assert off + len(rutina) + 20 <= 0x40000 + (0x9C29 - 0x8000), 'no cabe'
    rom[off:off + len(rutina)] = rutina
    print('  %05X  rutina de escritura inmediata (%d B) en $%04X'
          % (off, len(rutina), RUT))

    # --- 4. la tabla de columnas, detras de la rutina -----------------
    cols = columnas()
    tabla = bytearray()
    for celda, _ in cols:
        w = celda * 64
        tabla += bytes([w & 0xFF, w >> 8])
    assert len(tabla) == 20, 'tabla de %d B' % len(tabla)
    offt = 0x40000 + (TAB - 0x8000)
    rom[offt:offt + len(tabla)] = tabla
    print('  %05X  tabla de %d columnas (%d B) en $%04X'
          % (offt, len(cols), len(tabla), TAB))
    for i, (a, b) in enumerate(cols):
        print('           col %2d: celdas %03X/%03X -> word $%04X' % (i, a, b, a * 64))

    # --- 5. los dos STA $3667,X pasan a JSR a la rutina ---------------
    for o in (0x41883, 0x41892):
        real = bytes(rom[o:o + 3])
        assert real == b'\x9d\x67\x36', \
            'ROM %05X: esperaba STA $3667,X y hay %s' % (o, real.hex())
        rom[o:o + 3] = bytes([0x20, RUT & 0xFF, RUT >> 8])
        print('  %05X  STA $3667,X -> JSR $%04X' % (o, RUT))

    # --- 3. zonas que NO se pueden haber tocado -------------------------
    intacto = {
        'fuente de dialogo': (0x3D660, 0x3E200),
        'guion': (0x48F91, 0x4A4B9),
        'tabla de punteros': (0x48000, 0x480E8),
    }
    orig = open(BASE, 'rb').read()
    for nom, (a, b) in intacto.items():
        assert rom[a:b] == orig[a:b], 'se ha tocado la zona: %s' % nom
    print('zonas intactas verificadas: %s' % ', '.join(intacto))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    print()
    print('%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA1   %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    dif = sum(1 for i in range(len(d)) if d[i] != orig[i])
    print('  bytes modificados respecto a la v157: %d' % dif)
    print()
    print('Todo aplicado: contadores, indice, rutina inmediata y tabla.')
    print('Las 80 celdas estan simuladas una a una contra la geometria.')
    print('FALTA la prueba en pantalla: es lo unico que no se puede medir aqui.')


if __name__ == '__main__':
    main()
