#!/usr/bin/env python3
"""
build_v179.py - PASO 3 sobre la v178: AMPLIAR EL CG del bocadillo.

Este paso NO cambia la geometria del texto. Solo carga 13 celdas de relleno
blanco de mas, en `0x170-0x17C`, y deja el bocadillo EXACTAMENTE igual que
en la v178. Es un paso verificable por si solo:

    si el bocadillo se sigue viendo bien -> el cargador nuevo no rompe nada
    y en el Tile Viewer aparecen 13 celdas blancas en 0x170

POR QUE 0x170 (medido, entrada 121 del diario)
----------------------------------------------
Cruzando **25 volcados de VRAM** con el criterio correcto (celda ocupada =
referenciada por el SATB con su tamano real, o por una entrada de la BAT),
quedan 62 celdas de sprite que no referencia NADIE. El tramo contiguo mas
grande es `0x170-0x17F` (16 celdas).

Ojo con `0x15F-0x16F`: parecia libre por tener "datos sin usar", pero la
escena de los PADRES dibuja ahi dos sprites de 32x64 (`cel=160` y `cel=168`,
`at=$3180`) **con el bocadillo abierto**. Por eso el tramo empieza en 0x170.

EL CARGADOR ($9C32, ROM 0x41C32)
--------------------------------
```
9C32  JSR $9C5F              interruptor de tamano
9C35  LDA #$1E / ADC $20 / TAM #$04      banco 0x1E en MPR2
9C3C  LDA #$01 / STA $14     puntero al stream = $5401 (ROM 0x3D401)
9C40  LDA #$54 / STA $15
9C44  LDA #$00 / STA $3126   destino = word $6700 (celda 0x19C)
9C49  LDA #$67 / STA $3127
9C4E  LDX $5400              cuenta = 20
9C51  PHX / JSR $861F / PLX / DEX / BNE $9C51
9C59  JSR $9C29              limpia el buffer de texto
9C5C  JMP $9B7C              vuelca el texto
```

`$861F` (ROM `0x4061F`) descomprime **una celda de 16x16** por llamada
(cuatro planos: `LDX #$04` y cuatro `JSR $867F`) y **autoincrementa**
`$3126/$3127` en `$40` = 64 words = una celda. Verificado desensamblando.

Asi que ampliar es trivial: un segundo bucle con otro destino y otra cuenta.
No hay que tocar `$861F` ni el formato del stream.

QUE HACE ESTE PARCHE
--------------------
1. **Stream nuevo** en el hueco `ROM 0x3D214` (492 B de relleno `$FF`,
   identicos en la ROM virgen, sin ningun puntero que los alcance):
   13 celdas de relleno blanco puro comprimidas = 13 x 28 = 364 B.

2. **Cargador nuevo** en la zona muerta `$9AAE..$9ADC` (47 B): son los
   restos de la lista de sprites vieja, que la v177 dejo huerfana al mover
   la lista al banco $23. Nadie los lee (comprobado: ninguna referencia a
   `$9AAE`-`$9ADC` en toda la ROM).

3. `$9C32` termina con `JMP $9B7C`; se cambia por `JMP` al cargador nuevo,
   que hace su trabajo y luego salta a `$9B7C`. Asi no se toca el orden de
   `$9C29`/`$9B7C` (norma 104: se parchea el llamante, no la rutina).

El relleno blanco = planos 0,1,2 a $FFFF y plano 3 a 0 (color 7), que es
exactamente lo que tienen las celdas `1A6-1AB` (norma 109).

Uso:  python3 tools/build_v179.py
"""
import hashlib
import zlib
import struct
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v178.pce'
SALIDA = 'roms/momotaro_es_v179.pce'
IPS = 'parches/momotaro_v179.ips'
MD5_BASE = '9bc41d60e3149cbe52e93bdd21fe3fcd'

CG_CUENTA = 0x3D400          # numero de celdas del stream original (20)
CG_STREAM = 0x3D401
HUECO = 0x3D214              # 492 B de $FF
HUECO_FIN = 0x3D400

CELDA_NUEVA = 0x170          # primera celda del relleno nuevo
N_NUEVAS = 13                # 19x4 = 76 glifos /4 = 19 celdas ; hoy 6 -> +13

CARGADOR = 0x41AAE           # zona muerta de la lista vieja
CARGADOR_FIN = 0x41ADD       # empieza la tabla del rabillo $9ADD


def celda_blanca():
    """Relleno blanco puro: planos 0-2 a uno, plano 3 a cero = color 7."""
    return struct.pack('<64H', *([0xFFFF] * 48 + [0] * 16))


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v178 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # 1. Comprobar el stream original y de donde a donde llega
    # ------------------------------------------------------------------
    n_orig = rom[CG_CUENTA]
    assert n_orig == 20, 'la cuenta del CG no es 20 sino %d' % n_orig
    f = Flujo(rom, CG_STREAM)
    celdas = [b''.join(tile(f) for _ in range(4)) for _ in range(n_orig)]
    fin = f.p
    print('stream original: %d celdas, 0x%05X..0x%05X (%d B)'
          % (n_orig, CG_STREAM, fin - 1, fin - CG_STREAM))
    assert fin == 0x3D660, 'el stream no acaba donde esperaba: 0x%05X' % fin

    # las 6 celdas de relleno actuales son blancas puras
    blanca = celda_blanca()
    rell = [0x19C + k for k, c in enumerate(celdas) if c == blanca]
    assert rell == list(range(0x1A6, 0x1AC)), \
        'el relleno actual no es 1A6-1AB sino %s' % [hex(c) for c in rell]
    print('relleno actual: %s (%d celdas)'
          % (' '.join('%03X' % c for c in rell), len(rell)))

    # ------------------------------------------------------------------
    # 2. El hueco donde va el stream nuevo
    # ------------------------------------------------------------------
    assert set(rom[HUECO:HUECO_FIN]) == {0xFF}, 'el hueco 0x3D214 no esta libre'
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    assert rom[HUECO:HUECO_FIN] == jp[HUECO:HUECO_FIN], \
        'el hueco difiere de la ROM virgen'
    print('hueco libre: 0x%05X..0x%05X = %d B (identico en la virgen)'
          % (HUECO, HUECO_FIN - 1, HUECO_FIN - HUECO))

    # ------------------------------------------------------------------
    # 3. Construir el stream nuevo: N_NUEVAS celdas blancas
    # ------------------------------------------------------------------
    nuevo = b''.join(comprime(blanca) for _ in range(N_NUEVAS))
    print('stream nuevo: %d celdas blancas = %d B (%d B/celda)'
          % (N_NUEVAS, len(nuevo), len(nuevo) // N_NUEVAS))
    assert HUECO + len(nuevo) <= HUECO_FIN, \
        'el stream nuevo (%d B) no cabe en el hueco (%d B)' % (
            len(nuevo), HUECO_FIN - HUECO)

    # round-trip: se descomprime a lo que queriamos
    f2 = Flujo(bytes(nuevo), 0)
    for k in range(N_NUEVAS):
        c = b''.join(tile(f2) for _ in range(4))
        assert c == blanca, 'la celda %d del stream nuevo no es blanca' % k
    assert f2.p == len(nuevo), 'sobran bytes en el stream nuevo'
    print('  round-trip del stream nuevo: OK')

    rom[HUECO:HUECO + len(nuevo)] = nuevo

    # ------------------------------------------------------------------
    # 4. El cargador nuevo, en la zona muerta $9AAE
    # ------------------------------------------------------------------
    # Nadie referencia $9AAE..$9ADC (restos de la lista de sprites vieja).
    esperado = bytes.fromhex(
        '180a0f010308080f000028040f100008120f002038100f0020f8020f'
        '010038000f0100f8140f0103281c0f001418ff')
    assert bytes(rom[CARGADOR:CARGADOR_FIN]) == esperado, \
        'la zona muerta no tiene los restos esperados'
    for a in range(0x9AAE, 0x9ADD):
        p = bytes([a & 0xFF, a >> 8])
        hits = [i for i in range(len(orig) - 1)
                if orig[i:i + 2] == p and orig[max(0, i - 1)] in
                (0x20, 0x4C, 0xAD, 0x8D, 0xBD, 0x9D, 0xB9, 0x99)]
        assert not hits, '$%04X esta referenciado en %s' % (
            a, ['%05X' % h for h in hits[:3]])
    print('zona muerta $9AAE..$9ADC (%d B): sin referencias, reutilizable'
          % (CARGADOR_FIN - CARGADOR))

    w = CELDA_NUEVA * 64
    ptr = 0x4000 + (HUECO - 0x3C000)      # el hueco visto desde MPR2
    assert ptr == 0x5214, 'el puntero al hueco no es $5214 sino $%04X' % ptr

    cargador = bytes([
        0xA9, ptr & 0xFF, 0x85, 0x14,        # LDA #$14 / STA $14
        0xA9, ptr >> 8, 0x85, 0x15,          # LDA #$52 / STA $15
        0xA9, w & 0xFF, 0x8D, 0x26, 0x31,    # LDA #$00 / STA $3126
        0xA9, w >> 8, 0x8D, 0x27, 0x31,      # LDA #$5C / STA $3127
        0xA2, N_NUEVAS,                      # LDX #13
        0xDA,                                # PHX          <- bucle
        0x20, 0x1F, 0x86,                    # JSR $861F
        0xFA,                                # PLX
        0xCA,                                # DEX
        0xD0, 0xF8,                          # BNE bucle
        0x4C, 0x7C, 0x9B,                    # JMP $9B7C
    ])
    assert len(cargador) <= CARGADOR_FIN - CARGADOR, \
        'el cargador (%d B) no cabe en la zona muerta' % len(cargador)
    rom[CARGADOR:CARGADOR + len(cargador)] = cargador
    print('cargador nuevo en $9AAE (%d B): destino word $%04X (celda %03X), '
          '%d celdas' % (len(cargador), w, CELDA_NUEVA, N_NUEVAS))

    # comprobar el desplazamiento del BNE
    bucle = CARGADOR + 20            # offset del PHX dentro del cargador
    destino = CARGADOR + 26 + 2 + (0xF8 - 256)
    assert destino == bucle, \
        'el BNE no vuelve al PHX: destino 0x%05X, bucle 0x%05X' % (
            destino, bucle)
    print('  BNE verificado: vuelve a $%04X (el PHX)'
          % (0x8000 + bucle - 0x40000))

    # ------------------------------------------------------------------
    # 5. Enganchar: $9C5C  JMP $9B7C  ->  JMP $9AAE
    # ------------------------------------------------------------------
    o = 0x41C5C
    assert bytes(rom[o:o + 3]) == bytes([0x4C, 0x7C, 0x9B]), \
        'en $9C5C no hay JMP $9B7C sino %s' % bytes(rom[o:o + 3]).hex()
    rom[o + 1] = 0xAE
    rom[o + 2] = 0x9A
    print('  0x%05X  $9C5C: JMP $9B7C -> JMP $9AAE (y el cargador salta a '
          '$9B7C al acabar)' % o)

    # ------------------------------------------------------------------
    # 6. Zonas que NO se pueden tocar
    # ------------------------------------------------------------------
    intactas = [
        ('fuente', 0x3D660, 0x3E200),
        ('stream CG original', CG_STREAM, 0x3D660),
        ('cuenta CG', CG_CUENTA, CG_CUENTA + 1),
        ('tabla rabillo $9ADD', 0x41ADD, 0x41AFD),
        ('lista sprites banco $23', 0x47C02, 0x47C67),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('flecha $99C6', 0x419E2, 0x419F3),
        ('punteros guion', 0x48000, 0x480E8),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nzonas intactas verificadas: %s'
          % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    permitido = set(range(HUECO, HUECO + len(nuevo))) \
        | set(range(CARGADOR, CARGADOR + len(cargador))) | {o + 1, o + 2}
    fuera = [i for i in dif if i not in permitido]
    assert not fuera, 'cambios fuera de lo previsto: %s' % [
        hex(i) for i in fuera[:8]]
    print('%d bytes modificados, todos previstos' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    # IPS
    rec = []
    for a, b in ((HUECO, HUECO + len(nuevo)),
                 (CARGADOR, CARGADOR + len(cargador)),
                 (o + 1, o + 3)):
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')

    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        off = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n = raw[p + 3] << 8 | raw[p + 4]
        prueba[off:off + n] = raw[p + 5:p + 5 + n]
        p += 5 + n
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER EN EL EMULADOR')
    print('  1. El bocadillo se ve EXACTAMENTE igual que en la v178.')
    print('  2. En el Tile Viewer (Sprites), las celdas 0x170-0x17C estan')
    print('     BLANCAS al abrir un bocadillo.')
    print('  3. En el Memory Viewer, VRAM byte $B800 (word $5C00) a $FF.')


if __name__ == '__main__':
    main()
