#!/usr/bin/env python3
"""
build_v272.py - Artes / No puedo / ¡Puaj!

POR QUE
=======
David probo la v271 y midio el limite en pantalla:

```
'No se come'  (10 chars) -> se ve 'No se co'   corta en 8
'No se puede' (11 chars) -> se ve 'No se pu'   corta en 8
'Objetos'      (7 chars) -> completo
'Poderes'      (7 chars) -> completo
```

Desensamblado el bucle que las dibuja (`$D619`, banco $0C): **no tiene
contador de corte**, escribe hasta el `$00`. `$C3` es el cursor de celda y
solo se incrementa. El limite NO esta en el codigo: es el ancho fisico del
bocadillo, **8 celdas**. Lo que sobra se pinta fuera del marco.

LOS TRES CAMBIOS
================
```
Poderes      -> Artes      5 chars   (coherencia con el menu SELECT, que ya
                                      pone «ARTES»: lo vio David en su captura)
No se puede  -> No puedo   8 chars   (justo en el limite)
No se come   -> ¡Puaj!     6 chars   (interjeccion, con apertura y cierre)
```

David sobre "Inutil": *«sigue sonandome mal»*. Y sobre el punto final:
*«en el caso de una expresion, si que creo que deberia llevarlo (o
exclamacion)»*. «¡Puaj!» cabe con los dos signos.

Descartadas por medida, no por gusto:
  «Qué asco»   8 chars justos, no deja sitio para los signos
  «No comer»   suena a advertencia (David)
  «Tóxico»     se aleja del mensaje real (David)

NO SE MUEVE NADA
================
Las tres cadenas nuevas son MAS CORTAS que las que sustituyen, asi que se
escriben en el mismo sitio y **no hay que repuntar**. Los 7 punteros del
banco $0C se quedan como estan; se releen al final para comprobarlo.

Uso:  python3 tools/build_v272.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import encode, CHAR_TO_CODE          # noqa: E402

BASE = 'roms/momotaro_es_v271.pce'
SALIDA = 'roms/momotaro_es_v272.pce'
IPS = 'parches/momotaro_v272.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '68345b4235958b93ab26fde746d11d2f'

BANCO_INI, CPU_INI = 0x18000, 0xC000
ANCHO = 8                        # celdas del bocadillo pequeno, medido

# (offset, hueco reservado, texto viejo, texto nuevo)
CAMBIOS = [
    (0x19FBC, 9, 'Poderes', 'Artes'),
    (0x19FAF, 13, 'No se puede', 'No puedo'),
    (0x19C1F, 12, 'No se come', '¡Puaj!'),
]

# los 7 punteros del banco $0C: (tipo, datos, texto esperado)
PUNTEROS_TABLA = [
    (0x197F2, 'Objetos'),
    (0x197F4, 'Artes'),
    (0x19A61, '¡Puaj!'),
    (0x19A63, 'No puedo'),
]
PUNTEROS_INMED = [
    (0x199BC, 0x199C0, 'Faltan momos'),
    (0x199C5, 0x199C9, 'No puedo'),
    (0x199F0, 0x199F4, 'No puedo'),
]


def cpu(off):
    return CPU_INI + (off - BANCO_INI)


def cadena(txt):
    return bytes([0x01]) + encode(txt) + bytes([0x00])


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v271'
    print('base %s  OK' % BASE)
    inv = {v: k for k, v in CHAR_TO_CODE.items()}

    # ==================================================================
    # 1. todos los textos nuevos tienen que caber en el ancho del marco
    # ==================================================================
    print('\n--- ancho del bocadillo: %d celdas (medido por David)' % ANCHO)
    for _, _, viejo, nuevo in CAMBIOS:
        n = len(encode(nuevo))
        assert n <= ANCHO, '«%s» son %d chars, no caben en %d' \
            % (nuevo, n, ANCHO)
        print('    %-12r -> %-10r  %d chars  OK' % (viejo, nuevo, n))
    # y los que ya estaban
    for _, txt in PUNTEROS_TABLA:
        assert len(encode(txt)) <= ANCHO, '«%s» se sale del marco' % txt

    # ==================================================================
    # 2. escribir, comprobando antes lo que hay
    # ==================================================================
    print('\n--- escritura')
    for off, hueco, viejo, nuevo in CAMBIOS:
        esperado = cadena(viejo)
        assert bytes(rom[off:off + len(esperado)]) == esperado, \
            'en 0x%05X no esta %r, hay %s' \
            % (off, viejo, bytes(rom[off:off + len(esperado)]).hex(' '))
        cod = cadena(nuevo)
        assert len(cod) <= hueco, 'no cabe en el hueco reservado'
        # el resto del hueco vuelve a $FF (era relleno del banco)
        rom[off:off + hueco] = cod + b'\xFF' * (hueco - len(cod))
        print('    0x%05X ($%04X)  %-12r -> %-10r  %2d B de %d'
              % (off, cpu(off), viejo, nuevo, len(cod), hueco))

    # ==================================================================
    # 3. relectura: se sigue cada puntero como hace el motor
    # ==================================================================
    print('\n--- releido siguiendo los 7 punteros')

    def lee(w):
        o = BANCO_INI + (w - CPU_INI)
        assert rom[o] == 0x01, 'la cadena en $%04X no empieza por $01' % w
        f = o + 1
        while rom[f] != 0x00:
            f += 1
        return ''.join(inv.get(x, '[%02X]' % x) for x in rom[o + 1:f])

    for tabla, esperado in PUNTEROS_TABLA:
        w = rom[tabla] | (rom[tabla + 1] << 8)
        got = lee(w)
        assert got == esperado, 'tabla 0x%05X: leido %r' % (tabla, got)
        print('    tabla     0x%05X -> $%04X -> %-13r %d chars  OK'
              % (tabla, w, got, len(encode(got))))
    for lo, hi, esperado in PUNTEROS_INMED:
        w = rom[lo] | (rom[hi] << 8)
        got = lee(w)
        assert got == esperado, 'inmediato 0x%05X: leido %r' % (lo, got)
        print('    inmediato 0x%05X -> $%04X -> %-13r %d chars  OK'
              % (lo, w, got, len(encode(got))))

    # password y debug siguen en japones
    for tabla, off_cad, nom in ((0x197F6, 0x19807, 'password'),
                                (0x197F8, 0x19810, 'debug')):
        w = rom[tabla] | (rom[tabla + 1] << 8)
        assert w == cpu(off_cad), '%s ha cambiado de sitio' % nom
        print('    %-9s $%04X intacto (japones)' % (nom, w))

    # ==================================================================
    # 4. los glifos de «¡» y «!» existen en la fuente
    # ==================================================================
    ORI = rom[0x42B4C:0x42B53]
    DES = rom[0x42B54:0x42B5B]

    def glifo(c):
        if c in ORI:
            c = DES[ORI.index(c)]
        if 0x30 <= c and (c - 0x30) < 0x54:
            return rom[0x43F9B + c - 0x30]
        return rom[0x41C73 + c - 0x20]

    print('\n--- los signos de «¡Puaj!», comprobados en la fuente')
    for ch in ('¡', '!'):
        c = CHAR_TO_CODE[ch]
        g = glifo(c)
        a = 0x3D660 + g * 8
        pintado = any(rom[a:a + 8])
        assert pintado, 'el glifo de %r (cod $%02X -> $%02X) esta en blanco' \
            % (ch, c, g)
        print('    %r cod $%02X -> glifo $%02X  dibujado  OK' % (ch, c, g))

    # ==================================================================
    # 5. zonas intactas
    # ==================================================================
    intactas = [
        ('menu RUN del banco $21', 0x431AC, 0x431EB),
        ('«Nada» de las aldeas', 0x42ED9, 0x42EE0),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla de glifos', 0x43F9B, 0x44000),
        ('bucle del canto', 0x16A73, 0x16AD6),
        ('password $DE69', 0x17E69, 0x17E78),
        ('codigo del banco $0C', 0x18000, 0x197F2),
        ('«Objetos»', 0x19C50, 0x19C5A),
        ('«Faltan momos»', 0x19BF9, 0x19C0B),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    permitido = set()
    for off, hueco, _, _ in CAMBIOS:
        permitido |= set(range(off, off + hueco))
    assert set(dif) <= permitido, 'cambios fuera de sitio'
    print('%d bytes sobre la v271, todos en las 3 cadenas' % len(dif))

    open(SALIDA, 'wb').write(d)

    # --- IPS con round-trip ---
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
