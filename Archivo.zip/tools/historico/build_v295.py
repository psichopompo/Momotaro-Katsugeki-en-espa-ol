#!/usr/bin/env python3
"""
build_v295.py - las TIENDAS traducidas (banco $24).

ESTRUCTURA, MEDIDA
==================
tabla maestra `$C929` = ROM 0x10929, 24 entradas de 4 B:
    [puntero lo][puntero hi][precio lo][precio hi]
Los precios confirman la tabla: salen 200 y 500, los que ve David en la
tienda de armas.

lector `$9B0B` (banco $20): `LDA ($14)` byte a byte.
    < $20   codigo de control
    $5C     conmuta resaltado ($9AFD: EOR #$01 sobre $3666) -> VA EN PARES
    >= $A0  kana / letra directa
    resto   pasa por la tabla $9C73

El texto se reparte en LINEAS DE 20 y el relleno es `$A0`.
David: alineacion a la izquierda (el centrado japones es por ser vertical).

POR QUE ESTO DEBERIA QUITAR LOS ARTEFACTOS
==========================================
Los codigos solapan: `$A1-$B4` es `a..t` para nosotros y katakana para el
juego. Este texto japones se esta pintando con la fuente latina y sale
convertido en letras sueltas. Al traducirlo, deberia limpiarse solo.
Es la prueba de la hipotesis (norma 250).

NOMBRES (los que ya usa el juego, verificados en la tabla $AF4C)
    Onigiri, Manjar, Banquete, Dango, Pedos, Solar, Glacial,
    Raquetas, Bonzo, Capa, Aletas
    Corazas: Roja, Satsuki, Valor      Espadas: Katana, Byakko,
    Hiryu, Asura, Fenix, Valor
David: en la tienda van con «Espada X» / «Coraza X» para que se entienda.

Uso:  python3 tools/build_v295.py
"""
import hashlib, zlib, sys
sys.path.insert(0,'tools')
from charset_oficial import encode

BASE='roms/momotaro_es_v294.pce'; SALIDA='roms/momotaro_es_v295.pce'
IPS='parches/momotaro_v295.ips'; VIRGEN='roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE='1ebc049f703af63de27884a855ddc817'
TABLA=0x10929
REL=0xA0                      # relleno
ANCHO=20

# --- las 20 descripciones: (indice en la tabla, texto por lineas) -----
DESC = {
 0:("Onigiri:","Recupera 1 de vida."),
 1:("Manjar:","Recupera 1 técnica."),
 2:("Banquete:","Recupera 1 de cada."),
 3:("Dango:","Llama a un aliado."),
 4:("Bonzo:","Llueven melocotones."),
 5:("Pedos:","Atacas hacia atrás."),
 6:("Solar:","Calcina a los ogros."),
 7:("Glacial:","Congela a los ogros."),
 8:("Raquetas:","No resbalas en hielo"),
 9:("Capa:","Los ogros no te ven."),
 10:("Aletas:","Nadas con libertad."),
 11:("Coraza Roja:","Recibes menos daño."),
 12:("Coraza Satsuki:","Daño a la mitad."),
 13:("Coraza Valor:","Daño mínimo."),
 14:("Katana:","Dispara más lejos."),
 15:("Espada Byakko:","Dispara 2 seguidas."),
 16:("Espada Hiryu:","La de más alcance."),
 17:("Espada Asura:","Dispara 3 seguidas."),
 18:("Espada Fénix:","Balas más grandes."),
 19:("Espada Valor:","Las balas mayores."),
}

# --- los dialogos: (offset, lineas) -----------------------------------
DIAL = [
 (0x484C0, ["¡Gracias!","¡Vuelve pronto!"]),
 (0x484E1, ["¡Vaya! No te llega","el dinero. ¡Ánimo!"]),
 (0x48506, ["No hay arma más","fuerte que ésa."]),
 (0x48518, ["Siento no poder","ayudarte."]),
 (0x4852D, ["¡Bienvenido!","¿Te interesa una"]),
 (0x48551, ["coraza?","No te ha gustado."]),
 (0x4856B, ["Te espero de nuevo.","¡Muchas gracias!"]),
 (0x4858F, ["Te espero de nuevo.","¡Vaya, cliente!"]),
 (0x485AC, ["Te falta dinero.","No hay coraza mejor."]),
 (0x485D7, ["Siento no ayudarte.","¡Bienvenido!"]),
 (0x485F9, ["Llévate un Manjar.","¡Muchas gracias!"]),
 (0x48620, ["Si te quedas sin","técnica, vuelve."]),
 (0x48646, ["¡Vaya, cliente!","Te falta dinero."]),
 (0x4866B, ["No puedo venderte","más Manjares."]),
 (0x48684, ["¡Bienvenido!","¿Qué va a ser?"]),
 (0x486A9, ["No te ha gustado.","Vuelve otro día."]),
 (0x486CC, ["¡Muchas gracias!","Vuelve otro día."]),
 (0x486F1, ["¡Vaya, cliente!","Te falta dinero."]),
 (0x48716, ["¡Llevas las manos","llenas!"]),
 (0x4873C, ["¡Qué bien verte!","¿Necesitas algo?"]),
 (0x48764, ["Vuelve por aquí."]),
 (0x487A0, ["Muchas gracias."]),
 (0x487D4, ["¡Vaya, cliente!","Te falta dinero."]),
 (0x487F8, ["Llevas las manos","llenas."]),
]

def linea(txt):
    b=encode(txt)
    assert len(b)<=ANCHO, '«%s» son %d, el maximo es %d'%(txt,len(b),ANCHO)
    return b+bytes([REL])*(ANCHO-len(b))

def main():
    rom=bytearray(open(BASE,'rb').read()); orig=open(VIRGEN,'rb').read()
    base=bytes(rom)
    assert hashlib.md5(rom).hexdigest()==MD5_BASE,'la base no es la v294'
    print('base %s  OK'%BASE)

    # --- la tabla es la que creemos: los precios lo confirman ---------
    pr=[rom[TABLA+i*4+2]|(rom[TABLA+i*4+3]<<8) for i in range(24)]
    assert pr[14]==200 and pr[15]==500, 'los precios no cuadran'
    print('\n--- tabla $C929 verificada (precios 200 y 500 en su sitio)')

    ptr=[(rom[TABLA+i*4]|(rom[TABLA+i*4+1]<<8)) for i in range(24)]
    off=[0x48000+(w-0x4000) for w in ptr]

    # --- 1. las descripciones -----------------------------------------
    print('\n--- descripciones de objetos')
    orden=sorted(set(off))
    escritas=0
    for i,(nom_l) in DESC.items():
        o=off[i]
        nxt=[x for x in orden if x>o]
        hueco=(nxt[0] if nxt else o+45)-o
        cod=linea(nom_l[0])+linea(nom_l[1])
        # el hueco puede ser algo mayor o menor que 2 lineas: se ajusta
        if len(cod)<hueco: cod=cod+bytes([REL])*(hueco-len(cod))
        rom[o:o+hueco]=cod[:hueco]
        n=hueco
        print('    [%2d] 0x%05X %-16s %2d/%2d B'%(i,o,nom_l[0],n,hueco))
        escritas+=1
    print('    %d descripciones'%escritas)

    # --- 2. los dialogos ------------------------------------------------
    print('\n--- dialogos de tendero')
    for o,lineas in DIAL:
        cod=b''.join(linea(t) for t in lineas)
        # no pisar el bloque de descripciones
        assert o+len(cod)<=0x488A1, 'el dialogo de 0x%05X invade las descripciones'%o
        rom[o:o+len(cod)]=cod
        print('    0x%05X %-24r %d B'%(o,lineas[0],len(cod)))

    # --- 3. verificacion -------------------------------------------------
    # El $5C conmuta el resaltado ($9AFD: EOR #$01). En el ORIGINAL el
    # bloque tampoco esta balanceado (17 en 0x484C0-0x488A1, impar): el
    # resaltado se abre y cierra ENTRE mensajes, no dentro de cada uno.
    # Asi que no se puede exigir paridad. Lo que si se comprueba es que
    # NO HEMOS ANADIDO NI QUITADO ninguno respecto a la v294.
    for a,b in ((0x484C0,0x488A1),(0x488A1,0x48B7A)):
        antes=sum(1 for x in base[a:b] if x==0x5C)
        ahora=sum(1 for x in rom[a:b] if x==0x5C)
        assert ahora<=antes, \
            'hemos anadido $5C en 0x%05X-0x%05X: %d -> %d'%(a,b,antes,ahora)
        print('    $5C en 0x%05X-0x%05X: %d -> %d'%(a,b,antes,ahora))

    intactas=[('tabla $C929',TABLA,TABLA+96),
              ('menu de Game Over',0x1F9D5,0x1FA00),
              ('lista sprites GO',0x47CFC,0x47D60),
              ('parrilla',0x1BBBA,0x1BC00),
              ('tabla Jizo',0x16AD6,0x16B16),
              ('canto Game Over',0x1F7B6,0x1F836)]
    for nom,a,b in intactas:
        assert bytes(rom[a:b])==base[a:b],'se ha tocado %s'%nom
    print('intactas: %s'%', '.join(n for n,_,_ in intactas))

    d=bytes(rom); open(SALIDA,'wb').write(d)
    print('%d bytes sobre la v294'%sum(1 for i in range(len(d)) if d[i]!=base[i]))

    difv=[i for i in range(len(d)) if d[i]!=orig[i]]
    rec=[];i=0
    while i<len(difv):
        s=difv[i];j=i
        while j+1<len(difv) and difv[j+1]<=difv[j]+8: j+=1
        e=difv[j]+1
        rec.append(bytes([s>>16&0xFF,s>>8&0xFF,s&0xFF,(e-s)>>8,(e-s)&0xFF])+d[s:e])
        i=j+1
    p=b'PATCH'+b''.join(rec)+b'EOF'; open(IPS,'wb').write(p)
    t=bytearray(orig); q=5
    while p[q:q+3]!=b'EOF':
        o2=p[q]<<16|p[q+1]<<8|p[q+2]; n2=p[q+3]<<8|p[q+4]
        t[o2:o2+n2]=p[q+5:q+5+n2]; q+=5+n2
    assert bytes(t)==d,'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)'%len(p))
    print('\n%s\n  MD5    %s\n  CRC32  %08X'%(SALIDA,
        hashlib.md5(d).hexdigest(),zlib.crc32(d)&0xFFFFFFFF))

main()
