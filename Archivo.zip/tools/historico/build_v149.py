"""build_v149.py - el kanji RYO, 1 px arriba.

Parte de test_contenidos_v148.pce (MD5 2d6afb1b3a6b934cd6e053427f9ed505).

EL PROBLEMA (David): «El kanji del ryo esta 1 px mas abajo del numero que
tiene al lado. Habria que subirlo.»

MEDIDO
------
En el CG del menu, fila del dinero:

    digitos  cuerpo en las filas 0..6
    ryo      cuerpo en las filas 1..7     <- 1 px mas abajo

DONDE ESTA DE VERDAD
--------------------
Me despiste dos veces antes de dar con ello:

  1. Mire el glifo $3E de la fuente MENU (ROM 0x40E0): esta bien, filas 0..6.
     No es ese el que se dibuja.
  2. Busque la secuencia del CG en la ROM y salio 0x40DF, un byte antes del
     glifo. Era CASUALIDAD: ese $00 es el ultimo byte de la sombra del
     glifo anterior ($3D).

La buena es la otra coincidencia: **0x3DB58**, que cae exacta en la fuente
DIALOGO (base 0x3D660, 8 B/glifo) = **glifo 159 ($9F)**.

El ryo del menu se dibuja por la RUTA BAJA: el remapeo 0x42B4C convierte
$24 -> $3E, y la tabla baja $BF9B (ROM 0x43F9B) manda el $3E al glifo 159
de la fuente DIALOGO. Ese glifo tiene la fila 0 vacia y el dibujo corrido
una fila hacia abajo.

USO UNICO
---------
Barridas las cinco tablas (fuente 0, 1, 2, 3 y la baja), el glifo 159 lo
referencia SOLO el codigo $3E. Subirlo no afecta a nada mas.

EL ARREGLO
----------
Rotar el glifo una fila hacia arriba. La fila que se pierde arriba es $00
(vacia) y la que entra abajo tambien: no se pierde ni un pixel.

    antes  00 FE 10 FE 92 D6 FE 82
    ahora  FE 10 FE 92 D6 FE 82 00
"""
import os
import sys
import hashlib
import zlib

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(RAIZ, 'roms', 'test_contenidos_v148.pce')
SALIDA = os.path.join(RAIZ, 'roms', 'test_ryo_v149.pce')
MD5_BASE = '2d6afb1b3a6b934cd6e053427f9ed505'

FUENTE_DIALOGO = 0x3D660
GLIFO = 159
TABLA_BAJA = 0x43F9B


def main():
    rom = bytearray(open(BASE, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v148'

    o = FUENTE_DIALOGO + GLIFO * 8
    viejo = bytes(rom[o:o + 8])
    assert viejo == bytes([0x00, 0xFE, 0x10, 0xFE, 0x92, 0xD6, 0xFE, 0x82]), \
        'el glifo 159 no es el ryo esperado: %s' % viejo.hex()
    assert viejo[0] == 0x00, 'la fila que se pierde no esta vacia'

    # solo el codigo $3E debe apuntar a este glifo
    refs = [0x30 + i for i in range(84) if rom[TABLA_BAJA + i] == GLIFO]
    assert refs == [0x3E], 'el glifo 159 lo usa tambien %s' % [hex(r) for r in refs]
    for base in (0x41CF3, 0x41CB3):
        assert GLIFO not in rom[base:base + 0x40], \
            'una tabla alta apunta al glifo 159'

    nuevo = viejo[1:] + b'\x00'
    rom[o:o + 8] = nuevo

    # verificacion: el cuerpo pasa de las filas 1..7 a las 0..6
    d = rom[o:o + 8]
    filas = [y for y in range(8) if d[y]]
    assert (min(filas), max(filas)) == (0, 6), \
        'el glifo no quedo en las filas 0..6: %s' % filas

    open(SALIDA, 'wb').write(bytes(rom))
    print('escrito', SALIDA)
    print('MD5  ', hashlib.md5(rom).hexdigest())
    print('SHA1 ', hashlib.sha1(rom).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
    print()
    print('glifo 159 (ryo) en 0x%05X' % o)
    print('  antes %s   filas 1..7' % viejo.hex())
    print('  ahora %s   filas 0..6' % nuevo.hex())


if __name__ == '__main__':
    main()
