#!/usr/bin/env python3
"""v307 = v306 con los textos de TIENDA maquetados y revisados por David.

Las cadenas NO se escriben a mano en este fichero: se LEEN de
`docs/MAQUETACION_tiendas.md`, que es el documento que ha revisado David.
Así lo que se inserta es exactamente lo aprobado, sin copiar a mano.

Formato del motor (medido, ver INFORME_v296_a_v301.md):
  $C6C4 hace LDX #$02 / LDX #$10  -> 2 lineas de 16 = 32 bytes fijos.
  Relleno con $A0. Alineado a la izquierda.
  Tabla 0x10854 = 8 tiendas x 6 ranuras de 2 bytes.

CODIFICACION (norma 256): el motor de tienda ($9B0B) NO es el del menu.
'b','c','p' y 'Ç' deben ir con sus bytes DIRECTOS $A2 $A3 $B0 $DE.
charset_oficial.encode() usa los alias del menu ($5B/$5D/$5E) y aqui
pintarian una ©. Por eso se post-procesa.
"""
import hashlib, re, sys, zlib
sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE

SRC = 'roms/momotaro_es_v306.pce'
JP  = 'roms/Momotarou Katsugeki (Japan).pce'
DOC = 'docs/MAQUETACION_tiendas.md'
DST = 'roms/momotaro_es_v307.pce'

TABLA = 0x10854          # 8 tiendas x 6 ranuras
BANCO24 = 0x48000        # banco $24 -> logico $4000
RELLENO = 0xA0

# alias que hay que deshacer para el motor de TIENDA
ALIAS_TIENDA = {0x5B: 0xA2, 0x5D: 0xA3, 0x5E: 0xB0, 0xDE: 0xDE}


def cod_tienda(s):
    """Codifica para el motor de tienda: 16 bytes exactos, relleno $A0."""
    out = bytearray()
    for ch in s:
        if ch not in CHAR_TO_CODE:
            raise ValueError('caracter no soportado: %r' % ch)
        b = CHAR_TO_CODE[ch]
        out.append(ALIAS_TIENDA.get(b, b))
    if len(out) > 16:
        raise ValueError('linea de %d caracteres: %r' % (len(out), s))
    out += bytes([RELLENO] * (16 - len(out)))
    return bytes(out)


def lee_documento(path):
    """Extrae {puntero: (L1, L2)} de las lineas PROPUESTA del documento."""
    lines = open(path, encoding='utf-8').read().split('\n')
    props, cur = {}, None
    for i, l in enumerate(lines):
        m = re.match(r'### .*·  `(\$[0-9A-F]{4})`  ·  hueco', l)
        if m:
            cur = m.group(1)
            continue
        if l.startswith('PROPUESTA |') and cur:
            l1 = l[11:].rstrip()
            l2 = lines[i + 1][11:].rstrip()
            assert l1.endswith('|') and l2.endswith('|'), 'formato en %s' % cur
            par = (l1[:-1].rstrip(), l2[:-1].rstrip())
            # Un mismo puntero puede aparecer varias veces en el documento
            # (las ranuras que lo comparten). Todas tienen que decir LO MISMO,
            # o no se sabria cual escribir. Paso en la v307: corregi una
            # aparicion de $4834 y el parser se quedo con otra sin corregir.
            if cur in props:
                assert props[cur] == par, (
                    'el puntero %s aparece con dos propuestas distintas:\n'
                    '  |%s| / |%s|\n  |%s| / |%s|'
                    % (cur, props[cur][0], props[cur][1], par[0], par[1]))
            props[cur] = par
            cur = None
    return props


def main():
    rom = bytearray(open(SRC, 'rb').read())
    jp = open(JP, 'rb').read()
    orig = bytes(rom)
    assert len(rom) == 512 * 1024
    assert hashlib.md5(orig).hexdigest() == 'b1ac7be52f6010d74a887be0766969ae', \
        'la base no es la v306'

    props = lee_documento(DOC)

    # los punteros del documento tienen que ser EXACTAMENTE los de la tabla
    de_tabla = set()
    for t in range(8):
        o = TABLA + t * 12
        for s in range(6):
            de_tabla.add(rom[o + s * 2] | (rom[o + s * 2 + 1] << 8))
    del_doc = {int(k[1:], 16) for k in props}
    assert del_doc == de_tabla, 'el documento no cuadra con la tabla: %s' % (
        sorted('%04X' % x for x in de_tabla ^ del_doc))

    # la tabla NO se toca: solo se reescribe el contenido de cada cadena
    escritas = 0
    for key, (l1, l2) in sorted(props.items()):
        w = int(key[1:], 16)
        r = BANCO24 + (w - 0x4000)
        dato = cod_tienda(l1) + cod_tienda(l2)
        assert len(dato) == 32
        rom[r:r + 32] = dato
        escritas += 1

    # --- zonas que no se pueden tocar -------------------------------------
    assert rom[TABLA:TABLA + 96] == orig[TABLA:TABLA + 96], 'tabla de tiendas tocada'
    assert rom[0x10929:0x10929 + 96] == orig[0x10929:0x10929 + 96], 'tabla maestra tocada'
    # el bloque de vitores/finales sigue intacto (aun sin traducir)
    assert rom[0x48401:0x4847D] == jp[0x48401:0x4847D], 'tocado el bloque de vitores'
    # motor, glifos, tablas de indice, CG de tienda
    assert rom[0x41B0B:0x41B40] == orig[0x41B0B:0x41B40], 'motor $9B0B tocado'
    assert rom[0x41C73:0x41D33] == orig[0x41C73:0x41D33], 'tabla $9C73 tocada'
    assert rom[0x3D660:0x3E000] == orig[0x3D660:0x3E000], 'glifos tocados'
    assert rom[0x2C05A:0x2C319] == orig[0x2C05A:0x2C319], 'stream del CG tocado'
    assert rom[0x105F3:0x1060E] == orig[0x105F3:0x1060E], 'cargador del CG tocado'
    for nom, o, n in (('f0', 0x41CF3, 64), ('f1', 0x41CB3, 64), ('parrilla', 0x1BBBA, 64),
                      ('Jizo', 0x16AD6, 64), ('canto GO', 0x1F7B6, 128)):
        assert rom[o:o + n] == orig[o:o + n], 'tabla %s tocada' % nom
    assert rom[0x47CFB] == 0xFF, 'terminador de la lista del abuelo pisado'
    assert rom[0x1F9C4:0x1FA00] == orig[0x1F9C4:0x1FA00], 'rotulo/Game Over tocado'
    assert rom[0x2F8B5:0x2F8C5] == orig[0x2F8B5:0x2F8C5], 'sprites del titulo tocados'
    # descripciones de objeto: no entran en esta tanda
    assert rom[0x488A1:0x48C60] == orig[0x488A1:0x48C60] or True  # (se comprueba abajo)

    fuera = []
    permitido = set()
    for key in props:
        w = int(key[1:], 16)
        r = BANCO24 + (w - 0x4000)
        permitido |= set(range(r, r + 32))
    for i in range(len(rom)):
        if rom[i] != orig[i] and i not in permitido:
            fuera.append(i)
    assert not fuera, 'cambios fuera de las cadenas: %s' % [hex(x) for x in fuera[:12]]

    open(DST, 'wb').write(rom)

    # --- RELECTURA siguiendo el puntero, como hace el motor ---------------
    v = open(DST, 'rb').read()
    inv = {val: k for k, val in CHAR_TO_CODE.items()}
    T = dict(inv)
    T[0xA2], T[0xA3], T[0xB0], T[0xDE] = 'b', 'c', 'p', 'Ç'

    def des(b):
        return ''.join('' if x == RELLENO else T.get(x, '{%02X}' % x) for x in b)

    print('relectura por la tabla 0x10854:')
    fallos = 0
    for t in range(8):
        o = TABLA + t * 12
        for s in range(6):
            w = v[o + s * 2] | (v[o + s * 2 + 1] << 8)
            r = BANCO24 + (w - 0x4000)
            l1, l2 = des(v[r:r + 16]), des(v[r + 16:r + 32])
            esp = props['$%04X' % w]
            if (l1, l2) != esp:
                print('  FALLO tienda %d ranura %d: |%s|/|%s| != |%s|/|%s|'
                      % (t, s, l1, l2, esp[0], esp[1]))
                fallos += 1
    assert not fallos, '%d ranuras no releen lo esperado' % fallos
    print('  las 48 ranuras releen exactamente lo aprobado')

    # ninguna © suelta por el alias mal puesto
    for key in props:
        w = int(key[1:], 16)
        r = BANCO24 + (w - 0x4000)
        assert 0x8B not in v[r:r + 32], 'hay un $8B (©) en %s' % key
    print('  sin ningun $8B: los alias b/c/p van con sus bytes directos')

    b = bytes(v)
    print()
    print('%s  (%d cadenas, %d bytes cambiados)'
          % (DST, escritas, sum(1 for i in range(len(b)) if b[i] != orig[i])))
    print('  MD5    %s' % hashlib.md5(b).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(b) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
