#!/usr/bin/env python3
"""
build_v200.py - ajuste fino del bocadillo del abuelo: -23 px en X, -5 en Y.

LO QUE PIDE DAVID
-----------------
> «En tu mockup del abuelo, el bocadillo tendria que estar 5 px mas arriba
>  (siempre que sea posible) y 23 px mas a la izquierda. Esto es porque,
>  aunque no nos habiamos dado cuenta, justo a la izquierda del abuelo,
>  dentro del bocadillo, vemos el rabillo lateral con el que habria que
>  alinearlo.»

MEDIDO
------
El bocadillo del abuelo sale SIEMPRE en la misma posicion de pantalla. Con
la v199 el ancla cae en (160, 28) y el rabillo lateral (celda 1AF) en
x=207..222, y=48..63. El cuerpo ocupa x=88..231.

Con -23/-5 el ancla pasa a (137, 23) y el cuerpo a x=65..208, que es
justo donde el borde derecho del cuerpo se pega al rabillo.

EL RABILLO NO SE MUEVE
----------------------
El rabillo tiene que seguir donde esta (pegado al abuelo). Como se dibuja
con el MISMO ancla, hay que compensarle el desplazamiento en la tabla
$9ADD:

    dX: 47 -> 70   (207 - 137)
    dY: 20 -> 25   ( 48 -  23)

COSTE EN RANURAS: CERO
----------------------
Simulado con `tools/vdc_slots.py` sobre los 4 states validos de la v199
(`Abuelo final minijuego 1`, `Comentario abuelo caja`, `Abuelo mensaje
caja`, `Recuadro verde sobre enemigo`): **ni un sprite mutilado de mas**.

En un quinto state (`Mensaje abuelo sprites por linea`) subir 5 px le
quitaba 5 filas a MOMOTARO (celda 0C4), que ahi esta saltando a la altura
del HUD. David: «es normal que Momotaro quede tapado por el HUD. Eso no lo
hemos hecho nosotros». Asi que se aplica el -5 completo.

Uso:  python3 tools/build_v200.py
"""
import hashlib
import zlib
import subprocess

BASE = 'roms/momotaro_es_v199.pce'
SALIDA = 'roms/momotaro_es_v200.pce'
IPS = 'parches/momotaro_v200.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '6628bb57acb0fe4f31bfd30b93bf025a'

# OJO: estas son las direcciones del OPERANDO, no las del opcode.
#   ROM 0x168B1 = E9 (opcode SBC)   ROM 0x168B2 = 48 (operando)
# En la primera pasada escribi el valor en 0x168B1 y machaque el SBC: el
# desensamblado lo canto al instante ("BBR5 $48"). Por eso se desensambla
# SIEMPRE desde la ROM ya escrita y no desde el fuente.
ABUELO_X = 0x168B2              # operando del $88B1 SBC #$48
ABUELO_Y = 0x168C3              # operando del $88C2 SBC #$1C
RAB2_DX = 0x41AF4               # dX de la variante 2 en la tabla $9ADD
RAB2_DY = 0x41AF5               # dY

DX = 23                         # a la izquierda
DY = 5                          # hacia arriba


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v199'
    print('base %s  OK' % BASE)

    # --- 1. el ancla ---------------------------------------------------
    esp = bytes([0x38, 0xE9, 0x48])                 # SEC / SBC #$48
    assert bytes(rom[ABUELO_X - 2:ABUELO_X + 1]) == esp, \
        'en $88B0 no esta el SBC #$48: %s' % bytes(
            rom[ABUELO_X - 2:ABUELO_X + 1]).hex()
    esp = bytes([0x38, 0xE9, 0x1C])                 # SEC / SBC #$1C
    assert bytes(rom[ABUELO_Y - 2:ABUELO_Y + 1]) == esp, \
        'en $88C1 no esta el SBC #$1C (la v199): %s' % bytes(
            rom[ABUELO_Y - 2:ABUELO_Y + 1]).hex()

    # restar mas al ancla = mover el bocadillo hacia la izquierda/arriba
    rom[ABUELO_X] = 0x48 + DX                       # $48 -> $5F
    rom[ABUELO_Y] = 0x1C + DY                       # $1C -> $21
    print('\nancla del abuelo:')
    print('  $88B1 SBC #$48 -> SBC #$%02X   (%d px a la izquierda)'
          % (0x48 + DX, DX))
    print('  $88C2 SBC #$1C -> SBC #$%02X   (%d px hacia arriba)'
          % (0x1C + DY, DY))

    # --- 2. compensar el rabillo, que NO se mueve ----------------------
    esp = bytes([0x3F, 0x0F, 0x00, 0x2F, 0x14, 0xFF])
    assert bytes(rom[RAB2_DX - 3:RAB2_DX + 3]) == esp, \
        'la variante 2 del rabillo no es la de la v199: %s' % bytes(
            rom[RAB2_DX - 3:RAB2_DX + 3]).hex()
    rom[RAB2_DX] = 0x2F + DX                        # 47 -> 70
    rom[RAB2_DY] = 0x14 + DY                        # 20 -> 25
    print('rabillo lateral (celda 1AF), compensado para no moverse:')
    print('  dX 47 -> %d      dY 20 -> %d' % (0x2F + DX, 0x14 + DY))

    # los opcodes tienen que seguir intactos (el fallo de la 1a pasada)
    assert rom[ABUELO_X - 1] == 0xE9 and rom[ABUELO_Y - 1] == 0xE9, \
        'se ha machacado un opcode SBC'
    assert rom[RAB2_DX - 3] == 0x3F, 'se ha machacado la celda del rabillo'

    # --- 3. verificacion geometrica ------------------------------------
    # ancla de pantalla del abuelo en la v199: (160, 28)
    ax, ay = 160 - DX, 28 - DY
    rx, ry = ax + rom[RAB2_DX], ay + rom[RAB2_DY]
    print('\ncomprobacion:')
    print('  ancla   (160,28) -> (%d,%d)' % (ax, ay))
    print('  cuerpo  x=88..231 -> x=%d..%d' % (88 - DX, 231 - DX))
    print('  rabillo x=207..222 -> x=%d..%d  y=%d..%d'
          % (rx, rx + 15, ry, ry + 15))
    assert (rx, ry) == (207, 48), 'el rabillo se ha movido: (%d,%d)' % (rx, ry)
    print('  el rabillo NO se mueve: OK')

    # --- 4. desensamblar lo escrito, desde la ROM ----------------------
    tmp = '/tmp/_v200.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM construida')
    for off, n, carga, nom in [(0x168AD, 20, 0x88AD, 'ancla del abuelo'),
                               (0x41AF1, 6, 0x9AF1, 'rabillo variante 2')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % off,
                            str(n), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('rutina de recorte $FF6B', 0x1F6B, 0x1FE0),
        ('lista de sprites', 0x47C02, 0x47CB6),
        ('CG del bocadillo', 0x3D214, 0x3D660),
        ('fuente', 0x3D660, 0x3E200),
        ('cabecera y vectores', 0x1FE0, 0x2000),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    assert dif == [ABUELO_X, ABUELO_Y, RAB2_DX, RAB2_DY], \
        'ha cambiado algo que no tocaba: %s' % ['%05X' % x for x in dif]
    print('%d bytes sobre la v199: %s'
          % (len(dif), ' '.join('%05X' % x for x in dif)))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
