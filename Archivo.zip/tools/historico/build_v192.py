#!/usr/bin/env python3
"""
build_v192.py - las cabezas que desaparecen: bajar de 12 a 10 sprites por
                linea de scan.

EL FALLO
--------
David: «a muchos personajes les desaparecen partes de los graficos de la
cabeza. Esto tiene que ser por los sprites por linea».

**Exacto.** El VDC del PC Engine dibuja **16 sprites por scanline** y uno de
32 px de ancho cuenta como dos. Contando las ranuras del bocadillo:

```
dY=12..27   10 ranuras   borde superior
dY=28..43   12 ranuras   TEXTO   <-- aqui
dY=44..59   12 ranuras   TEXTO   <-- y aqui
dY=60..75   10 ranuras   borde inferior + rabillo
```

En las filas de texto quedan **4 ranuras** para Momotaro, los aldeanos y el
HUD. Por eso se recortan las cabezas.

David propone subir el bocadillo unos pixeles. **No sirve**: el problema no
es donde esta, es cuantos sprites hay en cada linea. Subirlo solo mueve el
recorte a otra altura del personaje.

DE DONDE SALEN LAS 12 RANURAS
------------------------------
```
1A0 lateral izq   x=-80..-64    1
170..177 texto    x=-72..56     8
1A6 tapon izq     x=-77..-61    1   <-- sobra
1A6 tapon der     x= 51..67     1   <-- sobra
1A1 lateral der   x= 67..83     1
                                --
                                12
```

Los dos tapones los anadi en la v186 para cubrir el fondo que asomaba entre
el trazo y el texto. **Son el exceso**: el minimo teorico de un marco de
160 px son 10 ranuras.

EL ARREGLO: que el CG tape los huecos, no dos sprites de mas
-------------------------------------------------------------
En vez de poner sprites encima, se rellena de blanco el CG de los laterales
y se recoloca el texto para que no quede hueco:

```
1A0 lateral izq:  trazo en las columnas 0-2, y 3-15 BLANCO
                  (antes 3-15 transparentes)
1A1 lateral der:  BLANCO en 0-14 y el trazo en la 15
                  (antes blanco 0-11, trazo en la 12, 13-15 transparente)

texto:  de -72 a 56   ->   de -64 a 64    (margen 16 en vez de 8)
1A1:    x=67          ->   x=64
```

Con eso:

```
trazo izq  -80..-77
1A0 blanco -77..-64      pegado al texto
texto      -64..64
1A1 blanco  64..79       pegado al texto
trazo der   79           alineado con el de la esquina
```

Sin un solo pixel de fondo, y **10 ranuras** por linea en vez de 12: dos
libres mas para los personajes.

EL PUNTERO DEL CG SE MUEVE 2 BYTES
-----------------------------------
Rellenar de blanco el CG **encarece la compresion**: el stream pasa de 607 a
609 B y el hueco original son 607. Como el puntero esta en `$9C32` con
inmediatos (`LDA #$01 / LDA #$54` = `$5401`), se mueve el stream 2 bytes
hacia atras, a `$53FF` (ROM `0x3D3FF`), donde hay 44 B libres entre mi
stream de las 16 celdas blancas y este.

David pedia ademas «subir el bocadillo lo menos posible». No hace falta para
las cabezas, pero **el margen del texto pasa de 8 a 16 px**, que es un
cambio visible: se avisa para que lo valide.

Uso:  python3 tools/build_v192.py
"""
import hashlib
import zlib
import struct
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v191.pce'
SALIDA = 'roms/momotaro_es_v192.pce'
IPS = 'parches/momotaro_v192.ips'
MD5_BASE = 'cc43e9c823d27028bcc4902b95b8f2f3'

CG_VIEJO = 0x3D401
CG_FIN = 0x3D660
PUNTERO = 0x41C3C        # LDA #$01 / STA $14 / LDA #$54 / STA $15
MI_STREAM_FIN = 0x3D3D4  # donde acaba el stream de las 16 celdas blancas

LISTA = 0x47C02
LAT_I, LAT_D = 0x1A0, 0x1A1
TAPON = 0x1A6
CELDA0 = 0x170
X0 = -80
ANCHO = 160
MARGEN = 16              # antes 8
ANCHO_TXT = 128


def setp(c, x, y, col):
    w = list(struct.unpack('<64H', bytes(c)))
    b = 15 - x
    for p in range(4):
        if (col >> p) & 1:
            w[p * 16 + y] |= 1 << b
        else:
            w[p * 16 + y] &= ~(1 << b) & 0xFFFF
    c[:] = struct.pack('<64H', *w)


def getp(c, x, y):
    w = struct.unpack('<64H', bytes(c))
    b = 15 - x
    return ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
        | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v191 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # 1. contar las ranuras de ahora
    # ------------------------------------------------------------------
    def ranuras(r):
        i = LISTA
        f = {}
        while r[i] != 0xFF:
            b0, b1, b2, dx, dy = r[i:i + 5]
            sy = dy - 256 if dy > 127 else dy
            f[sy] = f.get(sy, 0) + (2 if (b2 & 1) else 1)
            i += 5
        return f
    antes = ranuras(rom)
    print('ranuras por linea ANTES: %s' % dict(sorted(antes.items())))
    assert max(antes.values()) == 12, 'esperaba 12 ranuras en el peor caso'

    # ------------------------------------------------------------------
    # 2. el CG: rellenar de blanco los laterales
    # ------------------------------------------------------------------
    f = Flujo(rom, CG_VIEJO)
    cg = [bytearray(b''.join(tile(f) for _ in range(4))) for _ in range(20)]
    # la v190 recomprimio el CG al meter el rabillo simetrico: ocupa 603 B
    # y no llena el hueco hasta CG_FIN. Se comprueba que lo que sobra esta
    # a cero, no que acabe justo.
    assert f.p <= CG_FIN, 'el stream se pasa del hueco'
    assert set(rom[f.p:CG_FIN]) <= {0x00}, 'hay datos tras el stream'
    print('stream actual: 0x%05X..0x%05X (%d B)' % (CG_VIEJO, f.p - 1,
                                                    f.p - CG_VIEJO))

    a = cg[LAT_I - 0x19C]
    assert [x for x in range(16) if getp(a, x, 0)] == [0, 1, 2], \
        'el lateral izquierdo no tiene el trazo en 0-2'
    for y in range(16):
        for x in range(3, 16):
            setp(a, x, y, 7)
    print('1A0 lateral izq: columnas 3-15 -> BLANCO (antes transparentes)')

    b = cg[LAT_D - 0x19C]
    assert [x for x in range(16) if getp(b, x, 0)] == list(range(13)), \
        'el lateral derecho no es blanco 0-11 + trazo en 12'
    for y in range(16):
        for x in range(16):
            setp(b, x, y, 6 if x == 15 else 7)
    print('1A1 lateral der: blanco 0-14, trazo movido de la columna 12 a la 15')

    # ------------------------------------------------------------------
    # 3. recomprimir y recolocar el stream
    # ------------------------------------------------------------------
    stream = b''.join(comprime(bytes(c)) for c in cg)
    print('stream: %d B (antes %d)' % (len(stream), CG_FIN - CG_VIEJO))
    nuevo_ini = CG_FIN - len(stream)
    assert nuevo_ini >= MI_STREAM_FIN, \
        'el stream nuevo pisa el de las 16 celdas blancas'
    # OJO: 0x3D400 es la CUENTA de celdas (=20), y $9C4E la lee con
    # LDX $5400 (absoluto). Al mover el stream hay que mover la cuenta
    # con el y repuntar ese LDX.
    assert rom[0x3D400] == 20, 'la cuenta del CG no es 20'
    assert set(rom[MI_STREAM_FIN:0x3D400]) == {0xFF}, \
        'la zona entre los dos streams no esta libre'
    assert nuevo_ini - 1 >= MI_STREAM_FIN, \
        'no cabe la cuenta delante del stream nuevo'
    rom[nuevo_ini:CG_FIN] = stream
    rom[nuevo_ini - 1] = 20                    # la cuenta, delante
    rom[MI_STREAM_FIN:nuevo_ini - 1] = b'\xFF' * (nuevo_ini - 1 - MI_STREAM_FIN)
    print('  cuenta (=20) movida a ROM 0x%05X' % (nuevo_ini - 1))

    # repuntar el LDX $5400 de $9C4E
    o_cuenta = 0x41C4E
    assert bytes(rom[o_cuenta:o_cuenta + 3]) == bytes([0xAE, 0x00, 0x54]), \
        'en $9C4E no hay LDX $5400 sino %s' % bytes(
            rom[o_cuenta:o_cuenta + 3]).hex()
    log_cuenta = 0x4000 + (nuevo_ini - 1 - 0x3C000)
    rom[o_cuenta + 1] = log_cuenta & 0xFF
    rom[o_cuenta + 2] = log_cuenta >> 8
    print('  $9C4E: LDX $5400 -> LDX $%04X' % log_cuenta)
    print('  colocado en ROM 0x%05X..0x%05X (%d B libres delante)'
          % (nuevo_ini, CG_FIN - 1, nuevo_ini - MI_STREAM_FIN))

    # el puntero de $9C32
    esperado = bytes([0xA9, 0x01, 0x85, 0x14, 0xA9, 0x54, 0x85, 0x15])
    assert bytes(rom[PUNTERO:PUNTERO + 8]) == esperado, \
        'el puntero de $9C32 no es el esperado: %s' % bytes(
            rom[PUNTERO:PUNTERO + 8]).hex()
    log = 0x4000 + (nuevo_ini - 0x3C000)
    rom[PUNTERO + 1] = log & 0xFF
    rom[PUNTERO + 5] = log >> 8
    print('  puntero $9C32: $5401 -> $%04X' % log)

    # round-trip
    f2 = Flujo(bytes(rom), nuevo_ini)
    for k in range(20):
        c = b''.join(tile(f2) for _ in range(4))
        assert c == bytes(cg[k]), 'round-trip roto en la celda %03X' % (
            0x19C + k)
    assert f2.p == CG_FIN
    print('  round-trip de las 20 celdas: OK')

    # ------------------------------------------------------------------
    # 4. la lista: quitar los tapones y recolocar texto y lateral derecho
    # ------------------------------------------------------------------
    regs = []
    i = LISTA
    while rom[i] != 0xFF:
        regs.append(list(rom[i:i + 5]))
        i += 5
    nueva = []
    for r in regs:
        celda = 0x170 + r[0]
        dx = r[3] - 256 if r[3] > 127 else r[3]
        dy = r[4] - 256 if r[4] > 127 else r[4]
        if celda == TAPON:
            continue                              # fuera los dos tapones
        if CELDA0 <= celda < CELDA0 + 16:         # texto: margen 8 -> 16
            dx += 8
        if celda == LAT_D:                        # lateral derecho: 67 -> 64
            dx = X0 + ANCHO - 16
        r[3] = dx & 0xFF
        r[4] = dy & 0xFF
        nueva.append(r)
    quitados = len(regs) - len(nueva)
    assert quitados == 4, 'se han quitado %d tapones, esperaba 4' % quitados
    print('\nlista: %d sprites (antes %d), fuera los %d tapones'
          % (len(nueva), len(regs), quitados))

    off = LISTA
    for r in nueva:
        rom[off:off + 5] = bytes(r)
        off += 5
    rom[off] = 0xFF
    for k in range(off + 1, LISTA + 220):
        rom[k] = 0xFF

    # ------------------------------------------------------------------
    # 5. verificar: ni un pixel de fondo, y 10 ranuras
    # ------------------------------------------------------------------
    despues = ranuras(rom)
    print('ranuras por linea DESPUES: %s' % dict(sorted(despues.items())))
    assert max(despues.values()) == 10, \
        'siguen quedando %d ranuras' % max(despues.values())
    print('  de 12 a 10: dos ranuras libres mas para los personajes')

    # cobertura de la fila de texto
    tramos = []
    i = LISTA
    while rom[i] != 0xFF:
        b0, b1, b2, dx, dy = rom[i:i + 5]
        sy = dy - 256 if dy > 127 else dy
        sx = dx - 256 if dx > 127 else dx
        celda = 0x170 + b0
        if sy == 28:
            if celda == LAT_I:
                tramos.append((sx, sx + 16))          # ahora blanco entero
            elif celda == LAT_D:
                tramos.append((sx, sx + 15))          # blanco hasta el trazo
            else:
                tramos.append((sx, sx + 16))
        i += 5
    tramos.sort()
    x = X0 + 3
    for p, q in tramos:
        if p > x:
            raise AssertionError('fondo a la vista de %d a %d' % (x, p))
        x = max(x, q)
    assert x >= X0 + ANCHO - 1, 'la fila no llega al trazo derecho (%d)' % x
    print('  fila de texto cubierta de %d a %d, sin fondo' % (X0 + 3, x))

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('tabla rabillo', 0x41ADD, 0x41AFD),
        ('mi stream de 16 celdas', 0x3D214, MI_STREAM_FIN),
        ('fuente', 0x3D660, 0x3E200),
        ('ancla $C825', 0x16825, 0x16829),
    ]
    for nom, p, q in intactas:
        assert rom[p:q] == orig[p:q], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [k for k in range(len(rom)) if rom[k] != orig[k]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = []
    k = 0
    while k < len(dif):
        p = dif[k]
        j = k
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        q = dif[j] + 1
        rec.append(bytes([p >> 16 & 0xFF, p >> 8 & 0xFF, p & 0xFF,
                          (q - p) >> 8, (q - p) & 0xFF]) + d[p:q])
        k = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        of = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n = raw[p + 3] << 8 | raw[p + 4]
        prueba[of:of + n] = raw[p + 5:p + 5 + n]
        p += 5 + n
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  1. Las cabezas de los personajes COMPLETAS.')
    print('  2. El bocadillo igual que en la v191, pero con el texto 8 px')
    print('     mas a la derecha (margen 16 en vez de 8). Si prefieres el')
    print('     margen de 8, dilo: se recupera moviendo el marco.')


if __name__ == '__main__':
    main()
