#!/usr/bin/env python3
"""
build_v227.py - lista propia para el abuelo, BIEN hecha. Revierte la v226.

LOS TRES FALLOS DE LA v226, reconocidos
=======================================

**1. Me comi el terminador de la lista compartida.**
Puse la tabla de punteros en `0x47C98`, que es EXACTAMENTE donde estaba el
`$FF` que cierra la lista de aldeanos/Jizo. Resultado: esa lista dejaba de
terminar y seguia leyendo mi tabla como si fueran sprites.

David lo cazo con el Sprite Viewer: *"tile index $1EC, 16x64"*. Y en efecto,
`0x170 + $7C = $1EC`, donde `$7C` es el byte alto de mi puntero `$7C02`.
Por eso ademas se rompio el bocadillo de los Jizo y los aldeanos.

  -> El hueco de verdad empieza en `0x47C99`, DESPUES del terminador.

**2. El selector no podia funcionar: `$E3EB` machaca la `Y`.**
Mi plan era reusar la `Y` que `$9A87` calcula para el rabillo. Pero entre
ese calculo y mi selector hay un `JSR $E3EB` (la 1a llamada, la del
rabillo), y `$E3EB` hace `CLY` y usa `Y` como indice propio:

```
$9A83  LDA $368F / ASL A / TAY    <- Y = variante*2
$9A88  LDA $9ADD,Y ...            <- puntero del rabillo   (Y viva)
$9A92  JSR $E3EB                  <- CLY: LA MATA
$9A9F  (mi selector)              <- Y = basura
```

  -> Hay que RECALCULAR `Y` releyendo `$368F`. Son 4 bytes mas.

**3. La geometria no cambiaba.**
Reduje el texto a 7 celdas pero deje los laterales en `dX=-72` y `dX=+48`,
que es la separacion de 8 celdas. El marco seguia midiendo 136-144 px, tal
como midio David.

  -> Los laterales van pegados al texto: `dX = -8 - 16*ncel/2` y el derecho
     justo detras de la ultima celda.

LA GEOMETRIA REAL DE LA v225 (la compartida, que NO se toca)
============================================================
```
30 registros, 3 filas de 16 px, terminador $FF en 0x47C98

fila 1  dY=20   1C4..1CB (8 celdas)  + 1DC en dX=-72 y dX=+56
fila 2  dY=36   1CC..1D3 (8 celdas)  + 1A0/1A1
fila 3  dY=52   1D4..1DB (8 celdas)  + 1DD en dX=-72 y dX=+56
```
Ancho: de dX=-72 a dX=+71 = **144 px**. 10 ranuras por fila.

LA NUEVA DEL ABUELO: 14x2
=========================
```
fila 1  dY=20   1C4..1CA (7 celdas)  + laterales
fila 2  dY=36   1CB..1D1 (7 celdas)  + laterales
```
7 celdas = 112 px de texto. Con los dos laterales de 16: **144-32 = 128 px**.
Ancho de dX=-64 a dX=+63 = **128 px**, 16 menos que la compartida.
9 ranuras por fila (7 + 2 laterales).

Y sobre todo: **2 filas en vez de 3**. Acaba en dY=36+15=51 en vez de 67,
que es lo que la saca de la franja de los ogros.

Uso:  python3 tools/build_v227.py
"""
import hashlib
import zlib
import struct
import subprocess
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v225.pce'
SALIDA = 'roms/momotaro_es_v227.pce'
IPS = 'parches/momotaro_v227.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'a1ecc337b9bb1e4f5c5b44dcad45744e'

BASE_PATRON = 0x170
LISTA = 0x47C02                 # la compartida: NO SE TOCA
TERMINADOR = 0x47C98            # el $FF que la cierra: NO SE TOCA
HUECO = 0x47C99                 # 871 B libres, DESPUES del terminador
GLACIAR = 0x430C1

PTR_LO = 0x41AA0                # operando del $9A9F LDA #$02
PTR_HI = 0x41AA4                # operando del      LDA #$7C

# el rabillo: David lo quiere 1 px abajo y 10 px a la izquierda
RAB_DX_DELTA = -10
RAB_DY_DELTA = +1


def rota_izq(celda):
    w = struct.unpack('<64H', celda)
    src = [[0] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            b = 15 - x
            src[y][x] = ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
                | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)
    dst = [[0] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            dst[15 - x][y] = src[y][x]
    out = [0] * 64
    for y in range(16):
        for x in range(16):
            b = 15 - x
            v = dst[y][x]
            for pl in range(4):
                if v & (1 << pl):
                    out[pl * 16 + y] |= (1 << b)
    return struct.pack('<64H', *out)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v225'
    print('base %s  OK  (se revierte la v226 entera)' % BASE)

    # ==================================================================
    # 0. el terminador de la compartida es SAGRADO
    # ==================================================================
    assert rom[TERMINADOR] == 0xFF, \
        'en 0x%05X no esta el terminador de la lista compartida' % TERMINADOR
    n_comp = (TERMINADOR - LISTA) // 5
    assert n_comp == 30, 'la lista compartida no tiene 30 registros'
    print('lista compartida: %d registros, terminador en 0x%05X'
          % (n_comp, TERMINADOR))

    # ==================================================================
    # 1. "Glaciar" -> "Glacial"
    # ==================================================================
    assert bytes(rom[0x430BC:0x430C2]) == bytes([0xAC, 0xA1, 0xA3, 0xA9,
                                                 0xA1, 0xB2]), \
        'en 0x430BC no pone "laciar"'
    rom[GLACIAR] = 0xAC
    print('\n1. "Glaciar" -> "Glacial"')

    # ==================================================================
    # 2. el rabillo: rotado, y movido como pide David
    # ==================================================================
    ptr = rom[0x41C3D] | (rom[0x41C41] << 8)
    cnt = rom[0x41C4F] | (rom[0x41C50] << 8)
    CG = 0x3C000 + (ptr - 0x4000)
    CN = 0x3C000 + (cnt - 0x4000)
    n = rom[CN]
    f = Flujo(bytes(rom), CG)
    celdas = [b''.join(tile(f) for _ in range(4)) for _ in range(n)]
    fin = f.p
    prim = (rom[0x41C45] | (rom[0x41C4A] << 8)) // 64
    celdas[0x1AF - prim] = rota_izq(celdas[0x1AD - prim])
    print('\n2. rabillo: celda 1AD rotada 90 a la izquierda -> 1AF')

    stream = comprime(b''.join(celdas))
    hueco_cg = fin - CG
    if len(stream) > hueco_cg:
        extra = len(stream) - hueco_cg
        libre = 0
        o = CN - 1
        while rom[o] == 0xFF:
            libre += 1
            o -= 1
        assert libre >= extra + 8, 'no hay relleno delante del CG'
        nuevo_cg = CG - extra
        nueva_cnt = nuevo_cg - 1
        assert all(b == 0xFF for b in rom[nueva_cnt:CN]), 'zona ocupada'
        rom[nueva_cnt] = n
        rom[nuevo_cg:nuevo_cg + len(stream)] = stream
        pn = 0x4000 + (nuevo_cg - 0x3C000)
        cn2 = 0x4000 + (nueva_cnt - 0x3C000)
        rom[0x41C3D] = pn & 0xFF
        rom[0x41C41] = pn >> 8
        rom[0x41C4F] = cn2 & 0xFF
        rom[0x41C50] = cn2 >> 8
        print('   CG %d B (+%d): stream movido a 0x%05X, puntero $%04X'
              % (len(stream), extra, nuevo_cg, pn))
        CG = nuevo_cg
    else:
        rom[CG:CG + len(stream)] = stream
        rom[CG + len(stream):fin] = b'\xFF' * (hueco_cg - len(stream))
        print('   CG %d B (hueco %d)' % (len(stream), hueco_cg))

    f2 = Flujo(bytes(rom), CG)
    assert [b''.join(tile(f2) for _ in range(4))
            for _ in range(n)] == celdas, 'round-trip del CG'
    print('   round-trip: OK')

    # la variante 2 del rabillo, movida
    RAB = 0x41ADD
    p2 = rom[RAB + 4] | (rom[RAB + 5] << 8)
    o2 = 0x40000 + (p2 - 0x8000)
    dx = rom[o2 + 3] - 256 if rom[o2 + 3] > 127 else rom[o2 + 3]
    dy = rom[o2 + 4] - 256 if rom[o2 + 4] > 127 else rom[o2 + 4]
    ndx, ndy = dx + RAB_DX_DELTA, dy + RAB_DY_DELTA
    rom[o2 + 3] = ndx & 0xFF
    rom[o2 + 4] = ndy & 0xFF
    print('   variante 2: dX %d -> %d,  dY %d -> %d' % (dx, ndx, dy, ndy))

    # ==================================================================
    # 3. la lista del abuelo, 14x2, DESPUES del terminador
    # ==================================================================
    COLS, LINEAS = 14, 2
    ncel = COLS // 2                     # 7 celdas de 16 px
    # OJO CON LA CUENTA (me equivoque en la v226):
    #   ancho total = (ncel + 2 laterales) * 16
    #   con ncel=7  ->  9*16 = 144 px   = LO MISMO QUE LA COMPARTIDA
    #   con ncel=6  ->  8*16 = 128 px
    # La compartida tiene ncel=8 y dos laterales = 10*16 = 160? No:
    # sus laterales estan en dX=-72 y +56, o sea SOLAPANDO 8 px con el
    # texto (-64..63). Ancho real 144 = 9 celdas de ancho efectivo.
    # Para bajar de verdad hay que quitar CELDAS DE TEXTO.
    X_TEXTO = -(ncel * 16) // 2          # texto centrado en el ancla
    filas = [[0x1C4 + li * ncel + k for k in range(ncel)]
             for li in range(LINEAS)]
    LAT = {0: (0x1DC, 0x00), 1: (0x1A0, 0x00)}
    LAT_D = {0: (0x1DC, 0x08), 1: (0x1A1, 0x00)}

    regs = bytearray()
    nsp = 0
    for li in range(LINEAS):
        dY = 20 + li * 16
        for k, c in enumerate(filas[li]):
            regs += bytes([c - BASE_PATRON, 0x0F, 0x00,
                           (X_TEXTO + k * 16) & 0xFF, dY & 0xFF])
            nsp += 1
        # Los laterales van PEGADOS al texto. En la v226 los deje en
        # dX=-72/+56 (la separacion de 8 celdas) y por eso el marco seguia
        # midiendo 144 px: David lo midio y no habia cambiado nada.
        # Los laterales, como en la compartida: 8 px por fuera del texto.
        # (En la v226 los deje en -72/+56, la separacion de 8 celdas, y por
        #  eso el marco seguia midiendo 144 px. David lo midio.)
        ci, fi = LAT[li]
        regs += bytes([ci - BASE_PATRON, 0x0F, fi,
                       (X_TEXTO - 8) & 0xFF, dY & 0xFF])
        cd, fd = LAT_D[li]
        regs += bytes([cd - BASE_PATRON, 0x0F, fd,
                       (X_TEXTO + ncel * 16 - 8) & 0xFF, dY & 0xFF])
        nsp += 2
    regs += b'\xFF'

    ancho = 8 + ncel * 16 + 8
    print('\n3. lista del abuelo: %d sprites, %d filas x %d celdas'
          % (nsp, LINEAS, ncel))
    print('   ancho %d px (la compartida mide 144), %d ranuras por fila'
          % (ancho, ncel + 2))
    print('   dX de %d a %d ; dY de 20 a %d'
          % (X_TEXTO - 16, X_TEXTO + ncel * 16 + 15, 20 + (LINEAS - 1) * 16))

    libre = 0
    while HUECO + libre < 0x48000 and rom[HUECO + libre] == 0xFF:
        libre += 1
    print('   hueco tras el terminador: 0x%05X, %d B' % (HUECO, libre))

    TABLA = HUECO
    LISTA_AB = HUECO + 8
    assert 8 + len(regs) <= libre, 'no cabe'
    p_comp = 0x7C02
    p_ab = 0x6000 + (LISTA_AB - 0x46000)
    p_tabla = 0x6000 + (TABLA - 0x46000)
    for k, p in enumerate([p_comp, p_comp, p_ab, p_comp]):
        rom[TABLA + k * 2] = p & 0xFF
        rom[TABLA + k * 2 + 1] = p >> 8
    rom[LISTA_AB:LISTA_AB + len(regs)] = regs
    print('   tabla en $%04X, lista en $%04X (%d B)'
          % (p_tabla, p_ab, len(regs)))

    # ==================================================================
    # 4. el selector: RECALCULA Y, porque $E3EB la machaca
    # ==================================================================
    assert rom[PTR_LO - 1] == 0xA9 and rom[PTR_LO] == 0x02, 'emisor raro'
    assert rom[PTR_HI - 1] == 0xA9 and rom[PTR_HI] == 0x7C, 'emisor raro'
    SEL = 0x1FA0
    while rom[SEL] != 0xFF:
        SEL += 1
    sel_addr = 0xE000 + SEL
    selector = bytes([
        0xAD, 0x8F, 0x36,                                  # LDA $368F
        0x0A,                                              # ASL A
        0xA8,                                              # TAY
        0xB9, p_tabla & 0xFF, p_tabla >> 8,                # LDA tabla,Y
        0x85, 0x53,                                        # STA $53
        0xB9, (p_tabla + 1) & 0xFF, (p_tabla + 1) >> 8,    # LDA tabla+1,Y
        0x85, 0x54,                                        # STA $54
        0x60,                                              # RTS
    ])
    libre_sel = 0
    while SEL + libre_sel < 0x1FE0 and rom[SEL + libre_sel] == 0xFF:
        libre_sel += 1
    assert len(selector) <= libre_sel, 'no cabe el selector'
    rom[SEL:SEL + len(selector)] = selector
    rom[PTR_LO - 1] = 0x20
    rom[PTR_LO] = sel_addr & 0xFF
    rom[PTR_LO + 1] = sel_addr >> 8
    for k in range(3, 8):
        rom[PTR_LO - 1 + k] = 0xEA
    print('\n4. selector de %d B en $%04X (ROM 0x%05X)'
          % (len(selector), sel_addr, SEL))
    print('   RELEE $368F: la Y de $9A87 la mata el JSR $E3EB de $9A92')
    print('   $9A9F  LDA #$02/... -> JSR $%04X + 5 NOP' % sel_addr)

    # ==================================================================
    # verificacion
    # ==================================================================
    tmp = '/tmp/_v227.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM')
    for off, nb, carga, nom in [(0x41A9B, 16, 0x9A9B, 'emisor'),
                                (SEL, len(selector), sel_addr, 'selector')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % off,
                            str(nb), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    print('\n--- la lista COMPARTIDA sigue intacta y terminada')
    assert bytes(rom[LISTA:TERMINADOR + 1]) == base[LISTA:TERMINADOR + 1], \
        'SE HA TOCADO LA LISTA COMPARTIDA'
    print('    30 registros + $FF en 0x%05X: intactos' % TERMINADOR)

    print('\n--- lista del abuelo, releida de la ROM')
    i = LISTA_AB
    k = 0
    while rom[i] != 0xFF:
        b = rom[i:i + 5]
        dX = b[3] - 256 if b[3] > 127 else b[3]
        dY = b[4] - 256 if b[4] > 127 else b[4]
        print('    [%2d] celda %03X  dX=%4d  dY=%3d  flags=%02X'
              % (k, BASE_PATRON + b[0], dX, dY, b[2]))
        i += 5
        k += 1
    print('    terminador $FF en 0x%05X' % i)

    intactas = [
        ('lista compartida', LISTA, TERMINADOR + 1),
        ('fuente', 0x3D660, 0x3E200),
        ('cabecera y vectores', 0x1FE0, 0x2000),
        ('guion', 0x48F91, 0x4A484),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    print('%d bytes sobre la v225'
          % sum(1 for i in range(len(d)) if d[i] != base[i]))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
