#!/usr/bin/env python3
"""
build_v201.py - los tres ajustes que pidio David sobre la v200:

  (A) el bocadillo del abuelo, 1 px mas a la izquierda
  (B) el nordo mutilado bajo el abuelo (minijuego oculto)
  (C) [no aqui] el cuadro verde: va en la v202, es una mudanza de VRAM

LO QUE DICE DAVID
-----------------
> «Veo que el bocadillo aun hay que moverlo 1 px a la izquierda, y justo
>  debajo del abuelo sale un nordo mutilado.»

=====================================================================
(A) EL PIXEL QUE FALTABA
=====================================================================
Medido en la captura de David (`...072937.png`), el trazo del bocadillo
esta en x=65 y x=208, o sea cuerpo de 65 a 208. Con un pixel mas a la
izquierda queda 64..207, que es multiplo de 8 y cuadra con el rabillo.

    $88B1  SBC #$5F  ->  SBC #$60
    rabillo variante 2: dX 70 -> 71   (para que NO se mueva)

=====================================================================
(B) EL NORDO MUTILADO: la causa, medida
=====================================================================
Del state `Abuelo final minijuego 1` (que ES de la v200):

    sprite 49, celda 0F8 (el nordo), y=73..88
    pierde las filas 79..87  -> 9 filas, justo lo que se ve en la captura

Y el reparto de ranuras lo explica entero:

```
scan 72..78   11/16   fila de texto inferior (10) + nordo (1)
scan 79..87   20/16   fila de texto (10) + BORDE INFERIOR (8) + nordo (1)
scan 88       10/16
```

**El borde inferior solapa 9 px con la ultima fila de texto.** Viene de la
v193: el borde va en `dY=51` mientras la fila de texto ocupa `dY=44..59`.
Se hizo asi a proposito (norma 147: el dibujo del borde esta al FONDO de la
celda, en las filas 9..15, para que el solape no se vea). Pero **la norma
147 solo dice que no se VE; la ranura se gasta igual** (norma 166). En esas
9 scanlines el bocadillo pide 18 ranuras el solo.

EL ARREGLO
----------
Quitar el solape sin mover el marco: se **sube el dibujo 9 filas dentro de
la celda** (de las filas 9..15 a las 0..6) y se **baja el sprite 9 px**
(`dY 51 -> 60`). El resultado en pantalla es identico al pixel, pero las
scanlines 79..87 pasan de 20 a 11 ranuras.

Verificado con el simulador sobre el state real: **LIMPIO**, el nordo sale
entero.

Las celdas `19E/19F/1AE` son exclusivas del bocadillo (comprobado en los 22
volcados: nadie mas las referencia), asi que tocar su CG no afecta a nada.

Uso:  python3 tools/build_v201.py
"""
import hashlib
import zlib
import struct
import subprocess
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v200.pce'
SALIDA = 'roms/momotaro_es_v201.pce'
IPS = 'parches/momotaro_v201.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'e59dc57f5dc96febf98bd7b386e13e1d'

ABUELO_X = 0x168B2              # operando del $88B1 SBC #$5F
RAB2_DX = 0x41AF4               # dX de la variante 2

# El puntero del CG se MUEVE en cada reconstruccion. No se pone a mano: se
# lee del propio codigo de $9C32, que es quien lo carga.
#   $9C3C LDA #$04 / STA $14 / LDA #$54 / STA $15   -> puntero $5404
#   $9C4E LDX $5403                                 -> cuenta de celdas
# Banco $1E mapeado en MPR4 ($8000): ROM = 0x3C000 + (dir - 0x4000)
PTR_LO = 0x41C3D                # operando del LDA #$04
PTR_HI = 0x41C41                # operando del LDA #$54
CNT_ADDR = 0x41C4F              # operando (word) del LDX $5403
LISTA = 0x47C02
BORDE_CELDAS = {0x19E, 0x19F, 0x1AE}
SUBIR = 9                       # filas que sube el dibujo dentro de la celda


def sube(celda, n):
    """Sube n filas el dibujo dentro de una celda de 128 B (4 planos)."""
    w = list(struct.unpack('<64H', celda))
    out = []
    for pl in range(4):
        filas = w[pl * 16:(pl + 1) * 16]
        out += filas[n:] + [0] * n
    return struct.pack('<64H', *out)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v200'
    print('base %s  OK' % BASE)

    # ==================================================================
    # (A) 1 px a la izquierda
    # ==================================================================
    assert rom[ABUELO_X - 1] == 0xE9 and rom[ABUELO_X] == 0x5F, \
        'en $88B1 no esta el SBC #$5F: %s' % bytes(
            rom[ABUELO_X - 1:ABUELO_X + 1]).hex()
    assert rom[RAB2_DX] == 70, 'el dX del rabillo no es 70'
    rom[ABUELO_X] = 0x60
    rom[RAB2_DX] = 71
    print('\n(A) $88B1 SBC #$5F -> SBC #$60   (1 px mas a la izquierda)')
    print('    rabillo variante 2: dX 70 -> 71  (asi NO se mueve)')

    # ==================================================================
    # (B) el solape del borde inferior
    # ==================================================================
    # 1. la lista de sprites: dY 51 -> 60 en las 8 entradas del borde
    n = 0
    for k in range(36):
        o = LISTA + k * 5
        celda = 0x170 + rom[o]
        if celda in BORDE_CELDAS:
            assert rom[o + 4] == 51, \
                'la entrada %d no tiene dY=51 sino %d' % (k, rom[o + 4])
            rom[o + 4] = 51 + SUBIR
            n += 1
    assert n == 8, 'esperaba 8 entradas de borde inferior, hay %d' % n
    print('\n(B) lista de sprites: %d entradas del borde, dY 51 -> %d'
          % (n, 51 + SUBIR))

    # 2. el CG: subir el dibujo 9 filas en 19E/19F/1AE
    #    El puntero se LEE del codigo de $9C32, no se escribe a mano.
    assert rom[PTR_LO - 1] == 0xA9 and rom[PTR_HI - 1] == 0xA9, \
        'el cargador $9C3C no tiene la forma esperada'
    ptr = rom[PTR_LO] | (rom[PTR_HI] << 8)
    cnt = rom[CNT_ADDR] | (rom[CNT_ADDR + 1] << 8)
    assert rom[CNT_ADDR - 1] == 0xAE, 'en $9C4E no hay un LDX abs'
    BANCO_1E = 0x3C000
    CG = BANCO_1E + (ptr - 0x4000)
    cuenta = BANCO_1E + (cnt - 0x4000)
    print('\n    puntero del CG   $%04X -> ROM 0x%05X' % (ptr, CG))
    print('    cuenta de celdas $%04X -> ROM 0x%05X = %d'
          % (cnt, cuenta, rom[cuenta]))
    assert rom[cuenta] == 20, 'la cuenta no es 20 sino %d' % rom[cuenta]
    assert cuenta + 1 == CG, 'la cuenta no esta justo delante del stream'

    f = Flujo(bytes(rom), CG)
    celdas = []
    for k in range(20):
        celdas.append(b''.join(tile(f) for _ in range(4)))
    fin = f.p
    print('    CG: 20 celdas, stream 0x%05X..0x%05X (%d B)'
          % (CG, fin, fin - CG))

    # round-trip antes de tocar nada
    f2 = Flujo(bytes(rom), CG)
    for k in range(20):
        assert b''.join(tile(f2) for _ in range(4)) == celdas[k], \
            'el round-trip falla en la celda %d' % k

    tocadas = 0
    for k in range(20):
        celda = 0x19C + k
        if celda in BORDE_CELDAS:
            antes = celdas[k]
            celdas[k] = sube(antes, SUBIR)
            # comprobar que el dibujo estaba abajo y ahora esta arriba
            w0 = struct.unpack('<64H', antes)
            w1 = struct.unpack('<64H', celdas[k])
            f0 = [y for y in range(16)
                  if w0[y] | w0[16 + y] | w0[32 + y] | w0[48 + y]]
            f1 = [y for y in range(16)
                  if w1[y] | w1[16 + y] | w1[32 + y] | w1[48 + y]]
            assert min(f0) == SUBIR, \
                'la celda %03X no tiene el dibujo en la fila %d' % (
                    celda, SUBIR)
            assert min(f1) == 0, 'la celda %03X no ha subido' % celda
            print('    celda %03X: dibujo filas %d..%d -> %d..%d'
                  % (celda, min(f0), max(f0), min(f1), max(f1)))
            tocadas += 1
    assert tocadas == 3, 'esperaba 3 celdas de borde, he tocado %d' % tocadas

    # comprime() espera los tiles CONCATENADOS (multiplo de 32), no una
    # lista de celdas: pasarle la lista devuelve 0 bytes en silencio.
    nuevo = comprime(b''.join(celdas))
    hueco = fin - CG
    print('    CG recomprimido: %d B (hueco original %d)'
          % (len(nuevo), hueco))

    # Al subir el dibujo, las filas de ceros quedan ABAJO y el compresor
    # ya no las puede fundir con el ultimo literal: el stream crece 12 B.
    # Detras esta la FUENTE (0x3D660), asi que no se puede alargar hacia
    # delante. Pero DELANTE hay relleno $FF: se desplaza el stream hacia
    # atras y se repunta el cargador, que es justo para lo que el juego
    # tiene el puntero en $9C3C y la cuenta en $9C4E.
    if len(nuevo) > hueco:
        extra = len(nuevo) - hueco
        libre = 0
        o = cuenta - 1
        while rom[o] == 0xFF:
            libre += 1
            o -= 1
        assert libre >= extra + 1, \
            'no hay relleno delante: hacen falta %d B y hay %d' % (
                extra + 1, libre)
        print('    hacen falta %d B mas; hay %d B de relleno $FF delante'
              % (extra, libre))
        nuevo_cg = CG - extra
        nueva_cuenta = nuevo_cg - 1
        # comprobar que la zona de la que nos apropiamos es TODO $FF
        # la zona nueva va de nueva_cuenta a cuenta-1 (el byte 'cuenta'
        # es el 0x14 viejo, que se reescribe con el stream)
        assert all(b == 0xFF for b in rom[nueva_cuenta:cuenta]), \
            'la zona que voy a ocupar no esta libre: %s' % bytes(
                rom[nueva_cuenta:cuenta]).hex()
        # No se compara con la VIRGEN: ahi el CG del bocadillo vivia en
        # otro sitio (la cuenta estaba en 0x3D400) y el reparto de esta
        # zona ya cambio en versiones anteriores. Lo que hay que garantizar
        # es que en la ROM DE PARTIDA la zona esta libre, y que por delante
        # sigue habiendo margen hasta el ultimo dato real.
        ultimo = nueva_cuenta - 1
        while rom[ultimo] in (0xFF, 0x00):
            ultimo -= 1
        print('    ultimo byte con datos por delante: ROM 0x%05X (%02X), '
              'quedan %d B de margen'
              % (ultimo, rom[ultimo], nueva_cuenta - ultimo - 1))
        assert nueva_cuenta - ultimo - 1 >= 8, \
            'me quedo pegado al dato anterior'
        rom[nueva_cuenta] = 20
        rom[nuevo_cg:nuevo_cg + len(nuevo)] = nuevo
        # repuntar el cargador
        ptr_nuevo = 0x4000 + (nuevo_cg - BANCO_1E)
        cnt_nuevo = 0x4000 + (nueva_cuenta - BANCO_1E)
        rom[PTR_LO] = ptr_nuevo & 0xFF
        rom[PTR_HI] = ptr_nuevo >> 8
        rom[CNT_ADDR] = cnt_nuevo & 0xFF
        rom[CNT_ADDR + 1] = cnt_nuevo >> 8
        print('    stream movido a ROM 0x%05X, puntero $%04X -> $%04X'
              % (nuevo_cg, ptr, ptr_nuevo))
        print('    cuenta movida a  ROM 0x%05X, $%04X -> $%04X'
              % (nueva_cuenta, cnt, cnt_nuevo))
        CG = nuevo_cg
        assert CG + len(nuevo) == fin, 'el final del stream no cuadra'
    else:
        rom[CG:CG + len(nuevo)] = nuevo
        if len(nuevo) < hueco:
            rom[CG + len(nuevo):fin] = b'\x00' * (hueco - len(nuevo))

    # round-trip DESPUES de escribir, desde la ROM
    f3 = Flujo(bytes(rom), CG)
    for k in range(20):
        leido = b''.join(tile(f3) for _ in range(4))
        assert leido == celdas[k], \
            'el round-trip falla tras escribir, celda %03X' % (0x19C + k)
    print('    round-trip de las 20 celdas tras escribir: OK')

    # ==================================================================
    # verificacion
    # ==================================================================
    tmp = '/tmp/_v201.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM construida')
    r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '168AD', '10',
                        '88AD'], capture_output=True, text=True)
    for l in r.stdout.strip().split('\n'):
        print('    ' + l)

    print('\n--- lista de sprites, filas del borde inferior')
    for k in range(28, 36):
        o = LISTA + k * 5
        print('    celda %03X  dX=%4d  dY=%d'
              % (0x170 + rom[o],
                 rom[o + 3] - 256 if rom[o + 3] > 127 else rom[o + 3],
                 rom[o + 4]))

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('rutina de recorte $FF6B', 0x1F6B, 0x1FE0),
        ('fuente', 0x3D660, 0x3E200),
        ('cabecera y vectores', 0x1FE0, 0x2000),
        ('descompresor', 0x4B93B, 0x4BF40),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v200' % len(dif))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
