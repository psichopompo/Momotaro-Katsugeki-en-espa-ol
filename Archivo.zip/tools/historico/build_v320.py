#!/usr/bin/env python3
"""build_v320.py - REVIERTE la tabla B, que rompi en la v318.

EL ERROR
--------
En la v318 escribi que la tabla `0x4379D` era «el rotulo AL VIAJAR» y la
repunte a mis nombres cortos del banco `$21`. **Falso.** Es la tabla de los
**ROTULOS DE ALDEA** — los del mapa y los de la entrada a cada aldea — y
apuntaba a textos que **ya estaban traducidos** desde hace muchas
versiones, en el banco `$0F`.

Al repuntarla, David vio «Bambu» a secas en el mapa y al entrar, y
**«Aldea» desaparecio de todos los rotulos del juego**.

Volvi a incumplir la norma 288 — la que yo mismo escribi tras la v237:
identifique la tabla por su lector sin comprobar el CONTENIDO apuntado.

QUE SI HABIA QUE TRADUCIR
-------------------------
La tabla A (`0x43712`) [4..13] apuntaba a japones y es el **menu de
destinos** del teletransporte, donde la ventana mide 8 celdas. Esa se
queda como esta: los nombres cortos ahi son obligatorios.

«Bambu» -> «Taketori»
---------------------
David: el rotulo dice «Aldea Bambu» pero la aldeana dice «la aldea de
Taketori». Los demas rotulos usan el nombre propio (Urashima, Kachiyama,
Issunboshi, Kintaro), asi que lo coherente es **«Aldea Taketori»**.

Como los rotulos van PEGADOS y «Taketori» son 3 B mas que «Bambu», se
reescribe el bloque entero `0x1F89C..0x1F900` (92 B usados + 8 de hueco
contiguo = 100 disponibles, 95 necesarios) y se repuntan las 6 entradas
correspondientes de la tabla B.

TRES CHARSETS DISTINTOS
-----------------------
Los rotulos usan `charset_rotulos` (motor `$AAB4`: alias b/c **y ademas**
e=$3D, o=$62), no el de tienda. El assert de byte esperado lo cazo al
primer intento.
"""
import hashlib
import struct
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode as encode_tienda, RELLENO   # noqa: E402
from charset_rotulos import encode as encode_rot               # noqa: E402

BASE = 'roms/momotaro_es_v319.pce'
REF = 'roms/momotaro_es_v317.pce'
SALIDA = 'roms/momotaro_es_v320.pce'
MD5_BASE = '8e8fbe16b6d078f1ca159a36a8a0971e'
MD5_REF = 'ed42393598926fe107e11a6121c32099'

TABLA_A = 0x43712
TABLA_B = 0x4379D
ROT_INI, ROT_FIN = 0x1F89C, 0x1F900
DESTINO_BAMBU = 0x43782

# los 6 rotulos que viven en 0x1F89C (los otros 3 estan en 0x1E25B)
NOMBRES = ['Aldea Dormilón', 'Aldea Urashima', 'Aldea Kachiyama',
           'Aldea Issunboshi', 'Aldea Taketori', 'Isla Ogros']

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x1E000, 0x1F800, 'banco $0F: tabla de escenas y rotulos 0-2'),
    (0x1F900, 0x20000, 'banco $0F: passwords y resto'),
    (0x48000, 0x4A000, 'banco $24'),
    (0x4AC80, 0x4AD60, 'los dados de la v319'),
    (0x4AEE6, 0x4C000, 'el QUIZ'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    ref = open(REF, 'rb').read()
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v319'
    assert hashlib.md5(ref).hexdigest() == MD5_REF, 'la referencia no es la v317'

    # ---------- 0. el charset de rotulos reproduce lo ya validado --------
    for off, txt in ((0x1E25C, 'Aldea de la Partida'),
                     (0x1E271, 'Aldea Florecer'),
                     (0x1E281, 'Aldea Kintaro'),
                     (0x1F89E, 'Aldea Dormilón'),
                     (0x1F8AE, 'Aldea Urashima'),
                     (0x1F8BE, 'Aldea Kachiyama'),
                     (0x1F8CF, 'Aldea Issunboshi'),
                     (0x1F8E1, 'Aldea Bambú'),
                     (0x1F8EE, 'Isla Ogros')):
        e = encode_rot(txt)
        assert rom[off:off + len(e)] == e, \
            'el charset de rotulos no reproduce «%s»' % txt

    # ---------- 1. revertir la tabla B -----------------------------------
    buena = bytearray(ref[TABLA_B:TABLA_B + 18])
    assert bytes(buena) != bytes(rom[TABLA_B:TABLA_B + 18]), 'la tabla B ya esta bien'
    for i in range(9):
        p = struct.unpack('<H', buena[i * 2:i * 2 + 2])[0]
        o = 0x1E000 + p - 0x4000
        assert 0x1E000 <= o < 0x20000, 'puntero %d fuera del banco $0F' % i
        assert ref[o] == 0x01, 'el rotulo %d no empieza por $01' % i

    # ---------- 2. reescribir el bloque de rotulos con «Taketori» --------
    p = ROT_INI
    for _ in range(6):
        e = rom.find(b'\xff', p)
        assert 0 < e - p < 40, 'rotulo sin terminador en %06X' % p
        p = e + 1
    assert p == 0x1F8F9, 'el bloque no acaba donde creo: %06X' % p
    assert all(b == 0xFF for b in rom[0x1F8F9:ROT_FIN]), \
        'el hueco contiguo no es relleno limpio'

    bloque = bytearray()
    nuevos = []
    for n in NOMBRES:
        nuevos.append(ROT_INI + len(bloque))
        bloque += b'\x01' + encode_rot(n) + b'\xff'
    assert len(bloque) <= ROT_FIN - ROT_INI, \
        'los rotulos ocupan %d B y hay %d' % (len(bloque), ROT_FIN - ROT_INI)
    rom[ROT_INI:ROT_FIN] = bytes(bloque) + b'\xff' * (ROT_FIN - ROT_INI - len(bloque))

    # repuntar las 6 entradas [3..8] de la tabla B
    for i, o in enumerate(nuevos):
        idx = 3 + i
        struct.pack_into('<H', buena, idx * 2, 0x4000 + (o - 0x1E000))
    rom[TABLA_B:TABLA_B + 18] = bytes(buena)
    # los 3 primeros no se tocan: apuntan a 0x1E25B/0x1E270/0x1E280
    for i, esp in enumerate((0x425B, 0x4270, 0x4280)):
        v = struct.unpack('<H', rom[TABLA_B + i * 2:TABLA_B + i * 2 + 2])[0]
        assert v == esp, 'el puntero %d se ha movido: $%04X' % (i, v)

    # ---------- 3. el destino del menu: «Bambú» -> «Taketori» ------------
    vd = encode_tienda('Bambú')
    e = rom.find(b'\xff', DESTINO_BAMBU)
    assert rom[DESTINO_BAMBU] == 0x01, 'el destino no empieza por $01'
    assert bytes(rom[DESTINO_BAMBU + 1:e]) == vd, 'en el destino no esta «Bambú»'
    nd = encode_tienda('Taketori')
    assert len(nd) <= 8, 'el destino se pasa de 8 celdas'
    desplaz = len(nd) - len(vd)
    # OJO: la TABLA B esta en 0x4379D. La cola NO puede llegar hasta alli o
    # la arrastra y corrompe los punteros.  Solo se mueve hasta el relleno.
    LIMITE = TABLA_B
    cola = bytes(rom[e:LIMITE])               # $FF + «Ogros» + «Jizo» + relleno
    ini = DESTINO_BAMBU + 1 + len(nd)
    assert ini + len(cola) - desplaz <= LIMITE, 'la cola no cabe'
    # el relleno del final absorbe el desplazamiento
    assert all(b == RELLENO for b in rom[LIMITE - desplaz:LIMITE]), \
        'no hay %d B de relleno antes de la tabla B' % desplaz
    rom[DESTINO_BAMBU + 1:DESTINO_BAMBU + 1 + len(nd)] = nd
    rom[ini:ini + len(cola) - desplaz] = cola[:len(cola) - desplaz]
    # las entradas posteriores de la tabla A se desplazan
    for idx in (12, 13):
        pp = TABLA_A + idx * 2
        v = struct.unpack('<H', rom[pp:pp + 2])[0]
        rom[pp:pp + 2] = struct.pack('<H', v + desplaz)

    # ---------- VERIFICACION ---------------------------------------------
    assert len(rom) == 524288, 'la ROM cambio de tamanyo'

    # los 9 rotulos, siguiendo la tabla B
    esperados = ['Aldea de la Partida', 'Aldea Florecer', 'Aldea Kintaro'] + NOMBRES
    for i, txt in enumerate(esperados):
        p = struct.unpack('<H', rom[TABLA_B + i * 2:TABLA_B + i * 2 + 2])[0]
        o = 0x1E000 + p - 0x4000
        e = rom.find(b'\xff', o)
        assert rom[o] == 0x01, 'rotulo %d sin comando' % i
        assert bytes(rom[o + 1:e]) == encode_rot(txt), \
            'rotulo %d releido no es «%s»' % (i, txt)

    # la tabla A sigue resolviendo dentro del banco $21
    for i in range(14):
        p = struct.unpack('<H', rom[TABLA_A + i * 2:TABLA_A + i * 2 + 2])[0]
        assert 0xA000 <= p < 0xC000, 'tabla A[%d] fuera de ventana' % i
        o = 0x42000 + p - 0xA000
        assert rom[o] in (0x01, 0x02), 'tabla A[%d] no apunta a comando' % i

    # los 10 destinos siguen legibles y «Taketori» esta
    dest = []
    for i in range(4, 14):
        p = struct.unpack('<H', rom[TABLA_A + i * 2:TABLA_A + i * 2 + 2])[0]
        o = 0x42000 + p - 0xA000
        e = rom.find(b'\xff', o)
        dest.append(bytes(rom[o + 1:e]))
    assert encode_tienda('Taketori') in dest, 'el destino «Taketori» no aparece'
    assert encode_tienda('Bambú') not in dest, 'sigue el destino «Bambú»'
    assert encode_rot('Bambú') not in bytes(rom), 'queda un «Bambú» de rotulo'

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  ROTULOS (tabla B revertida y repuntada):')
    for i, txt in enumerate(esperados):
        p = struct.unpack('<H', rom[TABLA_B + i * 2:TABLA_B + i * 2 + 2])[0]
        print('    [%d] $%04X -> %06X  «%s»'
              % (i, p, 0x1E000 + p - 0x4000, txt))
    print()
    print('  DESTINO del menu: «Bambú» -> «Taketori»')


if __name__ == '__main__':
    main()
