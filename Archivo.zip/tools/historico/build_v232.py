#!/usr/bin/env python3
"""
build_v232.py - los 23 textos del abuelo, traducidos.

Sobre la v231 (bocadillo 14x2 ya validado por David).

EL FORMATO, MEDIDO
==================
Tabla `$C969` -> ROM `0x16969`, 23 punteros de 2 B al banco `$24`
(`ROM = 0x48000-0x4000 + puntero`). Los lee `$88DB`:

```
$88DB  LDA $363E / ASL A / TAY / LDA $C969,Y -> $92 ; LDA $C96A,Y -> $93
```

**El separador de linea es `$A0`, no `$3B`.** Volcado de los originales:

```
[0]  b6 d7 de c0 c9 | a0 a0 | 5c b5 c6 de b7 d8 5c a6 | a0 | c3 c6 | a0 | b2 da c0
     ｶ ﾗ ﾞ ﾀ ﾉ        \ ｵ ﾆ ﾞ ｷ ﾘ \ ｦ                    ﾃ ﾆ         ｲ ﾚ ﾀ
     "karada no"   ""   "onigiri wo"   "te ni"   "ireta"
```

Son las columnas del bocadillo VERTICAL japones original: por eso hay
tantas y son tan cortas. Los `$A0` sobrantes al final son relleno.

REGLA QUE ME IMPONGO
--------------------
Despues de tres versiones rompiendo cosas, aqui **no invento formato**: se
respeta el numero de lineas que ya tiene cada texto y solo se sustituye el
contenido. Si la traduccion necesita menos lineas, el resto se rellena con
`$A0`, exactamente como hace el original.

Cada texto se maqueta a **14 columnas** (el ancho nuevo) y se comprueba que
no pasa de 2 lineas visibles.

Uso:  python3 tools/build_v232.py
"""
import hashlib
import zlib
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from charset_oficial import CHAR_TO_CODE

BASE = 'roms/momotaro_es_v231.pce'
SALIDA = 'roms/momotaro_es_v232.pce'
IPS = 'parches/momotaro_v232.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '1e105cc9c9c1aa08c4eca6b4395f0248'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL = 0xA0                       # salto de linea de ESTE bloque
COLS = 14

# Nombres de objeto: los que YA estan en el menu, elegidos por David por lo
# que cabia. Moneda: ryo/ryos. "Bakamon" traducido, como pidio.
TEXTOS = [
    'Coges el Onigiri',
    'Coges el Manjar',
    'Coges el Banquete',
    'Coges un Dango',
    'Coges los Pedos',
    'Coges la Solar',
    'Coges la Glacial',
    'Coges la Capa',
    'Ganas 100 ryos',
    'Ganas 50 ryos',
    'Ganas 30 ryos',
    'Ganas 10 ryos',
    'No puedes llevar mas',
    'El perro te acompana',
    'El faisan te acompana',
    'El mono te acompana',
    'Coges el Caparazon',
    'Coges el Bonzo',
    'Ganas 80 ryos',
    'Ganas 20 ryos',
    'Menudo idiota!',
    'Sigue hacia arriba',
    'Sigue a la derecha',
]


def voraz(t, c):
    out, cur = [], ''
    for w in t.split():
        if not cur:
            cur = w
        elif len(cur) + 1 + len(w) <= c:
            cur += ' ' + w
        else:
            out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    return out


def cod(s):
    out = bytearray()
    for ch in s:
        assert ch in CHAR_TO_CODE, 'caracter no codificable: %r' % ch
        out.append(CHAR_TO_CODE[ch])
    return bytes(out)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v231'
    print('base %s  OK' % BASE)

    ptrs = [rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
            for k in range(23)]
    ini = BANCO24 + min(ptrs)
    fin = BANCO24 + max(ptrs)
    while rom[fin] not in (0xA0, 0x00):
        fin += 1
    # el ultimo texto acaba donde empieza el siguiente bloque
    while rom[fin] == 0xA0:
        fin += 1
    disponible = fin - ini
    print('zona: ROM 0x%05X..0x%05X = %d B' % (ini, fin, disponible))

    # estructura original: cuantas lineas tiene cada texto
    print('\n--- estructura original (lineas separadas por $A0)')
    for k in range(23):
        a = BANCO24 + ptrs[k]
        b = BANCO24 + ptrs[k + 1] if k + 1 < 23 else fin
        nl = rom[a:b].count(NL)
        print('   [%2d] %2d B, %d separadores' % (k, b - a, nl))

    # codificar
    bloques = []
    for k, t in enumerate(TEXTOS):
        li = voraz(t, COLS)
        assert len(li) <= 2, '[%d] %r necesita %d lineas' % (k, t, len(li))
        b = bytearray()
        for i, l in enumerate(li):
            if i:
                b.append(NL)
            b += cod(l)
        bloques.append(bytes(b))
    total = sum(len(b) + 1 for b in bloques)      # +1 separador entre textos
    print('\nnecesito %d B de %d disponibles' % (total, disponible))
    assert total <= disponible, 'no caben'

    # escribir y repuntar
    o = ini
    for k, b in enumerate(bloques):
        rom[TABLA + k * 2] = (o - BANCO24) & 0xFF
        rom[TABLA + k * 2 + 1] = (o - BANCO24) >> 8
        rom[o:o + len(b)] = b
        o += len(b)
        rom[o] = NL                                # cierra el texto
        o += 1
    # el resto de la zona, a $A0 (relleno, como el original)
    if o < fin:
        rom[o:fin] = bytes([NL]) * (fin - o)
    print('escritos %d B, relleno %d B' % (total, fin - o))

    # ---- verificacion: releer de la ROM ------------------------------
    C2C = {v: k for k, v in CHAR_TO_CODE.items()}
    print('\n--- releido de la ROM')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        s = ''
        while rom[a] != NL or (a + 1 < fin and rom[a + 1] != NL
                               and s.count('/') == 0):
            if rom[a] == NL:
                s += '/'
            else:
                s += C2C.get(rom[a], '{%02X}' % rom[a])
            a += 1
            if a >= fin:
                break
        print('   [%2d] $%04X  %s' % (k, p, s))

    intactas = [
        ('lista compartida', 0x47C02, 0x47C99),
        ('lista del abuelo', 0x47C99, 0x47CFB),
        ('tabla $9BBD', 0x41BBD, 0x41C05),
        ('fuente', 0x3D660, 0x3E200),
        ('guion principal', 0x48F91, 0x4A484),
        ('selector $FFA0', 0x1FA0, 0x1FC3),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v231' % len(dif))
    assert all(TABLA <= i < TABLA + 46 or ini <= i < fin for i in dif), \
        'hay cambios fuera de la tabla y la zona de textos'
    print('todos los cambios estan en la tabla o en la zona de textos')

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
