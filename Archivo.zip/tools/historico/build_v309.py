#!/usr/bin/env python3
"""v309 = v308 + el fondo del menu SELECT con SALUD (PNG de David).

El fondo del menu ya estaba traducido: los siete rotulos en castellano YA
ESTAN en la ROM. Lo unico que cambia es VIDA -> SALUD, pero como los
rotulos van DIBUJADOS en el fondo y SALUD es mas ancho que el kanji, el
trazo invade celdas del borde: 94 celdas pasan a usar otro tile y hacen
falta 10 tiles nuevos.

Estructura (medida sobre la v308, el diario estaba obsoleto):

    CG   0x0F3D9  UN SOLO stream de 256 tiles ($C1CC hace CLY -> 256)
                  -> VRAM $100..$1FF
    BAT  0x1E7EA  510 B RLE, 22x32, solo el byte BAJO (el alto lo pone el
                  juego: $01 -> patrones $1xx)
    cargador de la BAT:  $D301 (ROM 0x1B301) banco, $D308 puntero $47EA
    cargador del CG:     $D32D (ROM 0x1B32D) banco, $D33C puntero $53D9

Las 38 celdas de texto dinamico (cifras, importe, nombres de arma) las
escribe el juego en ejecucion; se detectan por su byte alto $02 y no se
tocan.
"""
import hashlib, sys, zlib
sys.path.insert(0, 'tools')
from select_bg import carga_paleta, tiles_png, tile_de_cg, a_bytes
from descomp_cg import descomprime, comprime
from rle_bat import descomprime as rle_des, comprime as rle_com

SRC = 'roms/momotaro_es_v308.pce'
DST = 'roms/momotaro_es_v309.pce'
PNG = '/home/user/uploads/Pantalla SELECT.png'
CG_INI, N_CG = 0x0F3D9, 256
BAT_INI, BAT_FIN = 0x1E7EA, 0x1E9E8
NUEVA_BAT = 0x47D61                  # 671 B libres en el banco $23

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
assert hashlib.md5(orig).hexdigest() == '05de5af123244e3d970f78a5d78057bf', 'la base no es la v308'

vram = open('docs/select_vram.bin', 'rb').read()
def word(f, c):
    o = (f * 64 + c) * 2
    return vram[o] | (vram[o + 1] << 8)

def libre(off):
    n = 0
    while off + n < len(rom) and rom[off + n] == 0xFF:
        n += 1
    return n

# --- estado actual ---------------------------------------------------------
png = tiles_png(PNG, carga_paleta())
cg, cg_fin = descomprime(rom, CG_INI, N_CG)
tiles = [tile_de_cg(cg, i) for i in range(N_CG)]
idx_de = {}
for i, t in enumerate(tiles):
    idx_de.setdefault(t, 0x100 + i)

dinamicas = {(f, c) for f in range(22) for c in range(32) if (word(f, c) >> 8) == 0x02}
assert len(dinamicas) == 38, 'esperaba 38 celdas dinamicas, hay %d' % len(dinamicas)

# --- los 10 tiles que faltan (la palabra SALUD y su borde) ----------------
faltan = [(f, c) for f in range(22) for c in range(32)
          if (f, c) not in dinamicas and png[f][c] not in idx_de]
ESPERADAS = [(2, 2), (2, 4), (2, 5), (2, 7),
             (3, 2), (3, 3), (3, 4), (3, 5), (3, 6), (3, 7)]
assert faltan == ESPERADAS, 'faltan celdas distintas de las de SALUD: %s' % faltan

# se reciclan los tiles del kanji sustituido, que el PNG ya no usa
usados = {idx_de[png[f][c]] for f in range(22) for c in range(32)
          if (f, c) not in dinamicas and png[f][c] in idx_de}
RECICLABLES = [0x10A, 0x10C, 0x118, 0x119, 0x11A, 0x128, 0x129, 0x100, 0x10D, 0x110]
for t in RECICLABLES:
    assert t not in usados, 'el tile $%03X si lo usa el PNG' % t
assert len(RECICLABLES) >= len(faltan)

for (f, c), slot in zip(faltan, RECICLABLES):
    tiles[slot - 0x100] = png[f][c]
    idx_de[png[f][c]] = slot

# --- CG: recomprimir en su sitio ------------------------------------------
raw = b''.join(a_bytes(t) for t in tiles)
cg_comp = comprime(raw)
assert descomprime(cg_comp, 0, N_CG)[0] == raw, 'round-trip del CG falla'
hueco_cg = cg_fin - CG_INI
assert len(cg_comp) <= hueco_cg, 'el CG crece de %d a %d B' % (hueco_cg, len(cg_comp))
rom[CG_INI:CG_INI + len(cg_comp)] = cg_comp
rom[CG_INI + len(cg_comp):cg_fin] = orig[CG_INI + len(cg_comp):cg_fin]

# --- BAT: repuntar TODAS las celdas estaticas -----------------------------
# (no solo las 10: el PNG cambia el tile de 94 celdas mas, porque el trazo
#  de SALUD invade el borde superior del recuadro)
bat_vieja, bat_fin = rle_des(rom, BAT_INI, 704)
assert bat_fin == BAT_FIN
bat = bytearray(bat_vieja)
for f in range(22):
    for c in range(32):
        if (f, c) in dinamicas:
            continue
        i = idx_de[png[f][c]]
        assert 0x100 <= i <= 0x1FF, 'el tile $%03X no cabe en el byte bajo' % i
        bat[f * 32 + c] = i & 0xFF
bat_comp = rle_com(bytes(bat))
assert rle_des(bat_comp, 0, 704)[0] == bytes(bat), 'round-trip de la BAT falla'

if len(bat_comp) <= BAT_FIN - BAT_INI:
    rom[BAT_INI:BAT_INI + len(bat_comp)] = bat_comp
    rom[BAT_INI + len(bat_comp):BAT_FIN] = orig[BAT_INI + len(bat_comp):BAT_FIN]
    BAT_OFF = BAT_INI
else:
    assert len(bat_comp) <= libre(NUEVA_BAT), \
        'la BAT no cabe: %d B en %d libres' % (len(bat_comp), libre(NUEVA_BAT))
    rom[NUEVA_BAT:NUEVA_BAT + len(bat_comp)] = bat_comp
    assert rom[0x1B301:0x1B303] == bytes([0xA9, 0x0F]), 'no es LDA #$0F'
    assert rom[0x1B308:0x1B30A] == bytes([0xA9, 0xEA]), 'no es LDA #$EA'
    assert rom[0x1B30C:0x1B30E] == bytes([0xA9, 0x47]), 'no es LDA #$47'
    banco = NUEVA_BAT // 0x2000
    log = 0x4000 + (NUEVA_BAT % 0x2000)
    rom[0x1B302] = banco
    rom[0x1B309] = log & 0xFF
    rom[0x1B30D] = (log >> 8) & 0xFF
    BAT_OFF = NUEVA_BAT
    print('BAT reubicada a %#07x (banco $%02X, logico $%04X), %d B'
          % (NUEVA_BAT, banco, log, len(bat_comp)))

# --- zonas intactas --------------------------------------------------------
for nom, a, b in (('vitores', 0x48401, 0x4847D),
                  ('CG de tienda', 0x2C05A, 0x2C319),
                  ('glifos', 0x3D660, 0x3E000),
                  ('tabla de tiendas', 0x10854, 0x108C0),
                  ('textos de tienda', 0x48460, 0x48C60),
                  ('rotulo/Game Over', 0x1F9C4, 0x1FA00)):
    assert rom[a:b] == orig[a:b], '%s tocado' % nom
assert rom[0x47CFB] == 0xFF, 'terminador del abuelo pisado'

open(DST, 'wb').write(rom)

# --- RELECTURA: reconstruir la pantalla como la lee el juego --------------
v = open(DST, 'rb').read()
cg2, _ = descomprime(v, CG_INI, N_CG)
T2 = [tile_de_cg(cg2, i) for i in range(N_CG)]
bat2, _ = rle_des(v, BAT_OFF, 704)
fallos = [(f, c) for f in range(22) for c in range(32)
          if (f, c) not in dinamicas and T2[bat2[f * 32 + c]] != png[f][c]]
assert not fallos, '%d celdas no releen el PNG: %s' % (len(fallos), fallos[:8])
print('relectura: las %d celdas estaticas dan EXACTAMENTE el PNG de David'
      % (704 - len(dinamicas)))

b = bytes(v)
print('%s  (%d bytes cambiados)' % (DST, sum(1 for i in range(len(b)) if b[i] != orig[i])))
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xFFFFFFFF))
