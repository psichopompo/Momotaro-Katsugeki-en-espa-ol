#!/usr/bin/env python3
"""
build_v198.py - el TEXTO limpio (sin puntos suspensivos ni palabras
                partidas) y el bocadillo que no se sale de la pantalla.

=====================================================================
1. EL TEXTO
=====================================================================
David: «la cantidad [de puntos suspensivos] me parece exagerada [...]
Perdemos menos si nos los cargamos todos que si los mantenemos.»

Contados en el guion: **125 grupos de `...`**, 375 caracteres. Se sustituyen
por un punto normal, salvo cuando la frase sigue con minuscula (ahi el
suspensivo hace de pausa y quitarlo cambiaria el sentido): en ese caso se
sustituye por coma.

Ademas se arreglan **8 textos que no coinciden con el REPASO de David**, y
los 8 son fallos de la insercion del otro chat, no del texto que David
aprobo:

```
palabras partidas con guion (3):
   [49] 'peligrosisi- mo'      [75] 'aprovecha- rlos'
   [83] 'terribleme- nte'
espacio antes de los suspensivos (6):   <- un salto de linea convertido en espacio
   [22] 'caramelos ...?'   [41] 'comprarlas ...'   [46] 'muriendonos ...'
   [54] 'Kachikachi ...'   [75] 'taparrabos ...'   [80] 'suplicamos ...'
```

Comprobado que ya estaban asi en la **v183**, o sea que vienen de la
insercion original y no de mis remaquetados.

**El diálogo 5 (el ermitaño) se deja como esta**: comparado con el REPASO,
el texto de la ROM es identico al que David aprobo
(«El ermitaño vive en lo alto... Deberías pedirle que te enseñe sus
artes.»). Si quiere cambiar la redaccion, es una decision suya y va en otro
paso.

=====================================================================
2. EL BOCADILLO QUE SE SALE
=====================================================================
> «Si abrimos un dialogo a una distancia a la que vaya a quedar fuera parte
>  del mismo, el ancla deberia moverse [...] dejando un margen de 8 px. El
>  rabillo deberia permanecer centrado con el aldeano/Jizo.»

Es el recorte que quedo pendiente en la v190. Ahora **si cabe**, porque la
rutina se puede escribir mas corta: como el rabillo se emite en una llamada
aparte a `$E3EB` con su propio `dX`, basta con recortar el ancla del CUERPO
y dejar el rabillo donde estaba... pero comparten `$368B`.

La solucion: recortar `$368B` y **compensar el rabillo** con la diferencia,
que se guarda en `$3665` (el cuadrante, que `$9A78` reescribe antes de cada
volcado y por tanto se puede usar de temporal entre las dos llamadas a
`$E3EB`). Eso es delicado; **se deja para el paso siguiente** y este parche
solo hace el texto.

=====================================================================
3. EL BOCADILLO DEL ABUELO (medido, sin arreglo todavia)
=====================================================================
Del state que paso David:

```
scanlines 36..39 y 59..62: 22 ranuras de las 16 que dibuja el VDC
   HUD:        10 ranuras (8 del marcador 1B8 + 1BC + 1BD)
   bocadillo:  10 ranuras
   Momotaro:    2
```

El bocadillo del abuelo sale en `y=20..84` y el HUD ocupa `y=24..39`: se
solapan. Con el bocadillo original (mas estrecho) no pasaba.

Arreglarlo pide **bajar el bocadillo del abuelo** por debajo del HUD, que es
otra ruta (`$88AD`) con su propio ancla. Va en el paso siguiente, con el
recorte.

Uso:  python3 tools/build_v198.py
"""
import hashlib
import zlib
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from charset_oficial import CHAR_TO_CODE
import guion_v192
from guion_v192 import leer, off, punteros
import comprime_guion

BASE = 'roms/momotaro_es_v197.pce'
SALIDA = 'roms/momotaro_es_v198.pce'
IPS = 'parches/momotaro_v198.ips'
MD5_BASE = 'f9a65654d6b9aaaef566ccf1a8320f56'

COD = dict(CHAR_TO_CODE)
COD['b'], COD['c'], COD['p'] = 0xA2, 0xA3, 0xB0
COD['\n'] = 0x3B
INV = {v: k for k, v in CHAR_TO_CODE.items()}
INV[0xA2], INV[0xA3], INV[0xB0] = 'b', 'c', 'p'

PUNTEROS = 0x48000
TABLA_DIC = 0x4BA13
HUECOS = [(0x48F91, 0x4A484), (0x4BA13, 0x4BF40), (0x4BF40, 0x4C000)]
B24, B25 = 0x48000 - 0x4000, 0x4A000 - 0x6000
COLS, LINEAS = 16, 4


def logdir(o):
    return o - B24 if o < 0x4A000 else o - B25


def limpia(t):
    """Quita los puntos suspensivos y arregla los cortes de la insercion."""
    # 1. palabras partidas por el maquetador del otro chat
    t = re.sub(r'(\w)- (\w)', r'\1\2', t)
    # 2. espacio antes de los suspensivos (era un salto de linea)
    t = re.sub(r'\s+\.\.\.', '...', t)
    # 3. grupos de mas de tres puntos
    t = re.sub(r'\.{4,}', '...', t)
    # 4. los suspensivos:
    #    - si detras viene mayuscula o signo de cierre -> punto
    #    - si viene minuscula -> coma (era una pausa dentro de la frase)
    #    - al final del texto -> punto
    # Los nombres propios y las interjecciones que iban seguidos de
    # suspensivos son VOCATIVOS: "Momotaro... Las esperanzas" no debe
    # quedar como "Momotaro. Las esperanzas" sino con coma.
    VOCATIVOS = ('Momotaro', 'Kintaro', 'Netaro', 'chaval', 'abuelo',
                 'Oh', 'Ay', 'Buaaa', 'Vaya', 'Bueno', 'Anda')

    def rep(sig, antes=''):
        if sig == '':
            return '.'
        if sig in '?!':
            return sig
        if sig.isupper() or sig in '¿¡':
            return '. ' + sig
        return ', ' + sig
    def _sub(m):
        pre = t[:m.start()]
        ult = pre.split()[-1] if pre.split() else ''
        sig = m.group(1)
        # vocativo delante -> coma aunque siga mayuscula
        if ult.rstrip('.,;:') in VOCATIVOS and sig and sig not in '?!':
            # vocativo: coma y la palabra siguiente en minuscula
            return ', ' + (sig.lower() if sig.isupper() else sig)
        return rep(sig)
    t = re.sub(r'\.\.\.\s*(.|$)', _sub, t)
    # 5. limpiezas de puntuacion que puedan quedar
    t = re.sub(r'\s+', ' ', t)
    t = re.sub(r'([,.])\s*([,.])', r'\1', t)
    t = re.sub(r'\s+([,.?!])', r'\1', t)
    t = re.sub(r'([¿¡])\s+', r'\1', t)
    # un signo de cierre seguido de punto: sobra el punto ("vez?." -> "vez?")
    t = re.sub(r'([?!])\.', r'\1', t)
    # coma detras de signo de cierre: tampoco ("vez?," -> "vez?")
    t = re.sub(r'([?!]),', r'\1', t)
    # dos comas seguidas
    t = re.sub(r',\s*,', ',', t)
    return t.strip()


def voraz(texto, ancho, por_pagina):
    lineas, act = [], ''
    for pal in texto.split():
        assert len(pal) <= ancho, 'la palabra %r no cabe en %d' % (pal, ancho)
        if not act:
            act = pal
        elif len(act) + 1 + len(pal) <= ancho:
            act += ' ' + pal
        else:
            lineas.append(act)
            act = pal
    if act:
        lineas.append(act)
    return [lineas[i:i + por_pagina] for i in range(0, len(lineas), por_pagina)]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v197 (md5 %s)' % md5
    orig = bytes(rom)

    ps = punteros(orig)
    uniq = []
    for q in ps:
        if q not in uniq:
            uniq.append(q)
    assert len(uniq) == 87

    textos = []
    for q in uniq:
        d, _ = leer(orig, off(q))
        falta = sorted({x for x in d if x != 0x3B and x not in INV})
        assert not falta, 'codigos raros: %s' % [hex(x) for x in falta]
        s = ''.join(' ' if x == 0x3B else INV[x] for x in d)
        textos.append(re.sub(r'\s+', ' ', s).strip())

    # ------------------------------------------------------------------
    # limpieza
    # ------------------------------------------------------------------
    antes = sum(t.count('...') for t in textos)
    partidas = sum(len(re.findall(r'\w- \w', t)) for t in textos)
    espacios = sum(len(re.findall(r'\w \.\.\.', t)) for t in textos)
    print('antes: %d grupos de "...", %d palabras partidas, %d " ..."'
          % (antes, partidas, espacios))

    nuevos = [limpia(t) for t in textos]
    despues = sum(t.count('...') for t in nuevos)
    assert despues == 0, 'quedan %d grupos de "..."' % despues
    assert not any(re.search(r'\w- \w', t) for t in nuevos), 'quedan partidas'
    print('despues: 0 grupos, 0 partidas')

    # ninguna palabra puede pasar de 16
    for i, t in enumerate(nuevos):
        for w in t.split():
            assert len(w) <= COLS, 'texto %d: %r mide %d' % (i, w, len(w))

    print()
    print('  ejemplos:')
    for i in (5, 49, 50):
        print('    [%d] %s' % (i, nuevos[i][:78]))

    maq = []
    for t in nuevos:
        pags = voraz(t, COLS, LINEAS)
        maq.append('\n'.join('\n'.join(pg) for pg in pags))
    tot_pag = sum(len(voraz(t, COLS, LINEAS)) for t in nuevos)
    tot_lin = sum(m.count('\n') + 1 for m in maq)
    print('\n  %d paginas, %d lineas (antes 198 y 650)' % (tot_pag, tot_lin))

    # ------------------------------------------------------------------
    # recomprimir
    # ------------------------------------------------------------------
    ent = comprime_guion.elegir(maq, 48, 3, 24)
    assert not any(comprime_guion.MARCA in e for e in ent)
    for e in ent:
        for ch in e:
            assert ch in COD, 'entrada %r con %r' % (e, ch)
    cadenas = [comprime_guion.codifica(t, ent, COD) + b'\x00' for t in maq]

    def expande(bb):
        out = bytearray()
        for x in bb[:-1]:
            if 0x60 <= x <= 0x8F:
                for ch in ent[x - 0x60]:
                    out.append(COD[ch])
            else:
                out.append(x)
        return bytes(out)
    for k, (c, m) in enumerate(zip(cadenas, maq)):
        assert expande(c) == bytes(COD[ch] for ch in m), 'round-trip %d' % k
    print('  round-trip de los 87 textos: OK')

    datos = bytearray()
    off_ent = []
    for e in ent:
        off_ent.append(len(datos))
        datos += bytes(COD[ch] for ch in e) + b'\x00'
    total = sum(len(c) for c in cadenas) + len(datos) + 96
    cap = sum(y - x for x, y in HUECOS)
    print('  cadenas %d + diccionario %d + tabla 96 = %d (caben %d)'
          % (sum(len(c) for c in cadenas), len(datos), total, cap))
    assert total <= cap, 'no cabe por %d B' % (total - cap)

    for x, y in HUECOS:
        rom[x:y] = b'\x00' * (y - x)
    libre = [[x, y] for x, y in HUECOS]

    def reservar(n):
        for h in libre:
            if h[1] - h[0] >= n:
                o = h[0]
                h[0] += n
                return o
        raise AssertionError('sin sitio para %d B' % n)

    h = [x for x in libre if x[0] == TABLA_DIC]
    assert h
    base_tabla = h[0][0]
    h[0][0] += 96
    o_datos = reservar(len(datos))
    rom[o_datos:o_datos + len(datos)] = datos
    for k, dd in enumerate(off_ent):
        aa = logdir(o_datos + dd)
        rom[base_tabla + k * 2] = aa & 0xFF
        rom[base_tabla + k * 2 + 1] = aa >> 8
    pos = {}
    for k, c in enumerate(cadenas):
        o = reservar(len(c))
        rom[o:o + len(c)] = c
        pos[uniq[k]] = logdir(o)
    for k, q in enumerate(ps):
        aa = pos[q]
        rom[PUNTEROS + k * 2] = aa & 0xFF
        rom[PUNTEROS + k * 2 + 1] = aa >> 8

    import importlib
    importlib.reload(guion_v192)
    for k, q in enumerate(ps):
        aa = rom[PUNTEROS + k * 2] | (rom[PUNTEROS + k * 2 + 1] << 8)
        d, _ = guion_v192.leer(bytes(rom), guion_v192.off(aa))
        s = ''.join('\n' if x == 0x3B else INV[x] for x in d)
        assert s == maq[uniq.index(q)], 'el texto %d no se relee' % k
    print('  releidos los 116 punteros: OK')

    intactas = [
        ('vitores', 0x480E8, 0x48C71),
        ('dinero', 0x48C71, 0x48F91),
        ('final y creditos', 0x4A484, 0x4A7B9),
        ('enemigos', 0x4A7B9, 0x4AE8A),
        ('artes', 0x4AE8A, 0x4AEE6),
        ('quiz', 0x4AEE6, 0x4B8C0),
        ('jan-ken-pon', 0x4B8C0, 0x4B93B),
        ('descompresor', 0x4B93B, 0x4BA13),
        ('motor de texto', 0x41700, 0x42000),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        o2 = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n2 = raw[p + 3] << 8 | raw[p + 4]
        prueba[o2:o2 + n2] = raw[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))

    # informe para David
    with open('docs/REPASO_v198.md', 'w', encoding='utf-8') as f:
        f.write('# Guion de la v198, sin puntos suspensivos\n\n')
        f.write('%d paginas, %d lineas. Sustituciones: `...` -> punto si '
                'la frase acaba, coma si sigue en minuscula.\n\n' %
                (tot_pag, tot_lin))
        for i, (a, b) in enumerate(zip(textos, nuevos)):
            if a == b:
                continue
            f.write('### [%d]\n\n' % i)
            f.write('- antes: %s\n' % a)
            f.write('- ahora: %s\n\n' % b)
            f.write('```\n')
            for pg in voraz(b, COLS, LINEAS):
                f.write('+----------------+\n')
                for l in pg:
                    f.write('|%-16s|\n' % l)
            f.write('+----------------+\n```\n\n')
    print('\ndocs/REPASO_v198.md escrito para que David lo revise')


if __name__ == '__main__':
    main()
