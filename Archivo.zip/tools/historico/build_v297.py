#!/usr/bin/env python3
"""v297 = v296 + dos arreglos medidos.

1) 0x3DBE8  $00 -> $18   contador de bloques del CG del bocadillo de TIENDA.
   Lo habia pisado el ultimo byte del glifo 'p'. Con $00 el bucle
   'LDX $5BE8 / ... / DEX / BNE' da 256 vueltas en vez de 24 y arrasa la
   VRAM de $0EC a $1EB, incluido el HUD ($1B0-$1BF).
   Ver docs/HALLAZGO_HUD_tiendas.md.

2) 0x04100  glifo 16 de la fuente del titulo (codigo $40).
   Alguien lo reaprovecho para dibujar una 'E' con tilde, pero ese codigo
   lo usa la cadena del copyright: salia "E1990 HUDSON SOFT" en vez de
   "(c)1990 HUDSON SOFT". Se restaura el simbolo (c) de la ROM japonesa.
   Comprobado que NINGUNA otra cadena de ese motor usa el codigo $40.
"""
import hashlib, zlib, sys

SRC = 'roms/momotaro_es_v296.pce'
JP  = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v297.pce'

rom = bytearray(open(SRC, 'rb').read())
jp  = open(JP, 'rb').read()
orig = bytes(rom)

assert len(rom) == 512 * 1024, 'tamano inesperado'
assert hashlib.md5(orig).hexdigest() == '781fb22da4b5cba725ca73afc6f6a1bf', 'la v296 no es la esperada'

# --- 1. contador del CG de tienda -----------------------------------------
assert rom[0x3DBE8] == 0x00, 'byte 0x3DBE8 inesperado: %02X' % rom[0x3DBE8]
assert jp[0x3DBE8] == 0x18, 'la japonesa no trae $18'
rom[0x3DBE8] = 0x18

# --- 2. el simbolo (c) del titulo -----------------------------------------
CO = 0x04100
assert rom[CO:CO+16] != jp[CO:CO+16], 'el glifo 16 ya estaba intacto'
rom[CO:CO+16] = jp[CO:CO+16]

# --- asserts de zonas que NO se pueden tocar ------------------------------
dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
permitido = set([0x3DBE8]) | set(range(CO, CO + 16))
fuera = [x for x in dif if x not in permitido]
assert not fuera, 'cambios fuera de las dos zonas: %s' % [hex(x) for x in fuera][:20]
assert 0x3DBE8 in dif, 'el contador no se ha escrito'

# el stream de tienda que sigue al contador no se toca en esta version
assert rom[0x3DBE9:0x3DE60] == orig[0x3DBE9:0x3DE60], 'se ha tocado el stream'
# los otros dos glifos retocados del titulo (T y Ó) siguen siendo NUESTROS
assert rom[0x04240:0x04250] != jp[0x04240:0x04250], 'la T se ha revertido'
assert rom[0x042B0:0x042C0] != jp[0x042B0:0x042C0], 'la Ó se ha revertido'

open(DST, 'wb').write(rom)

# --- relectura siguiendo el puntero como hace el motor --------------------
v = open(DST, 'rb').read()
assert v[0x3DBE8] == 0x18
n = v[0x3DBE8]
sys.path.insert(0, 'tools')
from descomp_cg2 import bloque, F
f = F(v, 0x3DBE9)
cel = [bloque(f) for _ in range(n)]
assert len(cel) == 24, 'el motor no lee 24 celdas'
print('relectura: LDX $5BE8 -> %d bloques, celdas $0EC..$%03X, fin ROM %#07x'
      % (n, 0x0EC + n - 1, f.p))
assert 0x0EC + n - 1 == 0x103, 'el volcado ya no acaba en $103'
assert 0x0EC + n - 1 < 0x1B0, 'sigue pisando el HUD'

b = bytes(v)
print(DST)
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xffffffff))
print('  %d bytes cambiados respecto a la v296' % len(dif))
