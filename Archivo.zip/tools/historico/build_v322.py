#!/usr/bin/env python3
"""build_v322.py - Arregla el «texto raro» del ermitanyo (error propio v318).

EL BUG
------
David: *«la pregunta inicial estaba traducida a medias, se colaba un texto
raro antes»*.

En la v318 escribi la linea del ermitanyo empezando en `0x4AE18`. **El
bloque empieza en `0x4AE0A`.** Los 14 bytes de delante se quedaron en
japones y en pantalla salen como basura latina («"+¡»), justo antes de mi
texto.

LA ESTRUCTURA REAL (medida, terminadores $80/$00/$FF)
-----------------------------------------------------
    0x4AE0A .. 0x4AE31   39 B, term $00   <- ESTE es el bloque
        «kuregure mo muri wa kinmotsu ja! ujuju! washi wa »
        = «¡sobre todo, nada de excesos! ¡ujuju! yo soy »
        El $00 de 0x4AE31 es el MARCADOR de sustitucion: ahi se inserta
        el nombre de la tecnica.
    0x4AE32 .. 0x4AE3A    8 B, term $80
        «sennin ja!» = «...el ermitanyo»  (la 2a mitad de la frase)

O sea que la frase completa es:
    [bloque 1] + <<NOMBRE DE TECNICA>> + [bloque 2]

Por eso David veia «Vuelo» incrustado: el nombre ya estaba traducido y el
resto no.

LA TRADUCCION
-------------
Rejilla 2 x 16, como el resto de bocadillos de esta zona.

    bloque 1:  L1 «¡Y nada de excesos!»  -> no cabe, 19
               L1 «¡Sin pasarse, eh!»    17 -> tampoco
               L1 «¡Nada de excesos!»    17 -> tampoco
               L1 «¡Sin excesos!»        13   OK
               L2 «¡Jujú! Yo soy »       + marcador
    bloque 2:  «el gran ermitaño» -> no cabe en 8 B

El bloque 2 solo tiene 8 B, asi que la frase se reparte:
    «¡Sin excesos! / ¡Jujú! Soy <<T>>» + «.» en el bloque 2.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode, RELLENO   # noqa: E402

BASE = 'roms/momotaro_es_v321.pce'
SALIDA = 'roms/momotaro_es_v322.pce'
MD5_BASE = '1019a547950fe60515c3886f961f4cf7'

BLOQUE1 = 0x4AE0A          # 39 B, acaba en el $00 marcador de 0x4AE31
MARCADOR = 0x4AE2C   # la v318 lo dejo aqui, no en 0x4AE31
BLOQUE2 = 0x4AE2D          # tras el marcador, hasta el $80 de 0x4AE3A
FIN2 = 0x4AE3A

COLS = 16
L1 = '¡Sin excesos!'
L2 = '¡Jujú! Soy '       # + <<TECNICA>> insertada por el motor
B2 = '.'                  # cierra la frase tras el nombre

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x1E000, 0x20000, 'banco $0F: escenas y rotulos'),
    (0x42000, 0x44000, 'banco $21: menu RUN'),
    (0x48000, 0x4A000, 'banco $24: tiendas, guion, vitores'),
    (0x4AC80, 0x4AE0A, 'dados y lo anterior al ermitanyo'),
    (0x4AE3B, 0x4AEE6, 'ermitanyo bloques quiz/ppt y tecnicas'),
    (0x4AEE6, 0x4BA13, 'el QUIZ'),
    (0x4BA15, 0x4C000, 'diccionario y dialogos'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v321'

    # ---- asserts de estructura ------------------------------------------
    assert jp[0x4AE31] == 0x00, 'la japonesa no tiene el marcador en 0x4AE31'
    assert jp[FIN2] == 0x80, 'en %06X no hay terminador $80' % FIN2
    assert rom[MARCADOR] == 0x00, 'se perdio el marcador de sustitucion'
    assert rom[FIN2] == 0x80, 'se perdio el terminador $80'
    # los 14 primeros bytes siguen en japones: eso es el bug
    assert rom[BLOQUE1:BLOQUE1 + 14] == jp[BLOQUE1:BLOQUE1 + 14], \
        'los bytes de %06X ya no son los japoneses' % BLOQUE1

    hueco1 = MARCADOR - BLOQUE1
    hueco2 = FIN2 - BLOQUE2
    assert hueco1 == 34, 'hueco1 = %d' % hueco1
    assert hueco2 == 13, 'hueco2 = %d' % hueco2

    # ---- el bloque 1: 2 lineas de 16 + relleno hasta el marcador --------
    assert len(L1) <= COLS, '«%s» son %d columnas' % (L1, len(L1))
    assert len(L2) <= COLS, '«%s» son %d columnas' % (L2, len(L2))
    datos = (encode(L1) + bytes([RELLENO]) * (COLS - len(L1)) +
             encode(L2))
    assert len(datos) <= hueco1, 'el bloque 1 ocupa %d B y hay %d' % (len(datos), hueco1)
    datos += bytes([RELLENO]) * (hueco1 - len(datos))
    rom[BLOQUE1:MARCADOR] = datos

    # ---- el bloque 2 ----------------------------------------------------
    d2 = encode(B2)
    assert len(d2) <= hueco2, 'el bloque 2 no cabe'
    rom[BLOQUE2:FIN2] = d2 + bytes([RELLENO]) * (hueco2 - len(d2))

    # ---- VERIFICACION ----------------------------------------------------
    assert rom[MARCADOR] == 0x00, 'se perdio el marcador'
    assert rom[FIN2] == 0x80, 'se perdio el terminador'
    # no queda kana: en este charset las latinas van de $A1 a $BA y los
    # signos de $BB a $DD, asi que se comprueba contra los bytes JAPONESES
    # que habia antes (kana puro: $B1-$DD sin equivalente latino usado)
    assert rom[BLOQUE1:MARCADOR] != jp[BLOQUE1:MARCADOR], 'no se escribio nada'
    assert all(rom[i] != jp[i] or rom[i] in (0x20, RELLENO)
               for i in range(BLOQUE1, BLOQUE1 + 14)), \
        'quedan bytes japoneses sin tocar al principio del bloque'
    # releer
    rv = {}
    from charset_vitores import CHAR_TO_CODE
    for k, v in CHAR_TO_CODE.items():
        rv.setdefault(v, k)
    leido1 = ''.join(rv.get(b, '?') for b in rom[BLOQUE1:BLOQUE1 + len(L1)])
    assert leido1 == L1, 'la L1 releida es «%s»' % leido1
    leido2 = ''.join(rv.get(b, '?') for b in rom[BLOQUE1 + COLS:BLOQUE1 + COLS + len(L2)])
    assert leido2 == L2, 'la L2 releida es «%s»' % leido2
    leido3 = ''.join(rv.get(b, '?') for b in rom[BLOQUE2:BLOQUE2 + len(B2)])
    assert leido3 == B2, 'el bloque 2 releido es «%s»' % leido3

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = [i for i in range(len(rom)) if rom[i] != original[i]]
    assert all(BLOQUE1 <= i < FIN2 for i in dif), 'hay bytes fuera del bloque'

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % len(dif))
    print()
    print('  %06X  |%-16s|' % (BLOQUE1, L1))
    print('          |%-16s|<<TECNICA>>' % L2)
    print('  %06X  «%s»' % (BLOQUE2, B2))
    print()
    print('  en pantalla:  «¡Sin excesos! / ¡Jujú! Soy Vuelo.»')


if __name__ == '__main__':
    main()
