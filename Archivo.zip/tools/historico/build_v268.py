#!/usr/bin/env python3
"""
build_v268.py - el password en pagina limpia. Arregla el CUELGUE de la v267.

POR QUE SE COLGABA LA v267
==========================
David: *«cuando tiene que salir el password el bocadillo se queda en blanco
y se congela. La musica sigue sonando con normalidad.»*

La captura del depurador (breakpoint $CA73-$CAB2) lo confirmo: el juego
entra en `$CA73  JSR $CABD` con `$3657 = $03`, o sea que llega al borrado.
No pasa de ahi.

**El bucle de borrado de la v267 NO TERMINA NUNCA.** Tal y como quedo
escrito en la ROM:

```
CAC2  STA $3657
CAC5  PHA / JSR $9B7C / PLA
CACA  SEC
CACB  SBC #$02
CACD  CMP #$01
CACF  BCS $CAC2      <-- AQUI
```

`BCS` despues de `CMP #$01` es una comparacion **SIN SIGNO**: el acarreo se
pone a 1 siempre que `A >= 1` interpretando A como 0..255.

```
A=$03 -> SBC -> A=$01 -> CMP #$01 -> C=1 -> salta   (2a vuelta)
A=$01 -> SBC -> A=$FF -> CMP #$01 -> C=1 -> SALTA   <-- deberia salir
A=$FF -> SBC -> A=$FD -> CMP #$01 -> C=1 -> salta
A=$FD -> ... $FB, $F9, $F7 ... nunca baja de 1 sin signo
```

Bucle infinito. Y como cada vuelta hace `JSR $9B7C` volcando el buffer
vacio, la pantalla se queda **en blanco**; y como el cuelgue es un bucle de
usuario y no un crash, las **interrupciones siguen corriendo** y por eso la
musica suena con normalidad. Los dos sintomas que describio David encajan
exactamente.

MI ERROR, EXPLICITO
===================
El simulador que metí en `build_v267.py` era este:

```python
if not (A >= 1 and A < 0x80):
    break
```

Eso modela un `BCS` **con signo**. El 6502 no funciona asi: `BCS` es sin
signo y `$FF` es 255, no -1. El `assert vals == [3, 1]` paso porque estaba
comprobando el codigo contra un modelo equivocado, no contra la maquina.
Violé mi propia norma: el assert verificaba mi hipotesis, no el hardware.

EL ARREGLO: UN SOLO BYTE
========================
Hay que salir por **signo**, no por acarreo. `CMP #$01` calcula `A - 1` y
fija N con el bit 7 de ese resultado:

```
A=$01 -> $01-$01 = $00 -> N=0 -> BPL salta  (sigue: 2a vuelta con $3657=1)
A=$FF -> $FF-$01 = $FE -> N=1 -> BPL NO salta -> SALE
```

O sea: `BCS` ($B0) -> `BPL` ($10) en `0x16ACF`. **Un byte.**

Verificado paso a paso con los flags reales:
```
   STA $3657=$03 -> SBC A=$01 -> CMP #$01: N=0 -> sigue
   STA $3657=$01 -> SBC A=$FF -> CMP #$01: N=1 -> SALE
```
Toma [3, 1] y sale con `$3657 = 1` -> filas A. Que es justo lo pedido:
borra las filas B, borra las filas A, y deja el cursor arriba.

LO DEMAS SE MANTIENE (igual que la v267)
========================================
(a) `$CA73  JSR $9C29` -> `JSR $CABD`  (el borrado de las dos mitades)
(b) `$CAAA  JMP $9B7C`  -> `JMP $DE69` (continuar en la misma pagina)

```
$DE69  JSR $9B7C     vuelca las lineas 1-2
       JSR $9C29     limpia el buffer
       LDA #$03
       STA $3657     -> filas B (linea 3)
       CLX           X=0
       JMP $CA78     sigue el bucle SIN salir
```

Simulado el bucle del canto entero (32 simbolos + separador cada 4) con el
borrado ya arreglado:
```
   volcado 1: filas A (lineas 1-2), 30 celdas
   volcado 2: filas B (lineas 3-4), 10 celdas
   -> fin por canto
```
Dos volcados, UNA sola pagina, empezando arriba.

Uso:  python3 tools/build_v268.py
"""
import hashlib
import zlib
import subprocess

BASE = 'roms/momotaro_es_v264.pce'
SALIDA = 'roms/momotaro_es_v268.pce'
IPS = 'parches/momotaro_v268.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '695965973173f0a960eb3c0095f8cef0'

BUCLE = 0x16A73                 # $CA73  JSR $9C29
CORTE = 0x16AAA                 # $CAAA  JMP $9B7C  (fin de pagina)
NOPS = 0x16ABD                  # $CABD  25 NOPs
CONT = 0x17E69                  # $DE69  407 B de relleno
FUENTE = 0x3D660


def sim_borrado(op_salto):
    """Simula el bucle con los flags REALES del 6502. Devuelve los valores
    que toma $3657, o None si no termina."""
    A = 0x03
    vals = []
    for _ in range(64):
        vals.append(A)
        A = (A - 2) & 0xFF              # SEC / SBC #$02
        t = (A - 0x01) & 0xFF           # CMP #$01
        C = 1 if A >= 0x01 else 0       # acarreo: comparacion SIN SIGNO
        N = (t >> 7) & 1                # negativo: bit 7 del resultado
        sigue = {0xB0: C == 1,          # BCS
                 0x90: C == 0,          # BCC
                 0x10: N == 0,          # BPL
                 0x30: N == 1}[op_salto]
        if not sigue:
            return vals
    return None


def sim_canto(rom):
    """Simula el bucle del canto ENTERO leyendo el codigo de la ROM ya
    escrita: 32 simbolos, separador cada 4, con la continuacion $DE69."""
    tabla = [0] * 0x80
    for i in range(32):
        tabla[i] = (i % 60) + 1         # password de 32 simbolos
    r3657, r365D, X = 1, 0, 0
    buf = [None] * 36
    volcados = []
    for _ in range(600):
        A = (tabla[r365D] - 1) & 0xFF
        if A & 0x80:                                    # $CA7F BMI $CAAD
            volcados.append((r3657, sum(1 for c in buf if c)))
            return volcados, 'fin del canto ($CAAD)'
        buf[X] = 'g'
        X += 1
        r365D += 1
        if (r365D & 3) == 0:                            # $CA8C separador
            buf[X] = '/'
            X += 1
            if X == 0x0F:                               # $CA99
                X = 0x10
        if r365D >= 0x20:                               # $CA9F corte canto
            volcados.append((r3657, sum(1 for c in buf if c)))
            return volcados, 'fin del canto ($CAAD)'
        if X >= 0x1F:                                   # $CAA6 -> $CAAA
            volcados.append((r3657, sum(1 for c in buf if c)))
            buf = [None] * 36                           # $DE69: JSR $9C29
            r3657 = 3                                   #        $3657=3
            X = 0                                       #        CLX
    return volcados, 'NO TERMINA'


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v264'
    print('base %s  OK' % BASE)
    assert all(b == 0 for b in rom[FUENTE:FUENTE + 8]), \
        'el glifo 0 no es todo ceros (el borrado dejaria de borrar)'

    # ==================================================================
    # demostracion del fallo de la v267 antes de escribir nada
    # ==================================================================
    print('\n--- por que se colgaba la v267 (BCS)')
    mal = sim_borrado(0xB0)
    assert mal is None, 'el bucle con BCS SI terminaba: %s' % mal
    print('    BCS: el bucle NO TERMINA -> pantalla en blanco + musica = cuelgue')
    bien = sim_borrado(0x10)
    assert bien == [3, 1], 'el bucle con BPL no recorre [3, 1]: %s' % bien
    print('    BPL: $3657 toma %s y sale con %d' % (bien, bien[-1]))
    for v in bien:
        print('       $3657=%d -> calc_alto=%d -> filas %s'
              % (v, (v - 1) & 2,
                 'A (lineas 1-2)' if ((v - 1) & 2) == 0 else 'B (lineas 3-4)'))

    # ==================================================================
    # (a) el borrado de las dos mitades, en los NOPs de $CABD
    # ==================================================================
    n = 0
    while rom[NOPS + n] == 0xEA:
        n += 1
    borra = bytes([
        0x20, 0x29, 0x9C,            # JSR $9C29   buffer a cero
        0xA9, 0x03,                  # LDA #$03
        0x8D, 0x57, 0x36,            # @b: STA $3657
        0x48,                        # PHA
        0x20, 0x7C, 0x9B,            # JSR $9B7C   vuelca vacio -> BORRA
        0x68,                        # PLA
        0x38,                        # SEC
        0xE9, 0x02,                  # SBC #$02
        0xC9, 0x01,                  # CMP #$01
        0x10, 0xF1,                  # BPL @b      <-- $10, NO $B0
        0x60,                        # RTS
    ])
    assert len(borra) <= n, 'el borrado no cabe: %d > %d' % (len(borra), n)
    print('\n(a) borrado: %d B en $CABD (hueco de %d NOPs)' % (len(borra), n))

    # el salto se comprueba, no se supone
    i_b = borra.index(0x10, 12)
    assert borra[i_b] == 0x10, 'no esta el BPL donde se espera'
    rel = borra[i_b + 1] - 256 if borra[i_b + 1] > 127 else borra[i_b + 1]
    destino = i_b + 2 + rel
    assert destino == 5, 'el BPL salta a +%d, el bucle esta en +5' % destino
    print('    BPL en +%d -> +%d (el STA $3657): OK' % (i_b, destino))

    assert bytes(rom[BUCLE:BUCLE + 3]) == bytes([0x20, 0x29, 0x9C]), \
        'en $CA73 no esta el JSR $9C29'
    rom[NOPS:NOPS + len(borra)] = borra
    a_borra = 0xC000 + (NOPS - 0x16000)
    rom[BUCLE:BUCLE + 3] = bytes([0x20, a_borra & 0xFF, a_borra >> 8])
    print('    $CA73  JSR $9C29 -> JSR $%04X' % a_borra)

    # ==================================================================
    # (b) continuar en la misma pagina
    # ==================================================================
    assert bytes(rom[CORTE:CORTE + 3]) == bytes([0x4C, 0x7C, 0x9B]), \
        'en $CAAA no esta el JMP $9B7C'
    libre = 0
    while rom[CONT + libre] == 0xFF:
        libre += 1
    assert all(b == 0xFF for b in orig[CONT:CONT + libre]), \
        'el hueco no esta a $FF en la ROM virgen'
    # $CA73 y $DE69 tienen que caer en el MISMO banco ($0B en MPR6)
    assert (BUCLE >> 13) == (CONT >> 13) == 0x0B, \
        'el bucle y la continuacion no estan en el banco $0B'
    print('\n(b) hueco en $DE69: %d B a $FF (tambien en la virgen), banco $0B'
          % libre)

    cont = bytes([
        0x20, 0x7C, 0x9B,            # JSR $9B7C   vuelca lineas 1-2
        0x20, 0x29, 0x9C,            # JSR $9C29   limpia el buffer
        0xA9, 0x03,                  # LDA #$03
        0x8D, 0x57, 0x36,            # STA $3657   -> filas B (linea 3)
        0x82,                        # CLX
        0x4C, 0x78, 0xCA,            # JMP $CA78   sigue el bucle
    ])
    assert len(cont) <= libre, 'la continuacion no cabe'
    rom[CONT:CONT + len(cont)] = cont
    a_cont = 0xC000 + (CONT - 0x16000)
    rom[CORTE:CORTE + 3] = bytes([0x4C, a_cont & 0xFF, a_cont >> 8])
    print('    rutina de %d B en $%04X' % (len(cont), a_cont))
    print('    $CAAA  JMP $9B7C -> JMP $%04X' % a_cont)

    # ==================================================================
    # simulacion del canto entero, ya con el arreglo
    # ==================================================================
    print('\n--- el canto completo, simulado con el borrado arreglado')
    volc, fin = sim_canto(bytes(rom))
    assert fin != 'NO TERMINA', 'el bucle del canto no termina'
    assert len(volc) == 2, 'se esperaban 2 volcados, hay %d' % len(volc)
    assert ((volc[0][0] - 1) & 2) == 0, 'el primer volcado no va a filas A'
    assert ((volc[1][0] - 1) & 2) == 2, 'el segundo volcado no va a filas B'
    for i, (v, c) in enumerate(volc, 1):
        print('    volcado %d: $3657=%d -> filas %s, %d celdas'
              % (i, v, 'A (lineas 1-2)' if ((v - 1) & 2) == 0
                 else 'B (lineas 3-4)', c))
    print('    %s  -> 3 lineas en UNA pagina, empezando arriba' % fin)

    # ==================================================================
    # verificacion sobre la ROM ya escrita
    # ==================================================================
    tmp = '/tmp/_v268.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado DESDE LA ROM ESCRITA')
    for o, nb, carga, nom in [(BUCLE, 6, 0xCA73, 'entrada'),
                              (CORTE, 6, 0xCAAA, 'corte de pagina'),
                              (NOPS, len(borra), a_borra, 'borrado'),
                              (CONT, len(cont), a_cont, 'continuacion')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % o,
                            str(nb), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    # el byte del salto, comprobado en la ROM final
    assert rom[NOPS + i_b] == 0x10, 'en la ROM no hay un BPL, hay $%02X' \
        % rom[NOPS + i_b]
    print('\n  el byte del salto en 0x%05X es $10 (BPL), no $B0 (BCS): OK'
          % (NOPS + i_b))

    intactas = [
        ('cuerpo del bucle', BUCLE + 3, CORTE),
        ('cola del bucle', CORTE + 3, NOPS),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla del canto', 0x16AD6, 0x16B16),
        ('cadena Capa', 0x43140, 0x43148),
        ('verbos del menu', 0x431B4, 0x431EB),
        ('parrilla del password', 0x1BBBA, 0x1BC00),
        ('nombres del inventario', 0x42F4C, 0x43180),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('intactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    ok = (set(range(BUCLE, BUCLE + 3)) | set(range(CORTE, CORTE + 3))
          | set(range(NOPS, NOPS + len(borra)))
          | set(range(CONT, CONT + len(cont))))
    assert set(dif) <= ok, 'cambios fuera de sitio'
    print('%d bytes sobre la v264, todos en las 4 zonas previstas' % len(dif))

    open(SALIDA, 'wb').write(d)

    # --- IPS contra la virgen, con round-trip ---
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
