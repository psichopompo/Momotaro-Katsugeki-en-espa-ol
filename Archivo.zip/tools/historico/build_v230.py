#!/usr/bin/env python3
"""
build_v230.py - arregla el FREEZE de la v229. Sin marca en RAM.

Desde la v227 (la que David aprueba en medidas).

=====================================================================
LO QUE APRENDI, Y QUE EXPLICA EL FALLO DE LA v228
=====================================================================
El texto NO ocupa la celda entera, solo MEDIA. La tabla `$9C05` fija el
cuadrante de cada indice del buffer:

```
indices  0-15 (linea 1) -> cuadrante 02/03 = mitad INFERIOR de la celda
indices 16-31 (linea 2) -> cuadrante 00/01 = mitad SUPERIOR
```

Y el marco esta DIBUJADO dentro de esas mismas celdas:

```
1C4..1CB   arriba = borde superior   abajo = LINEA 1
1CC..1D3   arriba = LINEA 2          abajo = blanco
1D4..1DB   arriba = blanco           abajo = borde inferior (fila 14)
```

Por eso el compartido tiene **3 filas de sprites pero solo 2 de texto**: la
tercera es medio blanco y medio borde. En la v228 añadi una tercera fila
entera creyendo que hacia falta; lo que sobra es el hueco blanco.

=====================================================================
LA SOLUCION
=====================================================================
La linea 2 del abuelo va a `1D4..1DA`, que YA llevan el borde inferior
dibujado abajo y tienen la mitad de arriba limpia (verificado: 0 px no
blancos en las filas 0-7). Con eso, **dos filas de sprites**:

```
fila 1  dY=20   1C4..1CA   borde superior + LINEA 1
fila 2  dY=36   1D4..1DA   LINEA 2 + BORDE INFERIOR
laterales 1DC (arriba) y 1DD (abajo), los dos con borde
alto = 32 px, como la v227
```

**Y no hace falta duplicar la tabla `$9BBD` ni tocar el CG.** La celda 1D4
esta 8 celdas por encima de la 1CC, o sea exactamente **+$200 en el word
de destino = +2 en el byte ALTO**, que lo calcula `$9FE0`:

```
$9FE0  LDA $3657 / DEC A / AND #$02 / CLC / ADC $9BBE,Y / RTS
```

Basta sumarle 2 mas cuando (a) sea la linea 2 y (b) sea el abuelo. El
selector deja una marca en `$3693` (comprobado: 0 referencias en la ROM) y
`$9FE0` la suma.

Datos del otro chat que confirman que esto es seguro:
- `$52C2` es codigo suyo de la v216: carga el CG del marco POR ESCENA,
  no por apertura. No se toca.
- `1C4..1DB` **no se recargan al abrir el bocadillo**: el CG va por escena
  y el texto por apertura. Escribir la linea 2 en `1D4..1DA` no puede
  corromper el marco de los aldeanos, porque su CG se recarga con la
  escena.

RIESGO CONOCIDO (entrada 251 del otro chat)
-------------------------------------------
`$CEE7` carga 8 celdas en `$7400` = `1D0..1D7` y pisa parte de la fila C.
Hoy no falla porque el texto se escribe despues. Con este cambio la linea 2
del abuelo vive en `1D4..1DA`, dentro de ese rango: si esa escena coincide
con un bocadillo del abuelo, habria que recargar. Queda anotado.

Uso:  python3 tools/build_v229.py
"""
import hashlib
import zlib
import subprocess
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

BASE = 'roms/momotaro_es_v225.pce'
SALIDA = 'roms/momotaro_es_v230.pce'
IPS = 'parches/momotaro_v230.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'a1ecc337b9bb1e4f5c5b44dcad45744e'

BASE_PATRON = 0x170
LISTA = 0x47C02
TERMINADOR = 0x47C98
HUECO = 0x47C99
CALC_ALTO = 0x41FE0             # $9FE0
MARCA = 0x3693                  # RAM libre: 1 si toca el abuelo
PTR_LO = 0x41AA0

DX_ABUELO = +8
RAB_DX_EXTRA = -10              # ademas del +8 del cuerpo, para compensar
RAB_DY_EXTRA = +3
COLS = 14


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v227'
    print('base %s  OK' % BASE)
    assert rom[TERMINADOR] == 0xFF, 'no esta el terminador de la compartida'

    # ==================================================================
    # 1. la lista del abuelo: 2 filas, la 2a con borde inferior
    # ==================================================================
    ncel = COLS // 2                       # 7 celdas = 14 caracteres
    X0 = -(ncel * 16) // 2 + DX_ABUELO
    fila1 = [0x1C4 + k for k in range(ncel)]
    fila2 = [0x1D4 + k for k in range(ncel)]
    regs = bytearray()
    for celdas, dY, li, ld in [(fila1, 20, (0x1DC, 0x00), (0x1DC, 0x08)),
                               (fila2, 36, (0x1DD, 0x00), (0x1DD, 0x08))]:
        for k, c in enumerate(celdas):
            regs += bytes([c - BASE_PATRON, 0x0F, 0x00,
                           (X0 + k * 16) & 0xFF, dY & 0xFF])
        ci, fi = li
        regs += bytes([ci - BASE_PATRON, 0x0F, fi,
                       (X0 - 8) & 0xFF, dY & 0xFF])
        cd, fd = ld
        regs += bytes([cd - BASE_PATRON, 0x0F, fd,
                       (X0 + ncel * 16 - 8) & 0xFF, dY & 0xFF])
    regs += b'\xFF'
    nsp = (len(regs) - 1) // 5
    print('\n1. lista del abuelo: %d sprites, 2 filas, alto 32 px' % nsp)
    print('   fila 1 dY=20  %03X..%03X  borde sup + linea 1'
          % (fila1[0], fila1[-1]))
    print('   fila 2 dY=36  %03X..%03X  linea 2 + BORDE INFERIOR'
          % (fila2[0], fila2[-1]))
    print('   ancho %d px  (dX %d..%d)'
          % (8 + ncel * 16 + 8, X0 - 8, X0 + ncel * 16 + 7))

    libre = 0
    while HUECO + libre < 0x48000 and rom[HUECO + libre] == 0xFF:
        libre += 1
    TAB_PTR = HUECO
    LISTA_AB = HUECO + 8
    assert 8 + len(regs) <= libre, 'no cabe'
    rom[LISTA_AB:LISTA_AB + len(regs)] = regs
    p_comp = 0x7C02
    p_ab = 0x6000 + (LISTA_AB - 0x46000)
    p_tabla = 0x6000 + (TAB_PTR - 0x46000)
    for k, p in enumerate([p_comp, p_comp, p_ab, p_comp]):
        rom[TAB_PTR + k * 2] = p & 0xFF
        rom[TAB_PTR + k * 2 + 1] = p >> 8

    # ==================================================================
    # 2. el selector: elige lista Y pone la marca
    # ==================================================================
    SEL = 0x1FA0
    while rom[SEL] != 0xFF:
        SEL += 1
    sel_addr = 0xE000 + SEL
    # Se ensambla con etiquetas y el salto se CALCULA (norma: nunca a mano)
    cuerpo = [
        [0xAD, 0x8F, 0x36],                        # LDA $368F
        [0x0A],                                    # ASL A
        [0xA8],                                    # TAY
        [0xB9, p_tabla & 0xFF, p_tabla >> 8],      # LDA tabla,Y
        [0x85, 0x53],                              # STA $53
        [0xB9, (p_tabla + 1) & 0xFF, (p_tabla + 1) >> 8],
        [0x85, 0x54],                              # STA $54
    ]
    tam = sum(2 if x[0] == 'BNE' else len(x) for x in cuerpo) + 1  # +RTS
    sel = bytearray()
    for x in cuerpo:
        if x[0] == 'BNE':
            rel = tam - 1 - (len(sel) + 2)         # al RTS final
            assert 0 <= rel <= 127, 'salto fuera de rango'
            sel += bytes([0xD0, rel])
        else:
            sel += bytes(x)
    sel.append(0x60)                               # RTS
    assert len(sel) == tam
    libre_sel = 0
    while SEL + libre_sel < 0x1FE0 and rom[SEL + libre_sel] == 0xFF:
        libre_sel += 1
    assert len(sel) <= libre_sel, 'no cabe el selector (%d > %d)' % (
        len(sel), libre_sel)
    rom[SEL:SEL + len(sel)] = sel
    assert rom[PTR_LO - 1] == 0xA9 and rom[PTR_LO] == 0x02, 'emisor raro'
    rom[PTR_LO - 1] = 0x20
    rom[PTR_LO] = sel_addr & 0xFF
    rom[PTR_LO + 1] = sel_addr >> 8
    for k in range(3, 8):
        rom[PTR_LO - 1 + k] = 0xEA
    print('\n2. selector de %d B en $%04X' % (len(sel), sel_addr))
    print('   elige la lista y deja marca en $%04X si es el abuelo' % MARCA)

    # ==================================================================
    # 3. calc_alto: +2 al byte alto en la linea 2 del abuelo
    # ==================================================================
    esp = bytes([0xAD, 0x57, 0x36, 0x3A, 0x02 | 0x27, 0x18, 0x79, 0xBE,
                 0x9B, 0x60])
    real = bytes(rom[CALC_ALTO:CALC_ALTO + 11])
    assert real[:4] == bytes([0xAD, 0x57, 0x36, 0x3A]), \
        '$9FE0 no empieza como espero: %s' % real.hex()
    assert real[4:6] == bytes([0x29, 0x02]), 'falta el AND #$02'
    assert real[6:10] == bytes([0x18, 0x79, 0xBE, 0x9B]), 'falta el ADC'
    assert real[10] == 0x60, 'falta el RTS'
    # $9FE0 son 11 B y detras hay hueco (norma: $9FEB era relleno)
    ALTO2 = 0x1FB0                       # detras del selector, banco $00
    while rom[ALTO2] != 0xFF:
        ALTO2 += 1
    alto_addr = 0xE000 + ALTO2
    nuevo = bytearray([
        0xAD, 0x57, 0x36,               # LDA $3657
        0x3A,                           # DEC A
        0x29, 0x02,                     # AND #$02
        0x18,                           # CLC
        0x79, 0xBE, 0x9B,               # ADC $9BBE,Y
        0x20, alto_addr & 0xFF, alto_addr >> 8,   # JSR extra
        0x60,                           # RTS
    ])
    assert len(nuevo) <= 11 + 5, 'no cabe en $9FE0 (%d B)' % len(nuevo)
    # el hueco tras $9FE0
    h = 0
    while rom[CALC_ALTO + 11 + h] in (0x00, 0xFF, 0xEA):
        h += 1
    print('\n3. calc_alto $9FE0: 11 B + %d B de hueco detras' % h)
    assert 11 + h >= len(nuevo), 'no cabe la version nueva'
    rom[CALC_ALTO:CALC_ALTO + len(nuevo)] = nuevo

    # EL FALLO DE LA v229: use $3693 como marca, y esa direccion NO esta
    # libre: $3692 se indexa con ,Y y cubre $3692..$3699 (norma 163, que
    # yo mismo escribi). Escribir ahi corrompia una tabla del banco $23 y
    # el juego se colgaba al hablar con un aldeano.
    #
    # No hace falta marca: $368F YA tiene la variante durante todo el
    # dibujado. Se lee con X, que esta libre en $9FE0, para no tocar el
    # acumulador (que trae el byte alto ya calculado).
    # OJO: CPX y CPY tocan el CARRY, asi que hay CLC antes del ADC.
    cuerpo_x = [
        [0xAE, 0x8F, 0x36],        # LDX $368F
        [0xE0, 0x02],              # CPX #$02      (2 = abuelo)
        ['BNE'],                   # -> salir
        [0xC0, 0x20],              # CPY #$20      (linea 2)
        ['BCC'],                   # -> salir
        [0x18],                    # CLC           (CPX/CPY lo ensucian)
        [0x69, 0x02],              # ADC #$02
    ]
    tam_x = sum(2 if x[0] in ('BNE', 'BCC') else len(x)
                for x in cuerpo_x) + 1
    extra = bytearray()
    for x in cuerpo_x:
        if x[0] in ('BNE', 'BCC'):
            rel = tam_x - 1 - (len(extra) + 2)
            assert 0 <= rel <= 127, 'salto fuera de rango'
            extra += bytes([0xD0 if x[0] == 'BNE' else 0x90, rel])
        else:
            extra += bytes(x)
    extra.append(0x60)
    extra = bytes(extra)
    assert len(extra) == tam_x
    rom[ALTO2:ALTO2 + len(extra)] = extra
    print('   rutina extra de %d B en $%04X: +2 al alto si abuelo y linea 2'
          % (len(extra), alto_addr))

    # ==================================================================
    # 4. el rabillo: rotado 90 a la izquierda + movido
    # ==================================================================
    from descomp_cg import Flujo, tile, comprime
    import struct as _st

    def rota_izq(celda):
        w = _st.unpack('<64H', celda)
        src = [[0] * 16 for _ in range(16)]
        for y in range(16):
            for x in range(16):
                b = 15 - x
                src[y][x] = ((w[y] >> b) & 1) | (((w[16+y] >> b) & 1) << 1) \
                    | (((w[32+y] >> b) & 1) << 2) | (((w[48+y] >> b) & 1) << 3)
        dst = [[0] * 16 for _ in range(16)]
        for y in range(16):
            for x in range(16):
                dst[15 - x][y] = src[y][x]
        out = [0] * 64
        for y in range(16):
            for x in range(16):
                b = 15 - x
                v = dst[y][x]
                for pl in range(4):
                    if v & (1 << pl):
                        out[pl * 16 + y] |= (1 << b)
        return _st.pack('<64H', *out)

    ptr = rom[0x41C3D] | (rom[0x41C41] << 8)
    cnt = rom[0x41C4F] | (rom[0x41C50] << 8)
    CG = 0x3C000 + (ptr - 0x4000)
    CN = 0x3C000 + (cnt - 0x4000)
    ncg = rom[CN]
    f = Flujo(bytes(rom), CG)
    cel = [b''.join(tile(f) for _ in range(4)) for _ in range(ncg)]
    fincg = f.p
    prim = (rom[0x41C45] | (rom[0x41C4A] << 8)) // 64
    cel[0x1AF - prim] = rota_izq(cel[0x1AD - prim])
    st = comprime(b''.join(cel))
    hu = fincg - CG
    if len(st) > hu:
        ex = len(st) - hu
        lb = 0
        o = CN - 1
        while rom[o] == 0xFF:
            lb += 1
            o -= 1
        assert lb >= ex + 8, 'no hay relleno delante del CG'
        n2 = CG - ex
        c2 = n2 - 1
        assert all(b == 0xFF for b in rom[c2:CN]), 'zona ocupada'
        rom[c2] = ncg
        rom[n2:n2 + len(st)] = st
        pn = 0x4000 + (n2 - 0x3C000)
        cc = 0x4000 + (c2 - 0x3C000)
        rom[0x41C3D] = pn & 0xFF
        rom[0x41C41] = pn >> 8
        rom[0x41C4F] = cc & 0xFF
        rom[0x41C50] = cc >> 8
        CG = n2
    else:
        rom[CG:CG + len(st)] = st
        rom[CG + len(st):fincg] = b'\xFF' * (hu - len(st))
    f3 = Flujo(bytes(rom), CG)
    assert [b''.join(tile(f3) for _ in range(4))
            for _ in range(ncg)] == cel, 'round-trip del CG'
    print('\n4. rabillo rotado 90 a la izquierda (1AD -> 1AF)')

    RAB = 0x41ADD
    p2 = rom[RAB + 4] | (rom[RAB + 5] << 8)
    o2 = 0x40000 + (p2 - 0x8000)
    dx = rom[o2 + 3] - 256 if rom[o2 + 3] > 127 else rom[o2 + 3]
    dy = rom[o2 + 4] - 256 if rom[o2 + 4] > 127 else rom[o2 + 4]
    ndx = dx + RAB_DX_EXTRA
    ndy = dy + RAB_DY_EXTRA
    rom[o2 + 3] = ndx & 0xFF
    rom[o2 + 4] = ndy & 0xFF
    print('\n4. rabillo variante 2: dX %d -> %d,  dY %d -> %d'
          % (dx, ndx, dy, ndy))

    # ==================================================================
    # verificacion
    # ==================================================================
    tmp = '/tmp/_v229.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM')
    for off, nb, carga, nom in [
            (0x41A9B, 16, 0x9A9B, 'emisor'),
            (SEL, len(sel), sel_addr, 'selector'),
            (CALC_ALTO, len(nuevo), 0x9FE0, 'calc_alto'),
            (ALTO2, len(extra), alto_addr, 'suma +2')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % off,
                            str(nb), '%X' % carga], capture_output=True,
                           text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    assert bytes(rom[LISTA:TERMINADOR + 1]) == base[LISTA:TERMINADOR + 1], \
        'SE HA TOCADO LA LISTA COMPARTIDA'
    print('\nlista compartida (aldeanos/Jizo): INTACTA')
    assert bytes(rom[0x41BBD:0x41C05]) == base[0x41BBD:0x41C05], \
        'se ha tocado la tabla de destinos'
    print('tabla de destinos $9BBD: INTACTA (no hizo falta duplicarla)')

    print('\n--- lista del abuelo, releida')
    i = LISTA_AB
    k = 0
    xs = []
    ys = []
    while rom[i] != 0xFF:
        b = rom[i:i + 5]
        dX = b[3] - 256 if b[3] > 127 else b[3]
        dY = b[4] - 256 if b[4] > 127 else b[4]
        xs.append(dX)
        ys.append(dY)
        print('    [%2d] celda %03X  dX=%4d dY=%3d flags=%02X'
              % (k, BASE_PATRON + b[0], dX, dY, b[2]))
        i += 5
        k += 1
    print('    ancho %d px, alto %d px'
          % (max(xs) + 16 - min(xs), max(ys) + 16 - min(ys)))

    intactas = [('fuente', 0x3D660, 0x3E200), ('cabecera', 0x1FE0, 0x2000),
                ('guion', 0x48F91, 0x4A484)]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    print('%d bytes sobre la v225'
          % sum(1 for i in range(len(d)) if d[i] != base[i]))
    open(SALIDA, 'wb').write(d)

    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
