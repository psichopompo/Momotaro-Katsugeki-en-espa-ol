"""build_v145.py - arreglos de FUENTE del menu y de la tilde con sombra.

Parte de test_terminador_v144.pce (MD5 4887028c2f7d33421af89b833075a173).

1. La T de la fuente MENU, 1 px a la izquierda.
   Medido: el cuerpo de la T empieza en x=1; A B C D E ... empiezan en x=0.
   Solo L($01) Y($01) e I($02) comparten sangrado, y son sangrados de diseno
   (la L y la Y son simetricas). La T no: es un error del original.

2. E con tilde GRUESA en el glifo $40 de la fuente MENU.
   $40 esta en la lista de control $AAA3, luego NUNCA se dibuja por la ruta
   de dialogo. Aparece 0 veces en los bloques de texto traducidos y 0 celdas
   del state del menu lo usan. Es un glifo muerto.

3. Sombra en las tildes de la fuente MENU.
   Reportado por un usuario: la tilde de BOTON no tiene sombra. Medido:
   el cuerpo de la tilde esta en las filas 0-1 y el plano de sombra esta a 0
   en esas filas. Se regenera la sombra con el algoritmo ya validado en
   tools/fuente_menu.py: dilatar {(+1,0),(0,+1),(+1,+1)} menos el cuerpo.
"""
import os
import sys
import hashlib
import zlib

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))

BASE = os.path.join(RAIZ, 'roms', 'test_terminador_v144.pce')
SALIDA = os.path.join(RAIZ, 'roms', 'test_menu_v145.pce')
MD5_BASE = '4887028c2f7d33421af89b833075a173'

FUENTE = 0x4000
STRIDE = 16
SOMBRA = ((1, 0), (0, 1), (1, 1))


def off(cod):
    return FUENTE + (cod - 0x30) * STRIDE


def leer(rom, cod):
    o = off(cod)
    return bytearray(rom[o:o + 16])


def a_sets(d16):
    cuerpo, sombra = set(), set()
    for y in range(8):
        for x in range(8):
            m = 0x80 >> x
            if d16[y] & m:
                cuerpo.add((x, y))
            if d16[8 + y] & m:
                sombra.add((x, y))
    return cuerpo, sombra


def empaqueta(cuerpo, sombra):
    out = bytearray(16)
    for y in range(8):
        b = s = 0
        for x in range(8):
            if (x, y) in cuerpo:
                b |= 0x80 >> x
            if (x, y) in sombra:
                s |= 0x80 >> x
        out[y] = b
        out[8 + y] = s
    return out


def con_sombra(cuerpo):
    s = set()
    for (x, y) in cuerpo:
        for dx, dy in SOMBRA:
            s.add((x + dx, y + dy))
    s = {p for p in s - cuerpo if 0 <= p[0] < 8 and 0 <= p[1] < 8}
    return s


def main():
    rom = bytearray(open(BASE, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la ROM base no es la v144'
    assert len(rom) == 512 * 1024

    cambios = []

    # ---------- 1. la T, 1 px a la izquierda ----------
    d = leer(rom, 0x54)
    cuerpo, sombra = a_sets(d)
    assert min(x for x, y in cuerpo) == 1, 'la T ya no empieza en x=1'
    cuerpo = {(x - 1, y) for x, y in cuerpo}
    sombra = con_sombra(cuerpo)
    nueva = empaqueta(cuerpo, sombra)
    rom[off(0x54):off(0x54) + 16] = nueva
    cambios.append(('T $54', off(0x54)))

    # ---------- 2. E con tilde gruesa en $40 ----------
    viejo = leer(rom, 0x40)
    assert viejo != bytearray(16), '$40 esperado con contenido'
    arte = [
        '...##...',
        '..##....',
        '######..',
        '##......',
        '#####...',
        '##......',
        '######..',
        '........',
    ]
    cuerpo = {(x, y) for y, f in enumerate(arte)
              for x, c in enumerate(f) if c == '#'}
    nueva = empaqueta(cuerpo, con_sombra(cuerpo))
    rom[off(0x40):off(0x40) + 16] = nueva
    cambios.append(('E-acentuada $40', off(0x40)))

    # ---------- 3. sombra en las tildes ----------
    # Lista EXPLICITA de los glifos acentuados que hemos anadido nosotros.
    # No se hace por deteccion automatica: la A, el 3 y el 5 llevan la
    # sombra recortada A MANO por el grafista (documentado en
    # tools/fuente_menu.py) y regenerarla los estropearia.
    ACENTUADOS = (0x5B,)      # $5B = O con tilde (v-anteriores)
    reparados = []
    for cod in ACENTUADOS:
        d = leer(rom, cod)
        cuerpo, sombra = a_sets(d)
        falta = con_sombra(cuerpo) - sombra
        if not falta:
            continue
        nueva = empaqueta(cuerpo, sombra | falta)
        rom[off(cod):off(cod) + 16] = nueva
        reparados.append('$%02X (+%d px)' % (cod, len(falta)))
    cambios.append(('tildes con sombra', reparados))

    # ---------- verificacion ----------
    d = leer(rom, 0x54)
    c, s = a_sets(d)
    assert min(x for x, y in c) == 0, 'la T no se movio'
    d = leer(rom, 0x40)
    c, s = a_sets(d)
    assert (3, 0) in c and (2, 2) in c, 'la E acentuada no se escribio'
    assert s, 'la E acentuada quedo sin sombra'

    open(SALIDA, 'wb').write(bytes(rom))
    md5 = hashlib.md5(rom).hexdigest()
    print('escrito', SALIDA)
    print('MD5 ', md5)
    print('SHA1', hashlib.sha1(rom).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
    for c in cambios:
        print('  ', c)


if __name__ == '__main__':
    main()
