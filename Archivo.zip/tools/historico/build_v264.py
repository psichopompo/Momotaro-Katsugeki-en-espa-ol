#!/usr/bin/env python3
"""
build_v264.py - la 'p' de "Capa". El atasco de tres versiones, resuelto.

LA CAUSA
========
No hacia falta ninguna teoria nueva: **la respuesta ya estaba en el informe
v202->v225, seccion 3.3**, y se paso por alto al retomar el problema.

Hay una TABLA DE SUSTITUCION PREVIA en `$AB34` que intercepta el codigo
ANTES de que llegue a la tabla de fuente. Son dos arrays paralelos de 7
bytes, no pares intercalados (por eso al volcarlos "en pares" salia ruido):

```
origen  0x42B4C:  20 21 2D B0 A2 A3 24
destino 0x42B54:  3C 5C 5F 5F 5B 5D 3E
                        ^^
                        $B0 -> $5F
```

**`$B0` (la 'p') se convierte en `$5F`.** Y despues, `$CB1B` decide la ruta:

```
si (cod - $30) < $54  ->  ruta BAJA: idx = rom[0x43F9B + cod - $30]
si no                 ->  ruta ALTA: idx = rom[0x41C73 + cod - $20]
```

LA CADENA COMPLETA EXPLICA LOS DOS EXPERIMENTOS
-----------------------------------------------
```
v260:  $B0 -> sust -> $5F -> ruta BAJA -> glifo $DE     David vio $DE  OK
v261:  $70 -> (sin sust)  -> ruta BAJA -> glifo $EA     David vio $EA  OK
```

Los dos resultados que "ninguna tabla explicaba" salen de la misma cadena.
Lo que fallaba era el modelo, no los datos.

EL ARREGLO
==========
Barrido de los 224 codigos posibles: **solo `$5E` produce el glifo `$B0`**
(la 'p'), y ademas no lo intercepta la tabla de sustitucion.

Y ese alias **ya estaba documentado** en el propio informe:

> RUTA A (canto): alias SOLO aqui: b=$5B  c=$5D  p=$5E

La nota decia "solo aqui", pero el menu usa la misma ruta baja. De ahi el
malentendido.

```
0x43143:  $B0 -> $5E
```

EL ESPACIO FINAL
================
David: *«Los espacios vacios al final de los nombres de los objetos no son
viables. En el menu SELECT esos espacios aparecen como un cuadrado negro.»*

Medido: `$20` -> sustitucion -> `$3C` -> ruta baja -> glifo `$00`. Y el
glifo `$00` de la fuente no esta en blanco: pinta un cuadrado.

Se quita el `$20` que la v263 metio al final de "Capa" y se recorta la
cadena. El byte que queda libre se deja a `$00` (terminador), sin mover
nada mas.

Uso:  python3 tools/build_v264.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v263.pce'
SALIDA = 'roms/momotaro_es_v264.pce'
IPS = 'parches/momotaro_v264.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '202f73d747a931e1d4faec4265783c3b'

CAPA = 0x43140                  # la cadena "Capa " del inventario
SUB_O, SUB_D = 0x42B4C, 0x42B54
T_BAJA = 0x43F9B
T0 = 0x41C73


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v263'
    print('base %s  OK' % BASE)

    # --- el modelo, reconstruido y verificado -------------------------
    sub = dict(zip(rom[SUB_O:SUB_O + 7], rom[SUB_D:SUB_D + 7]))
    assert sub.get(0xB0) == 0x5F, \
        'la tabla de sustitucion no mapea $B0 -> $5F'

    def glifo(cod):
        c = sub.get(cod, cod)
        if 0x30 <= c and c - 0x30 < 0x54:
            return rom[T_BAJA + c - 0x30]
        return rom[T0 + c - 0x20]

    # los dos experimentos de David, como test del modelo
    assert glifo(0xB0) == 0xDE, 'el modelo no reproduce la v260'
    assert glifo(0x70) == 0xEA, 'el modelo no reproduce la v261'
    print('\nmodelo verificado contra los dos experimentos:')
    print('   $B0 -> sust $5F -> ruta baja -> glifo $DE   (v260, David vio $DE)')
    print('   $70 -> ruta baja           -> glifo $EA   (v261, David vio $EA)')

    # --- que codigo da la 'p' -----------------------------------------
    sol = [c for c in range(0x20, 0x100) if glifo(c) == 0xB0]
    assert sol == [0x5E], 'esperaba solo $5E, salen %s' % [hex(c) for c in sol]
    print('\ncodigos que producen el glifo $B0 (la p): %s'
          % ' '.join('$%02X' % c for c in sol))

    # --- la cadena actual ---------------------------------------------
    esp = bytes([0x01, 0x43, 0xA1, 0xB0, 0xA1, 0x20, 0x00])
    assert bytes(rom[CAPA:CAPA + 7]) == esp, \
        'la cadena de 0x43140 no es la esperada: %s' % bytes(
            rom[CAPA:CAPA + 7]).hex()
    print('\ncadena actual en 0x%05X: %s' % (CAPA, esp.hex(' ')))
    for k, b in enumerate(esp):
        if b in (0x00, 0x01, 0x02):
            print('   [%d] $%02X  control' % (k, b))
        else:
            print('   [%d] $%02X -> glifo $%02X' % (k, b, glifo(b)))

    # --- 1. la p -------------------------------------------------------
    rom[CAPA + 3] = 0x5E
    print('\n1. 0x%05X: $B0 -> $5E   (la p, por fin)' % (CAPA + 3))

    # --- 2. fuera el espacio final -------------------------------------
    assert glifo(0x20) == 0x00, 'el $20 no da el glifo $00'
    print('2. el espacio final $20 da el glifo $00, que PINTA un cuadrado')
    rom[CAPA + 5] = 0x00        # terminador donde estaba el espacio
    rom[CAPA + 6] = 0x00        # el hueco que queda, a cero
    print('   0x%05X: $20 -> $00 (terminador); 0x%05X a $00'
          % (CAPA + 5, CAPA + 6))

    # --- verificacion ---------------------------------------------------
    print('\ncadena nueva: %s' % bytes(rom[CAPA:CAPA + 7]).hex(' '))
    txt = ''
    for b in rom[CAPA:CAPA + 7]:
        if b == 0x00:
            break
        if b in (0x01, 0x02):
            continue
        g = glifo(b)
        txt += {0x72: 'C', 0xA1: 'a', 0xB0: 'p'}.get(g, '<%02X>' % g)
    print('se leera: %r' % txt)
    assert txt == 'Capa', 'la cadena no se lee "Capa" sino %r' % txt

    # nada mas puede haber cambiado
    dif = [i for i in range(len(rom)) if rom[i] != base[i]]
    # 0x43146 ya era $00, asi que solo cambian dos bytes
    assert set(dif) <= {CAPA + 3, CAPA + 5, CAPA + 6}, \
        'cambios inesperados: %s' % ['%05X' % x for x in dif]
    print('\n%d bytes sobre la v263: %s'
          % (len(dif), ' '.join('0x%05X' % x for x in dif)))

    # zonas que no se tocan, por si acaso
    intactas = [
        ('codigo CPY #$03/CMP #$B3', 0x43439, 0x43440),
        ('tabla de sustitucion', SUB_O, SUB_O + 16),
        ('tabla baja', T_BAJA, T_BAJA + 0x54),
        ('tabla T0', T0, T0 + 0x100),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('intactas: %s' % ', '.join(n for n, _, _ in intactas))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
