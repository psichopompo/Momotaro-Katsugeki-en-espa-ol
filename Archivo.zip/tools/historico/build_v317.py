#!/usr/bin/env python3
"""build_v317.py - Nombres de las TECNICAS + dos correcciones de traduccion.

QUE ENTRA
---------
1. Los **14 nombres de tecnica** (`0x4AE86..0x4AEE6`), opcion A de David.
2. `¿Jugamos, majo?` -> `¿Te animas?`   (el «majo» no estaba en el original)
3. `¡Bah, qué sosa!` -> `¡Qué rácano!`  (genero y significado, los dos mal)

   El documento llego a decir «¡Bah, que cutre!» en un paso intermedio,
   pero en la ROM v316 lo que hay es «¡Bah, que sosa!»: el assert de byte
   esperado lo cazo al primer intento.

EL BLOQUE DE TECNICAS ES SECUENCIAL
-----------------------------------
No hay tabla de punteros: verificado que los 14 inicios reales no aparecen
en la ROM ni como bytes bajos, ni altos, ni words. El motor cuenta
terminadores `$00`, asi que el reparto entre cadenas es LIBRE y lo unico
fijo es el total.

    bloque 0x4AE86..0x4AEE6            = 96 B
    suma de las 14 japonesas + sus $00 = 96 B   cuadra al byte
    las 14 castellanas + sus $00       = 92 B   sobran 4

Los 4 B sobrantes se rellenan con `$A0` AL FINAL, sin mover el inicio ni el
final del bloque: el byte `0x4AEE6` (primer byte del quiz) queda intacto.

POR QUE NO SE USAN LOS 11 B DE DELANTE
--------------------------------------
Los dos bloques del ermitanyo liberan 11 B, pero estan DELANTE de la lista.
Aprovecharlos exigiria arrancarla en `0x4AE7B`, o sea **mover su inicio**, y
no se sabe como llega el motor hasta ella (no hay tabla ni `LDA #$86`).
Es el error de la v237 y no se repite. Presupuesto real: 96 B.
"""
import hashlib
import re
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode, RELLENO   # noqa: E402

BASE = 'roms/momotaro_es_v316.pce'
DOC = 'docs/MAQUETACION_minijuegos.md'
SALIDA = 'roms/momotaro_es_v317.pce'
MD5_BASE = '834afa5be5f535fea56032d065eb62dd'

TEC_INI = 0x4AE86
TEC_FIN = 0x4AEE6          # primer byte del quiz, INTOCABLE
COLS = 16

# Las dos frases a corregir: (offset del bloque, linea, texto viejo, nuevo)
CORRECCIONES = [
    (0x4AC9C, 0, '¿Jugamos, majo?', '¿Te animas?'),
    (0x4AD22, 1, '¡Bah, qué sosa!', '¡Qué rácano!'),
]

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x16000, 0x18000, 'banco $0B: tablas de los vitores'),
    (0x1E000, 0x20000, 'banco $0F: tabla de escenas (arreglo v314)'),
    (0x48000, 0x4A000, 'banco $24: tiendas, guion, vitores'),
    (0x4AE3B, 0x4AE86, 'los 2 bloques del ermitanyo'),
    (0x4AEE6, 0x4C000, 'el QUIZ y el resto del banco $25'),
]


def lee_tecnicas(path):
    """Saca los 14 nombres de la tabla del documento."""
    t = open(path, encoding='utf-8').read()
    m = re.search(r'TEC = (.+?)\n\s+(.+?)\n', t)
    assert m, 'no encuentro el bloque TEC en el documento'
    ns = (m.group(1) + ' ' + m.group(2)).split()
    assert len(ns) == 14, 'esperaba 14 tecnicas, hay %d' % len(ns)
    return ns


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v316'

    # ---------- 1. las tecnicas -----------------------------------------
    nombres = lee_tecnicas(DOC)

    # el bloque japones tiene que sumar exactamente lo que ocupa
    p = TEC_INI
    n_jap = 0
    while p < TEC_FIN:
        e = original.find(b'\x00', p)
        assert 0 < e - p < 40, 'cadena japonesa rara en %06X' % p
        p = e + 1
        n_jap += 1
    assert p == TEC_FIN, 'las cadenas japonesas no acaban en %06X' % TEC_FIN
    assert n_jap == 14, 'hay %d cadenas japonesas, no 14' % n_jap

    datos = bytearray()
    for s in nombres:
        datos += encode(s) + b'\x00'
    presupuesto = TEC_FIN - TEC_INI
    assert len(datos) <= presupuesto, \
        'las tecnicas ocupan %d B y solo hay %d' % (len(datos), presupuesto)
    sobra = presupuesto - len(datos)
    datos += bytes([RELLENO]) * sobra
    assert len(datos) == presupuesto
    rom[TEC_INI:TEC_FIN] = datos

    # ---------- 2. las dos correcciones ---------------------------------
    for off, nlin, viejo, nuevo in CORRECCIONES:
        pos = off + nlin * COLS
        esperado = encode(viejo) + bytes([RELLENO]) * (COLS - len(viejo))
        assert rom[pos:pos + COLS] == esperado, \
            'en %06X no esta «%s»' % (pos, viejo)
        assert len(nuevo) <= COLS, '«%s» son %d columnas' % (nuevo, len(nuevo))
        rom[pos:pos + COLS] = encode(nuevo) + bytes([RELLENO]) * (COLS - len(nuevo))

    # ---------- VERIFICACION: releer como lo hace el motor ---------------
    # las 14 tecnicas, contando terminadores desde la base
    p = TEC_INI
    leidas = []
    for _ in range(14):
        e = rom.find(b'\x00', p)
        assert 0 < e - p < 40, 'cadena %d sin terminador' % len(leidas)
        leidas.append(rom[p:e])
        p = e + 1
    assert leidas == [encode(s) for s in nombres], \
        'lo releido no coincide con el documento'
    assert p <= TEC_FIN, 'las 14 cadenas se salen del bloque'
    # lo que queda hasta el quiz es relleno
    assert all(b == RELLENO for b in rom[p:TEC_FIN]), \
        'la cola del bloque no es relleno limpio'
    # el quiz empieza donde empezaba
    assert rom[TEC_FIN] == original[TEC_FIN], 'se ha tocado el primer byte del quiz'

    # los dos bloques corregidos siguen consumiendo 32 B visibles
    def hueco(data, off, cols=COLS, filas=2):
        q = off
        for _ in range(filas):
            k = 0
            while k < cols:
                b = data[q]
                q += 1
                if b not in (0x5C, 0xDE, 0xDF):
                    k += 1
        return q - off
    for off, _n, _v, _nu in CORRECCIONES:
        assert hueco(rom, off) == 32, '%06X ya no consume 32 B' % off

    # ---------- zonas intactas -------------------------------------------
    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = [i for i in range(len(rom)) if rom[i] != original[i]]
    zonas = [(TEC_INI, TEC_FIN)] + [(o + n * COLS, o + n * COLS + COLS)
                                    for o, n, _v, _nu in CORRECCIONES]
    assert all(any(a <= d < b for a, b in zonas) for d in dif), \
        'hay bytes fuera de las zonas previstas'

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % len(dif))
    print()
    print('  TECNICAS  %d B de %d, %d de relleno' % (len(datos) - sobra, presupuesto, sobra))
    p = TEC_INI
    for i, s in enumerate(nombres):
        print('    [%2d] %06X  %-10s %d B' % (i, p, s, len(s)))
        p += len(s) + 1
    print()
    for off, n, v, nu in CORRECCIONES:
        print('  %06X L%d  «%s» -> «%s»' % (off, n + 1, v, nu))


if __name__ == '__main__':
    main()
