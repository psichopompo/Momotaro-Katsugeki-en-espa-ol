#!/usr/bin/env python3
"""
build_v194.py - los cuatro fallos de la v193.

1. LA PRIMERA PAGINA PERDIA DOS LINEAS
--------------------------------------
> «El dialogo del primer aldeano empieza directamente por "II podras atacar
>  / a los ogros...". Faltan las dos primeras lineas.»

El clon `$9952` (que pinta la PRIMERA pagina) seguia en **2 lineas**
(`$99BA CMP #$02`). Escribia las lineas 1-2, volcaba, y al pulsar boton el
motor `$9807` continuaba por la 3 y la 4... pero `$97EE` recarga el CG en
cada pagina (v189) y **borraba** lo que habia pintado el clon.

Se convierte el clon a 4 lineas con volcado por mitades, igual que el motor:

```
$99B4  INC $3657 / LDA $3657
       CMP #$04 / BCS fin
       CMP #$02 / BNE $9976        (sigue en la misma mitad)
       JSR $9ACD                    vuelca la fila A, limpia, rehace MPR2
       CLX                          X=0 para la segunda mitad
       BRA $9976
fin:   JSR $9B7C / PLA / TAM #$08 / PLX / RTS
```

El sitio sale de **reciclar dos trozos muertos** del propio clon:

```
$999A..$99A7  PHX/TXA/SEC/SBC #$00/TAX/LDA $10/STA $3667,X/PLX
              el SBC #$00 no resta nada (era #$06 y lo puse a 0 en la v184),
              asi que todo equivale a STA $3667,X   -> sobran 11 B
$99AF..$99B3  TXA/CLC/ADC #$00/TAX  -> no hace nada -> sobran 5 B
```

2. LA MAQUETACION DESAPROVECHABA EL ANCHO
------------------------------------------
> «en varias lineas queda bastante espacio y la linea siguiente comienza con
>  una simple preposicion "a" o "de" que podria ir perfectamente arriba»

`maquetar.py` usa Knuth-Plass: minimiza la suma de los huecos **al
cuadrado**, lo que reparte el aire entre todas las lineas en vez de apretar
arriba. Eso esta bien para un parrafo suelto, pero David quiere lo contrario:
llenar cada linea.

Se cambia a reparto **voraz** (meter palabras hasta que no quepan) y se mide:

```
                    paginas  lineas  hueco medio
Knuth-Plass (v193)    198      650      3.06
voraz (v194)          193      614      2.31
```

3. EL BORDE INFERIOR TAMBIEN ROBABA SCANLINES
----------------------------------------------
> «me he dado cuenta de que el borde inferior del bocadillo tambien deja ese
>  espacio vacio en sus sprites»

Cierto, y David tiene razon en discrepar: **subir el bocadillo si ayuda
aqui**, pero no por lo que el pensaba. Las celdas `19E/19F/1AE` (borde
inferior) solo dibujan sus **7 primeras filas**; las 9 de abajo estan
vacias y gastan ranura hasta 9 px por debajo del bocadillo.

Mismo arreglo que el rabillo: mover el dibujo al fondo de la celda y subir
el sprite lo mismo. El bocadillo se ve **exactamente igual** y libera 9
scanlines.

4. EL INTERLINEADO
------------------
> «Creo que si entre cada linea hubiera 1 px mas de separacion, el texto
>  respiraria mejor.»

**No se puede sin rehacer la fuente.** El motor escribe cada glifo en un
cuadrante fijo de 8x8 de la celda (`$3665` elige mitad izquierda/derecha y
arriba/abajo), asi que las lineas van cada 8 px exactos. Para separarlas 9
habria que cambiar el modelo entero de direccionamiento.

Lo que SI se puede: la fuente ocupa 8 filas y **la ultima esta vacia en casi
todos los glifos**. Si se sube el dibujo una fila en los que tienen hueco
arriba, se gana el pixel visualmente. Es un cambio de la fuente, no del
motor, y toca 200+ glifos: **se deja para un paso propio**, con muestra
antes.

Uso:  python3 tools/build_v194.py
"""
import hashlib
import zlib
import struct
import sys
import os
import re

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime
from charset_oficial import CHAR_TO_CODE
import guion_v192
from guion_v192 import leer, off, punteros
import comprime_guion

BASE = 'roms/momotaro_es_v193.pce'
SALIDA = 'roms/momotaro_es_v194.pce'
IPS = 'parches/momotaro_v194.ips'
MD5_BASE = 'f7b3dd2a7758be6d8f004dfe52b56dff'

COD = dict(CHAR_TO_CODE)
COD['b'], COD['c'], COD['p'] = 0xA2, 0xA3, 0xB0
COD['\n'] = 0x3B
INV = {v: k for k, v in CHAR_TO_CODE.items()}
INV[0xA2], INV[0xA3], INV[0xB0] = 'b', 'c', 'p'

CLON = 0x4199A            # $999A, zona a reescribir (hasta $99C5)
CLON_FIN = 0x419C6
CG_INI = 0x3D3F8          # donde lo dejo la v193
LISTA = 0x47C02
PUNTEROS = 0x48000
TABLA_DIC = 0x4BA13
HUECOS = [(0x48F91, 0x4A484), (0x4BA13, 0x4BF40), (0x4BF40, 0x4C000)]
COLS, LINEAS = 16, 4


def setp(c, x, y, col):
    w = list(struct.unpack('<64H', bytes(c)))
    b = 15 - x
    for p in range(4):
        if (col >> p) & 1:
            w[p * 16 + y] |= 1 << b
        else:
            w[p * 16 + y] &= ~(1 << b) & 0xFFFF
    c[:] = struct.pack('<64H', *w)


def getp(c, x, y):
    w = struct.unpack('<64H', bytes(c))
    b = 15 - x
    return ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
        | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)


def voraz(texto, ancho, por_pagina):
    """Reparto que LLENA cada linea, no el equilibrado de Knuth-Plass."""
    lineas, act = [], ''
    for pal in texto.split():
        if not act:
            act = pal
        elif len(act) + 1 + len(pal) <= ancho:
            act += ' ' + pal
        else:
            lineas.append(act)
            act = pal
    if act:
        lineas.append(act)
    return [lineas[i:i + por_pagina] for i in range(0, len(lineas), por_pagina)]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v193 (md5 %s)' % md5
    orig = bytes(rom)

    # ==================================================================
    # 1. EL CLON A 4 LINEAS
    # ==================================================================
    esperado = bytes([
        0x85, 0x10, 0xDA, 0x8A, 0x38, 0xE9, 0x00, 0xAA, 0xA5, 0x10,
        0x9D, 0x67, 0x36, 0xFA,                       # $999A..$99A7
        0xAD, 0x58, 0x36, 0xC9, 0x10, 0x90, 0xCA,     # $99A8..$99AE
        0x8A, 0x18, 0x69, 0x00, 0xAA,                 # $99AF..$99B3
        0xEE, 0x57, 0x36, 0xAD, 0x57, 0x36, 0xC9, 0x02, 0x90, 0xB8,
        0x20, 0x7C, 0x9B, 0x68, 0x53, 0x08, 0xFA, 0x60])
    assert bytes(rom[CLON:CLON_FIN]) == esperado, \
        'el clon no es el de la v193: %s' % bytes(rom[CLON:CLON_FIN]).hex()

    L = 0x999A
    p = []

    def emit(*b):
        p.extend(b)

    # $999A  rama del caracter ancho: equivale a STA $3667,X
    emit(0x85, 0x10)                    # STA $10
    emit(0xA5, 0x10)                    # LDA $10   (deja A como estaba)
    emit(0x9D, 0x67, 0x36)              # STA $3667,X
    off_a8 = len(p)                     # aqui empieza lo que era $99A8
    emit(0xAD, 0x58, 0x36)              # LDA $3658
    emit(0xC9, COLS)                    # CMP #$10
    pos_bcc = len(p)
    emit(0x90, 0x00)                    # BCC $9979
    emit(0xEE, 0x57, 0x36)              # INC $3657
    emit(0xAD, 0x57, 0x36)              # LDA $3657
    emit(0xC9, LINEAS)                  # CMP #$04
    pos_bcs = len(p)
    emit(0xB0, 0x00)                    # BCS fin
    emit(0xC9, LINEAS // 2)             # CMP #$02
    pos_bne = len(p)
    emit(0xD0, 0x00)                    # BNE $9976
    emit(0x20, 0xCD, 0x9A)              # JSR $9ACD  vuelca fila A
    emit(0x82)                          # CLX
    pos_bra = len(p)
    emit(0x80, 0x00)                    # BRA $9976
    lab_fin = len(p)
    emit(0x20, 0x7C, 0x9B)              # JSR $9B7C  vuelca la fila B
    emit(0x68, 0x53, 0x08)              # PLA / TAM #$08
    emit(0xFA, 0x60)                    # PLX / RTS

    def rel(pos, destino):
        d = destino - (L + pos + 2)
        assert -128 <= d <= 127, 'salto fuera de rango: %d' % d
        p[pos + 1] = d & 0xFF

    rel(pos_bcc, 0x9979)
    rel(pos_bne, 0x9976)
    rel(pos_bra, 0x9976)
    rel(pos_bcs, L + lab_fin)

    assert len(p) <= CLON_FIN - CLON, \
        'el clon nuevo mide %d B y hay %d' % (len(p), CLON_FIN - CLON)
    # la entrada por BCS $999A desde $997E sigue cayendo en el sitio bueno
    rom[CLON:CLON + len(p)] = bytes(p)
    for k in range(CLON + len(p), CLON_FIN):
        rom[k] = 0xEA                     # NOP de relleno
    print('clon $9952 -> 4 lineas con volcado por mitades (%d B de %d)'
          % (len(p), CLON_FIN - CLON))
    print('  reciclados los trozos muertos $999A-$99A7 y $99AF-$99B3')

    # el BCS $999A de $997E tiene que seguir apuntando aqui
    assert bytes(rom[0x4197E:0x41980]) == bytes([0xB0, 0x1A]), \
        'el BCS de $997E cambio'
    assert 0x997E + 2 + 0x1A == 0x999A

    # ==================================================================
    # 2. EL BORDE INFERIOR: dibujo al fondo de la celda
    # ==================================================================
    f = Flujo(rom, CG_INI)
    cg = [bytearray(b''.join(tile(f) for _ in range(4))) for _ in range(20)]

    for celda in (0x19E, 0x19F, 0x1AE):
        c = cg[celda - 0x19C]
        filas = [y for y in range(16) if any(getp(c, x, y) for x in range(16))]
        assert filas and filas[0] == 0, \
            'la celda %03X no empieza a dibujar en la fila 0' % celda
        d = 15 - max(filas)
        copia = [[getp(c, x, y) for x in range(16)] for y in range(16)]
        for y in range(16):
            for x in range(16):
                setp(c, x, y, copia[y - d][x] if y >= d else 0)
        print('  celda %03X: dibujo de las filas 0..%d a %d..15 (+%d)'
              % (celda, max(filas), d, d))
        DESP_INF = d

    stream = b''.join(comprime(bytes(c)) for c in cg)
    ini = 0x3D660 - len(stream)
    assert ini - 1 >= 0x3D3D4, 'el CG no cabe'
    rom[ini:0x3D660] = stream
    rom[ini - 1] = 20
    rom[0x3D3D4:ini - 1] = b'\xFF' * (ini - 1 - 0x3D3D4)
    lg = 0x4000 + (ini - 0x3C000)
    rom[0x41C3D] = lg & 0xFF
    rom[0x41C41] = lg >> 8
    lc = 0x4000 + (ini - 1 - 0x3C000)
    rom[0x41C4F] = lc & 0xFF
    rom[0x41C50] = lc >> 8
    print('  CG: %d B en 0x%05X' % (len(stream), ini))

    # bajar los sprites del borde inferior lo mismo que subio el dibujo
    i = LISTA
    n = 0
    while rom[i] != 0xFF:
        celda = 0x170 + rom[i]
        if celda in (0x19E, 0x19F, 0x1AE):
            dy = rom[i + 4]
            sdy = dy - 256 if dy > 127 else dy
            rom[i + 4] = (sdy - DESP_INF) & 0xFF
            n += 1
        i += 5
    print('  %d sprites del borde inferior: dY -%d (se ven igual)'
          % (n, DESP_INF))

    # ==================================================================
    # 3. LA MAQUETACION VORAZ
    # ==================================================================
    ps = punteros(orig)
    uniq = []
    for q in ps:
        if q not in uniq:
            uniq.append(q)
    textos = []
    for q in uniq:
        d, _ = leer(orig, off(q))
        falta = sorted({x for x in d if x != 0x3B and x not in INV})
        assert not falta, 'codigos raros: %s' % [hex(x) for x in falta]
        s = ''.join(' ' if x == 0x3B else INV[x] for x in d)
        textos.append(re.sub(r'\s+', ' ', s).strip())

    import maquetar
    hk = [maquetar.maquetar(t, COLS, LINEAS) for t in textos]
    vz = [voraz(t, COLS, LINEAS) for t in textos]

    # OJO: el numero de lineas y el hueco TOTAL salen iguales con los dos
    # metodos (el texto es el mismo y el ancho tambien); lo que cambia es
    # DONDE queda el hueco. Lo que David pide es que no haya una linea con
    # 6-8 huecos seguida de otra que empieza con "a" o "de", asi que la
    # metrica buena es cuantas lineas quedan MUY cortas pudiendo no serlo.
    def mide(pags):
        hu = [COLS - len(l) for pg in pags for l in pg]
        # solo cuentan las lineas que NO son la ultima de su parrafo
        cortas = 0
        todas = [l for pg in pags for l in pg]
        for k, l in enumerate(todas[:-1]):
            hueco = COLS - len(l)
            siguiente = todas[k + 1].split()[0] if todas[k + 1] else ''
            if hueco >= len(siguiente) + 1:
                cortas += 1
        return len(pags), len(hu), sum(hu), cortas
    a = [mide(x) for x in hk]
    b = [mide(x) for x in vz]
    print('\nmaquetacion   paginas  lineas  hueco  lineas que podrian')
    print('                                       llevar la palabra')
    print('                                       siguiente')
    for nom, m in (('Knuth-Plass', a), ('voraz', b)):
        print('  %-12s %4d    %4d   %5d      %d'
              % (nom, sum(x[0] for x in m), sum(x[1] for x in m),
                 sum(x[2] for x in m), sum(x[3] for x in m)))
    difs = sum(1 for x, y in zip(hk, vz) if x != y)
    print('  (los dos repartos difieren en %d de los %d textos)'
          % (difs, len(hk)))

    maq = []
    for pags in vz:
        for pg in pags:
            for l in pg:
                assert len(l) <= COLS, 'linea de %d: %r' % (len(l), l)
        maq.append('\n'.join('\n'.join(pg) for pg in pags))

    ent = comprime_guion.elegir(maq, 48, 3, 24)
    assert not any(comprime_guion.MARCA in e for e in ent)
    cadenas = [comprime_guion.codifica(t, ent, COD) + b'\x00' for t in maq]

    def expande(bb):
        out = bytearray()
        for x in bb[:-1]:
            if 0x60 <= x <= 0x8F:
                for ch in ent[x - 0x60]:
                    out.append(COD[ch])
            else:
                out.append(x)
        return bytes(out)
    for k, (c, m) in enumerate(zip(cadenas, maq)):
        assert expande(c) == bytes(COD[ch] for ch in m), 'round-trip %d' % k

    datos = bytearray()
    off_ent = []
    for e in ent:
        off_ent.append(len(datos))
        datos += bytes(COD[ch] for ch in e) + b'\x00'
    total = sum(len(c) for c in cadenas) + len(datos) + 96
    cap = sum(y - x for x, y in HUECOS)
    print('  cadenas %d + diccionario %d + tabla 96 = %d (caben %d)'
          % (sum(len(c) for c in cadenas), len(datos), total, cap))
    assert total <= cap, 'no cabe por %d B' % (total - cap)

    for x, y in HUECOS:
        rom[x:y] = b'\x00' * (y - x)
    libre = [[x, y] for x, y in HUECOS]

    def reservar(nn):
        for h in libre:
            if h[1] - h[0] >= nn:
                o = h[0]
                h[0] += nn
                return o
        raise AssertionError('sin sitio para %d B' % nn)

    h = [x for x in libre if x[0] == TABLA_DIC]
    assert h, 'el hueco del diccionario no empieza en $7A13'
    base_tabla = h[0][0]
    h[0][0] += 96
    o_datos = reservar(len(datos))
    rom[o_datos:o_datos + len(datos)] = datos
    for k, dd in enumerate(off_ent):
        aa = guion_v192.off.__wrapped__(o_datos + dd) if False else None
    B24, B25 = 0x48000 - 0x4000, 0x4A000 - 0x6000

    def logdir(o):
        return o - B24 if o < 0x4A000 else o - B25
    for k, dd in enumerate(off_ent):
        aa = logdir(o_datos + dd)
        rom[base_tabla + k * 2] = aa & 0xFF
        rom[base_tabla + k * 2 + 1] = aa >> 8
    pos = {}
    for k, c in enumerate(cadenas):
        o = reservar(len(c))
        rom[o:o + len(c)] = c
        pos[uniq[k]] = logdir(o)
    for k, q in enumerate(ps):
        aa = pos[q]
        rom[PUNTEROS + k * 2] = aa & 0xFF
        rom[PUNTEROS + k * 2 + 1] = aa >> 8

    import importlib
    importlib.reload(guion_v192)
    for k, q in enumerate(ps):
        aa = rom[PUNTEROS + k * 2] | (rom[PUNTEROS + k * 2 + 1] << 8)
        d, _ = guion_v192.leer(bytes(rom), guion_v192.off(aa))
        s = ''.join('\n' if x == 0x3B else INV[x] for x in d)
        assert s == maq[uniq.index(q)], 'el texto %d no se relee' % k
    print('  releidos los 116 punteros: OK')

    # ==================================================================
    intactas = [
        ('vitores', 0x480E8, 0x48C71),
        ('dinero', 0x48C71, 0x48F91),
        ('final y creditos', 0x4A484, 0x4A7B9),
        ('enemigos', 0x4A7B9, 0x4AE8A),
        ('artes', 0x4AE8A, 0x4AEE6),
        ('quiz', 0x4AEE6, 0x4B8C0),
        ('jan-ken-pon', 0x4B8C0, 0x4B93B),
        ('descompresor', 0x4B93B, 0x4BA13),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, x, y in intactas:
        assert rom[x:y] == orig[x:y], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    rec = []
    i = 0
    while i < len(dif):
        x = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        y = dif[j] + 1
        rec.append(bytes([x >> 16 & 0xFF, x >> 8 & 0xFF, x & 0xFF,
                          (y - x) >> 8, (y - x) & 0xFF]) + d[x:y])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    q = 5
    while raw[q:q + 3] != b'EOF':
        o2 = raw[q] << 16 | raw[q + 1] << 8 | raw[q + 2]
        n2 = raw[q + 3] << 8 | raw[q + 4]
        prueba[o2:o2 + n2] = raw[q + 5:q + 5 + n2]
        q += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
