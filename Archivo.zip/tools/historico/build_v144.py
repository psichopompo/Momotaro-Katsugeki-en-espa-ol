"""build_v144.py - El byte robado: mis tablas de aldea se comieron el
terminador de la lista del bocadillo de los padres.

BASE: roms/test_tildes_v143.pce

EL SINTOMA
----------
David, desde la v134: artefactos en la escena de los padres; desde la
v138, un bloque negro. Su biseccion (v130/v132/v133 bien, v134 mal) situo
el cambio con exactitud.

Y con un breakpoint de escritura en `$270B` (ranura 43 del SATB en RAM)
capturo la pila de llamadas:

    $C2DB  <-  $C031  <-  $C000

`$C2DB` es la rutina que dibuja el bocadillo de los padres.

LA CAUSA, y es mia
------------------
`build_v122` creo la lista de sprites de ese bocadillo en `0x2FAE2`:

    34 registros x 5 B + 1 terminador = 171 B
    ocupa 0x2FAE2 .. 0x2FB8C           <- el $FF final cae en 0x2FB8C

Y `build_v134` puso las tablas del rotulo de aldea en `A_DAT = 0x2FB8C`.

**Exactamente el mismo byte.** Mis tablas pisan el terminador.

El motor `$E3EB` no encuentra el `$FF`, sigue leyendo mis tablas de
indices y punteros como si fueran registros de 5 B, y emite sprites con
patrones y atributos arbitrarios: paletas 2, 3, 4, 9, 10, 11, 13 y 15,
que en esa escena estan **todas a negro**. De ahi el rectangulo.

Medido en los states de David:

    lista $5AE2:  v128  39 registros y terminador OK
                  v134  76 registros (ya desbordaba)
                  v143  90 y sin terminador a la vista

    SATB:  v128  8 padres + 40 bocadillo +  0 basura = 48
           v142  8 padres + 36 bocadillo + 19 basura = 63 (tope 64)

Los 19 sprites de basura agotan el SATB, por eso el texto se corta a la
primera letra.

POR QUE NO LO CAZO EL ASSERT
-----------------------------
`build_v134` comprobaba que desde `A_DAT` **hacia adelante** todo fuera
`$FF`, y lo era: el terminador es UN solo `$FF` y el resto del hueco
tambien. La comprobacion no distingue «hueco libre» de «terminador de
alguien».

**Norma 72. Un `$FF` puede ser el TERMINADOR de un bloque anterior, no
espacio libre. Antes de ocupar un hueco hay que comprobar donde ACABA lo
que hay justo antes, no solo que el hueco este a `$FF`.**

Es la norma 35 («el primer $FF tras un bloque es su terminador») aplicada
al reves: alli el peligro era leer de mas, aqui es escribir encima.

EL ARREGLO
----------
Mover el bloque de aldea 2 bytes mas adelante, a `0x2FB8E`, dejando
intacto el terminador en `0x2FB8C` y un byte de respeto.

Todo el bloque (tablas + listas) es reubicable: el codigo lo alcanza por
punteros calculados en tiempo de construccion. Solo hay que reescribir
las direcciones inmediatas de `$DF58`.

Espacio: el bloque mide 1073 B; desde `0x2FB8E` acaba en `0x2FFBF`, con
64 B libres hasta el fin del banco.
"""

import hashlib
import os
import sys
import zlib

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(RAIZ, 'roms', 'test_tildes_v143.pce')
DST = os.path.join(RAIZ, 'roms', 'test_terminador_v144.pce')
IPS = os.path.join(RAIZ, 'parches', 'momotaro_terminador_v144.ips')

VIEJO = 0x2FB8C        # donde estan hoy mis tablas (pisa el terminador)
NUEVO = 0x2FB8E        # donde deben ir
TAM = 1073             # tamano del bloque de aldea
LISTA = 0x2FAE2        # lista del bocadillo de padres
COD = 0x19F58          # mi rutina $DF58


def log17(off):
    return 0x4000 + (off - 0x2E000)


def main():
    rom = bytearray(open(SRC, 'rb').read())
    base = bytes(rom)
    print('base   %s' % hashlib.md5(base).hexdigest())

    # ---------- 1. medir el solape ----------
    i = LISTA
    n = 0
    while base[i] != 0xFF and n < 120:
        n += 1
        i += 5
    print('\n  lista del bocadillo $%04X: %d registros leidos sin terminador'
          % (log17(LISTA), n))
    fin = LISTA + 34 * 5           # donde DEBE estar el terminador
    print('  terminador correcto en 0x%05X (34 registros)' % fin)
    assert fin == VIEJO, 'el terminador no cae en 0x%05X' % VIEJO
    print('  mis tablas empiezan en 0x%05X  ->  SOLAPE de 1 byte' % VIEJO)

    # ---------- 2. mover el bloque ----------
    bloque = bytes(base[VIEJO:VIEJO + TAM])
    assert NUEVO + TAM <= 0x30000, 'el bloque no cabe'
    rom[VIEJO:VIEJO + TAM] = b'\xFF' * TAM
    rom[NUEVO:NUEVO + TAM] = bloque
    rom[fin] = 0xFF                # el terminador, restaurado
    print('\n  bloque de aldea: 0x%05X -> 0x%05X (%d B)' % (VIEJO, NUEVO, TAM))
    print('  terminador restaurado en 0x%05X' % fin)

    # ---------- 3. repuntar las direcciones inmediatas de $DF58 ----------
    # Son SEIS, no cuatro: las tablas de punteros se leen dos veces cada
    # una (byte bajo y byte alto), con direcciones consecutivas.
    #   $DF75 LDA $5B96,X   TA_IDXT
    #   $DF7A LDA $5BB0,X   TA_PTRT lo     $DF7F LDA $5BB1,X   hi
    #   $DF93 LDA $5B8C,X   TA_IDXC
    #   $DF98 LDA $5BA0,X   TA_PTRC lo     $DF9D LDA $5BA1,X   hi
    d = NUEVO - VIEJO
    ajustes = []
    for off in range(COD, COD + 87 - 2):
        if rom[off] == 0xBD:                       # LDA abs,X
            p = rom[off + 1] | (rom[off + 2] << 8)
            if 0x5B8C <= p <= 0x5B8C + 40:         # dentro de mis tablas
                q = p + d
                rom[off + 1] = q & 0xFF
                rom[off + 2] = q >> 8
                ajustes.append((off, p, q))
    print('\n  punteros repuntados en $DF58 (+%d):' % d)
    for off, p, q in ajustes:
        print('    ROM 0x%05X  $%04X -> $%04X' % (off, p, q))
    assert len(ajustes) == 6, 'esperaba 6 punteros, ajuste %d' % len(ajustes)

    # ---------- 4. las tablas internas apuntan a listas: reajustar ----------
    A = NUEVO
    ica = list(rom[A:A + 10])
    nc = len(set(ica))
    PC = A + 20
    PT = PC + 2 * nc
    nt = len(set(rom[A + 10:A + 20]))
    tocados_int = 0
    for tabla, cuenta in ((PC, nc), (PT, nt)):
        for k in range(cuenta):
            p = rom[tabla + k * 2] | (rom[tabla + k * 2 + 1] << 8)
            q = p + d
            rom[tabla + k * 2] = q & 0xFF
            rom[tabla + k * 2 + 1] = q >> 8
            tocados_int += 1
    print('  %d punteros internos de lista reajustados (+%d)' % (tocados_int, d))

    # ---------- 5. verificar que todo apunta bien ----------
    def r17(p):
        return p - 0x4000 + 0x2E000

    for tabla, cuenta, nom in ((PC, nc, 'caja'), (PT, nt, 'texto')):
        for k in range(cuenta):
            p = rom[tabla + k * 2] | (rom[tabla + k * 2 + 1] << 8)
            o = r17(p)
            assert NUEVO <= o < NUEVO + TAM, \
                '%s %d apunta fuera del bloque: $%04X' % (nom, k, p)
            j = o
            m = 0
            while rom[j] != 0xFF and m < 60:
                m += 1
                j += 5
            assert m < 60, '%s %d sin terminador' % (nom, k)
    print('  las %d listas del bloque tienen terminador y caen dentro' % (nc + nt))

    # la lista del bocadillo vuelve a tener 34 registros
    i = LISTA
    n2 = 0
    while rom[i] != 0xFF and n2 < 120:
        n2 += 1
        i += 5
    assert n2 == 34, 'la lista del bocadillo tiene %d registros, esperaba 34' % n2
    print('  lista del bocadillo: %d registros y terminador OK' % n2)

    # ---------- 6. zonas intactas ----------
    for o, ln, nm in (
        (LISTA, 34 * 5, 'lista del bocadillo'),
        (0x1DC88, 806, 'bloque del mapa'),
        (0x1FEA9, 196, 'padres'),
        (0x1FC5F, 585, 'intro'),
        (0x1F2C9, 157, 'tutorial'),
        (0x3D660, 0x800, 'fuente'),
        (0x003EB, 0x215, 'motor $E3EB'),
        (0x1A2DB, 0x24, 'rutina $C2DB'),
    ):
        assert rom[o:o + ln] == base[o:o + ln], '%s modificado' % nm

    dif = [i for i in range(len(rom)) if rom[i] != base[i]]
    print('\n  %d bytes modificados' % len(dif))

    open(DST, 'wb').write(bytes(rom))

    # IPS: registros de 65535 B como maximo (norma: trocear rangos largos)
    def registros(a, n):
        out = []
        while n > 0:
            m = min(n, 0xFFFF)
            out.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                              m >> 8, m & 0xFF]) + bytes(rom[a:a + m]))
            a += m
            n -= m
        return out

    rec = []
    rec += registros(min(VIEJO, NUEVO), max(VIEJO, NUEVO) + TAM - min(VIEJO, NUEVO))
    for off, _, _ in ajustes:
        rec += registros(off, 3)
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')

    dd = bytes(rom)
    print('\n%s' % os.path.basename(DST))
    print('  MD5    %s' % hashlib.md5(dd).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(dd).hexdigest())
    print('  CRC32  %08x' % (zlib.crc32(dd) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
