#!/usr/bin/env python3
"""v310 = v308 + VIDA -> SALUD en el menu SELECT.

MEDIDO SOBRE EL SAVESTATE REAL de la v308. `docs/select_vram.bin` es un
volcado de la ROM JAPONESA y describe una pantalla que ya no existe: usarlo
costo dos ROMs malas (norma nueva al final).

Lo que hay de verdad en la v308:

  - El proyecto YA movio el CG del menu (el diario no lo recoge):
        japonesa   banco $3F  puntero $58F2 -> ROM 0x7F8F2
        v308       banco $07  puntero $53D9 -> ROM 0x0F3D9
    cargador en $D32D (ROM 0x1B32D).
  - Ese stream son 256 tiles -> VRAM $100..$1FF y YA lleva los siete
    rotulos en castellano DIBUJADOS.
  - La BAT de 0x1E7EA es la JAPONESA, identica a la ROM original, y difiere
    de la pantalla real en 160 celdas: la buena la compone el juego en
    ejecucion. NO se puede repuntar desde la ROM, asi que NO se toca.

Consecuencia: solo se pueden redibujar tiles que sean EXCLUSIVOS del rotulo.
La fila 3 (las letras) tiene cinco seguidos y exclusivos:

    (3,2) $17E   (3,3) $17F   (3,4) $180   (3,5) $181   (3,6) $182

Son 40 px. El SALUD del PNG de David mide 43, asi que se redibuja con el
mismo estilo (trazo de 2 px, altura 10, misma linea base que TECNICA y ORO)
pero a 39 px y 8 px de alto: cinco letras de 7 px con separador de 1,
enteras dentro de la fila 3. Entra sin tocar ninguna celda compartida.

La fila 2 (los 2 px altos del rotulo original) se deja como esta: sus celdas
comparten tile con OBJETOS y con el borde liso. El resultado es un SALUD
2 px mas bajo que el VIDA japones, pero alineado con TECNICA y ORO.
"""
import hashlib, sys, zlib
sys.path.insert(0, 'tools')
from descomp_cg import descomprime, comprime
from select_bg import tile_de_cg, a_bytes

SRC = 'roms/momotaro_es_v308.pce'
DST = 'roms/momotaro_es_v310.pce'
CG_INI, N_CG = 0x0F3D9, 256
TINTA, FONDO = 3, 1

# --- el rotulo, con el estilo del resto del menu ---------------------------
# Los rotulos cruzan dos filas de celdas: 2 px en la fila 2 y 8 en la 3.
# Las celdas de la fila 2 comparten tile con OBJETOS y con el borde, asi que
# NO se pueden tocar. Por eso el glifo se dibuja de 8 px de alto, entero
# dentro de la fila 3, con la misma linea base que TECNICA y ORO.
GLIFOS = {
 'S': [".####.", "##..##", "##....", ".####.", "....##",
       "....##", "##..##", ".####."],
 'A': [".####.", "##..##", "##..##", "######", "##..##",
       "##..##", "##..##", "##..##"],
 'L': ["##....", "##....", "##....", "##....", "##....",
       "##....", "##....", "######"],
 'U': ["##..##", "##..##", "##..##", "##..##", "##..##",
       "##..##", "##..##", ".####."],
 'D': ["####..", "##..##", "##..##", "##..##", "##..##",
       "##..##", "##..##", "####.."],
}
for n, g in GLIFOS.items():
    assert len(g) == 8, 'el glifo %s no mide 8 px de alto' % n
    assert all(len(r) == 6 for r in g), 'el glifo %s no mide 6 px de ancho' % n

# Se desplaza 2 px a la derecha para esquivar los 2 px de resto que quedan
# en la esquina de la celda (2,6): su tile $171 lo comparte la J de OBJETOS
# y no se puede limpiar.
SANGRIA = 0

CELDAS = [(3, 2), (3, 3), (3, 4), (3, 5), (3, 6)]   # 5 celdas = 40 px

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
assert hashlib.md5(orig).hexdigest() == '05de5af123244e3d970f78a5d78057bf', 'la base no es la v308'

vram = open('/home/user/descargas/v308_vram.bin', 'rb').read()
def word(f, c):
    o = (f * 64 + c) * 2
    return vram[o] | (vram[o + 1] << 8)
def tv(idx):
    b = idx * 32
    return tuple(tuple(((vram[b + r * 2] >> (7 - k)) & 1) |
                       (((vram[b + r * 2 + 1] >> (7 - k)) & 1) << 1) |
                       (((vram[b + 16 + r * 2] >> (7 - k)) & 1) << 2) |
                       (((vram[b + 16 + r * 2 + 1] >> (7 - k)) & 1) << 3)
                       for k in range(8)) for r in range(8))

# --- el stream que carga el juego -----------------------------------------
off = rom[0x1B32E] * 0x2000 + (((rom[0x1B341] << 8) | rom[0x1B33D]) - 0x4000)
assert off == CG_INI, 'el cargador apunta a %#07x, no a %#07x' % (off, CG_INI)
cg, cg_fin = descomprime(rom, CG_INI, N_CG)
tiles = [tile_de_cg(cg, i) for i in range(N_CG)]
ok = sum(1 for i in range(N_CG) if tiles[i] == tv(0x100 + i))
assert ok >= 200, 'el stream no es el del menu: %d/256' % ok

# --- las cinco celdas tienen que ser EXCLUSIVAS ---------------------------
uso = {}
for f in range(28):
    for c in range(32):
        uso.setdefault(word(f, c) & 0x7FF, []).append((f, c))
destino = []
for f, c in CELDAS:
    t = word(f, c) & 0x7FF
    otros = [x for x in uso[t] if x != (f, c)]
    assert not otros, 'el tile $%03X de (%d,%d) lo comparte %s' % (t, f, c, otros[:3])
    assert 0x100 <= t <= 0x1FF
    destino.append(t)

# --- pintar la banda y trocearla ------------------------------------------
ANCHO = 8 * len(CELDAS)
banda = [[FONDO] * ANCHO for _ in range(8)]
x = SANGRIA
for ch in 'SALUD':
    for y, fila in enumerate(GLIFOS[ch]):
        for fx, v in enumerate(fila):
            if v == '#':
                banda[y][x + fx] = TINTA
    x += 7
assert x - 1 <= ANCHO, 'SALUD no cabe en %d px' % ANCHO

for i, t in enumerate(destino):
    tiles[t - 0x100] = tuple(tuple(banda[r][i * 8 + k] for k in range(8)) for r in range(8))

# La fila 2 lleva los 2 px altos del VIDA japones. Como SALUD se dibuja
# entero en la fila 3, esos restos hay que borrarlos o quedan flotando
# encima. Solo se pueden limpiar los tiles EXCLUSIVOS del rotulo:
#   $16E (2,2), $16F (2,3)+(2,4), $170 (2,5)   -> exclusivos, se limpian
#   $171 (2,6) lo comparte con la J de OBJETOS -> NO se toca
#   $10B (2,7) ya esta limpio
LIMPIAR = []
for c in range(2, 8):
    t = word(2, c) & 0x7FF
    if all(ff == 2 and 2 <= cc <= 7 for ff, cc in uso[t]):
        LIMPIAR.append(t)
LIMPIAR = sorted(set(LIMPIAR))
liso = tuple((FONDO,) * 8 for _ in range(8))
for t in LIMPIAR:
    tiles[t - 0x100] = liso
print('tiles del borde limpiados: %s' % ' '.join('$%03X' % t for t in LIMPIAR))
resto = [c for c in range(2, 8) if (word(2, c) & 0x7FF) not in LIMPIAR
         and any(v == TINTA for r in tv(word(2, c) & 0x7FF) for v in r)]
if resto:
    print('AVISO: quedan restos en las columnas %s de la fila 2 (tile compartido)' % resto)

# --- recomprimir en su sitio ----------------------------------------------
raw = b''.join(a_bytes(t) for t in tiles)
cg_comp = comprime(raw)
assert descomprime(cg_comp, 0, N_CG)[0] == raw, 'round-trip del CG falla'
hueco = cg_fin - CG_INI
assert len(cg_comp) <= hueco, 'el CG crece de %d a %d B' % (hueco, len(cg_comp))
rom[CG_INI:CG_INI + len(cg_comp)] = cg_comp
rom[CG_INI + len(cg_comp):cg_fin] = orig[CG_INI + len(cg_comp):cg_fin]

# --- solo puede cambiar el stream -----------------------------------------
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and not (CG_INI <= i < cg_fin)]
assert not fuera, 'cambios fuera del CG: %s' % [hex(x) for x in fuera[:8]]
assert rom[0x1E7EA:0x1E9E8] == orig[0x1E7EA:0x1E9E8], 'la BAT se ha tocado'
assert rom[0x1B32D:0x1B344] == orig[0x1B32D:0x1B344], 'el cargador se ha tocado'
assert rom[0x1BBB9:0x1BFDC] == orig[0x1BBB9:0x1BFDC], 'la tabla del menu se ha tocado'
for nom, a, b in (('vitores', 0x48401, 0x4847D), ('CG de tienda', 0x2C05A, 0x2C319),
                  ('glifos', 0x3D660, 0x3E000), ('textos de tienda', 0x48460, 0x48C60),
                  ('Game Over', 0x1F9C4, 0x1FA00)):
    assert rom[a:b] == orig[a:b], '%s tocado' % nom
assert rom[0x47CFB] == 0xFF, 'terminador del abuelo pisado'

# los otros seis rotulos, intactos
for f, c in [(3, 14), (3, 24), (5, 2), (7, 2), (10, 2), (15, 2)]:
    t = word(f, c) & 0x7FF
    assert tiles[t - 0x100] == tv(t), 'se ha tocado el rotulo de (%d,%d)' % (f, c)

open(DST, 'wb').write(rom)

# --- relectura por el puntero del cargador --------------------------------
v = open(DST, 'rb').read()
off2 = v[0x1B32E] * 0x2000 + (((v[0x1B341] << 8) | v[0x1B33D]) - 0x4000)
cg2, _ = descomprime(v, off2, N_CG)
T2 = [tile_de_cg(cg2, i) for i in range(N_CG)]
print('SALUD, releido de la ROM por el puntero del cargador:')
for r in range(8):
    print('  ' + ''.join('#' if T2[t - 0x100][r][k] == TINTA else '.'
                         for t in destino for k in range(8)))
b = bytes(v)
print()
print('%s  (%d bytes cambiados)' % (DST, sum(1 for i in range(len(b)) if b[i] != orig[i])))
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xFFFFFFFF))
