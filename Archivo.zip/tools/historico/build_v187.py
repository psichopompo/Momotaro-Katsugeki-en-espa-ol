#!/usr/bin/env python3
"""
build_v187.py - LAS CUATRO LINEAS. El bocadillo pasa a 16x4 de verdad.

QUE FALTABA
-----------
La v186 tiene el marco de 16x4 (dos filas de celdas, 170-177 y 178-17F) pero
el motor solo escribe **dos** lineas, en la fila A. La mitad de abajo sale en
blanco.

Para las cuatro lineas hay que hacer dos cosas:

  1. que el motor cuente 4 lineas por pagina en vez de 2
  2. que vuelque DOS veces: al acabar la linea 2 (fila A) y al acabar la 4
     (fila B), porque el buffer solo tiene 36 bytes y 16x4 = 64 glifos no
     caben de una vez

EL OFFSET DE LA SEGUNDA MITAD, SIN VARIABLE NUEVA
-------------------------------------------------
La fila B esta 8 celdas por delante de la A:

    fila A: 170..177      fila B: 178..17F
    8 celdas x 64 words = 512 words = $200

o sea que al destino de la fila B hay que sumarle `$200`, que en el byte
ALTO son **+2**.

No hace falta guardar en ningun sitio "por que mitad voy": **`$3657` ya lo
dice**. Cuando se llama al volcado, la linea recien terminada vale 2 (fin de
la mitad A) o 4 (fin de la mitad B):

```
    LDA $3657 / LSR A / AND #$02
      $3657=2 -> 1 & 2 = 0     mitad A, offset 0
      $3657=4 -> 2 & 2 = 2     mitad B, offset +2 en el byte alto
```

Esto importa porque **la pagina cero esta toda usada**: barridos todos los
opcodes de direccionamiento directo, no queda ni un byte de `$00-$FF` sin
referenciar. Y en la RAM alta, los candidatos junto al buffer (`$3650-$3652`)
son alcanzables por instrucciones indexadas con base `$35xx`. Asi que la
solucion buena es la que **no necesita variable**.

LOS DOS PARCHES
---------------

**1. El destino alto, en `$9BA8`** (mismo numero de bytes):

```
antes:  B9 BE 9B        LDA $9BBE,Y
nuevo:  20 xx xx        JSR calc_alto
```

y `calc_alto`, en el hueco de `$9FE0`:

```
    AD 57 36    LDA $3657
    4A          LSR A
    29 02       AND #$02
    18          CLC
    79 BE 9B    ADC $9BBE,Y     <- Y sigue valiendo lo que valia
    60          RTS
```

Once bytes. `Y` no se toca en medio, asi que el `ADC abs,Y` lee la misma
entrada de la tabla que leia el `LDA abs,Y`.

**2. El fin de linea, en `$98A9`**:

```
antes:                          nuevo:
  INC $3657                       INC $3657
  LDA $3657                       LDA $3657
  CMP #$02                        CMP #$04        <- 4 lineas
  BCS fin_pagina                  BCS fin_pagina
  JMP $9801                       CMP #$02        <- mitad?
                                  BNE otra_linea
                                  JSR $9B7C       <- vuelca la fila A
                                  otra_linea: JMP $9801
```

Cabe justo en los 11 bytes que habia (`$98A9..$98B5`), sin tocar el bloque
de fin de pagina que va detras.

EL ANCHO
--------
David: «que todas las lineas muestren su nuevo uso de 16 columnas. Creo que
ahora mismo están usando las 10 o 12 columnas originales».

Eso no es del motor: **es de la maquetacion del guion**, que el otro chat
inserto repartida a 12 columnas. Los contadores ya estan a 16 desde la v184
(`$987D CMP #$10`) y el bocadillo mide 16. Lo que hay que rehacer es el
reparto de lineas del guion, que es un paso aparte y toca el texto (norma
38: los cortes de David mandan). Este parche **no toca el guion**.

Uso:  python3 tools/build_v187.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v186.pce'
SALIDA = 'roms/momotaro_es_v187.pce'
IPS = 'parches/momotaro_v187.ips'
MD5_BASE = 'a07115e11240528fe933dc9951c6cba8'

CALC = 0x41FE0          # hueco de 16 B ($9FE0)
CALC_L = 0x9FE0
RESTO = 0x41FF1         # hueco de 15 B ($9FF1)
RESTO_L = 0x9FF1
REST_MPR = 0x41ACD      # zona muerta tras el cargador (16 B)
REST_MPR_L = 0x9ACD
LINEAS = 4
MITAD = 2


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v186 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # 1. calc_alto en el hueco $9FE0
    # ------------------------------------------------------------------
    assert set(rom[CALC:CALC + 16]) == {0x00}, 'el hueco $9FE0 no esta libre'
    # y que nadie lo referencie ya
    for a in range(CALC_L, CALC_L + 16):
        p = bytes([a & 0xFF, a >> 8])
        for i in range(len(orig) - 2):
            if orig[i] in (0x20, 0x4C) and orig[i + 1:i + 3] == p:
                raise AssertionError('$%04X ya se referencia en 0x%05X' % (a, i))

    calc = bytes([
        0xAD, 0x57, 0x36,     # LDA $3657
        0x4A,                 # LSR A
        0x29, 0x02,           # AND #$02
        0x18,                 # CLC
        0x79, 0xBE, 0x9B,     # ADC $9BBE,Y
        0x60,                 # RTS
    ])
    assert len(calc) <= 16
    rom[CALC:CALC + len(calc)] = calc
    print('calc_alto en $%04X (%d B): LDA $3657 / LSR / AND #$02 / CLC / '
          'ADC $9BBE,Y / RTS' % (CALC_L, len(calc)))
    for l, esp in ((2, 0), (4, 2)):
        assert ((l >> 1) & 2) == esp
    print('  verificado: $3657=2 -> +0 (fila A) ; $3657=4 -> +2 (fila B)')

    # ------------------------------------------------------------------
    # 2. enganchar en $9BA8
    # ------------------------------------------------------------------
    o = 0x41BA8
    assert bytes(rom[o:o + 3]) == bytes([0xB9, 0xBE, 0x9B]), \
        'en $9BA8 no hay LDA $9BBE,Y sino %s' % bytes(rom[o:o + 3]).hex()
    rom[o:o + 3] = bytes([0x20, CALC_L & 0xFF, CALC_L >> 8])
    print('  0x%05X  $9BA8: LDA $9BBE,Y -> JSR $%04X' % (o, CALC_L))
    # el STA $3664 de detras no se toca
    assert bytes(rom[o + 3:o + 6]) == bytes([0x8D, 0x64, 0x36])

    # ------------------------------------------------------------------
    # 3. el fin de linea: 4 lineas y volcado a mitad
    # ------------------------------------------------------------------
    f = 0x418A9
    esperado = bytes([
        0xEE, 0x57, 0x36,        # INC $3657
        0xAD, 0x57, 0x36,        # LDA $3657
        0xC9, 0x02,              # CMP #$02
        0xB0, 0x03,              # BCS $98B6
        0x4C, 0x01, 0x98,        # JMP $9801
    ])
    assert bytes(rom[f:f + 13]) == esperado, \
        'el fin de linea no es el esperado: %s' % bytes(rom[f:f + 13]).hex()
    # el bloque de fin de pagina que viene detras NO se toca
    fin_pag = bytes(rom[f + 13:f + 24])
    assert fin_pag == bytes([0xA9, 0x01, 0x8D, 0x54, 0x36, 0x68, 0x53, 0x08,
                             0x4C, 0x7C, 0x9B]), \
        'el bloque de fin de pagina cambio: %s' % fin_pag.hex()

    # En $98A9 solo hay 13 bytes antes del bloque de fin de pagina, y la
    # logica nueva necesita 20. Se parte: lo que cabe se queda (incluido el
    # salto a fin de pagina, que es a 3 bytes) y el resto va al hueco $9FF1.
    nuevo = bytes([
        0xEE, 0x57, 0x36,        # INC $3657
        0xAD, 0x57, 0x36,        # LDA $3657
        0xC9, LINEAS,            # CMP #$04        fin de pagina?
        0xB0, 0x03,              # BCS +3     -> $98B6
        0x4C, RESTO_L & 0xFF, RESTO_L >> 8,   # JMP $9FF1
    ])
    assert len(nuevo) == 13, 'el bloque nuevo mide %d, no 13' % len(nuevo)
    destino_bcs = f + 10 + 0x03
    assert destino_bcs == f + 13, \
        'el BCS no cae en $98B6 sino en 0x%05X' % destino_bcs
    rom[f:f + len(nuevo)] = nuevo

    # El resto va en la zona muerta $9ACD (restos de la lista de sprites
    # de la v157, huerfanos desde la v177; verificado: 0 referencias).
    #
    # OJO, y esto es lo que casi se me escapa: **$9B7C REMAPEA MPR2** al
    # banco 0x1E para leer el CG. El fin de PAGINA no sufre porque sale de
    # la rutina, pero este volcado es INTERMEDIO y vuelve a $9801 a seguir
    # leyendo el guion con LDA ($92), que vive en MPR2 = banco $24.
    # Sin restaurar el mapeo, el motor leeria basura a partir de la linea 3.
    # Se repite el prologo de $97F4: LDA #$24 / CLC / ADC $20 / TAM #$04.
    assert set(rom[RESTO:RESTO + 15]) == {0x00}, 'el hueco $9FF1 no esta libre'
    resto = bytes([
        0xC9, MITAD,             # CMP #$02        mitad de pagina?
        0xD0, 0x03,              # BNE +3     -> JMP $9801
        0x20, REST_MPR_L & 0xFF, REST_MPR_L >> 8,   # JSR volcar_y_restaurar
        0x4C, 0x01, 0x98,        # JMP $9801       otra linea
    ])
    assert len(resto) <= 15
    assert RESTO + 4 + 0x03 == RESTO + 7, 'el BNE no cae en el JSR'
    rom[RESTO:RESTO + len(resto)] = resto

    # volcar_y_restaurar, en la zona muerta del cargador (16 B, 0 referencias)
    mpr_esperado = bytes.fromhex('000f0100f8140f0103281c0f001418ff')
    assert bytes(rom[REST_MPR:REST_MPR + 16]) == mpr_esperado, \
        'la zona muerta $9ACD no tiene los restos esperados'
    for a in range(REST_MPR_L, REST_MPR_L + 16):
        pp = bytes([a & 0xFF, a >> 8])
        for i in range(len(orig) - 2):
            if orig[i] in (0x20, 0x4C) and orig[i + 1:i + 3] == pp:
                raise AssertionError('$%04X referenciado en 0x%05X' % (a, i))
    vol = bytes([
        0x20, 0x7C, 0x9B,        # JSR $9B7C     vuelca la fila A
        0xA9, 0x24,              # LDA #$24      y restaura MPR2
        0x18,                    # CLC           (no se asume $20 = 0)
        0x65, 0x20,              # ADC $20
        0x53, 0x04,              # TAM #$04
        0x60,                    # RTS
    ])
    assert len(vol) <= 16, 'volcar_y_restaurar mide %d B' % len(vol)
    rom[REST_MPR:REST_MPR + len(vol)] = vol
    print('  0x%05X  volcar_y_restaurar (%d B): JSR $9B7C + rehace MPR2'
          % (REST_MPR, len(vol)))
    # el prologo que copiamos es el mismo que usa el motor
    assert bytes(orig[0x417F4:0x417FB]) == bytes(
        [0xA9, 0x24, 0x18, 0x65, 0x20, 0x53, 0x04]), \
        'el prologo de $97F4 no es el que creo'
    rom[RESTO:RESTO + len(resto)] = resto

    print('  0x%05X  fin de linea (13 B): CMP #$04 / BCS fin_pagina / '
          'JMP $%04X' % (f, RESTO_L))
    print('  0x%05X  resto (%d B): CMP #$02 / BNE / JSR $9B7C / restaura '
          'MPR2 / JMP $9801' % (RESTO, len(resto)))

    # el fin de pagina tiene que seguir intacto y en su sitio
    assert bytes(rom[f + 13:f + 24]) == fin_pag, \
        'se ha pisado el bloque de fin de pagina'
    print('  bloque de fin de pagina ($98B6) intacto')

    # ------------------------------------------------------------------
    # 4. el clon $9952 tambien cuenta lineas
    # ------------------------------------------------------------------
    # El clon pinta la PRIMERA pagina. Con 4 lineas tiene el mismo problema
    # del buffer, pero su bucle es distinto: escribe y al final llama a
    # $9B7C una sola vez. Se deja en 2 lineas: la primera pagina saldra con
    # dos lineas y el resto con cuatro. Es un paso intermedio verificable;
    # unificarlo es el siguiente.
    assert rom[0x419BB] == MITAD, 'el clon no esta en 2 lineas'
    print('  clon $9952: se queda en 2 lineas (la primera pagina). Pendiente.')

    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('cargador del CG', 0x41AAE, 0x41ACD),
        ('tabla rabillo', 0x41ADD, 0x41AFD),
        ('fuente', 0x3D660, 0x3E200),
        ('flecha', 0x419E2, 0x419F3),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    permitido = set(range(CALC, CALC + len(calc))) | set(range(o, o + 3)) \
        | set(range(f, f + len(nuevo))) | set(range(RESTO, RESTO + len(resto))) \
        | set(range(REST_MPR, REST_MPR + len(vol)))
    fuera = [i for i in dif if i not in permitido]
    assert not fuera, 'cambios fuera de lo previsto: %s' % [hex(i) for i in fuera]
    print('%d bytes modificados, todos previstos' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        of = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n = raw[p + 3] << 8 | raw[p + 4]
        prueba[of:of + n] = raw[p + 5:p + 5 + n]
        p += 5 + n
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B, %d registros)' % (len(raw), len(rec)))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  CUATRO lineas de texto en el bocadillo (salvo la primera pagina')
    print('  de cada dialogo, que la pinta el clon y sigue en dos).')
    print('  Las lineas seguiran siendo cortas: el guion esta maquetado a 12')
    print('  columnas y hay que rehacer el reparto, que es el paso siguiente.')


if __name__ == '__main__':
    main()
