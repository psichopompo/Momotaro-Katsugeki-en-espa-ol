#!/usr/bin/env python3
"""
build_v196.py - LA CAUSA RAIZ de las lineas que se pierden entre paginas.

EL SINTOMA QUE LO DESTAPA
-------------------------
De todo lo que reporta David, la pista buena es esta:

> «Cuando tenemos una nueva pagina con una sola linea, esta no aparece en la
>  linea superior, sino mas abajo (creo que en la tercera linea).»

Una pagina de una linea deberia salir arriba. Si sale en la tercera, es que
el volcado esta eligiendo la **fila B** en vez de la A.

LA CADENA, TRAZADA ENTERA
-------------------------
```
$9789  despachador segun $3654:
         0 -> $97EE   prologo de pagina
         1 -> $97BA   parpadea la flecha; al pulsar, $3654=0
$97EE  JSR $9C32      <-- recarga el CG **y vuelca**
       ...
$97FE  STZ $3657      <-- la linea se pone a 0 DESPUES
```

y dentro de `$9C32`:

```
$9C59  JSR $9C29      limpia el buffer de RAM
$9C5C  JMP $9A4D  ->  JSR $9AAE    carga las 16 celdas blancas
                        $9ACA  JMP $9B7C   <-- VUELCA
                      JMP $9B7C            <-- VUELCA OTRA VEZ
```

Ese volcado usa `calc_alto`, que lee `$3657`... y en ese instante `$3657`
**todavia tiene el valor de la pagina anterior**, porque el `STZ` va detras.

Resultado: al recargar se blanquea **solo la fila que diga el `$3657`
viejo**; la otra conserva el texto de la pagina anterior. De ahi que la
pagina nueva aparezca mezclada con la vieja, que se pierdan lineas y que una
pagina de una sola linea salga abajo.

POR QUE NO BASTA CON REORDENAR
------------------------------
Mi primera idea fue mover el `STZ $3657` delante del `JSR $9C32`. **No
sirve**: con `$3657 = 0`, `calc_alto` hace `DEC A` y da `$FF`, y
`$FF AND 2 = 2`, o sea la fila B. Seguiria blanqueando solo una.

EL ARREGLO: DOS BYTES
---------------------
El cargador `$9AAE` **ya deja las 16 celdas en blanco** en la VRAM: ese es
el borrado de verdad, y no depende de `$3657` ni del buffer. El `JMP $9B7C`
con el que acaba es herencia de la v179, cuando el cargador era el ultimo
paso de la apertura.

```
$9ACA   JMP $9B7C   ->   RTS + NOP
```

`$9A4D` (`JSR $9AAE / JMP $9B7C`) sigue haciendo el volcado que necesita la
apertura, y ahora el `JSR` **vuelve de verdad** en vez de encadenarse.

Con esto la recarga blanquea las dos filas y el volcado posterior pinta un
buffer ya limpio.

Uso:  python3 tools/build_v196.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v195.pce'
SALIDA = 'roms/momotaro_es_v196.pce'
IPS = 'parches/momotaro_v196.ips'
MD5_BASE = '39bb0e301b69531338edd9d8ae7291ce'

FIN_CARGADOR = 0x41ACA        # $9ACA, el JMP $9B7C del final del cargador


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v195 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # que la cadena es la que creo
    # ------------------------------------------------------------------
    assert bytes(rom[0x417EE:0x417F1]) == bytes([0x20, 0x32, 0x9C]), \
        '$97EE no empieza con JSR $9C32'
    assert bytes(rom[0x417FE:0x41801]) == bytes([0x9C, 0x57, 0x36]), \
        '$97FE no es STZ $3657'
    # OJO: en la v189 se enganchó $9C5C con JMP $9A4D, pero la v190
    # rehizo esa zona y ahora salta DIRECTO al cargador. Comprobado
    # desensamblando, no supuesto.
    assert bytes(rom[0x41C59:0x41C5F]) == bytes(
        [0x20, 0x29, 0x9C, 0x4C, 0xAE, 0x9A]), \
        '$9C59 no es JSR $9C29 / JMP $9AAE sino %s' % bytes(
            rom[0x41C59:0x41C5F]).hex()
    print('cadena verificada:')
    print('  $97EE  JSR $9C32   (recarga el CG y vuelca)')
    print('  $97FE  STZ $3657   (la linea se pone a 0 DESPUES)')
    print('  $9C5C  JMP $9AAE   (directo al cargador)')
    print('  $9ACA  JMP $9B7C   (el cargador vuelca por su cuenta)')

    # el cargador carga las 16 celdas blancas
    assert bytes(rom[0x41AC0:0x41AC2]) == bytes([0xA2, 0x10]), \
        'el cargador no carga 16 celdas'

    # ------------------------------------------------------------------
    # el arreglo
    # ------------------------------------------------------------------
    assert bytes(rom[FIN_CARGADOR:FIN_CARGADOR + 3]) == bytes(
        [0x4C, 0x7C, 0x9B]), \
        'en $9ACA no hay JMP $9B7C sino %s' % bytes(
            rom[FIN_CARGADOR:FIN_CARGADOR + 3]).hex()
    rom[FIN_CARGADOR] = 0x60          # RTS
    rom[FIN_CARGADOR + 1] = 0xEA      # NOP
    rom[FIN_CARGADOR + 2] = 0xEA      # NOP
    print()
    print('  0x%05X  $9ACA: JMP $9B7C -> RTS' % FIN_CARGADOR)
    print('    el cargador deja las 16 celdas EN BLANCO y vuelve al')
    print('    llamante en vez de volcar con un $3657 que aun es el de')
    print('    la pagina anterior')

    # El unico llamante es $9C5C, y lo hace con JMP: al poner RTS, el
    # cargador retorna al que llamo a $9C32, que es $97EE. Alli sigue el
    # prologo (mapear el guion, STZ $3657/$3658) y luego $9807 dibuja.
    h = [i for i in range(len(rom) - 2)
         if rom[i] in (0x20, 0x4C) and rom[i + 1] == 0xAE
         and rom[i + 2] == 0x9A]
    assert h == [0x41C5C], 'los llamantes de $9AAE son %s' % [
        '%05X' % x for x in h]
    assert rom[0x41C5C] == 0x4C, 'el llamante no es un JMP'
    # $9C32 se llama con JSR desde $97EE, asi que el RTS del cargador
    # devuelve el control a $97F1. Comprobado.
    assert bytes(orig[0x417EE:0x417F1]) == bytes([0x20, 0x32, 0x9C])
    print('  $9C5C llama con JMP, asi que el RTS vuelve a $97F1 (el JSR')
    print('  $9C32 de $97EE): el prologo continua y pone $3657 a 0')

    # Las OTRAS cuatro rutas que llaman a $9C32 no se rompen:
    #   0x168D2 JSR : apertura, y luego JMP $9952 (el clon dibuja)
    #   0x4170F JMP : $9706, acaba en $9C32
    #   0x41780 JMP : $9778, acaba en $9C32
    #   0x5F6E9 JSR : otro banco, sigue con STZ $37D1
    # En las dos que son JMP, antes la cadena era
    #     $9C32 -> $9AAE -> $9B7C -> RTS
    # y ahora
    #     $9C32 -> $9AAE -> RTS
    # El RTS retorna al MISMO sitio en los dos casos ($9B7C acaba en RTS),
    # asi que la pila se comporta igual.
    assert rom[0x41BBC] == 0x60, '$9B7C no acaba en RTS'
    # Y el volcado que se quita no pintaba nada: $9C32 acaba de llamar a
    # $9C29 (buffer a cero) y el cargador ya ha dejado las 16 celdas
    # blancas, asi que volcar solo reescribia blanco sobre blanco.
    assert bytes(rom[0x41C59:0x41C5C]) == bytes([0x20, 0x29, 0x9C]), \
        '$9C59 ya no limpia el buffer antes del cargador'
    # El mapeo tampoco cambia: $9C35 deja MPR2 en el banco 0x1E igual que
    # lo dejaria $9B7C.
    assert bytes(rom[0x41C35:0x41C3C]) == bytes(
        [0xA9, 0x1E, 0x18, 0x65, 0x20, 0x53, 0x04]), \
        '$9C35 no mapea el banco 0x1E'
    print('  las otras 4 rutas de $9C32: misma pila, mismo mapeo, y el')
    print('  volcado que se quita solo pintaba blanco sobre blanco')

    # ------------------------------------------------------------------
    intactas = [
        ('guion', 0x48000, 0x4C000),
        ('CG del bocadillo', 0x3D3D4, 0x3D660),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('calc_alto', 0x41FE0, 0x41FEB),
        ('clon $9952', 0x4199A, 0x419C6),
        ('fin de linea', 0x418A9, 0x418C1),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('volcar_y_restaurar', 0x41ACD, 0x41ADB),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    assert dif == [FIN_CARGADOR, FIN_CARGADOR + 1, FIN_CARGADOR + 2], \
        'se han tocado otros bytes: %s' % [hex(i) for i in dif]
    print('%d bytes modificados, los previstos' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    a, b = FIN_CARGADOR, FIN_CARGADOR + 3
    rec = bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF, 0, 3]) + d[a:b]
    open(IPS, 'wb').write(b'PATCH' + rec + b'EOF')
    prueba = bytearray(orig)
    prueba[a:b] = d[a:b]
    assert bytes(prueba) == d
    print('IPS round-trip OK')

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  Los dialogos de varias paginas COMPLETOS. En concreto:')
    print('   - el 7 debe decir "derrote a 1000 ogros / de esta manera..."')
    print('   - el 48 "el autor del juego, / asi que es verdad..."')
    print('   - una pagina de una sola linea, ARRIBA del todo')


if __name__ == '__main__':
    main()
