#!/usr/bin/env python3
"""v313 = v312 + las descripciones de los tres onigiri.

David:
  «Tu sugerencia de Salud +1., Tecnica +1., Todo +1. me parece bien.»

Viene de dos correcciones suyas:
  - «Cura ambos» era ambiguo: no se sabia a que se referia.
  - «1 vida» era enganoso: la barra son PUNTOS de vida, no vidas.
  - Y «momo» no lo entiende nadie: el menu SELECT llama TECNICA a esa barra,
    asi que las descripciones usan la misma palabra.

Las tres van con punto final. Norma de David: que falte un punto final es un
error garrafal, y si no cabe hay que buscar otra formulacion, nunca quitarlo.

Formato: 2 lineas de 16, relleno $A0 (ver build_v307.py).
Codificacion: motor de TIENDA -> b/c/p/C con sus bytes directos (norma 256).
"""
import hashlib, sys, zlib
sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE

SRC = 'roms/momotaro_es_v312.pce'
DST = 'roms/momotaro_es_v313.pce'
MAESTRA = 0x10929
RELLENO = 0xA0
ALIAS = {0x5B: 0xA2, 0x5D: 0xA3, 0x5E: 0xB0}

# entrada de la tabla maestra -> (nombre, descripcion nueva)
CAMBIOS = {
    0: ('Onigiri:',  'Salud +1.'),
    1: ('Manjar:',   'Técnica +1.'),
    2: ('Banquete:', 'Todo +1.'),
}
ANTES = {
    0: 'Recupera 1 vida.',
    1: 'Recupera 1 momo.',
    2: 'Cura vida y momo',
}


def cod(s):
    out = bytearray()
    for ch in s:
        if ch not in CHAR_TO_CODE:
            raise ValueError('caracter no soportado: %r' % ch)
        b = CHAR_TO_CODE[ch]
        out.append(ALIAS.get(b, b))
    if len(out) > 16:
        raise ValueError('%d caracteres: %r' % (len(out), s))
    return bytes(out) + bytes([RELLENO] * (16 - len(out)))


rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
assert len(rom) == 512 * 1024
assert hashlib.md5(orig).hexdigest() == 'be7b3223ea3f49de5b0ec1d4f47efacc', 'la base no es la v312'

inv = {v: k for k, v in CHAR_TO_CODE.items()}
T = dict(inv); T[0xA2], T[0xA3], T[0xB0], T[0xDE] = 'b', 'c', 'p', 'Ç'
def des(b):
    return ''.join('' if x == RELLENO else T.get(x, '{%02X}' % x) for x in b)

for i, (nombre, nueva) in CAMBIOS.items():
    o = MAESTRA + i * 4
    w = rom[o] | (rom[o + 1] << 8)
    r = 0x48000 + (w - 0x4000)
    # la entrada tiene que ser la que se espera, no otra
    assert des(rom[r:r + 16]) == nombre, \
        'la entrada %d no es %r sino %r' % (i, nombre, des(rom[r:r + 16]))
    assert des(rom[r + 16:r + 32]) == ANTES[i], \
        'la 2a linea de %s no es la esperada: %r' % (nombre, des(rom[r + 16:r + 32]))
    assert nueva.endswith('.'), 'la descripcion %r no lleva punto final' % nueva
    rom[r + 16:r + 32] = cod(nueva)

# --- zonas intactas --------------------------------------------------------
permitido = set()
for i in CAMBIOS:
    o = MAESTRA + i * 4
    w = rom[o] | (rom[o + 1] << 8)
    r = 0x48000 + (w - 0x4000)
    permitido |= set(range(r + 16, r + 32))
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and i not in permitido]
assert not fuera, 'cambios fuera de las 3 descripciones: %s' % [hex(x) for x in fuera[:8]]
assert rom[MAESTRA:MAESTRA + 96] == orig[MAESTRA:MAESTRA + 96], 'tabla maestra tocada'
assert rom[0x10854:0x108C0] == orig[0x10854:0x108C0], 'tabla de tiendas tocada'
assert rom[0x0F3D9:0x10000] == orig[0x0F3D9:0x10000], 'CG del menu tocado'
assert rom[0x48401:0x4847D] == orig[0x48401:0x4847D], 'bloque de vitores tocado'
assert rom[0x47CFB] == 0xFF, 'terminador del abuelo pisado'

open(DST, 'wb').write(rom)

# --- RELECTURA siguiendo el puntero, como hace el motor -------------------
v = open(DST, 'rb').read()
print('las 20 descripciones, releidas por la tabla maestra:')
sin_punto = []
for i in range(20):
    o = MAESTRA + i * 4
    w = v[o] | (v[o + 1] << 8)
    r = 0x48000 + (w - 0x4000)
    l1, l2 = des(v[r:r + 16]), des(v[r + 16:r + 32])
    marca = '  <--' if i in CAMBIOS else ''
    print('  %2d  %-16s %-16s%s' % (i, l1, l2, marca))
    if l2 and not l2.endswith(('.', '!', '?')):
        sin_punto.append((i, l2))
assert not sin_punto, 'descripciones sin punto final: %s' % sin_punto
for i, (_, nueva) in CAMBIOS.items():
    o = MAESTRA + i * 4
    w = v[o] | (v[o + 1] << 8)
    r = 0x48000 + (w - 0x4000)
    assert des(v[r + 16:r + 32]) == nueva, 'la entrada %d no relee %r' % (i, nueva)
    assert 0x8B not in v[r:r + 32], 'hay un $8B (©) en la entrada %d' % i
print()
print('las 3 releen lo acordado, todas con punto final, sin ningun $8B')

b = bytes(v)
print()
print('%s  (%d bytes cambiados)' % (DST, sum(1 for i in range(len(b)) if b[i] != orig[i])))
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xFFFFFFFF))
