#!/usr/bin/env python3
"""v312 = v308 + el menu SELECT rediseñado por David (VIDA -> SALUD).

David rehizo los siete rotulos con una regla que resolvio el atasco:
UNA LETRA POR CELDA de 8x8, sin invadir la celda vecina, y la misma letra
dibujada siempre igual.

Por que era imprescindible: el juego REUTILIZA tiles entre rotulos.
    $1A3 = la A final de TECNICA  y  la A inicial de ARMADURA
    $1A8 = la R de ORO            y  la R de ARMADURA
Si una letra se derrama sobre la celda de al lado, esas dos celdas piden
dibujos distintos del MISMO tile y es imposible. Con una letra por celda
coinciden solas.

Estructura real (medida sobre el savestate de la v308, no sobre
docs/select_vram.bin, que es un volcado japones y costo tres ROMs malas):

    CG   0x0F3D9  un stream de 201 tiles -> VRAM $100..$1C8
                  Son 201 EXACTOS: el stream acaba en 0x0FE2B y a partir de
                  ahi hay 469 B de relleno $FF hasta el fin del banco $07
                  (0x10000). Pedir 256 hace que el descompresor siga leyendo
                  el banco $08 -y al reescribirlo se machaca su codigo, que
                  es lo que colgaba el juego al entrar en las aldeas.
                  cargador en $D32D (ROM 0x1B32D): banco $07, puntero $53D9
    BAT  la de 0x1E7EA es la JAPONESA; la real la compone el juego en
         ejecucion. NO se toca: solo se redibujan tiles.

Verificado antes de escribir: las 100 celdas que cambian dan CERO
conflictos de tile compartido.
"""
import hashlib, sys, zlib
sys.path.insert(0, 'tools')
from PIL import Image
from descomp_cg import descomprime, comprime
from select_bg import tile_de_cg, a_bytes

SRC = 'roms/momotaro_es_v308.pce'
DST = 'roms/momotaro_es_v312.pce'
PNG = 'capturas/select_david_v312.png'
CG_INI, N_CG = 0x0F3D9, 201

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
assert hashlib.md5(orig).hexdigest() == '05de5af123244e3d970f78a5d78057bf', 'la base no es la v308'

vram = open('docs/select_v308_vram.bin', 'rb').read()
pal = open('docs/select_v308_pal.bin', 'rb').read()
def rgb(i):
    w = pal[i * 2] | (pal[i * 2 + 1] << 8)
    g, r, b = (w >> 6) & 7, (w >> 3) & 7, w & 7
    return (r * 36, g * 36, b * 36)
COL = {rgb(i): i for i in range(16)}
def word(f, c):
    o = (f * 64 + c) * 2
    return vram[o] | (vram[o + 1] << 8)
def tv(idx):
    b = idx * 32
    return tuple(tuple(((vram[b + r * 2] >> (7 - k)) & 1) |
                       (((vram[b + r * 2 + 1] >> (7 - k)) & 1) << 1) |
                       (((vram[b + 16 + r * 2] >> (7 - k)) & 1) << 2) |
                       (((vram[b + 16 + r * 2 + 1] >> (7 - k)) & 1) << 3)
                       for k in range(8)) for r in range(8))

im = Image.open(PNG).convert('RGB')
assert im.size == (256, 176), 'el PNG debe medir 256x176'
px = im.load()
for y in range(176):
    for x in range(256):
        assert px[x, y] in COL, 'color %s fuera de la paleta en (%d,%d)' % (px[x, y], x, y)
def tp(cx, cy):
    return tuple(tuple(COL[px[cx * 8 + k, cy * 8 + r]] for k in range(8)) for r in range(8))

# --- el stream que carga el juego -----------------------------------------
off = rom[0x1B32E] * 0x2000 + (((rom[0x1B341] << 8) | rom[0x1B33D]) - 0x4000)
assert off == CG_INI, 'el cargador apunta a %#07x' % off
cg, cg_fin = descomprime(rom, CG_INI, N_CG)
tiles = [tile_de_cg(cg, i) for i in range(N_CG)]
ok = sum(1 for i in range(N_CG) if tiles[i] == tv(0x100 + i))
assert ok == N_CG, 'el stream no cuadra con la VRAM real: %d/%d' % (ok, N_CG)
assert cg_fin <= 0x0FE2B, 'el stream se sale del banco $07: acaba en %#07x' % cg_fin

uso = {}
for f in range(28):
    for c in range(32):
        uso.setdefault(word(f, c) & 0x7FF, []).append((f, c))
dinamicas = {(f, c) for f in range(22) for c in range(32) if (word(f, c) >> 8) == 0x02}
# El numero de celdas dinamicas depende de lo que haya en pantalla en el
# savestate (objetos del inventario, cifras...). No se fija una cuenta
# exacta: basta con que existan y con que ninguna caiga en los rotulos.
assert 30 <= len(dinamicas) <= 80, 'celdas dinamicas fuera de rango: %d' % len(dinamicas)
ROTULOS = ([(2, c) for c in range(2, 10)] + [(3, c) for c in range(2, 10)] +
           [(4, c) for c in range(2, 10)] + [(5, c) for c in range(2, 10)] +
           [(6, c) for c in range(2, 6)] + [(7, c) for c in range(2, 6)] +
           [(9, c) for c in range(2, 8)] + [(10, c) for c in range(2, 8)] +
           [(14, c) for c in range(2, 12)] + [(15, c) for c in range(2, 12)] +
           [(2, c) for c in range(14, 22)] + [(3, c) for c in range(14, 22)] +
           [(2, c) for c in range(24, 30)] + [(3, c) for c in range(24, 30)])
solapan = sorted(set(dinamicas) & set(ROTULOS))
assert not solapan, 'hay celdas dinamicas dentro de los rotulos: %s' % solapan[:8]

cambian = [(f, c) for f in range(22) for c in range(32)
           if (f, c) not in dinamicas and tp(c, f) != tv(word(f, c) & 0x7FF)]

# --- CERO conflictos: es la condicion que hace viable el cambio -----------
conflictos = []
for f, c in cambian:
    t = word(f, c) & 0x7FF
    if len({tp(cc, ff) for ff, cc in uso[t]}) > 1:
        conflictos.append((f, c, t))
assert not conflictos, 'hay %d celdas con tile compartido: %s' % (
    len(conflictos), [('(%d,%d) $%03X' % x) for x in conflictos[:6]])
print('%d celdas cambian, 0 conflictos de tile compartido' % len(cambian))

for f, c in cambian:
    t = word(f, c) & 0x7FF
    assert 0x100 <= t <= 0x1FF, '(%d,%d) usa el tile $%03X, fuera del stream' % (f, c, t)
    tiles[t - 0x100] = tp(c, f)

# --- recomprimir en su sitio ----------------------------------------------
raw = b''.join(a_bytes(t) for t in tiles)
cg_comp = comprime(raw)
assert descomprime(cg_comp, 0, N_CG)[0] == raw, 'round-trip del CG falla'
hueco = cg_fin - CG_INI
assert len(cg_comp) <= hueco, 'el CG crece de %d a %d B' % (hueco, len(cg_comp))
assert CG_INI + len(cg_comp) <= 0x10000, \
    'el CG invadiria el banco $08: acabaria en %#07x' % (CG_INI + len(cg_comp))
rom[CG_INI:CG_INI + len(cg_comp)] = cg_comp
rom[CG_INI + len(cg_comp):cg_fin] = orig[CG_INI + len(cg_comp):cg_fin]

# --- nada mas puede cambiar ------------------------------------------------
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and not (CG_INI <= i < cg_fin)]
assert not fuera, 'cambios fuera del CG: %s' % [hex(x) for x in fuera[:8]]
invade = [i for i in range(0x10000, len(rom)) if rom[i] != orig[i]]
assert not invade, 'se ha tocado el banco $08 o posterior: %s' % [hex(x) for x in invade[:8]]
assert rom[0x1E7EA:0x1E9E8] == orig[0x1E7EA:0x1E9E8], 'la BAT se ha tocado'
assert rom[0x1B32D:0x1B344] == orig[0x1B32D:0x1B344], 'el cargador se ha tocado'
assert rom[0x1BBB9:0x1BFDC] == orig[0x1BBB9:0x1BFDC], 'la tabla del menu se ha tocado'
for nom, a, b in (('vitores', 0x48401, 0x4847D), ('CG de tienda', 0x2C05A, 0x2C319),
                  ('glifos', 0x3D660, 0x3E000), ('textos de tienda', 0x48460, 0x48C60),
                  ('Game Over', 0x1F9C4, 0x1FA00)):
    assert rom[a:b] == orig[a:b], '%s tocado' % nom
assert rom[0x47CFB] == 0xFF, 'terminador del abuelo pisado'

open(DST, 'wb').write(rom)

# --- RELECTURA siguiendo el puntero del cargador --------------------------
v = open(DST, 'rb').read()
off2 = v[0x1B32E] * 0x2000 + (((v[0x1B341] << 8) | v[0x1B33D]) - 0x4000)
cg2, _ = descomprime(v, off2, N_CG)
T2 = [tile_de_cg(cg2, i) for i in range(N_CG)]
mal = [(f, c) for f, c in cambian if T2[(word(f, c) & 0x7FF) - 0x100] != tp(c, f)]
assert not mal, 'no releen el PNG: %s' % mal[:6]
print('las %d celdas releen EXACTAMENTE el PNG de David' % len(cambian))

b = bytes(v)
print('%s  (%d bytes cambiados)' % (DST, sum(1 for i in range(len(b)) if b[i] != orig[i])))
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xFFFFFFFF))
