#!/usr/bin/env python3
"""
build_v189.py - borrar el texto de la pagina anterior. UN BYTE.

EL FALLO QUE VE DAVID
---------------------
> «si hemos visto 4 lineas en la primera pagina, pero en la segunda solo hay
>  dos, seguiremos viendo las lineas 3 y 4 de la pagina anterior»

El motor escribe el **glifo en el plano 3** de la celda (norma 108) y solo
toca las celdas de las lineas que escribe. Si la pagina nueva tiene 2
lineas, las celdas de las lineas 3-4 (`178-17F`) conservan el glifo de la
pagina anterior.

El buffer de RAM si se limpia (`$9C29`). Lo que no se limpiaba es la VRAM.
Antes no pasaba porque el bocadillo tenia una sola fila de celdas y cada
pagina la reescribia entera.

EL ARREGLO
----------
`$9C32` ya hace **exactamente** lo que hace falta:

```
$9C32  JSR $9C5F              interruptor de tamano a normal
       LDA #$1E / ADC $20 / TAM #$04    mapea el banco del CG
       puntero $5401, destino $6700, 20 celdas   (marco)
       JSR $9C29              limpia el buffer de RAM
       JMP $9A4D -> JSR $9AAE (16 celdas blancas en 170-17F) / JMP $9B7C
```

O sea: recarga las 36 celdas **en blanco**, limpia el buffer y vuelca. Solo
hay que llamarla al empezar cada pagina en vez de solo al abrir.

`$97EE` es la entrada del motor de pagina y hoy hace `JSR $9C29`. Se cambia
por `JSR $9C32`: **mismo tamano, un byte distinto**.

DOS ERRORES MIOS EN EL CAMINO (los cuento porque casi entrego la ROM mala)
--------------------------------------------------------------------------
**1.** Mi primera version convertia el cargador `$9AAE` en subrutina y metia
las llamadas en los "huecos" `$9A4D` y `$9A59`. **No son huecos**: son los
bitmaps de la flecha de continuar.

```
$9A49  punteros:  4D 9A  55 9A     <- apuntan a los dos bitmaps
$9A4D  bitmap de BORRADO (8 ceros)
$9A55  bitmap de la FLECHA (00 1F 0E 04 00 00 00 00)
$9A5D  bitmap del CURSOR de tienda
```

Mi barrido de "rachas de ceros" los dio por libres **porque son ceros**,
pero `$9A49` los referencia como datos. Habria borrado la flecha.

**2.** El cargador `$9AAE` **no mapea MPR2**: hereda el mapeo de quien lo
llama (`$9C32` lo hace por el). Llamarlo desde `$97EE` habria leido el
stream del CG del banco equivocado.

Los dos se evitan usando `$9C32`, que ya lo hace todo bien.

COSTE
-----
Descomprimir 36 celdas en cada cambio de pagina. Es lo mismo que ya se hace
al abrir cada bocadillo, asi que el juego lo soporta de sobra.

Uso:  python3 tools/build_v189.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v188.pce'
SALIDA = 'roms/momotaro_es_v189.pce'
IPS = 'parches/momotaro_v189.ips'
MD5_BASE = 'a98c5f592bb0ba8af7f7123b8ff7d9fb'

ENTRADA = 0x417EE           # $97EE  JSR $9C29


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v188 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # que $9C32 hace lo que creo
    # ------------------------------------------------------------------
    assert bytes(rom[0x41C32:0x41C3C]) == bytes(
        [0x20, 0x5F, 0x9C, 0xA9, 0x1E, 0x18, 0x65, 0x20, 0x53, 0x04]), \
        '$9C32 no empieza como creo: %s' % bytes(rom[0x41C32:0x41C3C]).hex()
    assert bytes(rom[0x41C59:0x41C5F]) == bytes(
        [0x20, 0x29, 0x9C, 0x4C, 0xAE, 0x9A]), \
        '$9C59 no es JSR $9C29 / JMP $9AAE: %s' % bytes(
            rom[0x41C59:0x41C5F]).hex()
    print('$9C32 verificado: mapea el banco 0x1E, recarga el marco (20 celdas),')
    print('  limpia el buffer y salta al cargador de las 16 celdas blancas')

    # el cargador deja las 16 celdas de texto en blanco
    assert bytes(rom[0x41AAE:0x41AC2]) == bytes(
        [0xA9, 0x14, 0x85, 0x14, 0xA9, 0x52, 0x85, 0x15,
         0xA9, 0x00, 0x8D, 0x26, 0x31, 0xA9, 0x5C, 0x8D, 0x27, 0x31,
         0xA2, 0x10]), \
        'el cargador $9AAE no es el esperado'
    print('  cargador $9AAE: 16 celdas desde word $5C00 (celda 170)  OK')

    # ------------------------------------------------------------------
    # NO TOCAR: los bitmaps de la flecha, que parecen huecos y no lo son
    # ------------------------------------------------------------------
    ptr = bytes(rom[0x41A49:0x41A4D])
    assert ptr == bytes([0x4D, 0x9A, 0x55, 0x9A]), \
        'los punteros de $9A49 no son los esperados'
    assert set(rom[0x41A4D:0x41A55]) == {0x00}, 'el bitmap de borrado cambio'
    assert bytes(rom[0x41A55:0x41A5D]) == bytes(
        [0x00, 0x1F, 0x0E, 0x04, 0x00, 0x00, 0x00, 0x00]), \
        'el bitmap de la flecha cambio'
    print('  $9A4D y $9A55 son BITMAPS de la flecha (referenciados desde')
    print('  $9A49), no huecos: se dejan intactos')

    # ------------------------------------------------------------------
    # el cambio: un byte
    # ------------------------------------------------------------------
    assert bytes(rom[ENTRADA:ENTRADA + 3]) == bytes([0x20, 0x29, 0x9C]), \
        'en $97EE no hay JSR $9C29 sino %s' % bytes(
            rom[ENTRADA:ENTRADA + 3]).hex()
    rom[ENTRADA + 1] = 0x32
    print()
    print('  0x%05X  $97EE: JSR $9C29 -> JSR $9C32' % ENTRADA)
    print('    (limpiar el buffer -> recargar el CG entero y limpiar)')

    # el orden con el mapeo del guion
    assert bytes(rom[0x417F1:0x417FE]) == bytes(
        [0x43, 0x08, 0x48, 0xA9, 0x24, 0x18, 0x65, 0x20, 0x53, 0x04,
         0x1A, 0x53, 0x08]), 'el prologo de $97F1 cambio'
    print('  orden: $97EE recarga -> $97F4 mapea el guion -> $9807 lee')

    # ------------------------------------------------------------------
    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('cargador del CG', 0x41AAE, 0x41ACD),
        ('volcar_y_restaurar', 0x41ACD, 0x41ADB),
        ('tabla rabillo', 0x41ADD, 0x41AFD),
        ('indice $9863', 0x41863, 0x41874),
        ('calc_alto', 0x41FE0, 0x41FEB),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    assert dif == [ENTRADA + 1], 'se han tocado otros bytes: %s' % [
        hex(i) for i in dif]
    print('1 byte modificado, el previsto')

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    i = dif[0]
    rec = bytes([i >> 16 & 0xFF, i >> 8 & 0xFF, i & 0xFF, 0, 1, d[i]])
    open(IPS, 'wb').write(b'PATCH' + rec + b'EOF')
    prueba = bytearray(orig)
    prueba[i] = d[i]
    assert bytes(prueba) == d
    print('IPS round-trip OK (14 B)')

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  Al pasar de pagina, las lineas que sobran en BLANCO, no con el')
    print('  texto de la pagina anterior.')


if __name__ == '__main__':
    main()
