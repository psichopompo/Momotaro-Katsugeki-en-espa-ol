"""build_v147.py - rotulos del menu SELECT escritos POR CODIGO.

Parte de test_menu_v145.pce (MD5 27d45972652f7c7789364f67488d307d).

POR QUE POR CODIGO Y NO POR BAT
-------------------------------
La BAT del menu esta comprimida con RLE en 0x1E7EA y ocupa 510 B, con datos
vivos justo detras (otra BAT sin comprimir en 0x1E9E8). Medido:

    66 celdas ocupadas (las MISMAS que el japones) -> 541 B
    99 celdas (los rotulos de David)               -> 541 B
    limite                                            510 B

Ni reproduciendo la ocupacion del original cabe: el japones entra porque sus
celdas usan patrones consecutivos y repetidos que el RLE comprime, y
cualquier texto nuevo rompe esas carreras. No hay solucion por el arte.

Solucion: dejar la BAT INTACTA y escribir las celdas de rotulo en tiempo de
ejecucion, igual que hace el juego con las cifras ($D5EE: LDX/LDY/JSR $EF2B).

QUE HACE
--------
1. Trocea el arte de David y anade al CG los tiles que faltan.
   El bloque de CG tiene 110 tiles ($100-$16D), no 96: los ultimos son el
   MARCO. Los nuevos van a partir de $16E.
2. Mueve el CG ampliado al hueco muerto del banco $07 (0xF3D9, 3111 B).
   Se cambia SOLO el banco del CG ($D32D). El banco de la BAT ($D301) NO se
   toca: alli cuelga un segundo puntero ($4B28) que se rompia.
3. Inyecta en 0x1BEF1 (logico $DEF1, banco $0D, 271 B de $FF libres) una
   rutina que pinta las celdas de rotulo, y la engancha en $D407.
"""
import os
import sys
import struct
import hashlib
import zlib

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
from descomp_cg import descomprime, comprime
from rle_bat import descomprime as rle_desc
from PIL import Image
import numpy as np

BASE = os.path.join(RAIZ, 'roms', 'test_menu_v145.pce')
SALIDA = os.path.join(RAIZ, 'roms', 'test_codigo_v147.pce')
ARTE = os.path.join(RAIZ, 'capturas', 'david_menu_limpio.png')
MD5_BASE = '27d45972652f7c7789364f67488d307d'

N_TILES = 110
CG_VIEJO = 0x7F8F2
CG_NUEVO = 0xF3D9
CG_TOPE = 0x10000
RUT = 0x1BEF1          # ROM
RUT_LOG = 0xDEF1       # logico en el banco $0D
RUT_TOPE = 0x1C000

ZONAS = [(16, 20, 56, 14), (16, 32, 56, 18), (16, 52, 32, 14),
         (16, 78, 80, 14), (16, 118, 80, 14),
         (112, 20, 64, 14), (192, 20, 48, 16)]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v145'

    im = np.array(Image.open(ARTE).convert('RGB'))
    assert im.shape[:2] == (176, 256)

    p = open(os.path.join(RAIZ, 'docs', 'select_pal.bin'), 'rb').read()
    IDX = {}
    for i in range(16):
        c = struct.unpack('<H', p[i * 2:i * 2 + 2])[0]
        IDX[(((c >> 3) & 7) * 36, ((c >> 6) & 7) * 36, (c & 7) * 36)] = i

    def tile(cx, cy):
        out = bytearray(32)
        for y in range(8):
            b = [0, 0, 0, 0]
            for x in range(8):
                c = tuple(im[cy * 8 + y, cx * 8 + x])
                assert c in IDX, 'color fuera de paleta en %d,%d' % (cx * 8 + x, cy * 8 + y)
                for k in range(4):
                    if (IDX[c] >> k) & 1:
                        b[k] |= 0x80 >> x
            out[y * 2] = b[0]; out[y * 2 + 1] = b[1]
            out[16 + y * 2] = b[2]; out[16 + y * 2 + 1] = b[3]
        return bytes(out)

    cg, fin_cg = descomprime(rom, CG_VIEJO, N_TILES)
    assert fin_cg == 0x7FFFD, 'el bloque de CG no acaba donde se midio'
    assert all(b == 0xFF for b in rom[fin_cg:0x80000])

    bat, _ = rle_desc(rom, 0x1E7EA, 704)
    liso = bytes([0xFF, 0] * 8 + [0, 0] * 8)
    conocidos = {cg[i * 32:(i + 1) * 32]: 0x100 + i for i in range(N_TILES)}

    # ---- celdas a pintar y tiles que hacen falta ----
    celdas = sorted({(cx, cy) for (x, y, w, h) in ZONAS
                     for cy in range(y // 8, (y + h - 1) // 8 + 1)
                     for cx in range(x // 8, (x + w - 1) // 8 + 1)},
                    key=lambda t: (t[1], t[0]))
    extra = []
    pintar = []
    for (cx, cy) in celdas:
        t = tile(cx, cy)
        if t == liso:
            continue                      # ya es relleno en la BAT
        if t in conocidos:
            pat = conocidos[t]
        else:
            if t not in extra:
                extra.append(t)
            pat = 0x100 + N_TILES + extra.index(t)
        if 0x100 + bat[cy * 32 + cx] == pat:
            continue                      # la BAT ya pone ese patron
        assert pat <= 0x3FF
        pintar.append((cx, cy, pat))

    cg_nuevo = cg + b''.join(extra)
    n_tiles = len(cg_nuevo) // 32
    comp = comprime(cg_nuevo)
    assert descomprime(comp + b'\x00' * 64, 0, n_tiles)[0] == cg_nuevo
    assert CG_NUEVO + len(comp) <= CG_TOPE, 'el CG no cabe en el hueco'
    assert all(b == 0xFF for b in rom[CG_NUEVO:CG_TOPE]), 'el hueco no esta libre'

    # ---- la rutina ----
    # Tabla de RACHAS: [cx][cy][pat_lo][pat_hi][n]  ...  terminador $FF
    # Una racha son n celdas seguidas en horizontal cuyos patrones son
    # CONSECUTIVOS (pat, pat+1, pat+2...). Los tiles nuevos se numeran en
    # orden de aparicion, asi que casi todas las palabras forman una racha.
    # 31 rachas x 5 B = 156 B, frente a 4 B por celda = 409 B.
    pintar.sort(key=lambda t: (t[1], t[0]))
    rachas = []
    i = 0
    while i < len(pintar):
        cx, cy, pat = pintar[i]
        j = i + 1
        while (j < len(pintar) and pintar[j][1] == cy
               and pintar[j][0] == pintar[j - 1][0] + 1
               and pintar[j][2] == pintar[j - 1][2] + 1
               and j - i < 255):
            j += 1
        rachas.append((cx, cy, pat, j - i))
        i = j

    TAB = RUT_LOG + 0x50
    c = bytearray()
    c += bytes([0x20, 0xC3, 0xD4])                # JSR $D4C3  (lo que sustituimos)
    c += bytes([0xA0, 0x00])                      # LDY #$00
    ini_bucle = len(c)
    c += bytes([0xB9, TAB & 0xFF, TAB >> 8])      # LDA tabla,Y     cx
    c += bytes([0xC9, 0xFF])                      # CMP #$FF
    c += bytes([0xF0, 0x00])                      # BEQ fin
    br = len(c) - 1
    c += bytes([0x85, 0x10])                      # STA $10         cx
    c += bytes([0xC8, 0xB9, TAB & 0xFF, TAB >> 8])# INY / LDA tabla,Y
    c += bytes([0x85, 0x11])                      # STA $11         cy
    c += bytes([0xC8, 0xB9, TAB & 0xFF, TAB >> 8])# INY / LDA tabla,Y
    c += bytes([0x85, 0x12])                      # STA $12         pat lo
    c += bytes([0xC8, 0xB9, TAB & 0xFF, TAB >> 8])# INY / LDA tabla,Y
    c += bytes([0x85, 0x13])                      # STA $13         pat hi
    c += bytes([0xC8, 0xB9, TAB & 0xFF, TAB >> 8])# INY / LDA tabla,Y
    c += bytes([0x85, 0x1A])                      # STA $1A         n
    c += bytes([0xC8])                            # INY
    c += bytes([0x5A])                            # PHY
    c += bytes([0xA6, 0x10, 0xA4, 0x11])          # LDX $10 / LDY $11
    c += bytes([0x20, 0x2B, 0xEF])                # JSR $EF2B   $16/$17
    c += bytes([0x20, 0x1A, 0xD6])                # JSR $D61A   MAWR
    esc = len(c)
    c += bytes([0xA5, 0x12, 0x8D, 0x02, 0x00])    # LDA $12 / STA $0002
    c += bytes([0xA5, 0x13, 0x8D, 0x03, 0x00])    # LDA $13 / STA $0003
    c += bytes([0xE6, 0x12])                      # INC $12
    c += bytes([0xD0, 0x02])                      # BNE +2
    c += bytes([0xE6, 0x13])                      # INC $13
    c += bytes([0xC6, 0x1A])                      # DEC $1A
    d = len(c) + 2 - esc
    c += bytes([0xD0, (256 - d) & 0xFF])          # BNE escribir
    c += bytes([0x7A])                            # PLY
    d = len(c) + 2 - ini_bucle
    c += bytes([0x80, (256 - d) & 0xFF])          # BRA bucle
    c[br] = len(c) - br - 1
    c += bytes([0x60])                            # RTS
    cuerpo = c
    assert len(cuerpo) <= 0x50, 'el codigo invade la tabla: %d B' % len(cuerpo)

    tabla = bytearray()
    for (cx, cy, pat, n) in rachas:
        assert cx != 0xFF and n >= 1
        tabla += bytes([cx, cy, pat & 0xFF, pat >> 8, n])
    tabla += b'\xFF'

    bloque = bytearray(b"\xFF" * 0x50)
    bloque[:len(cuerpo)] = cuerpo
    bloque += tabla
    assert RUT + len(bloque) <= RUT_TOPE, \
        'la rutina no cabe: %d B, hay %d' % (len(bloque), RUT_TOPE - RUT)
    assert all(b == 0xFF for b in rom[RUT:RUT + len(bloque)]), 'el hueco no esta libre'

    # ---- escribir ----
    rom[CG_VIEJO:0x80000] = b'\xFF' * (0x80000 - CG_VIEJO)
    rom[CG_NUEVO:CG_NUEVO + len(comp)] = comp
    rom[RUT:RUT + len(bloque)] = bloque

    banco = CG_NUEVO // 0x2000
    log_cg = 0x4000 + (CG_NUEVO - banco * 0x2000)
    for off, viejo, nuevo, nom in [(0x1B32E, 0x3F, banco, 'banco CG'),
                                   (0x1B33D, 0xF2, log_cg & 0xFF, 'CG lo'),
                                   (0x1B341, 0x58, log_cg >> 8, 'CG hi')]:
        assert rom[off] == viejo, '%s: esperaba $%02X, hay $%02X' % (nom, viejo, rom[off])
        rom[off] = nuevo

    # gancho: $D407 es la cadena que monta el menu y acaba en
    #     $D419  JMP $D5D1
    # No hay hueco detras ($D41C ya es el motor de texto), asi que se cambia
    # la PRIMERA llamada:
    #     $D407  JSR $D4C3   ->   JSR rutina
    # y la rutina hace JSR $D4C3 al entrar y pinta los rotulos al salir.
    assert rom[0x1B407] == 0x20 and rom[0x1B408] == 0xC3 and rom[0x1B409] == 0xD4, \
        '$D407 no empieza con JSR $D4C3'
    rom[0x1B408] = RUT_LOG & 0xFF
    rom[0x1B409] = RUT_LOG >> 8

    open(SALIDA, 'wb').write(bytes(rom))
    print('escrito', SALIDA)
    print('MD5  ', hashlib.md5(rom).hexdigest())
    print('SHA1 ', hashlib.sha1(rom).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
    print()
    print('tiles      %d -> %d  (%d nuevos)' % (N_TILES, n_tiles, len(extra)))
    print('CG         %d B en 0x%05X (logico $%04X, banco $%02X)'
          % (len(comp), CG_NUEVO, log_cg, banco))
    print('BAT        INTACTA')
    print('rutina     %d B de codigo, %d rachas (%d celdas) en 0x%05X ($%04X)'
          % (len(cuerpo), len(rachas), len(pintar), RUT, RUT_LOG))
    print('           bloque total %d B de %d libres' % (len(bloque), RUT_TOPE - RUT))


if __name__ == '__main__':
    main()
