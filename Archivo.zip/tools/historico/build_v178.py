#!/usr/bin/env python3
"""
build_v178.py - PASO 2 sobre la v177: la FLECHA de continuar, al lado derecho.

QUE ES LA FLECHA (medido con las dos capturas de David, no deducido)
--------------------------------------------------------------------
    CF60  00 00 00 1F 00 0E 00 04 00 00 ...   <- flecha VISIBLE
    CF60  00 00 00 00 00 00 00 00 00 00 ...   <- flecha OCULTA

El Memory Viewer de Mesen direcciona la VRAM en BYTES, el VDC en WORDS:

    byte $CF60 / 2 = word $67B0
    $67B0 // 64    = celda 0x19E        <- esquina inferior IZQUIERDA
    $67B0 %  64    = 48                 <- PLANO 3  (norma 108)

O sea: **la flecha NO es un sprite**. No esta en la lista de `$7C02` ni en
la tabla del rabillo `$9ADD`, y por eso moverlo todo en la v177 no la movio.
Es un glifo de 8x8 que el motor escribe en el plano 3 de la esquina
inferior izquierda del marco, igual que escribe las letras.

Los words de la captura leidos como los escribe el VDC:

    word 0 = $0000   word 1 = $1F00   word 2 = $0E00   word 3 = $0400
                            ^^ byte ALTO = columnas 0-7 = mitad IZQUIERDA

lo que ademas CONFIRMA el significado del cuadrante `$3665` (ver abajo).

La rutina, en el banco $20:

    $99C6  INC $365B / BIT #$0F        (temporiza el parpadeo)
           AND #$10 / LSR x3 -> Y      (alterna 0 y 2)
           LDA $9A49,Y -> $3661/$3662  ptr al dibujo:
                                         $9A4D = 00 00 00 00 00 00 00 00 (borrar)
                                         $9A55 = 00 1F 0E 04 00 00 00 00 (flecha)
           LDA #$B0 / STA $3663  ->  destino = word $67B0
           LDA #$67 / STA $3664  ->  0x419E8 <-- ESTE BYTE
           STZ $3665                  cuadrante 0 = mitad IZQUIERDA, filas 0-7
           JMP $9D33                  escribe 8 words

EL ERROR QUE COMETI Y COMO LO VI
--------------------------------
Mi primer borrador tocaba tambien `$9A0E` («camino B») y la tabla de
cuadrantes `$9A47` = `03 02`, dando por hecho que era la misma flecha por
otro camino. **Es falso, y lo vi al desensamblarlo entero antes de escribir
la ROM.** `$9A0E` escribe en `$69B0` (celda `0x1A6`, el RELLENO) DOS cosas:
borra un cuadrante y dibuja el bitmap de `$9A5D` = `00 00 FE 7C 38 10 00 00`
en el otro, alternando con `$365C`, que es un indice que vale 0 o 1 y que
`$97D0` conmuta con el mando.

    $9A5D = FE 7C 38 10  -> triangulo hacia ABAJO, no hacia la derecha
    $365C -> 0 / 1       -> dos posiciones
    cuadrantes 03 y 02   -> abajo-derecha y abajo-izquierda

Eso no es la flecha de continuar: es el **cursor de seleccion de dos
opciones** (el si/no de las tiendas). Tocarlo habria roto las compras.
Fallo de razonamiento por mi parte: agrupe dos rutinas por parecerse el
`LDA #$B0` inicial, sin mirar el bitmap ni quien conmuta la variable.
**No se toca.**

EL ARREGLO: UN BYTE
-------------------
Llevar la flecha a la esquina inferior DERECHA, que en la v177 es la celda
`0x1AE` (registro 13 de la lista, dX = X0+96, dY = Y0+24):

    0x1AE * 64 + 48 = $6BB0     (en el Memory Viewer: byte $D760)

El byte bajo del destino ya es `$B0`, asi que solo cambia el alto:

    ROM 0x419E8   LDA #$67  ->  LDA #$6B

El cuadrante se queda en 0. Comprobado contra el CG volcado que la mitad
IZQUIERDA de `0x1AE` es blanca en las 8 filas y la flecha cabe entera,
mientras que la mitad derecha chocaria con la diagonal del borde:

    1AE mitad izq       1AE mitad der
      0 WWWWWWWW          0 WWWWWWW6
      1 WWWWWWWW  AAAAA   1 WWWWWWW6  AAAAA  <- choca en la columna 7
      2 WWWWWWWW   AAA    2 WWWWWW6.   AAA   <- choca en la columna 6
      3 WWWWWWWW    A     3 WWWWWW6.    A
      6 66666666          6 666.....

No se toca nada mas: ni la lista de sprites, ni el CG, ni las tablas de
texto, ni el cursor de las tiendas.

Uso:  python3 tools/build_v178.py
"""
import hashlib
import zlib
import struct

BASE = 'roms/momotaro_es_v177.pce'
SALIDA = 'roms/momotaro_es_v178.pce'
IPS = 'parches/momotaro_v178.ips'
MD5_BASE = '5537a1e0f32ad33098559af2ebea2301'
VRAM = 'docs/aldeano_vram.bin'

CELDA_VIEJA = 0x19E          # esquina inferior IZQUIERDA
CELDA_NUEVA = 0x1AE          # esquina inferior DERECHA
PLANO3 = 48
OFF_ALTO = 0x419E8           # el inmediato del LDA #$67

FLECHA = [0x00, 0x1F, 0x0E, 0x04, 0x00, 0x00, 0x00, 0x00]


def pixeles(vram, celda, mitad):
    """Devuelve el color de las 8x8 de una mitad de la celda (filas 0-7)."""
    w = struct.unpack('<64H', vram[celda * 128:celda * 128 + 128])
    out = []
    for y in range(8):
        fila = []
        for x in range(8):
            bit = 15 - (x + (8 if mitad else 0))
            fila.append(((w[y] >> bit) & 1)
                        | (((w[16 + y] >> bit) & 1) << 1)
                        | (((w[32 + y] >> bit) & 1) << 2)
                        | (((w[48 + y] >> bit) & 1) << 3))
        out.append(fila)
    return out


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v177 (md5 %s)' % md5
    orig = bytes(rom)
    vram = open(VRAM, 'rb').read()

    # --- 1. la captura de David cuadra con la celda 0x19E --------------
    w_viejo = CELDA_VIEJA * 64 + PLANO3
    assert 0xCF60 // 2 == w_viejo, 'la captura no apunta a la celda 19E'
    print('captura de David: VRAM byte $CF60 = word $%04X = celda %03X plano 3'
          % (w_viejo, CELDA_VIEJA))

    # --- 2. la rutina es la que creo que es ----------------------------
    esperado = bytes([0xA9, 0xB0, 0x8D, 0x63, 0x36,     # LDA #$B0 / STA $3663
                      0xA9, 0x67, 0x8D, 0x64, 0x36,     # LDA #$67 / STA $3664
                      0x9C, 0x65, 0x36,                 # STZ $3665
                      0x4C, 0x33, 0x9D])                # JMP $9D33
    a = 0x419E2
    assert bytes(rom[a:a + 16]) == esperado, \
        'la rutina $99C6 no es la esperada: %s' % bytes(rom[a:a + 16]).hex()
    assert rom[OFF_ALTO] == w_viejo >> 8, 'el byte alto no es $%02X' % (w_viejo >> 8)
    print('rutina $99C6 verificada; el byte a cambiar es ROM 0x%05X' % OFF_ALTO)

    # y el bitmap de la flecha es el de la captura
    assert list(rom[0x41A55:0x41A5D]) == FLECHA, 'el bitmap de $9A55 no cuadra'
    print('bitmap $9A55 = %s  (el 1F 0E 04 de la captura)'
          % ' '.join('%02X' % b for b in FLECHA))

    # --- 3. la celda nueva admite la flecha (norma 109) ----------------
    izq = pixeles(vram, CELDA_NUEVA, 0)
    der = pixeles(vram, CELDA_NUEVA, 1)
    choques_izq = [(x, y) for y in range(8) for x in range(8)
                   if (FLECHA[y] >> (7 - x)) & 1 and izq[y][x] != 7]
    choques_der = [(x, y) for y in range(8) for x in range(8)
                   if (FLECHA[y] >> (7 - x)) & 1 and der[y][x] != 7]
    assert not choques_izq, \
        'la mitad izquierda de %03X no admite la flecha: %s' % (CELDA_NUEVA,
                                                                choques_izq)
    assert choques_der, \
        'la mitad derecha deberia chocar con la diagonal y no choca'
    print('celda %03X mitad IZQUIERDA: la flecha cabe entera sobre blanco'
          % CELDA_NUEVA)
    print('celda %03X mitad derecha: chocaria con la diagonal en %s -> se '
          'mantiene el cuadrante 0' % (CELDA_NUEVA, choques_der))

    # --- 4. el cursor de las tiendas NO se toca ------------------------
    cursor = bytes([0x00, 0x00, 0xFE, 0x7C, 0x38, 0x10, 0x00, 0x00])
    assert bytes(rom[0x41A5D:0x41A65]) == cursor, 'el bitmap del cursor cambio'
    assert bytes(rom[0x41A47:0x41A49]) == bytes([0x03, 0x02]), \
        'la tabla de cuadrantes del cursor cambio'
    print('cursor de tiendas ($9A0E / $9A5D / $9A47): intacto')

    # --- 5. el cambio --------------------------------------------------
    w_nuevo = CELDA_NUEVA * 64 + PLANO3
    rom[OFF_ALTO] = w_nuevo >> 8
    print()
    print('  0x%05X  LDA #$%02X -> LDA #$%02X'
          % (OFF_ALTO, w_viejo >> 8, w_nuevo >> 8))
    print('  destino: word $%04X -> $%04X   (celda %03X -> %03X)'
          % (w_viejo, w_nuevo, CELDA_VIEJA, CELDA_NUEVA))
    print('  en el Memory Viewer de Mesen: byte $%04X -> $%04X'
          % (w_viejo * 2, w_nuevo * 2))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    assert dif == [OFF_ALTO], 'se han tocado otros bytes: %s' % dif
    print('\n1 byte modificado, el previsto')

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = [bytes([i >> 16 & 0xFF, i >> 8 & 0xFF, i & 0xFF, 0, 1, d[i]])
           for i in dif]
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')

    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        off = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n = raw[p + 3] << 8 | raw[p + 4]
        prueba[off:off + n] = raw[p + 5:p + 5 + n]
        p += 5 + n
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
