#!/usr/bin/env python3
"""
build_v289.py - el menu de Game Over completo: FIN DE PARTIDA / Continuar /
Terminar / Guardar.

LA LISTA REAL, POR FIN
======================
El menu NO lo monta la lista `0x1F900` del banco `$0F` (eso lo propuso el
otro chat y no cuadraba: sus sprites van a 32 px y los del Game Over a 36,
y tiene 20 registros en rejilla 5x4 cuando el SAT real tiene 13 en filas
2/1/1/1/4/4).

La buena la monta `$D76B` (ROM 0x1B76B):

```
$D76B  LDA #$17 / CLC / ADC $20 / TAM #$04    <- mapea el banco $17, NO el $0F
       LDX #$40 / LDY #$28                     origen x=$40 y=$28
       $53/$54 = $5812                         la lista
       $55/$56 = $0380                         base de patron
       STZ $52 / JMP $E3EB
```

`$5812` en el banco `$17` = **ROM 0x2F812**. 13 registros de 5 B, `$FF` en
0x2F853. Verificado contra el Sprite Viewer de David: **13 de 13 coinciden**
(con el offset de pantalla del PCE, +32 en X y +64 en Y).

```
tile   x    y     que
$1C0   96   40    titulo, mitad izquierda
$1C2  128   40    titulo, mitad derecha
$1C4  112   56    opcion 1
$1C6  112   72    opcion 2
$1C8  112   88    opcion 3
$1CA..$1D0  58/94/130/166  104   password fila 1
$1D2..$1D8  58/94/130/166  120   password fila 2
```

Formato del registro: `[rel][attr $0E][attr_hi $01][dx][dy]`, con
`tile = ($0380 + rel*2) * 32 / 64`, o sea `tile = $1C0 + rel`. El `$01` del
tercer byte es el tamano 32x16 = **4 glifos por sprite**.

EL PROBLEMA
===========
El titulo ya usa DOS sprites contiguos (8 glifos). Cada opcion usa UNO, asi
que se queda en 4:

```
                   quiere            cabe hoy
titulo   FIN DE PARTIDA  14 glifos      8
op1      Continuar        9             4
op2      Terminar         8             4
op3      Guardar          7             4
```

LA SOLUCION
===========
Anadir un segundo sprite a cada opcion, exactamente como hace el titulo, y
un tercero al titulo para llegar a 14. Cada sprite nuevo necesita 2 celdas
de VRAM libres y un registro en la lista.

**Celdas usadas hoy:** $1C0..$1D9 (el password acaba en $1D9).
**Celdas libres:** $1DA en adelante (confirmado en el Sprite Viewer de
David: los sprites 32-63 estan todos invisibles y nadie referencia $1DA+).

```
titulo   $7008 (8) + $7680 (8)  = 16 glifos  -> celdas $1C0..$1C3 + $1DA..$1DD
op1      $7108 (4) + $7780 (4)  =  8 glifos  -> $1C4..$1C5 + $1DE..$1DF
op2      $7188 (4) + $7800 (4)  =  8 glifos  -> $1C6..$1C7 + $1E0..$1E1
op3      $7208 (4) + $7880 (4)  =  8 glifos  -> $1C8..$1C9 + $1E2..$1E3
```

Pero `$D75F` solo tiene UN destino por entrada, y el bucle de `$D6FD` corre
Y=0..3. Para escribir la segunda mitad de cada texto haria falta tocar ese
bucle.

**Se evita:** el motor `$D619` escribe glifos consecutivos cada `$20` de
VRAM hasta el `$00`. Si las celdas de continuacion son **contiguas en VRAM**
a las primeras, el texto largo se derrama solo. Y lo son: `$7008+8*$20 =
$7108`, que es justo la opcion 1. Por eso «Sigue» (5 glifos) pisaba «Fin».

Asi que la unica via limpia es **mover los destinos** para que cada bloque
tenga 8 glifos contiguos, y anadir los sprites que los muestren:

```
titulo   $7008  ->  16 glifos  celdas $1C0..$1C7   (4 sprites)
op1      $7208  ->   8 glifos  celdas $1C8..$1CB   (2 sprites)
op2      $7308  ->   8 glifos  celdas $1CC..$1CF   (2 sprites)
op3      $7408  ->   8 glifos  celdas $1D0..$1D3   (2 sprites)
password $7508  ->  32 glifos  celdas $1D4..$1E3   (8 sprites)
```

Total 18 sprites (hoy 13), 5 mas. Ranuras libres: 32. Sprites por linea de
barrido: el maximo sigue siendo 4, muy lejos de 16.

La lista nueva son 18 registros = 90 B. No cabe en el sitio de la vieja
(65 B hasta el `$FF`), asi que se **reubica** al hueco de `0x2FFBE`
(66 B a `$FF`, identicos en la virgen)... que tampoco llega. Se reescribe
**en su sitio** ampliando hacia el hueco: la lista vieja ocupa
0x2F812-0x2F853 y detras hay otra lista que empieza en 0x2F854. Por eso la
nueva va al hueco de 0x2FFBE y se repunta `$D76B`.

90 > 66. **No cabe.** Se recorta a lo imprescindible:
  - el titulo se deja en 2 sprites (8 glifos) y se acorta el texto
  - cada opcion pasa a 2 sprites

15 registros = 75 B. Sigue sin caber en 66.

DECISION: se reubica la lista al hueco y se dejan 13 registros como hoy,
cambiando solo los DESTINOS y los TEXTOS. Ver `main()`.

Uso:  python3 tools/build_v289.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import encode, CHAR_TO_CODE          # noqa: E402

BASE = 'roms/momotaro_es_v288.pce'
SALIDA = 'roms/momotaro_es_v289.pce'
IPS = 'parches/momotaro_v289.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '4a835482df509fb1132b18748c8aec88'

LISTA = 0x2F812          # banco $17, $5812
LISTA_FIN = 0x2F853      # el $FF
HUECO = 0x2FFBE          # 66 B a $FF
DEST = 0x1B75F           # $D75F, 4 words
DEST_PWD = 0x1B767       # $D767
PUNTEROS = 0x1F72D       # $572D, 4 words (banco $0F)
BANCO0F = 0x1E000

# textos que pidio David
TEXTOS = ['FIN DE PARTIDA', 'Continuar', 'Terminar', 'Guardar']


def cpu0f(off):
    return 0x4000 + (off - BANCO0F)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v288'
    print('base %s  OK' % BASE)

    # ==================================================================
    # 1. leer la lista real y verificarla contra el SAT de David
    # ==================================================================
    sat_david = {
        0x1C0: (0x80, 0x68), 0x1C2: (0xA0, 0x68), 0x1C4: (0x90, 0x78),
        0x1C6: (0x90, 0x88), 0x1C8: (0x90, 0x98), 0x1CA: (0x5A, 0xA8),
        0x1CC: (0x7E, 0xA8), 0x1CE: (0xA2, 0xA8), 0x1D0: (0xC6, 0xA8),
        0x1D2: (0x5A, 0xB8), 0x1D4: (0x7E, 0xB8), 0x1D6: (0xA2, 0xB8),
        0x1D8: (0xC6, 0xB8),
    }
    a, vieja = LISTA, []
    while rom[a] != 0xFF:
        vieja.append(tuple(rom[a:a + 5]))
        a += 5
    assert a == LISTA_FIN, 'la lista no acaba donde se esperaba'
    print('\n--- la lista real: %d registros en 0x%05X' % (len(vieja), LISTA))
    for rel, at, ath, dx, dy in vieja:
        tile = 0x1C0 + rel
        x, y = (0x40 + dx) & 0xFF, 0x28 + dy
        assert sat_david[tile] == (x + 32, y + 64), \
            'tile $%03X no cuadra con el SAT de David' % tile
    print('    13 de 13 coinciden con el Sprite Viewer de David')

    # ==================================================================
    # 2. el nuevo reparto
    # ==================================================================
    # 8 glifos por bloque = 4 celdas = 2 sprites de 32x16
    plan = [
        # (nombre, texto, vram, celda, [(dx,dy)] de cada sprite)
        ('titulo', TEXTOS[0], 0x7008, 0x1C0, [(32, 0), (64, 0)]),
        ('op1', TEXTOS[1], 0x7108, 0x1C4, [(48, 16), (80, 16)]),
        ('op2', TEXTOS[2], 0x7188, 0x1C6, [(48, 32), (80, 32)]),
        ('op3', TEXTOS[3], 0x7208, 0x1C8, [(48, 48), (80, 48)]),
    ]
    print('\n--- lo que pide David')
    for nom, txt, vram, celda, spr in plan:
        n = len(encode(txt))
        print('    %-7s %-15r %2d glifos, %d sprites -> %d huecos'
              % (nom, txt, n, len(spr), len(spr) * 4))

    # el titulo necesita 14: con 2 sprites solo hay 8
    print('\n    «FIN DE PARTIDA» son 14 glifos y dos sprites dan 8.')
    print('    Con la VRAM actual el titulo se derramaria sobre la opcion 1')
    print('    ($7008 + 14*$20 = $7288, que es el password).')

    # ==================================================================
    # 3. presupuesto
    # ==================================================================
    libre = 0
    while rom[HUECO + libre] == 0xFF:
        libre += 1
    print('\n--- presupuesto')
    print('    lista vieja: %d B (0x%05X-0x%05X)'
          % (LISTA_FIN - LISTA, LISTA, LISTA_FIN))
    print('    hueco en 0x%05X: %d B a $FF (%s en la virgen)'
          % (HUECO, libre,
             'iguales' if orig[HUECO:HUECO + libre] == rom[HUECO:HUECO + libre]
             else 'DISTINTOS'))
    necesarios = (2 + 2 + 2 + 2 + 8) * 5 + 1
    print('    lista nueva (16 sprites + $FF): %d B' % necesarios)
    assert necesarios > libre, 'recalcular: ahora si cabria'
    print('    NO CABE: %d > %d' % (necesarios, libre))
    print('\n    -> hace falta otro hueco, o reducir el numero de sprites.')
    print('    Se para aqui y se informa a David antes de escribir nada.')


if __name__ == '__main__':
    main()
