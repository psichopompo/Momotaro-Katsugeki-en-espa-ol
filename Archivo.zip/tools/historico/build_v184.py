#!/usr/bin/env python3
"""
build_v184.py - fusion de las dos ramas + bocadillo de 16x4.

DE DONDE VIENE CADA COSA
------------------------
Hasta ahora habia dos ramas en paralelo:

  rama A (este chat):  v177 flecha -> v178 -> v179 CG ampliado
  rama B (otro chat):  v178 -> v183 guion insertado + descompresor

La v183 y la v179 **no se solapan en un solo byte**. Comprobado zona a zona:

```
v178 -> v183 (7025 B en 7 zonas):
  41807..4180D   hook del descompresor en $9807 (JSR $793B + 4 NOP)
  4194A..41951   tabla $994A reescrita (a6 a7 a8 a9 aa ab ac ad)
  4197B..4197C   el clon $9952 llama a $79EB
  41BB9..41BB9   CPX #$24 -> #$18 en $9B7C
  48004..480E7   punteros del guion
  48F91..4A483   el guion en castellano
  4B93B..4BF3F   descompresor ($793B) y adaptador ($79EB)

v178 -> v179 (240 B en 3 zonas):
  3D214..3D37F   stream del CG: 13 celdas de relleno
  41AAE..41ACD   cargador nuevo
  41C5C..41C5E   JMP $9B7C -> JMP $9AAE
```

Verificado sobre la v183: el hueco `0x3D214` sigue a `$FF`, la zona muerta
`$9AAE` sigue con los restos de la lista vieja y `$9C5C` sigue con
`JMP $9B7C`. Asi que la v179 se **reaplica** limpia sobre la v183.

EL TRABAJO DEL OTRO CHAT QUE HAY QUE RESPETAR
---------------------------------------------
1. `$9807` empieza con `JSR $793B` (descompresor) + 4 `NOP`. **No tocar.**
2. `$9952` (el clon, la primera pagina) llama a `$79EB`, que es un
   adaptador: copia `$14/$15` a `$92/$93`, llama al descompresor y devuelve
   el puntero. Resuelve el problema de los dos lectores sin unificar los
   motores. **No tocar.**
3. `$9B7C` tiene `CPX #$18` (24 posiciones = 12x2). Este parche lo sube a
   `#$20` (32 = 16x2), que es la mitad de pagina de 16x4.
4. El clon `$9952` **sigue en 6x3** (`$99AB CMP #$06`, `$99BA CMP #$03`).
   Hay que convertirlo tambien (norma 118).

EL BOCADILLO DE 16x4
--------------------
La medicion que fija el numero (entrada 123 y siguientes):

* El buffer `$3667` son **36 bytes** y no hay donde ampliarlo (12 volcados
  de RAM cruzados, cero rachas de 76 B). Asi que una pagina de 4 lineas
  **no cabe entera**: hay que volcar por mitades.
* El volcado `$9B7C` lee `$9BBD` indexada por X. Para volcar la 2a mitad en
  otras celdas hacen falta dos tablas (144 B, no caben junto a `$9C29`) o
  **un offset constante**, que exige que las dos filas de celdas sean
  contiguas y del mismo tamano.
* Tramos de celdas libres contiguas, cruzando **25 volcados de VRAM**:
  `139-13F` (7) y `170-17F` (**16**). El maximo es 16.

De ahi sale 16x4:

```
  fila A (lineas 1-2): 170..177   8 celdas = 16 glifos
  fila B (lineas 3-4): 178..17F   8 celdas
  offset A->B = 8 celdas * 64 words = $200   CONSTANTE
  buffer: 16x2 = 32 B de los 36    tabla: 32 entradas de las 36
```

Coste tipografico sobre los 87 dialogos (`maquetar.py`):

```
 12x2 (hoy)  459 paginas   16x4  199 paginas   18x4  179   19x4  162
```

16x4 es **menos de la mitad** que lo actual, y la palabra mas larga del
guion (`peligrosisimo.`, 14) cabe de sobra.

QUE HACE ESTE PARCHE
--------------------
1. Reaplica la v179 (stream del CG + cargador), cambiando el destino de la
   celda `0x170` y **16 celdas** en vez de 13.
2. Tablas `$9BBD`/`$9C05` para 16x2 sobre la fila A.
3. Contadores a 16 columnas x 2 lineas por mitad, en **los dos motores**.
4. Indice de celda: `linea*12` -> `linea*16`.
5. `$9B7C`: `CPX #$18` -> `CPX #$20`.

**NO** toca todavia el volcado de la 2a mitad ni la lista de sprites del
marco: eso es el paso siguiente, para poder verificar este por separado.
Con este parche el bocadillo pasa a **16x2** con las celdas nuevas; si eso
se ve bien, se anade la 2a mitad.

Uso:  python3 tools/build_v184.py
"""
import hashlib
import zlib
import struct
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v183.pce'
SALIDA = 'roms/momotaro_es_v184.pce'
IPS = 'parches/momotaro_v184.ips'
MD5_BASE = 'b1a22faff8bb501eaa253dd74722090d'

HUECO = 0x3D214
HUECO_FIN = 0x3D400
CARGADOR = 0x41AAE
CARGADOR_FIN = 0x41ADD

CELDA0 = 0x170               # primera celda de relleno nuevo
N_CELDAS = 16                # 170..17F
COLS = 16                    # 16 glifos por linea
LIN_MITAD = 2                # lineas por volcado
PLANO3 = 48

TABLA = 0x41BBD              # $9BBD destinos (36 words)
CUAD = 0x41C05               # $9C05 cuadrantes (36 bytes)


def celda_blanca():
    return struct.pack('<64H', *([0xFFFF] * 48 + [0] * 16))


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v183 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # 0. Comprobar que el trabajo del otro chat esta donde creo
    # ------------------------------------------------------------------
    assert bytes(rom[0x41807:0x4180E]) == bytes(
        [0x20, 0x3B, 0x79, 0xEA, 0xEA, 0xEA, 0xEA]), \
        'el hook del descompresor en $9807 no es el esperado'
    assert bytes(rom[0x4197A:0x4197D]) == bytes([0x20, 0xEB, 0x79]), \
        'el clon no llama a $79EB'
    assert rom[0x41BB9] == 0x18, 'el CPX de $9B7C no es #$18'
    print('base v183 verificada: descompresor $793B, adaptador $79EB, '
          'CPX #$18')

    # ------------------------------------------------------------------
    # 1. Stream del CG: 16 celdas blancas
    # ------------------------------------------------------------------
    assert set(rom[HUECO:HUECO_FIN]) == {0xFF}, 'el hueco 0x3D214 no esta libre'
    blanca = celda_blanca()
    nuevo = b''.join(comprime(blanca) for _ in range(N_CELDAS))
    assert HUECO + len(nuevo) <= HUECO_FIN, \
        'el stream (%d B) no cabe en %d B' % (len(nuevo), HUECO_FIN - HUECO)
    f = Flujo(bytes(nuevo), 0)
    for k in range(N_CELDAS):
        assert b''.join(tile(f) for _ in range(4)) == blanca, \
            'la celda %d no es blanca' % k
    assert f.p == len(nuevo)
    rom[HUECO:HUECO + len(nuevo)] = nuevo
    print('stream: %d celdas blancas = %d B en 0x%05X (round-trip OK)'
          % (N_CELDAS, len(nuevo), HUECO))

    # ------------------------------------------------------------------
    # 2. Cargador en la zona muerta $9AAE
    # ------------------------------------------------------------------
    v178 = open('roms/momotaro_es_v178.pce', 'rb').read()
    assert rom[CARGADOR:CARGADOR_FIN] == v178[CARGADOR:CARGADOR_FIN], \
        'la zona muerta $9AAE ya no tiene los restos de la lista vieja'
    w = CELDA0 * 64
    ptr = 0x4000 + (HUECO - 0x3C000)
    assert ptr == 0x5214
    cargador = bytes([
        0xA9, ptr & 0xFF, 0x85, 0x14,
        0xA9, ptr >> 8, 0x85, 0x15,
        0xA9, w & 0xFF, 0x8D, 0x26, 0x31,
        0xA9, w >> 8, 0x8D, 0x27, 0x31,
        0xA2, N_CELDAS,
        0xDA,                        # PHX
        0x20, 0x1F, 0x86,            # JSR $861F
        0xFA, 0xCA, 0xD0, 0xF8,      # PLX / DEX / BNE
        0x4C, 0x7C, 0x9B,            # JMP $9B7C
    ])
    assert len(cargador) <= CARGADOR_FIN - CARGADOR
    rom[CARGADOR:CARGADOR + len(cargador)] = cargador
    # el BNE tiene que volver al PHX
    assert CARGADOR + 26 + 2 + (0xF8 - 256) == CARGADOR + 20, 'BNE mal'
    print('cargador en $9AAE (%d B): %d celdas desde word $%04X (celda %03X)'
          % (len(cargador), N_CELDAS, w, CELDA0))

    o = 0x41C5C
    assert bytes(rom[o:o + 3]) == bytes([0x4C, 0x7C, 0x9B])
    rom[o + 1], rom[o + 2] = 0xAE, 0x9A
    print('  $9C5C: JMP $9B7C -> JMP $9AAE')

    # ------------------------------------------------------------------
    # 3. Tablas para 16 columnas x 2 lineas (la mitad de pagina)
    # ------------------------------------------------------------------
    # celda = CELDA0 + col//2 ; cuadrante = linea*2 + col%2
    # (patron verificado contra la tabla original, entrada 123)
    dest = bytearray()
    cuad = bytearray()
    for linea in range(LIN_MITAD):
        for col in range(COLS):
            celda = CELDA0 + col // 2
            wd = celda * 64 + PLANO3
            dest += bytes([wd & 0xFF, wd >> 8])
            cuad.append(linea * 2 + (col & 1))
    n = COLS * LIN_MITAD
    assert n == 32, 'se esperaban 32 posiciones, hay %d' % n
    # las 4 entradas sobrantes de la tabla (36-32) se dejan apuntando a la
    # ultima celda: nunca se leen porque CPX se queda en $20
    while len(dest) < 72:
        dest += dest[-2:]
        cuad.append(cuad[-1])
    rom[TABLA:TABLA + 72] = dest
    rom[CUAD:CUAD + 36] = cuad
    # comprobar que todos los destinos caen en el plano 3
    restos = {(dest[k * 2] | (dest[k * 2 + 1] << 8)) % 64 for k in range(36)}
    assert restos == {PLANO3}, 'hay destinos fuera del plano 3: %s' % restos
    celdas_usadas = sorted({(dest[k * 2] | (dest[k * 2 + 1] << 8)) // 64
                            for k in range(n)})
    assert celdas_usadas == list(range(CELDA0, CELDA0 + 8)), \
        'las celdas no son 170-177: %s' % [hex(c) for c in celdas_usadas]
    print('tablas: %d posiciones, celdas %03X..%03X, todas al plano 3'
          % (n, celdas_usadas[0], celdas_usadas[-1]))

    # ------------------------------------------------------------------
    # 4. Contadores del motor bueno $9807
    # ------------------------------------------------------------------
    # indice: linea*12 + col  ->  linea*16 + col
    #   original: LDA $3657 / ASL / CLC / ADC $3657 / ASL / ASL /
    #             CLC / ADC $3658 / CLC / ADC #$00      (17 B, $9863..$9873)
    #   nuevo:    LDA $3657 / ASL / ASL / ASL / ASL /
    #             CLC / ADC $3658 / NOP x6              (l*16 + col)
    idx = 0x41863
    esperado = bytes([0xAD, 0x57, 0x36, 0x0A, 0x18, 0x6D, 0x57, 0x36,
                      0x0A, 0x0A, 0x18, 0x6D, 0x58, 0x36, 0x18, 0x69, 0x00])
    assert bytes(rom[idx:idx + 17]) == esperado, \
        'el indice no es el esperado: %s' % bytes(rom[idx:idx + 17]).hex()
    nuevo_idx = bytes([0xAD, 0x57, 0x36,       # LDA $3657
                       0x0A, 0x0A, 0x0A, 0x0A,  # x16
                       0x18, 0x6D, 0x58, 0x36]) # CLC / ADC $3658
    nuevo_idx += b'\xEA' * (17 - len(nuevo_idx))
    rom[idx:idx + 17] = nuevo_idx
    print('indice $9863: linea*12 -> linea*16 (%d B + %d NOP)'
          % (11, 17 - 11))
    for l in range(4):
        assert (l << 4) == l * 16
    print('  verificado: l=0..3 -> 0, 16, 32, 48')

    for off, esp, val, nom in ((0x4187E, 0x0C, COLS, 'columnas $987D'),
                               (0x418B0, 0x02, LIN_MITAD, 'lineas $98AF'),
                               (0x41BB9, 0x18, n, 'CPX $9B7C')):
        assert rom[off] == esp, '0x%05X: hay $%02X, esperaba $%02X' % (
            off, rom[off], esp)
        rom[off] = val
        print('  0x%05X  %-16s $%02X -> $%02X' % (off, nom, esp, val))

    # ------------------------------------------------------------------
    # 5. El CLON $9952 (norma 118: la geometria se cambia en LOS DOS)
    # ------------------------------------------------------------------
    # OJO (medido, no deducido): el clon arranca con `LDX #$06` y salta de
    # 12 en 12 (6 del INX + 6 del ADC). Escribe en 6-11, 18-23, 30-35: es
    # un layout de 12 columnas usando solo la MITAD DERECHA, o sea el
    # bocadillo VERTICAL japones. Es el mismo "+6" que quitamos del motor
    # bueno en la v177.
    #
    # Mi primera version puso COLS en los tres sitios y X iba 16..31 y
    # luego 32..47: **se salia del buffer de 36 y machacaba $368B**, que
    # son las coordenadas del bocadillo. Lo vi al simular el bucle.
    #
    # Para 16x2 sin desfase: X arranca en 0 y el salto de linea no suma
    # nada extra (el INX ya deja X en la posicion correcta).
    for off, esp, val, nom in ((0x41972, 0x06, 0x00, 'LDX $9971'),
                               (0x419A0, 0x06, 0x00, 'SBC $999F'),
                               (0x419B2, 0x06, 0x00, 'ADC $99B1'),
                               (0x419AC, 0x06, COLS, 'CMP cols $99AB'),
                               (0x419BB, 0x03, LIN_MITAD, 'CMP lin $99BA')):
        assert rom[off] == esp, '0x%05X: hay $%02X, esperaba $%02X' % (
            off, rom[off], esp)
        rom[off] = val
        print('  0x%05X  clon %-16s $%02X -> $%02X' % (off, nom, esp, val))

    # simular el bucle del clon y comprobar que NO desborda el buffer
    X, linea, col = rom[0x41972], 0, 0
    maxX = X
    while linea < LIN_MITAD:
        X += 1                      # INX de $9994
        col += 1
        maxX = max(maxX, X)
        if col >= COLS:             # CMP de $99AB
            X = (X + rom[0x419B2]) & 0xFF   # ADC de $99B1
            linea += 1
            col = 0
    assert maxX <= 36, \
        'el clon desborda el buffer: X llega a %d y el buffer son 36 B ' \
        '(machacaria $368B, las coordenadas del bocadillo)' % maxX
    print('  simulado el bucle del clon: X llega a %d de 36  OK' % maxX)

    # ------------------------------------------------------------------
    # 6. Zonas intocables
    # ------------------------------------------------------------------
    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('punteros guion', 0x48000, 0x480E8),
        ('descompresor $793B', 0x4B93B, 0x4BF40),
        ('hook $9807', 0x41807, 0x4180E),
        ('adaptador del clon', 0x4197A, 0x4197D),
        ('fuente', 0x3D660, 0x3E200),
        ('stream CG original', 0x3D401, 0x3D660),
        ('tabla rabillo', 0x41ADD, 0x41AFD),
        ('lista sprites', 0x47C02, 0x47C67),
        ('flecha', 0x419E2, 0x419F3),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')

    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        off = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        ln = raw[p + 3] << 8 | raw[p + 4]
        prueba[off:off + ln] = raw[p + 5:p + 5 + ln]
        p += 5 + ln
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B, %d registros)' % (len(raw), len(rec)))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  Bocadillo de 16 caracteres x 2 lineas, con el texto en las')
    print('  celdas nuevas 170-177. El MARCO sigue siendo el de 12x2, asi')
    print('  que el texto se saldra por la derecha: es LO ESPERADO en este')
    print('  paso. Lo que se comprueba es que las LETRAS son correctas y')
    print('  que caben 16 por linea.')


if __name__ == '__main__':
    main()
