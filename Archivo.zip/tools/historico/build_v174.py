#!/usr/bin/env python3
"""
build_v174.py - hace coherentes el MOTOR y los SPRITES de la v173.

EL FALLO DE LA v173 (medido, entrada 165 del diario)
-----------------------------------------------------
El otro chat amplio la lista de sprites del bocadillo pero **no** la tabla de
destinos del motor:

    el MOTOR escribe en:   1A1 1A3 1A5 1A6 1A7 1A8 1A9 1AA 1AB
    los SPRITES muestran:  1A6 1A8 1AA 1C0 1C2 1D8 1DA ... 1D6
    coinciden:             1A6 1A8 1AA   (solo 3)

Por eso se lee una linea suelta ("esta es la aldea de Kintaro") y el resto es
ruido: en 17 de las 20 celdas que se muestran no escribe nadie. Ademas el
motor escribe en 1A1/1A3/1A5, que son del MARCO, y algunos sprites caen sobre
1D8-1E9, que son graficos vivos.

LA CORRECCION
-------------
Derivar las dos cosas de la MISMA lista de celdas (norma 99):

    1. elegir 10 parejas de celdas libres (ni HUD ni marco ni graficos)
    2. escribir la tabla $9BBD con esos destinos
    3. escribir la lista de sprites con esas mismas celdas
    4. ajustar los contadores a 20x4

GEOMETRIA
---------
Un sprite de 16x32 px cubre 2 caracteres de ancho x 4 lineas de alto, o sea
una pareja de celdas (c, c+1). Para 20 caracteres x 4 lineas hacen falta
**10 sprites**, no los 20 que pone la v173.

    celda de texto k (fila f, columna c):
        pareja  = c // 2
        celda   = par[pareja] + (f // 2)
        destino = celda * 64            (words)
        cuadrante = (f & 1) * 2 + (c & 1)

Uso:  python3 tools/build_v174.py
"""
import hashlib
import zlib
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from render_sprites import leer_words

BASE_ROM = 'v173/momotaro_es_v173.pce'
SALIDA = 'roms/momotaro_es_v174.pce'
MD5_BASE = '4b18abf62798caeffbca0457ea8469d8'

LISTA = 0x47C02        # lista de sprites (banco $23, logico $7C02)
BASE_PAT = 0x0338      # base de patron, verificada contra el SATB
N_MARCO = 28           # los primeros 28 sprites son el marco
TABLA = 0x41BBD        # tabla de destinos del motor ($9BBD)
CUAD = 0x41C05         # tabla de cuadrantes ($9C05)

ANCHO, LINEAS = 20, 4

HUD = {0x1B0, 0x1B1, 0x1B2, 0x1B3, 0x1B4, 0x1B5, 0x1B6, 0x1B8,
       0x1BC, 0x1BD, 0x1BE, 0x1BF}
MARCO = {0x19C, 0x19D, 0x19E, 0x19F, 0x1A0, 0x1A1, 0x1A4, 0x1A5,
         0x1AC, 0x1AD, 0x1AE}
RECICLABLE = [0x1A2, 0x1A3, 0x1A6, 0x1A7, 0x1A8, 0x1A9, 0x1AA, 0x1AB, 0x1AF]


def parejas():
    """Parejas (c, c+1) libres de verdad, fuera del HUD y del marco."""
    w = leer_words(open('docs/aldeano_vram.bin', 'rb').read())
    libres = {c for c in range(0x100, 0x1FC)
              if not any(w[c * 64 + j] for j in range(64))}
    disp = (libres | set(RECICLABLE)) - HUD - MARCO
    return [c for c in sorted(disp) if c % 2 == 0 and c + 1 in disp]


def main():
    rom = bytearray(open(BASE_ROM, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v173'
    orig = bytes(rom)

    par = parejas()
    npar = ANCHO // 2
    assert len(par) >= npar, 'hacen falta %d parejas y hay %d' % (npar, len(par))
    par = par[:npar]
    n = ANCHO * LINEAS
    print('parejas de celdas elegidas (%d): %s'
          % (len(par), ', '.join('%03X' % c for c in par)))

    # --- 1. rutina que CALCULA destino y cuadrante ---------------------
    # No caben 240 B de tablas en los 108 disponibles, asi que se calcula
    # (misma idea que geom_v158): tabla de 10 parejas + aritmetica.
    RUT = 0x9B84                      # sustituye el cuerpo del bucle
    # la tabla va DETRAS de la rutina + su cola (6 B); se calcula abajo

    cuerpo = [
        0x8A,                          # TXA
        0x64, 0x13,                    # STZ $13          fila = 0
        0xC9, ANCHO,                   # CMP #ANCHO
        0x90, 0x07,                    # BCC +7
        0x38,                          # SEC
        0xE9, ANCHO,                   # SBC #ANCHO
        0xE6, 0x13,                    # INC $13
        0x80, 0xF5,                    # BRA -11
        0x85, 0x12,                    # STA $12          col
        0xA5, 0x13, 0x29, 0x01, 0x0A,  # (fila&1)*2
        0x85, 0x11,
        0xA5, 0x12, 0x29, 0x01,        # col&1
        0x05, 0x11,
        0x8D, 0x65, 0x36,              # STA $3665        cuadrante
        0xA5, 0x12, 0x4A, 0x0A, 0xA8,  # Y = (col/2)*2
        0xB9, 0x00, 0x00,              # LDA tabla,Y     (se parchea)
        0x85, 0x14,
        0xC8,
        0xB9, 0x00, 0x00,              # LDA tabla+1,Y   (se parchea)
        0x85, 0x15,
        0xA5, 0x13, 0x4A,              # fila/2
        0xF0, 0x0B,                    # BEQ +11 -> $9BDF (LDA $14)
        0xA5, 0x14, 0x18, 0x69, 0x40,  # +$40 words (media celda abajo)
        0x85, 0x14,
        0x90, 0x02,
        0xE6, 0x15,
        0xA5, 0x14, 0x8D, 0x63, 0x36,  # STA $3663
        0xA5, 0x15, 0x8D, 0x64, 0x36,  # STA $3664
    ]
    # el glifo: lo que hacia $9B86..$9B9C, se conserva delante
    cabeza = [
        0x64, 0x15,                    # STZ $15
        0xBD, 0x67, 0x36,              # LDA $3667,X
        0x0A, 0x26, 0x15,
        0x0A, 0x26, 0x15,
        0x0A, 0x26, 0x15,
        0x18, 0x69, 0x60,              # ADC #$60
        0x8D, 0x61, 0x36,              # STA $3661
        0xA5, 0x15, 0x69, 0x56,        # ADC #$56
        0x8D, 0x62, 0x36,              # STA $3662
    ]
    rutina = list(cabeza + cuerpo + [0x20, 0x33, 0x9D])   # JSR $9D33
    off = 0x40000 + (RUT - 0x8000)
    LIMITE = 0x41C29                   # aqui empieza codigo vivo
    cola_len = 6
    TAB = RUT + len(rutina) + cola_len
    tab_off = 0x40000 + (TAB - 0x8000)
    assert tab_off + len(par) * 2 <= LIMITE, \
        'rutina %d B + tabla %d B no caben (limite 0x%05X)' % (
            len(rutina), len(par) * 2, LIMITE)
    # parchear las dos referencias a la tabla
    for k, b in enumerate(rutina):
        if b == 0xB9 and rutina[k + 1] == 0x00 and rutina[k + 2] == 0x00:
            rutina[k + 1] = TAB & 0xFF
            rutina[k + 2] = TAB >> 8
    rom[off:off + len(rutina)] = bytes(rutina)
    print('rutina de %d B en $%04X' % (len(rutina), RUT))

    fin = off + len(rutina)
    dest_bcc = (RUT - (0x8000 + (fin + 5 - 0x40000))) & 0xFF
    cola = bytes([0xE8, 0xE0, n, 0x90, dest_bcc, 0x60])
    rom[fin:fin + len(cola)] = cola
    print('cola del bucle en 0x%05X: %s' % (fin, cola.hex()))

    # la tabla de 10 parejas
    tabla = bytearray()
    for c in par:
        w = c * 64
        tabla += bytes([w & 0xFF, w >> 8])
    rom[tab_off:tab_off + len(tabla)] = tabla
    print('tabla de %d parejas (%d B) en $%04X' % (len(par), len(tabla), TAB))

    # --- 2. contadores de geometria --------------------------------------
    # el tope del bucle ($9BB8) ya va dentro de la cola de la rutina nueva
    for off, esp, nuevo, nom in ((0x4187D, 0x06, ANCHO, 'caracteres por linea'),
                                 (0x418AF, 0x03, LINEAS, 'lineas por pagina')):
        assert rom[off + 1] == esp, \
            '0x%05X: esperaba $%02X y hay $%02X' % (off, esp, rom[off + 1])
        rom[off + 1] = nuevo
        print('  0x%05X  %s: %d -> %d' % (off, nom, esp, nuevo))

    # --- 3. indice de celda: col*12+pos+6 -> fila*20+pos -----------------
    idx = bytes([0xAD, 0x57, 0x36, 0x0A, 0x0A, 0x85, 0x13, 0x0A, 0x0A,
                 0x18, 0x65, 0x13, 0x18, 0x6D, 0x58, 0x36, 0xAA, 0xEA])
    assert len(idx) == 18
    assert bytes(rom[0x41863:0x41875]).hex() == 'ad57360a186d57360a0a186d5836186906aa'
    rom[0x41863:0x41875] = idx
    print('  0x41863  indice -> fila*%d + posicion' % ANCHO)

    # --- 4. la lista de sprites, con LAS MISMAS celdas -------------------
    regs = []
    i = 0
    while rom[LISTA + i * 5] != 0xFF:
        regs.append(list(rom[LISTA + i * 5:LISTA + i * 5 + 5]))
        i += 1
    marco = regs[:N_MARCO]
    viejo = regs[N_MARCO:]
    print('lista: %d sprites (%d marco + %d texto)' % (len(regs), len(marco), len(viejo)))

    # posicion: la rejilla vieja da las X e Y de referencia
    xs = sorted({r[4] - 256 if r[4] > 127 else r[4] for r in viejo})
    ys = sorted({r[3] - 256 if r[3] > 127 else r[3] for r in viejo})
    x0, y0 = xs[0], ys[0]
    print('origen de la rejilla: dX=%+d dY=%+d' % (x0, y0))

    nuevos = []
    plant = viejo[0]
    for k, celda in enumerate(par):
        dx = x0 + k * 16
        r = list(plant)
        r[0] = ((celda << 1) - BASE_PAT) // 2
        r[3] = y0 & 0xFF
        r[4] = dx & 0xFF
        nuevos.append(r)

    lista = marco + nuevos
    off = LISTA
    for r in lista:
        rom[off:off + 5] = bytes(r)
        off += 5
    rom[off] = 0xFF
    print('lista nueva: %d sprites de texto, terminador en 0x%05X'
          % (len(nuevos), off))

    # --- 5. verificaciones ----------------------------------------------
    usa_sprites = set()
    for r in nuevos:
        c = (r[0] * 2 + BASE_PAT) >> 1
        usa_sprites |= {c, c + 1}
    usa_motor = set()
    for c in par:
        usa_motor |= {c, c + 1}

    assert not (usa_sprites & HUD), 'pisa el HUD'
    assert not (usa_sprites & MARCO), 'pisa el marco'
    assert usa_motor <= usa_sprites, \
        'el motor escribe donde no hay sprite: %s' % sorted(
            hex(c) for c in usa_motor - usa_sprites)
    print('verificado: motor y sprites usan las MISMAS celdas, sin pisar nada')

    for nom, a, b in (('guion', 0x48F91, 0x4A4B9),
                      ('diccionario', 0x4B93B, 0x4BFFF),
                      ('fuente', 0x3D660, 0x3E200)):
        assert rom[a:b] == orig[a:b], 'se ha tocado: %s' % nom
    print('intactos: guion, diccionario y fuente')

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    print()
    print(SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  bytes modificados: %d'
          % sum(1 for i in range(len(d)) if d[i] != orig[i]))


if __name__ == '__main__':
    main()
