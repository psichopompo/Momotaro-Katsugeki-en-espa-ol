#!/usr/bin/env python3
"""v399 - los tres textos: Capa (N1), baño (N2) y Kaguya (N3).

N1 CAPA   ROM 0x48A16, 20 B exactos. «Los ogros no te ven.» se cortaba en
          «Los ogros no te » porque la ventana es de 16 columnas y UNA línea.
          Elegido «Nadie te verá.» (14), propuesta de David.
          El bloque NO puede crecer: «Aletas:» empieza en 0x48A2A. Se rellena
          con espacios ($A0) hasta los 20 B.

N2 BAÑO   ROM 0x4AC45, **4 líneas de 17 columnas** = 68 B. La rejilla de 17
          está MEDIDA, no supuesta: el bloque del quiz que va justo detrás
          (0x4AC8B, ya traducido) encaja en 17 exactos, y el baño alineado a
          17 termina en 0x4AC89, a 2 bytes del quiz. Con 16 no cuadraba.
          Traducción según la corrección de David: lo dicen las mujeres, así
          que no es «¡Sabía que estaría aquí!» sino «¡Pues sí existía!».

N3 KAGUYA ROM 0x4A403, 114 B + 15 B de relleno $00 = 129 B de presupuesto.
          Reflujo de David. 131 B en crudo -> 107 B con el diccionario.
          Formato $3B salto de línea / $00 fin de página.
"""
import hashlib, sys, os
sys.path.insert(0, 'tools')
import texto

BASE = "roms/Momotaro Katsugeki (Español).pce"   # = v398
SAL  = "roms/momotaro_es_v399.pce"
MD5_BASE = "68ffe9bcf98d169d1e63c30a9ee072bd"

CAPA_OFF, CAPA_LEN = 0x48A16, 20
CAPA_TXT = "Nadie te verá."

BANO_OFF = 0x4AC45
BANO = ["¡Pues sí existía!",
        "¡El ansiado baño!",
        "¡Suerte, hermano!",
        "¡Je, je! ¡Je, je!"]

KAG_OFF, KAG_LEN = 0x4A403, 129
KAGUYA = ("La princesa\nKaguya ha\naprendido hace\npoco a apostar.|"
          "Dicen que anda\nprobando suerte\npor todos lados.|"
          "¿Y si lo intento\nyo también?|")


def main():
    d = bytearray(open(BASE, "rb").read())
    assert hashlib.md5(d).hexdigest() == MD5_BASE, "la base no es la v398"
    orig = bytes(d)

    # ---------------- N1 CAPA ----------------
    assert d[CAPA_OFF:CAPA_OFF+CAPA_LEN] == texto.codifica("Los ogros no te ven."), \
        "la descripción de la Capa no es la que creo"
    # el vecino de detrás empieza justo aquí: no hay margen para crecer
    assert texto.decodifica(orig, orig[CAPA_OFF+CAPA_LEN:CAPA_OFF+CAPA_LEN+7]) == "Aletas:", \
        "el vecino de la Capa no es «Aletas:»"
    b = texto.codifica(CAPA_TXT)
    assert len(b) <= CAPA_LEN, "la Capa no cabe"
    d[CAPA_OFF:CAPA_OFF+CAPA_LEN] = b + b"\xA0" * (CAPA_LEN - len(b))

    # ---------------- N2 BAÑO ----------------
    # el quiz de detrás está traducido y en la rejilla de 17: es el testigo
    assert texto.decodifica(orig, orig[0x4AC8B:0x4AC8B+17]) == "¡Acierta y ganas ", \
        "el quiz no está donde creo: la rejilla de 17 no se sostiene"
    for i, l in enumerate(BANO):
        assert len(l) <= 17, "línea %d del baño se pasa de 17: %r" % (i+1, l)
        e = texto.codifica(l)
        e += b"\xA0" * (17 - len(e))
        d[BANO_OFF+i*17:BANO_OFF+i*17+17] = e
    assert BANO_OFF + 68 <= 0x4AC8B, "el baño pisa el quiz"

    # ---------------- N3 KAGUYA ----------------
    assert orig[0x4A475:0x4A484] == b"\x00" * 15, "el relleno de Kaguya cambió"
    k = texto.comprime(orig, KAGUYA)
    assert texto.decodifica(orig, k) == KAGUYA, "round-trip del diccionario FALLA"
    assert len(k) <= KAG_LEN, "Kaguya no cabe: %d > %d" % (len(k), KAG_LEN)
    for l in KAGUYA.replace('|', '\n').split('\n'):
        assert len(l) <= 16, "línea de Kaguya se pasa de 16: %r" % l
    d[KAG_OFF:KAG_OFF+KAG_LEN] = k + b"\x00" * (KAG_LEN - len(k))

    # ------------- nada más se ha tocado -------------
    dif = [i for i in range(len(d)) if d[i] != orig[i]]
    zonas = [(CAPA_OFF, CAPA_OFF+CAPA_LEN), (BANO_OFF, BANO_OFF+68),
             (KAG_OFF, KAG_OFF+KAG_LEN)]
    for i in dif:
        assert any(a <= i < b for a, b in zonas), "byte fuera de zona: 0x%X" % i
    assert d[:0x48000] == orig[:0x48000], "se ha tocado código"
    # el diccionario y su tabla, intactos
    assert d[0x4BA13:0x4BF40] == orig[0x4BA13:0x4BF40], "diccionario tocado"

    open(SAL, "wb").write(d)
    print("%s   %d bytes cambiados" % (SAL, len(dif)))
    print("  MD5   ", hashlib.md5(d).hexdigest())
    print("  SHA-1 ", hashlib.sha1(bytes(d)).hexdigest())
    print()
    print("  Capa  : %r  (%d/%d B)" % (CAPA_TXT, len(b), CAPA_LEN))
    print("  Baño  : 4 x 17 col = 68 B")
    print("  Kaguya: %d/%d B con diccionario (%d en crudo)"
          % (len(k), KAG_LEN, len(texto.codifica(KAGUYA))))

main()
