#!/usr/bin/env python3
"""
build_v175.py - bocadillo 20x4 sobre la v173, SIN buffer de RAM.

QUE ARREGLA
-----------
La v173 amplio la lista de sprites pero no la tabla de destinos del motor:
de las 20 celdas que muestran los sprites, el motor solo escribe en 3. Las
otras 17 ensenan restos de VRAM (el "ruido tipo QR"), y ademas el motor
escribe en 1A1/1A3/1A5 (del marco) y los sprites invaden 1AF/1B3 (del HUD).

POR QUE SIN BUFFER
------------------
Un 20x4 son 80 celdas y el buffer de RAM ($3667) solo tiene 36: a partir de
$368B estan las COORDENADAS del bocadillo, con 20 punteros en 3 bancos.
Ampliarlo las machaca. Y no hay 80 B libres en los 8 KB de RAM (medido
cruzando el indice de referencias con 7 states; el breakpoint de David tumbo
el ultimo candidato).

La salida es no acumular: escribir cada caracter en VRAM en el momento. Es
seguro porque $9D33 ya llama a $E185 (espera al VDC) en CADA celda, o sea
que el motor ya sincroniza celda a celda y el patron de acceso no cambia.

De paso desaparecen otros dos problemas:
  - $9C29 limpiaba solo 36 celdas -> ya no hay nada que limpiar;
  - el fondo de las celdas nuevas se rellena al vuelo (solo 6 de las 20
    celdas traen fondo blanco en el CG, medido descomprimiendo 0x3D401).

MAPA DE MEMORIA (banco $20, todo dentro de lo que libera el volcado)
--------------------------------------------------------------------
    $9B7C  rutina de escritura inmediata
    $9BF0  tabla de 10 parejas de celdas (20 B)
    $9C10  rutina de relleno de fondo

Uso:  python3 tools/build_v175.py
"""
import hashlib
import zlib
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from render_sprites import leer_words

BASE_ROM = 'v173/momotaro_es_v173.pce'
SALIDA = 'roms/momotaro_es_v175.pce'
MD5_BASE = '4b18abf62798caeffbca0457ea8469d8'

ANCHO, LINEAS = 20, 4
LISTA = 0x47C02          # lista de sprites del bocadillo (banco $23)
BASE_PAT = 0x0338
N_MARCO = 28

RUT = 0x9B86             # escritura inmediata      (banco $20)
#   OJO: el CLX de $9B83 (1 B) se sustituye por un JSR (3 B), que
#   ocupa $9B83-$9B85. La rutina EMPIEZA en $9B86 o el retorno cae
#   en mitad de una instruccion y la maquina se cuelga.
TAB = 0x9C00             # tabla de parejas          (banco $20)
TRAMP = 0x9C14           # trampolin al relleno      (banco $20)
FILL = 0x5214            # relleno de fondo          (banco $1E, MPR2)
FILL_ROM = 0x3D214
LIMITE = 0x9C29          # aqui empieza codigo vivo

HUD = {0x1B0, 0x1B1, 0x1B2, 0x1B3, 0x1B4, 0x1B5, 0x1B6, 0x1B8,
       0x1BC, 0x1BD, 0x1BE, 0x1BF}
MARCO = {0x19C, 0x19D, 0x19E, 0x19F, 0x1A0, 0x1A1, 0x1A4, 0x1A5,
         0x1AC, 0x1AD, 0x1AE}
RECICLABLE = [0x1A2, 0x1A3, 0x1A6, 0x1A7, 0x1A8, 0x1A9, 0x1AA, 0x1AB, 0x1AF]


def parejas():
    w = leer_words(open('docs/aldeano_vram.bin', 'rb').read())
    libres = {c for c in range(0x100, 0x1FC)
              if not any(w[c * 64 + j] for j in range(64))}
    disp = (libres | set(RECICLABLE)) - HUD - MARCO
    return [c for c in sorted(disp) if c % 2 == 0 and c + 1 in disp]


def rutina_escritura():
    """Entrada: $10 = glifo, X = celda 0..79. Escribe la celda en VRAM."""
    c = []
    E = c.extend
    # fila = X/20, col = X%20
    E([0x8A])                              # TXA
    E([0x64, 0x13])                        # STZ $13
    E([0xC9, ANCHO])                       # CMP #20
    E([0x90, 0x07])                        # BCC +7
    E([0x38])                              # SEC
    E([0xE9, ANCHO])                       # SBC #20
    E([0xE6, 0x13])                        # INC $13
    E([0x80, 0xF5])                        # BRA -11
    E([0x85, 0x12])                        # STA $12       col
    # cuadrante = (fila&1)*2 + (col&1)
    E([0xA5, 0x13, 0x29, 0x01, 0x0A])
    E([0x85, 0x11])
    E([0xA5, 0x12, 0x29, 0x01])
    E([0x05, 0x11])
    E([0x8D, 0x65, 0x36])                  # STA $3665
    # destino: sprite = col/4 + (fila/2)*5 ; celda = par[sprite] + (col%4)/2
    # Se precalcula en la tabla una entrada por SPRITE (10), y aqui se suma
    # la celda de dentro. Y = sprite*2
    E([0xA5, 0x12, 0x4A, 0x4A])            # col/4
    E([0x85, 0x11])
    E([0xA5, 0x13, 0x4A])                  # fila/2  (OJO: pisa A)
    E([0xF0, 0x07])                        # BEQ +7 -> LDA $11 (tras el BRA)
    E([0xA5, 0x11, 0x18, 0x69, 0x05])      # +5 sprites (segunda fila)
    E([0x80, 0x02])                        # BRA +2 -> ASL
    E([0xA5, 0x11])                        # LDA $11  (destino del BEQ)
    E([0x0A, 0xA8])                        # Y = sprite*2
    E([0xB9, TAB & 0xFF, TAB >> 8])
    E([0x85, 0x14])
    E([0xC8])
    E([0xB9, TAB & 0xFF, TAB >> 8])
    E([0x85, 0x15])
    # + la celda de dentro del sprite: (col%4)/2 -> +$40 words si es la 2a
    E([0xA5, 0x12, 0x29, 0x02])            # col & 2
    E([0xF0, 0x0B])                        # BEQ +11
    E([0xA5, 0x14, 0x18, 0x69, 0x40])
    E([0x85, 0x14])
    E([0x90, 0x02])
    E([0xE6, 0x15])
    E([0xA5, 0x14, 0x8D, 0x63, 0x36])      # STA $3663
    E([0xA5, 0x15, 0x8D, 0x64, 0x36])      # STA $3664
    # origen del glifo: $5660 + glifo*8
    E([0x64, 0x15])
    E([0xA5, 0x10])
    for _ in range(3):
        E([0x0A, 0x26, 0x15])
    E([0x18, 0x69, 0x60])
    E([0x8D, 0x61, 0x36])
    E([0xA5, 0x15, 0x69, 0x56])
    E([0x8D, 0x62, 0x36])
    E([0x20, 0x33, 0x9D])                  # JSR $9D33
    E([0x60])                              # RTS
    return bytes(c)


def rutina_relleno():
    """Rellena las 20 celdas con el fondo del bocadillo (planos 0-2 = $FFFF).
    Se llama una vez al abrir el bocadillo."""
    c = []
    E = c.extend
    E([0xDA, 0x5A])                        # PHX PHY
    # $E185 espera al VDC Y fija el auto-incremento de VRAM a +1 (registro
    # de control, bits 3-4). Sin esta llamada el relleno escribe salteado
    # por toda la VRAM y destroza el fondo: era la causa de que la pantalla
    # entera saliera corrupta.
    E([0x82])                              # CLX  (X=0 -> incremento +1)
    E([0x20, 0x85, 0xE1])                  # JSR $E185
    E([0xA0, 0x00])                        # LDY #0
    # --- por cada pareja (10 iteraciones, 2 celdas cada una)
    ini = len(c)
    E([0xB9, TAB & 0xFF, TAB >> 8])        # LDA tabla,Y
    E([0x85, 0x14])
    E([0xC8])
    E([0xB9, TAB & 0xFF, TAB >> 8])
    E([0x85, 0x15])
    E([0xC8])
    E([0x5A])                              # PHY
    # MAWR = $14/$15
    E([0x9C, 0x00, 0x00])                  # STZ $0000   reg 0 = MAWR
    E([0xA5, 0x14, 0x8D, 0x02, 0x00])
    E([0xA5, 0x15, 0x8D, 0x03, 0x00])
    E([0xA9, 0x02, 0x8D, 0x00, 0x00])      # reg 2 = VWR
    # Una celda son 64 words: 16 del plano0, 16 del p1, 16 del p2, 16 del p3.
    # El fondo blanco es p0-p2 = $FFFF y p3 = $0000, y hay DOS celdas
    # seguidas (la pareja), asi que el patron se repite dos veces.
    # OJO: los planos van ALTERNANDO por celda, no 96 seguidos y 32 despues.
    E([0xA2, 0x02])                        # LDX #2   (dos celdas)
    cel = len(c)
    E([0x5A])                              # PHY
    E([0xA0, 0x30])                        # LDY #48  (3 planos x 16 words)
    E([0xA9, 0xFF])
    b1 = len(c)
    E([0x8D, 0x02, 0x00, 0x8D, 0x03, 0x00])
    E([0x88])                              # DEY
    E([0xD0, (b1 - (len(c) + 2)) & 0xFF])
    E([0xA0, 0x10])                        # LDY #16  (plano 3)
    E([0xA9, 0x00])
    b2 = len(c)
    E([0x8D, 0x02, 0x00, 0x8D, 0x03, 0x00])
    E([0x88])
    E([0xD0, (b2 - (len(c) + 2)) & 0xFF])
    E([0x7A])                              # PLY
    E([0xCA])                              # DEX
    E([0xD0, (cel - (len(c) + 2)) & 0xFF])
    E([0x7A])                              # PLY
    E([0xC0, 20])                          # CPY #20
    E([0xD0, (ini - (len(c) + 2)) & 0xFF])  # BNE bucle
    E([0x7A, 0xFA])                        # PLY PLX
    E([0x60])                              # RTS
    return bytes(c)


def main():
    rom = bytearray(open(BASE_ROM, 'rb').read())
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v173'
    orig = bytes(rom)

    # un sprite de 32x16 cubre 4 caracteres de ancho x 2 lineas, y usa
    # DOS celdas contiguas en HORIZONTAL (c, c+1). Para 20x4 hacen falta
    # 5 columnas x 2 filas = 10 sprites = 10 parejas.
    par = parejas()[:10]
    assert len(par) == 10, 'faltan parejas de celdas'
    n = ANCHO * LINEAS
    print('parejas: %s' % ', '.join('%03X' % c for c in par))

    def poner(logico, datos, nombre):
        off = 0x40000 + (logico - 0x8000)
        fin = logico + len(datos)
        assert fin <= LIMITE, '%s se sale: $%04X > $%04X' % (nombre, fin, LIMITE)
        rom[off:off + len(datos)] = datos
        print('  $%04X..$%04X  %-24s %3d B' % (logico, fin - 1, nombre, len(datos)))

    esc = rutina_escritura()
    assert RUT + len(esc) <= TAB, 'la rutina invade la tabla (%d B)' % len(esc)
    poner(RUT, esc, 'escritura inmediata')

    tabla = bytearray()
    for c in par:
        w = c * 64
        tabla += bytes([w & 0xFF, w >> 8])
    poner(TAB, bytes(tabla), 'tabla de parejas')

    # el relleno va en el banco $1E, que el motor ya mapea en MPR2
    fill = rutina_relleno()
    assert rom[FILL_ROM:FILL_ROM + len(fill)] == b'\xFF' * len(fill), \
        'el hueco del banco $1E no esta libre'
    rom[FILL_ROM:FILL_ROM + len(fill)] = fill
    print('  $%04X..$%04X  %-24s %3d B  (banco $1E)'
          % (FILL, FILL + len(fill) - 1, 'relleno de fondo', len(fill)))

    # trampolin: mapea el banco $1E, llama al relleno y restaura
    # OJO: el CLX que se le quito al volcado se hace AQUI, al final, para
    # que X arranque en 0 justo antes del bucle. Meterlo dentro de la rutina
    # de escritura lo ejecutaria en cada caracter -> bucle infinito.
    tramp = bytes([0x20, 0x29, 0x9C,           # JSR $9C29 (limpia el buffer)
                   0x43, 0x04, 0x48,           # TMA #$04 / PHA
                   0xA9, 0x1E, 0x18, 0x65, 0x20, 0x53, 0x04,
                   0x20, FILL & 0xFF, FILL >> 8,
                   0x68, 0x53, 0x04,           # PLA / TAM #$04
                   0x60])
    poner(TRAMP, tramp, 'trampolin del relleno')

    # --- los dos STA $3667,X pasan a JSR a la rutina ---------------------
    for o in (0x41883, 0x41892):
        assert bytes(rom[o:o + 3]) == b'\x9d\x67\x36', \
            'ROM %05X no es STA $3667,X' % o
        rom[o:o + 3] = bytes([0x20, RUT & 0xFF, RUT >> 8])
        print('  0x%05X  STA $3667,X -> JSR $%04X' % (o, RUT))

    # --- el relleno se engancha al VOLCADO, no al limpiador --------------
    # El limpiador $9C29 lo llaman CUATRO sitios, uno desde el banco $0B, y
    # se ejecuta durante la carga de fase. Colgarse ahi dejaba la pantalla
    # en negro: la tabla se lee de MPR4 (banco $20) y desde el banco $0B no
    # hay garantia de que este mapeado, y ademas $E185 lee el status del
    # VDC, lo que BORRA los flags de interrupcion que el cargador espera.
    #
    # $9B7C (el volcado) es el sitio seguro: solo corre con el bocadillo ya
    # abierto y vive en el propio banco $20.
    # El volcado $9B7C ya no tiene nada que volcar (cada caracter se pinta
    # al llegar), asi que se convierte en un simple RTS. Sus 8 primeros
    # bytes se dejan como estaban salvo el CLX, que pasa a RTS.
    o = 0x41B7C
    assert bytes(rom[o:o + 8]) == bytes([0xA9, 0x1E, 0x18, 0x65, 0x20,
                                         0x53, 0x04, 0x82]), \
        'la cabecera del volcado no es la esperada: %s' % bytes(rom[o:o + 8]).hex()
    rom[o] = 0x60                       # RTS
    print('  0x%05X  volcado -> RTS (ya no hace falta: escritura inmediata)' % o)

    # El RELLENO se engancha en los TRES llamantes del banco $20, no en la
    # rutina $9C29: asi el llamante del banco $0B (que corre durante la
    # carga de fase, con otro banco en MPR4 y esperando el vblank) queda
    # INTACTO. Colgar ahi dejaba la pantalla en negro.
    for caller in (0x417EE, 0x41953, 0x41C59):
        assert bytes(rom[caller:caller + 3]) == bytes([0x20, 0x29, 0x9C]), \
            'ROM %05X no es JSR $9C29' % caller
        rom[caller + 1:caller + 3] = bytes([TRAMP & 0xFF, TRAMP >> 8])
        print('  0x%05X  JSR $9C29 -> JSR $%04X' % (caller, TRAMP))

    # --- contadores e indice ---------------------------------------------
    for off, esp, nuevo, nom in ((0x4187D, 0x06, ANCHO, 'caracteres/linea'),
                                 (0x418AF, 0x03, LINEAS, 'lineas/pagina')):
        assert rom[off + 1] == esp, '0x%05X: hay $%02X' % (off, rom[off + 1])
        rom[off + 1] = nuevo
        print('  0x%05X  %s: %d -> %d' % (off, nom, esp, nuevo))

    idx = bytes([0xAD, 0x57, 0x36, 0x0A, 0x0A, 0x85, 0x13, 0x0A, 0x0A,
                 0x18, 0x65, 0x13, 0x18, 0x6D, 0x58, 0x36, 0xAA, 0xEA])
    assert bytes(rom[0x41863:0x41875]).hex() == \
        'ad57360a186d57360a0a186d5836186906aa'
    rom[0x41863:0x41875] = idx
    print('  0x41863  indice -> fila*%d + posicion' % ANCHO)

    # --- la lista de sprites, con LAS MISMAS celdas ----------------------
    regs = []
    i = 0
    while rom[LISTA + i * 5] != 0xFF:
        regs.append(list(rom[LISTA + i * 5:LISTA + i * 5 + 5]))
        i += 1
    viejo = regs[N_MARCO:]
    # OJO: byte[3] = dX y byte[4] = dY. Verificado contra el SATB del state
    # de David: el registro (b3=-83, b4=-32) sale en pantalla en (x=3, y=45),
    # y subir b3 en 32 mueve la X 32 px. Lo tenia al reves.
    xs = sorted({r[3] - 256 if r[3] > 127 else r[3] for r in viejo})
    ys = sorted({r[4] - 256 if r[4] > 127 else r[4] for r in viejo})
    # rejilla real: 5 columnas (paso 32 px) x 2 filas (paso 16 px)
    plant = viejo[0]
    nuevos = []
    for k, celda in enumerate(par):
        fila, col = k // 5, k % 5
        r = list(plant)
        r[0] = ((celda << 1) - BASE_PAT) // 2
        r[3] = (xs[0] + col * 32) & 0xFF      # dX
        r[4] = (ys[0] + fila * 16) & 0xFF      # dY
        nuevos.append(r)
    off = LISTA
    for r in regs[:N_MARCO] + nuevos:
        rom[off:off + 5] = bytes(r)
        off += 5
    rom[off] = 0xFF
    print('  lista: %d sprites de texto (antes %d)' % (len(nuevos), len(viejo)))

    # --- verificaciones ---------------------------------------------------
    usa = set()
    for r in nuevos:
        c = (r[0] * 2 + BASE_PAT) >> 1
        usa |= {c, c + 1}
    assert not (usa & HUD), 'pisa el HUD: %s' % sorted(hex(c) for c in usa & HUD)
    assert not (usa & MARCO), 'pisa el marco'
    motor = set()
    for c in par:
        motor |= {c, c + 1}
    assert motor == usa, 'motor y sprites no coinciden'
    print('verificado: motor y sprites usan las MISMAS 20 celdas')

    for nom, a, b in (('guion', 0x48F91, 0x4A4B9),
                      ('diccionario', 0x4B93B, 0x4BFFF),
                      ('fuente', 0x3D660, 0x3E200)):
        assert rom[a:b] == orig[a:b], 'se ha tocado: %s' % nom
    print('intactos: guion, diccionario y fuente')

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    print()
    print(SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  bytes modificados: %d'
          % sum(1 for i in range(len(d)) if d[i] != orig[i]))


if __name__ == '__main__':
    main()
