#!/usr/bin/env python3
"""
build_v288.py - la «Ç» del password de Game Over. UN BYTE.

EL BUG (lo caza David a ojo)
============================
David: *«el ultimo caracter del password es una Ç, que no figura en la
parrilla. Todos los demas, si.»*

Tenia razon, y no es cosmetico: **ese password no se puede volver a
teclear**. La parrilla de entrada no tiene `Ç`, asi que cualquier partida
cuyo password contenga el valor 38 queda inservible.

La tabla del canto de Game Over (`$57B6` = ROM 0x1F7B6, 64 words) usa en la
posicion 37 el codigo `$B0` para la `p`. Pero `$B0` esta en la tabla de
sustitucion previa `$AB34`:

```
origen  20 21 2D B0 A2 A3 24
destino 3C 5C 5F 5F 5B 5D 3E
              ^^ ^^
```

`$B0` -> `$5F` -> ruta baja -> **glifo $DE**, que es la `Ç`. Renderizado
desde la fuente, el dibujo es inequivoco: una C con rabito.

La `p` buena es **`$5E`** (norma 204), que da el glifo `$B0`. Es exactamente
el mismo bug que bloqueo tres versiones con la palabra «Capa» en el menu
SELECT, repetido aqui por copiar la nota «b/c/p = $A2/$A3/$B0» del informe.

POR QUE b Y c SI FUNCIONAN
==========================
Tambien pasan por la sustitucion (`$A2`->`$5B`, `$A3`->`$5D`), pero sus
destinos dan por casualidad el glifo correcto. Se dejan como estan: tocarlos
sin necesidad es arriesgar por estetica.

BARRIDO DE LAS OTRAS DOS TABLAS
===============================
Verificadas las tres tablas de 64 codigos que existen en la ROM:

```
parrilla de entrada  0x1BBBA   ABCDEFGabcdefg...  64/64 OK
tabla del Jizo       0x16AD6   ABCDEFGabcdefg...  64/64 OK  (indices directos)
Game Over            0x1F7B6   ...ñoÇqrst...      1 MAL: pos 37
```

David dijo que creia que la parrilla estaba bien. Lo estaba. **El fallo es
unico en toda la ROM.**

Uso:  python3 tools/build_v288.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v287.pce'
SALIDA = 'roms/momotaro_es_v288.pce'
IPS = 'parches/momotaro_v288.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '426a0a2555389ec694fd4d4735c7777d'

TABLA_GO = 0x1F7B6          # $57B6, 64 words
POS_P = 37                  # la 'p'
OFF_P = TABLA_GO + POS_P * 2
VIEJO, NUEVO = 0xB0, 0x5E

ESPERADO = ("ABCDEFGabcdefgHIJKLMNhijklmn"
            "ÑOPQRSTñopqrstUVWXYZuvwxyz0123456789")


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v287'
    print('base %s  OK' % BASE)

    # --- el decodificador real del juego, reconstruido de la ROM --------
    ORI = rom[0x42B4C:0x42B53]
    DES = rom[0x42B54:0x42B5B]
    assert bytes(ORI) == bytes([0x20, 0x21, 0x2D, 0xB0, 0xA2, 0xA3, 0x24]), \
        'la tabla de sustitucion $AB34 no es la esperada'

    def glifo(c):
        if c in ORI:
            c = DES[list(ORI).index(c)]
        if 0x30 <= c and (c - 0x30) < 0x54:
            return rom[0x43F9B + c - 0x30]
        return rom[0x41C73 + c - 0x20]

    import sys
    sys.path.insert(0, 'tools')
    from charset_oficial import CHAR_TO_CODE
    g2c = {}
    for ch, c in CHAR_TO_CODE.items():
        if c not in ORI:                      # solo codigos sin sustitucion
            g2c.setdefault(glifo(c), ch)

    def lee_tabla(off, paso, es_codigo):
        s = ''
        for i in range(64):
            b = rom[off + i * paso]
            g = glifo(b) if es_codigo else b
            s += g2c.get(g, '?')
        return s

    # --- 1. las otras dos tablas tienen que estar limpias ---------------
    print('\n--- barrido de las tres tablas de 64 codigos')
    for nom, off, paso, cod in (('parrilla de entrada', 0x1BBBA, 1, True),
                                ('tabla del Jizo', 0x16AD6, 1, False)):
        got = lee_tabla(off, paso, cod)
        assert got == ESPERADO, '%s difiere:\n  %s\n  %s' % (nom, got,
                                                            ESPERADO)
        print('    %-20s 64/64 OK' % nom)

    antes = lee_tabla(TABLA_GO, 2, True)
    fallos = [(i, a, b) for i, (a, b) in enumerate(zip(antes, ESPERADO))
              if a != b]
    print('    %-20s %d fallo(s)' % ('Game Over', len(fallos)))
    for i, a, b in fallos:
        print('       pos %2d (ROM 0x%05X): sale %r, deberia ser %r'
              % (i, TABLA_GO + i * 2, a, b))
    assert len(fallos) == 1 and fallos[0][0] == POS_P, \
        'se esperaba exactamente 1 fallo en la posicion %d' % POS_P

    # --- 2. el arreglo ---------------------------------------------------
    assert rom[OFF_P] == VIEJO, \
        'en 0x%05X hay $%02X, se esperaba $%02X' % (OFF_P, rom[OFF_P], VIEJO)
    print('\n--- el arreglo')
    print('    0x%05X  $%02X -> $%02X   (glifo $%02X -> $%02X)'
          % (OFF_P, VIEJO, NUEVO, glifo(VIEJO), glifo(NUEVO)))
    rom[OFF_P] = NUEVO

    # el segundo byte del par tiene que seguir siendo $20 (norma de la v285)
    assert rom[OFF_P + 1] == 0x20, \
        'el segundo byte del par no es $20: $%02X' % rom[OFF_P + 1]
    print('    el segundo byte del par sigue en $20  OK')

    # --- 3. relectura ----------------------------------------------------
    despues = lee_tabla(TABLA_GO, 2, True)
    print('\n--- releido desde la ROM escrita')
    print('    antes:   %s' % antes)
    print('    despues: %s' % despues)
    assert despues == ESPERADO, 'la tabla sigue mal'
    print('    64/64 OK, y coincide con la parrilla y con el Jizo')

    # el glifo de la p tiene que estar dibujado
    g = glifo(NUEVO)
    assert any(rom[0x3D660 + g * 8:0x3D660 + g * 8 + 8]), \
        'el glifo $%02X esta en blanco' % g

    # --- 4. zonas intactas -----------------------------------------------
    intactas = [
        ('menu de Game Over', 0x1F739, 0x1F758),
        ('error de guardado (JP)', 0x1F758, 0x1F7B6),
        ('resto de la tabla del canto', TABLA_GO, OFF_P),
        ('cola de la tabla', OFF_P + 1, 0x1F836),
        ('«¿Cual quieres cargar?»', 0x1F836, 0x1F860),
        ('parrilla de entrada', 0x1BBBA, 0x1BC00),
        ('tabla del Jizo', 0x16AD6, 0x16B16),
        ('bucle del canto del Jizo', 0x16A73, 0x16AD6),
        ('rutina del canto GO', 0x1B9D5, 0x1BA00),
        ('fuente', 0x3D660, 0x3E200),
        ('tabla de glifos', 0x43F9B, 0x44000),
        ('sustitucion $AB34', 0x42B4C, 0x42B5C),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    assert dif == [OFF_P], 'cambios fuera de sitio: %s' % dif
    print('1 byte sobre la v287')

    open(SALIDA, 'wb').write(d)

    # --- IPS con round-trip ---
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
