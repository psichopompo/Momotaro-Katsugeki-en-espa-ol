#!/usr/bin/env python3
"""
build_v177.py - PASO 1 desde la v157: bocadillo apaisado de 12x3.

POR QUE DESDE LA v157
---------------------
David: en la v157 el texto se ve con letras de verdad; en la v158 y todo lo
que vino despues salian cuadros. Volvemos ahi y avanzamos de uno en uno.

LA CAUSA DE LOS "QR", MEDIDA
----------------------------
El motor escribe el glifo en el plano 3 de la celda, y los planos 0-2 tienen
que traer el fondo blanco. Comprobado en la VRAM:

    celdas con fondo blanco:  1A6 1A7 1A8 1A9 1AA 1AB   (6)
    celdas del marco:         1A1 1A3 1A5               (3, traen su dibujo)
    celdas 1C0, 1C4, 1CC...:  VACIAS -> cuadros de colores

La v157 usa exactamente esas 9. Mi v158/v176 metia 8 celdas vacias, y de ahi
el QR. **El bocadillo solo puede usar celdas que el CG cargue.**

Ademas, el fondo solo existe mientras hay un bocadillo abierto: en los
states de tienda o de enemigo esas celdas estan a cero. El juego recarga el
CG en cada apertura (cargador en `$9C32`, cuenta de tiles en `ROM 0x3D400`,
destino `$6700` = celda `0x19C`).

QUE HACE ESTE PASO
------------------
**Solo reorganiza las tablas**, sin tocar ni una celda de VRAM ni el CG:

    v157:  6 caracteres x 6 lineas
    v177: 18 caracteres x 2 lineas     <- apaisado, mismas 9 celdas

Cada celda de 16x16 cubre 2 caracteres de ancho x 2 lineas, asi que las 9
celdas se reparten en una rejilla de celdas, no de caracteres sueltos:

    6x6  -> 3 columnas x 3 filas de celdas = 9   OK (lo que hay)
    18x2 -> 9 columnas x 1 fila  de celdas = 9   OK (este paso)
    12x3 -> 6 columnas x 2 filas de celdas = 12  NO CABE

Por eso el salto es a 18x2 y no a 12x3: con 3 lineas harian falta doce
celdas y solo hay nueve.

Se cambian las dos tablas y los dos contadores. Nada mas.

Uso:  python3 tools/build_v177.py
"""
import hashlib
import zlib
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

BASE = 'roms/test_horizontal_v157.pce'
SALIDA = 'roms/momotaro_es_v177.pce'
MD5_BASE = '294f0c20ef190860391267c330007dad'

TABLA = 0x41BBD          # destinos, 36 words
CUAD = 0x41C05           # cuadrantes, 36 bytes
ANCHO, LINEAS = 12, 2

# Las 9 celdas utilizables, en el orden en que se van a recorrer.
# Cada una cubre 2 caracteres de ancho x 2 lineas.
# Fila 0 de celdas -> lineas 0-1 ; fila 1 -> linea 2 (y sobra la 3)
# las 9 celdas en una sola fila: 18 caracteres de ancho, 2 lineas de alto
# SOLO las celdas de RELLENO PURO (blanco entero). Medido en la VRAM:
#     1A0 1A2 1A4  -> lateral IZQUIERDO (traen el trazo del borde)
#     1A1 1A3 1A5  -> lateral DERECHO   (traen el trazo a 12 px)
#     1A6 .. 1AB   -> relleno puro       <- las unicas usables en medio
#
# La v157 metia 1A1/1A3/1A5 en la ultima columna, y por eso encajaban:
# el trazo caia justo en el borde. Al ponerlas en medio (v177 anterior)
# el borde derecho aparecia dentro del bocadillo: eso eran las rayas.
CELDAS = [0x1A6, 0x1A7, 0x1A8, 0x1A9, 0x1AA, 0x1AB]
PLANO3 = 48


VRAM_19C = None


def main():
    global VRAM_19C
    rom = bytearray(open(BASE, 'rb').read())
    import struct as _st
    _v = open('docs/aldeano_vram.bin', 'rb').read()
    VRAM_19C = _v[0x19C * 128:0x19C * 128 + 128]
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v157 (md5 %s)' % md5
    orig = bytes(rom)

    # las celdas que usemos tienen que ser las que ya usa la v157
    usadas_v157 = {(orig[TABLA + k * 2] | (orig[TABLA + k * 2 + 1] << 8)) // 64
                   for k in range(36)}
    todas = set(CELDAS)
    assert todas <= usadas_v157, \
        'se usan celdas que la v157 no carga: %s' % sorted(
            hex(c) for c in todas - usadas_v157)
    print('las %d celdas son las mismas que usa la v157' % len(todas))

    # y todos sus destinos tienen que caer en el plano 3
    restos = {(orig[TABLA + k * 2] | (orig[TABLA + k * 2 + 1] << 8)) % 64
              for k in range(36)}
    assert restos == {PLANO3}, 'la v157 no usa el plano 3: %s' % restos
    print('destinos al plano 3 (+%d words), como la v157' % PLANO3)
    print()

    dest = bytearray()
    cuad = bytearray()
    for linea in range(LINEAS):
        for col in range(ANCHO):
            celda = CELDAS[col // 2]
            w = celda * 64 + PLANO3
            dest += bytes([w & 0xFF, w >> 8])
            # cuadrante: bit1 = mitad inferior de la celda, bit0 = derecha
            cuad.append(linea * 2 + (col & 1))

    n = ANCHO * LINEAS
    assert n == 24, 'se esperaban 24 celdas de texto, no %d' % n
    # la tabla tiene 36 entradas; las 4 sobrantes apuntan a la ultima celda
    while len(dest) < 72:
        dest += dest[-2:]
        cuad.append(cuad[-1])
    rom[TABLA:TABLA + len(dest)] = dest
    rom[CUAD:CUAD + len(cuad)] = cuad
    print('tabla de destinos: %d B' % len(dest))
    print('tabla de cuadrantes: %d B' % len(cuad))

    # El indice de celda arrastra un "+6" del bocadillo vertical japones
    # ($9872: CLC / ADC #$06). Con la tabla nueva eso empujaba el texto seis
    # caracteres a la derecha: el primero caia en la celda 1A9 en vez de en
    # la 1A6, que es justo lo que David describe. Se pone a 0.
    assert bytes(rom[0x41871:0x41874]) == bytes([0x18, 0x69, 0x06]), \
        'no encuentro el CLC/ADC #$06 del indice: %s' % bytes(
            rom[0x41871:0x41874]).hex()
    rom[0x41873] = 0x00
    print('  0x41873  indice: ADC #$06 -> ADC #$00 (texto 48 px a la izq)')

    for off, esp, nuevo, nom in ((0x4187D, 0x06, ANCHO, 'caracteres/linea'),
                                 (0x418AF, 0x03, LINEAS, 'lineas/pagina')):
        assert rom[off + 1] == esp, '0x%05X: hay $%02X' % (off, rom[off + 1])
        rom[off + 1] = nuevo
        print('  0x%05X  %s: %d -> %d' % (off, nom, esp, nuevo))

    # nada fuera de las tablas y los dos contadores
    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    permitido = set(range(TABLA, TABLA + 72)) | set(range(CUAD, CUAD + 36)) \
        | {0x4187E, 0x418B0, 0x41873}
    fuera = [i for i in dif if i not in permitido]
    assert not fuera, 'cambios fuera de lo previsto: %s' % [hex(i) for i in fuera[:8]]
    print()
    print('%d bytes en las tablas y los contadores' % len(dif))

    print()
    print('reparto resultante:')
    for linea in range(LINEAS):
        fila = []
        for col in range(ANCHO):
            k = linea * ANCHO + col
            w = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
            fila.append('%03X:%d' % (w // 64, rom[CUAD + k]))
        print('  linea %d  %s' % (linea, ' '.join(fila)))

    # ------------------------------------------------------------------
    # El MARCO: recolocar los 12 sprites para que envuelvan 18x2 en vez de
    # 6x6. Formato del registro: [pat/2, b1, b2, dX, dY], terminador $FF.
    # b2: bit0 = ancho 32 px, bit4 = flip H, bit0 de la parte alta = alto 32.
    #
    # El texto ocupa 18*8 = 144 px de ancho y 2*8 = 16 de alto. Las nueve
    # celdas de texto van seguidas en horizontal desde dX=+3.
    # La lista no cabe donde esta ($9AA0..$9ADC son 61 B = 12 sprites), asi
    # que se mueve al banco $23, que en la v157 esta virgen (1022 B libres
    # en ROM 0x47C02). Es la misma solucion que uso el otro chat, tomada
    # como pieza suelta y verificada.
    LISTA_VIEJA = 0x41AA0
    assert rom[LISTA_VIEJA + 12 * 5] == 0xFF, 'la lista no tiene 12 sprites'
    LISTA = 0x47C02
    assert rom[LISTA:LISTA + 256] == b'\xFF' * 256, \
        'el banco $23 no esta libre en 0x47C02'

    # el emisor pasa a mapear el banco $23 en MPR3 y leer la lista de $7C02
    cargador = bytes([
        0x43, 0x08, 0x48,                    # TMA #$08 / PHA
        0xA9, 0x23, 0x18, 0x65, 0x20, 0x53, 0x08,   # banco $23 -> MPR3
        0xA9, 0x02, 0x85, 0x53,              # puntero $7C02
        0xA9, 0x7C, 0x85, 0x54,
        0x20, 0xEB, 0xE3,                    # JSR $E3EB
        0x68, 0x53, 0x08,                    # PLA / TAM #$08
        0x60,                                # RTS
    ])
    o = 0x41A95
    assert bytes(rom[o:o + 11]) == bytes([0xA9, 0xA0, 0x85, 0x53, 0xA9, 0x9A,
                                          0x85, 0x54, 0x4C, 0xEB, 0xE3]), \
        'el emisor no es el esperado: %s' % bytes(rom[o:o + 11]).hex()
    # el cargador (25 B) ocupa $9A95..$9AAD, pisando el principio de la
    # lista vieja. No pasa nada: la lista se ha movido al banco $23 y esos
    # bytes ya no se leen. Es exactamente lo que hizo el otro chat.
    assert o + len(cargador) <= 0x41ADD, 'el cargador invade la tabla del rabillo'
    rom[o:o + len(cargador)] = cargador
    print()
    print('  0x%05X  emisor -> mapea el banco $23 y lee la lista de $7C02'
          % o)

    def reg(celda, b1, b2, dx, dy):
        return [((celda << 1) - 0x0338) // 2, b1, b2, dx & 0xFF, dy & 0xFF]

    # dX es de 8 bits con signo. Para que un bocadillo de 150 px quepa,
    # se centra el ancla: la mitad izquierda usa dX negativos.
    # El ancho lo marca el RELLENO disponible, no el numero de caracteres:
    # 6 celdas x 16 px = 96, empezando en +3 (tras el trazo del lateral
    # izquierdo). Si el marco se hace mas ancho queda un hueco a la derecha,
    # que es lo que vio David: 16 px sin nada entre el ultimo relleno y el
    # lateral. No hay una septima celda de relleno puro.
    ANCHO_PX = len(CELDAS) * 16               # 96
    X0 = -(ANCHO_PX + 19) // 2                # borde izquierdo
    # David: el RABILLO esta en su sitio original; lo que esta demasiado
    # arriba es el resto del bocadillo. Bajarlo 32 px lo une con el rabillo.
    Y0 = 32
    # El lateral derecho (1A1) lleva su trazo en la columna 12, asi que va
    # +3 respecto a la rejilla; las ESQUINAS derechas (1AC/1AE) lo llevan en
    # la 15 y van sin desplazar. David: "el lateral derecho esta en su
    # sitio, hay que mover las esquinas 3 px a la izquierda".
    DER = 3
    nueva = [
        # borde superior: esquina izq, tramos de 32, esquina der
        # OJO: un sprite de 32 px REDONDEA su celda a par (el VDC ignora
        # el bit 0 del patron). Con 32 px, la celda 19D se mostraba como
        # 19C, o sea la esquina repetida cuatro veces. Los tramos de borde
        # tienen que ser de 16 px para poder usar 19D y 19F.
        reg(0x19C, 0x0F, 0x01, X0, Y0 - 8),                 # esquina (par: 32 ok)
        reg(0x19D, 0x0F, 0x00, X0 + 32, Y0 - 8),
        reg(0x19D, 0x0F, 0x00, X0 + 48, Y0 - 8),
        reg(0x19D, 0x0F, 0x00, X0 + 64, Y0 - 8),
        reg(0x19D, 0x0F, 0x00, X0 + 80, Y0 - 8),
        reg(0x1AC, 0x0F, 0x00, X0 + ANCHO_PX, Y0 - 8),
        # laterales: 16x16, a los lados del relleno
        reg(0x1A0, 0x0F, 0x00, X0, Y0 + 8),
        reg(0x1A1, 0x0F, 0x00, X0 + ANCHO_PX + 3, Y0 + 8),
        # borde inferior
        reg(0x19E, 0x0F, 0x01, X0, Y0 + 24),                 # esquina (par)
        reg(0x19F, 0x0F, 0x00, X0 + 32, Y0 + 24),
        reg(0x19F, 0x0F, 0x00, X0 + 48, Y0 + 24),
        reg(0x19F, 0x0F, 0x00, X0 + 64, Y0 + 24),
        reg(0x19F, 0x0F, 0x00, X0 + 80, Y0 + 24),
        reg(0x1AE, 0x0F, 0x00, X0 + ANCHO_PX, Y0 + 24),
        # NADA de 1B0: en la v157 ese registro (32x16 en dX+3 dY+40) era la
        # TERCERA fila de relleno del bocadillo vertical, no una flecha. Su
        # celda esta vacia en los states con bocadillo de aldeano abierto.
        # Lo que David ve abajo-izquierda es ese sprite sobrante; se quita.
        # SIN rabillo: no va en esta lista. El juego lo emite aparte, en
        # una segunda llamada a $E3EB, eligiendo UNA de las cuatro
        # variantes de la tabla $9ADD segun $368F:
        #     [0] abajo-derecha   [1] abajo-izquierda (flip H)
        #     [2] LATERAL derecho (para el bocadillo del abuelo, que sale
        #         en la esquina superior derecha)   [3] abajo (flip H)
        # Anadir uno aqui producia un cuarto rabillo siempre visible.
        # las celdas de RELLENO, que es donde se escribe el texto
    ]
    for i, celda in enumerate(CELDAS):
        # 16 px de ancho x 32 de alto -> b2 = $10 (bit4 = alto 32)
        # 16x16: una fila de celdas = 2 lineas de texto
        # El lateral 1A0 solo dibuja 3 px (columnas 0-2); las otras 13 son
        # TRANSPARENTES. Por eso el relleno arranca en +3, como en la
        # v157, y no en +16: si no, queda un cuadrado de cielo de 13 px.
        nueva.append(reg(celda, 0x0F, 0x00, X0 + 3 + i * 16, Y0 + 8))

    for r in nueva:
        celda = r[0] + 0x19C
        if r[2] & 0x01:                       # 32 px de ancho
            assert celda % 2 == 0, \
                'sprite de 32 px con celda IMPAR %03X: el VDC la redondea' % celda
        dx = r[3] - 256 if r[3] > 127 else r[3]
        dy = r[4] - 256 if r[4] > 127 else r[4]
        assert -128 <= dx <= 127, 'dX fuera de rango: %d' % dx
        assert -128 <= dy <= 127, 'dY fuera de rango: %d' % dy

    # Ningun par de sprites de la misma fila puede solaparse... salvo en la
    # fila del texto, donde el relleno arranca en +3 y monta 13 px sobre el
    # lateral izquierdo A PROPOSITO (el lateral solo dibuja 3 px y el resto
    # es transparente). Se comprueba solo el borde superior y el inferior.
    for fila in (Y0 - 8, Y0 + 24):
        # la flecha (1B0) va ENCIMA del borde inferior, a proposito
        t = sorted((r[3] - 256 if r[3] > 127 else r[3],
                    (r[3] - 256 if r[3] > 127 else r[3]) + (32 if r[2] & 1 else 16))
                   for r in nueva
                   if (r[4] - 256 if r[4] > 127 else r[4]) == fila
                   and r[0] + 0x19C != 0x1B0)
        for i in range(len(t) - 1):
            assert t[i][1] <= t[i + 1][0], \
                'solape en la fila %d: %s con %s' % (fila, t[i], t[i + 1])

    cabe = LISTA + len(nueva) * 5 + 1
    assert cabe <= 0x48000, \
        'la lista nueva (%d sprites) se sale del banco $23' % len(nueva)
    off = LISTA
    for r in nueva:
        rom[off:off + 5] = bytes(r)
        off += 5
    rom[off] = 0xFF
    print()
    print('marco recolocado: %d sprites (antes 12), terminador en 0x%05X'
          % (len(nueva), off))
    print('  bocadillo: %d px de ancho x 32 de alto' % (ANCHO_PX + 22))

    # ------------------------------------------------------------------
    # El pixel que senala David: celda 19C, fila 14, columna 1. Comparada
    # con la esquina derecha en espejo, la izquierda tiene un negro de mas:
    #     IZQ y14  ##WWWW      DER y14 (espejo)  #WWWWW
    # Ese (1,14) rompe la curva y hace el escaloncito. Debe ser blanco.
    #
    # El CG esta comprimido en 0x3D401, asi que se descomprime, se toca el
    # pixel y se recomprime con el modulo validado.
    from descomp_cg import Flujo, tile, comprime
    f = Flujo(rom, 0x3D401)
    celda = bytearray()
    for _ in range(4):
        celda += tile(f)
    fin_stream = f.p
    assert bytes(celda) == VRAM_19C, 'el CG de 19C no es el esperado'

    # la celda son 64 words: plano k en los words k*16 .. k*16+15
    import struct
    ws = list(struct.unpack('<64H', bytes(celda)))
    BIT = 1 << (15 - 1)                       # columna 1
    p1, p2 = ws[1 * 16 + 14], ws[2 * 16 + 14]
    assert (p1 & BIT) and (p2 & BIT), \
        'el pixel (1,14) no es color 6: p1=%04X p2=%04X' % (p1, p2)
    # color 7 (blanco) = planos 0,1,2 a uno y el 3 a cero
    ws[0 * 16 + 14] |= BIT
    ws[3 * 16 + 14] &= ~BIT & 0xFFFF
    celda[:] = struct.pack('<64H', *ws)

    # recomprimir y comprobar que ocupa lo MISMO (si creciera, pisaria el
    # resto del stream)
    nuevo = comprime(bytes(celda))
    viejo_len = fin_stream - 0x3D401
    assert len(nuevo) == viejo_len, \
        'el stream recomprimido mide %d y el original %d' % (len(nuevo), viejo_len)
    rom[0x3D401:0x3D401 + len(nuevo)] = nuevo
    # y verificar el round-trip
    comp, _ = __import__('descomp_cg').descomprime(bytes(rom), 0x3D401, 4)
    assert comp == bytes(celda), 'el round-trip del CG no cuadra'

    print('  pixel (1,14) de la esquina 19C: negro -> blanco (David)')

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    print()
    print(SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
