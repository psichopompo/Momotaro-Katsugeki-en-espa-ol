#!/usr/bin/env python3
"""build_v332.py - El corte de pagina del ermitanyo y «Toma: +Vuelo».

1. LA FRASE DEL ERMITANYO, COMPLETA
   --------------------------------
   David, literal: «no me jodas. En japones dice "Washi wa hiensen nin ja!".
   Tendria que decir "¡Yo soy el ermitaño Hien!"».

   Y tiene razon dos veces. Yo habia escrito «Soy Vuelo.», que se come la
   palabra ERMITAÑO entera. Peor: dije que «ermitaño no esta traducido en
   ninguna parte» y David me tapo la boca con una captura. Comprobado:

       0x491D4  «El ermitaño vive en lo alto. Deberias pedirle que te enseñe»

   Estaba traducido desde hace versiones. Me bastaba con BUSCARLO.

   El problema real era el hueco: prefijo 4 B + sufijo 8 B = 12 utiles, y
   «¡Yo soy el ermitaño » son 20. La solucion no es rebajar el texto, es
   REPUNTAR: el prefijo se carga inmediato en $D7BE (LDA #$2D / LDA #$6E),
   asi que basta cambiar dos bytes y llevarlo a espacio libre.

       0x4B7D3   168 bytes de $A0 libres al final de la zona del quiz
                 (CPU $77D3, mismo banco $25, misma ventana)

   Queda:  |¡Yo soy el      | + |ermitaño | + <TECNICA> + |!|

2. LA P4, QUE NO SE ENTENDIA
   -------------------------
   «¿Al quemar qué / salió ceniza?» no se entiende. En el cuento, al viejo
   le dan ceniza al quemar el MORTERO (usu). La pregunta correcta es de
   donde salio esa ceniza.
       ->  «La ceniza, ¿de / qué salio?»
   Revisadas de paso las 40 buscando la misma pega.

1. LA 'p' DE LAS OPCIONES: «KaÇÇa» en vez de «Kappa»
   -------------------------------------------------
   David: «en las respuestas veo que pone "KaÇÇa" [...] Parece ser algo con
   la 'p' minuscula.»

   Medido: PREGUNTAS y OPCIONES usan juegos de glifos DISTINTOS.

       PREGUNTAS ($DD53)  byte directo $B0 -> p    BIEN (desde la v327)
                          alias      $5B/$5D/$5E -> ©   (bug que arregle)
       OPCIONES  ($DAC0)  alias      $5B (b) -> b        BIEN («Bambú»)
                          byte directo $B0 (p) -> Ç      MAL  («KaÇÇa»)

   O sea, justo al reves. En la v327 pase TODO a bytes directos para matar
   el ©, y con eso rompi la 'p' de las opciones. La 'b' y la 'c' directas
   ($A2/$A3) si funcionan en opciones; la unica que falla es la 'p'.

   Comprobado contra las capturas: la p buena del aldeano BAJA de la linea
   base; el glifo del quiz tiene cola de Ç.

   Afecta a CINCO opciones, no solo a «Kappa». David solo vio esa porque las
   otras cuatro son de preguntas que no le salieron:
       P5 Kappa   P11 Topo   P21 Espada   P34 Copita   P39 Empate

   Arreglo: en las OPCIONES la 'p' se escribe con el alias $5E.

2. «Faltan momos» -> «Sin momos»
   ------------------------------
   David lo localizo por fin: sale en el menu RUN al ejecutar un arte sin
   puntos, y se ve cortado como «Faltan m». Propone «0 puntos» pero no le
   convence. «Sin momos» son 9... tampoco cabe en 8. Cabe «Sin momo» (8),
   pero en singular chirria. Se mide el hueco real antes de decidir.

3. EL MENSAJE DEL ERMITANYO TRAS EL QUIZ
   --------------------------------------
   Pagina 1: «¡Momotaro! Ya te enseñé un»   <- frase cortada
   Pagina 2: «. ¡Corre a la Isla Ogros!»    <- empieza por punto, y «Isla»
                                               parte la I al final de linea
   Reescrito para que cada pagina sea una frase entera.

EL ERROR QUE HE REPETIDO TRES VECES
-----------------------------------
David, tres mensajes seguidos: «NO QUIERO QUE SE LLAME "VUELO", SINO HIEN».

`hien` (ヒエン) es el NOMBRE PROPIO del ermitaño, no la tecnica traducida.
Yo lo tradujé como «Vuelo» porque la tabla $D8BC comparte forma con los
nombres de arte, y no comprobé QUIEN la lee. Comprobado ahora:

    $D7CE  LDA $D8BC,X   X = $3B00*2, mundos 0..6
           -> UNICO lector de las entradas 0..6

    $D610  LDA $D8CA,X   ($D8BC + 14) -> entradas 7..13, la frase del premio

Las artes del menu SELECT viven en OTRO bloque (0x434B5) y no se tocan.
Asi que las entradas 0..6 son EXCLUSIVAMENTE el nombre del ermitaño de
cada mundo, y puedo ponerles su nombre propio sin romper nada.

    [0] hien       [1] jyanpu    [2] korokoro   [3] mawashi
    [4] bakuhatsu  [5] tsunami   [6] paropunte

Los 7 nombres nuevos se escriben en el hueco libre 0x4B7D6..0x4B85D (135 B)
y se repunta la tabla. Las entradas 7..13 (el premio) SI son artes y se
quedan como estan.

CINCO FRASES CORREGIDAS POR DAVID (literal)
-------------------------------------------
    P4   ¿De dónde salió / la ceniza?
    P9   ¿Qué había en / el cesto?        (volver a la de antes)
    P13  ¿Qué le tiró al / cangrejo?
    P17  ¿Qué hacía el / chas-chas?       (volver a la de antes)
    P20  ¿Contra quién / luchó al sumo?
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402
from quiz_texto import QUIZ, VISIBLES                                  # noqa: E402

BASE = 'roms/momotaro_es_v331.pce'
SALIDA = 'roms/momotaro_es_v332.pce'
MD5_BASE = '605160e0e669d9dd607ee2dfeab7dc90'

# ---- 1. la frase del ermitanyo -----------------------------------------
LDA_PREFIJO = 0x117BE       # A9 2D 85 BF A9 6E 85 C0  -> $6E2D
PREFIJO_VIEJO = 0x4AE2D
MARCADOR = 0x4AE31
SUFIJO = 0x4AE32
FIN = 0x4AE3A

NUEVO = 0x4B85D             # al FINAL de la zona del quiz, CPU $785D
#                             (el quiz ocupa hasta 0x4B7D6; aqui sobran 30 B)
CPU_BASE = 0x6000
ROM_BASE = 0x4A000

NOMBRES_ERM = ['Hien', 'Janpu', 'Korokoro', 'Mawashi', 'Bakuhatsu',
               'Tsunami', 'Paropunte']
NOMBRES_OFF = 0x4B7D6       # hueco libre entre el quiz y la frase
TABLA_TEC = 0x118BC

#  El mensaje que suelta el ermitanyo cuando ya te enseño el arte.
#  David: pagina 1 «¡Momotaro! Ya te enseñé un» (cortada) y pagina 2
#  «. ¡Corre a la Isla Ogros!» (empieza por punto y «Isla» parte la I).
#  Cada bloque son lineas de 16 columnas que el motor encadena; hay que
#  cuadrar las palabras DENTRO de cada linea de 16.
#  El japones reparte asi:
#    $6D76  3 lineas: «Momotaro! yo ya» / «te enseñe un arte!» / «corre! ve a
#                      la isla de los ogros!»
#    $6DBC  2 lineas: «aun te falta entrenamiento!» / «vuelve otro dia!»
#  SON DOS PAGINAS SEPARADAS, no un bloque de 70 B. Medido en $CFD1:
#      $CFDC  LDA #$76 / #$6D  -> pinta $6D76        PAGINA 1
#      $CFE7  LDA #$9A / #$6D  -> deja $6D9A lista   PAGINA 2
#  o sea el corte esta en 0x4AD9A, y mi «arte.» quedaba partido justo ahi:
#  el punto caia al principio de la pagina 2. Eso es el «. ¡Ve a la isla»
#  que veia David.
CIERRE = [
    (0x4AD76, 0x4AD9A, ['¡Momotaro! Ya te', 'enseñé un arte.']),
    (0x4AD9A, 0x4ADBC, ['¡Ve a la Isla', 'de Ogros!']),
    (0x4ADBC, 0x4ADE2, ['¡Aún te falta', 'entrenamiento!']),
]

#  El premio se imprime en TRES trozos ($D5F6):
#      $D600  ptr $6DE2      «sasuga wa Momotaro ja!»
#      $D610  tabla $D8CA    <TECNICA>
#      $D61D  ptr $6DF5      «wo sazukeyou zo!»
#  En japones la particula va DETRAS del nombre; en castellano el «Toma:»
#  tiene que ir DELANTE. Yo lo puse en el tercer trozo y salia
#  «+VueloToma:». El bloque $6DE2 son 18 B y no caben «¡Bien hecho!» (16
#  con relleno) + «Toma: », asi que se REPUNTA a espacio libre.
PREMIO_LDA = 0x11600        # LDA #$E2 / STA $BF / LDA #$6D / STA $C0
PREMIO_NUEVO = 0x4B80E      # 79 B libres entre los nombres y la frase
PREMIO_L1 = '¡Bien hecho!'
PREMIO_L2 = 'Toma: '        # el nombre de la tecnica se pega detras
PREMIO_CIERRE = (0x4ADF5, 0x4AE00, '!')

FALTAN = 0x19BFA            # «Faltan momos» + $00, con 4 B de $FF detras
FALTAN_MAX = 8              # medido en la captura: se ve «Faltan m»
FALTAN_NUEVO = '0 momos'    # 7. David proponia «0 puntos», pero los momos
#                             son la moneda real del juego y ya sale asi

L1 = '¡Yo soy el'           # linea 1, se rellena a 16
L2 = 'ermitaño '            # linea 2, el nombre se pega detras
SUF = '!'                   # cierra tras el nombre

COLS = 16
RELLENO = 0xA0

# ---- 2. las preguntas que no se entendian ------------------------------
#   P1  «¿Qué le dio / Otohime a él?»   el «a él» no tiene antecedente
#   P4  «¿Al quemar qué / salió ceniza?» no se entiende (la que mando David)
#   P9  «¿Qué había en / el cesto?»     faltaba que el cesto era el PESADO
#   P13 «El mono, ¿qué / le tiró?»      no decia a quien
#   P17 «¿Qué hacía el / chas-chas?»    «hacer un chas-chas» no se dice
#   P20 «¿Quién luchó a / sumo con él?» «con él» sin antecedente
#   P34 «¿En qué barco / iba Issun?»    «Issun» a secas
# Todas en quiz_texto.py. Aqui se reescribe la zona ENTERA.
ZONA_INI = 0x4AEEE
COLS_PREG = 16
UTILES = 7

TABLA = 0x11818
ZONA_FIN = 0x4B87B

INTACTAS = [
    (0x00000, 0x10000, 'bancos 00-07'),
    (0x12000, 0x19BFA, 'bancos 09-0C hasta «Faltan momos»'),
    (0x19C07, 0x4A000, 'resto de bancos 0C-24'),
    (0x4A000, 0x4AD76, 'dados y el bloque limpiador'),
    (0x4ADE2, 0x4ADF5, 'primer trozo del premio'),
    (0x4AE00, 0x4AE2D, 'tras el premio'),
    (0x4AE3B, 0x4AEE6, 'quiz/ppt y las 14 tecnicas'),
    (0x4B87B, 0x4C000, 'cierre del quiz'),
    (0x4C000, 0x80000, 'bancos 26-3F'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v328'
    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    # ============ 1. la frase completa ==================================
    # la v329 ya lo repunto a $785D; comprobamos la FORMA, no el valor
    assert rom[LDA_PREFIJO] == 0xA9 and rom[LDA_PREFIJO + 2:LDA_PREFIJO + 4] \
        == bytes([0x85, 0xBF]) and rom[LDA_PREFIJO + 4] == 0xA9, \
        'en %06X no esta el LDA del prefijo' % LDA_PREFIJO
    # el destino tiene que estar libre de verdad
    largo = COLS + len(cv.encode(L2)) + 1        # 16 + 9 + el $00
    assert NUEVO + largo < ZONA_FIN, 'se sale de la zona'

    d = (cv.encode(L1) + bytes([RELLENO]) * (COLS - len(L1)) + cv.encode(L2))
    rom[NUEVO:NUEVO + len(d)] = d
    rom[NUEVO + len(d)] = 0x00                   # marcador de sustitucion

    cpu = CPU_BASE + NUEVO - ROM_BASE
    assert 0x6000 <= cpu < 0x8000
    rom[LDA_PREFIJO + 1] = cpu & 0xFF
    rom[LDA_PREFIJO + 5] = cpu >> 8

    # --- el mensaje del ermitanyo tras el quiz -------------------------
    for ca, cb, lineas in CIERRE:
        dd = b''
        for l in lineas:
            assert len(l) <= 16, '«%s» son %d columnas' % (l, len(l))
            dd += cv.encode(l) + bytes([RELLENO]) * (16 - len(l))
        assert len(dd) <= cb - ca, '%s ocupa %d y hay %d' % (
            lineas, len(dd), cb - ca)
        rom[ca:cb] = dd + bytes([RELLENO]) * (cb - ca - len(dd))

    # --- el premio: «¡Bien hecho! / Toma: <TECNICA>!» ------------------
    assert rom[PREMIO_LDA] == 0xA9 and rom[PREMIO_LDA + 1] == 0xE2 and \
        rom[PREMIO_LDA + 4] == 0xA9 and rom[PREMIO_LDA + 5] == 0x6D, \
        'en %06X no esta el LDA del premio' % PREMIO_LDA
    dp = (cv.encode(PREMIO_L1) + bytes([RELLENO]) * (16 - len(PREMIO_L1)) +
          cv.encode(PREMIO_L2))
    assert all(rom[PREMIO_NUEVO + k] == RELLENO
               for k in range(len(dp) + 1)), 'el hueco del premio no esta libre'
    assert PREMIO_NUEVO + len(dp) + 1 < NUEVO, 'el premio pisa la frase'
    rom[PREMIO_NUEVO:PREMIO_NUEVO + len(dp)] = dp
    rom[PREMIO_NUEVO + len(dp)] = 0x00
    cpu_p = CPU_BASE + PREMIO_NUEVO - ROM_BASE
    rom[PREMIO_LDA + 1] = cpu_p & 0xFF
    rom[PREMIO_LDA + 5] = cpu_p >> 8
    # el tercer trozo cierra la frase tras el nombre
    ca, cb, txt = PREMIO_CIERRE
    rom[ca:cb] = cv.encode(txt) + bytes([RELLENO]) * (cb - ca - len(txt))

    # --- «Faltan momos» -> «0 momos» ---------------------------------
    import charset_oficial as co
    # la v331 ya lo cambio: aceptamos el original o el nuestro
    viejo = co.encode('Faltan momos')
    if rom[FALTAN:FALTAN + len(viejo)] != viejo:
        assert rom[FALTAN:FALTAN + 7] == co.encode('0 momos'), \
            'en %06X no esta ni «Faltan momos» ni «0 momos»' % FALTAN
    nuevo_f = co.encode(FALTAN_NUEVO)
    assert len(nuevo_f) <= FALTAN_MAX, '«%s» son %d, caben %d' % (
        FALTAN_NUEVO, len(nuevo_f), FALTAN_MAX)
    rom[FALTAN:FALTAN + len(viejo) + 1] = (
        nuevo_f + bytes([0x00]) + bytes([0xFF]) * (len(viejo) - len(nuevo_f)))

    # el sufijo, en su sitio de siempre
    ds = cv.encode(SUF)
    rom[SUFIJO:FIN] = ds + bytes([RELLENO]) * (FIN - SUFIJO - len(ds))
    rom[FIN] = 0x80

    # el hueco viejo queda muerto: a relleno, respetando su $00 y su $80
    rom[PREFIJO_VIEJO:MARCADOR] = bytes([RELLENO]) * (MARCADOR - PREFIJO_VIEJO)
    rom[MARCADOR] = 0x00

    # ============ 2. la P4 ==============================================
    def blq(i):
        c = rom[TABLA + 2 * i] | rom[TABLA + 2 * i + 1] << 8
        return ROM_BASE + c - CPU_BASE

    bloques = []
    for _n, l1, l2, _o1, _o2, _o3, _jp in QUIZ:
        assert len(l1) <= VISIBLES and len(l2) <= VISIBLES, (l1, l2)
        bloques.append(cv.encode(l1) + bytes([RELLENO]) * (COLS - len(l1)) +
                       bytes([0x80]) +
                       cv.encode(l2) + bytes([RELLENO]) * (COLS - len(l2)))
    def enc_opcion(txt):
        """En las OPCIONES la 'p' va con el alias $5E, no con el $B0 directo.

        Medido: preguntas y opciones usan juegos de glifos distintos.
        En opciones el $B0 pinta una Ç («KaÇÇa»). La 'b' y la 'c' directas
        ($A2/$A3) SI funcionan aqui; la unica que falla es la 'p'.
        """
        out = bytearray()
        for c in txt:
            out.append(0x5E if c == 'p' else cv.CHAR_TO_CODE[c])
        return bytes(out)

    for _n, _l1, _l2, o1, o2, o3, _jp in QUIZ:
        r = b''
        for op in (o1, o2, o3):
            assert len(op) <= UTILES, op
            r += (bytes([RELLENO]) + enc_opcion(op) +
                  bytes([RELLENO]) * (UTILES - len(op)))
        bloques.append(r)

    # el prefijo del ermitanyo vive al final de la zona: no lo pisamos
    tope = NOMBRES_OFF
    total = sum(len(b) for b in bloques)
    assert ZONA_INI + total <= tope, 'el quiz (%d B) pisaria el prefijo' % total

    pos = ZONA_INI
    for i, b in enumerate(bloques):
        rom[pos:pos + len(b)] = b
        c = CPU_BASE + pos - ROM_BASE
        rom[TABLA + 2 * (i + 2)] = c & 0xFF
        rom[TABLA + 2 * (i + 2) + 1] = c >> 8
        pos += len(b)
    rom[pos:tope] = bytes([RELLENO]) * (tope - pos)

    # --- los 7 nombres propios del ermitanyo -------------------------
    pos_n = NOMBRES_OFF
    for i, nom in enumerate(NOMBRES_ERM):
        b = cv.encode(nom)
        # el hueco puede traer los nombres de la v330: se reescriben
        assert pos_n + len(b) + 1 <= NUEVO, 'los nombres pisan la frase'
        rom[pos_n:pos_n + len(b)] = b
        rom[pos_n + len(b)] = 0x00
        c2 = CPU_BASE + pos_n - ROM_BASE
        rom[TABLA_TEC + 2 * i] = c2 & 0xFF
        rom[TABLA_TEC + 2 * i + 1] = c2 >> 8
        pos_n += len(b) + 1
    assert pos_n <= NUEVO, 'los nombres pisan la frase'


    # ============ VERIFICACION ==========================================
    def lee(cpu_, hasta=(0x00, 0x80, 0xFF)):
        o = ROM_BASE + cpu_ - CPU_BASE
        e = o
        while rom[e] not in hasta:
            e += 1
        return ''.join(' ' if x == RELLENO else rv.get(x, '?') for x in rom[o:e])

    # la frase, montada como la monta $D7AE: prefijo + tecnica + sufijo
    pref = lee(rom[LDA_PREFIJO + 1] | rom[LDA_PREFIJO + 5] << 8)
    suf = lee(0x6E32)
    for i, tec in enumerate(NOMBRES_ERM):
        frase = (pref + tec + suf).rstrip()
        assert 'ermitaño' in frase, 'falta «ermitaño»: «%s»' % frase
        assert frase.startswith('¡Yo soy el'), frase
        assert frase.endswith('!'), frase
        # y el nombre va PEGADO a «ermitaño », sin hueco
        assert 'ermitaño ' + tec + '!' in frase, frase
    for tec in NOMBRES_ERM:
        print('  «%s»' % (pref + tec + suf).replace('      ', ' ').rstrip())

    # las 14 tecnicas siguen enteras
    esperados = NOMBRES_ERM + ['+Vuelo', '+Salto', '+Rodar', '+Giro',
                               '+Bomba', '+Ola', 'Parapunte']
    for i, nombre in enumerate(esperados):
        c = rom[0x118BC + 2 * i] | rom[0x118BC + 2 * i + 1] << 8
        assert lee(c, (0x00, 0x80)).strip() == nombre, 'tecnica [%d] rota' % i

    # el premio, montado como lo monta $D5F6
    pr = lee(rom[PREMIO_LDA + 1] | rom[PREMIO_LDA + 5] << 8)
    cierre_txt = lee(0x6DF5)
    for tec in ('+Vuelo', '+Salto', 'Parapunte'):
        frase_p = (pr + tec + cierre_txt).rstrip()
        assert 'Toma: ' + tec in frase_p, 'premio mal: «%s»' % frase_p
        assert frase_p.endswith('!'), frase_p
    print('  premio: «%s»' % (pr + '+Vuelo' + cierre_txt).replace('    ', ' ').rstrip())

    # el limpiador, intacto
    assert rom[0x4AD56:0x4AD76] == bytes([0x20]) * 32, 'limpiador tocado'

    # las 40 preguntas y las 120 opciones, releidas por puntero
    for i, (_n, l1, l2, o1, o2, o3, _jp) in enumerate(QUIZ):
        a = blq(i + 2)
        assert rom[a + COLS] == 0x80, 'P%d sin $80' % (i + 1)
        g1 = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                     for x in rom[a:a + COLS]).rstrip()
        g2 = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                     for x in rom[a + COLS + 1:a + 2 * COLS + 1]).rstrip()
        assert (g1, g2) == (l1, l2), 'P%d «%s»/«%s»' % (i + 1, g1, g2)
        b = blq(i + 42)
        for k, op in enumerate((o1, o2, o3)):
            cel = rom[b + k * 8:b + (k + 1) * 8]
            assert cel[0] == RELLENO, 'P%d op%d sin sangria' % (i + 1, k + 1)
            g = ''.join(' ' if x == RELLENO else
                        ('p' if x == 0x5E else rv.get(x, '?')) for x in cel).strip()
            assert g == op, 'P%d op%d «%s» != «%s»' % (i + 1, k + 1, g, op)
            # y NINGUNA opcion puede llevar el $B0 directo
            assert 0xB0 not in cel, 'P%d op%d lleva $B0 (saldria Ç)' % (
                i + 1, k + 1)

    # cero alias en la zona del quiz
    # En las PREGUNTAS no puede haber NINGUN alias (daban ©).
    # En las OPCIONES el unico permitido es $5E (la p); $5B/$5D/$5C no.
    for i, _q in enumerate(QUIZ):
        a2 = blq(i + 2)
        for x in rom[a2:a2 + 33]:
            assert x not in (0x5B, 0x5D, 0x5E, 0x5C), \
                'P%d: alias $%02X en la pregunta' % (i + 1, x)
        b2 = blq(i + 42)
        for x in rom[b2:b2 + 24]:
            assert x not in (0x5B, 0x5D, 0x5C), \
                'P%d: alias $%02X en las opciones' % (i + 1, x)
    # y el cierre, sin alias de ningun tipo
    malos = [i for i in range(0x4AD76, 0x4AE0A)
             if rom[i] in (0x5B, 0x5D, 0x5E, 0x5C)]
    assert not malos, 'alias en el cierre: %s' % ['%06X' % x for x in malos[:5]]

    # toda pregunta cierra su interrogacion
    for q in range(40):
        o = blq(q + 2)
        t = ''.join(' ' if x == RELLENO else rv.get(x, '')
                    for x in rom[o:o + 33] if x != 0x80)
        assert t.count('¿') == t.count('?'), 'P%d: «%s»' % (q + 1, t)

    for a2, b2, nombre in INTACTAS:
        assert rom[a2:b2] == original[a2:b2], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print('  prefijo repuntado $6E2D -> $%04X (ROM %06X)' % (cpu, NUEVO))
    print('  quiz reescrito: %d B, tope %06X' % (total, tope))
    for q in (1, 4, 9, 13, 17, 20, 34):
        n, l1, l2 = QUIZ[q - 1][0], QUIZ[q - 1][1], QUIZ[q - 1][2]
        print('    P%-2d |%-15s| |%s|' % (n, l1, l2))


if __name__ == '__main__':
    main()
