#!/usr/bin/env python3
"""v311 = v308 + el menu SELECT rediseñado por David (VIDA -> SALUD).

David rehizo TODAS las letras del menu para que hubiera coherencia con
SALUD, respetando la zona marcada. Son 100 celdas, no solo las 5 del
rotulo.

Estructura real (medida sobre el savestate de la v308, NO sobre
docs/select_vram.bin, que es un volcado japones y costo tres ROMs malas):

    CG   0x0F3D9  un stream de 256 tiles -> VRAM $100..$1FF
                  cargador en $D32D (ROM 0x1B32D): banco $07, puntero $53D9
    BAT  la de 0x1E7EA es la JAPONESA y difiere de la pantalla real en 160
         celdas: la buena la compone el juego en ejecucion. NO se toca.

Como la BAT no se puede repuntar, solo se pueden redibujar tiles cuyo
dibujo nuevo sea COHERENTE en todas las celdas que los comparten. De las
100 celdas hay 4 tiles compartidos por parejas que piden dibujos distintos:

    $191  (4,2) y (4,6)     bordes de ARMA
    $196  (4,8) y (6,2)
    $1A3  (5,8) y (15,2)
    $1A8  (7,3) y (15,3)    la R de ARMA y la de ARMADURA

Para esos se coge un tile LIBRE del stream (hay 101) y se le da a UNA de
las dos celdas... pero sin poder tocar la BAT no hay forma de que la celda
apunte al tile nuevo. Asi que esas celdas se dejan con el dibujo que ya
tienen y se avisa.
"""
import hashlib, sys, zlib
sys.path.insert(0, 'tools')
from PIL import Image
from descomp_cg import descomprime, comprime
from select_bg import tile_de_cg, a_bytes

SRC = 'roms/momotaro_es_v308.pce'
DST = 'roms/momotaro_es_v311.pce'
PNG = '/home/user/uploads/Pantalla SELECT.png'
CG_INI, N_CG = 0x0F3D9, 256

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
assert hashlib.md5(orig).hexdigest() == '05de5af123244e3d970f78a5d78057bf', 'la base no es la v308'

vram = open('/home/user/descargas/v308_vram.bin', 'rb').read()
pal = open('/home/user/descargas/v308_pal.bin', 'rb').read()
def rgb(i):
    w = pal[i * 2] | (pal[i * 2 + 1] << 8)
    g, r, b = (w >> 6) & 7, (w >> 3) & 7, w & 7
    return (r * 36, g * 36, b * 36)
COL = {rgb(i): i for i in range(16)}
def word(f, c):
    o = (f * 64 + c) * 2
    return vram[o] | (vram[o + 1] << 8)
def tv(idx):
    b = idx * 32
    return tuple(tuple(((vram[b + r * 2] >> (7 - k)) & 1) |
                       (((vram[b + r * 2 + 1] >> (7 - k)) & 1) << 1) |
                       (((vram[b + 16 + r * 2] >> (7 - k)) & 1) << 2) |
                       (((vram[b + 16 + r * 2 + 1] >> (7 - k)) & 1) << 3)
                       for k in range(8)) for r in range(8))

im = Image.open(PNG).convert('RGB')
assert im.size == (256, 176), 'el PNG debe medir 256x176'
px = im.load()
for y in range(176):
    for x in range(256):
        assert px[x, y] in COL, 'color %s fuera de la paleta en (%d,%d)' % (px[x, y], x, y)
def tp(cx, cy):
    return tuple(tuple(COL[px[cx * 8 + k, cy * 8 + r]] for k in range(8)) for r in range(8))

# --- el stream que carga el juego -----------------------------------------
off = rom[0x1B32E] * 0x2000 + (((rom[0x1B341] << 8) | rom[0x1B33D]) - 0x4000)
assert off == CG_INI, 'el cargador apunta a %#07x' % off
cg, cg_fin = descomprime(rom, CG_INI, N_CG)
tiles = [tile_de_cg(cg, i) for i in range(N_CG)]
assert sum(1 for i in range(N_CG) if tiles[i] == tv(0x100 + i)) >= 200, 'el stream no es el del menu'

# --- que celdas cambian ----------------------------------------------------
uso = {}
for f in range(28):
    for c in range(32):
        uso.setdefault(word(f, c) & 0x7FF, []).append((f, c))
dinamicas = {(f, c) for f in range(22) for c in range(32) if (word(f, c) >> 8) == 0x02}

cambian = [(f, c) for f in range(22) for c in range(32)
           if (f, c) not in dinamicas and tp(c, f) != tv(word(f, c) & 0x7FF)]

hechas, saltadas = 0, []
for f, c in cambian:
    t = word(f, c) & 0x7FF
    if not (0x100 <= t <= 0x1FF):
        saltadas.append((f, c, 'fuera del stream'))
        continue
    dibujos = {tp(cc, ff) for ff, cc in uso[t]}
    if len(dibujos) > 1:
        saltadas.append((f, c, 'tile $%03X compartido' % t))
        continue
    tiles[t - 0x100] = tp(c, f)
    hechas += 1

print('celdas que cambian: %d -> %d aplicadas, %d saltadas' % (len(cambian), hechas, len(saltadas)))
for f, c, m in saltadas:
    print('   (%2d,%2d)  %s' % (f, c, m))

# --- recomprimir en su sitio ----------------------------------------------
raw = b''.join(a_bytes(t) for t in tiles)
cg_comp = comprime(raw)
assert descomprime(cg_comp, 0, N_CG)[0] == raw, 'round-trip del CG falla'
hueco = cg_fin - CG_INI
assert len(cg_comp) <= hueco, 'el CG crece de %d a %d B' % (hueco, len(cg_comp))
rom[CG_INI:CG_INI + len(cg_comp)] = cg_comp
rom[CG_INI + len(cg_comp):cg_fin] = orig[CG_INI + len(cg_comp):cg_fin]

# --- nada mas puede cambiar ------------------------------------------------
fuera = [i for i in range(len(rom)) if rom[i] != orig[i] and not (CG_INI <= i < cg_fin)]
assert not fuera, 'cambios fuera del CG: %s' % [hex(x) for x in fuera[:8]]
assert rom[0x1E7EA:0x1E9E8] == orig[0x1E7EA:0x1E9E8], 'la BAT se ha tocado'
assert rom[0x1B32D:0x1B344] == orig[0x1B32D:0x1B344], 'el cargador se ha tocado'
assert rom[0x1BBB9:0x1BFDC] == orig[0x1BBB9:0x1BFDC], 'la tabla del menu se ha tocado'
for nom, a, b in (('vitores', 0x48401, 0x4847D), ('CG de tienda', 0x2C05A, 0x2C319),
                  ('glifos', 0x3D660, 0x3E000), ('textos de tienda', 0x48460, 0x48C60),
                  ('Game Over', 0x1F9C4, 0x1FA00)):
    assert rom[a:b] == orig[a:b], '%s tocado' % nom
assert rom[0x47CFB] == 0xFF, 'terminador del abuelo pisado'

open(DST, 'wb').write(rom)

# --- relectura por el puntero del cargador --------------------------------
v = open(DST, 'rb').read()
off2 = v[0x1B32E] * 0x2000 + (((v[0x1B341] << 8) | v[0x1B33D]) - 0x4000)
cg2, _ = descomprime(v, off2, N_CG)
T2 = [tile_de_cg(cg2, i) for i in range(N_CG)]
mal = [(f, c) for f, c in cambian
       if (f, c) not in [(x, y) for x, y, _ in saltadas]
       and T2[(word(f, c) & 0x7FF) - 0x100] != tp(c, f)]
assert not mal, 'no releen el PNG: %s' % mal[:6]
print('las %d celdas aplicadas releen el PNG de David' % hechas)

b = bytes(v)
print('%s  (%d bytes cambiados)' % (DST, sum(1 for i in range(len(b)) if b[i] != orig[i])))
print('  MD5    %s' % hashlib.md5(b).hexdigest())
print('  SHA-1  %s' % hashlib.sha1(b).hexdigest())
print('  CRC32  %08X' % (zlib.crc32(b) & 0xFFFFFFFF))
