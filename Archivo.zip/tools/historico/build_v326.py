#!/usr/bin/env python3
"""build_v326.py - El ermitanyo BIEN (David tenia razon) y las tecnicas repuntadas.

1. EL «Vuelo.»: NO SOBRABA. Me equivoque, David lo intuyo.
   ------------------------------------------------------
   David: «creo que no es que sobre, sino que tendria que ir otro texto».
   Su captura de la ROM japonesa lo confirma: UNA linea,
   «washi wa hien sennin ja!» = «yo soy el ermitanyo Vuelo».

   El codigo concatena TRES trozos en el mismo bocadillo:

       $D7C6  JSR $DD42   ptr $6E2D -> «washi wa »      = «Soy »
       $D7D8  JSR $DD42   tabla $D8BC[tecnica]          = «Vuelo»
       $D7E3  JSR $DD42   ptr $6E32 -> «sennin ja!»     = « ...!»

   En la v324 puse NOP en el PRIMERO creyendo que sobraba. Resultado: se
   perdio el «Soy » y quedo «Vuelo.» huerfano, que es lo que David seguia
   viendo. **Se revierten los NOP.**

   Cuarta vez que me equivoco en este mismo bloque (v318, v322, v323, v324).
   Las tres primeras fueron de offset; esta fue de COMPRENSION: di por
   sobrante un texto que era el principio de una frase compuesta.

2. LOS 14 NOMBRES DE TECNICA ESTABAN ROTOS (bug de la v317, sin detectar)
   ----------------------------------------------------------------------
   La tabla $D8BC (ROM 0x118BC) conserva los OFFSETS JAPONESES, pero los
   nombres castellanos tienen longitudes distintas. Siguiendo el puntero:

       [ 0] -> «Vuelo»      OK por casualidad
       [ 1] -> «o»          debia ser «Salto»
       [ 2] -> «odar»       debia ser «Rodar»
       [ 7] -> «»           debia ser «+Vuelo»
       ...  12 de 14 rotas

   Los nombres SI estan bien escritos en 0x4AE86, troceados por $00. Lo que
   falla es la tabla. Se repunta siguiendo los $00 reales.

   Esto explica el miedo de David: «Vuelo es una de las artes de Momotaro».
   Justamente por eso habia que arreglarlo antes de tocar nada mas.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402

BASE = 'roms/momotaro_es_v325.pce'
SALIDA = 'roms/momotaro_es_v326.pce'
MD5_BASE = 'e0aaf6e16c625afda2961b5f8dc92b94'

# ---- 1. revertir los NOP ------------------------------------------------
JSR = 0x117C6
NOP3 = bytes([0xEA, 0xEA, 0xEA])
JSR_BYTES = bytes([0x20, 0x42, 0xDD])       # JSR $DD42

# ---- 2. el bloque del ermitanyo ----------------------------------------
BLOQUE1 = 0x4AE0A       # 35 B, mensaje independiente («¡Sin excesos!...»)
MEDIO = 0x4AE2D         # 5 B: 4 de texto + el $00 marcador en 0x4AE31
MARCADOR = 0x4AE31
CIERRE = 0x4AE32        # 8 B
FIN = 0x4AE3A           # $80

COLS = 16
L1 = '¡Sin excesos!'
L2 = '¡Jujú!'
TXT_MEDIO = 'Soy '      # 4 B exactos
TXT_CIERRE = '.'        # se pega tras el nombre de la tecnica

# ---- 3. la tabla de tecnicas -------------------------------------------
TABLA_TEC = 0x118BC     # 14 words, base CPU $6000 -> ROM 0x4A000
NOMBRES_INI = 0x4AE86
NOMBRES_FIN = 0x4AEE6
CPU_BASE = 0x6000
ROM_BASE = 0x4A000

RELLENO = 0xA0

INTACTAS = [
    (0x00000, 0x10000, 'bancos 00-07'),
    (0x12000, 0x42000, 'bancos 09-20'),
    (0x42000, 0x4A000, 'bancos 21-24'),
    (0x4A000, 0x4AE0A, 'creditos y dados'),
    (0x4AEE6, 0x4C000, 'el QUIZ y el diccionario'),
    (0x4C000, 0x80000, 'bancos 26-3F'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v325'

    # ============ 1. revertir los NOP ===================================
    assert rom[JSR:JSR + 3] == NOP3, 'en %06X no estan los NOP de la v324' % JSR
    rom[JSR:JSR + 3] = JSR_BYTES

    # ============ 2. el bloque del ermitanyo ============================
    # geometria japonesa, byte a byte (norma 297)
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    assert jp[MARCADOR] == 0x00, 'no hay marcador en %06X' % MARCADOR
    assert jp[FIN] == 0x80, 'no hay $80 en %06X' % FIN

    h1 = MEDIO - BLOQUE1            # 35
    hm = MARCADOR - MEDIO           # 4
    hc = FIN - CIERRE               # 8
    assert (h1, hm, hc) == (35, 4, 8), '%d/%d/%d' % (h1, hm, hc)

    d1 = (cv.encode(L1) + bytes([RELLENO]) * (COLS - len(L1)) + cv.encode(L2))
    assert len(d1) <= h1
    rom[BLOQUE1:MEDIO] = d1 + bytes([RELLENO]) * (h1 - len(d1))

    dm = cv.encode(TXT_MEDIO)
    assert len(dm) == hm, '«%s» ocupa %d y el hueco es %d' % (
        TXT_MEDIO, len(dm), hm)
    rom[MEDIO:MARCADOR] = dm
    rom[MARCADOR] = 0x00

    dc = cv.encode(TXT_CIERRE)
    assert len(dc) <= hc
    rom[CIERRE:FIN] = dc + bytes([RELLENO]) * (hc - len(dc))
    rom[FIN] = 0x80

    # ============ 3. repuntar las 14 tecnicas ===========================
    # trocear por $00 lo que YA hay escrito
    trozos = []
    ini = NOMBRES_INI
    for a in range(NOMBRES_INI, NOMBRES_FIN):
        if rom[a] == 0x00:
            trozos.append((ini, bytes(rom[ini:a])))
            ini = a + 1
    assert len(trozos) == 14, 'esperaba 14 nombres, hay %d' % len(trozos)

    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}
    esperados = ['Vuelo', 'Salto', 'Rodar', 'Giro', 'Bomba', 'Ola', 'Parapunte',
                 '+Vuelo', '+Salto', '+Rodar', '+Giro', '+Bomba', '+Ola',
                 'Parapunte']
    for i, (off, b) in enumerate(trozos):
        txt = ''.join(rv.get(x, '?') for x in b)
        assert txt == esperados[i], '[%d] es «%s», esperaba «%s»' % (
            i, txt, esperados[i])
        cpu = CPU_BASE + off - ROM_BASE
        assert 0x6000 <= cpu < 0x8000
        rom[TABLA_TEC + 2 * i] = cpu & 0xFF
        rom[TABLA_TEC + 2 * i + 1] = cpu >> 8

    # ============ VERIFICACION ==========================================
    # -- relectura SIGUIENDO EL PUNTERO, como el motor (norma 287) -------
    for i, nombre in enumerate(esperados):
        p = rom[TABLA_TEC + 2 * i] | rom[TABLA_TEC + 2 * i + 1] << 8
        o = ROM_BASE + p - CPU_BASE
        e = o
        while rom[e] not in (0x00, 0x80):
            e += 1
        leido = ''.join(rv.get(x, '?') for x in rom[o:e])
        assert leido == nombre, '[%d] el puntero lleva a «%s», no a «%s»' % (
            i, leido, nombre)

    # -- la frase compuesta, montada como la monta el codigo -------------
    def sigue(cpu):
        o = ROM_BASE + cpu - CPU_BASE
        e = o
        while rom[e] not in (0x00, 0x80):
            e += 1
        return ''.join(rv.get(x, '') for x in rom[o:e] if x != RELLENO)

    frase = sigue(0x6E2D) + esperados[0] + sigue(0x6E32)
    assert frase == 'Soy Vuelo.', 'la frase montada es «%s»' % frase
    # con el espacio real:
    crudo = (''.join(rv.get(x, '') for x in rom[MEDIO:MARCADOR]) +
             esperados[0] +
             ''.join(rv.get(x, '') for x in rom[CIERRE:FIN] if x != RELLENO))
    assert crudo == 'Soy Vuelo.', 'la frase real es «%s»' % crudo

    assert rom[JSR:JSR + 3] == JSR_BYTES
    assert rom[MARCADOR] == 0x00 and rom[FIN] == 0x80
    extras = [i for i in range(BLOQUE1, MARCADOR) if rom[i] == 0x00]
    assert not extras, 'hay $00 de mas en %s' % [hex(x) for x in extras]

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  1. NOP -> JSR $DD42 en %06X (vuelve el «Soy »)' % JSR)
    print('  2. bocadillo: |%s| / |%s|  y  «Soy <TECNICA>.»' % (L1, L2))
    print('  3. las 14 tecnicas repuntadas:')
    for i, (off, _b) in enumerate(trozos):
        print('       [%2d] %06X  %s' % (i, off, esperados[i]))


if __name__ == '__main__':
    main()
