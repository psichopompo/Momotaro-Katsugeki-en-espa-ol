#!/usr/bin/env python3
"""build_v334.py - «Los ogros no te ven.» en la descripcion de la Capa.

LA CELDA, MEDIDA
----------------
    0x48A06 .. 0x48A16   16 B   nombre       «Capa:»
    0x48A16 .. 0x48A2A   20 B   descripcion  «Ogros no te ven.» + « te »
    0x48A2A              siguiente objeto    «Aletas:»

El hueco de descripcion son **20 bytes**, no los 16 que ocupaba la frase.
Los 4 de detras («` te `») son resto de un troceo viejo: no los apunta nadie
y el motor corta antes de llegar, asi que no se veian. Es el mismo caso que
los 8 bytes japoneses de la v333 (norma 321).

«Los ogros no te ven.» son 20 caracteres: entra exacto.

El motor de tienda ($9B0B) corta a 16 columnas, asi que en pantalla queda:

    |Los ogros no te |
    |ven.            |

Parte entre palabras, se lee bien.

OJO CON EL CHARSET
------------------
Estas descripciones las pinta el motor de TIENDA ($9B0B), que NO tiene la
tabla de sustitucion $AB34. Los alias b/c/p = $5B/$5D/$5E caen ahi en el
glifo $8B, que es una ©. Hay que usar `charset_vitores` (bytes directos),
que es justo lo que hace este constructor.
"""
import hashlib
import sys
import zlib

sys.path.insert(0, 'tools')
import charset_vitores as cv                                          # noqa: E402

BASE = 'roms/momotaro_es_v333.pce'
SALIDA = 'roms/momotaro_es_v334.pce'
MD5_BASE = 'ffdefd8dc6c8d83371ff259e2ecb92ae'

CAPA_NOMBRE = 0x48A06
CAPA_DESC = 0x48A16
CAPA_FIN = 0x48A2A          # aqui empieza «Aletas:»

VIEJO = 'Ogros no te ven.'
NUEVO = 'Los ogros no te ven.'

RELLENO = 0xA0

INTACTAS = [
    (0x00000, 0x48A16, 'todo lo anterior'),
    (0x48A2A, 0x80000, 'todo lo posterior'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v333'
    rv = {b: c for c, b in cv.CHAR_TO_CODE.items()}

    # --- comprobar la geometria antes de escribir ------------------------
    hueco = CAPA_FIN - CAPA_DESC
    assert hueco == 20, 'el hueco son %d B, esperaba 20' % hueco
    viejo = cv.encode(VIEJO)
    assert rom[CAPA_DESC:CAPA_DESC + len(viejo)] == viejo, \
        'en %06X no esta «%s»' % (CAPA_DESC, VIEJO)
    # el nombre de delante y el objeto de detras, para no equivocarme de celda
    assert rom[CAPA_NOMBRE:CAPA_NOMBRE + 5] == cv.encode('Capa:'), \
        'en %06X no esta «Capa:»' % CAPA_NOMBRE
    assert rom[CAPA_FIN:CAPA_FIN + 7] == cv.encode('Aletas:'), \
        'en %06X no esta «Aletas:»' % CAPA_FIN

    # --- escribir --------------------------------------------------------
    d = cv.encode(NUEVO)
    assert len(d) <= hueco, '«%s» son %d y el hueco es %d' % (
        NUEVO, len(d), hueco)
    rom[CAPA_DESC:CAPA_FIN] = d + bytes([RELLENO]) * (hueco - len(d))

    # --- VERIFICACION ----------------------------------------------------
    leido = ''.join(' ' if x == RELLENO else rv.get(x, '?')
                    for x in rom[CAPA_DESC:CAPA_FIN]).rstrip()
    assert leido == NUEVO, 'leido «%s»' % leido

    # cero bytes ajenos al charset (el « te » residual tenia que irse)
    validos = set(cv.CHAR_TO_CODE.values()) | {RELLENO}
    malos = [i for i in range(CAPA_DESC, CAPA_FIN) if rom[i] not in validos]
    assert not malos, 'bytes ajenos en %s' % ['%06X' % x for x in malos]

    # ningun alias: este motor los pinta como ©
    alias = [i for i in range(CAPA_DESC, CAPA_FIN)
             if rom[i] in (0x5B, 0x5D, 0x5E, 0x5C)]
    assert not alias, 'alias en %s (saldrian ©)' % ['%06X' % x for x in alias]

    # como lo parte el motor, a 16 columnas
    l1 = leido[:16]
    l2 = leido[16:]
    assert not l1.endswith(('L', 'o')) or l1 == 'Los ogros no te ', l1

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    open(SALIDA, 'wb').write(rom)
    d2 = bytes(rom)
    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d2).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d2).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d2) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)
    print()
    print('  Capa: |%s|' % leido)
    print('  en pantalla, a 16 columnas:')
    print('        |%-16s|' % l1)
    print('        |%-16s|' % l2)


if __name__ == '__main__':
    main()
