#!/usr/bin/env python3
"""v397 - N4: el bocadillo del ABUELO baja 2 px (texto centrado).

Reescribe la cueva $FFC3 (v234) para que el desplazamiento del abuelo se
calcule a partir del que ya hay, en vez de ser una constante:

    resto ($368F != 2):  $10 = 8 (mitad baja) o 0     <- IGUAL QUE ANTES
    abuelo ($368F == 2): $10 = 6 (mitad baja) o 2     <- antes 4 y 0

Los dos renglones bajan 2 px. La constante #$04 de la v234 sólo movía el
renglón de la mitad baja; el otro se quedaba en 0 y el texto se descentraba.

NO se toca $9BBD (tabla COMPARTIDA: fue la regresión de la v396 en los
bocadillos de 3 filas, entrada 277 / norma 383).
"""
import hashlib, shutil, sys

BASE = "roms/Momotaro Katsugeki (Español).pce"   # = v396
SAL  = "roms/momotaro_es_v397.pce"
MD5_BASE = "4e073a4c466dac2c63cd151277a1d67f"

VIEJA = bytes.fromhex("6410" "ad6536" "2902" "f009"
                      "ad8f36" "c902" "f003" "b710" "60"
                      "a904" "8510" "60")
#  FFC3 STZ $10 / LDA $3665 / AND #$02 / BEQ $FFD5
#  FFCC LDA $368F / CMP #$02 / BEQ $FFD6 / SMB3 $10 / RTS
#  FFD6 LDA #$04 / STA $10 / RTS

NUEVA = bytes.fromhex(
    "6410"      # FFC3  STZ  $10
    "ad6536"    # FFC5  LDA  $3665      ; cuadrante
    "2902"      # FFC8  AND  #$02
    "f002"      # FFCA  BEQ  $FFCE
    "b710"      # FFCC  SMB3 $10        ; mitad baja -> $10 = 8
    "ad8f36"    # FFCE  LDA  $368F      ; identificador de bocadillo
    "c902"      # FFD1  CMP  #$02
    "d006"      # FFD3  BNE  $FFDB      ; no es el abuelo -> como siempre
    "4610"      # FFD5  LSR  $10        ; 8 -> 4 ; 0 -> 0   (la subida de la v234)
    "e610"      # FFD7  INC  $10        ; +1
    "e610"      # FFD9  INC  $10        ; +1  -> 6 y 2
    "60"        # FFDB  RTS
)

OFF = 0x1FC3
FIRMA = 0x1FE0

def main():
    d = bytearray(open(BASE, "rb").read())
    assert hashlib.md5(d).hexdigest() == MD5_BASE, "la base no es la v396"

    # 1. la cueva vieja está donde creo
    assert d[OFF:OFF + len(VIEJA)] == VIEJA, "la cueva $FFC3 no es la de la v234"

    # 2. el gancho sigue en su sitio: JSR $FFC3 + 8 NOP en $9D43
    assert d[0x41D43:0x41D4E] == bytes.fromhex("20c3ff" + "ea" * 8), "gancho $9D43 movido"

    # 3. no invadir la firma del cartucho (norma 371: el assert incluye el límite)
    fin = OFF + len(NUEVA)
    assert fin <= FIRMA, "la cueva pisa la firma"
    assert d[FIRMA:FIRMA + 9] == b"MOMOKATSU", "la firma no está donde creo"

    # 4. la cola que queda entre la cueva nueva y la firma se rellena a $FF
    d[OFF:FIRMA] = NUEVA + b"\xFF" * (FIRMA - fin)

    # 5. la tabla COMPARTIDA $9BBD queda intacta (la regresión de la v396)
    assert d[0x41BBD:0x41BFD] == bytes.fromhex(
        "3071307170717071b071b071f071f071"
        "3072307270727072b072b072f072f072"
        "3073307370737073b073b073f073f073"
        "3074307470747074b074b074f074f074"), "ojo: la tabla COMPARTIDA $9BBD ha cambiado"

    open(SAL, "wb").write(d)
    b = open(SAL, "rb").read()
    print("%s  %d B" % (SAL, len(b)))
    print("  MD5   ", hashlib.md5(b).hexdigest())
    print("  SHA-1 ", hashlib.sha1(b).hexdigest())
    print("  bytes distintos vs v396:",
          sum(1 for x, y in zip(open(BASE,'rb').read(), b) if x != y))

main()
