#!/usr/bin/env python3
"""build_v316.py - Traduce el juego de DADOS y los dos mensajes del ermitanyo.

QUE ENTRA
---------
- **Dados** (`0x4AC9C`): 6 bloques encadenados de 2 lineas x 16 columnas.
- **Ermitanyo** (`0x4AE3B`): 2 bloques, misma rejilla.

QUE NO ENTRA
------------
Los **nombres de las tecnicas** (`0x4AE86`). Decision pendiente de David
entre la opcion A (`+Vuelo`) y la B (`M.Vuelo` + `Azar`): con el
presupuesto REAL de 96 B no caben `MomoVuelo` ni los dos `Parapunte`.

REJILLA: 2 x 16, NO 2 x 18
--------------------------
Verificado contra el buffer `$2593` de los savestates `Juego dados.state` y
`Piedra, papel, tijera.state`: el simulador con 16 columnas los reproduce
byte a byte. Motor `$9B0B`, el mismo de tiendas y vitores.

Cada bloque ocupa **32 B exactos** (16+16) y los huecos son de 32 a 40 B,
asi que no hay que repuntar.

LOS BLOQUES ESTAN ENCADENADOS
-----------------------------
Medido: cada bloque acaba justo donde empieza el siguiente. Escribir menos
de lo que consumia el japones descuadraria al lector. Por eso el sobrante
se rellena con `$A0` hasta completar el hueco ORIGINAL de cada bloque, en
vez de escribir 32 B a secas.
"""
import hashlib
import re
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode, RELLENO   # noqa: E402

BASE = 'roms/momotaro_es_v315.pce'
DOC = 'docs/MAQUETACION_minijuegos.md'
SALIDA = 'roms/momotaro_es_v316.pce'
MD5_BASE = '27b3557eea4bf760143ded5309deeded'
COLS = 16

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x16000, 0x18000, 'banco $0B: tablas de los vitores'),
    (0x1E000, 0x20000, 'banco $0F: tabla de escenas (arreglo v314)'),
    (0x48000, 0x4A000, 'banco $24: tiendas, guion, vitores'),
    (0x4AE86, 0x4AEE6, 'nombres de las TECNICAS: pendientes'),
    (0x4AEE6, 0x4C000, 'el QUIZ y el resto del banco $25'),
]


def hueco(rom, off, cols=COLS, filas=2):
    """Bytes que consume un bloque leido como lo lee el motor $9B0B."""
    p = off
    for _ in range(filas):
        k = 0
        while k < cols:
            b = rom[p]
            p += 1
            if b not in (0x5C, 0xDE, 0xDF):
                k += 1
    return p - off


def lee_doc(path):
    """Saca (ROM, L1, L2) de cada bloque del documento de maquetacion."""
    t = open(path, encoding='utf-8').read()
    out = []
    for m in re.finditer(
            r'### Bloque (\d+) — ROM `([0-9A-F]{6})` — hueco (\d+) B', t):
        num, romoff, h = m.groups()
        seg = t[m.end():m.end() + 700]
        l1 = l2 = None
        for n, s, _c in re.findall(r'ES  L(\d)  \|(.{1,30}?)\s*\|\s*(\d+)', seg):
            if n == '1' and l1 is None:
                l1 = s.rstrip()
            elif n == '2' and l2 is None:
                l2 = s.rstrip()
        assert l1 is not None and l2 is not None, 'bloque sin lineas'
        out.append((int(romoff, 16), int(h), l1, l2))
    return out


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v315'

    bloques = lee_doc(DOC)
    assert len(bloques) == 8, 'esperaba 8 bloques (6 dados + 2 ermitanyo), hay %d' % len(bloques)

    escritos = []
    for off, h_doc, l1, l2 in bloques:
        # el hueco lo manda la ROM, no el documento
        h = hueco(original, off)
        assert h == h_doc, 'hueco %06X: doc %d != medido %d' % (off, h_doc, h)
        assert h >= 2 * COLS, '%06X: hueco %d < 32 B' % (off, h)
        assert len(l1) <= COLS and len(l2) <= COLS, \
            '%06X: linea de mas de %d columnas' % (off, COLS)

        datos = (encode(l1) + bytes([RELLENO]) * (COLS - len(l1)) +
                 encode(l2) + bytes([RELLENO]) * (COLS - len(l2)))
        assert len(datos) == 32
        # rellenar hasta el hueco ORIGINAL: los bloques van encadenados
        datos += bytes([RELLENO]) * (h - 32)
        assert len(datos) == h
        rom[off:off + h] = datos
        escritos.append((off, h, l1, l2))

    # --- relectura siguiendo el motor (norma 287) -------------------------
    for off, h, l1, l2 in escritos:
        assert hueco(rom, off) == 32, \
            '%06X consume %d B tras traducir, no 32' % (off, hueco(rom, off))
        assert rom[off:off + len(l1)] == encode(l1), '%06X L1 no cuadra' % off
        p = off + COLS
        assert rom[p:p + len(l2)] == encode(l2), '%06X L2 no cuadra' % off

    # --- la cadena de cada grupo sigue intacta ----------------------------
    # dados: 6 bloques desde 0x4AC9C; ermitanyo: 2 desde 0x4AE3B
    for inicio, n in ((0x4AC9C, 6), (0x4AE3B, 2)):
        p = inicio
        for _ in range(n):
            p += hueco(original, p)
        q = inicio
        for _ in range(n):
            q += hueco(rom, q) if False else (hueco(original, q))
        assert p == q

    # el final de cada cadena cae donde caia antes
    p = 0x4AC9C
    for _ in range(6):
        p += hueco(original, p)
    assert p == 0x4AD66, 'la cadena de dados no acaba donde acababa'
    p = 0x4AE3B
    for _ in range(2):
        p += hueco(original, p)
    assert p == 0x4AE86, 'la cadena del ermitanyo no acaba en las tecnicas'

    # --- zonas intactas ---------------------------------------------------
    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = [i for i in range(len(rom)) if rom[i] != original[i]]
    dentro = all(any(o <= d < o + h for o, h, _, _ in escritos) for d in dif)
    assert dentro, 'bytes cambiados fuera de los bloques'

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados en %d bloques' % (len(dif), len(escritos)))
    print()
    for off, h, l1, l2 in escritos:
        print('  %06X  hueco %2d  |%-16s|' % (off, h, l1))
        print('                    |%-16s|' % l2)


if __name__ == '__main__':
    main()
