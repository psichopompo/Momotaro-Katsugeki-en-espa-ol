#!/usr/bin/env python3
"""
build_v296.py - la «p» de las tiendas: los alias son OTROS en este motor.

DAVID LO VIO
============
*«pone Es©ada en lugar de Espada. Y también Dis©ara. Siempre es la p.»*

DOS MOTORES, DOS CODIFICACIONES
===============================
El juego decodifica el texto de forma distinta segun quien lo pinte:

```
motor MENU   ($AAB4)  tabla de sustitucion $AB34  ->  tabla $43F9B
motor TIENDA ($9B0B)  SBC #$20 (una o dos veces)  ->  tabla $9C73
```

Los alias `b`/`c`/`p` = `$5B`/`$5D`/`$5E` funcionan en el MENU porque pasan
por la tabla de sustitucion. En la TIENDA esa tabla **no existe**: el codigo
va directo a `$9C73` y los tres caen en el glifo `$8B`, que es una **©**.

Barrido de los 90 caracteres del charset comparando ambos motores:
**solo 4 discrepan**, y son justo los alias:

```
'b' $5B   menu -> $A2    tienda -> $8B  (©)
'c' $5D   menu -> $A3    tienda -> $8B
'p' $5E   menu -> $B0    tienda -> $8B
'Ç' $5F   menu -> $DE    tienda -> $8B
```

EL ARREGLO
==========
En el motor de tienda hay que usar los codigos **directos**, justo lo
contrario que en el menu:

```
'b' -> $A2      'c' -> $A3      'p' -> $B0      'Ç' -> $DE
```

56 bytes en el bloque de tiendas (25 en dialogos, 31 en descripciones).

NOTA para el futuro: `charset_oficial.encode()` sirve para el MENU. Para
textos que pinte `$9B0B` hay que pasar por `a_tienda()`.
"""
import hashlib, zlib

BASE='roms/momotaro_es_v295.pce'; SALIDA='roms/momotaro_es_v296.pce'
IPS='parches/momotaro_v296.ips'; VIRGEN='roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE='8fb4a20ccb1f2a35a2f02c4530bda43e'

ALIAS={0x5B:0xA2, 0x5D:0xA3, 0x5E:0xB0, 0x5F:0xDE}
ZONAS=[(0x484C0,0x488A1,'dialogos'),(0x488A1,0x48BA0,'descripciones')]

def main():
    rom=bytearray(open(BASE,'rb').read()); orig=open(VIRGEN,'rb').read()
    base=bytes(rom)
    assert hashlib.md5(rom).hexdigest()==MD5_BASE,'la base no es la v295'
    print('base %s  OK'%BASE)

    ORI=rom[0x42B4C:0x42B53]; DES=rom[0x42B54:0x42B5B]
    def g_menu(c):
        if c in ORI: c=DES[list(ORI).index(c)]
        if 0x30<=c and (c-0x30)<0x54: return rom[0x43F9B+c-0x30]
        return rom[0x41C73+c-0x20]
    def g_tienda(c):
        if c>=0xA0: return c
        return rom[0x41C73+(c-0x40 if c>=0x60 else c-0x20)]

    # --- 1. el diagnostico, reproducido ---------------------------------
    print('\n--- los dos motores, comparados sobre el charset entero')
    import sys; sys.path.insert(0,'tools')
    from charset_oficial import CHAR_TO_CODE
    disc=[(ch,c) for ch,c in CHAR_TO_CODE.items() if g_menu(c)!=g_tienda(c)]
    assert len(disc)==4, 'se esperaban 4 discrepancias, hay %d'%len(disc)
    for ch,c in sorted(disc,key=lambda x:x[1]):
        print('    %r $%02X  menu->$%02X  tienda->$%02X'%(ch,c,g_menu(c),g_tienda(c)))

    # --- 2. cada alias nuevo da EL MISMO glifo que en el menu -----------
    print('\n--- los alias de tienda, verificados')
    for viejo,nuevo in sorted(ALIAS.items()):
        assert g_tienda(nuevo)==g_menu(viejo), \
            '$%02X en tienda da $%02X, el menu da $%02X'%(nuevo,g_tienda(nuevo),g_menu(viejo))
        print('    $%02X -> $%02X   glifo $%02X en ambos motores  OK'
              %(viejo,nuevo,g_tienda(nuevo)))

    # --- 3. el reemplazo -------------------------------------------------
    print('\n--- reemplazo')
    tot=0
    for a,b,nom in ZONAS:
        n=0
        for i in range(a,b):
            if rom[i] in ALIAS:
                rom[i]=ALIAS[rom[i]]; n+=1
        print('    %-14s %d bytes'%(nom,n)); tot+=n
    assert tot==56, 'se esperaban 56 cambios, hay %d'%tot

    # --- 4. no queda ningun alias de menu en la zona de tienda ----------
    for a,b,nom in ZONAS:
        resto=[i for i in range(a,b) if rom[i] in ALIAS]
        assert not resto, 'quedan alias en %s'%nom
    print('    no queda ningun $5B/$5D/$5E/$5F en el bloque de tiendas  OK')

    # --- 5. relectura: como lo vera el motor -----------------------------
    G2C={}
    for ch,c in CHAR_TO_CODE.items():
        G2C.setdefault(g_menu(c),ch)
    def leer(o,n):
        return ''.join(G2C.get(g_tienda(x),'.') if x!=0xA0 else ' '
                       for x in rom[o:o+n])
    print('\n--- releido con el motor de TIENDA')
    for o,nom in ((0x48AEA,'Espada Byakko'),(0x48B0E,'Espada Hiryu'),
                  (0x484C0,'dialogo 1')):
        print('    0x%05X |%s|'%(o,leer(o,20)))
        print('             |%s|'%leer(o+20,20))

    intactas=[('tabla $C929',0x10929,0x10989),
              ('menu de Game Over',0x1F9D5,0x1FA00),
              ('menu RUN banco $0C',0x197F0,0x19810),
              ('menu RUN banco $21',0x431AC,0x431EB),
              ('parrilla',0x1BBBA,0x1BC00),
              ('canto Game Over',0x1F7B6,0x1F836),
              ('fuente',0x3D660,0x3E200)]
    for nom,a,b in intactas:
        assert bytes(rom[a:b])==base[a:b],'se ha tocado %s'%nom
    print('\nintactas: %s'%', '.join(n for n,_,_ in intactas))

    d=bytes(rom); open(SALIDA,'wb').write(d)
    print('%d bytes sobre la v295'%sum(1 for i in range(len(d)) if d[i]!=base[i]))

    difv=[i for i in range(len(d)) if d[i]!=orig[i]]
    rec=[];i=0
    while i<len(difv):
        s=difv[i];j=i
        while j+1<len(difv) and difv[j+1]<=difv[j]+8: j+=1
        e=difv[j]+1
        rec.append(bytes([s>>16&0xFF,s>>8&0xFF,s&0xFF,(e-s)>>8,(e-s)&0xFF])+d[s:e])
        i=j+1
    p=b'PATCH'+b''.join(rec)+b'EOF'; open(IPS,'wb').write(p)
    t=bytearray(orig); q=5
    while p[q:q+3]!=b'EOF':
        o2=p[q]<<16|p[q+1]<<8|p[q+2]; n2=p[q+3]<<8|p[q+4]
        t[o2:o2+n2]=p[q+5:q+5+n2]; q+=5+n2
    assert bytes(t)==d,'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)'%len(p))
    print('\n%s\n  MD5    %s\n  CRC32  %08X'%(SALIDA,
        hashlib.md5(d).hexdigest(),zlib.crc32(d)&0xFFFFFFFF))

main()
