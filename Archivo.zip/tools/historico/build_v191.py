#!/usr/bin/env python3
"""
build_v191.py - los tres ajustes finos que mide David sobre la v190.

LO QUE PIDE
-----------
> - Hay que desplazarlo 8 px a la izquierda. De este modo, medira 80 px a
>   ambos lados del centro, y quedara perfectamente centrado con los
>   aldeanos y los Jizo.
> - Tambien hay que bajarlo 4 px para que encaje bien con el nuevo rabillo,
>   que es mas corto.
> - El rabillo hay que desplazarlo 25 px a la izquierda para estar alineado
>   con el bocadillo.

COMO SE APLICA CADA UNO
-----------------------

**1. Los 8 px del cuerpo: se mueve el ANCLA, no la lista.**

La lista de sprites es simetrica respecto al ancla (`dX` de -80 al trazo
derecho en +79). Si moviera la lista, dejaria de serlo y el bocadillo ya no
mediria «80 px a ambos lados del centro», que es justo lo que pide David.
Moviendo el ancla se conserva la simetria:

```
tabla $C825 (ROM 0x16825):  +8  ->  0     en las dos entradas
```

Con `0`, el ancla es exactamente la X del aldeano.

**2. Los 4 px de bajada: solo el CUERPO.**

El rabillo nuevo es mas corto (su punta acaba en la fila 8, la cuna vieja
llegaba a la 6), asi que el cuerpo baja y el rabillo se queda. `dY += 4` en
los 42 sprites de la lista; la tabla `$9ADD` no se toca en Y.

**3. Los 25 px del rabillo: OJO, 8 ya vienen del ancla.**

El rabillo **comparte el ancla con el cuerpo** (los emite la misma rutina
`$9A78`, con el mismo `$368B`). Al mover el ancla -8, el rabillo se mueve
-8 tambien. Para que el desplazamiento total sea -25 hay que restar **17**
a su `dX`, no 25.

```
variante 0 (abajo-der):  dX  24 -> 7
variante 1 (abajo-izq):  dX   8 -> -9
variante 3 (abajo):      dX  24 -> 7
variante 2:              NO SE TOCA  (celda 1AF, el lateral del abuelo)
```

**SUPOSICION QUE HAY QUE CONFIRMAR:** interpreto que los 25 px estan
medidos sobre la pantalla de la v190, o sea sobre la posicion actual del
rabillo. Si David los midio pensando «ademas de mover el bocadillo», serian
25 en el `dX` y no 17. Se ve a simple vista: si el rabillo queda 8 px a la
derecha de su sitio, es lo segundo.

EL JIZO
-------
David: «el alineamiento si afecta al Jizo, pero eso no creo que sea un
problema». Confirmado: el Jizo entra por la misma ruta `$8800` que los
aldeanos, asi que se centra igual. El que NO cambia es el bocadillo del
abuelo (`$88AD`, variante 2 del rabillo).

Uso:  python3 tools/build_v191.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v190.pce'
SALIDA = 'roms/momotaro_es_v191.pce'
IPS = 'parches/momotaro_v191.ips'
MD5_BASE = '460cf8695d55a1c74c8594607a3352fc'

TABLA = 0x16825          # $C825, desplazamiento del ancla
LISTA = 0x47C02          # lista de sprites del cuerpo
RABILLO = 0x41ADD        # tabla de 4 variantes

DESP_ANCLA = 0           # antes +8: el bocadillo se va 8 px a la izquierda
BAJA = 4                 # el cuerpo baja 4 px
RAB_DX = -17             # -25 en total, porque el ancla ya aporta -8


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v190 (md5 %s)' % md5
    orig = bytes(rom)

    # ==================================================================
    # 1. el ancla: +8 -> 0  (los 8 px a la izquierda)
    # ==================================================================
    assert bytes(rom[TABLA:TABLA + 4]) == bytes([0x08, 0x00, 0x08, 0x00]), \
        'la tabla $C825 no es la de la v190: %s' % bytes(
            rom[TABLA:TABLA + 4]).hex()
    for k, nom in ((0, 'rabillo dcha'), (1, 'rabillo izda')):
        rom[TABLA + k * 2] = DESP_ANCLA & 0xFF
        rom[TABLA + k * 2 + 1] = 0x00
    print('ancla ($C825): +8 -> %+d   (el bocadillo entero, 8 px a la izq)'
          % DESP_ANCLA)

    # ==================================================================
    # 2. el cuerpo baja 4 px
    # ==================================================================
    i = LISTA
    n = 0
    ys_antes = set()
    while rom[i] != 0xFF:
        dy = rom[i + 4]
        sdy = dy - 256 if dy > 127 else dy
        ys_antes.add(sdy)
        nuevo = sdy + BAJA
        assert -128 <= nuevo <= 127, 'dY fuera de rango: %d' % nuevo
        rom[i + 4] = nuevo & 0xFF
        i += 5
        n += 1
    assert n == 42, 'la lista tiene %d sprites, esperaba 42' % n
    print('cuerpo: %d sprites, dY %s -> %s  (baja %d px)'
          % (n, sorted(ys_antes), sorted(y + BAJA for y in ys_antes), BAJA))

    # el marco no puede salirse del rango de un byte con signo
    ys = []
    i = LISTA
    while rom[i] != 0xFF:
        dy = rom[i + 4]
        ys.append(dy - 256 if dy > 127 else dy)
        i += 5
    assert max(ys) <= 127 and min(ys) >= -128

    # ==================================================================
    # 3. el rabillo, 17 px mas a la izquierda (25 con el ancla)
    # ==================================================================
    tocadas = 0
    for v in range(4):
        p = rom[RABILLO + v * 2] | (rom[RABILLO + v * 2 + 1] << 8)
        off = 0x40000 + (p - 0x8000)
        b0 = rom[off]
        celda = 0x170 + b0
        dx = rom[off + 3]
        sdx = dx - 256 if dx > 127 else dx
        if celda == 0x1AF:
            print('  variante %d: celda %03X (lateral del abuelo) INTACTA'
                  % (v, celda))
            continue
        assert celda == 0x1AD, 'la variante %d apunta a %03X' % (v, celda)
        nuevo = sdx + RAB_DX
        assert -128 <= nuevo <= 127, 'dX del rabillo fuera de rango: %d' % nuevo
        rom[off + 3] = nuevo & 0xFF
        print('  variante %d: celda %03X  dX %+d -> %+d   (total %+d con el '
              'ancla)' % (v, celda, sdx, nuevo, RAB_DX - 8))
        tocadas += 1
    assert tocadas == 3, 'se han tocado %d variantes, esperaba 3' % tocadas

    # la Y del rabillo NO cambia: el cuerpo baja hacia el
    for v in range(4):
        p = orig[RABILLO + v * 2] | (orig[RABILLO + v * 2 + 1] << 8)
        off = 0x40000 + (p - 0x8000)
        assert rom[off + 4] == orig[off + 4], \
            'se ha movido la Y de la variante %d' % v
    print('  la Y del rabillo no se toca: es el cuerpo el que baja')

    # ==================================================================
    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('CG del bocadillo', 0x3D401, 0x3D660),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('bitmaps de la flecha', 0x41A47, 0x41A65),
        ('cargador del CG', 0x41AAE, 0x41ACD),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    print('%d bytes modificados' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        of = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        ln = raw[p + 3] << 8 | raw[p + 4]
        prueba[of:of + ln] = raw[p + 5:p + 5 + ln]
        p += 5 + ln
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B, %d registros)' % (len(raw), len(rec)))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('SI EL RABILLO QUEDA 8 px A LA DERECHA DE SU SITIO')
    print('  entonces los 25 px eran ADEMAS del movimiento del cuerpo:')
    print('  cambiar RAB_DX de -17 a -25 y reconstruir.')


if __name__ == '__main__':
    main()
