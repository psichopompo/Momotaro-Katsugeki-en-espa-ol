#!/usr/bin/env python3
"""build_v392.py - Traduce el minijuego de piedra, papel o tijeras.

QUÉ SE HACE
-----------
1. El motor pasa de 2 a 3 líneas (un byte).
2. El mensaje A se mueve a un hueco libre para que quepa la frase entera.
3. Los dos mensajes quedan traducidos, con «¡Mira allá!» completo.

    A) «¡Piedra, papel / o tijeras! / ¡Mira allá!»
    B) «¡Iguales! / ¡Mira allá!»

«¡Iguales!» y no «¡Empate!» por decisión de David: el mensaje sale cuando
ambos sacan lo mismo, o sea una tirada nula, no un empate de la partida.

LO QUE COSTÓ ENCONTRAR (entrada 258)
------------------------------------
El primer intento de repunte falló porque cambié la tabla `$D2BB`
(ROM 0x1B2BB), que es de OTRO conjunto de mensajes. Los punteros reales del
minijuego están escritos como inmediatos dentro del código, en el banco $08:

    $DD1B  LDA #$08 / STA $BF ; LDA #$79 / STA $C0   -> $7908  (mensaje A)
    $DD26  LDA #$23 / STA $BF ; LDA #$79 / STA $C0   -> $7923  (mensaje B)

Es decir: **cada mensaje tiene su propio puntero y se pueden mover por
separado**. Eso es lo que da el espacio.

EL REPARTO
----------
    A (38 B) -> 0x4B826, hueco de 55 B entre dos mensajes (sobran 17)
    B (22 B) -> 0x4B908, donde estaba (52 B, sobran 30)

El hueco de 0x4B826 son $A0 muertos tras el $00 que cierra el mensaje
anterior. Verificado que **nadie apunta dentro**: las únicas cargas de
puntero cercanas son $780E y $785D, que quedan fuera.

ANCHO: 14 columnas por línea, medido en pantalla.
CHARSET: `charset_oficial` (la `p` es $5E; con $B0 salía «ÇaÇel»).
CONTROLES: $00 pausa · $80 fin de línea · $FF fin de mensaje.
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
import charset_oficial as co

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v391
DST = 'roms/momotaro_es_v392.pce'

LINEAS = 0x106E3          # LDX #$02 -> #$03
A_DEST, A_TOPE = 0x4B826, 0x4B85D     # hueco de 55 B
B_DEST, B_TOPE = 0x4B908, 0x4B93C     # donde estaba A+B (52 B)
PA_LO, PA_HI = 0x11D1C, 0x11D20       # puntero del mensaje A
PB_LO, PB_HI = 0x11D27, 0x11D2B       # puntero del mensaje B
ANCHO = 14


def e(s):
    out = bytearray()
    for c in s:
        if c not in co.CHAR_TO_CODE:
            raise ValueError('carácter sin código: %r' % c)
        out.append(co.CHAR_TO_CODE[c])
    return bytes(out)


def monta(lineas):
    """lineas -> bytes, con $80 entre ellas y $FF al final."""
    out = b''
    for i, l in enumerate(lineas):
        assert len(l) <= ANCHO, 'línea de %d columnas: %r' % (len(l), l)
        out += e(l) + bytes([0xFF if i == len(lineas) - 1 else 0x80])
    return out


rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)

# ---- 0. el estado de partida es el que creo -------------------------------
assert rom[LINEAS] == 0x02, 'en 0x%05X no hay un LDX #$02' % LINEAS
assert rom[PA_LO] == 0x08 and rom[PA_HI] == 0x79, 'el puntero A no es $7908'
assert rom[0x11D27] == 0x23 and rom[0x11D2B] == 0x79, 'el puntero B no es $7923'
# el hueco de destino está libre de verdad
assert all(b == 0xA0 for b in rom[A_DEST:A_TOPE]), 'el hueco 0x4B826 no está limpio'
assert rom[A_DEST - 1] == 0x00, 'antes del hueco no hay un terminador'
# y el mensaje que va detrás sigue en su sitio
vecino = bytes(rom[A_TOPE:A_TOPE + 16])

A = monta(['¡Piedra, papel', 'o tijeras!', '¡Mira allá!'])
B = monta(['¡Iguales!', '¡Mira allá!'])

assert len(A) <= A_TOPE - A_DEST, 'A: %d B, caben %d' % (len(A), A_TOPE - A_DEST)
assert len(B) <= B_TOPE - B_DEST, 'B: %d B, caben %d' % (len(B), B_TOPE - B_DEST)

# ---- 1. tres líneas -------------------------------------------------------
rom[LINEAS] = 0x03

# ---- 2. el mensaje A al hueco, y su puntero -------------------------------
rom[A_DEST:A_TOPE] = A + bytes([0xA0]) * (A_TOPE - A_DEST - len(A))
rom[PA_LO] = A_DEST & 0xFF          # $26
rom[PA_HI] = 0x60 + ((A_DEST >> 8) & 0x1F)   # $78  (CPU $7826)
assert rom[PA_LO] == 0x26 and rom[PA_HI] == 0x78, 'el puntero A no quedó en $7826'

# ---- 3. el mensaje B, al principio del bloque que deja libre A ------------
# OJO: el puntero B apuntaba a $7923 (ROM 0x4B923), que sólo tiene 25 B hasta
# el código. Escribirlo en 0x4B908 sin repuntar dejaba el texto 27 bytes antes
# de donde el juego lo lee: salía basura. Se repunta a $7908.
rom[B_DEST:B_TOPE] = B + bytes([0xA0]) * (B_TOPE - B_DEST - len(B))
rom[PB_LO] = B_DEST & 0xFF                      # $08
rom[PB_HI] = 0x60 + ((B_DEST >> 8) & 0x1F)      # $79  (CPU $7908)
assert rom[PB_LO] == 0x08 and rom[PB_HI] == 0x79, 'el puntero B no quedó en $7908'

# ---- 4. nada ajeno se ha tocado -------------------------------------------
assert bytes(rom[A_TOPE:A_TOPE + 16]) == vecino, 'se ha pisado el mensaje vecino'
assert bytes(rom[0x4B93C:0x4B960]) == orig[0x4B93C:0x4B960], 'se ha pisado el código'
tocado = (set(range(A_DEST, A_TOPE)) | set(range(B_DEST, B_TOPE))
          | {LINEAS, PA_LO, PA_HI, PB_LO, PB_HI})
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos <= tocado, sorted(distintos - tocado)[:8]

# ---- 5. NORMA 370: leer el texto DESDE el puntero, no desde donde escribí --
def texto_en(lo, hi):
    cpu = rom[lo] | rom[hi] << 8
    off = 0x25 * 0x2000 + (cpu & 0x1FFF)
    fin = off
    while rom[fin] != 0xFF:
        fin += 1
    return bytes(rom[off:fin + 1])

assert texto_en(PA_LO, PA_HI) == A, 'el puntero A no lee el mensaje A'
assert texto_en(PB_LO, PB_HI) == B, 'el puntero B no lee el mensaje B'

open(DST, 'wb').write(bytes(rom))
print('%s  %d B' % (DST, len(rom)))
print('  0x%05X  LDX #$02 -> #$03   (tres líneas)' % LINEAS)
print('  A 0x%05X (%2d/%d B)  «¡Piedra, papel» / «o tijeras!» / «¡Mira allá!»'
      % (A_DEST, len(A), A_TOPE - A_DEST))
print('  B 0x%05X (%2d/%d B)  «¡Iguales!» / «¡Mira allá!»'
      % (B_DEST, len(B), B_TOPE - B_DEST))
print('  puntero A: $7908 -> $7826   puntero B: $7923 -> $7908')
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
