#!/usr/bin/env python3
"""build_v315.py - Traduce los VITORES (pancarta de fin de fase).

QUE ENTRA
---------
Los **19 bloques con puntero propio** en la tabla `$C433` (ROM `0x16433`).
Cada uno son 2 lineas x 18 columnas = **36 bytes exactos**, y el hueco mas
pequenyo es de 37 B, asi que NO hay que repuntar nada.

QUE NO ENTRA, Y POR QUE
-----------------------
Los **4 bloques huerfanos** (`$40E8 $4112 $4139 $4163`). Medido: forman una
CADENA secuencial exacta — cada uno acaba justo donde empieza el siguiente,
y el cuarto aterriza en `$418A`, que es el bloque 0 de la tabla:

    0x480E8 +42-> 0x48112 +39-> 0x48139 +42-> 0x48163 +39-> 0x4818A

El japones consume 42/39/42/39 B (los dakuten `$DE/$DF` no gastan columna);
el texto latino gasta 36 B clavados. Si escribo 36, un lector encadenado
aterriza descuadrado y lee basura desde el segundo bloque.

El sobrante se podria absorber con pares de `$5C` (conmutar y reconmutar el
juego de glifos no tiene efecto visual ni gasta columna), pero solo funciona
con sobrantes PARES: 6 y 6 si, 3 y 3 no — un `$5C` suelto dejaria `$3666`
invertido y el bloque siguiente saldria con los glifos cambiados.

Y sobre todo: **no se sabe quien lee esos 4 bloques**. No concluir «no lo
usa nadie» a partir de «no he encontrado quien lo use» (el error de la
v217). Se dejan en japones hasta identificar al lector.

EL TEXTO NO VA AQUI DENTRO
--------------------------
Se lee de `docs/MAQUETACION_vitores.md`, que es el documento que David
revisa y aprueba. El constructor no decide redaccion.
"""
import hashlib
import re
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode, linea, RELLENO   # noqa: E402
import vitores                                        # noqa: E402

BASE = 'roms/momotaro_es_v314.pce'
DOC = 'docs/MAQUETACION_vitores.md'
SALIDA = 'roms/momotaro_es_v315.pce'

MD5_BASE = 'd3ee96488f99aa2cc4abe9d0a4ebb2f3'
COLS = 18

# Zonas que no se pueden tocar
INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x16000, 0x18000, 'banco $0B: tablas $C433/$C459 de los vitores'),
    (0x1E000, 0x20000, 'banco $0F: tabla de escenas (el arreglo de la v314)'),
    (0x48000, 0x480E8, 'subtabla del guion de aldeanos'),
    (0x480E8, 0x4818A, 'los 4 bloques huerfanos, en japones'),
    (0x48480, 0x4A000, 'tiendas y resto del banco $24'),
    (0x4A000, 0x4C000, 'banco $25: creditos, quiz'),
]


def lee_maquetacion(path):
    """Saca (ptr, L1, L2) de cada bloque de la tabla. Ignora los huerfanos."""
    t = open(path, encoding='utf-8').read()
    out = []
    for m in re.finditer(
            r'### Bloque (\d+) — `\$([0-9A-F]{4})` \(ROM `([0-9A-F]{6})`\)'
            r' — hueco (\d+) B', t):
        num, ptr, romoff, hueco = m.groups()
        seg = t[m.end():m.end() + 900]
        l1 = l2 = None
        for n, s, _c in re.findall(r'ES  L(\d)  \|(.{1,30}?)\s*\|\s*(\d+)', seg):
            if n == '1' and l1 is None:
                l1 = s.rstrip()
            elif n == '2' and l2 is None:
                l2 = s.rstrip()
        assert l1 is not None and l2 is not None, 'bloque %s sin lineas' % num
        out.append((int(num), int(ptr, 16), int(romoff, 16), int(hueco), l1, l2))
    return out


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v314'

    bloques = lee_maquetacion(DOC)
    assert len(bloques) == 19, 'esperaba 19 bloques, hay %d' % len(bloques)

    # --- la tabla de la ROM manda, no el documento -----------------------
    ptrs = vitores.punteros(rom)
    offs = vitores.offsets(rom)

    escritos = []
    for i, (num, ptr, romoff, hueco, l1, l2) in enumerate(bloques):
        assert num == i, 'bloques desordenados en el documento'
        assert ptr == ptrs[i], \
            'bloque %d: el doc dice $%04X, la ROM $%04X' % (i, ptr, ptrs[i])
        assert romoff == offs[i], 'bloque %d: offset ROM no coincide' % i

        # hueco real medido con el motor, no el del documento
        real = vitores.longitud(original, romoff)
        assert real == hueco, \
            'bloque %d: hueco doc %d != medido %d' % (i, hueco, real)
        assert real >= 2 * COLS, \
            'bloque %d: hueco %d < 36 B' % (i, real)

        datos = linea(l1, COLS) + linea(l2, COLS)
        assert len(datos) == 36
        rom[romoff:romoff + 36] = datos
        escritos.append((i, romoff, real, l1, l2))

    # --- VERIFICACION: releer siguiendo el puntero, como el motor --------
    for i, (num, ptr, romoff, hueco, l1, l2) in enumerate(bloques):
        p = ptrs[i]
        off = 0x48000 + p - 0x4000
        assert off == romoff
        _buf, fin = vitores.render(rom, off)
        consumido = fin - off
        assert consumido == 36, \
            'bloque %d consume %d B, no 36' % (i, consumido)
        # y que el texto releido sea el del documento
        leido1 = rom[off:off + COLS]
        leido2 = rom[off + COLS:off + 36]
        assert leido1 == linea(l1, COLS), 'bloque %d L1 no cuadra' % i
        assert leido2 == linea(l2, COLS), 'bloque %d L2 no cuadra' % i

    # --- ningun bloque pisa al siguiente ---------------------------------
    for i in range(18):
        fin = offs[i] + 36
        assert fin <= offs[i + 1], \
            'bloque %d (%06X+36) pisa al %d (%06X)' % (i, offs[i], i + 1, offs[i + 1])
    assert offs[18] + 36 <= 0x48480, 'el bloque 18 se sale de la zona'

    # --- la cola de cada hueco queda como estaba (relleno del japones) ---
    # solo se comprueba que no hemos escrito fuera de los 36 B
    for i in range(19):
        a, b = offs[i] + 36, offs[i] + vitores.longitud(original, offs[i])
        assert rom[a:b] == original[a:b], 'bloque %d: escrito fuera de los 36 B' % i

    # --- zonas intactas ---------------------------------------------------
    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    # --- las tablas de los vitores, sin mover -----------------------------
    assert rom[0x16433:0x16433 + 38] == original[0x16433:0x16433 + 38]
    assert rom[0x16459:0x16459 + 28] == original[0x16459:0x16459 + 28]

    # --- cuenta de bytes --------------------------------------------------
    dif = [i for i in range(len(rom)) if rom[i] != original[i]]
    dentro = all(any(o <= d < o + 36 for o in offs) for d in dif)
    assert dentro, 'hay bytes cambiados fuera de los 19 bloques'

    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados, todos dentro de los 19 bloques' % len(dif))
    print()
    for i, off, hueco, l1, l2 in escritos:
        print('  %2d  %06X  hueco %2d  |%-18s|' % (i, off, hueco, l1))
        print('                        |%-18s|' % l2)


if __name__ == '__main__':
    main()
