#!/usr/bin/env python3
"""
build_v188.py - arregla el DESBORDAMIENTO DEL BUFFER de la v187.

EL FALLO (mio, y de bulto)
--------------------------
David ve tres cosas:

  1. cuatro lineas, «aunque parecen dos bloques repetidos»
  2. de repente el bocadillo salta ~177 px a la derecha
  3. al hablar con los aldeanos no sale ni bocadillo ni texto

**Son el mismo fallo.** El indice de celda que puse en la v184 es
`linea*16 + columna`, y el buffer solo tiene 36 bytes:

```
linea 0 -> indices  0..15   $3667..$3676   OK
linea 1 -> indices 16..31   $3677..$3686   OK
linea 2 -> indices 32..47   $3687..$3696   SE SALE
linea 3 -> indices 48..63   $3697..$36A6   SE SALE
```

Y lo que hay justo detras del buffer es:

```
$368B (indice 36) coordenada X baja del bocadillo
$368C (indice 37) coordenada X alta
$368D (indice 38) coordenada Y baja
$368E (indice 39) coordenada Y alta
$368F (indice 40) variante del rabillo
$3690 (indice 41) interruptor de dakuten
```

O sea que **las lineas 3 y 4 escriben el texto encima de las coordenadas
del bocadillo**. De ahi el salto de 177 px (un codigo de letra metido en la
X) y de ahi que al siguiente aldeano no salga nada: las coordenadas quedan
corruptas de la conversacion anterior.

Y los «dos bloques repetidos»: al acabar la linea 4 se vuelca otra vez
`X = 0..31`, que sigue conteniendo **las lineas 1 y 2**, porque las lineas
3 y 4 se escribieron fuera. La fila B repite la fila A.

Lo grave es que la norma 126 —que escribi yo en la v184— dice exactamente
esto: *«un contador de bucle no se cambia por simetria: se SIMULA el bucle y
se comprueba que el indice no se sale del buffer»*. La aplique al clon
`$9952` y **no al motor principal**, que es donde estaba el problema.

EL ARREGLO
----------
El buffer solo tiene que guardar **media pagina** (2 lineas x 16 = 32), no
las cuatro. El indice pasa de `linea*16` a `(linea AND 1)*16`:

```
linea 0 -> 0..15     linea 2 -> 0..15
linea 1 -> 16..31    linea 3 -> 16..31
```

Las lineas 3-4 reutilizan el mismo buffer, que es justo lo que permite el
volcado por mitades de la v187: cuando se escriben, la fila A ya esta en
VRAM.

```
antes:  AD 57 36  0A 0A 0A 0A  18  6D 58 36        (11 B + 6 NOP)
ahora:  AD 57 36  29 01  0A 0A 0A 0A  18  6D 58 36 (13 B + 4 NOP)
```

Y hay que **limpiar el buffer entre las dos mitades**: si la linea 3 es mas
corta que la 1, quedarian restos de la primera mitad. Se anade un
`JSR $9C29` (el limpiador que ya existe) en `volcar_y_restaurar`, DESPUES
de volcar.

Uso:  python3 tools/build_v188.py
"""
import hashlib
import zlib

BASE = 'roms/momotaro_es_v187.pce'
SALIDA = 'roms/momotaro_es_v188.pce'
IPS = 'parches/momotaro_v188.ips'
MD5_BASE = '19e079a20feb5977ce850fc865245fa5'

IDX = 0x41863           # $9863, el indice de celda
VOL = 0x41ACD           # $9ACD, volcar_y_restaurar
COLS = 16
BUFFER = 36


def main():
    rom = bytearray(open(BASE, 'rb').read())
    md5 = hashlib.md5(rom).hexdigest()
    assert md5 == MD5_BASE, 'la base no es la v187 (md5 %s)' % md5
    orig = bytes(rom)

    # ------------------------------------------------------------------
    # 1. el indice: linea*16 -> (linea AND 1)*16
    # ------------------------------------------------------------------
    esperado = bytes([0xAD, 0x57, 0x36,          # LDA $3657
                      0x0A, 0x0A, 0x0A, 0x0A,    # ASL x4
                      0x18, 0x6D, 0x58, 0x36])   # CLC / ADC $3658
    assert bytes(rom[IDX:IDX + 11]) == esperado, \
        'el indice no es el de la v187: %s' % bytes(rom[IDX:IDX + 11]).hex()
    assert bytes(rom[IDX + 11:IDX + 17]) == b'\xEA' * 6, \
        'no hay 6 NOP detras del indice'

    nuevo = bytes([0xAD, 0x57, 0x36,             # LDA $3657
                   0x29, 0x01,                   # AND #$01   <- media pagina
                   0x0A, 0x0A, 0x0A, 0x0A,       # ASL x4
                   0x18, 0x6D, 0x58, 0x36])      # CLC / ADC $3658
    nuevo += b'\xEA' * (17 - len(nuevo))
    rom[IDX:IDX + 17] = nuevo
    print('indice $9863: linea*16 -> (linea AND 1)*16   (%d B + %d NOP)'
          % (13, 17 - 13))

    # simular las cuatro lineas y comprobar que NO se sale (norma 126)
    peor = -1
    for linea in range(4):
        for col in range(COLS):
            idx = (linea & 1) * 16 + col
            peor = max(peor, idx)
            assert idx < BUFFER, \
                'linea %d col %d -> indice %d, fuera del buffer de %d' % (
                    linea, col, idx, BUFFER)
    print('  simuladas las 4 lineas: indice maximo %d de %d  OK'
          % (peor, BUFFER - 1))
    for l in range(4):
        print('    linea %d -> %2d..%2d' % (l, (l & 1) * 16,
                                            (l & 1) * 16 + COLS - 1))

    # ------------------------------------------------------------------
    # 2. limpiar el buffer tras volcar la primera mitad
    # ------------------------------------------------------------------
    # Si la linea 3 es mas corta que la 1, en el buffer quedarian restos de
    # la primera mitad y se pintarian en la fila B.
    esp_vol = bytes([0x20, 0x7C, 0x9B,           # JSR $9B7C
                     0xA9, 0x24, 0x18, 0x65, 0x20, 0x53, 0x04,  # rehace MPR2
                     0x60])                      # RTS
    assert bytes(rom[VOL:VOL + 11]) == esp_vol, \
        'volcar_y_restaurar no es el de la v187: %s' % bytes(
            rom[VOL:VOL + 11]).hex()
    # el limpiador $9C29 existe y es el que creo
    assert bytes(rom[0x41C29:0x41C32]) == bytes(
        [0xA2, 0x23, 0x9E, 0x67, 0x36, 0xCA, 0x10, 0xFA, 0x60]), \
        'el limpiador $9C29 no es el esperado'

    vol = bytes([0x20, 0x7C, 0x9B,               # JSR $9B7C     vuelca fila A
                 0x20, 0x29, 0x9C,               # JSR $9C29     limpia buffer
                 0xA9, 0x24, 0x18, 0x65, 0x20,   # LDA #$24/CLC/ADC $20
                 0x53, 0x04,                     # TAM #$04      rehace MPR2
                 0x60])                          # RTS
    assert len(vol) <= 16, 'volcar_y_restaurar mide %d B y hay 16' % len(vol)
    rom[VOL:VOL + len(vol)] = vol
    print('volcar_y_restaurar $9ACD (%d B): JSR $9B7C / JSR $9C29 / rehace MPR2'
          % len(vol))
    print('  el JSR $9C29 borra el buffer entre las dos mitades')

    # OJO: $9C29 machaca X. Comprobar que no hace falta despues.
    # El flujo es: $9FF1 JSR $9ACD -> JMP $9801, y $9801 hace STZ $3658 y
    # recalcula X en $9863 (TAX). X no se hereda.
    assert bytes(rom[0x41801:0x41804]) == bytes([0x9C, 0x58, 0x36]), \
        '$9801 no empieza con STZ $3658'
    assert rom[0x41874] == 0xAA, '$9874 no es TAX: X no se recalcularia'
    print('  X no se hereda: $9801 -> STZ $3658 y $9874 TAX lo recalcula')

    # ------------------------------------------------------------------
    intactas = [
        ('guion', 0x48F91, 0x4A484),
        ('descompresor', 0x4B93B, 0x4BF40),
        ('tablas $9BBD/$9C05', 0x41BBD, 0x41C29),
        ('lista de sprites', 0x47C02, 0x47CD5),
        ('cargador del CG', 0x41AAE, 0x41ACD),
        ('tabla rabillo', 0x41ADD, 0x41AFD),
        ('calc_alto', 0x41FE0, 0x41FEB),
        ('fin de linea', 0x418A9, 0x418B6),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert rom[a:b] == orig[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    dif = [i for i in range(len(rom)) if rom[i] != orig[i]]
    permitido = set(range(IDX, IDX + 17)) | set(range(VOL, VOL + len(vol)))
    fuera = [i for i in dif if i not in permitido]
    assert not fuera, 'cambios fuera de lo previsto: %s' % [hex(i) for i in fuera]
    print('%d bytes modificados, todos previstos' % len(dif))

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)

    rec = []
    i = 0
    while i < len(dif):
        a = dif[i]
        j = i
        while j + 1 < len(dif) and dif[j + 1] <= dif[j] + 8:
            j += 1
        b = dif[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    open(IPS, 'wb').write(b'PATCH' + b''.join(rec) + b'EOF')
    prueba = bytearray(orig)
    raw = open(IPS, 'rb').read()
    p = 5
    while raw[p:p + 3] != b'EOF':
        of = raw[p] << 16 | raw[p + 1] << 8 | raw[p + 2]
        n = raw[p + 3] << 8 | raw[p + 4]
        prueba[of:of + n] = raw[p + 5:p + 5 + n]
        p += 5 + n
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(raw))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print()
    print('QUE HAY QUE VER')
    print('  Cuatro lineas DISTINTAS (no dos bloques repetidos), el bocadillo')
    print('  en su sitio y los aldeanos hablando otra vez.')
    print('  La primera pagina de cada dialogo sigue saliendo con 2 lineas:')
    print('  la pinta el clon $9952 y es el paso siguiente.')


if __name__ == '__main__':
    main()
