#!/usr/bin/env python3
"""
build_v226.py - el bocadillo del abuelo a 14x2, con lista propia.

QUE PIDE DAVID
--------------
> «Sí, 14x2. Sí, rotación del rabillo del tutorial 90º a la izquierda del
>  abuelo. Sí, "Coges la piedra glacial". Creo que, además, en los nombres
>  de los objetos hemos cambiado "Hielo" por "Glacial" (aunque puede que el
>  del otro chat la haya cagado y haya puesto "Glaciar")»

Tenia razon: en `0x430BC` pone `laciar`. Se corrige (1 byte).

=====================================================================
POR QUE 14x2 Y NO 12x2
=====================================================================
Medido sobre `states6/Ogros y abuelo_vram.bin` (la escena que revienta).
Ocupacion AJENA al bocadillo, por franjas:

```
y=40..79    2-3 ranuras     <- sitio de sobra
y=80..119   11-12 ranuras   <- los 4 ogros + el objeto
```

El bocadillo empieza en y=43. Con filas de 16 px:

```
2 lineas -> acaba en y=74   NO toca la franja de los ogros
3 lineas -> acaba en y=90   SE METE DE LLENO
```

Por eso **lo decisivo son las 2 lineas, no el ancho**:

```
geometria           pico   veredicto     (limite 16)
14x2 con laterales    12   OK, margen 4
12x2 con laterales    11   OK
16x2 con laterales    13   OK
14x3 con laterales    21   SE PASA
12x3 sin laterales    18   SE PASA
```

Y en texto, 14 columnas evitan partir frases tontamente:

```
12 cols -> 5 de 23 textos necesitan 2 paginas
14 cols -> 1 de 23   ("piedra glacial" cabe partida en 2 lineas)
```

=====================================================================
LA LISTA PROPIA
=====================================================================
La lista `$7C02` la comparten aldeanos, Jizo y abuelo. El bocadillo de
aldeanos (v216) es INTOCABLE, asi que el abuelo necesita la suya.

El emisor ya calcula el indice de variante para el rabillo:

```
$9A83  LDA $368F / ASL A / TAY     <- Y = variante*2  (abuelo = 2 -> Y=4)
$9A88  LDA $9ADD,Y / LDA $9ADE,Y   <- puntero del RABILLO, indexado
$9A9F  LDA #$02 / LDA #$7C         <- puntero de la LISTA, FIJO  <-- aqui
```

Se sustituyen esos dos `LDA #` por lecturas indexadas de una tabla nueva
de 4 punteros, con el MISMO `Y`. La tabla y la lista del abuelo van al
hueco de 872 B que hay detras de la lista actual (`0x47C98-0x48000`).

=====================================================================
EL RABILLO ROTADO
=====================================================================
El VDC solo tiene flip H y V: **no hay rotacion**. Hay que rotar los
pixeles y escribir la celda. Se toma la `1AD` (la del tutorial, punta
abajo) y se gira 90 grados a la izquierda -> punta a la DERECHA, que es
lo que pide David para el abuelo, y se escribe en la `1AF`.

Uso:  python3 tools/build_v226.py
"""
import hashlib
import zlib
import struct
import subprocess
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from descomp_cg import Flujo, tile, comprime

BASE = 'roms/momotaro_es_v225.pce'
SALIDA = 'roms/momotaro_es_v226.pce'
IPS = 'parches/momotaro_v226.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'a1ecc337b9bb1e4f5c5b44dcad45744e'

BASE_PATRON = 0x170             # $9A7B: $02E0 / 2
LISTA = 0x47C02                 # $7C02, la compartida
HUECO = 0x47C98                 # 872 B a $FF detras de la lista
GLACIAR = 0x430C1               # la 'r' de "Glaciar"

# tabla de rabillos
RAB = 0x41ADD
# el emisor
PTR_LO = 0x41AA0                # operando del $9A9F LDA #$02
PTR_HI = 0x41AA4                # operando del      LDA #$7C

COLS = 14
LINEAS = 2


def rota_izq(celda):
    """Gira 90 grados a la izquierda una celda de 16x16 (128 B, 4 planos)."""
    w = struct.unpack('<64H', celda)
    src = [[0] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            b = 15 - x
            src[y][x] = ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
                | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)
    dst = [[0] * 16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            dst[15 - x][y] = src[y][x]
    out = [0] * 64
    for y in range(16):
        for x in range(16):
            b = 15 - x
            v = dst[y][x]
            for pl in range(4):
                if v & (1 << pl):
                    out[pl * 16 + y] |= (1 << b)
    return struct.pack('<64H', *out)


def dibuja(celda, tit):
    w = struct.unpack('<64H', celda)
    print('  %s' % tit)
    for y in range(16):
        s = ''
        for x in range(16):
            b = 15 - x
            v = ((w[y] >> b) & 1) | (((w[16 + y] >> b) & 1) << 1) \
                | (((w[32 + y] >> b) & 1) << 2) | (((w[48 + y] >> b) & 1) << 3)
            s += '.' if v == 0 else '%X' % v
        print('     ' + s)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v225'
    print('base %s  OK' % BASE)

    # ==================================================================
    # 1. "Glaciar" -> "Glacial"
    # ==================================================================
    assert bytes(rom[0x430BC:0x430C2]) == bytes([0xAC, 0xA1, 0xA3, 0xA9,
                                                 0xA1, 0xB2]), \
        'en 0x430BC no pone "laciar": %s' % bytes(rom[0x430BC:0x430C2]).hex()
    rom[GLACIAR] = 0xAC          # 'r' -> 'l'
    print('\n1. "Glaciar" -> "Glacial"  (1 byte en 0x%05X)' % GLACIAR)

    # ==================================================================
    # 2. el rabillo rotado
    # ==================================================================
    ptr = rom[0x41C3D] | (rom[0x41C41] << 8)
    cnt = rom[0x41C4F] | (rom[0x41C50] << 8)
    CG = 0x3C000 + (ptr - 0x4000)
    CN = 0x3C000 + (cnt - 0x4000)
    n = rom[CN]
    assert n == 20, 'esperaba 20 celdas, hay %d' % n
    f = Flujo(bytes(rom), CG)
    celdas = [b''.join(tile(f) for _ in range(4)) for _ in range(n)]
    fin = f.p
    destino = rom[0x41C45] | (rom[0x41C4A] << 8)
    prim = destino // 64
    print('\n2. CG: %d celdas %03X..%03X, stream 0x%05X..0x%05X (%d B)'
          % (n, prim, prim + n - 1, CG, fin, fin - CG))

    i_1AD = 0x1AD - prim
    i_1AF = 0x1AF - prim
    dibuja(celdas[i_1AD], 'celda 1AD (tutorial, punta abajo):')
    nuevo = rota_izq(celdas[i_1AD])
    dibuja(nuevo, 'rotada 90 a la IZQUIERDA -> punta a la DERECHA:')
    celdas[i_1AF] = nuevo

    stream = comprime(b''.join(celdas))
    hueco = fin - CG
    print('  CG recomprimido: %d B (hueco original %d)' % (len(stream), hueco))
    if len(stream) > hueco:
        # El rabillo rotado tiene mas transiciones y comprime peor (norma
        # 172). Detras esta la FUENTE (0x3D660): se desplaza el stream
        # hacia atras, donde hay relleno, y se repunta el cargador.
        extra = len(stream) - hueco
        libre = 0
        o = CN - 1
        while rom[o] == 0xFF:
            libre += 1
            o -= 1
        print('  hacen falta %d B mas; hay %d B de relleno delante'
              % (extra, libre))
        assert libre >= extra + 8, 'no hay relleno suficiente delante'
        nuevo_cg = CG - extra
        nueva_cnt = nuevo_cg - 1
        assert all(b == 0xFF for b in rom[nueva_cnt:CN]), \
            'la zona a ocupar no esta libre'
        rom[nueva_cnt] = n
        rom[nuevo_cg:nuevo_cg + len(stream)] = stream
        pn = 0x4000 + (nuevo_cg - 0x3C000)
        cn2 = 0x4000 + (nueva_cnt - 0x3C000)
        rom[0x41C3D] = pn & 0xFF
        rom[0x41C41] = pn >> 8
        rom[0x41C4F] = cn2 & 0xFF
        rom[0x41C50] = cn2 >> 8
        print('  stream movido a 0x%05X, puntero $%04X -> $%04X'
              % (nuevo_cg, ptr, pn))
        CG = nuevo_cg
        CN = nueva_cnt
        assert CG + len(stream) == fin, 'el final del stream no cuadra'
    else:
        rom[CG:CG + len(stream)] = stream
        if len(stream) < hueco:
            rom[CG + len(stream):fin] = b'\xFF' * (hueco - len(stream))

    # round-trip desde la ROM
    f2 = Flujo(bytes(rom), CG)
    rel = [b''.join(tile(f2) for _ in range(4)) for _ in range(n)]
    assert rel == celdas, 'el round-trip del CG falla'
    print('  round-trip: OK')

    # ==================================================================
    # 3. la lista propia del abuelo, 14x2
    # ==================================================================
    # geometria de la actual, para copiar estilo
    print('\n3. lista actual (compartida) en 0x%05X:' % LISTA)
    i = LISTA
    viejos = []
    while rom[i] != 0xFF:
        viejos.append(tuple(rom[i:i + 5]))
        i += 5
    print('   %d sprites, terminador en 0x%05X' % (len(viejos), i))

    # celdas: el marco vive en 19C-1AF; el texto en 1C4.. (segun el informe)
    # Se reutilizan las MISMAS celdas de la lista compartida.
    # Estructura de la compartida (3 filas): [borde/texto...] por fila.
    # Para el abuelo: 2 filas de 7 celdas (14 cols) + 2 laterales.
    celdas_texto = [0x1C4 + k for k in range(14)]
    LAT_IZQ, LAT_DER = 0x1A0, 0x1A1
    ESQ_SUP, ESQ_INF = 0x1DC, 0x1DD

    ncel = (COLS + 1) // 2       # 7 celdas de 16 px = 14 caracteres
    nueva = []
    X0 = -72                     # dX del lateral izquierdo
    for li in range(LINEAS):
        dY = 12 + li * 16
        fila = celdas_texto[li * ncel:(li + 1) * ncel]
        nueva.append((LAT_IZQ, 0x00, X0, dY))
        for k, c in enumerate(fila):
            nueva.append((c, 0x00, X0 + 8 + k * 16, dY))
        nueva.append((LAT_DER, 0x00, X0 + 8 + ncel * 16, dY))
    # bordes: se dibujan en las mismas celdas (el marco va en el CG)
    regs = bytearray()
    for celda, flags, dX, dY in nueva:
        b0 = celda - BASE_PATRON
        assert 0 <= b0 <= 0xFF, 'b0 fuera de rango para la celda %03X' % celda
        regs += bytes([b0, 0x0F, flags, dX & 0xFF, dY & 0xFF])
    regs += b'\xFF'
    print('   lista nueva: %d sprites (%d filas x %d celdas + 2 laterales)'
          % (len(nueva), LINEAS, ncel))
    print('   ranuras por fila: %d  (limite 16, la escena gasta 12)'
          % (ncel + 2))
    assert ncel + 2 <= 9, 'demasiadas ranuras por fila'

    # comprobar el hueco
    libre = 0
    while HUECO + libre < 0x48000 and rom[HUECO + libre] == 0xFF:
        libre += 1
    print('   hueco en 0x%05X: %d B libres' % (HUECO, libre))
    TABLA = HUECO                       # 4 punteros = 8 B
    LISTA_AB = HUECO + 8
    assert 8 + len(regs) <= libre, 'no cabe la tabla + la lista'

    p_comp = 0x7C02                     # la compartida
    p_ab = 0x7C00 + (LISTA_AB - 0x47C00)
    for k, p in enumerate([p_comp, p_comp, p_ab, p_comp]):
        rom[TABLA + k * 2] = p & 0xFF
        rom[TABLA + k * 2 + 1] = p >> 8
    rom[LISTA_AB:LISTA_AB + len(regs)] = regs
    p_tabla = 0x7C00 + (TABLA - 0x47C00)
    print('   tabla de 4 punteros en $%04X (ROM 0x%05X)' % (p_tabla, TABLA))
    print('   lista del abuelo en   $%04X (ROM 0x%05X), %d B'
          % (p_ab, LISTA_AB, len(regs)))

    # ==================================================================
    # 4. el emisor: puntero indexado
    # ==================================================================
    assert rom[PTR_LO - 1] == 0xA9 and rom[PTR_HI - 1] == 0xA9, \
        'el emisor $9A9F no tiene la forma esperada'
    assert rom[PTR_LO] == 0x02 and rom[PTR_HI] == 0x7C, \
        'el puntero fijo no es $7C02'
    # $9A9F  LDA #$02 / STA $53 / LDA #$7C / STA $54   = 8 bytes
    # ->     LDA tabla,Y / STA $53 / LDA tabla+1,Y / STA $54 = 8 bytes
    nuevo_cod = bytes([
        0xB9, p_tabla & 0xFF, p_tabla >> 8,          # LDA tabla,Y
        0x85, 0x53,                                  # STA $53
        0xB9, (p_tabla + 1) & 0xFF, (p_tabla + 1) >> 8,   # LDA tabla+1,Y
        0x85, 0x54,                                  # STA $54
    ])
    # el hueco original son 8 B ($9A9F..$9AA6); el nuevo son 10.
    # $9A9B..$9A9E es "ADC $20 / TAM #$08", que hay que conservar.
    # Se mira si hay sitio: el JSR de $9AA7 va justo detras.
    # La lectura indexada son 10 B y en $9A9F solo hay 8. Pero no hace
    # falta apretarla ahi: el banco $00 esta SIEMPRE mapeado en MPR7
    # (norma 162) y detras de la rutina de recorte $FF6B quedan 64 B
    # libres. Se mete alli el selector y se llama con un JSR de 3 B,
    # que cabe de sobra en los 8.
    SEL = 0x1FA0
    libre_sel = 0
    while SEL + libre_sel < 0x1FE0 and rom[SEL + libre_sel] == 0xFF:
        libre_sel += 1
    sel_addr = 0xE000 + (SEL - 0x0000)
    selector = bytes([
        0xB9, p_tabla & 0xFF, p_tabla >> 8,                # LDA tabla,Y
        0x85, 0x53,                                        # STA $53
        0xB9, (p_tabla + 1) & 0xFF, (p_tabla + 1) >> 8,    # LDA tabla+1,Y
        0x85, 0x54,                                        # STA $54
        0x60,                                              # RTS
    ])
    assert len(selector) <= libre_sel, 'no cabe el selector'
    assert all(b == 0xFF for b in rom[SEL:SEL + len(selector)]), \
        'la zona del selector no esta libre'
    rom[SEL:SEL + len(selector)] = selector
    # y en $9A9F: JSR selector + 5 NOP  (8 bytes justos)
    rom[PTR_LO - 1] = 0x20
    rom[PTR_LO] = sel_addr & 0xFF
    rom[PTR_LO + 1] = sel_addr >> 8
    for k in range(3, 8):
        rom[PTR_LO - 1 + k] = 0xEA                          # NOP
    print('\n4. emisor: selector de %d B en $%04X (ROM 0x%05X)'
          % (len(selector), sel_addr, SEL))
    print('   $9A9F  LDA #$02/... -> JSR $%04X + 5 NOP' % sel_addr)
    print('   la Y de $9A87 (variante*2) elige la lista')
    aplicado = True

    # OJO: el banco de la LISTA lo mapea $9A98 (LDA #$23 / TAM #$08) ANTES
    # de este punto, asi que la tabla y la lista del abuelo tienen que
    # vivir en el banco $23. Y asi es: las dos estan en 0x47C98+.
    assert 0x46000 <= TABLA < 0x48000, 'la tabla no esta en el banco $23'
    assert 0x46000 <= LISTA_AB < 0x48000, 'la lista no esta en el banco $23'

    # ==================================================================
    # verificacion
    # ==================================================================
    tmp = '/tmp/_v226.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM')
    for off, nb, carga, nom in [(0x41A9B, 16, 0x9A9B, 'emisor'),
                                (0x1FA0, 11, 0xFFA0, 'selector')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % off,
                            str(nb), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    print('\n--- lista del abuelo, releida de la ROM')
    i = LISTA_AB
    k = 0
    while rom[i] != 0xFF:
        b = rom[i:i + 5]
        dX = b[3] - 256 if b[3] > 127 else b[3]
        dY = b[4] - 256 if b[4] > 127 else b[4]
        print('    [%2d] celda %03X  dX=%4d  dY=%3d'
              % (k, BASE_PATRON + b[0], dX, dY))
        i += 5
        k += 1

    intactas = [
        ('lista compartida (aldeanos/Jizo)', LISTA, 0x47C98),
        ('fuente', 0x3D660, 0x3E200),
        ('cabecera y vectores', 0x1FE0, 0x2000),
        ('guion', 0x48F91, 0x4A484),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(n for n, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('%d bytes sobre la v225' % len(dif))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    if not aplicado:
        print('\nAVISO: el puntero indexado NO se ha aplicado (no cabe).')
        print('La lista del abuelo esta escrita y lista, pero todavia')
        print('no se usa. Hace falta un trampolin de 2 bytes.')


if __name__ == '__main__':
    main()
