#!/usr/bin/env python3
"""build_v321.py - «Ve. Momotaro.os» -> «Ve, Momotaro.»

EL BUG QUE VIO DAVID
--------------------
Un aldeano de Isla Ogros acaba diciendo:

    ahora:  ...trae la paz al / mundo. Ve. / Momotaro.os
    debe:   ...trae la paz al / mundo. Ve, / Momotaro.

LA CAUSA (y el error que estuve a punto de cometer)
---------------------------------------------------
Mi primer diagnostico fue «la `o` y la `s` de 0x4BF1F son basura». **FALSO
Y PELIGROSO**: son la **entrada `$60` del diccionario**, `«os »`, que usan
30 dialogos del banco `$25` («todos», «aldeanos», «esperanzas»...).
Ponerlas a relleno las habria roto todas. La v321 se llego a construir y se
BORRO al detectarlo en la relectura.

La causa real es un **solape**: el dialogo `0x4BEBE` no tiene terminador
propio. Su texto llega hasta `0x4BF1E` y a partir de `0x4BF1F` empieza la
entrada del diccionario, asi que el motor sigue leyendo, imprime `«os »` y
solo se para en el `$00` de `0x4BF22`, que es el terminador de la ENTRADA,
no del dialogo.

    0x4BF1B  $CB  '.'          <- deberia ser ','
    0x4BF1C  $3B  salto
    0x4BF1D  $65  DICC «Momotaro»
    0x4BF1E  $CB  '.'
    0x4BF1F  $AF ─┐
    0x4BF20  $B3  ├ entrada $60 del diccionario = «os »
    0x4BF21  $20 ─┘
    0x4BF22  $00  terminador de la ENTRADA, que el dialogo usa por accidente

EL ARREGLO
----------
Mover la entrada `$60` (4 B con su terminador) al hueco libre del final del
banco `$25`, repuntar su casilla en la tabla `0x4BA13`, y poner el `$00`
del dialogo en `0x4BF1F`.

El hueco `0x4BFE7..0x4C000` (25 B) esta verificado libre: en la japonesa
era todo `$FF`, ninguna de las 48 entradas del diccionario llega mas alla
de `0x4BF6F` y el ultimo dialogo acaba justo en `0x4BFE7`.
"""
import hashlib
import struct
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_vitores import encode   # noqa: E402

BASE = 'roms/momotaro_es_v320.pce'
SALIDA = 'roms/momotaro_es_v321.pce'
MD5_BASE = '9469caf05942325ee122a06abebc1273'

TABLA_DICC = 0x4BA13       # 48 entradas, banco $24 en ventana $4000
DIALOGO = 0x4BEBE
COMA = 0x4BF1B             # el '.' de «Ve.»
FIN_DIALOGO = 0x4BF1F      # donde va el $00 nuevo
ENT60_VIEJA = 0x4BF1F      # la entrada «os » vive aqui
DESTINO = 0x4BFE7          # hueco libre al final del banco $25

INTACTAS = [
    (0x00000, 0x16000, 'bancos 00-0A'),
    (0x1E000, 0x20000, 'banco $0F: escenas y rotulos'),
    (0x42000, 0x44000, 'banco $21: menu RUN'),
    (0x48000, 0x4A000, 'banco $24: tiendas, guion, vitores'),
    (0x4AC80, 0x4AD60, 'los dados'),
    (0x4AEE6, 0x4BA13, 'el QUIZ (hasta la tabla del diccionario)'),
    (0x4BA15, 0x4BEBE, 'resto del diccionario y dialogos'),
]


def leer_dicc(rom, cod):
    p = struct.unpack('<H', rom[TABLA_DICC + (cod - 0x60) * 2:
                                TABLA_DICC + (cod - 0x60) * 2 + 2])[0]
    o = 0x48000 + p - 0x4000
    e = rom.find(b'\x00', o)
    return o, rom[o:e]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v320'

    # ---- asserts previos -------------------------------------------------
    o60, txt60 = leer_dicc(rom, 0x60)
    assert o60 == ENT60_VIEJA, 'la entrada $60 no esta en %06X' % ENT60_VIEJA
    assert bytes(txt60) == encode('os '), \
        'la entrada $60 no es «os » sino %r' % txt60
    assert rom[COMA] == encode('.')[0], 'en %06X no hay un punto' % COMA
    assert rom[0x4BF1D] == 0x65, 'no esta el codigo $65 de «Momotaro»'
    assert rom[0x4BF1E] == encode('.')[0], 'falta el punto de «Momotaro.»'
    assert rom.find(b'\x00', DIALOGO) == 0x4BF22, \
        'el dialogo no acaba donde creo'

    # el hueco de destino: libre en la japonesa y sin usar hoy
    assert all(b == 0xFF for b in jp[DESTINO:0x4C000]), \
        'el hueco no era $FF en la japonesa'
    assert all(b == 0x00 for b in rom[DESTINO:0x4C000]), \
        'el hueco no esta a cero hoy'
    for c in range(0x60, 0x90):
        oo, _ = leer_dicc(rom, c)
        assert c == 0x60 or oo < DESTINO, \
            'la entrada $%02X ya cae en el hueco' % c

    # ---- 1. mover la entrada $60 ----------------------------------------
    nueva = encode('os ') + b'\x00'
    assert DESTINO + len(nueva) <= 0x4C000
    rom[DESTINO:DESTINO + len(nueva)] = nueva
    cpu = 0x4000 + (DESTINO - 0x48000)
    assert 0x4000 <= cpu < 0x8000, 'la direccion CPU se sale de la ventana'
    rom[TABLA_DICC:TABLA_DICC + 2] = struct.pack('<H', cpu)

    # ---- 2. arreglar el dialogo -----------------------------------------
    rom[COMA] = encode(',')[0]
    rom[FIN_DIALOGO] = 0x00

    # ---- VERIFICACION ----------------------------------------------------
    # la entrada $60 sigue siendo «os » desde su sitio nuevo
    o60n, txt60n = leer_dicc(rom, 0x60)
    assert o60n == DESTINO, 'la entrada $60 no quedo en el destino'
    assert bytes(txt60n) == encode('os '), 'la entrada $60 se rompio'

    # las otras 47 entradas, intactas
    for c in range(0x61, 0x90):
        oa, ta = leer_dicc(original, c)
        ob, tb = leer_dicc(rom, c)
        assert oa == ob and ta == tb, 'la entrada $%02X cambio' % c

    # el dialogo, releido expandiendo el diccionario
    rv = {}
    from charset_vitores import CHAR_TO_CODE
    for k, v in CHAR_TO_CODE.items():
        rv.setdefault(v, k)
    fin = rom.find(b'\x00', DIALOGO)
    assert fin == FIN_DIALOGO, 'el dialogo no acaba en %06X' % FIN_DIALOGO
    out = []
    for x in rom[DIALOGO:fin]:
        if x == 0x3B:
            out.append(' / ')
        elif 0x60 <= x <= 0x8F:
            out.append(''.join(' / ' if c == 0x3B else rv.get(c, '{%02X}' % c)
                               for c in leer_dicc(rom, x)[1]))
        else:
            out.append(rv.get(x, '{%02X}' % x))
    texto = ''.join(out)
    assert texto.endswith('Ve, / Momotaro.'), \
        'el dialogo acaba en ...%s' % texto[-30:]
    assert '{' not in texto, 'hay codigos sin expandir: %s' % texto

    # los 30 dialogos que usan «os » siguen bien: se comprueba uno a uno que
    # el byte $60 sigue expandiendo
    usos = sum(1 for i in range(0x4A000, 0x4C000) if rom[i] == 0x60)
    assert usos >= 25, 'han desaparecido usos del codigo $60'

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = [i for i in range(len(rom)) if rom[i] != original[i]]
    open(SALIDA, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % SALIDA)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % len(dif))
    print()
    print('  entrada $60 «os »:  %06X -> %06X  (tabla repuntada a $%04X)'
          % (ENT60_VIEJA, DESTINO, cpu))
    print('  %06X  «.» -> «,»' % COMA)
    print('  %06X  terminador $00 del dialogo' % FIN_DIALOGO)
    print()
    print('  dialogo releido:')
    print('    %s' % texto)


if __name__ == '__main__':
    main()
