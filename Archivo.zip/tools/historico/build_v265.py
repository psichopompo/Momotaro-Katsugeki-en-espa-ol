#!/usr/bin/env python3
"""
build_v265.py - el canto del Jizo en pagina limpia. David tenia razon.

LO QUE PEDIA DAVID
==================
> «Al decir SI deberiamos ir a una pagina completamente nueva, sin pregunta
>  arriba, en la que se vea unicamente el password en tres lineas limpias.
>  Me contaste un rollo de que no se podia. ¿Como no se va a poder si con la
>  pregunta y las dos primeras lineas son 4 lineas en total, y luego
>  simplemente se sustituyen las dos lineas de password por la tercera?»

**Se puede, y son 12 bytes.**

POR QUE NO SE HABIA VISTO
=========================
El informe anterior decia:

> «Lo que falta: la pregunta NO vive en el buffer $3667. Ya esta volcada en
>  VRAM y el canto se pinta encima sin borrarla. Falta identificar quien
>  pinta la pregunta y con que rutina se limpia esa zona de VRAM.»

La primera frase es cierta, la conclusion no. **No hace falta saber quien
pinto la pregunta.** El volcado `$9B7C` escribe las 32 celdas SIEMPRE, valga
lo que valga el buffer:

```
$9B7C  CLX
       LDA $3667,X ... JSR $9D33 ... INX / CPX #$20 / BCC
```

Y el bitmap del codigo 0 es **todo ceros** (verificado: `0x3D660` = ocho
`$00`). O sea: **buffer a cero + volcado = pagina en blanco**.

`$9C29` ya pone el buffer a cero. Solo faltaba volcarlo antes de escribir.

LA MEDICION
===========
```
$9789   despachador por $3654:  0->$97EE 1->$97BA 2->$979A 3->$97D0 4+->$9928
$9928   estado 4 (canto): solo avanza si $39 bit0 (pulsacion)
        -> $9939 mapea el banco $0B en MPR6 -> JSR $CA73
$CA73   bucle del canto. Empieza con JSR $9C29 (limpia el buffer)
        y termina en $9B7C (vuelca)
0x41919 LDA #$04 / STA $3654   <- aqui se entra al canto al pulsar SI
$CABD   25 NOPs libres, justo detras del bucle
```

**`$CA73` corre SOLO al pulsar el boton**, no en cada frame, asi que meter
un borrado ahi no parpadea. Y como el canto ocupa 2 paginas (el buffer son
32 celdas y el canto 32 caracteres + separadores), borrar al entrar limpia
tambien al pasar de la pagina 1 a la 2, que es justo lo que pide David.

EL PARCHE
=========
```
$CABD (los NOPs):   JSR $9C29     pone el buffer a cero
                    JSR $9B7C     lo vuelca -> BORRA la pantalla
                    JMP $9C29     limpia otra vez y vuelve (acaba en RTS)

$CA73:              JSR $9C29  ->  JSR $CABD
```

3 bytes repuntados + 9 bytes nuevos.

Uso:  python3 tools/build_v265.py
"""
import hashlib
import zlib
import subprocess

BASE = 'roms/momotaro_es_v264.pce'
SALIDA = 'roms/momotaro_es_v265.pce'
IPS = 'parches/momotaro_v265.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '695965973173f0a960eb3c0095f8cef0'

BUCLE = 0x16A73                 # $CA73, primera instruccion (JSR $9C29)
NOPS = 0x16ABD                  # $CABD, 25 NOPs libres
FUENTE = 0x3D660


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v264'
    print('base %s  OK' % BASE)

    # --- la premisa: el glifo 0 borra ---------------------------------
    assert all(b == 0 for b in rom[FUENTE:FUENTE + 8]), \
        'el glifo 0 de la fuente NO es todo ceros: el borrado no funcionaria'
    print('\nglifo 0 de la fuente = 8 bytes a cero -> volcarlo BORRA')

    # --- el hueco ------------------------------------------------------
    n = 0
    while rom[NOPS + n] == 0xEA:
        n += 1
    print('hueco en $CABD: %d NOPs' % n)
    assert n >= 9, 'no caben los 9 bytes'

    # --- lo que vamos a sustituir --------------------------------------
    esp = bytes([0x20, 0x29, 0x9C])          # JSR $9C29
    assert bytes(rom[BUCLE:BUCLE + 3]) == esp, \
        'en $CA73 no esta el JSR $9C29: %s' % bytes(rom[BUCLE:BUCLE + 3]).hex()

    # --- la rutina -----------------------------------------------------
    rut = bytes([
        0x20, 0x29, 0x9C,       # JSR $9C29   buffer a cero
        0x20, 0x7C, 0x9B,       # JSR $9B7C   vuelca -> borra la pantalla
        0x4C, 0x29, 0x9C,       # JMP $9C29   limpia otra vez; acaba en RTS
    ])
    rom[NOPS:NOPS + len(rut)] = rut
    addr = 0xC000 + (NOPS - 0x16000)
    rom[BUCLE:BUCLE + 3] = bytes([0x20, addr & 0xFF, addr >> 8])
    print('\nrutina de %d B en $%04X (ROM 0x%05X)' % (len(rut), addr, NOPS))
    print('$CA73  JSR $9C29 -> JSR $%04X' % addr)

    # --- verificacion ---------------------------------------------------
    tmp = '/tmp/_v265.pce'
    open(tmp, 'wb').write(bytes(rom))
    print('\n--- desensamblado desde la ROM')
    for off, nb, carga, nom in [(BUCLE, 12, 0xCA73, 'entrada del bucle'),
                                (NOPS, len(rut), addr, 'rutina de borrado')]:
        print('  [%s]' % nom)
        r = subprocess.run(['python3', 'tools/dis6280.py', tmp, '%X' % off,
                            str(nb), '%X' % carga],
                           capture_output=True, text=True)
        for l in r.stdout.strip().split('\n'):
            print('    ' + l)

    # el resto del bucle, intacto
    assert bytes(rom[BUCLE + 3:NOPS]) == base[BUCLE + 3:NOPS], \
        'se ha tocado el cuerpo del bucle'
    print('\ncuerpo del bucle $CA76-$CABC: INTACTO')

    intactas = [
        ('fuente', 0x3D660, 0x3E200),
        ('tabla del canto $CAD6', 0x16AD6, 0x16B16),
        ('cadena Capa (v264)', 0x43140, 0x43148),
        ('tabla de sustitucion', 0x42B4C, 0x42B5C),
        ('parrilla del password', 0x1BBBA, 0x1BC00),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('intactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    print('\n%d bytes sobre la v264' % len(dif))
    assert all(BUCLE <= i < BUCLE + 3 or NOPS <= i < NOPS + len(rut)
               for i in dif), 'cambios fuera de sitio'

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec = []
    i = 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
