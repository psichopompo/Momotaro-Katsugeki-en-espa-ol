#!/usr/bin/env python3
"""password.py - Teclea un password ("canto de Jizo") en el emulador.

Sirve para saltar a cualquier punto del juego sin savestate. La rejilla se
midio celda a celda en el emulador; no esta deducida.

    CURSOR   columna $3C91   fila $3C92
    BUFFER   $3C94 (un codigo por caracter tecleado)

    fila 0   A B C D E F G  a b c d e f g     codigos $01..$0E
    fila 1   H I J K L M N  h i j k l m n     codigos $0F..$1C
    fila 2   N O P Q R S T  n o p q r s t     codigos $1D..$2A   <- empieza por N con virgulilla
    fila 3   U V W X Y Z    u v w x y z       codigos $2B..$36
    fila 4       0 1 2 3 4 5 6 7 8 9          codigos $37..$40

TRES TRAMPAS que me costaron tres intentos:
  1. La rejilla tiene **14 columnas**, no 16.
  2. La fila 2 empieza por **N con virgulilla**, no por O. Si no, todo se
     desplaza una celda y sale «rGAO» en vez de «rGAP».
  3. El password se acepta con **START**, no con el menu lateral de la
     derecha (ADELANTE/ATRAS/ESPACIO/BORRAR/FIN).

Passwords de David:
    Muy dificil  wCpeIfP        Sound test     BqdGlCIWNI
    Dificil      GoFIBM         Graphics test  BqdGlDWNI
    Normal       cJQIep
    Facil        rGAPad

USO
    from password import boot, escribe
    p = boot('roms/momotaro_es_v338.pce')
    escribe(p, 'rGAPad')
    p.press('START', frames=4); p.run(300)
"""
import sys, json; sys.path.insert(0,'/home/user/Momotaro/tools')
from pce import PCE
COL,ROW,BUF=0x3C91,0x3C92,0x3C94
# rejilla medida empiricamente en el emulador (codigo por celda)
FILAS = [
    "ABCDEFGabcdefg",
    "HIJKLMNhijklmn",
    "OPQRSTñopqrst",     # 13 visibles + 1
    "UVWXYZuvwxyz",
    "0123456789",
]
# codigos medidos:  fila0 c0..c13 -> 01..0E ; fila1 -> 0F..1C ; fila2 -> 1D..2A
# fila3: c0..c5 -> 2B..30, c7..c12 -> 31..36 ; fila4: c2..c11 -> 37..40
CELDAS = {}
for c in range(14): CELDAS[(c,0)] = 0x01+c
for c in range(14): CELDAS[(c,1)] = 0x0F+c
for c in range(14): CELDAS[(c,2)] = 0x1D+c
for i,c in enumerate(range(0,6)):  CELDAS[(c,3)] = 0x2B+i
for i,c in enumerate(range(7,13)): CELDAS[(c,3)] = 0x31+i
for i,c in enumerate(range(2,12)): CELDAS[(c,4)] = 0x37+i

def boot(rom):
    p=PCE(rom); p.run(240); p.press('START',frames=4); p.run(180)
    p.press('RIGHT',frames=4); p.run(30); p.press('START',frames=4); p.run(200)
    return p

def goto(p,c,r,limit=40):
    for _ in range(limit):
        cc,rr=p.peek(COL),p.peek(ROW)
        if (cc,rr)==(c,r): return True
        if rr!=r: p.press('DOWN' if ((r-rr)%5)<=2 else 'UP',frames=3); p.run(7)
        else:     p.press('RIGHT' if ((c-cc)%14)<=7 else 'LEFT',frames=3); p.run(7)
    return False

# tabla caracter -> (col,fila), verificada en pantalla: col7 = segundo bloque
CHAR={}
for i,ch in enumerate("ABCDEFG"): CHAR[ch]=(i,0)
for i,ch in enumerate("abcdefg"): CHAR[ch]=(7+i,0)
for i,ch in enumerate("HIJKLMN"): CHAR[ch]=(i,1)
for i,ch in enumerate("hijklmn"): CHAR[ch]=(7+i,1)
for i,ch in enumerate("ÑOPQRST"): CHAR[ch]=(i,2)
for i,ch in enumerate("ñopqrst"): CHAR[ch]=(7+i,2)
for i,ch in enumerate("UVWXYZ"):  CHAR[ch]=(i,3)
for i,ch in enumerate("uvwxyz"):  CHAR[ch]=(7+i,3)
for i,ch in enumerate("0123456789"): CHAR[ch]=(2+i,4)

def escribe(p,txt):
    for ch in txt:
        c,r=CHAR[ch]
        assert goto(p,c,r), 'no llego a %r'%ch
        p.press('A',frames=3); p.run(12)
