#!/usr/bin/env python3
r"""build_v396.py - N5: centrar en Y el texto de la pancarta de vítores.

EL BUG
------
N5  La pancarta de vítores («¡Ánimo! ¡Momotaro! / ¡Vamos, Momotaro!») tiene
    el texto 4 px demasiado arriba.

[N4 RETIRADO — ver entrada 277]  El arreglo del bocadillo del abuelo (+2 en
la tabla `$9BBD`) **rompía los bocadillos de TRES filas**: franjas negras
entre líneas y píxeles sobre el marco. Medido: en un bocadillo de 3 filas el
glifo de `$1C4` ya ocupa las filas 8..14, así que sólo queda **1 px** de
margen y el `+2` desborda a la fila 0 de `$1CC`, que es el BORDE de la celda
siguiente. En el del abuelo (2 filas) el glifo va en 4..10 y sobran 5 px: por
eso allí funcionaba. **Validé con una sola escena.** Norma 383.

Medido con `states/tras_jefe_david.state` (vítores en el frame 620):

    interior y=83..116 (34 px)   texto y=84..107   arriba 1 / abajo 9

David pidió 4 px y el número sale exacto de la medición.

ES UN MECANISMO INDEPENDIENTE DE LOS DIÁLOGOS (entrada 275)
------------------------------------------------------------
La pancarta usa las celdas `$178..$189`; los bocadillos de diálogo, las
`$1C4..$1DD`. Verificado que tocar la tabla `$9BBD` de los diálogos deja el
CG de `$178` byte a byte idéntico. Por eso este cambio no afecta a ningún
diálogo.

N5: UN SOLO BYTE
----------------
Cadena de los vítores (entrada 177 del log): `$C419` → `$C997`, que llena
el buffer `$2593` y luego calcula el destino:

    $C9EE  LDA $16 / CLC / ADC #$30 / STA $3663      <- ROM 0x169F2

El `#$30` es el mismo offset «plano 3». Bajar 4 px = `ADC #$34`.

VERIFICACIÓN (sobre el savestate, CG volcado fila a fila)
----------------------------------------------------------
    celda $178 frame 700:  el glifo pasa de las filas 4-10 a las 8-14

Y comprobado que NO toca los diálogos, con el state del aldeano de 3 filas:

    aldeano 3 filas, página 2:   0 px distintos
    bocadillo del abuelo:        0 px distintos
    pancarta de vítores:       720 px distintos   <- el arreglo

Ningún glifo partido, marco sin mover. Capturas en `capturas/`.
"""
import hashlib
import sys
import zlib

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v395
DST = 'roms/momotaro_es_v396.pce'
JPR = 'roms/Momotarou Katsugeki (Japan).pce'

BYTE_N5 = 0x169F2       # el #$30 de `ADC #$30` en $C9EE
SUBIR_N5 = 4

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
jp = open(JPR, 'rb').read()

# ---- 0. el estado de partida es el que creo ------------------------------
# el byte de N5, con su instrucción alrededor: LDA $16 / CLC / ADC #$30
assert bytes(rom[BYTE_N5 - 4:BYTE_N5 + 4]) == b'\xa5\x16\x18\x69\x30\x8d\x63\x36', (
    'en 0x%05X no está el `LDA $16 / CLC / ADC #$30 / STA $3663`' % BYTE_N5)
assert rom[BYTE_N5] == 0x30, 'el byte de N5 no es $30'
assert jp[BYTE_N5] == 0x30, 'en la japonesa ese byte no es $30'

# ---- 1. N5: bajar el texto de la pancarta de vítores 4 px ---------------
rom[BYTE_N5] += SUBIR_N5
assert rom[BYTE_N5] == 0x34, 'el ADC de N5 no quedó en #$34'
print('  N5  0x%05X  ADC #$30 -> #$%02X   +%d px  (pancarta de vítores)'
      % (BYTE_N5, rom[BYTE_N5], SUBIR_N5))

# ---- 2. nada más se ha tocado -------------------------------------------
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos == {BYTE_N5}, 'se ha tocado algo más: %s' % sorted(distintos)

# NORMA 383: la tabla $9BBD de los diálogos NO se toca. Tocarla rompe los
# bocadillos de 3 filas (entrada 277).
assert rom[0x41BBD:0x41BFD] == orig[0x41BBD:0x41BFD], (
    'tocada la tabla $9BBD: eso rompe los bocadillos de 3 filas')
# el código que rodea al byte de N5
assert bytes(rom[BYTE_N5 - 4:BYTE_N5]) == b'\xa5\x16\x18\x69', 'pisado el LDA $16 / CLC / ADC'
assert bytes(rom[BYTE_N5 + 1:BYTE_N5 + 4]) == b'\x8d\x63\x36', 'pisado el STA $3663'
assert bytes(rom[BYTE_N5 + 4:BYTE_N5 + 8]) == orig[BYTE_N5 + 4:BYTE_N5 + 8], 'pisado el LDA $17'

open(DST, 'wb').write(bytes(rom))
print()
print('%s  %d B' % (DST, len(rom)))
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
