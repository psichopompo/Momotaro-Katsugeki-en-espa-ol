#!/usr/bin/env python3
"""
vdc_slots.py - simula el limite de 16 ranuras por scanline del VDC del PCE.

El VDC recorre el SATB por indice ASCENDENTE y va reservando ranuras. Un
sprite de 32 px de ancho cuenta DOS (norma 144). Cuando una scanline se
queda sin ranuras, el sprite NO se dibuja en esa scanline (se pierde la
franja, no el sprite entero).

Devuelve, por cada sprite, el conjunto de scanlines en las que SI se pinta.
"""
import struct
from collections import defaultdict

SATB_WORD = 0x7F00
MAX = 16


def sat(vram):
    w = struct.unpack('<256H', vram[SATB_WORD * 2:SATB_WORD * 2 + 512])
    out = []
    for i in range(64):
        y, x, pat, at = w[i * 4:i * 4 + 4]
        if (y, x, pat, at) == (0, 0, 0, 0) or y > 0x3FF:
            continue
        out.append(dict(i=i, y=y - 64, x=x - 32, celda=(pat >> 1) & 0x7FF,
                        at=at,
                        ancho=32 if (at >> 8) & 1 else 16,
                        alto={0: 16, 1: 32, 2: 48, 3: 64}[(at >> 12) & 3]))
    return out


def simular(vram, alto_pantalla=224):
    """Devuelve (visible, uso) - visible[i] = set de scanlines pintadas."""
    uso = defaultdict(int)
    visible = {}
    for s in sat(vram):
        coste = 2 if s['ancho'] == 32 else 1
        ok = set()
        for y in range(s['y'], s['y'] + s['alto']):
            if not 0 <= y < alto_pantalla:
                continue
            if uso[y] + coste <= MAX:
                uso[y] += coste
                ok.add(y)
        visible[s['i']] = ok
    return visible, uso


def informe(vram, alto_pantalla=224):
    visible, uso = simular(vram, alto_pantalla)
    lineas = []
    for s in sat(vram):
        filas = range(max(0, s['y']), min(alto_pantalla, s['y'] + s['alto']))
        perdidas = [y for y in filas if y not in visible[s['i']]]
        if perdidas:
            lineas.append((s['i'], s['celda'], s['y'], s['x'], perdidas))
    return lineas, uso


def filas_con_pixeles(vram, s):
    """Filas (0..alto-1) de un sprite que tienen algun pixel != 0.

    Norma 147: el borde inferior lleva el dibujo al FONDO de la celda, asi
    que perder ranuras en sus primeras filas NO se ve. Sin esto el
    simulador da falsos positivos.
    """
    w = struct.unpack('<%dH' % (len(vram) // 2), vram)
    cell = s['celda']
    ncol = 2 if s['ancho'] == 32 else 1
    nfil = s['alto'] // 16
    if ncol == 2:
        cell &= ~1
    if nfil >= 2:
        cell &= ~(2 if nfil == 2 else 6)
    out = set()
    for fy in range(nfil):
        for fx in range(ncol):
            bw = (cell + fy * 2 + fx) * 64
            if bw + 64 > len(w):
                continue
            for y in range(16):
                v = (w[bw + y] | w[bw + 16 + y] | w[bw + 32 + y]
                     | w[bw + 48 + y])
                if v:
                    out.add(fy * 16 + y)
    return out


def informe_visible(vram, alto_pantalla=224):
    """Como informe(), pero solo cuenta las filas que DIBUJAN algo."""
    visible, uso = simular(vram, alto_pantalla)
    lineas = []
    for s in sat(vram):
        pint = filas_con_pixeles(vram, s)
        perdidas = [s['y'] + f for f in sorted(pint)
                    if 0 <= s['y'] + f < alto_pantalla
                    and s['y'] + f not in visible[s['i']]]
        if perdidas:
            lineas.append((s['i'], s['celda'], s['y'], s['x'], perdidas))
    return lineas, uso
