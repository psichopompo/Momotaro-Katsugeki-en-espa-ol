"""dis6280.py - Desensamblador HuC6280 (PC Engine).

Existe porque `capstone` en modo 65C02 NO sirve: lee TAM ($53) como `nop`
y se desincroniza (norma 12 del diario). Aquí las instrucciones propias
del HuC6280 están completas:

    ST0/ST1/ST2, TAM/TMA, TII/TDD/TIN/TIA/TAI (7 bytes),
    CSL/CSH, SAX/SAY/SXY, CLA/CLX/CLY, BSR, TST, SET,
    RMB/SMB/BBR/BBS, y todo el juego 65C02.

USO
---
    python3 dis6280.py <rom> <offset_rom_hex> <n_bytes> [addr_carga_hex]

El cuarto argumento es la dirección lógica en que corre ese código (la
ventana MPR). Es IMPRESCINDIBLE para que los saltos salgan bien.

    # $D720 con el banco 0x0C en MPR6:
    python3 dis6280.py rom.pce 19720 80 D720

Como módulo:  from dis6280 import desensambla
"""
import sys

# --- modos de direccionamiento: (sufijo, longitud) ---
M = {
    'imp': ('', 1), 'acc': (' A', 1), 'imm': (' #${:02X}', 2),
    'zp': (' ${:02X}', 2), 'zpx': (' ${:02X},X', 2), 'zpy': (' ${:02X},Y', 2),
    'izp': (' (${:02X})', 2), 'izx': (' (${:02X},X)', 2), 'izy': (' (${:02X}),Y', 2),
    'abs': (' ${:04X}', 3), 'abx': (' ${:04X},X', 3), 'aby': (' ${:04X},Y', 3),
    'ind': (' (${:04X})', 3), 'iax': (' (${:04X},X)', 3),
    'rel': (' ${:04X}', 2), 'zprel': (' ${:02X},${:04X}', 3),
    'blk': (' ${:04X},${:04X},${:04X}', 7),
    'tzp': (' #${:02X},${:02X}', 3), 'tzpx': (' #${:02X},${:02X},X', 3),
    'tabs': (' #${:02X},${:04X}', 4), 'tabx': (' #${:02X},${:04X},X', 4),
}

OPS = {}


def _f(tab):
    for op, mn, md in tab:
        OPS[op] = (mn, md)


_f([
    (0x00, 'BRK', 'imp'), (0x01, 'ORA', 'izx'), (0x02, 'SXY', 'imp'),
    (0x03, 'ST0', 'imm'), (0x04, 'TSB', 'zp'), (0x05, 'ORA', 'zp'),
    (0x06, 'ASL', 'zp'), (0x08, 'PHP', 'imp'), (0x09, 'ORA', 'imm'),
    (0x0A, 'ASL', 'acc'), (0x0C, 'TSB', 'abs'), (0x0D, 'ORA', 'abs'),
    (0x0E, 'ASL', 'abs'),
    (0x10, 'BPL', 'rel'), (0x11, 'ORA', 'izy'), (0x12, 'ORA', 'izp'),
    (0x13, 'ST1', 'imm'), (0x14, 'TRB', 'zp'), (0x15, 'ORA', 'zpx'),
    (0x16, 'ASL', 'zpx'), (0x18, 'CLC', 'imp'), (0x19, 'ORA', 'aby'),
    (0x1A, 'INC', 'acc'), (0x1C, 'TRB', 'abs'), (0x1D, 'ORA', 'abx'),
    (0x1E, 'ASL', 'abx'),
    (0x20, 'JSR', 'abs'), (0x21, 'AND', 'izx'), (0x22, 'SAX', 'imp'),
    (0x23, 'ST2', 'imm'), (0x24, 'BIT', 'zp'), (0x25, 'AND', 'zp'),
    (0x26, 'ROL', 'zp'), (0x28, 'PLP', 'imp'), (0x29, 'AND', 'imm'),
    (0x2A, 'ROL', 'acc'), (0x2C, 'BIT', 'abs'), (0x2D, 'AND', 'abs'),
    (0x2E, 'ROL', 'abs'),
    (0x30, 'BMI', 'rel'), (0x31, 'AND', 'izy'), (0x32, 'AND', 'izp'),
    (0x34, 'BIT', 'zpx'), (0x35, 'AND', 'zpx'), (0x36, 'ROL', 'zpx'),
    (0x38, 'SEC', 'imp'), (0x39, 'AND', 'aby'), (0x3A, 'DEC', 'acc'),
    (0x3C, 'BIT', 'abx'), (0x3D, 'AND', 'abx'), (0x3E, 'ROL', 'abx'),
    (0x40, 'RTI', 'imp'), (0x41, 'EOR', 'izx'), (0x42, 'SAY', 'imp'),
    (0x43, 'TMA', 'imm'), (0x44, 'BSR', 'rel'), (0x45, 'EOR', 'zp'),
    (0x46, 'LSR', 'zp'), (0x48, 'PHA', 'imp'), (0x49, 'EOR', 'imm'),
    (0x4A, 'LSR', 'acc'), (0x4C, 'JMP', 'abs'), (0x4D, 'EOR', 'abs'),
    (0x4E, 'LSR', 'abs'),
    (0x50, 'BVC', 'rel'), (0x51, 'EOR', 'izy'), (0x52, 'EOR', 'izp'),
    (0x53, 'TAM', 'imm'), (0x54, 'CSL', 'imp'), (0x55, 'EOR', 'zpx'),
    (0x56, 'LSR', 'zpx'), (0x58, 'CLI', 'imp'), (0x59, 'EOR', 'aby'),
    (0x5A, 'PHY', 'imp'), (0x5D, 'EOR', 'abx'), (0x5E, 'LSR', 'abx'),
    (0x60, 'RTS', 'imp'), (0x61, 'ADC', 'izx'), (0x62, 'CLA', 'imp'),
    (0x64, 'STZ', 'zp'), (0x65, 'ADC', 'zp'), (0x66, 'ROR', 'zp'),
    (0x68, 'PLA', 'imp'), (0x69, 'ADC', 'imm'), (0x6A, 'ROR', 'acc'),
    (0x6C, 'JMP', 'ind'), (0x6D, 'ADC', 'abs'), (0x6E, 'ROR', 'abs'),
    (0x70, 'BVS', 'rel'), (0x71, 'ADC', 'izy'), (0x72, 'ADC', 'izp'),
    (0x73, 'TII', 'blk'), (0x74, 'STZ', 'zpx'), (0x75, 'ADC', 'zpx'),
    (0x76, 'ROR', 'zpx'), (0x78, 'SEI', 'imp'), (0x79, 'ADC', 'aby'),
    (0x7A, 'PLY', 'imp'), (0x7C, 'JMP', 'iax'), (0x7D, 'ADC', 'abx'),
    (0x7E, 'ROR', 'abx'),
    (0x80, 'BRA', 'rel'), (0x81, 'STA', 'izx'), (0x82, 'CLX', 'imp'),
    (0x83, 'TST', 'tzp'), (0x84, 'STY', 'zp'), (0x85, 'STA', 'zp'),
    (0x86, 'STX', 'zp'), (0x88, 'DEY', 'imp'), (0x89, 'BIT', 'imm'),
    (0x8A, 'TXA', 'imp'), (0x8C, 'STY', 'abs'), (0x8D, 'STA', 'abs'),
    (0x8E, 'STX', 'abs'),
    (0x90, 'BCC', 'rel'), (0x91, 'STA', 'izy'), (0x92, 'STA', 'izp'),
    (0x93, 'TST', 'tabs'), (0x94, 'STY', 'zpx'), (0x95, 'STA', 'zpx'),
    (0x96, 'STX', 'zpy'), (0x98, 'TYA', 'imp'), (0x99, 'STA', 'aby'),
    (0x9A, 'TXS', 'imp'), (0x9C, 'STZ', 'abs'), (0x9D, 'STA', 'abx'),
    (0x9E, 'STZ', 'abx'),
    (0xA0, 'LDY', 'imm'), (0xA1, 'LDA', 'izx'), (0xA2, 'LDX', 'imm'),
    (0xA3, 'TST', 'tzpx'), (0xA4, 'LDY', 'zp'), (0xA5, 'LDA', 'zp'),
    (0xA6, 'LDX', 'zp'), (0xA8, 'TAY', 'imp'), (0xA9, 'LDA', 'imm'),
    (0xAA, 'TAX', 'imp'), (0xAC, 'LDY', 'abs'), (0xAD, 'LDA', 'abs'),
    (0xAE, 'LDX', 'abs'),
    (0xB0, 'BCS', 'rel'), (0xB1, 'LDA', 'izy'), (0xB2, 'LDA', 'izp'),
    (0xB3, 'TST', 'tabx'), (0xB4, 'LDY', 'zpx'), (0xB5, 'LDA', 'zpx'),
    (0xB6, 'LDX', 'zpy'), (0xB8, 'CLV', 'imp'), (0xB9, 'LDA', 'aby'),
    (0xBA, 'TSX', 'imp'), (0xBC, 'LDY', 'abx'), (0xBD, 'LDA', 'abx'),
    (0xBE, 'LDX', 'aby'),
    (0xC0, 'CPY', 'imm'), (0xC1, 'CMP', 'izx'), (0xC2, 'CLY', 'imp'),
    (0xC3, 'TDD', 'blk'), (0xC4, 'CPY', 'zp'), (0xC5, 'CMP', 'zp'),
    (0xC6, 'DEC', 'zp'), (0xC8, 'INY', 'imp'), (0xC9, 'CMP', 'imm'),
    (0xCA, 'DEX', 'imp'), (0xCC, 'CPY', 'abs'), (0xCD, 'CMP', 'abs'),
    (0xCE, 'DEC', 'abs'),
    (0xD0, 'BNE', 'rel'), (0xD1, 'CMP', 'izy'), (0xD2, 'CMP', 'izp'),
    (0xD3, 'TIN', 'blk'), (0xD4, 'CSH', 'imp'), (0xD5, 'CMP', 'zpx'),
    (0xD6, 'DEC', 'zpx'), (0xD8, 'CLD', 'imp'), (0xD9, 'CMP', 'aby'),
    (0xDA, 'PHX', 'imp'), (0xDD, 'CMP', 'abx'), (0xDE, 'DEC', 'abx'),
    (0xE0, 'CPX', 'imm'), (0xE1, 'SBC', 'izx'), (0xE3, 'TIA', 'blk'),
    (0xE4, 'CPX', 'zp'), (0xE5, 'SBC', 'zp'), (0xE6, 'INC', 'zp'),
    (0xE8, 'INX', 'imp'), (0xE9, 'SBC', 'imm'), (0xEA, 'NOP', 'imp'),
    (0xEC, 'CPX', 'abs'), (0xED, 'SBC', 'abs'), (0xEE, 'INC', 'abs'),
    (0xF0, 'BEQ', 'rel'), (0xF1, 'SBC', 'izy'), (0xF2, 'SBC', 'izp'),
    (0xF3, 'TAI', 'blk'), (0xF4, 'SET', 'imp'), (0xF5, 'SBC', 'zpx'),
    (0xF6, 'INC', 'zpx'), (0xF8, 'SED', 'imp'), (0xF9, 'SBC', 'aby'),
    (0xFA, 'PLX', 'imp'), (0xFD, 'SBC', 'abx'), (0xFE, 'INC', 'abx'),
])
for i in range(8):
    OPS[0x07 + i * 0x10] = ('RMB%d' % i, 'zp')
    OPS[0x87 + i * 0x10] = ('SMB%d' % i, 'zp')
    OPS[0x0F + i * 0x10] = ('BBR%d' % i, 'zprel')
    OPS[0x8F + i * 0x10] = ('BBS%d' % i, 'zprel')


def longitud(op):
    e = OPS.get(op)
    return M[e[1]][1] if e else 1


def una(rom, off, pc):
    """Devuelve (texto, longitud) de la instruccion en rom[off], que corre en pc."""
    op = rom[off]
    e = OPS.get(op)
    if e is None:
        return '.db $%02X' % op, 1
    mn, md = e
    fmt, ln = M[md]
    b = rom[off:off + ln]
    if len(b) < ln:
        return '.db $%02X' % op, 1
    if md in ('imp', 'acc'):
        txt = mn + fmt
    elif md == 'rel':
        d = b[1] - 256 if b[1] > 127 else b[1]
        txt = mn + fmt.format((pc + 2 + d) & 0xFFFF)
    elif md == 'zprel':
        d = b[2] - 256 if b[2] > 127 else b[2]
        txt = mn + fmt.format(b[1], (pc + 3 + d) & 0xFFFF)
    elif md == 'blk':
        txt = mn + fmt.format(b[1] | b[2] << 8, b[3] | b[4] << 8, b[5] | b[6] << 8)
    elif md in ('tzp', 'tzpx'):
        txt = mn + fmt.format(b[1], b[2])
    elif md in ('tabs', 'tabx'):
        txt = mn + fmt.format(b[1], b[2] | b[3] << 8)
    elif ln == 2:
        txt = mn + fmt.format(b[1])
    else:
        txt = mn + fmt.format(b[1] | b[2] << 8)
    return txt, ln


def desensambla(rom, off, n, carga, etiquetas=None):
    """Lista de (offset_rom, pc, bytes_hex, texto)."""
    out, i = [], 0
    while i < n:
        pc = (carga + i) & 0xFFFF
        txt, ln = una(rom, off + i, pc)
        if etiquetas:
            for a, nom in etiquetas.items():
                if ('$%04X' % a) in txt:
                    txt += '   ; ' + nom
        out.append((off + i, pc, rom[off + i:off + i + ln].hex(), txt))
        i += ln
    return out


def imprime(rom, off, n, carga, etiquetas=None):
    for o, pc, hx, txt in desensambla(rom, off, n, carga, etiquetas):
        print('%05X  %04X  %-14s %s' % (o, pc, hx, txt))


if __name__ == '__main__':
    rom = open(sys.argv[1], 'rb').read()
    off = int(sys.argv[2], 16)
    n = int(sys.argv[3])
    carga = int(sys.argv[4], 16) if len(sys.argv) > 4 else (off & 0x1FFF) | 0xC000
    imprime(rom, off, n, carga)
