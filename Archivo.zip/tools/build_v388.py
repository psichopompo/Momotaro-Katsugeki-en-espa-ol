#!/usr/bin/env python3
"""build_v388.py - Devuelve el marco de los bocadillos de minijuego (v387 rota).

QUÉ PASÓ
--------
La v387 arregló el cuadrado de los cerezos con dos pasos:

  PASO 1  quitar el gancho $DFAE, que yo creí código muerto, y devolver
          0x4B0F y 0x4C07 a su contenido japonés.
  PASO 2  mover los 43 tiles del árbol de 0x04900 al banco $3F (0x7F900).

El paso 1 estaba MAL. El gancho $DFAE no era código muerto: carga el MARCO
del bocadillo de los minijuegos de Momotaro.

    0x4C07 -> MAWR $7B00 = celda $1EC   (4 celdas: bordes)
    0x4B0F -> MAWR $7E00 = celda $1F8   (2 celdas: lateral + rabillo)

Descomprimidas con tools/cg.py se ve el marco dibujado, rabillo incluido.
Ver entrada 238 del diario y normas 359-361.

ESTA VERSIÓN
------------
Deshace el paso 1 (vuelve el gancho) y CONSERVA el paso 2 (el árbol movido).

No hay conflicto entre las dos cosas: los bytes de 0x4B0F/0x4C07 caían dentro
del bloque del árbol VIEJO (0x04900-0x04E60), pero ese bloque ya no se lee,
porque el cargador $DB60 apunta ahora al banco $3F. Así que el marco vuelve
y los cerezos siguen limpios.
"""
import hashlib
import zlib

V386 = '/tmp/v386.pce'                              # tiene el gancho intacto
V387 = 'roms/Momotaro Katsugeki (Español).pce'      # tiene el árbol movido
DST = 'roms/momotaro_es_v388.pce'

rom = bytearray(open(V387, 'rb').read())
v386 = open(V386, 'rb').read()
orig = bytes(rom)

# ---- comprobar de dónde partimos ----------------------------------------
assert bytes(rom[0x1D955:0x1D958]) == bytes([0x20, 0xE2, 0xBA]), 'v387: $D955'
assert rom[0x1D95C] == 0x18, 'v387: LDY'
assert all(b == 0xFF for b in rom[0x1DFAE:0x1DFDE]), 'v387: cueva borrada'
assert rom[0x19B61] == 0x3F, 'v387: banco del árbol'
assert rom[0x19BD3] == 0x54, 'v387: base del árbol'

# ---- deshacer el PASO 1: que vuelva el gancho ----------------------------
TRAMOS = [
    (0x04B0F, 0x04B54, 'CG del marco: lateral + rabillo -> $1F8'),
    (0x04C07, 0x04C76, 'CG del marco: bordes -> $1EC'),
    (0x1D955, 0x1D95D, '$D955: JSR $DFAE y LDY #$24'),
    (0x1DFAE, 0x1DFDE, 'la cueva $DFAE que copia los dos streams'),
]
for a, b, _ in TRAMOS:
    rom[a:b] = v386[a:b]

# ---- el gancho tiene que quedar exactamente como en la v386 --------------
assert bytes(rom[0x1D955:0x1D958]) == bytes([0x20, 0xAE, 0xDF]), 'no volvió el JSR'
assert rom[0x1D95C] == 0x24, 'no volvió el LDY #$24'
assert bytes(rom[0x1DFAE:0x1DFDE]) == v386[0x1DFAE:0x1DFDE], 'cueva mal'

# ---- el PASO 2 sigue en pie ---------------------------------------------
assert rom[0x19B61] == 0x3F, 'se perdió el banco del árbol'
assert rom[0x19BD3] == 0x54, 'se perdió la base del árbol'
jp = open('roms/Momotarou Katsugeki (Japan).pce', 'rb').read()
assert bytes(rom[0x7F900:0x7F900 + 1376]) == jp[0x04900:0x04900 + 1376], \
    'el árbol movido ya no coincide con el japonés'

# ---- los glifos de David, intactos --------------------------------------
assert bytes(rom[0x4920:0x4970]) == v386[0x4920:0x4970], 'glifos $C2-$C6'

# ---- nada más se ha movido ----------------------------------------------
tocado = set()
for a, b, _ in TRAMOS:
    tocado |= set(range(a, b))
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos <= tocado, sorted(distintos - tocado)[:10]

open(DST, 'wb').write(bytes(rom))
print('%s  %d B' % (DST, len(rom)))
for a, b, q in TRAMOS:
    print('  restaurado 0x%05X-0x%05X  %s' % (a, b - 1, q))
print('  árbol: sigue en 0x7F900 (banco $3F)')
print('  bytes cambiados respecto a la v387: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
