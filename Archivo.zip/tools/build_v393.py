#!/usr/bin/env python3
"""build_v393.py - Igual que la v392, pero SIN pisar el byte de código de 0x4B93B.

QUÉ SE HACE (lo mismo que la v392)
----------------------------------
1. El motor del minijuego pasa de 2 a 3 líneas (un byte).
2. El mensaje A se mueve a un hueco libre para que quepa la frase entera.
3. Los dos mensajes quedan traducidos, con «¡Mira allá!» completo.

    A) «¡Piedra, papel / o tijeras! / ¡Mira allá!»
    B) «¡Iguales! / ¡Mira allá!»

QUÉ CAMBIA RESPECTO A LA v392 (entrada 260 del diario)
------------------------------------------------------
En la v392 puse B_TOPE = 0x4B93C creyendo que el código del banco $25
empezaba ahí. Empieza en **0x4B93B**: el `LDA $DD` (`A5 DD`) de $793B.
El relleno `$A0` con que tapo el sobrante del bloque B llegaba hasta
0x4B93B **inclusive** y convertía ese `A5` (`LDA $DD`) en `A0`
(`LDY #$DD`), que NO carga el acumulador.

$793B es la cabecera del intérprete de texto: comprueba si queda un
nivel de anidamiento pendiente (`LDA $DD / BEQ $799F`) al entrar por
`JSR $793B` desde $41807 y $4B9F3, y por `JMP $793B` desde $79AC.
Con `LDY #$DD` el flag Z queda con la basura que trajera A, así que la
rama `BEQ $799F` se toma o no según el azar del acumulador anterior:
por eso el juego se saltaba UN carácter al principio de un diálogo y,
al releerlo, con el acumulador ya en otro estado, salía entero.

Aquí:
  - B_TOPE pasa a 0x4B93B (el relleno para UN byte antes).
  - El assert de «no se ha pisado el código» arranca en 0x4B93B, no en
    0x4B93C, y compara contra la ROM original.
  - Assert extra explícito: rom[0x4B93B] == 0xA5 (norma 371).

El presupuesto de B baja de 52 a 51 bytes. B ocupa 22: sigue holgado.

LO QUE COSTÓ ENCONTRAR (entrada 258)
------------------------------------
Los punteros del minijuego están escritos como inmediatos en el banco $08:

    $DD1B  LDA #$08 / STA $BF ; LDA #$79 / STA $C0   -> $7908  (mensaje A)
    $DD26  LDA #$23 / STA $BF ; LDA #$79 / STA $C0   -> $7923  (mensaje B)

Cada mensaje tiene su propio puntero y se pueden mover por separado.

EL REPARTO
----------
    A (38 B) -> 0x4B826, hueco de 55 B entre dos mensajes (sobran 17)
    B (22 B) -> 0x4B908, 51 B hasta el código (sobran 29)

ANCHO: 14 columnas por línea, medido en pantalla.
CHARSET: `charset_oficial` (la `p` es $5E; con $B0 salía «ÇaÇel»).
CONTROLES: $00 pausa · $80 fin de línea · $FF fin de mensaje.
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
import charset_oficial as co

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v391
DST = 'roms/momotaro_es_v393.pce'

LINEAS = 0x106E3          # LDX #$02 -> #$03
A_DEST, A_TOPE = 0x4B826, 0x4B85D     # hueco de 55 B
B_DEST, B_TOPE = 0x4B908, 0x4B93B     # 51 B: el código empieza EN 0x4B93B
CODIGO = 0x4B93B                      # $793B  LDA $DD  (A5 DD)
PA_LO, PA_HI = 0x11D1C, 0x11D20       # puntero del mensaje A
PB_LO, PB_HI = 0x11D27, 0x11D2B       # puntero del mensaje B
ANCHO = 14


def e(s):
    out = bytearray()
    for c in s:
        if c not in co.CHAR_TO_CODE:
            raise ValueError('carácter sin código: %r' % c)
        out.append(co.CHAR_TO_CODE[c])
    return bytes(out)


def monta(lineas):
    """lineas -> bytes, con $80 entre ellas y $FF al final."""
    out = b''
    for i, l in enumerate(lineas):
        assert len(l) <= ANCHO, 'línea de %d columnas: %r' % (len(l), l)
        out += e(l) + bytes([0xFF if i == len(lineas) - 1 else 0x80])
    return out


rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)

# ---- 0. el estado de partida es el que creo -------------------------------
assert rom[LINEAS] == 0x02, 'en 0x%05X no hay un LDX #$02' % LINEAS
assert rom[PA_LO] == 0x08 and rom[PA_HI] == 0x79, 'el puntero A no es $7908'
assert rom[0x11D27] == 0x23 and rom[0x11D2B] == 0x79, 'el puntero B no es $7923'
assert all(b == 0xA0 for b in rom[A_DEST:A_TOPE]), 'el hueco 0x4B826 no está limpio'
assert rom[A_DEST - 1] == 0x00, 'antes del hueco no hay un terminador'
# NORMA 371: el primer byte del código, identificado y comprobado ANTES
assert orig[CODIGO:CODIGO + 2] == b'\xA5\xDD', (
    'en 0x%05X no está el LDA $DD que abre el intérprete de texto' % CODIGO)
vecino = bytes(rom[A_TOPE:A_TOPE + 16])

A = monta(['¡Piedra, papel', 'o tijeras!', '¡Mira allá!'])
B = monta(['¡Iguales!', '¡Mira allá!'])

assert len(A) <= A_TOPE - A_DEST, 'A: %d B, caben %d' % (len(A), A_TOPE - A_DEST)
assert len(B) <= B_TOPE - B_DEST, 'B: %d B, caben %d' % (len(B), B_TOPE - B_DEST)

# ---- 1. tres líneas -------------------------------------------------------
rom[LINEAS] = 0x03

# ---- 2. el mensaje A al hueco, y su puntero -------------------------------
rom[A_DEST:A_TOPE] = A + bytes([0xA0]) * (A_TOPE - A_DEST - len(A))
rom[PA_LO] = A_DEST & 0xFF                    # $26
rom[PA_HI] = 0x60 + ((A_DEST >> 8) & 0x1F)    # $78  (CPU $7826)
assert rom[PA_LO] == 0x26 and rom[PA_HI] == 0x78, 'el puntero A no quedó en $7826'

# ---- 3. el mensaje B, al principio del bloque que deja libre A ------------
rom[B_DEST:B_TOPE] = B + bytes([0xA0]) * (B_TOPE - B_DEST - len(B))
rom[PB_LO] = B_DEST & 0xFF                      # $08
rom[PB_HI] = 0x60 + ((B_DEST >> 8) & 0x1F)      # $79  (CPU $7908)
assert rom[PB_LO] == 0x08 and rom[PB_HI] == 0x79, 'el puntero B no quedó en $7908'

# ---- 4. nada ajeno se ha tocado -------------------------------------------
assert bytes(rom[A_TOPE:A_TOPE + 16]) == vecino, 'se ha pisado el mensaje vecino'
# el assert que faltaba en la v392: empieza EN 0x4B93B
assert bytes(rom[CODIGO:0x4B960]) == orig[CODIGO:0x4B960], 'se ha pisado el código'
assert rom[CODIGO:CODIGO + 2] == b'\xA5\xDD', 'el LDA $DD de $793B sigue roto'
tocado = (set(range(A_DEST, A_TOPE)) | set(range(B_DEST, B_TOPE))
          | {LINEAS, PA_LO, PA_HI, PB_LO, PB_HI})
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos <= tocado, sorted(distintos - tocado)[:8]

# ---- 5. NORMA 370: leer el texto DESDE el puntero, no desde donde escribí --
def texto_en(lo, hi):
    cpu = rom[lo] | rom[hi] << 8
    off = 0x25 * 0x2000 + (cpu & 0x1FFF)
    fin = off
    while rom[fin] != 0xFF:
        fin += 1
    return bytes(rom[off:fin + 1])

assert texto_en(PA_LO, PA_HI) == A, 'el puntero A no lee el mensaje A'
assert texto_en(PB_LO, PB_HI) == B, 'el puntero B no lee el mensaje B'

open(DST, 'wb').write(bytes(rom))
print('%s  %d B' % (DST, len(rom)))
print('  0x%05X  LDX #$02 -> #$03   (tres líneas)' % LINEAS)
print('  A 0x%05X (%2d/%d B)  «¡Piedra, papel» / «o tijeras!» / «¡Mira allá!»'
      % (A_DEST, len(A), A_TOPE - A_DEST))
print('  B 0x%05X (%2d/%d B)  «¡Iguales!» / «¡Mira allá!»'
      % (B_DEST, len(B), B_TOPE - B_DEST))
print('  puntero A: $7908 -> $7826   puntero B: $7923 -> $7908')
print('  0x%05X intacto: %s  (LDA $DD de $793B)'
      % (CODIGO, rom[CODIGO:CODIGO + 2].hex()))
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
