"""fuente_menu.py - Formato de la fuente del MENÚ (la del fallback).

NO CONFUNDIR CON LA DEL DIÁLOGO
-------------------------------
    fuente DIÁLOGO   banco $1E   ROM 0x3D660   8 B/glifo   1 plano
    fuente MENÚ      banco $02   ROM 0x4000   16 B/glifo   2 planos

El renderer mapea el banco con TAM antes de leer:
    ruta tabla     $AAEA: LDA #$1E / CLC / ADC $20 / TAM #$04
    ruta fallback  $AB2C: LDA #$02 / CLC / ADC $20 / TAM #$04

Dirección: ROM = 0x4000 + ((byte - 0x30) & 0xFF) * 16

QUÉ ES EL SEGUNDO PLANO (medido, no supuesto)
---------------------------------------------
Los bytes 8..15 son la SOMBRA del cuerpo, proyectada a derecha-abajo:

    plano1 = dilatar(plano0, {(+1,0), (0,+1), (+1,+1)}) - plano0

Contrastado contra las 26 letras A-Z y los 10 dígitos: **34 de 36 exactos**.
Las 2 excepciones (la 'A' y los dígitos '3' y '5') difieren en UN píxel,
siempre dentro de un hueco cerrado del propio dibujo, donde el grafista
borró la sombra a mano por estética. Ninguna difiere por exceso: el plano1
nunca tiene píxeles fuera de la sombra calculada.

Se descartaron por medición: contorno de 8 vecinos (0/26), 4 vecinos
(0/26), sólo derecha+abajo sin diagonal (0/26), e izquierda-arriba (0/26).
"""

BASE = 0x4000       # con el banco $02 mapeado en $4000-$5FFF
STRIDE = 16
SOMBRA = ((1, 0), (0, 1), (1, 1))


def rom_off(byte):
    """Dirección de ROM del glifo que dibuja ese byte de texto."""
    return BASE + ((byte - 0x30) & 0xFF) * STRIDE


def encode(arte):
    """Arte ASCII de 8x8 -> 16 bytes (cuerpo + sombra calculada).

    La sombra se genera, no se dibuja a mano: así es imposible que
    quede incoherente con el cuerpo.
    """
    if len(arte) != 8:
        raise ValueError(f'se esperaban 8 filas, hay {len(arte)}')
    cuerpo = set()
    for y, fila in enumerate(arte):
        if len(fila) != 8:
            raise ValueError(f'fila de {len(fila)} px: {fila!r}')
        for x, c in enumerate(fila):
            if c == '#':
                cuerpo.add((x, y))
            elif c != '.':
                raise ValueError(f'caracter no valido: {c!r}')

    sombra = set()
    for (x, y) in cuerpo:
        for dx, dy in SOMBRA:
            sombra.add((x + dx, y + dy))
    sombra = {p for p in sombra - cuerpo if 0 <= p[0] < 8 and 0 <= p[1] < 8}

    def empaqueta(s):
        return bytes(sum(1 << (7 - x) for x in range(8) if (x, y) in s)
                     for y in range(8))

    return empaqueta(cuerpo) + empaqueta(sombra)


def render(d16):
    """16 bytes -> arte ASCII. '#'=cuerpo 'o'=sombra '.'=vacío"""
    out = []
    for y in range(8):
        fila = ''
        for x in range(8):
            c = (d16[y] >> (7 - x)) & 1
            s = (d16[8 + y] >> (7 - x)) & 1
            fila += '#' if c else ('o' if s else '.')
        out.append(fila)
    return out


def comprueba_regla(rom, byte):
    """Devuelve (cuadra, faltan, sobran) para un glifo ya existente."""
    off = rom_off(byte)
    d = rom[off:off + 16]
    cuerpo = {(x, y) for y in range(8) for x in range(8)
              if (d[y] >> (7 - x)) & 1}
    real = {(x, y) for y in range(8) for x in range(8)
            if (d[8 + y] >> (7 - x)) & 1}
    esp = set()
    for (x, y) in cuerpo:
        for dx, dy in SOMBRA:
            esp.add((x + dx, y + dy))
    esp = {p for p in esp - cuerpo if 0 <= p[0] < 8 and 0 <= p[1] < 8}
    return esp == real, sorted(esp - real), sorted(real - esp)
