#!/usr/bin/env python3
"""
rutina_v158.py - la rutina de escritura inmediata del bocadillo 20x4.

POR QUE
-------
El motor acumulaba cada caracter en un buffer de RAM de 36 celdas
($3667..$368A) y lo volcaba al final con $9B7C. Para 20x4 harian falta 80
celdas y NO existen: no hay ninguna racha de 80 B libre en los 8 KB de RAM
(cruzado el indice de referencias con los 7 states), y ampliar el buffer
hacia arriba choca con $368B-$368F, que son las COORDENADAS del bocadillo y
tienen 20 punteros en 3 bancos.

La salida es no acumular: escribir cada caracter en VRAM en el momento.
Es seguro porque $9D33 ya llama a $E185 (LDA $0000 / AND #$40 / BNE), o sea
que el motor YA espera al VDC celda a celda; escribir en el momento no
cambia el patron de acceso.

DONDE VA
--------
En $9B7C, el hueco de 65 B que deja el bucle de volcado al desaparecer.
Los dos `STA $3667,X` de $9883 y $9892 pasan a ser `JSR $9B7C` (3 B por 3 B).

ENTRADA
-------
    $10 = glifo a dibujar
    X   = indice de celda 0..79   (fila*20 + posicion)

LO QUE HACE (copiado de $9B84..$9BB6, que es el volcado original)
-----------------------------------------------------------------
    origen  $3661/$3662 = $5660 + glifo*8      (16 bits, ASL/ROL x3)
    destino $3663/$3664 = tabla[col/2] + (fila/2)*$80
    cuad    $3665       = (fila&1)*2 + (col&1)
    JSR $9D33

La division entre 20 se hace por restas sucesivas: 4 vueltas como maximo,
mas barato que una tabla y no hace falta multiplicador.
"""

TABLA = 0x9BBD      # tabla de columnas (10 entradas de 2 B)


def ensamblar(tabla=TABLA):
    c = []

    def E(*b):
        c.extend(b)

    # --- fila = X / 20, col = X % 20 ---------------------------------
    E(0x8A)                     # TXA
    E(0x64, 0x13)               # STZ $13          fila = 0
    # bucle: while A >= 20 { A -= 20; fila++ }
    E(0xC9, 20)                 # CMP #20
    E(0x90, 0x07)               # BCC +7  -> fin del bucle
    E(0x38)                     # SEC
    E(0xE9, 20)                 # SBC #20
    E(0xE6, 0x13)               # INC $13
    E(0x80, 0xF5)               # BRA -11 -> CMP
    E(0xAA)                     # TAX              X = col

    # --- cuadrante = (fila&1)*2 + (col&1) -----------------------------
    E(0xA5, 0x13)               # LDA $13
    E(0x29, 0x01)               # AND #$01
    E(0x0A)                     # ASL A            (fila&1)*2
    E(0x85, 0x12)               # STA $12
    E(0x8A)                     # TXA
    E(0x29, 0x01)               # AND #$01         col&1
    E(0x05, 0x12)               # ORA $12
    E(0x8D, 0x65, 0x36)         # STA $3665

    # --- destino = tabla[col/2] + (fila/2)*$80 ------------------------
    E(0x8A)                     # TXA
    E(0x4A)                     # LSR A            col/2
    E(0x0A)                     # ASL A            *2 (indice de word)
    E(0xA8)                     # TAY
    E(0xB9, tabla & 0xFF, tabla >> 8)          # LDA tabla,Y
    E(0x8D, 0x63, 0x36)         # STA $3663
    E(0xC8)                     # INY
    E(0xB9, tabla & 0xFF, tabla >> 8)          # LDA tabla,Y
    E(0x8D, 0x64, 0x36)         # STA $3664
    # + (fila/2)*$80  -> el byte alto suma (fila/2)/2, el bajo $80 si impar
    E(0xA5, 0x13)               # LDA $13
    E(0x4A)                     # LSR A            fila/2
    E(0x4A)                     # LSR A            (fila/2)/2  -> acarreo
    E(0x90, 0x0E)               # BCC +14 -> salta a STZ $15 (sin sumar $80)
    E(0xAD, 0x63, 0x36)         # LDA $3663
    E(0x18)                     # CLC
    E(0x69, 0x80)               # ADC #$80
    E(0x8D, 0x63, 0x36)         # STA $3663
    E(0x90, 0x03)               # BCC +3
    E(0xEE, 0x64, 0x36)         # INC $3664

    # --- origen del glifo: $5660 + glifo*8 ----------------------------
    E(0x64, 0x15)               # STZ $15
    E(0xA5, 0x10)               # LDA $10
    for _ in range(3):
        E(0x0A)                 # ASL A
        E(0x26, 0x15)           # ROL $15
    E(0x18)                     # CLC
    E(0x69, 0x60)               # ADC #$60
    E(0x8D, 0x61, 0x36)         # STA $3661
    E(0xA5, 0x15)               # LDA $15
    E(0x69, 0x56)               # ADC #$56
    E(0x8D, 0x62, 0x36)         # STA $3662

    E(0x20, 0x33, 0x9D)         # JSR $9D33
    E(0x60)                     # RTS
    return bytes(c)


if __name__ == '__main__':
    r = ensamblar()
    print('rutina de escritura inmediata: %d bytes' % len(r))
    print('hueco disponible en $9B7C: 65 bytes')
    print('  %s' % ('CABE' if len(r) <= 65 else 'NO CABE, sobran %d' % (len(r) - 65)))
    print()
    print(r.hex())
