"""render_rotulos.py - Renderizador de rotulos leyendo la ROM.

CORRECCION IMPORTANTE (v138): las celdas de TEXTO aportan su propio fondo
blanco. El juego limpia su CG a blanco (bucle $AD7A: 4 x JSR $FC43 escribe
00,FF,FF,00 = indice 6 = blanco) y luego pinta el glifo encima.

La version anterior de este script pintaba solo los glifos, sin el fondo.
Por eso dijo «sin huecos» donde David veia un hueco de 4 px: el hueco es
justamente la franja que NINGUNA celda de texto cubre, y sin pintar el
fondo de las celdas era invisible para el script.

Norma 60 aplicada: un simulador solo vale cuando reproduce el fallo.
"""
import sys, os
from PIL import Image

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
from charset_oficial import CHAR_TO_CODE

BLANCO = (255, 255, 255)
NEGRO = (24, 24, 24)
COL = {4: BLANCO, 6: BLANCO, 7: NEGRO}


class Render:
    def __init__(self, rom_path):
        self.rom = open(rom_path, 'rb').read()
        self.vm = open(os.path.join(RAIZ, 'docs', 'mapa_vram.bin'), 'rb').read()
        self.va = open(os.path.join(RAIZ, 'docs', 'aldea_vram.bin'), 'rb').read()
        self._cs()

    def _cs(self):
        rom = self.rom
        g2c = {}
        for c, k in CHAR_TO_CODE.items():
            gi = rom[0x43F9B + (k - 0x30)] if 0x30 <= k <= 0x65 else k
            if gi and gi not in g2c:
                g2c[gi] = c
        m = {}
        for i in range(0x36):
            gi = rom[0x42B5B + i]
            cod = 0x30 + i
            if gi and cod != 0x5C:
                c = g2c.get(gi)
                if c and c not in m:
                    m[c] = cod
        o = 0x40000 + (0x9CB3 - 0x8000)
        for i in range(0x40):
            gi = rom[o + i]
            if gi:
                c = g2c.get(gi)
                if c and c not in m:
                    m[c] = 0xA0 + i
        m[' '] = 0x20
        self.C = m
        self.REMAP = {}
        i = 0
        while rom[0x42B4C + i]:
            self.REMAP[rom[0x42B4C + i]] = rom[0x42B54 + i]
            i += 1

    def glifo(self, ch):
        k = self.REMAP.get(self.C[ch], self.C[ch])
        gi = (self.rom[0x42B5B + (k - 0x30)] if 0x30 <= k <= 0x65
              else self.rom[0x40000 + (0x9CB3 - 0x8000) + (k - 0xA0)])
        o = 0x3D660 + gi * 8
        return [self.rom[o + y] for y in range(8)]

    def tile16(self, v, u):
        o = u * 64
        px = [[0] * 16 for _ in range(16)]
        for y in range(16):
            p = [v[o + k * 32 + y * 2] | (v[o + k * 32 + y * 2 + 1] << 8) for k in range(4)]
            for x in range(16):
                b = 15 - x
                px[y][x] = sum(((p[k] >> b) & 1) << k for k in range(4))
        return px

    def caja(self, v, img, off, base, ax, ay, solo=None):
        """solo: filtra por dy, para respetar el z-order al pintar por capas."""
        rom = self.rom
        o = off
        while rom[o] != 0xFF:
            rel, alo, ahi, dx, dy = rom[o:o + 5]
            if solo is not None and dy not in solo:
                o += 5
                continue
            pat = base + (rel << 1)
            dxs = dx - 256 if dx > 127 else dx
            attr = alo | (ahi << 8)
            w = 32 if (ahi & 1) else 16
            hf, vf = bool(attr & 0x0800), bool(attr & 0x8000)
            X, Y = ax + dxs, (ay + dy) & 0xFF
            for i in range(w // 16):
                t = self.tile16(v, pat + i * 2)
                for yy in range(16):
                    for xx in range(16):
                        c = t[yy][xx]
                        if c not in COL:
                            continue
                        sx = X + ((w - 16 - i * 16) if hf else i * 16) + ((15 - xx) if hf else xx)
                        sy = Y + ((15 - yy) if vf else yy)
                        if 0 <= sx < 256 and 0 <= sy < 256:
                            img.putpixel((sx, sy), COL[c])
            o += 5

    def texto(self, img, off, ax, ay, txt):
        """Cada celda pinta 16x16 de FONDO BLANCO y encima los glifos."""
        rom = self.rom
        o = off
        celda = 0
        while rom[o] != 0xFF:
            rel, alo, ahi, dx, dy = rom[o:o + 5]
            dxs = dx - 256 if dx > 127 else dx
            X, Y = ax + dxs, (ay + dy) & 0xFF
            for yy in range(16):
                for xx in range(16):
                    sx, sy = X + xx, Y + yy
                    if 0 <= sx < 256 and 0 <= sy < 256:
                        img.putpixel((sx, sy), BLANCO)
            for mitad in range(2):
                ch = txt[celda] if celda < len(txt) else ' '
                g = self.glifo(ch)
                for yy in range(8):
                    fila = g[yy]
                    for xx in range(8):
                        if (fila >> (7 - xx)) & 1:
                            sx, sy = X + mitad * 8 + xx, Y + 4 + yy
                            if 0 <= sx < 256 and 0 <= sy < 256:
                                img.putpixel((sx, sy), NEGRO)
                celda += 1
            o += 5


NOMBRES = ['Aldea de la Partida', 'Aldea Florecer', 'Aldea Kintaro',
           'Aldea Dormilón', 'Aldea Urashima', 'Aldea Kachiyama',
           'Aldea Issunboshi', 'Aldea Bambú', 'Isla Ogros']
TODOS = NOMBRES + ['COMIENZA EL JUEGO']


def r0E(l):
    return l - 0xC000 + 0x1C000


def r17(l):
    return l - 0x4000 + 0x2E000


def escenas(R, layout):
    """layout: dict con los offsets de las tablas (cambian entre versiones)."""
    rom = R.rom
    out = []
    M = layout['M']
    T_ANC, T_IDXC, T_IDXT = M, M + 8, M + 16
    T_PTRC = M + 24
    T_PTRT = T_PTRC + 4 * layout['ncaj_m']
    anc = list(rom[T_ANC:T_ANC + 8])
    ic = list(rom[T_IDXC:T_IDXC + 8])
    it = list(rom[T_IDXT:T_IDXT + 8])
    for loc in range(8):
        img = Image.new('RGB', (256, 256), (120, 190, 140))
        pc = T_PTRC + ic[loc] * 4
        c1 = rom[pc] | (rom[pc + 1] << 8)
        c2 = rom[pc + 2] | (rom[pc + 3] << 8)
        pt = T_PTRT + it[loc] * 2
        t1 = rom[pt] | (rom[pt + 1] << 8)
        # el PCE dibuja el indice BAJO encima: se pinta en orden INVERSO
        # al de emision (caja_sup, texto, rabito, caja_inf).
        R.caja(R.vm, img, r0E(c2), 0x0348, anc[loc], 216)
        R.texto(img, r0E(t1), anc[loc], 216, NOMBRES[loc + 1])
        R.caja(R.vm, img, r0E(c1), 0x0348, anc[loc], 216)
        out.append(('MAPA  ' + NOMBRES[loc + 1], img.crop((0, 146, 256, 194))))
    A = layout['A']
    TA_IDXC, TA_IDXT = A, A + 10
    TA_PTRC = A + 20
    TA_PTRT = TA_PTRC + 2 * layout['ncaj_a']
    ica = list(rom[TA_IDXC:TA_IDXC + 10])
    ita = list(rom[TA_IDXT:TA_IDXT + 10])
    for i in range(10):
        img = Image.new('RGB', (256, 256), (120, 180, 235))
        pc = TA_PTRC + ica[i] * 2
        c = rom[pc] | (rom[pc + 1] << 8)
        pt = TA_PTRT + ita[i] * 2
        t = rom[pt] | (rom[pt + 1] << 8)
        # emision: texto -> caja. Se pinta al reves.
        R.caja(R.va, img, r17(c), 0x03C0, 128, 96)
        R.texto(img, r17(t), 128, 96, TODOS[i])
        out.append(('ALDEA ' + TODOS[i], img.crop((0, 92, 256, 140))))
    return out


def analiza(img):
    """devuelve (huecos, margen_izq, margen_der) medidos como en las capturas."""
    import numpy as np
    a = np.array(img.convert('RGB'))
    w = (a[:, :, 0] > 240) & (a[:, :, 1] > 240) & (a[:, :, 2] > 240)
    k = (a[:, :, 0] < 40) & (a[:, :, 1] < 40) & (a[:, :, 2] < 40)
    fil = [y for y in range(a.shape[0]) if w[y].sum() > 20]
    if not fil:
        return None
    # Solo se miden las filas SIN letras: en las filas con glifos el negro
    # parte el blanco y eso no es un hueco de fondo.
    #   filas 0..3 y las 4 ultimas son el borde redondeado de la caja, que
    #   legitimamente no es continuo. Se excluyen tambien.
    # Medido sobre las capturas reales de David: el borde redondeado ocupa
    # las 4 primeras y 4 ultimas filas de la caja; la BANDA es lo de en
    # medio. En la banda, las filas sin glifo deben ser blanco continuo.
    # Medido sobre las capturas de David: el borde redondeado ocupa las 4
    # primeras y 4 ultimas filas; la BANDA es lo de en medio. Un hueco de
    # fondo se distingue de un glifo en que aparece en TODAS las filas de
    # la banda, incluidas las que no tienen letra encima.
    y0, y1 = fil[0], fil[-1]
    cuenta = {}
    nb = 0
    for y in range(y0 + 4, y1 - 3):
        nb += 1
        xs = np.where(w[y])[0]
        d = np.diff(xs)
        for i in np.where(d > 1)[0]:
            cuenta[(int(xs[i]) + 1, int(xs[i + 1]) - 1)] = \
                cuenta.get((int(xs[i]) + 1, int(xs[i + 1]) - 1), 0) + 1
    huecos = [(n, a, b) for (a, b), n in sorted(cuenta.items()) if n == nb]
    ymid = fil[len(fil) // 2]
    negros = [x for x in range(a.shape[1]) if k[ymid, x]]
    bi, bd = (negros[0], negros[-1]) if negros else (0, 0)
    ytx = range(fil[0] + 8, fil[-1] - 7)
    cols = [x for x in range(a.shape[1]) if any(k[y, x] for y in ytx)]
    letras = [x for x in cols if bi < x < bd]
    li, ld = (letras[0], letras[-1]) if letras else (bi, bd)
    return huecos, li - bi, bd - ld


if __name__ == '__main__':
    rom_path = sys.argv[1]
    salida = sys.argv[2] if len(sys.argv) > 2 else None
    lay = {'M': 0x1DC88, 'ncaj_m': int(sys.argv[3]) if len(sys.argv) > 3 else 4,
           'A': 0x2FB8C, 'ncaj_a': int(sys.argv[4]) if len(sys.argv) > 4 else 6}
    R = Render(rom_path)
    esc = escenas(R, lay)
    print('%-28s %-28s %s' % ('rotulo', 'huecos de fondo', 'margen izq/der'))
    malos = 0
    for nom, img in esc:
        h, mi, md = analiza(img)
        if h:
            malos += 1
            det = 'HUECO %d px en x %d..%d' % (h[0][2] - h[0][1] + 1, h[0][1], h[0][2])
        else:
            det = 'ninguno'
        print('%-28s %-28s %2d / %2d%s' % (nom, det, mi, md, '   <-- asimetrico' if abs(mi - md) > 1 else ''))
    print('\n%d rotulos con hueco de %d' % (malos, len(esc)))
    if salida:
        out = Image.new('RGB', (256, 49 * len(esc)), (0, 0, 0))
        for i, (nom, img) in enumerate(esc):
            out.paste(img, (0, i * 49))
        out.resize((512, out.height * 2), Image.NEAREST).save(salida)
        print('escrito', salida)
