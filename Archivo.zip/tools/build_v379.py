#!/usr/bin/env python3
"""build_v379.py - Instala las vocales acentuadas DE DAVID en las dos fuentes.

BASE: v378 (1365880066e469d4f1e2c2721f061299)

QUÉ HACE
--------
David dibujó las cinco mayúsculas acentuadas (`Vocales tilde.png`, 40x8,
5 glifos de 8x8) y pidió instalarlas tal cual. Se instalan en:

    fuente DIÁLOGO  banco $1E  ROM 0x3D660 + glifo*8   8 B/glifo   1bpp
    fuente MENÚ     banco $02  ROM 0x4000 + (g-$30)*16 16 B/glifo  2bpp

Los códigos son los que ya usa el pack de créditos del final Difícil:

    Á=$C2  É=$C3  Í=$C4  Ó=$C5  Ú=$C6

RECTIFICACIÓN (error mío del mensaje anterior)
----------------------------------------------
Escribí que «faltan los glifos de las mayúsculas acentuadas». **Falso.**
Las cinco ya estaban instaladas desde la v376/v378, la `Ú` incluida
(`0x3DC90` = `0c c6 c6 c6 c6 c6 7c 00`). Lo dije sin comprobarlo: había
visto «MUSICA» sin tilde en una captura y salté a la conclusión de que no
existía el glifo, cuando lo que pasaba es que esa captura era de otra
ficha. El log ya lo decía y no lo leí antes de opinar.

Lo que sí es cierto y sigue en pie: los glifos de la v378 tienen trazo de
1 px y las mayúsculas nativas del juego lo tienen de 2 px, y por eso
desentonan. Los de David lo arreglan con trazo grueso.

LO QUE APORTAN LOS GLIFOS DE DAVID (medido)
-------------------------------------------
    - Cuerpo en filas 2..6, **base en la fila 6**: la misma línea base que
      las mayúsculas nativas ($70..$89). No se descuelgan.
    - Tilde diagonal de 2 px en las filas 0..1, con aire respecto al cuerpo.
    - Trazo de 2 px, igual que el resto del alfabeto.

HALLAZGO: la Á del MENÚ estaba corrupta
---------------------------------------
`0x04920` (la `Á` de la fuente de menú 2bpp) no era una letra: eran
píxeles sueltos sin forma (`o...ooo. / .......o / o...oo.. / ...`).
Al instalar la de David se arregla de paso.

LA SOMBRA NO SE DIBUJA, SE CALCULA
----------------------------------
La fuente de menú es 2bpp: bytes 0..7 cuerpo, 8..15 sombra proyectada a
derecha-abajo. `fuente_menu.encode()` la genera con la regla medida
(34 de 36 letras exactas), así que es imposible que quede incoherente.
"""
import hashlib
import sys
import zlib
from pathlib import Path

sys.path.insert(0, 'tools')
from fuente_menu import encode as enc_menu, rom_off as menu_off   # noqa: E402

BASE = 'roms/momotaro_es_v378.pce'
MD5_BASE = '1365880066e469d4f1e2c2721f061299'
PNG = '/home/user/descargas/v378/vocales_tilde.png'

DIAL = 0x3D660                     # fuente de diálogo, 8 B/glifo, 1bpp
CODIGOS = {'A': 0xC2, 'E': 0xC3, 'I': 0xC4, 'O': 0xC5, 'U': 0xC6}
NATIVAS = {'A': 0x70, 'E': 0x74, 'I': 0x78, 'O': 0x7E, 'U': 0x84}

# zonas que este parche NO puede tocar
INTACTAS = [
    (0x00000, 0x04900, 'todo lo anterior a la fuente de menú'),
    (0x04970, 0x3DC70, 'de la fuente de menú a la de diálogo: TODO el juego'),
    (0x3DC98, 0x80000, 'de la fuente de diálogo al final'),
]


def lee_png():
    """El PNG de David: 40x8 = 5 glifos de 8x8. Alfa>128 = píxel."""
    from PIL import Image
    im = Image.open(PNG).convert('RGBA')
    assert im.size == (40, 8), 'el PNG mide %s, esperaba (40, 8)' % (im.size,)
    px = im.load()
    arte = {}
    for gi, L in enumerate('AEIOU'):
        arte[L] = [''.join('#' if px[x, y][3] > 128 else '.'
                           for x in range(gi * 8, gi * 8 + 8))
                   for y in range(8)]
    return arte


def enc_1bpp(arte):
    return bytes(int(''.join('1' if c == '#' else '0' for c in fila), 2)
                 for fila in arte)


def base_de(arte):
    """Última fila con píxel: la línea base del glifo."""
    return max(i for i, r in enumerate(arte) if '#' in r)


def main(salida):
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v378'
    assert len(rom) == 524288, 'la ROM no mide 512 KB'

    arte = lee_png()

    # ---- 0. los glifos de David respetan la línea base del juego -------
    for L in 'AEIOU':
        o = DIAL + NATIVAS[L] * 8
        nat = [''.join('#' if rom[o + y] >> (7 - x) & 1 else '.'
                       for x in range(8)) for y in range(8)]
        bn, bd = base_de(nat), base_de(arte[L])
        assert bn == bd, \
            '%s: la nativa tiene la base en %d y la de David en %d' % (L, bn, bd)
        assert arte[L][7] == '........', '%s usa la fila 7' % L

    # ---- 1. estado de partida: los 5 glifos YA existen (no los invento) -
    for L, g in CODIGOS.items():
        o = DIAL + g * 8
        assert any(rom[o:o + 8]), \
            'el glifo %s ($%02X) estaba vacío: la ROM no es la que creo' % (L, g)

    # ---- 2. instalar en la fuente de DIÁLOGO (1bpp) --------------------
    for L, g in CODIGOS.items():
        b = enc_1bpp(arte[L])
        assert len(b) == 8
        rom[DIAL + g * 8:DIAL + g * 8 + 8] = b

    # ---- 3. instalar en la fuente de MENÚ (2bpp, sombra calculada) -----
    for L, g in CODIGOS.items():
        b = enc_menu(arte[L])
        assert len(b) == 16
        o = menu_off(g)
        assert 0x04900 <= o < 0x04970, 'glifo de menú fuera de sitio: 0x%05X' % o
        rom[o:o + 16] = b

    # ---- VERIFICACIÓN: releer y comparar con el PNG --------------------
    for L, g in CODIGOS.items():
        o = DIAL + g * 8
        rel = [''.join('#' if rom[o + y] >> (7 - x) & 1 else '.'
                       for x in range(8)) for y in range(8)]
        assert rel == arte[L], 'el glifo %s releído no es el de David' % L
        om = menu_off(g)
        cuerpo = [''.join('#' if rom[om + y] >> (7 - x) & 1 else '.'
                          for x in range(8)) for y in range(8)]
        assert cuerpo == arte[L], 'el cuerpo de menú de %s no cuadra' % L

    # la sombra del menú sigue la regla medida
    from fuente_menu import comprueba_regla
    for L, g in CODIGOS.items():
        ok, faltan, sobran = comprueba_regla(rom, g)
        assert ok, 'la sombra de %s no cuadra: faltan=%s sobran=%s' % (
            L, faltan, sobran)

    # las mayúsculas NATIVAS no se han tocado
    for L, g in NATIVAS.items():
        o = DIAL + g * 8
        assert rom[o:o + 8] == original[o:o + 8], 'toqué la %s nativa' % L

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    open(salida, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % salida)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '/tmp/v379_david.pce')
