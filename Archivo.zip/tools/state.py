#!/usr/bin/env python3
"""
Extractor de savestates de Mesen para PC Engine (formato '#RZIPv').

Cabecera de 24 B + zlib. Dentro hay un savestate de Mednafen con secciones
de nombre ASCII seguidas de una longitud <I.

Uso:
    python3 tools/state.py fichero.state              -> lista las secciones
    python3 tools/state.py fichero.state VRAM out.bin -> vuelca una seccion
"""
import sys, zlib, struct, re


def descomprimir(path):
    d = open(path, 'rb').read()
    assert d[:6] == b'#RZIPv', 'no es un state #RZIPv'
    return zlib.decompressobj().decompress(d[24:])


def secciones(raw):
    """Localiza nombres de seccion conocidos y devuelve (nombre, off, len)."""
    out = []
    for m in re.finditer(rb'[A-Za-z_][A-Za-z0-9_]{2,15}', raw):
        nom = m.group()
        p = m.end()
        if p + 4 > len(raw):
            continue
        ln = struct.unpack('<I', raw[p:p + 4])[0]
        if 0 < ln <= len(raw) - p - 4:
            out.append((nom.decode(), p + 4, ln))
    return out


def buscar(raw, nombre, longitud=None):
    """Devuelve los bytes de la seccion 'nombre' con longitud declarada."""
    pat = nombre.encode()
    i = 0
    while True:
        i = raw.find(pat, i)
        if i < 0:
            return None
        p = i + len(pat)
        ln = struct.unpack('<I', raw[p:p + 4])[0]
        if (longitud is None and 0 < ln <= len(raw) - p - 4) or ln == longitud:
            return raw[p + 4:p + 4 + ln]
        i += 1


if __name__ == '__main__':
    raw = descomprimir(sys.argv[1])
    if len(sys.argv) == 2:
        print('descomprimido: %d B' % len(raw))
        for nom, off, ln in secciones(raw):
            if ln >= 256:
                print('  %-16s off %#08x  len %6d' % (nom, off, ln))
    else:
        nom = sys.argv[2]
        dat = buscar(raw, nom)
        open(sys.argv[3], 'wb').write(dat)
        print('%s -> %s  (%d B)' % (nom, sys.argv[3], len(dat)))
