"""Reimplementacion de $F1B9 -> $E5C2 -> $861F -> $867F (cargador de CG).

$867F  un plano de 8 filas hacia ($16),Y con paso 2.
       bit 1 = literal.  bit 0 = REPITE el acumulador.
       El PRIMER bit es especial: si es 0, CLA -> escribe $00.
$861F  4 iteraciones x 4 planos (Y=0,1,$10,$11) -> buffer $313F, 128 B,
       que se vuelcan al VDC con TIA $313F,$0002,$0080.
$F1B9  el primer byte del stream es el numero de bloques de 128 B.
"""
class F:
    def __init__(s,d,p): s.d=d; s.p=p
    def b(s):
        v=s.d[s.p]; s.p+=1; return v

def plano(f,buf,y):
    mapa=f.b()
    c=(mapa>>7)&1; mapa=(mapa<<1)&0xFF
    a = f.b() if c else 0          # CLA en $8699
    buf[y]=a
    for _ in range(7):
        c=(mapa>>7)&1; mapa=(mapa<<1)&0xFF
        if c: a=f.b()              # si no, A conserva el ultimo literal
        y+=2
        buf[y]=a
    return buf

def bloque(f):
    buf=bytearray(0x80)
    off=0
    for _ in range(4):
        for y in (0,1,0x10,0x11):
            plano(f,buf,off+y)
        off+=0x20
    return bytes(buf)

def carga(rom,src):
    f=F(rom,src)
    cnt=f.b()
    out=bytearray()
    for _ in range(cnt):
        out+=bloque(f)
    return bytes(out),cnt,f.p

def comprime_plano(vals):
    """Inverso de $867F para 8 valores."""
    out=bytearray(); mapa=0; lits=bytearray()
    a=None
    for i,v in enumerate(vals):
        if i==0:
            if v==0:
                a=0
            else:
                mapa|=0x80; lits.append(v); a=v
        else:
            if v==a: pass
            else:
                mapa|=0x80>>i; lits.append(v); a=v
    out.append(mapa); out+=lits
    return bytes(out)

def comprime_bloque(cell):
    out=bytearray(); off=0
    for _ in range(4):
        for y in (0,1,0x10,0x11):
            vals=[cell[off+y+i*2] for i in range(8)]
            out+=comprime_plano(vals)
        off+=0x20
    return bytes(out)
