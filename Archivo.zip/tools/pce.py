"""pce.py - arnés de PC Engine sobre Beetle PCE (libretro).

Carga la ROM, ejecuta frames, pulsa botones y vuelca vídeo/RAM/VRAM.
Es la contrapartida de `md.py` del proyecto Nekketsu, que hacía lo mismo
con Genesis Plus GX.

David tenía razón: SÍ se puede emular aquí. El core se compila del
repositorio de libretro con `make` (hay gcc y red en el sandbox).

USO
---
    from pce import PCE
    p = PCE('roms/momotaro_es_v334.pce')
    p.run(300)                 # 300 frames
    p.press('START', 2)        # pulsar START 2 frames
    p.png('/tmp/foto.png')     # captura
    ram = p.ram()              # 8 KB de RAM de trabajo

Nada de esto escribe en la ROM.
"""
import ctypes
import os
import struct
from ctypes import (CDLL, CFUNCTYPE, POINTER, Structure, byref, c_bool,
                    c_char_p, c_int16, c_size_t, c_uint, c_void_p, cast,
                    create_string_buffer, string_at)
from pathlib import Path

SO = str(Path(__file__).with_name('bin') / 'mednafen_pce_libretro.so')
SO_TRACE = str(Path(__file__).with_name('bin') / 'mednafen_pce_trace.so')

# libretro
ENV_GET_SYSTEM_DIRECTORY = 9
ENV_SET_PIXEL_FORMAT = 10
ENV_GET_SAVE_DIRECTORY = 31
ENV_GET_LOG_INTERFACE = 27

MEM_SAVE_RAM = 0
MEM_SYSTEM_RAM = 2
MEM_VIDEO_RAM = 3

BTN = {'B': 0, 'Y': 1, 'SELECT': 2, 'START': 3, 'UP': 4, 'DOWN': 5,
       'LEFT': 6, 'RIGHT': 7, 'A': 8, 'X': 9, 'L': 10, 'R': 11}


class GameInfo(Structure):
    _fields_ = [('path', c_char_p), ('data', c_void_p),
                ('size', c_size_t), ('meta', c_char_p)]


class AVInfo(Structure):
    _fields_ = [('base_w', c_uint), ('base_h', c_uint),
                ('max_w', c_uint), ('max_h', c_uint),
                ('aspect', ctypes.c_float),
                ('fps', ctypes.c_double), ('sample_rate', ctypes.c_double)]


ENVCB = CFUNCTYPE(c_bool, c_uint, c_void_p)
VIDEOCB = CFUNCTYPE(None, c_void_p, c_uint, c_uint, c_size_t)
AUDIOCB = CFUNCTYPE(None, c_int16, c_int16)
AUDIOBCB = CFUNCTYPE(c_size_t, POINTER(c_int16), c_size_t)
POLLCB = CFUNCTYPE(None)
INPUTCB = CFUNCTYPE(c_int16, c_uint, c_uint, c_uint, c_uint)


class PCE:
    def __init__(self, rom, sysdir='/tmp/pce_sys', trace=False):
        os.makedirs(sysdir, exist_ok=True)
        self.sysdir = create_string_buffer(sysdir.encode())
        self.core = CDLL(SO_TRACE if trace else SO)
        self.trace = trace
        self.frame = None          # (bytes, w, h, pitch)
        self.nframe = 0
        self.buttons = set()

        self._env = ENVCB(self._on_env)
        self._video = VIDEOCB(self._on_video)
        self._audio = AUDIOCB(lambda l, r: None)
        self._audiob = AUDIOBCB(lambda d, f: f)
        self._poll = POLLCB(lambda: None)
        self._input = INPUTCB(self._on_input)

        c = self.core
        c.retro_set_environment(self._env)
        c.retro_set_video_refresh(self._video)
        c.retro_set_audio_sample(self._audio)
        c.retro_set_audio_sample_batch(self._audiob)
        c.retro_set_input_poll(self._poll)
        c.retro_set_input_state(self._input)
        c.retro_init()

        data = open(rom, 'rb').read()
        # las ROMs de PCE con cabecera de 512 B hay que quitarsela
        if len(data) % 1024 == 512:
            data = data[512:]
        self._rom = create_string_buffer(data, len(data))
        gi = GameInfo(path=rom.encode(), data=cast(self._rom, c_void_p),
                      size=len(data), meta=None)
        if not c.retro_load_game(byref(gi)):
            raise RuntimeError('retro_load_game falló')

        # sin esto el core no conecta el mando y no llega ningun boton
        c.retro_set_controller_port_device(0, 1)   # RETRO_DEVICE_JOYPAD

        av = AVInfo()
        c.retro_get_system_av_info(byref(av))
        self.av = av

    # ---- callbacks -----------------------------------------------------
    def _on_env(self, cmd, data):
        if cmd == ENV_SET_PIXEL_FORMAT:
            return True                      # RGB565, el que compilamos
        if cmd in (ENV_GET_SYSTEM_DIRECTORY, ENV_GET_SAVE_DIRECTORY):
            cast(data, POINTER(c_void_p))[0] = cast(self.sysdir, c_void_p)
            return True
        return False

    def _on_video(self, data, w, h, pitch):
        if data:
            self.frame = (string_at(data, pitch * h), w, h, pitch)

    def _on_input(self, port, device, index, ident):
        if port == 0 and ident in self.buttons:
            return 1
        return 0

    # ---- control -------------------------------------------------------
    def run(self, n=1):
        for _ in range(n):
            self.core.retro_run()
            self.nframe += 1
        return self

    def press(self, *names, frames=2, after=2):
        """Pulsa botones N frames y los suelta."""
        self.buttons = {BTN[n] for n in names}
        self.run(frames)
        self.buttons = set()
        if after:
            self.run(after)
        return self

    # ---- memoria -------------------------------------------------------
    def _mem(self, which):
        self.core.retro_get_memory_data.restype = c_void_p
        self.core.retro_get_memory_size.restype = c_size_t
        p = self.core.retro_get_memory_data(which)
        n = self.core.retro_get_memory_size(which)
        return string_at(p, n) if p and n else b''

    def ram(self):
        return self._mem(MEM_SYSTEM_RAM)

    def poke(self, addr, val):
        """Escribe en la RAM de trabajo. addr es CPU ($2000-$3FFF)."""
        self.core.retro_get_memory_data.restype = c_void_p
        base = self.core.retro_get_memory_data(MEM_SYSTEM_RAM)
        ctypes.memset(c_void_p(base + (addr - 0x2000)), val, 1)

    def peek(self, addr):
        return self.ram()[addr - 0x2000]

    def vram(self):
        return self._mem(MEM_VIDEO_RAM)

    def sram(self):
        return self._mem(MEM_SAVE_RAM)

    # ---- estado --------------------------------------------------------
    def state(self):
        self.core.retro_serialize_size.restype = c_size_t
        n = self.core.retro_serialize_size()
        buf = create_string_buffer(n)
        self.core.retro_serialize(buf, n)
        return buf.raw

    def load_state(self, blob):
        buf = create_string_buffer(blob, len(blob))
        return bool(self.core.retro_unserialize(buf, len(blob)))

    # ---- imagen --------------------------------------------------------
    def rgb(self):
        """El frame actual como lista de filas de (r,g,b)."""
        if not self.frame:
            return None
        raw, w, h, pitch = self.frame
        out = []
        for y in range(h):
            row = []
            off = y * pitch
            for x in range(w):
                px = raw[off + x * 2] | raw[off + x * 2 + 1] << 8
                r = (px >> 11) & 0x1F
                g = (px >> 5) & 0x3F
                b = px & 0x1F
                row.append((r << 3 | r >> 2, g << 2 | g >> 4, b << 3 | b >> 2))
            out.append(row)
        return out

    def png(self, path):
        from PIL import Image
        rows = self.rgb()
        h = len(rows)
        w = len(rows[0])
        im = Image.new('RGB', (w, h))
        im.putdata([p for row in rows for p in row])
        im.save(path)
        return path

    # ---- trazador (solo con trace=True) --------------------------------
    def _sym(self, nombre, tipo):
        return tipo.in_dll(self.core, nombre)

    def watch(self, pc):
        """Vigila un PC. Cada vez que se ejecute, guarda MPR y registros."""
        self._sym('mkt_trace_pc', c_uint).value = pc
        self._sym('mkt_hits', c_uint).value = 0

    def hits(self):
        return self._sym('mkt_hits', c_uint).value

    def mpr(self):
        return list(bytes((ctypes.c_ubyte * 9).in_dll(self.core, 'mkt_mpr')))

    def regs(self):
        r = (c_uint * 8).in_dll(self.core, 'mkt_regs')
        return {'A': r[0], 'X': r[1], 'Y': r[2], 'S': r[3], 'P': r[4], 'PC': r[5]}

    def log_on(self, desde=0, hasta=0xFFFF):
        self._sym('mkt_log_from', c_uint).value = desde
        self._sym('mkt_log_to', c_uint).value = hasta
        self._sym('mkt_logn', c_uint).value = 0
        self._sym('mkt_logging', c_uint).value = 1

    def log_off(self):
        self._sym('mkt_logging', c_uint).value = 0

    def log(self):
        """Lista de (pc, banco_mpr) de las instrucciones grabadas."""
        n = self._sym('mkt_logn', c_uint).value
        a = (c_uint * 4096).in_dll(self.core, 'mkt_log')
        return [(a[i] & 0xFFFF, (a[i] >> 16) & 0xFF) for i in range(min(n, 4096))]

    def rom_off(self, pc):
        """Traduce PC a offset de ROM usando el MPR capturado."""
        return (self.mpr()[pc >> 13] * 0x2000) + (pc & 0x1FFF)

    def watch_write(self, addr):
        """Vigila ESCRITURAS a una direccion CPU. Registra quien escribe."""
        self._sym('mkt_wp_addr', c_uint).value = addr
        self._sym('mkt_wp_hits', c_uint).value = 0
        self._sym('mkt_wp_n', c_uint).value = 0

    def writes(self):
        """[(pc, banco, valor)] de las escrituras capturadas (max 64)."""
        n = self._sym('mkt_wp_n', c_uint).value
        pcs = (c_uint * 64).in_dll(self.core, 'mkt_wp_pc')
        val = (c_uint * 64).in_dll(self.core, 'mkt_wp_val')
        return [(pcs[i] & 0xFFFF, (pcs[i] >> 16) & 0xFF, val[i]) for i in range(min(n, 64))]

    def write_hits(self):
        return self._sym('mkt_wp_hits', c_uint).value
