#!/usr/bin/env python3
"""sram.py - inyecta un .sav / .srm de backup RAM en una instancia de PCE.

El core expone los 2 KB de Backup RAM por `retro_get_memory_data(0)`, así que
se puede escribir directamente y el juego los ve como partidas guardadas.

Los .sav de Mesen son el mismo formato (cabecera «HUBM»), así que valen tal
cual: NO hacen falta savestates del emulador de David.
"""
import ctypes


def carga(p, path):
    """Escribe el fichero en la Backup RAM del core. Devuelve los bytes."""
    d = open(path, 'rb').read()
    assert d[:4] == b'HUBM', 'no parece backup RAM de PCE: %s' % d[:4]
    p.core.retro_get_memory_data.restype = ctypes.c_void_p
    p.core.retro_get_memory_size.restype = ctypes.c_size_t
    ptr = p.core.retro_get_memory_data(0)
    n = p.core.retro_get_memory_size(0)
    assert n >= len(d), 'la SRAM del core es menor que el fichero'
    ctypes.memmove(ptr, d, len(d))
    return d
