#!/usr/bin/env python3
"""
presupuesto.py - cuantas ranuras/scanline gasta cada geometria de bocadillo.

El VDC del PCE dibuja 16 sprites por scanline y uno de 32 px cuenta DOS
(norma 144). El limite es POR SCANLINE, no por sprite total. De ahi la
consecuencia que decide todo el diseño:

    ENSANCHAR cuesta ranuras.   ALARGAR (mas lineas) es GRATIS.

Porque las lineas de texto van una debajo de otra: en una scanline dada solo
hay UNA fila de texto (si no se solapan, que fue el bug del nordo, v201).
"""

COLS_POR_CELDA = 2          # 2 caracteres de 8 px en cada celda de 16 px


def ranuras(cols, laterales=True, marco_32=True):
    """Ranuras que gasta el bocadillo en una scanline de TEXTO."""
    celdas = (cols + COLS_POR_CELDA - 1) // COLS_POR_CELDA
    return celdas + (2 if laterales else 0)


def ranuras_marco(cols, marco_32=True):
    """Ranuras en una scanline del borde superior o inferior."""
    ancho = 32 + (cols // COLS_POR_CELDA) * 16 + 16     # px del marco
    # la esquina de 32 px cuenta 2, el resto de 16 en 1
    n_16 = (ancho - 32 - 16) // 16
    return 2 + n_16 + 1


def capacidad(cols, lineas):
    return cols * lineas


if __name__ == '__main__':
    print('CONFIGURACIONES  (cap = caracteres por pagina)')
    print()
    print('%-9s %-7s %-5s %-8s %-8s %s'
          % ('cols x li', 'cap', 'px', 'texto', 'marco', 'veredicto'))
    print('-' * 66)
    for cols, li in [(16, 4), (14, 4), (14, 5), (12, 4), (12, 5), (12, 6),
                     (10, 5), (10, 6), (8, 6), (8, 8)]:
        t = ranuras(cols, laterales=True)
        m = ranuras_marco(cols)
        cap = capacidad(cols, li)
        peor = max(t, m)
        v = ''
        if peor >= 10:
            v = 'igual o peor que hoy'
        elif peor == 9:
            v = 'gana 1 ranura'
        elif peor == 8:
            v = 'gana 2'
        else:
            v = 'gana %d' % (10 - peor)
        print('%-9s %-7d %-5d %-8d %-8d %s'
              % ('%dx%d' % (cols, li), cap, cols * 8, t, m, v))
    print()
    print('sin laterales (el trazo, metido en el CG de los extremos):')
    for cols, li in [(16, 4), (14, 5), (12, 5)]:
        t = ranuras(cols, laterales=False)
        print('   %dx%d -> %d ranuras de texto  (cap %d)'
              % (cols, li, t, capacidad(cols, li)))
