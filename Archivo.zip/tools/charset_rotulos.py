#!/usr/bin/env python3
"""charset_rotulos.py - Codificador de los ROTULOS de aldea (motor $AAB4).

TERCER charset del proyecto. No confundir:

    charset_oficial.py   motor de MENU      alias b/c/p/Ç en $5B/$5D/$5E/$5F
    charset_vitores.py   motor $9B0B        bytes directos (tiendas, vitores)
    charset_rotulos.py   motor $AAB4        alias b/c + ADEMAS e=$3D y o=$62

PROCEDENCIA
-----------
Deducido de rotulos que David lleva viendo bien en pantalla decenas de
versiones, en el banco `$0F`:

    0x1E25C  «Aldea de la Partida»   -> P=$50  t=$B4  r=$B2  i=$A9
    0x1E271  «Aldea Florecer»        -> F=$46  c=$5D
    0x1E281  «Aldea Kintaro»         -> K=$4B  n=$AE  o=$62
    0x1F89E  «Aldea Dormilon»        -> D=$44  ó=$BE
    0x1F8AE  «Aldea Urashima»        -> U=$55  s=$B3  h=$A8  m=$AD
    0x1F8BE  «Aldea Kachiyama»       -> y=$B9
    0x1F8CF  «Aldea Issunboshi»      -> I=$49  u=$B5
    0x1F8E1  «Aldea Bambu»           -> B=$42  b=$5B  ú=$BF
    0x1F8EE  «Isla Ogros»            -> O=$4F  g=$A7

Sin un solo conflicto en los 9 rotulos.

EL PATRON
---------
    mayusculas y espacio : ASCII directo
    minusculas           : $A1 + (c - 'a')
    alias                : b=$5B  c=$5D  e=$3D  o=$62

Los alias `b` y `c` son los mismos del motor de MENU. Los de `e` y `o` son
propios de este motor: pasan por la tabla de sustitucion `$AB34`.

`T` ($54) y `k` ($AB) no aparecen en ningun rotulo existente, pero siguen
el patron sin excepcion en los 20 caracteres verificados.
"""

CHAR_TO_CODE = {' ': 0x20}
for _i in range(10):
    CHAR_TO_CODE[str(_i)] = 0x30 + _i
for _i in range(26):
    CHAR_TO_CODE[chr(ord('A') + _i)] = 0x41 + _i
for _i, _ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    CHAR_TO_CODE[_ch] = 0xA1 + _i

# los cuatro alias de este motor
CHAR_TO_CODE['b'] = 0x5B
CHAR_TO_CODE['c'] = 0x5D
CHAR_TO_CODE['e'] = 0x3D
CHAR_TO_CODE['o'] = 0x62

CHAR_TO_CODE.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    '¡': 0xCA, '¿': 0xC9, '.': 0xCB, ',': 0xCC, '!': 0x21, '?': 0x3F, '-': 0xD2,
})

FIN = 0xFF          # terminador de rotulo
CMD = 0x01          # byte de comando: elige el juego de glifos


def encode(s):
    out = bytearray()
    for c in s:
        if c not in CHAR_TO_CODE:
            raise ValueError('caracter sin codigo en el charset de rotulos: %r' % c)
        out.append(CHAR_TO_CODE[c])
    return bytes(out)


def rotulo(s):
    """Cadena completa lista para la ROM: [$01] texto [$FF]."""
    return bytes([CMD]) + encode(s) + bytes([FIN])
