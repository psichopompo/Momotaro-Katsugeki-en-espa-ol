#!/usr/bin/env python3
"""v398 - los vítores vuelven a su sitio (regresión de la v397).

QUÉ PASÓ
--------
La pancarta de vítores del fin de fase también lleva `$368F = 2` y también
pasa por la cueva `$FFC3` (105 hits medidos). O sea que NO es un sistema
tan independiente como decía la entrada 277: sus celdas ($178..$189) son
propias, pero el desplazamiento vertical lo calcula la MISMA cueva que el
bocadillo del abuelo.

Al hacer que la cueva bajara 2 px (v397), los vítores bajaron 2 px de más
sobre el +4 que ya les daba el `ADC #$34` de la v396 → +6 en total. El glifo
desbordó por abajo y machacó la fila 0 de la celda siguiente, que es el
borde: de ahí las franjas negras que ve David en y=99/100 y y=115/116.

Es el MISMO fallo que la v396 con los bocadillos de 3 filas, sólo que por el
otro camino: un cambio en algo compartido, validado en una sola escena.

SOLUCIÓN
--------
Los vítores tienen su propia constante en `$C9EE`. Se le restan los 2 px que
ahora pone la cueva, y quedan igual que en la v396 aprobada:

    ROM 0x169F2   ADC #$34  ->  ADC #$32        (+4 de la v396, -2 de la cueva)
"""
import hashlib

BASE = "roms/momotaro_es_v397.pce"
SAL  = "roms/momotaro_es_v398.pce"
MD5_BASE = "20c2119d3c8367f4acce9bfc0e9eb722"

OFF = 0x169F2

def main():
    d = bytearray(open(BASE, "rb").read())
    assert hashlib.md5(d).hexdigest() == MD5_BASE, "la base no es la v397"

    # el opcode es el que creo: LDA $16 / CLC / ADC #$34 / STA $3663
    assert d[0x169EE:0x169F6] == bytes.fromhex("a5161869348d6336"), \
        "$C9EE no es la rutina de los vítores: %s" % d[0x169EE:0x169F6].hex()

    d[OFF] = 0x32

    # la cueva $FFC3 de la v397 sigue intacta
    assert d[0x1FC3:0x1FDC] == bytes.fromhex(
        "6410ad65362902f002b710ad8f36c902d0064610e610e61060"), "cueva $FFC3 tocada"
    # la tabla COMPARTIDA $9BBD sigue intacta
    assert d[0x41BBD:0x41BFD] == bytes.fromhex(
        "3071307170717071b071b071f071f071"
        "3072307270727072b072b072f072f072"
        "3073307370737073b073b073f073f073"
        "3074307470747074b074b074f074f074"), "$9BBD tocada"

    open(SAL, "wb").write(d)
    b = open(SAL, "rb").read()
    dif = [i for i in range(len(b)) if b[i] != open(BASE,'rb').read()[i]]
    assert dif == [OFF], "se han tocado otros bytes: %s" % [hex(i) for i in dif]
    print("%s   UN BYTE (0x%X)" % (SAL, OFF))
    print("  MD5   ", hashlib.md5(b).hexdigest())
    print("  SHA-1 ", hashlib.sha1(b).hexdigest())

main()
