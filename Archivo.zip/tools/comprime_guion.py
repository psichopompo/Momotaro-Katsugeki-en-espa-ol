"""comprime_guion.py - reconstruye el diccionario de 48 entradas ($60-$8F).

Mismo formato que el descompresor $793B del otro chat:
  $00      fin
  $60-$8F  entrada del diccionario (un nivel de anidamiento como mucho)
  otro     literal
"""
from collections import Counter


MARCA = '\x00'


def elegir(textos, n=48, minlen=3, maxlen=24):
    """Elige las n subcadenas que mas bytes ahorran, de forma voraz.

    Las ocurrencias ya sustituidas se marcan con MARCA. Las subcadenas
    candidatas NO pueden contenerla: si no, acaban entrando entradas como
    'l\x00ogr', que no son texto real y rompen la codificacion.
    """
    ent = []
    restos = list(textos)
    for _ in range(n):
        c = Counter()
        for t in restos:
            L = len(t)
            for i in range(L):
                for k in range(minlen, min(maxlen, L - i) + 1):
                    sub = t[i:i + k]
                    if MARCA in sub:
                        break
                    c[sub] += 1
        mejor, ahorro = None, 0
        for s, veces in c.items():
            if veces < 2:
                continue
            # cada uso: len(s) bytes -> 1 byte ; y la entrada cuesta len(s)+1
            a = veces * (len(s) - 1) - (len(s) + 1)
            if a > ahorro:
                mejor, ahorro = s, a
        if not mejor:
            break
        ent.append(mejor)
        restos = [t.replace(mejor, MARCA) for t in restos]
    return ent


def codifica(texto, ent, tabla_cod):
    """Sustituye las entradas y devuelve los bytes."""
    trozos = [texto]
    for i, e in enumerate(ent):
        nuevos = []
        for t in trozos:
            if isinstance(t, int):
                nuevos.append(t)
                continue
            partes = t.split(e)
            for k, p in enumerate(partes):
                if k:
                    nuevos.append(0x60 + i)
                if p:
                    nuevos.append(p)
        trozos = nuevos
    out = bytearray()
    for t in trozos:
        if isinstance(t, int):
            out.append(t)
        else:
            for ch in t:
                out.append(tabla_cod[ch])
    return bytes(out)
