#!/usr/bin/env python3
"""
fix_esquinas.py - cierra las dos esquinas izquierdas del bocadillo.

EL FALLO (medido en la captura de David, 219x138)
--------------------------------------------------
El borde izquierdo tiene un pixel abierto en la transicion de la diagonal a
la vertical, arriba y abajo. Por ahi se escapa el blanco del interior:

    IZQUIERDA (rota)        DERECHA (correcta)
    y=36  .#WWWW            WWWW#.
    y=37  .WWWWW   <-- hueco  WWWW#.
    y=38  #WWWWW            WWWWW#

En la derecha el trazo baja dos filas por columna (x190,x190,x191,x191). En
la izquierda salta de x=25 a x=24 dejando una fila sin trazo.

En el CG son los tiles de las esquinas:

    tile 19C (SUP-IZQ)  fila 13:  .#WWWW...  -> falta negro en x=0
    tile 19E (INF-IZQ)  fila  3:  .#WWWWW..  -> falta negro en x=0

FORMATO
-------
Sprite del PCE: 4 planos de 32 B. Un pixel de color 6 (el negro del borde)
tiene los bits 1 y 2 puestos y el 0 y el 3 a cero:

    color 6 = 0b0110 -> plano0=0, plano1=1, plano2=1, plano3=0

Los planos van en words: plano0 en +0..15, plano1 en +16..31,
plano2 en +32..47, plano3 en +48..63 (indices de word desde celda*64).

Uso:  python3 tools/fix_esquinas.py entrada.pce salida.pce
"""
import sys
import struct

# (celda, fila, columna) de los pixeles que hay que poner en negro
ARREGLOS = [
    (0x19C, 13, 0),   # esquina superior izquierda
    (0x19E, 3, 0),    # esquina inferior izquierda
]

COLOR_BORDE = 6       # el negro del marco, medido en el CG


def pixel(words, celda, fila, col, color):
    """Pone un pixel de la celda al color dado, tocando los 4 planos."""
    base = celda * 64
    bit = 15 - col
    for plano in range(4):
        i = base + plano * 16 + fila
        if (color >> plano) & 1:
            words[i] |= (1 << bit)
        else:
            words[i] &= ~(1 << bit) & 0xFFFF


def leer(v):
    return list(struct.unpack('<%dH' % (len(v) // 2), v))


def main(ent, sal):
    rom = bytearray(open(ent, 'rb').read())
    print('esto corrige la VRAM, no la ROM: hay que aplicarlo al CG.')
    print('Aqui solo se comprueba el calculo sobre un volcado de VRAM.')
    return rom


def verificar(vram_path):
    """Aplica el arreglo a un volcado de VRAM y ensena el antes/despues."""
    v = bytearray(open(vram_path, 'rb').read())
    w = leer(bytes(v))

    def dibujo(celda, filas):
        out = []
        base = celda * 64
        for f in filas:
            p = [w[base + pl * 16 + f] for pl in range(4)]
            fila = ''
            for x in range(8):
                b = 15 - x
                c = sum(((p[pl] >> b) & 1) << pl for pl in range(4))
                fila += '.' if c == 0 else ('#' if c == 6 else 'W')
            out.append(fila)
        return out

    for celda, fila, col in ARREGLOS:
        print('== celda %03X, fila %d' % (celda, fila))
        print('   antes:   %s' % dibujo(celda, [fila])[0])
        pixel(w, celda, fila, col, COLOR_BORDE)
        print('   despues: %s' % dibujo(celda, [fila])[0])
    return w


if __name__ == '__main__':
    if len(sys.argv) > 1:
        verificar(sys.argv[1])
    else:
        verificar('v173/Aldeana_vram.bin')
