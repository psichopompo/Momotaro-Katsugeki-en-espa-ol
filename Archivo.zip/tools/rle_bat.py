"""rle_bat.py - RLE de las BAT de fondo del Momotaro.

Formato (medido sobre la BAT del menu SELECT, ROM 0x1E7EA):

    FF <cnt> <val>   ->  repite <val> (cnt+1) veces
    <b>              ->  literal

La BAT del menu SELECT son 22 filas de 32 celdas = 704 bytes de indice de
patron BAJO. El byte ALTO (paleta + bit 8 del patron) lo pone otra parte:
todos los patrones del menu son < 0x100 salvo los de texto, que los escribe
el motor $D41C en tiempo de ejecucion.

Verificado: descomprimir 0x1E7EA da las 22 filas identicas al state, salvo
las celdas que el juego sobreescribe luego con texto dinamico (las cifras
de vitalidad/tecnica/dinero y los nombres de arma y armadura).
"""


def descomprime(d, pos, n):
    out = bytearray()
    while len(out) < n:
        b = d[pos]
        pos += 1
        if b == 0xFF:
            cnt = d[pos]
            val = d[pos + 1]
            pos += 2
            out += bytes([val]) * (cnt + 1)
        else:
            out.append(b)
    return bytes(out[:n]), pos


def comprime(datos):
    out = bytearray()
    i = 0
    n = len(datos)
    while i < n:
        v = datos[i]
        j = i
        while j < n and datos[j] == v and (j - i) < 256:
            j += 1
        run = j - i
        # un literal $FF hay que codificarlo siempre como carrera
        if run >= 3 or v == 0xFF:
            out += bytes([0xFF, run - 1, v])
        else:
            out += bytes([v]) * run
        i = j
    return bytes(out)


if __name__ == '__main__':
    import sys
    rom = open(sys.argv[1], 'rb').read()
    d, fin = descomprime(rom, int(sys.argv[2], 16), int(sys.argv[3]))
    print('fin', hex(fin), 'bytes', len(d))
