#!/usr/bin/env python3
"""
audita_vram.py - que celdas de sprite usa el juego DE VERDAD.

Recorre todos los volcados de VRAM disponibles y anota:
  - celdas referenciadas desde el SATB (sprites en pantalla)
  - celdas referenciadas desde la BAT (fondo; comparten VRAM desde $1000)
  - celdas con CONTENIDO no nulo (aunque nadie las referencie: son datos
    cargados, y machacarlas rompe algo mas tarde)

La tercera es la clave: en la v185 di por libre el tramo 170-17F porque
nadie lo referenciaba EN ESE INSTANTE, y resulta que el juego carga ahi el
proyectil y parte del jefe final.
"""
import glob
import struct
import sys

SATB = 0x7F00


def celdas_sat(vram):
    w = struct.unpack('<256H', vram[SATB * 2:SATB * 2 + 512])
    out = set()
    for i in range(64):
        y, x, pat, at = w[i * 4:i * 4 + 4]
        if (y, x, pat, at) == (0, 0, 0, 0) or y > 0x3FF:
            continue
        c = (pat >> 1) & 0x7FF
        ncol = 2 if (at >> 8) & 1 else 1
        nfil = {0: 1, 1: 2, 2: 2, 3: 4}[(at >> 12) & 3]
        if ncol == 2:
            c &= ~1
        if nfil >= 2:
            c &= ~(2 if nfil == 2 else 6)
        for fy in range(nfil):
            for fx in range(ncol):
                out.add(c + fy * 2 + fx)
    return out


def celdas_bat(vram, ancho=64, alto=64):
    """Patrones del fondo, en unidades de CELDA de sprite (64 words)."""
    out = set()
    for i in range(ancho * alto):
        e = struct.unpack('<H', vram[i * 2:i * 2 + 2])[0]
        pat = e & 0x0FFF          # patron de 16 words
        out.add(pat // 4)         # 4 patrones de BG = 1 celda de sprite
    return out


def con_contenido(vram):
    """Celdas de 16x16 cuyo CG no esta todo a cero."""
    w = struct.unpack('<%dH' % (len(vram) // 2), vram)
    out = set()
    for c in range(len(w) // 64):
        base = c * 64
        if any(w[base:base + 64]):
            out.add(c)
    return out


if __name__ == '__main__':
    ficheros = sorted(glob.glob('docs/*_vram.bin')
                      + glob.glob('states2/*_vram.bin')
                      + glob.glob('states3/*_vram.bin'))
    sat_t, bat_t, cont = set(), set(), {}
    for f in ficheros:
        v = open(f, 'rb').read()
        s = celdas_sat(v)
        b = celdas_bat(v)
        sat_t |= s
        bat_t |= b
        for c in con_contenido(v):
            cont.setdefault(c, []).append(f.split('/')[-1][:26])
    print('volcados analizados: %d' % len(ficheros))
    lo = int(sys.argv[1], 16) if len(sys.argv) > 1 else 0x100
    hi = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x200
    print('\ncelda  SAT  BAT  contenido en')
    libres = []
    for c in range(lo, hi):
        marca_s = 'X' if c in sat_t else '.'
        marca_b = 'X' if c in bat_t else '.'
        n = len(cont.get(c, []))
        if marca_s == '.' and marca_b == '.' and n == 0:
            libres.append(c)
        print(' %03X    %s    %s   %d %s' % (
            c, marca_s, marca_b, n,
            ','.join(cont.get(c, [])[:3])))
    print('\nLIBRES en todos los volcados: %s'
          % (' '.join('%03X' % c for c in libres) or 'NINGUNA'))
    # rachas
    rachas = []
    ini = None
    for c in range(lo, hi + 1):
        if c in libres:
            if ini is None:
                ini = c
        else:
            if ini is not None:
                rachas.append((ini, c - 1))
                ini = None
    print('rachas: %s' % ' '.join('%03X-%03X(%d)' % (a, b, b - a + 1)
                                  for a, b in rachas))
