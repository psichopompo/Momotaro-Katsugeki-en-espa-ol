"""Decodificador JIS X 0201 (katakana de media anchura) para los textos del juego.

Confirmado por el lector de tienda $9B37, que da trato especial justo a
$A1 . / $A4 , / $B0 alargamiento / $DE dakuten / $DF handakuten, que son
exactamente los signos de JIS X 0201.
"""
JIS = {
 0xA1:'。',0xA2:'「',0xA3:'」',0xA4:'、',0xA5:'・',0xA6:'ヲ',0xA7:'ァ',0xA8:'ィ',
 0xA9:'ゥ',0xAA:'ェ',0xAB:'ォ',0xAC:'ャ',0xAD:'ュ',0xAE:'ョ',0xAF:'ッ',0xB0:'ー',
 0xB1:'ア',0xB2:'イ',0xB3:'ウ',0xB4:'エ',0xB5:'オ',0xB6:'カ',0xB7:'キ',0xB8:'ク',
 0xB9:'ケ',0xBA:'コ',0xBB:'サ',0xBC:'シ',0xBD:'ス',0xBE:'セ',0xBF:'ソ',0xC0:'タ',
 0xC1:'チ',0xC2:'ツ',0xC3:'テ',0xC4:'ト',0xC5:'ナ',0xC6:'ニ',0xC7:'ヌ',0xC8:'ネ',
 0xC9:'ノ',0xCA:'ハ',0xCB:'ヒ',0xCC:'フ',0xCD:'ヘ',0xCE:'ホ',0xCF:'マ',0xD0:'ミ',
 0xD1:'ム',0xD2:'メ',0xD3:'モ',0xD4:'ヤ',0xD5:'ユ',0xD6:'ヨ',0xD7:'ラ',0xD8:'リ',
 0xD9:'ル',0xDA:'レ',0xDB:'ロ',0xDC:'ワ',0xDD:'ン',0xDE:'゛',0xDF:'゜',
}
# combinaciones con dakuten / handakuten
DAK = {'カ':'ガ','キ':'ギ','ク':'グ','ケ':'ゲ','コ':'ゴ','サ':'ザ','シ':'ジ','ス':'ズ',
       'セ':'ゼ','ソ':'ゾ','タ':'ダ','チ':'ヂ','ツ':'ヅ','テ':'デ','ト':'ド','ハ':'バ',
       'ヒ':'ビ','フ':'ブ','ヘ':'ベ','ホ':'ボ','ウ':'ヴ'}
HAN = {'ハ':'パ','ヒ':'ピ','フ':'プ','ヘ':'ペ','ホ':'ポ'}

ROMAJI = {
 'ア':'a','イ':'i','ウ':'u','エ':'e','オ':'o','カ':'ka','キ':'ki','ク':'ku','ケ':'ke','コ':'ko',
 'サ':'sa','シ':'shi','ス':'su','セ':'se','ソ':'so','タ':'ta','チ':'chi','ツ':'tsu','テ':'te','ト':'to',
 'ナ':'na','ニ':'ni','ヌ':'nu','ネ':'ne','ノ':'no','ハ':'ha','ヒ':'hi','フ':'fu','ヘ':'he','ホ':'ho',
 'マ':'ma','ミ':'mi','ム':'mu','メ':'me','モ':'mo','ヤ':'ya','ユ':'yu','ヨ':'yo',
 'ラ':'ra','リ':'ri','ル':'ru','レ':'re','ロ':'ro','ワ':'wa','ヲ':'wo','ン':'n',
 'ガ':'ga','ギ':'gi','グ':'gu','ゲ':'ge','ゴ':'go','ザ':'za','ジ':'ji','ズ':'zu','ゼ':'ze','ゾ':'zo',
 'ダ':'da','ヂ':'di','ヅ':'du','デ':'de','ド':'do','バ':'ba','ビ':'bi','ブ':'bu','ベ':'be','ボ':'bo',
 'パ':'pa','ピ':'pi','プ':'pu','ペ':'pe','ポ':'po','ヴ':'vu',
 'ァ':'a','ィ':'i','ゥ':'u','ェ':'e','ォ':'o','ャ':'ya','ュ':'yu','ョ':'yo',
 'ー':'-','。':'. ','、':', ','・':'/','「':'"','」':'"',
}

def decode(b):
    """bytes -> texto japones legible, combinando dakuten."""
    out=[]
    for x in b:
        if x == 0xA0:
            out.append(' ')
        elif x in (0xDE, 0xDF):
            if out:
                base = out[-1]
                tabla = DAK if x == 0xDE else HAN
                if base in tabla:
                    out[-1] = tabla[base]
                    continue
            out.append('゛' if x == 0xDE else '゜')
        elif x in JIS:
            out.append(JIS[x])
        elif 0x20 <= x < 0x80:
            out.append(chr(x))
        else:
            out.append('{%02X}' % x)
    return ''.join(out)

def romaji(txt):
    out=[]
    i=0
    while i < len(txt):
        c = txt[i]
        # digrafos con ya/yu/yo pequenas
        if i+1 < len(txt) and txt[i+1] in 'ャュョ' and c in ROMAJI:
            base = ROMAJI[c]
            peq = {'ャ':'ya','ュ':'yu','ョ':'yo'}[txt[i+1]]
            out.append(base[:-1] + peq if len(base) > 1 else base + peq)
            i += 2
            continue
        if c == 'ッ':
            if i+1 < len(txt) and txt[i+1] in ROMAJI:
                out.append(ROMAJI[txt[i+1]][0])
            i += 1
            continue
        out.append(ROMAJI.get(c, c))
        i += 1
    return ''.join(out)
