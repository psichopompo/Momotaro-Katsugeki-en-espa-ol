#!/usr/bin/env python3
"""noregresion.py - compara dos ROMs sobre TODOS los savestates.

POR QUÉ EXISTE (norma 378)
--------------------------
El script que se venía usando creaba DOS instancias de PCE a la vez, una por
ROM. **No funciona**: `CDLL` devuelve el mismo handle para la misma .so, así
que las dos instancias comparten el core y la segunda se queda con los
callbacks. Resultado: `pa.frame` era siempre None, la comparación no se
ejecutaba nunca y el script decía «0 diferencias» **sin haber comparado
nada**.

Aquí se corre **una ROM cada vez**, se guardan las capturas y se comparan
después.

USO
---
    python3 tools/noregresion.py ROM_A ROM_B [frames] [paso]
"""
import glob
import os
import sys

sys.path.insert(0, 'tools')
import numpy as np
from PIL import Image

from pce import PCE
import estados


def capturas(rom, st, frames, paso, tmp):
    """Corre la ROM sobre el state y devuelve {frame: array}."""
    p = PCE(rom)
    try:
        if not estados.carga(p, st):
            return None
    except Exception:
        return None
    out = {}
    for f in range(1, frames + 1):
        p.run(1)
        if (f % paso == 0 or f == frames) and p.frame:
            p.png(tmp)
            out[f] = np.array(Image.open(tmp).convert('RGB'))
    return out


def main():
    a = sys.argv[1] if len(sys.argv) > 1 else 'roms/Momotaro Katsugeki (Español).pce'
    b = sys.argv[2]
    frames = int(sys.argv[3]) if len(sys.argv) > 3 else 300
    paso = int(sys.argv[4]) if len(sys.argv) > 4 else 25
    # AVISO (norma 382): con 300 frames y paso 25 NO se ven las escenas
    # largas. `states/tras_jefe_david.state` necesita 700+ para llegar a los
    # vítores. Si el cambio afecta a una escena tardía, hay que subir
    # `frames` a mano: 0 diferencias con un muestreo corto no significa nada.

    sts = sorted(glob.glob('states/*.state'))
    malos, comparados, sin_frame = [], 0, []
    for st in sts:
        ca = capturas(a, st, frames, paso, '/tmp/_nra.png')
        cb = capturas(b, st, frames, paso, '/tmp/_nrb.png')
        if ca is None or cb is None:
            print('SKIP (no carga)', st)
            continue
        comunes = sorted(set(ca) & set(cb))
        if not comunes:
            sin_frame.append(st)
            continue
        peor = 0
        for f in comunes:
            d = (ca[f] != cb[f]).any(axis=2).sum()
            peor = max(peor, d)
        comparados += len(comunes)
        if peor:
            malos.append((st, peor))
            print('DIF  %-42s %d px' % (st.split('/')[-1], peor))

    print('---')
    print('states: %d   comparaciones reales: %d' % (len(sts), comparados))
    if sin_frame:
        print('SIN FRAME (no comparados): %d -> %s' % (len(sin_frame), sin_frame))
    print('states con diferencias: %d' % len(malos))
    # el script DEBE haber comparado algo: si no, es que está roto
    assert comparados > 0, 'no se comparó ni un frame: el arnés está roto'


if __name__ == '__main__':
    main()
