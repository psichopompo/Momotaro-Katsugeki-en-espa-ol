"""descomp_cg.py - descompresor del CG del PC Engine (rutina $C1CC/$C206).

Transcrito instrucción a instrucción del banco 0x0C ($C1CC..$C205).

$C206 descomprime UN plano de 8 filas hacia ($18),Y con paso 2:

    LDA ($14) / INC $14         mapa de bits de 8 bits
    STA $10 ; CLA ; CLY ; LDX #$08
  bucle:
    ASL $10                     saca el bit mas alto
    BCC salta                   bit 0 -> escribe 0 (A sigue valiendo 0)
    LDA ($14) / INC $14         bit 1 -> lee un byte literal
  salta:
    STA ($18),Y / INY / INY     escribe y avanza DOS bytes
    DEX / BNE bucle

OJO: cuando el bit es 0 escribe el ACUMULADOR, y A conserva el ULTIMO
literal leido. No es "escribe cero": es "REPITE el ultimo byte". Se ha
verificado contra el CG real del state (ver validar()).

$C1CC monta un tile completo llamando cuatro veces a $C206 con destinos
$393A, $393B, $394A, $394B: son los cuatro planos entrelazados de un tile
de 32 bytes en el buffer $393A. Luego TIA $393A -> $0002 (puerto de datos
del VDC), 32 bytes. Se repite Y veces (Y = numero de tiles).
"""


class Flujo:
    def __init__(self, datos, pos):
        self.d = datos
        self.p = pos

    def byte(self):
        b = self.d[self.p]
        self.p += 1
        return b


def plano(f, buf, off):
    """Descomprime 8 bytes hacia buf[off], buf[off+2], ... (paso 2)."""
    mapa = f.byte()
    a = 0
    for i in range(8):
        bit = (mapa >> (7 - i)) & 1
        if bit:
            a = f.byte()
        buf[off + i * 2] = a
    return buf


def tile(f):
    """Un tile de 32 bytes: 4 planos entrelazados en el buffer $393A."""
    buf = bytearray(32)
    plano(f, buf, 0)    # $393A -> bytes 0,2,4,..14
    plano(f, buf, 1)    # $393B -> bytes 1,3,5,..15
    plano(f, buf, 16)   # $394A -> bytes 16,18,..30
    plano(f, buf, 17)   # $394B -> bytes 17,19,..31
    return bytes(buf)


def descomprime(datos, pos, n):
    """n tiles a partir de datos[pos].  Devuelve (bytes, pos_final)."""
    f = Flujo(datos, pos)
    out = b''.join(tile(f) for _ in range(n))
    return out, f.p


def comprime(tiles):
    """Inverso exacto de $C206. tiles = bytes multiplo de 32."""
    out = bytearray()
    for t in range(len(tiles) // 32):
        b = tiles[t * 32:t * 32 + 32]
        for off in (0, 1, 16, 17):
            mapa = 0
            lits = bytearray()
            a = 0
            for i in range(8):
                v = b[off + i * 2]
                if v == a:
                    pass                    # bit 0: repite el acumulador
                else:
                    mapa |= 0x80 >> i       # bit 1: literal
                    lits.append(v)
                    a = v
            out.append(mapa)
            out += lits
    return bytes(out)


if __name__ == '__main__':
    import sys
    rom = open(sys.argv[1], 'rb').read()
    pos = int(sys.argv[2], 16)
    n = int(sys.argv[3])
    d, fin = descomprime(rom, pos, n)
    print('fin en', hex(fin), 'bytes', len(d))
