"""glifos_es_v74.py - Glifos españoles para Momotaro Katsugeki (PC Engine).

FORMATO REAL DE LA FUENTE (medido en la v73, contra la pantalla)
----------------------------------------------------------------
La v73 usaba ROM 0x3A10 con stride 16 (2bpp). ERA FALSO.

Medición: se extrajeron los bitmaps de las 21 celdas de la línea 1 de la
captura de David y se buscó cada uno en la ROM. Las 26 letras A-Z aparecen
UNA sola vez cada una, y siempre en:

        ROM = 0x3D660 + glifo * 8      (8 bytes por glifo, 1 BIT POR PÍXEL)

Ejemplos verificados byte a byte:
    'A' glifo 0x70 -> 0x3D9E0 = 00 38 6c c6 c6 fe c6 c6
    'H' glifo 0x77 -> 0x3DA18
    'O' glifo 0x7E -> 0x3DA50
    'Z' glifo 0x89 -> 0x3DAA8

La fila 0 va siempre vacía; la letra ocupa las filas 1..7.
No hay plano de contorno: es 1bpp puro.

DISEÑO DE LOS GLIFOS NUEVOS
---------------------------
No caben 8 filas de letra + tilde, así que las vocales acentuadas
comprimen la letra a las filas 2..7 (6 filas) y ponen la tilde en la
fila 0, dejando la fila 1 de separación.

Los signos ¿ y ¡ son los glifos ? (0x9D) y ! (0x9E) del propio juego
girados 180°, para que el trazo case exactamente con el resto.

Leyenda del arte:  '#' = píxel encendido,  '.' = apagado.
"""

GLIFOS = {

# ---- Á ---------------------------------------------------------------
'A_acute': [
    "....##..",   # tilde
    "........",
    "..###...",
    ".##.##..",
    "##...##.",
    "#######.",
    "##...##.",
    "##...##.",
],

# ---- É ---------------------------------------------------------------
'E_acute': [
    "....##..",
    "........",
    "#######.",
    "##......",
    "######..",
    "##......",
    "##......",
    "#######.",
],

# ---- Í ---------------------------------------------------------------
'I_acute': [
    "....##..",
    "........",
    ".######.",
    "...##...",
    "...##...",
    "...##...",
    "...##...",
    ".######.",
],

# ---- Ó ---------------------------------------------------------------
'O_acute': [
    "....##..",
    "........",
    ".#####..",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    ".#####..",
],

# ---- Ú ---------------------------------------------------------------
'U_acute': [
    "....##..",
    "........",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    ".#####..",
],

# ---- Ñ ---------------------------------------------------------------
'N_tilde': [
    "..####..",   # virgulilla
    "........",
    "##...##.",
    "###..##.",
    "####.##.",
    "#######.",
    "##..###.",
    "##...##.",
],

# ---- ¿  (el ? del juego, glifo 0x9D, girado 180°) --------------------
'inv_quest': [
    "........",
    "...##...",
    "........",
    "...##...",
    ".###....",
    "##...##.",
    "##...##.",
    ".#####..",
],

# ---- ¡  (el ! del juego, glifo 0x9E, girado 180°) --------------------
'inv_excl': [
    "........",
    "...##...",
    "...##...",
    "........",
    "...##...",
    "...##...",
    "...##...",
    "...##...",
],

# ---- , (coma) ----------------------------------------------------------
'coma': [
    "........",
    "........",
    "........",
    "........",
    "........",
    "..##....",
    "..##....",
    "..#.....",
],

# ---- . (punto) ---------------------------------------------------------
'punto': [
    "........",
    "........",
    "........",
    "........",
    "........",
    "........",
    "...##...",
    "...##...",
],
# ---- ! (exclamación de cierre) -----------------------------------------
'excl': [
    "...##...",
    "...##...",
    "...##...",
    "...##...",
    "...##...",
    "........",
    "...##...",
    "...##...",
],
}


def encode(arte):
    """Convierte el arte ASCII en 8 bytes, 1bpp."""
    if len(arte) != 8:
        raise ValueError(f'se esperaban 8 filas, hay {len(arte)}')
    out = []
    for fila in arte:
        if len(fila) != 8:
            raise ValueError(f'fila de {len(fila)} px: {fila!r}')
        b = 0
        for x, c in enumerate(fila):
            if c == '#':
                b |= 1 << (7 - x)
            elif c != '.':
                raise ValueError(f'caracter no valido: {c!r}')
        out.append(b)
    return bytes(out)


def render(datos8):
    """Devuelve el arte ASCII de 8 bytes, para verificar lo escrito."""
    return [''.join('#' if (datos8[y] >> (7 - x)) & 1 else '.'
                    for x in range(8)) for y in range(8)]
