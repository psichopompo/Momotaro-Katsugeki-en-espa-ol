"""select_bg.py - adapta el PNG del menu SELECT que edita David.

El fondo del menu es BAT + CG, los dos en la ROM:

    CG   0x0F3D9 .. 0x0F96C   1427 B comprimidos ($C1CC/$C206), 96 tiles
                              -> VRAM $100-$15F
    BAT  0x1E7EA .. 0x1E9E8    510 B comprimidos (RLE), 22 filas x 32 celdas
                              -> solo el byte BAJO; el alto lo pone el juego

38 celdas las reescribe el juego en ejecucion (las cifras de salud/tecnica,
el importe, los nombres de arma y armadura y las flechas). Se detectan por
su byte alto $02 en el state y **no se tocan**: el PNG las lleva lisas.

Estrategia de encaje: se reutilizan los tiles del CG que el PNG vuelve a
usar, y los que quedan libres al desaparecer los kanji se reciclan para los
nuevos. Asi el bloque no crece de indice y no hay que repuntar nada.
"""
import sys
from PIL import Image

sys.path.insert(0, 'tools')
from descomp_cg import descomprime, comprime

CG_INI, CG_FIN = 0x0F3D9, 0x0F96C
N_TILES = 96
BASE = 0x100


def carga_paleta(path='docs/select_pal.bin'):
    pal = open(path, 'rb').read()
    m = {}
    for i in range(16):
        w = pal[i * 2] | (pal[i * 2 + 1] << 8)
        g, r, b = (w >> 6) & 7, (w >> 3) & 7, w & 7
        m[(r * 36, g * 36, b * 36)] = i
    return m


def tiles_png(path, colmap):
    im = Image.open(path).convert('RGB')
    assert im.size == (256, 176), 'el PNG debe medir 256x176 (32x22 celdas)'
    px = im.load()
    def celda(cx, cy):
        f = []
        for r in range(8):
            fila = []
            for k in range(8):
                c = px[cx * 8 + k, cy * 8 + r]
                assert c in colmap, 'color %s fuera de la paleta del menu' % (c,)
                fila.append(colmap[c])
            f.append(tuple(fila))
        return tuple(f)
    return [[celda(c, f) for c in range(32)] for f in range(22)]


def tile_de_cg(cg, idx):
    b = idx * 32
    out = []
    for r in range(8):
        a, q = cg[b + r * 2], cg[b + r * 2 + 1]
        c, e = cg[b + 16 + r * 2], cg[b + 16 + r * 2 + 1]
        out.append(tuple(((a >> (7 - k)) & 1) | (((q >> (7 - k)) & 1) << 1) |
                         (((c >> (7 - k)) & 1) << 2) | (((e >> (7 - k)) & 1) << 3)
                         for k in range(8)))
    return tuple(out)


def a_bytes(t):
    buf = bytearray(32)
    for r in range(8):
        b0 = b1 = b2 = b3 = 0
        for k in range(8):
            v = t[r][k]
            bit = 7 - k
            if v & 1: b0 |= 1 << bit
            if v & 2: b1 |= 1 << bit
            if v & 4: b2 |= 1 << bit
            if v & 8: b3 |= 1 << bit
        buf[r * 2], buf[r * 2 + 1] = b0, b1
        buf[16 + r * 2], buf[16 + r * 2 + 1] = b2, b3
    return bytes(buf)
