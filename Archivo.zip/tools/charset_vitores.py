#!/usr/bin/env python3
"""charset_vitores.py - Codificador para el motor $9B0B (TIENDAS y VITORES).

NO es el mismo que `charset_oficial.py`, que sirve al motor de MENU ($AAB4,
con la tabla de sustitucion $AB34). Aqui NO existe esa tabla: los alias
`$5B/$5D/$5E/$5F` para `b c p Ç` pintarian una © (norma 256).

PROCEDENCIA DE LA TABLA
-----------------------
Deducida de texto REAL de la ROM que David ya ha verificado en pantalla:

    0x486D1  «Vaya, cliente!»   56 a1 b9 a1 cc 20 a3 ac a9 a5 ae b4 a5 21
    0x4BF70  «Para hablar con»  50 a1 b2 a1 20 a8 a1 a2 ac a1 b2 20 a3 af ae

De ahi: minusculas = `$A1 + (letra - 'a')` en BYTE DIRECTO, mayusculas y
digitos en ASCII, y los signos en `$C9..$DD`.

DOS TRAMPAS DEL LECTOR $9B0B (medidas, ver entrada 177 del diario)
------------------------------------------------------------------
1. `$5C` conmuta el juego de glifos ($3666) y **no consume columna**.
   No se puede usar como caracter.
2. `$DE` y `$DF` ponen CARRY (`CPX #$DE` en `$9B79`): su glifo se pinta en
   la FILA DE ARRIBA y tampoco consumen columna. Son el dakuten y el
   handakuten japoneses. **Prohibidos**: en `charset_oficial` la `Ç` vale
   `$DE`, y aqui destrozaria la linea anterior.
3. `$A1 $A4 $B0` usan el flag `$3690` en vez de `$3666`. Como el motor
   entra con `$3666=1` y `$3690=0`, dan glifos DISTINTOS de los que daria
   la ruta normal: `$A1`->'a' y `$B0`->'p' salen bien porque asi esta el
   texto de produccion, pero cualquier cambio ahi hay que medirlo.
"""

CHAR_TO_CODE = {}

# ASCII directo: espacio, digitos, mayusculas y los signos basicos
CHAR_TO_CODE[' '] = 0x20
for _i in range(10):
    CHAR_TO_CODE[str(_i)] = 0x30 + _i
for _i in range(26):
    CHAR_TO_CODE[chr(ord('A') + _i)] = 0x41 + _i
CHAR_TO_CODE['!'] = 0x21
CHAR_TO_CODE['?'] = 0x3F
CHAR_TO_CODE['$'] = 0x24

# minusculas: BYTE DIRECTO $A1..$BA  (nada de alias)
for _i, _ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    CHAR_TO_CODE[_ch] = 0xA1 + _i

# acentos y signos
CHAR_TO_CODE.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'º': 0xDC, 'ª': 0xDD,
})

RELLENO = 0xA0          # espacio de relleno del motor
PROHIBIDOS = {0x5C, 0xDE, 0xDF}


def encode(s):
    """texto -> bytes. Falla ruidosamente ante cualquier caracter dudoso."""
    out = bytearray()
    for c in s:
        if c not in CHAR_TO_CODE:
            raise ValueError('caracter sin codigo: %r en %r' % (c, s))
        b = CHAR_TO_CODE[c]
        if b in PROHIBIDOS:
            raise ValueError('caracter %r usa el byte prohibido $%02X' % (c, b))
        out.append(b)
    return bytes(out)


def linea(s, ancho=18):
    """Codifica una linea y la rellena a `ancho` columnas VISIBLES."""
    if len(s) > ancho:
        raise ValueError('linea de %d columnas (max %d): %r' % (len(s), ancho, s))
    return encode(s) + bytes([RELLENO]) * (ancho - len(s))
