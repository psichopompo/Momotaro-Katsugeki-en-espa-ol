#!/usr/bin/env python3
"""
mock_abuelo2.py - mueve el bocadillo del abuelo (cuerpo Y rabillo juntos)
y comprueba cuantos sprites se mutilan.

David pide -23 px en X y -5 px en Y para alinearlo con el rabillo lateral.
Se mueve TODO el conjunto (cuerpo + rabillo 1AF), porque el ajuste se hara
sobre el ANCLA y luego se compensara la tabla $9ADD para que el rabillo se
quede donde esta ahora.
"""
import struct
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vdc_slots import informe_visible, simular, sat
from render_sprites import dibujar

SATB = 0x7F00


def mueve(vram, dx, dy, celdas=None, mover_rabillo=True):
    v = bytearray(vram)
    for i in range(64):
        o = (SATB + i * 4) * 2
        y, x, pat, at = struct.unpack('<4H', v[o:o + 8])
        if (y, x, pat, at) == (0, 0, 0, 0) or y > 0x3FF:
            continue
        c = (pat >> 1) & 0x7FF
        if not (0x170 <= c <= 0x1AF):
            continue
        if c == 0x1AF and not mover_rabillo:
            continue
        struct.pack_into('<HH', v, o, (y + dy) & 0xFFFF, (x + dx) & 0xFFFF)
    return bytes(v)


if __name__ == '__main__':
    src = sys.argv[1]
    v0 = open(src, 'rb').read()
    print('%-6s %-6s  %-9s %s' % ('dx', 'dy', 'mutilados', 'detalle'))
    for dy in range(0, -9, -1):
        v = mueve(v0, -23, dy)
        li, uso = informe_visible(v)
        tot = sum(len(p) for *_, p in li)
        print('%-6d %-6d  %-9d %s' % (
            -23, dy, len(li),
            ' '.join('%03X(%d)' % (c, len(p)) for _, c, _, _, p in li)
            or 'LIMPIO'))
