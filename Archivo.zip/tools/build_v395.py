#!/usr/bin/env python3
r"""build_v395.py - A-CASA (B1): la casa mutilada del mapa de Kachiyama.

EL BUG
------
En el mapa de la Aldea Kachiyama la casa gris de arriba sale decapitada:
pierde la franja del tejado. Medido con `states/mapa_kachiyama.state`:

    scanlines y=120..127   16/16 ranuras   SATURADAS
    sprite 32 (celda $14C, 32x32, y=120)   pierde las filas 128..133

LA CAUSA (entrada 264)
----------------------
El VDC dibuja 16 ranuras por scanline y un sprite de 32 px cuesta DOS
(norma 144). En y=120..127 se juntan 16 justas y la casa, que es el último
sprite por índice, se cae.

    JP:  24 sprites,  12 ranuras,  pico 13,  0 pérdidas
    ES:  35 sprites,  16 ranuras,  pico 16,  6 filas perdidas

La fila inferior del marco del rótulo usa 3 sprites de 32 px en japonés
(96 px, 6 ranuras) y 5 en el nuestro (160 px, 10). **+4: 12+4 = 16.** El
rótulo ancho es nuestro (v126-v128) y Kachiyama es el único mapa donde el
fondo ya iba al límite.

EL ARREGLO: subir el rótulo 8 px, y SÓLO el rótulo
---------------------------------------------------
    rótulo -6 px   pico=16  la casa pierde 1 fila
    rótulo -8 px   pico=16  NINGUNA pérdida     <- el mínimo que limpia

El rótulo pasa de y=86/102/118 a y=78/94/110 y la casa se queda en y=120.
Al moverse las tres filas juntas el marco no se descuadra, y no se sale por
arriba.

[DESCARTADO] El primer intento tocaba UN byte: `0x1CCE0`, de la tabla
`$CCD0`. Cero pérdidas y captura correcta... pero `$CCD0[mapa]` es la **Y
base de todo el grupo de dibujo**: se carga en `$50` (`$DF28`) y de ahí sale
la Y de cada sprite (`$E49A`). Movía 23 sprites, la casa incluida, y en
`issunboshi.state` la casa roja quedaba flotando fuera de su camino
(entrada 266). Lo cazó el arnés de no-regresión ya arreglado. **Norma 379.**

LAS CUATRO LISTAS DEL RÓTULO
-----------------------------
    ROM 0x1DDF0  $DDF0   7 regs   marco superior + laterales   (i0..i6)
    ROM 0x1DEDD  $DEDD   8 regs   los glifos del texto         (i7..i14)
    ROM 0x1DE14  $DE14   6 regs   marco inferior + lateral     (i16..i21)
    ROM 0x1DF06  $DF06   1 reg    el rabillo, celda $1AD       (i15)

Cada registro son 5 bytes y el **byte 4 es la Y**.

Las tres primeras son del **grupo 5**, que sólo usan los mapas 4 y 12
(tabla `$DC90`: grupos [2,3,2,2,5,4,1,0] x2). Se les resta 8 sin más.

**La cuarta, `$DF06`, es GLOBAL**: la usan los 16 mapas. Aquí estuvo el
trabajo:

  - Bajarla dejaba el rabillo despegado en `issunboshi` (28 px medidos: un
    punto negro suelto dentro del bocadillo).
  - NO tocarla dejaba el rabillo descolgado 8 px en Kachiyama.

Solución: una **copia** del registro con la Y ya subida, y una cueva que
elige el puntero según el mapa. El puntero original está partido en dos
`LDA #` inmediatos (norma 369), así que se sustituyen por un `JSR`:

    antes  $DF75  A9 06 85 53 A9 DF 85 54     (8 B)
    ahora  $DF75  20 DE DF EA EA EA EA EA     JSR $DFDE + 5 NOP

    cueva $DFDE (ROM 0x1DFDE, 24 B):
        LDA $3CF6 ; CMP #$04 ; BEQ grupo5
                    CMP #$0C ; BEQ grupo5
        LDA #$06 ; BRA fin          ; resto de mapas -> $DF06
      grupo5:
        LDA #$F6                    ; mapas 4 y 12  -> $DFF6
      fin:
        STA $53 ; LDA #$DF ; STA $54 ; RTS

    copia $DFF6 (ROM 0x1DFF6, 6 B):  09 0E 00 F8 D6 FF   (Y = $DE-8)

El hueco de `0x1DFDE` son 34 B de `$FF` libres justo detrás de la cueva
`$DFAE` de la v388. Se usan 30: cueva 24 + copia 6.

**Cuidado con el solape** (norma 371): un primer montaje puso la copia en
`0x1DFF4` y pisó los dos últimos bytes de la cueva; el rabillo desaparecía
de Kachiyama. Aquí los rangos se comprueban con asserts.

VERIFICACIÓN
------------
    mapa_kachiyama:  rótulo y=[78,94,110]  rabillo y=110  0 pérdidas
    issunboshi:      rótulo y=[38,54,70,87] rabillo y=70   0 pérdidas
"""
import hashlib
import sys
import zlib

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v394
DST = 'roms/momotaro_es_v395.pce'
JPR = 'roms/Momotarou Katsugeki (Japan).pce'

SUBIR = 8
LISTAS = [                       # las del grupo 5 (mapas 4 y 12)
    (0x1DDF0, 7, 'marco superior + laterales'),
    (0x1DEDD, 8, 'glifos del texto'),
    (0x1DE14, 6, 'marco inferior + lateral'),
]
RABILLO = 0x1DF06                # lista global, 1 registro
ENGANCHE = 0x1DF75               # los dos LDA # del puntero, 8 B
CUEVA = 0x1DFDE                  # $DFDE
COPIA = 0x1DFF6                  # $DFF6
FIN_HUECO = 0x1E000

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)
jp = open(JPR, 'rb').read()

# ---- 0. el estado de partida es el que creo ------------------------------
for off, n, nom in LISTAS:
    for k in range(n):
        assert rom[off + k * 5] != 0xFF, 'lista 0x%05X corta en el reg %d' % (off, k)
    assert rom[off + n * 5] == 0xFF, 'lista 0x%05X no acaba en $FF tras %d' % (off, n)
    # son NUESTRAS: en la japonesa esa zona es relleno (las creó la v126-v128)
    assert all(b == 0xFF for b in jp[off:off + n * 5 + 1]), (
        'en la japonesa 0x%05X no es relleno: la lista NO es nuestra' % off)

ANTES = {0x1DDF0: {190, 206}, 0x1DEDD: {206}, 0x1DE14: {206, 222}}
for off, n, nom in LISTAS:
    ys = {rom[off + k * 5 + 4] for k in range(n)}
    assert ys == ANTES[off], 'Y inesperadas en 0x%05X: %s' % (off, sorted(ys))

assert bytes(rom[RABILLO:RABILLO + 6]) == b'\x09\x0e\x00\xf8\xde\xff', (
    'el registro del rabillo no es el esperado: %s' % rom[RABILLO:RABILLO + 6].hex())
assert bytes(rom[ENGANCHE:ENGANCHE + 8]) == b'\xa9\x06\x85\x53\xa9\xdf\x85\x54', (
    'en 0x%05X no están los dos LDA # del puntero' % ENGANCHE)
assert all(b == 0xFF for b in rom[CUEVA:FIN_HUECO]), (
    'el hueco 0x%05X no está limpio' % CUEVA)

# ---- 1. subir las tres listas del grupo 5 --------------------------------
tocado = set()
for off, n, nom in LISTAS:
    for k in range(n):
        o = off + k * 5 + 4
        assert rom[o] >= SUBIR, 'la Y de 0x%05X se saldría por arriba' % o
        rom[o] -= SUBIR
        tocado.add(o)
    print('  0x%05X  %d registros -%d px   %s' % (off, n, SUBIR, nom))

# ---- 2. la cueva que elige el puntero del rabillo ------------------------
cueva = bytes([
    0xAD, 0xF6, 0x3C,        # LDA $3CF6
    0xC9, 0x04,              # CMP #$04
    0xF0, 0x08,              # BEQ grupo5
    0xC9, 0x0C,              # CMP #$0C
    0xF0, 0x04,              # BEQ grupo5
    0xA9, COPIA & 0xFF ^ 0xF0,  # (se corrige debajo)
])
# se escribe explícita para que los saltos queden a la vista
cueva = bytes([
    0xAD, 0xF6, 0x3C,        # LDA $3CF6
    0xC9, 0x04,              # CMP #$04
    0xF0, 0x08,              # BEQ +8  -> grupo5
    0xC9, 0x0C,              # CMP #$0C
    0xF0, 0x04,              # BEQ +4  -> grupo5
    0xA9, RABILLO & 0xFF,    # LDA #$06     resto de mapas
    0x80, 0x02,              # BRA +2  -> fin
    0xA9, COPIA & 0xFF,      # LDA #$F6     mapas 4 y 12   (grupo5)
    0x85, 0x53,              # STA $53                     (fin)
    0xA9, 0xDF,              # LDA #$DF
    0x85, 0x54,              # STA $54
    0x60,                    # RTS
])
copia = bytes([0x09, 0x0E, 0x00, 0xF8, 0xDE - SUBIR, 0xFF])

# NORMA 371: los dos bloques no se pueden solapar, y el segundo cabe entero
assert CUEVA + len(cueva) <= COPIA, (
    'la cueva (%d B) pisa la copia: 0x%05X + %d > 0x%05X'
    % (len(cueva), CUEVA, len(cueva), COPIA))
assert COPIA + len(copia) <= FIN_HUECO, 'la copia se sale del hueco'

rom[CUEVA:CUEVA + len(cueva)] = cueva
rom[COPIA:COPIA + len(copia)] = copia
tocado |= set(range(CUEVA, CUEVA + len(cueva)))
tocado |= set(range(COPIA, COPIA + len(copia)))
print('  0x%05X  cueva de %d B (elige el puntero según $3CF6)' % (CUEVA, len(cueva)))
print('  0x%05X  copia del rabillo con Y-%d' % (COPIA, SUBIR))

# ---- 3. enganche ---------------------------------------------------------
rom[ENGANCHE:ENGANCHE + 8] = bytes([0x20, CUEVA & 0xFF, 0xDF]) + b'\xEA' * 5
tocado |= set(range(ENGANCHE, ENGANCHE + 8))
print('  0x%05X  JSR $DFDE + 5 NOP  (antes: dos LDA #)' % ENGANCHE)

# ---- 4. nada más se ha tocado -------------------------------------------
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos <= tocado, 'se ha tocado algo más: %s' % sorted(distintos - tocado)

# la tabla de posición del GRUPO no se toca (norma 379: eso mueve la casa)
assert rom[0x1CCCF:0x1CCCF + 64] == orig[0x1CCCF:0x1CCCF + 64], (
    'tocada la tabla $CCCF: eso movería la casa, no sólo el rótulo')
# la lista global del rabillo sigue intacta para los otros 14 mapas
assert bytes(rom[RABILLO:RABILLO + 6]) == b'\x09\x0e\x00\xf8\xde\xff', (
    'la lista global del rabillo se ha modificado')
# la cueva $DFAE de la v388 (marco del bocadillo de minijuegos), intacta
assert bytes(rom[0x1DFAE:0x1DFDE]) == orig[0x1DFAE:0x1DFDE], (
    'tocada la cueva $DFAE de la v388')
# las listas de los otros grupos, intactas hasta su propio $FF
def largo(off):
    n = 0
    while orig[off + n * 5] != 0xFF:
        n += 1
    return n * 5 + 1

for off in (0x1DCC4, 0x1DCE3, 0x1DCF8, 0x1DD17, 0x1DD31,
            0x1DD55, 0x1DD6F, 0x1DD93, 0x1DDB2, 0x1DDD6):
    L = largo(off)
    assert bytes(rom[off:off + L]) == orig[off:off + L], (
        'tocada la lista 0x%05X, que es de otro grupo' % off)

open(DST, 'wb').write(bytes(rom))
print()
print('%s  %d B' % (DST, len(rom)))
print('  el rótulo sube %d px SÓLO en los mapas del grupo 5 (4 y 12)' % SUBIR)
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
