"""texto.py - lector/escritor de los bloques de texto con diccionario.

El codificador oficial (charset_oficial) usa ALIAS de la zona ASCII para
b/c/p ($5B/$5D/$5E), pero el renderer acepta TAMBIEN los bytes directos
($A2/$A3/$B0), y el guion comprimido de la ROM los usa. Para LEER hay que
aceptar los dos; para ESCRIBIR se respeta el alias (viene de produccion).
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from charset_oficial import CHAR_TO_CODE

TAB = 0x4BA13          # tabla de 48 punteros del diccionario ($7A13)
BASE = 0x44000         # offset = puntero + 0x44000

INV = {}
for _k, _v in CHAR_TO_CODE.items():
    INV.setdefault(_v, _k)
# bytes directos que el renderer tambien pinta
INV.update({0xA2: 'b', 0xA3: 'c', 0xB0: 'p', 0xA0: ' '})


def entrada(rom, i):
    """Bytes crudos de la entrada i (0..47) del diccionario."""
    p = rom[TAB + i * 2] | (rom[TAB + i * 2 + 1] << 8)
    off = p + BASE
    out = bytearray()
    while rom[off] != 0x00:
        out.append(rom[off]); off += 1
    return bytes(out)


def decodifica(rom, b, prof=0):
    """bytes -> texto legible. \\n = salto de linea, | = fin de pagina."""
    o = ""
    for x in b:
        if x == 0x00:
            o += "|"
        elif x == 0x3B:
            o += "\n"
        elif 0x60 <= x <= 0x8F and prof == 0:
            o += decodifica(rom, entrada(rom, x - 0x60), 1)
        elif x in INV:
            o += INV[x]
        else:
            o += "<%02X>" % x
    return o


def codifica(txt):
    """texto -> bytes, SIN diccionario. \\n = $3B, | = $00."""
    out = bytearray()
    for c in txt:
        if c == '\n':
            out.append(0x3B)
        elif c == '|':
            out.append(0x00)
        else:
            if c not in CHAR_TO_CODE:
                raise KeyError('caracter sin glifo: %r' % c)
            out.append(CHAR_TO_CODE[c])
    return bytes(out)


def comprime(rom, txt):
    """texto -> bytes usando el diccionario (voraz, la entrada mas larga).

    Solo sustituye si la entrada del diccionario se puede representar con
    el MISMO texto que produce decodifica(), asi el round-trip es exacto.
    """
    ents = []
    for i in range(48):
        e = entrada(rom, i)
        ents.append((decodifica(rom, e, 1), 0x60 + i))
    # las mas largas primero
    ents.sort(key=lambda t: -len(t[0]))
    out = bytearray()
    i = 0
    while i < len(txt):
        for s, code in ents:
            if s and txt.startswith(s, i):
                out.append(code); i += len(s); break
        else:
            c = txt[i]
            if c == '\n': out.append(0x3B)
            elif c == '|': out.append(0x00)
            else: out.append(CHAR_TO_CODE[c])
            i += 1
    return bytes(out)
