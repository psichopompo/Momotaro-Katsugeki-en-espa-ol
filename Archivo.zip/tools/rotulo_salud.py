"""Dibuja el rotulo SALUD para el menu SELECT, en la banda y=6..15.

Medido sobre docs/select_vram.bin (state real del menu):
  - los TRES rotulos del panel izquierdo (体力/技/金) tienen su tinta
    exactamente en y=6..15 de la banda de 24 px que forman las filas
    de BAT f-1, f, f+1.  Son 10 px de alto.
  - tinta = color 3, fondo = color 1.
  - el rotulo de vida dispone de 8 celdas (64 px) hasta la cifra.

Letras de 7x10 con la MISMA linea base para todas: cuerpo en y=6..15,
exactamente el carril de los kanji. Ninguna sobresale arriba ni abajo.
"""

# Cada letra: 10 filas de 7 px. '#' tinta, '.' fondo.
# 10 px de alto = exactamente lo que ocupan los kanji originales (y=6..15).
LETRAS = {
 'S': ['..####.',
       '.##..##',
       '.##....',
       '.##....',
       '..####.',
       '.....##',
       '.....##',
       '.....##',
       '.##..##',
       '..####.'],
 'A': ['..####.',
       '.##..##',
       '.##..##',
       '.##..##',
       '.######',
       '.##..##',
       '.##..##',
       '.##..##',
       '.##..##',
       '.##..##'],
 'L': ['.##....',
       '.##....',
       '.##....',
       '.##....',
       '.##....',
       '.##....',
       '.##....',
       '.##....',
       '.##....',
       '.######'],
 'U': ['.##..##',
       '.##..##',
       '.##..##',
       '.##..##',
       '.##..##',
       '.##..##',
       '.##..##',
       '.##..##',
       '.##..##',
       '..####.'],
 'D': ['.#####.',
       '.##..##',
       '.##...#',
       '.##...#',
       '.##...#',
       '.##...#',
       '.##...#',
       '.##...#',
       '.##..##',
       '.#####.'],
}

ALTO_BANDA = 24      # tres filas de BAT
Y0 = 6               # primera fila con tinta, medida en el original
TINTA = 3
FONDO = 1


def render(texto, ancho_px):
    """Devuelve una matriz [24][ancho_px] con los indices de color."""
    lienzo = [[FONDO] * ancho_px for _ in range(ALTO_BANDA)]
    x = 0
    for ch in texto:
        pat = LETRAS[ch]
        assert len(pat) == 10, 'la letra %r no mide 10 px' % ch
        for fy, fila in enumerate(pat):
            assert len(fila) == 7, 'la letra %r no mide 7 px de ancho' % ch
            for fx, c in enumerate(fila):
                if c == '#':
                    lienzo[Y0 + fy][x + fx] = TINTA
        x += 7          # 7 px por letra, ya llevan su propio margen
    return lienzo, x


def a_tiles(lienzo, ncols):
    """Trocea la banda en 3 filas x ncols tiles de 8x8, formato PCE (32 B)."""
    tiles = []
    for fila in range(3):
        for col in range(ncols):
            buf = bytearray(32)
            for r in range(8):
                y = fila * 8 + r
                b0 = b1 = b2 = b3 = 0
                for k in range(8):
                    v = lienzo[y][col * 8 + k]
                    bit = 7 - k
                    if v & 1: b0 |= 1 << bit
                    if v & 2: b1 |= 1 << bit
                    if v & 4: b2 |= 1 << bit
                    if v & 8: b3 |= 1 << bit
                buf[r * 2] = b0
                buf[r * 2 + 1] = b1
                buf[16 + r * 2] = b2
                buf[16 + r * 2 + 1] = b3
            tiles.append(bytes(buf))
    return tiles


if __name__ == '__main__':
    lienzo, ancho = render('SALUD', 48)
    print('SALUD ocupa %d px de los 64 disponibles' % ancho)
    filas_con_tinta = [y for y in range(ALTO_BANDA) if TINTA in lienzo[y]]
    print('filas con tinta: y=%d..%d  (el original: y=6..15)'
          % (min(filas_con_tinta), max(filas_con_tinta)))
    for y in range(ALTO_BANDA):
        print(' y%2d %s' % (y, ''.join('#' if c == TINTA else '.' for c in lienzo[y])))
