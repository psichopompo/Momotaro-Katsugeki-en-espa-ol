#!/usr/bin/env python3
"""build_v391.py - Arregla la «Ç» del ermitaño Janpu (y Paropunte).

David: «el nombre del ermitaño de ese juego se muestra con la Ç de siempre.
Dice: "¡Yo soy el ermitaño JanÇu!"»

LA CAUSA (medida)
-----------------
El nombre es «Janpu», pero la 'p' se escribió con el código del charset de
RÓTULOS ($B0) en vez del OFICIAL ($5E). Este motor usa el oficial, y $B0 no
existe en su tabla: sale la Ç.

    charset_rotulos:  p = $B0
    charset_oficial:  p = $5E

Barrido de toda la lista de nombres de ermitaños (ROM 0x4B7CD-0x4B840): sólo
dos bytes están mal, los dos $B0.

    0x4B7DE   «Jan{B0}u»      -> «Janpu»
    0x4B808   «Paro{B0}unte»  -> «Paropunte»

El $A3 que también aparece en esa zona NO es un error: es un alias válido de
'c' que el motor entiende (se ve bien en «¡Sin excesos!», «El perro va
contigo»…). Verificado contando sus apariciones en bloques ya validados.
"""
import hashlib
import zlib

SRC = 'roms/Momotaro Katsugeki (Español).pce'   # v390
DST = 'roms/momotaro_es_v391.pce'

CAMBIOS = [(0x4B7DE, 'Janpu'), (0x4B808, 'Paropunte')]

rom = bytearray(open(SRC, 'rb').read())
orig = bytes(rom)

for off, nombre in CAMBIOS:
    assert rom[off] == 0xB0, 'en 0x%05X no está el $B0 (%s)' % (off, nombre)
    rom[off] = 0x5E

# no se ha movido nada más
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos == {off for off, _ in CAMBIOS}, sorted(distintos)[:10]

# y ya no queda ningún $B0 suelto en la lista de nombres
assert 0xB0 not in rom[0x4B7CD:0x4B840], 'queda algún $B0 en la lista'

open(DST, 'wb').write(bytes(rom))
print('%s  %d B' % (DST, len(rom)))
for off, nombre in CAMBIOS:
    print('  0x%05X  $B0 -> $5E   («%s»)' % (off, nombre))
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
