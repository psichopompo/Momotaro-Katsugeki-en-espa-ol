#!/usr/bin/env python3
"""build_v385.py - El bocadillo del abuelo: fin de la colision con el menu RUN.

BASE: v383 (3e06f6a36d4f221aa5d78b2b7b1f208b)

CORRIGE LA v384
---------------
La v384 ajustaba solo los bytes 0 y 5 de cada bloque de sprite, y el nivel 2
del menu perdia la tercera linea («Tirar»). **Error mio de estructura:** los
bloques de la tercera fila tienen CUATRO registros de 5 B, no dos:

    $4791: 04 0E 11 10 00 | 14 0E 11 30 00 | 24 0E 01 10 20 | 26 0E 01 30 20
           +0             | +5             | +10            | +15

Hay que ajustar los cuatro (+0, +5, +10, +15), no dos. El constructor ahora
recorre cada bloque hasta el $FF y ajusta **todos** sus registros, en vez de
usar una lista fija de offsets: asi no puede volver a quedarse corto.

Y otra correccion de concepto: los 12 bloques no son «3 por nivel» sino
**4 filas de 3**, y cada nivel usa las ultimas N filas:

    fila1 $4750 $475B $4766   tiles $00/$10/$20/$22
    fila2 $477B $4786 $4791   tiles $04/$14/$24/$26
    fila3 $47A6 $47B1 $47BC   tiles $08/$18/$28/$2A
    fila4 $47D1 $47DC $47E7   tiles $0C/$1C/$2C/$2E

    nivel 0 usa filas 1-4, nivel 1 las 2-4, nivel 2 las 3-4.

EL BUG
------
Abriendo el menu RUN mientras el bocadillo del abuelo sigue en pantalla, el
bocadillo mostraba dentro el texto del menu («Onig/iri», «Come/Us»), y
cambiaba segun el nivel del menu en que estuvieras.

LA CAUSA (entradas 221-225 del diario)
--------------------------------------
No es basura grafica ni un CG que falte. **El texto del bocadillo y el
texto del menu RUN se hornean en las mismas celdas de VRAM.**

    marco del bocadillo   celdas $19C-$1AF   las carga $9C32 desde ROM 0x3D400
    TEXTO del bocadillo   celdas $1C4-$1DD   las hornea el motor de dialogo
    TEXTO del menu RUN    celdas $1C0-$1DB   3 juegos, uno por nivel

El que escriba el ultimo, manda. El japones no lo sufre porque su bocadillo
es vertical y su texto cabia en otro rango.

Ojo con el formato del SAT: el word 2 es **el patron por dos**
(`patron = (word2 >> 1) & 0x3FF`, norma 346). Leerlo mal me hizo inventar
un «envolvimiento de VRAM» que no existe.

LA SOLUCION: el menu solo necesita UN juego de celdas
-----------------------------------------------------
El menu usaba tres juegos ($1C0-$1C3 / $1C4-$1C7 / $1C8-$1CB, y otros tres
en $1Dx) porque **dibujaba las tres ventanas a la vez**. Desde la v383 solo
se dibuja la activa, asi que los otros dos juegos sobran.

Dejandolo en el juego 0:

    menu RUN            $1C0-$1C3 y $1D0-$1D3
    bocadillo abuelo    $1C4-$1CA, $1D4-$1DA, $1DC, $1DD

**No solapan.** Verificado calculando celda a celda las dos listas de
sprites (`celda = $170 + byte0`, base en ROM 0x41A7B).

Es decir: el trabajo del menu RUN en un solo recuadro (v383) es lo que hace
posible este arreglo.

DOS MECANISMOS, HAY QUE TOCAR LOS DOS
-------------------------------------
El desplazamiento de 4 celdas por nivel se aplica en dos sitios distintos,
uno para escribir y otro para leer:

 1. ESCRITURA del texto: `ORA $3B51` en $D319 (ROM 0x19319) mezcla el nivel
    en el byte alto del destino VRAM.  ->  NOP NOP NOP

 2. LECTURA del sprite: `$D5AE` elige una lista de bloques via la tabla
    $4730 (banco $17), y el desplazamiento esta en los **bytes 0 y 5** de
    cada bloque de 11 B:
        nivel 0: byte0=$00 byte5=$10      nivel 2: byte0=$08 byte5=$18
        nivel 1: byte0=$04 byte5=$14      nivel 3: byte0=$0C byte5=$1C
    ->  los 9 bloques de los niveles 1-3 pasan a $00/$10

Tocar solo el primero deja las ventanas 2 y 3 vacias: el texto va a $1C0
pero el sprite sigue leyendo $1C4.

Y EL RETROCESO TENIA QUE REHORNEAR
----------------------------------
Con los tres niveles compartiendo celdas, al volver atras con B hay que
reescribir el texto. El avance ($D3C7) hace:

    LDX $3B51 / LDA #$FF / STZ $3B99,X / STZ $3B9D,X / STZ $3B55,X
    STA $3B59,X / JSR $D235 / JSR $D28E / JSR $D7CE / JMP $D910

...y el retroceso ($D3E4) solo hacia `DEC $3B51`. Se desvia a una cueva que
decrementa y salta al bloque completo del avance. Los STZ previos son
imprescindibles: sin ellos $D910 cree que la ventana ya esta dibujada.

POR QUE NO SE BLOQUEA EL MENU (opcion descartada por David)
------------------------------------------------------------
Se penso en bloquear el menu RUN mientras el abuelo habla, como hace el
juego con el aldeano y los padres. David lo rechazo con razon: **el abuelo
sale en fases de accion**, donde el menu hace falta para curarse o cambiar
de arma. En la aldea no hay peligro y por eso alli si puede bloquearse.

AUDITORIA PREVIA (peticion de David: «seamos cautos»)
------------------------------------------------------
20 savestates analizados con y sin menu abierto:

  - la lista COMPARTIDA (0x47C02, aldeanos/Jizo/tiendas) usa $1A0-$1DD, y
    4 de sus registros ($1D0-$1D3) seguirian pisando el juego 0 del menu.
  - pero **bocadillo y menu nunca coexisten** salvo con el abuelo: en
    aldeano, padres y jp el juego no abre el menu (medido: $3B50 se queda
    a 0 al pulsar RUN).

Por eso el arreglo es seguro. Si algun dia se desbloquea el menu en esas
escenas, habria que revisar esos 4 registros.
"""
import hashlib
import sys
import zlib

BASE = 'roms/momotaro_es_v383.pce'
MD5_BASE = '3e06f6a36d4f221aa5d78b2b7b1f208b'

ORA = 0x19319           # CPU $D319: ORA $3B51 (escritura del texto)
RETRO = 0x193E4         # CPU $D3E4: el retroceso
CUEVA_ROM = 0x19FD2     # CPU $DFD2, detras de la cueva de la v383
CUEVA_CPU = 0xDFD2

# bloques de sprite de las filas 2-4 (banco $17). Cada bloque son registros
# de 5 B terminados en $FF; el byte 0 de cada registro es el tile.
BLOQUES = [0x2E77B, 0x2E786, 0x2E791,      # fila 2
           0x2E7A6, 0x2E7B1, 0x2E7BC,      # fila 3
           0x2E7D1, 0x2E7DC, 0x2E7E7]      # fila 4
# tiles de la FILA 1, que es a la que se igualan todas
TILES_FILA1 = {0: 0x00, 5: 0x10, 10: 0x20, 15: 0x22}

INTACTAS = [
    (0x00000, 0x19319, 'todo lo anterior al ORA'),
    (0x1931C, 0x193E4, 'entre el ORA y el retroceso'),
    (0x193EF, 0x19FD2, 'del retroceso a la cueva'),
    (0x19FE1, 0x2E77B, 'de la cueva a los bloques de sprite'),
    (0x2E7FB, 0x80000, 'de los bloques al final: quiz, creditos, finales'),
]


def main(salida):
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v383'
    assert len(rom) == 524288, 'la ROM no mide 512 KB'

    # ---- 0. el estado de partida es el que creo ------------------------
    assert bytes(rom[ORA:ORA + 3]) == bytes([0x0D, 0x51, 0x3B]), \
        'en $D319 no hay un ORA $3B51'
    assert bytes(rom[RETRO:RETRO + 11]) == bytes(
        [0xCE, 0x51, 0x3B, 0x10, 0x06, 0x9C, 0x50, 0x3B, 0x9C, 0x51, 0x3B]), \
        'en $D3E4 no esta el retroceso que espero'
    # el bloque de redibujado del avance, al que saltara la cueva
    assert bytes(rom[0x193C7:0x193CC]) == bytes([0xAE, 0x51, 0x3B, 0xA9, 0xFF]), \
        'el bloque de redibujado de $D3C7 no esta donde creo'
    # cada bloque: registros de 5 B hasta el $FF, todos en offsets conocidos
    for off in BLOQUES:
        i = 0
        while i < 20 and rom[off + i] != 0xFF:
            assert i in TILES_FILA1, \
                'registro en offset inesperado %d del bloque 0x%05X' % (i, off)
            i += 5
        assert i > 0, 'el bloque 0x%05X esta vacio' % off

    cueva = bytes([
        0xCE, 0x51, 0x3B,     # DFD2  DEC $3B51
        0x30, 0x03,           # DFD5  BMI +3 -> DFDA (cerrar el menu)
        0x4C, 0xC7, 0xD3,     # DFD7  JMP $D3C7   redibuja la ventana
        0x9C, 0x50, 0x3B,     # DFDA  STZ $3B50
        0x9C, 0x51, 0x3B,     # DFDD  STZ $3B51
        0x60,                 # DFE0  RTS
    ])
    assert all(b == 0xFF for b in rom[CUEVA_ROM:CUEVA_ROM + len(cueva)]), \
        'la cueva de $DFD2 no esta limpia'

    # ---- 1. escritura: el texto de los 3 niveles al juego 0 -------------
    rom[ORA:ORA + 3] = b'\xEA\xEA\xEA'

    # ---- 2. lectura: los sprites de las filas 2-4 a los tiles de la 1 ---
    n_campos = 0
    for off in BLOQUES:
        i = 0
        while i < 20 and rom[off + i] != 0xFF:
            rom[off + i] = TILES_FILA1[i]
            n_campos += 1
            i += 5
    assert n_campos == 24, 'ajustados %d campos, esperaba 24' % n_campos

    # ---- 3. el retroceso rehornea el texto ------------------------------
    rom[RETRO] = 0x4C
    rom[RETRO + 1] = CUEVA_CPU & 0xFF
    rom[RETRO + 2] = CUEVA_CPU >> 8
    rom[RETRO + 3:RETRO + 11] = b'\xEA' * 8
    rom[CUEVA_ROM:CUEVA_ROM + len(cueva)] = cueva

    # ---- VERIFICACION ---------------------------------------------------
    assert bytes(rom[ORA:ORA + 3]) == b'\xEA\xEA\xEA'
    for off in BLOQUES:
        i = 0
        while i < 20 and rom[off + i] != 0xFF:
            assert rom[off + i] == TILES_FILA1[i], \
                'el bloque 0x%05X+%d no quedo ajustado' % (off, i)
            i += 5
    dst = rom[RETRO + 1] | (rom[RETRO + 2] << 8)
    assert dst == CUEVA_CPU, 'el retroceso no salta a la cueva'
    assert bytes(rom[CUEVA_ROM:CUEVA_ROM + len(cueva)]) == cueva

    # el BMI cae en el STZ $3B50 y no en otro sitio (norma 345: contarlo)
    # el BMI ocupa 2 B en $DFD5-$DFD6, asi que el PC tras leerlo es $DFD7
    destino = (CUEVA_CPU + 3) + 2 + rom[CUEVA_ROM + 4]
    off_destino = CUEVA_ROM + (destino - CUEVA_CPU)
    assert rom[off_destino] == 0x9C, \
        'el BMI cae en $%04X, donde hay $%02X y no un STZ' % (
            destino, rom[off_destino])
    assert destino == CUEVA_CPU + 8, 'el BMI no cae en el cierre'

    # las celdas ya no solapan: menu $1C0-$1C3/$1D0-$1D3, abuelo $1C4+
    CB = 0x170
    menu = set(range(0x1C0, 0x1C4)) | set(range(0x1D0, 0x1D4))
    for i in range(18):
        celda = CB + rom[0x47CA1 + i * 5]
        assert celda not in menu, \
            'el registro %d del abuelo ($%03X) sigue en el rango del menu' % (i, celda)

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    open(salida, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % salida)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '/tmp/v384.pce')
