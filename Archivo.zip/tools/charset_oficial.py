"""charset_oficial.py - El codificador VALIDADO del proyecto.

Procedencia: `uploads/Extracto chat inicial.txt`, el chat original del
proyecto. Es el mismo `CHAR_TO_CODE` con el que David tradujo la pantalla
de «El canto de Jizo no es correcto», que lleva funcionando desde
entonces con minúsculas y tildes.

POR QUÉ FUNCIONA (verificado contra la ROM)
-------------------------------------------
El renderer tiene DOS rutas:

    byte >= 0xA0  -> ruta KATAKANA: el glifo se toma DIRECTO del byte
    byte <  0xA0  -> ruta TABLA:    glifo = tabla[byte-0x30]  (0x43F9B)

Las minúsculas y los acentos viven en 0xA1-0xDD, o sea que van por la
ruta katakana y **no tocan la tabla 0x43F9B**. Por eso no pueden romper
la parrilla del Canto de Jizo ni el menú lateral: esas pantallas usan la
ruta de la tabla.

Comprobado glifo a glifo en la ROM: 0xA1='a', 0xA5='e', 0xBB='á',
0xBC='é', 0xBD='í', 0xC2='Á', 0xC8='Ñ', 0xCA='¡', 0xCB='.', 0xCC=','.

LOS TRES ALIAS
--------------
'b', 'c' y 'p' NO usan su byte directo (0xA2, 0xA3, 0xB0) sino alias de
la zona ASCII (0x5B, 0x5D, 0x5E), cuyas entradas de tabla apuntan
precisamente a los glifos 0xA2, 0xA3 y 0xB0. En el chat original están
marcados como «unsafe direct bytes». Se respeta esa decisión: viene de
producción y funciona.
"""

CHAR_TO_CODE = {' ': 0x20}
for _i in range(10):
    CHAR_TO_CODE[str(_i)] = 0x30 + _i
for _i in range(26):
    CHAR_TO_CODE[chr(ord('A') + _i)] = 0x41 + _i
CHAR_TO_CODE.update({'!': 0x21, '?': 0x3F, '$': 0x24})
for _i, _ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    CHAR_TO_CODE[_ch] = 0xA1 + _i
# bytes directos no seguros -> alias de la zona ASCII
CHAR_TO_CODE['b'] = 0x5B
CHAR_TO_CODE['c'] = 0x5D
CHAR_TO_CODE['p'] = 0x5E
CHAR_TO_CODE.update({
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ü': 0xC0, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6, 'Ü': 0xC7, 'Ñ': 0xC8,
    '¿': 0xC9, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD, ';': 0xCE, '…': 0xCF,
    "'": 0xD0, '"': 0xD1, '-': 0xD2, '/': 0xD3, '(': 0xD4, ')': 0xD5, '%': 0xD6,
    '&': 0xD7, '+': 0xD8, '¤': 0xD9, 'ç': 0xDA, 'Ç': 0x5F, 'º': 0xDC, 'ª': 0xDD,
})

# Códigos de control del motor de diálogo
FIN_LINEA = 0x00
WAIT      = 0xFD
PAGE      = 0xFC
FIN_PAG   = 0xFE
FIN_TEXTO = 0xFF


def encode(s):
    """Codifica una cadena. Lanza ValueError si algún carácter no existe."""
    out = bytearray()
    for ch in s:
        if ch == '\n':
            out.append(FIN_LINEA)
        elif ch in CHAR_TO_CODE:
            out.append(CHAR_TO_CODE[ch])
        else:
            raise ValueError(f'carácter no soportado: {ch!r}')
    return bytes(out)
