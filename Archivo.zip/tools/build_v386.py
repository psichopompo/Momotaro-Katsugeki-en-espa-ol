#!/usr/bin/env python3
"""Prueba: recortar el volcado de CG del menu RUN para que no pise el bocadillo.

MEDIDO:
  ROM 0x22CA0  stream comprimido, 1 byte de cuenta (58) + 1328 B
               -> celdas $1C0..$1F9  (58 celdas)
  El menu SOLO dibuja con $1C0-$1C3, $1D0-$1D3 y $1E0-$1F9.
  El bocadillo del abuelo vive en $1C4-$1CA, $1D4-$1DA, $1DC, $1DD.

ARREGLO: partir el stream en tres y saltarse las 24 celdas de enmedio.
  A  4 celdas -> $1C0   (dest $7000)
  B  4 celdas -> $1D0   (dest $7400)
  C 26 celdas -> $1E0   (dest $7800)
"""
import sys, hashlib, zlib
sys.path.insert(0, 'tools')
import cg

SRC = 'roms/momotaro_es_v385.pce'
DST = 'roms/momotaro_es_v386.pce'

STREAM   = 0x22CA0
D287     = 0x19287          # JSR $F1B9  dentro de $D268
CAVA_ROM = 0x19FE1          # CPU $DFE1, banco $0C
CAVA_CPU = 0xDFE1

rom = bytearray(open(SRC, 'rb').read())

# ---- 1. leer y trocear el stream -----------------------------------------
cells, size = cg.decode_stream(rom, STREAM)
assert len(cells) == 58, len(cells)
assert size == 1329, size
assert rom[STREAM] == 58

A = cells[0:4]           # $1C0-$1C3
B = cells[16:20]         # $1D0-$1D3
C = cells[32:58]         # $1E0-$1F9

nuevo = cg.encode_stream(A) + cg.encode_stream(B) + cg.encode_stream(C)
assert len(nuevo) <= size, (len(nuevo), size)

# round-trip de control: lo que escribo se vuelve a leer igual
for off, blk in ((0, A), (len(cg.encode_stream(A)), B),
                 (len(cg.encode_stream(A)) + len(cg.encode_stream(B)), C)):
    leido, _ = cg.decode_stream(nuevo, off)
    assert leido == blk, 'round-trip roto en offset %d' % off

rom[STREAM:STREAM + size] = nuevo + b'\xFF' * (size - len(nuevo))

# ---- 2. la cueva ----------------------------------------------------------
assert all(b == 0xFF for b in rom[CAVA_ROM:0x1A000]), 'la cueva no esta libre'

cava = bytes([
    0x20, 0xB9, 0xF1,        # JSR $F1B9        A -> $1C0..$1C3
    0xA9, 0x74,              # LDA #$74
    0x8D, 0x27, 0x31,        # STA $3127        dest = $7400
    0x20, 0xB9, 0xF1,        # JSR $F1B9        B -> $1D0..$1D3
    0xA9, 0x78,              # LDA #$78
    0x8D, 0x27, 0x31,        # STA $3127        dest = $7800
    0x4C, 0xB9, 0xF1,        # JMP $F1B9        C -> $1E0..$1F9  (y RTS al llamador)
])
assert CAVA_ROM + len(cava) <= 0x1A000
rom[CAVA_ROM:CAVA_ROM + len(cava)] = cava

# ---- 3. desviar la llamada ------------------------------------------------
assert bytes(rom[D287:D287 + 3]) == b'\x20\xB9\xF1', 'firma de D287'
rom[D287:D287 + 3] = bytes([0x20, CAVA_CPU & 0xFF, CAVA_CPU >> 8])

# ---- 4. zonas que NO se pueden haber movido -------------------------------
virgen = open(SRC, 'rb').read()
tocado = set(range(STREAM, STREAM + size)) | \
         set(range(CAVA_ROM, CAVA_ROM + len(cava))) | \
         set(range(D287, D287 + 3))
distintos = {i for i in range(len(rom)) if rom[i] != virgen[i]}
assert distintos <= tocado, sorted(distintos - tocado)[:10]

open(DST, 'wb').write(rom)
print('%s  %d B' % (DST, len(rom)))
print('  stream  %d B -> %d B  (%d celdas omitidas)' % (size, len(nuevo), 24))
print('  cueva   $%04X  %d B' % (CAVA_CPU, len(cava)))
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
