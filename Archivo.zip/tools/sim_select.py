"""sim_select.py - simulador de la BAT del menu SELECT.

Parte del volcado de VRAM real (docs/select_vram.bin) y permite reescribir
celdas para previsualizar una traduccion antes de tocar la ROM.
Norma 60: solo vale porque reproduce la captura de David pixel a pixel.
"""
import struct
import os
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
from charset_oficial import CHAR_TO_CODE
from PIL import Image

VRAM = open(os.path.join(RAIZ, 'docs', 'select_vram.bin'), 'rb').read()
PAL = open(os.path.join(RAIZ, 'docs', 'select_pal.bin'), 'rb').read()
FILL = 0x11B


def _cols():
    out = []
    for i in range(len(PAL) // 2):
        c = struct.unpack('<H', PAL[i * 2:i * 2 + 2])[0]
        out.append((((c >> 3) & 7) * 36, ((c >> 6) & 7) * 36, (c & 7) * 36))
    return out


COLS = _cols()


class Sim:
    def __init__(self):
        self.v = bytearray(VRAM)

    def set(self, cx, cy, pat, pal=0):
        o = (cy * 64 + cx) * 2
        self.v[o:o + 2] = struct.pack('<H', (pal << 12) | pat)

    def limpia(self, cx, cy, n, filas=1):
        for r in range(filas):
            for i in range(n):
                self.set(cx + i, cy + r, FILL)

    def txt(self, cx, cy, t):
        for i, ch in enumerate(t):
            if ch == ' ':
                self.set(cx + i, cy, FILL)
            else:
                self.set(cx + i, cy, 0x200 + CHAR_TO_CODE[ch])

    def png(self, ruta, S=3, filas=22, cols=32):
        img = Image.new('RGB', (cols * 8 * S, filas * 8 * S))
        px = img.load()
        v = self.v
        for cy in range(filas):
            for cx in range(cols):
                e = struct.unpack('<H', v[((cy * 64 + cx) * 2):((cy * 64 + cx) * 2) + 2])[0]
                pat = e & 0xFFF
                pal = e >> 12
                base = pat * 32
                for y in range(8):
                    b0 = v[base + y * 2]
                    b1 = v[base + y * 2 + 1]
                    b2 = v[base + 16 + y * 2]
                    b3 = v[base + 16 + y * 2 + 1]
                    for x in range(8):
                        m = 0x80 >> x
                        val = ((b0 & m) and 1) | ((b1 & m) and 2) | \
                              ((b2 & m) and 4) | ((b3 & m) and 8)
                        c = COLS[pal * 16 + val] if val else COLS[0]
                        for sy in range(S):
                            for sx in range(S):
                                px[(cx * 8 + x) * S + sx, (cy * 8 + y) * S + sy] = c
        img.save(ruta)


def base_limpia():
    """Borra las celdas de los siete rotulos, sin tocar marco ni cifras."""
    s = Sim()
    for cy in (3, 4, 5, 6, 7):
        s.limpia(2, cy, 8)
    for cy in (6, 7):
        s.limpia(2, cy, 4)
    for cy in (10, 11):
        s.limpia(2, cy, 10)
    for cy in (15, 16):
        s.limpia(2, cy, 10)
    for cy in (3, 4):
        s.limpia(14, cy, 8)
        s.limpia(24, cy, 6)
    return s


def txt_fina(sim, cx, cy, t):
    """Escribe con la FUENTE FINA (la que el original usa para el contenido).

    Ruta ALTA: patron = $2A0 + (codigo - $A0).
    Excepciones medidas: 'b','c','p' viven en $5B/$5D/$5E y en el CG del
    menu caen en $25B/$25D/$25E, que TAMBIEN son minusculas finas.
    """
    for i, ch in enumerate(t):
        if ch == ' ':
            sim.set(cx + i, cy, FILL)
            continue
        k = CHAR_TO_CODE[ch]
        if k >= 0xA0:
            sim.set(cx + i, cy, 0x2A0 + (k - 0xA0))
        else:
            sim.set(cx + i, cy, 0x200 + k)
