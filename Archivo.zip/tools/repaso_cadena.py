#!/usr/bin/env python3
"""repaso_cadena.py - repasa TODA la cadena de versiones con el arnés bueno.

Para cada ROM corre los 57 savestates y guarda una FIRMA (md5) de cada
captura muestreada. Después compara versión contra versión.

El md5 se usa sólo para DETECTAR el par (state, frame) que difiere; el
detalle en píxeles se saca luego re-ejecutando sólo ese caso, así que no
incumple la norma 365 (que prohíbe *concluir* a partir de una firma).

Una ROM viva cada vez: norma 378.
"""
import glob
import hashlib
import json
import os
import sys

sys.path.insert(0, 'tools')
from pce import PCE
import estados

FRAMES = 300
PASO = 25
CACHE = '/tmp/repaso'


def firmas(rom, etq):
    """{state: {frame: md5}}   con caché en disco."""
    os.makedirs(CACHE, exist_ok=True)
    cache = '%s/%s.json' % (CACHE, etq)
    if os.path.exists(cache):
        return json.load(open(cache))
    out = {}
    for st in sorted(glob.glob('states/*.state')):
        p = PCE(rom)
        try:
            if not estados.carga(p, st):
                continue
        except Exception:
            continue
        d = {}
        for f in range(1, FRAMES + 1):
            p.run(1)
            if (f % PASO == 0 or f == FRAMES) and p.frame:
                p.png('/tmp/_rc.png')
                d[str(f)] = hashlib.md5(open('/tmp/_rc.png', 'rb').read()).hexdigest()
        out[st] = d
        del p
    json.dump(out, open(cache, 'w'))
    return out


def main():
    vers = sys.argv[1:]
    prev = None
    for v in vers:
        rom = '/tmp/hitos/v%s.pce' % v
        f = firmas(rom, v)
        n = sum(len(d) for d in f.values())
        if prev is None:
            print('v%s   %d states, %d capturas  (base)' % (v, len(f), n))
        else:
            pv, pf = prev
            difs = []
            for st in sorted(set(f) & set(pf)):
                cam = [fr for fr in sorted(set(f[st]) & set(pf[st]), key=int)
                       if f[st][fr] != pf[st][fr]]
                if cam:
                    difs.append((st.split('/')[-1], len(cam), cam[0]))
            print('v%s vs v%s   %d capturas   %d states cambian'
                  % (v, pv, n, len(difs)))
            for nom, k, pr in difs:
                print('     %-42s %2d capturas (1ª en frame %s)' % (nom, k, pr))
        prev = (v, f)


if __name__ == '__main__':
    main()
