#!/usr/bin/env python3
"""vitores.py - Motor de los VITORES (pancarta de fin de fase).

MEDIDO sobre la ROM y VERIFICADO contra el buffer $2593 del savestate
`Vitores.state` de David: la simulacion reproduce los 72 B EXACTOS.

CADENA DE LLAMADA
-----------------
    $C419 (ROM 0x16419)  LDA $3B00 / ASL / ASL / ORA ($3B28 & 3) -> Y
                         LDA $C459,Y -> indice de bloque
                         ASL / TAY
                         LDA $C433,Y / $C434,Y -> $14/$15  (puntero al texto)
                         LDY $2CF0,X / LDA $30A2,Y / $30E2,Y -> $16/$17 (VRAM)
    $C430                JMP $C997
    $C997 (ROM 0x16997)  mapea banco $24 en MPR2 y $25 en MPR3
                         LDX #$02  (2 lineas)
                         LDX #$12  (18 columnas por linea)
                         JSR $9B0B por caracter -> buffer $2593 (4x18 tiles)

TABLAS (banco $0B, ROM 0x16000-0x18000 -> $C000-$DFFF)
-----------------------------------------------------
    $C433 = ROM 0x16433 : 19 words, punteros $418A..$4456 (banco $24)
    $C459 = ROM 0x16459 : 28 bytes = 7 mundos x 4 fases -> indice de bloque

LECTOR $9B0B (ROM 0x41B0B, banco $20) - el MISMO de las tiendas
---------------------------------------------------------------
    b <  $20  -> devuelve b tal cual, CLC  (se pinta y consume columna)
    b == $5C  -> conmuta $3666 (juego de glifos), NO consume columna
    b <  $A0  -> x = b-$20 (b<$60) o b-$40 (b>=$60); glifo = $9C73+x
    b >= $A0  -> $A1/$A4/$B0/$DE/$DF usan el flag $3690; el resto, $3666
                 flag=1 -> x = b-$20     flag=0 -> x = b-$60
                 CARRY = (b >= $DE)  <-- solo $DE y $DF ponen carry
    carry set -> el glifo va a la FILA DE ARRIBA (buf[$10-$13]) y NO
                 consume columna: asi se pintan dakuten y handakuten.

Al entrar, $C997 deja $3666=1 (JSR $9C5F) y $3690=0 (JSR $9C6F): la misma
configuracion que el lector de tiendas $C6C4, luego la codificacion de
`charset_oficial` vale igual aqui (norma 256: b/c/p/C-cedilla por alias).
"""
import struct

ROM_TABLA_PTR = 0x16433   # $C433, 19 words
ROM_TABLA_IDX = 0x16459   # $C459, 7 mundos x 4 fases
ROM_GLIFOS    = 0x41C73   # $9C73, banco $20
N_BLOQUES     = 19
COLS          = 18
FILAS         = 2

# Bloques que encajan en la misma rejilla justo ANTES de $418A pero a los
# que la tabla $C433 no apunta.  [HIPOTESIS] los alcanza otra rutina
# (candidata: $96F5 = ROM 0x416F5, que mapea el banco $0B y salta a $C997).
HUERFANOS = [0x480E8, 0x48112, 0x48139, 0x48163]


def punteros(rom):
    """Los 19 punteros logicos de $C433."""
    return list(struct.unpack('<%dH' % N_BLOQUES,
                              rom[ROM_TABLA_PTR:ROM_TABLA_PTR + N_BLOQUES * 2]))


def offsets(rom):
    """Los 19 punteros traducidos a offset de ROM (banco $24 en $4000)."""
    return [0x48000 + p - 0x4000 for p in punteros(rom)]


def indices(rom):
    """Tabla $C459: devuelve [mundo][fase] -> indice de bloque."""
    t = rom[ROM_TABLA_IDX:ROM_TABLA_IDX + 28]
    return [list(t[m * 4:m * 4 + 4]) for m in range(7)]


def render(rom, off, f3666=1, f3690=0):
    """Simula $C997 byte a byte.  Devuelve (buffer de 72 B, offset final)."""
    glif = rom[ROM_GLIFOS:ROM_GLIFOS + 0x100]
    buf = bytearray(FILAS * 2 * COLS)
    p = off
    z10 = COLS                      # $10, cursor dentro del buffer
    for _ in range(FILAS):
        col = COLS
        while col:
            b = rom[p]
            p += 1
            if b == 0x5C:           # conmutador de juego de glifos
                f3666 ^= 1
                continue
            if b < 0x20:            # devuelto tal cual, CLC
                g, carry = b, False
            elif b < 0xA0:
                x = b - 0x20 if b < 0x60 else b - 0x40
                g, carry = glif[x], False
            else:
                especial = b in (0xA1, 0xA4, 0xB0, 0xDE, 0xDF)
                f = f3690 if especial else f3666
                x = b - 0x20 if f else b - 0x60
                g, carry = glif[x], b >= 0xDE
            if carry:               # dakuten: fila de arriba, sin gastar columna
                buf[z10 - 0x13] = g
                continue
            buf[z10] = g
            z10 += 1
            col -= 1
        z10 += COLS                 # LDA $10 / CLC / ADC #$12 / STA $10
    return bytes(buf), p


def longitud(rom, off):
    """Bytes que consume un bloque leido como lo lee el motor."""
    return render(rom, off)[1] - off


if __name__ == '__main__':
    import sys
    rom = open(sys.argv[1] if len(sys.argv) > 1
               else 'roms/momotaro_es_v313.pce', 'rb').read()
    for i, o in enumerate(offsets(rom)):
        print('%2d  $%04X  ROM %06X  %2d B' % (i, punteros(rom)[i], o,
                                               longitud(rom, o)))
    print()
    for m, fila in enumerate(indices(rom)):
        print('mundo %d -> bloques %s' % (m, fila))
