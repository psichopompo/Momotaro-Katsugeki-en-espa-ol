#!/usr/bin/env python3
"""build_v383.py - Menu RUN: las tres ventanas al centro, una sola visible.

BASE: v381 (6273154e4efc18cb279c3c8e0d7e9138)

CORRIGE LA v382
---------------
La v382 ocultaba el MARCO de las ventanas inactivas pero no su TEXTO, asi
que David seguia viendo un recuadro negro colgando debajo de «No puedo» y
de «Nada»: era el texto de la ventana de abajo, ya sin su marco.

En el primer intento (descartado) ya probe a ocultar los dos, y lo di por
imposible porque «cambiaba de escena». **Era un error mio de aritmetica**:
escribi `BNE +7` cuando el desplazamiento correcto es `+6`. El salto caia
un byte mas alla del RTS y la CPU ejecutaba basura. No tenia nada que ver
con `$D5AE`.

LA PROPUESTA ES DE DAVID
------------------------
El menu RUN se abria en cascada descendente hacia la derecha, y la primera
ventana (Objetos/Artes, en X=16 Y=57) invadia la banda del bocadillo del
abuelo. David propuso que **las tres ventanas se abran en el centro, donde
esta la segunda, y que solo se vea la activa**.

EL BUG QUE RESUELVE (medido)
----------------------------
No era solapamiento de dibujo: era el **limite de ancho de sprites por
linea** del HuC6270. El VDC procesa 16 slots de 16 px por linea (256 px);
un sprite de 32 px consume dos.

En las lineas 57-66, con el menu abierto sobre el bocadillo:

    menu RUN     spr 0,6,7,2      5 slots
    bocadillo    9 segmentos      9 slots
    HUD derecho  spr 21,20,19     4 slots
                                 ---------
                                 19 slots   (caben 16)

Los 3 ultimos se perdian: por eso el HUD de la derecha aparecia cortado y
se veian franjas del fondo.

Referencia: el mismo savestate en la ROM japonesa da **16 slots exactos**,
justo en el limite. El bocadillo japones es estrecho (X=160..223) y el
nuestro mide el doble (X=81..209) porque se ensancho para el castellano.

LO QUE SE TOCA
--------------
1. Tabla de coordenadas de las ventanas, ROM 0x195A6 (CPU $D5A6), cuatro
   entradas de 2 bytes (X, Y) indexadas por `$3BA2`:

       nivel 0:  X=$10 Y=$39   ->  X=$50 Y=$61
       nivel 1:  X=$50 Y=$61   ->  X=$50 Y=$61   (ya estaba)
       nivel 2:  X=$90 Y=$99   ->  X=$50 Y=$61
       nivel 3:  X=$90 Y=$99   ->  X=$50 Y=$61

2. El marco Y EL TEXTO de las ventanas INACTIVAS no se dibujan. En
   `$D59B` hay `JSR $E3EB` (marco) y en `$D59E` `JSR $D5AE` (texto); los
   6 bytes se sustituyen por `JSR cueva` + 3 NOP, y la cueva llama a los
   dos solo si la ventana que toca dibujar es la activa:

       LDA $3BA2 / CMP $3B51 / BNE +6 / JSR $E3EB / JSR $D5AE / RTS

   El `BNE +6` cae exactamente en el RTS. Contarlo mal (+7) fue lo que
   hizo fracasar el primer intento.

   Cueva de 15 B en `$DFC3` (ROM 0x19FC3), donde hay 61 B de $FF libres.

LO QUE **NO** SE TOCA, Y POR QUE  (aqui me equivoque tres veces)
-----------------------------------------------------------------
- **`ORA $3B51` en `$D319`**: NO es un calculo de celda de BAT. El texto
  del menu son **tiles de sprite horneados en VRAM $7000-$77FF**, y ese
  ORA elige el JUEGO DE TILES de cada nivel:

      nivel 0 -> tiles $1C0-$1C3 / $1D0-$1D3
      nivel 1 -> tiles $1C4-$1C7 / $1D4-$1D7
      nivel 2 -> tiles $1C8-$1CB / $1D8-$1DB

  Al ponerle NOP, los tres niveles horneaban en los mismos tiles y se
  machacaban: al volver de Onigiri a Objetos seguia leyendose «Onigiri»,
  y «No puedo» / «Nada» arrastraban un recuadro negro debajo (el tile del
  nivel anterior). Lo cazaron las capturas del Sprite Viewer de David:
  sprite 39, tile index $1DD, tile address $7740.w.

- **El bucle de `$D559`**: acumula el indice de sprite. Cortarlo con BMI
  dejaba la SAT a medias y salia basura (39 slots, paletas absurdas).

- **`$D591` (las coordenadas)**: alimentan a `$EE86`, que guarda X/Y en
  `$4E-$51` y de ahi comen **el marco Y el texto**. Tocarlo ocultaba los
  dos y las ventanas salian vacias.

RESULTADO MEDIDO
----------------
    nivel        antes    despues
    Objetos      19 slots   13    OK
    Onigiri      19 slots   13    OK
    Comer        18 slots   16    OK

Verificado en pantalla el recorrido completo ida y vuelta, y los dos casos
que David reporto: «Nada» (Artes vacio) y «No puedo», ambos ya sin el
recuadro colgando debajo.

NO-REGRESION: 195 puntos, 0 diferencias (partida nueva con 3 semillas
aleatorias + los 4 finales por savestate).

PENDIENTE, no lo arregla esta version
-------------------------------------
El bocadillo del abuelo sigue siendo ancho y azul (el japones lo pinta
estrecho y blanco). Eso es otro asunto, y David lo quiere ver aparte.
"""
import hashlib
import sys
import zlib

BASE = 'roms/momotaro_es_v381.pce'
MD5_BASE = '6273154e4efc18cb279c3c8e0d7e9138'

TABLA = 0x195A6         # CPU $D5A6: 4 pares (X, Y)
MARCO = 0x1959B         # CPU $D59B: JSR $E3EB + JSR $D5AE (6 B)
CUEVA_ROM = 0x19FC3     # CPU $DFC3 (en 0x19FC2 hay un $00 del bloque anterior)
CUEVA_CPU = 0xDFC3

X_CENTRO = 0x50         # 80
Y_CENTRO = 0x61         # 97

INTACTAS = [
    (0x00000, 0x1959B, 'todo lo anterior al JSR del marco'),
    (0x195A1, 0x195A6, 'entre el parche y la tabla'),
    (0x195AE, 0x19FC2, 'de la tabla a la cueva: TODO el banco $0C'),
    (0x19FD2, 0x80000, 'de la cueva al final: quiz, creditos, finales'),
]


def main(salida):
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v381'
    assert len(rom) == 524288, 'la ROM no mide 512 KB'

    # ---- 0. el estado de partida es el que creo -------------------------
    esperado = [(0x10, 0x39), (0x50, 0x61), (0x90, 0x99), (0x90, 0x99)]
    for i, (x, y) in enumerate(esperado):
        assert rom[TABLA + i * 2] == x and rom[TABLA + i * 2 + 1] == y, \
            'la tabla de ventanas no es la que espero en el nivel %d' % i
    assert bytes(rom[MARCO:MARCO + 6]) == bytes([0x20, 0xEB, 0xE3,
                                                 0x20, 0xAE, 0xD5]), \
        'en $D59B no estan los JSR del marco y del texto'
    assert all(b == 0xFF for b in rom[CUEVA_ROM:CUEVA_ROM + 15]), \
        'la cueva de $DFC3 no esta limpia'
    # lo que NO se toca tiene que seguir ahi
    assert bytes(rom[0x19319:0x1931C]) == bytes([0x0D, 0x51, 0x3B]), \
        'falta el ORA $3B51 de $D319 (elige el juego de tiles)'
    assert bytes(rom[0x19559:0x1955C]) == bytes([0xAE, 0x51, 0x3B]), \
        'el bucle de $D559 no esta intacto'
    # ---- 1. las cuatro ventanas al centro -------------------------------
    for i in range(4):
        rom[TABLA + i * 2] = X_CENTRO
        rom[TABLA + i * 2 + 1] = Y_CENTRO

    # ---- 2. marco Y TEXTO solo de la ventana activa ---------------------
    rom[MARCO] = 0x20
    rom[MARCO + 1] = CUEVA_CPU & 0xFF
    rom[MARCO + 2] = CUEVA_CPU >> 8
    rom[MARCO + 3:MARCO + 6] = b'\xEA\xEA\xEA'
    cueva = bytes([
        0xAD, 0xA2, 0x3B,     # LDA $3BA2    ventana que toca dibujar
        0xCD, 0x51, 0x3B,     # CMP $3B51    nivel activo
        0xD0, 0x06,           # BNE +6       no es la activa -> RTS
        0x20, 0xEB, 0xE3,     # JSR $E3EB    dibuja el marco
        0x20, 0xAE, 0xD5,     # JSR $D5AE    dibuja el texto
        0x60,                 # RTS
    ])
    rom[CUEVA_ROM:CUEVA_ROM + len(cueva)] = cueva

    # ---- VERIFICACION ---------------------------------------------------
    for i in range(4):
        assert rom[TABLA + i * 2] == X_CENTRO, 'ventana %d sin centrar' % i
        assert rom[TABLA + i * 2 + 1] == Y_CENTRO, 'ventana %d sin centrar' % i
    dst = rom[MARCO + 1] | (rom[MARCO + 2] << 8)
    assert dst == CUEVA_CPU, 'el JSR del marco no apunta a la cueva'
    assert bytes(rom[CUEVA_ROM:CUEVA_ROM + len(cueva)]) == cueva, \
        'la cueva releida no cuadra'
    # el ORA y el bucle siguen intactos
    assert bytes(rom[0x19319:0x1931C]) == bytes([0x0D, 0x51, 0x3B])
    assert bytes(rom[0x19559:0x1955C]) == bytes([0xAE, 0x51, 0x3B])

    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    open(salida, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % salida)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '/tmp/v382.pce')
