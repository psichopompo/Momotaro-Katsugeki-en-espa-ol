#!/usr/bin/env python3
"""fix_password.py - Devuelve el «!» a «¡Introduce el canto de Jizo!».

BASE: v334 (7608edb92eeccae3eed71f8c618d1a0e). Salida configurable.

QUÉ PASÓ (medido, no supuesto)
------------------------------
El «!» estaba bien hasta la **v319** y desapareció en la **v320**.

    v319  0x1F89C = $21 '!'   0x1F89D = $01  «Aldea Dormilón»
    v320  0x1F89C = $01       0x1F89E = 'A'  «Aldea Dormilón»

La v320 reescribió el bloque de rótulos de aldea `0x1F89C..0x1F900` para
meter «Aldea Taketori» (3 B más que «Bambú») y **empezó a escribir un byte
antes de la cuenta**: en 0x1F89C, que era del password, no de los rótulos.
Se comió el «!».

El assert de la v320 (`assert p == 0x1F8F9`) comprobaba dónde ACABABA el
bloque, no dónde empezaba, así que no lo cazó. Ese es el fallo de método:
verifiqué la cola y no la cabeza.

Después, la v324 revirtió «Taketori» a «Bambú» pero dejó los punteros
desplazados, así que quedaron 3 B muertos ($FF) en 0x1F8EC..0x1F8EE.

CÓMO CORTA EL MOTOR (medido en emulador, corrige el diagnóstico anterior)
-------------------------------------------------------------------------
Tres ROMs de prueba en el emulador:

  test1  27 caracteres A..Z,a  -> se ven 27 + la 'A' del rótulo = 28
  test2  $FF metido en 0x1F89B -> corta ahí: «...canto de Jiz»
  test3  28 caracteres         -> se ven los 28 y NO sigue

Conclusión: el motor pinta **hasta $FF o hasta 28 columnas**, lo que llegue
antes. El diagnóstico viejo («máximo 26 B, hay que decir *Escribe*») era
FALSO: nunca lo medí, lo deduje. «¡Introduce el canto de Jizo!» son 28
caracteres exactos y CABEN, que es justamente como estaba en la v319.

DOS CHARSETS EN LA MISMA PANTALLA (lo cazó el assert)
-----------------------------------------------------
El password NO usa `charset_rotulos` sino `charset_oficial`: su «o» es
$AF y su «e» es $A5, no los alias $62/$3D de los rótulos. Los rótulos que
van justo detrás, en el mismo bloque, sí usan los alias. Comprobado byte a
byte contra la v319. El «!» es $21 en los dos, por suerte.

EL ARREGLO
----------
Se recompone el bloque entero devolviendo el «!» y añadiendo además un
`$FF` explícito de cierre (la v319 no lo tenía; se apoyaba en el corte por
ancho). Los 6 rótulos se recompactan detrás -- eso recupera de paso los
3 B muertos de la v324 -- y se repuntan las 6 entradas de la tabla B.

    0x1F880  $01
    0x1F881  «¡Introduce el canto de Jizo!»   28 caracteres
    0x1F89D  $FF                              cierre explícito
    0x1F89E  $01 «Aldea Dormilón»  $FF        B[3] = $589E
    0x1F8AE  $01 «Aldea Urashima»  $FF        B[4] = $58AE
    0x1F8BE  $01 «Aldea Kachiyama» $FF        B[5] = $58BE
    0x1F8CF  $01 «Aldea Issunboshi» $FF       B[6] = $58CF
    0x1F8E1  $01 «Aldea Bambú»     $FF        B[7] = $58E1
    0x1F8EE  $01 «Isla Ogros»      $FF        B[8] = $58EE
    0x1F8FA..0x1F8FF  $FF de relleno (6 B libres)

POR QUÉ NO ROMPE NADA
---------------------
Barrido de los 524288 B buscando cualquier puntero LE con valor en
$5878..$5900: aparecen 200 coincidencias, pero **todas menos las 6 de la
tabla B son byte a byte idénticas a la ROM japonesa**, o sea que son
gráficos y código, no referencias a los rótulos. La única tabla que apunta
a esta zona es la B (`0x4379D`), y se repunta aquí.
"""
import hashlib
import struct
import sys
import zlib

sys.path.insert(0, 'tools')
from charset_rotulos import encode as encode_rot     # noqa: E402
from charset_oficial import encode as encode_pw      # noqa: E402

BASE = 'roms/momotaro_es_v334.pce'
MD5_BASE = '7608edb92eeccae3eed71f8c618d1a0e'

TABLA_B = 0x4379D
PW_CMD = 0x1F880          # el $01 que abre la cadena del password
PW_TXT = 0x1F881
BLOQUE_FIN = 0x1F900      # límite duro: a partir de aquí son datos

PASSWORD = '¡Introduce el canto de Jizo!'
ROTULOS = ['Aldea Dormilón', 'Aldea Urashima', 'Aldea Kachiyama',
           'Aldea Issunboshi', 'Aldea Bambú', 'Isla Ogros']
FIJOS = ['Aldea de la Partida', 'Aldea Florecer', 'Aldea Kintaro']

# zonas que este parche NO puede tocar
INTACTAS = [
    (0x00000, 0x1F880, 'todo lo anterior al password'),
    (0x1F900, 0x4379D, 'del banco $0F a la tabla B: quiz, dados, tiendas...'),
    (0x437AF, 0x80000, 'de la tabla B al final: menú RUN, créditos, QUIZ'),
]


def main(salida):
    rom = bytearray(open(BASE, 'rb').read())
    original = bytes(rom)
    assert hashlib.md5(original).hexdigest() == MD5_BASE, 'la base no es la v334'
    assert len(rom) == 524288, 'la ROM no mide 512 KB'

    # ---- 0. el estado de partida es EXACTAMENTE el que creo ------------
    assert rom[PW_CMD] == 0x01, 'el password no abre con $01'
    viejo = encode_pw('¡Introduce el canto de Jizo')
    assert rom[PW_TXT:PW_TXT + len(viejo)] == viejo, \
        'en 0x1F881 no está la cadena del password que espero'
    assert rom[0x1F89C] == 0x01, \
        'en 0x1F89C ya no está el $01 del rótulo: la ROM no es la que creo'
    assert rom[0x1F89D] == 0x41, 'la «A» culpable no está en 0x1F89D'
    # los 3 bytes muertos que dejó la v324
    assert rom[0x1F8EC:0x1F8EF] == b'\xff\xff\xff', \
        'no están los 3 B muertos de la v324'
    assert all(b == 0xFF for b in rom[0x1F8FA:BLOQUE_FIN]), \
        'el relleno final no está limpio'

    # el charset reproduce los 3 rótulos que NO se mueven
    for off, txt in ((0x1E25C, FIJOS[0]), (0x1E271, FIJOS[1]),
                     (0x1E281, FIJOS[2])):
        assert rom[off:off + len(encode_rot(txt))] == encode_rot(txt), \
            'el charset de rótulos no reproduce «%s»' % txt

    # ---- 1. el password cabe en 28 columnas ----------------------------
    pw = encode_pw(PASSWORD)
    assert len(pw) == 28, 'el password mide %d caracteres, no 28' % len(pw)
    assert pw[-1] == 0x21, 'el último byte no es el «!»'

    # ---- 2. componer el bloque entero ----------------------------------
    bloque = bytearray(b'\x01') + pw + b'\xff'
    punteros = []
    for txt in ROTULOS:
        punteros.append(PW_CMD + len(bloque))
        bloque += b'\x01' + encode_rot(txt) + b'\xff'

    libre = BLOQUE_FIN - PW_CMD - len(bloque)
    assert libre >= 0, 'el bloque se pasa %d B' % -libre
    print('  bloque %d B, %d B libres de relleno' % (len(bloque), libre))

    rom[PW_CMD:BLOQUE_FIN] = bytes(bloque) + b'\xff' * libre

    # ---- 3. repuntar las 6 entradas de la tabla B ----------------------
    tabla = bytearray(rom[TABLA_B:TABLA_B + 18])
    for i, off in enumerate(punteros):
        v = 0x4000 + (off - 0x1E000)
        assert 0x5800 <= v < 0x5900, 'puntero fuera de la zona: $%04X' % v
        struct.pack_into('<H', tabla, (3 + i) * 2, v)
    rom[TABLA_B:TABLA_B + 18] = bytes(tabla)

    # ---- VERIFICACIÓN: releer siguiendo el puntero ---------------------
    esperados = FIJOS + ROTULOS
    for i, txt in enumerate(esperados):
        p = struct.unpack('<H', rom[TABLA_B + i * 2:TABLA_B + i * 2 + 2])[0]
        o = 0x1E000 + p - 0x4000
        assert rom[o] == 0x01, 'rótulo %d no abre con $01' % i
        e = rom.find(b'\xff', o)
        assert bytes(rom[o + 1:e]) == encode_rot(txt), \
            'rótulo %d releído no es «%s»' % (i, txt)
    # los 3 primeros no se han movido
    for i, esp in enumerate((0x425B, 0x4270, 0x4280)):
        v = struct.unpack('<H', rom[TABLA_B + i * 2:TABLA_B + i * 2 + 2])[0]
        assert v == esp, 'el puntero fijo %d se ha movido: $%04X' % (i, v)

    # el password, releído desde su $01
    e = rom.find(b'\xff', PW_CMD)
    assert bytes(rom[PW_CMD + 1:e]) == pw, 'el password releído no cuadra'
    assert e == 0x1F89D, 'el terminador no cae en 0x1F89D sino en 0x%05X' % e

    # no queda ni rastro de la cadena mutilada
    assert encode_pw('Jizo') + b'\x01' not in bytes(rom), \
        'sigue habiendo un «Jizo» seguido de comando'

    # zonas intactas
    for a, b, nombre in INTACTAS:
        assert rom[a:b] == original[a:b], 'zona tocada: %s' % nombre

    dif = sum(1 for i in range(len(rom)) if rom[i] != original[i])
    open(salida, 'wb').write(rom)
    d = bytes(rom)
    print('%s' % salida)
    print('  MD5   %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1 %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('  %d bytes cambiados' % dif)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '/tmp/momotaro_fix_pw.pce')
