#!/usr/bin/env python3
"""render_texto.py - dibuja una cadena con la FUENTE REAL de la ROM.

No es una simulación de la maquetación: coge los bitmaps de 8x8 que el
juego tiene en 0x3D660 y los pinta, así se ve exactamente qué glifo sale
por cada byte (incluidos los alias b/c/p y las tildes).

    ROM = 0x3D660 + glifo * 8      8 bytes por glifo, 1 bit por pixel
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from charset_oficial import CHAR_TO_CODE

FUENTE = 0x3D660


def bitmap(rom, code):
    """8 filas de 8 px del glifo.

    El byte >= 0xA0 va DIRECTO. Los de 0x30..0x9F pasan por la tabla
    0x43F9B (indexada desde 0x30). Los de debajo de 0x30 -el espacio 0x20
    y el '!' 0x21- NO estan en esa tabla: indexarlos ahi lee basura (era
    el bug de la primera version, que pintaba katakana por espacios).
    El renderer real los trata aparte; aqui el espacio se deja en blanco."""
    if code == 0x20:
        return [0] * 8
    if 0x30 <= code < 0xA0:
        code = rom[0x43F9B + code - 0x30]
    elif code < 0x30:
        # signos sueltos de la zona baja: su glifo esta en 0xA0 + (code-0x20)
        code = {0x21: 0x9E, 0x24: 0xDB, 0x3F: 0x9D}.get(code, 0x20)
    off = FUENTE + code * 8
    return [rom[off + i] for i in range(8)]


def linea(rom, txt):
    filas = [""] * 8
    for ch in txt:
        c = CHAR_TO_CODE.get(ch)
        if c is None:
            c = CHAR_TO_CODE[' ']
        bm = bitmap(rom, c)
        for i in range(8):
            filas[i] += "".join("#" if bm[i] >> (7 - b) & 1 else "." for b in range(8))
    return filas


def pinta(rom, lineas, ancho=None):
    out = []
    for l in lineas:
        out.extend(linea(rom, l))
        out.append("")
    return out


if __name__ == '__main__':
    rom = open(sys.argv[1], 'rb').read()
    for l in sys.argv[2:]:
        for f in linea(rom, l):
            print(f)
        print()
