#!/usr/bin/env python3
"""build_v389.py - Arregla el submenú corrupto de las raquetas (A-RUN4).

EL BUG
------
Al entrar en el submenú «Comer/Usar/Tirar» de las raquetas de nieve (y de
cualquier objeto a partir del 4º), el recuadro mostraba `a` repetidas, y en
Mesen el menú se colgaba: $3B52 se disparaba hasta $7B en vez de moverse
entre 0 y 8.

LA CAUSA (medida, entrada 247)
------------------------------
Cadena del dibujado:

    $D910  X = $3B51*2 ; puntero de lista = tabla $D948[X]
    $D922  Y = $3B54 + $3B9D,X          <- suma el scroll
    $D92D  LDA ($1A),Y                  -> código del objeto
    $D972  según $3B51, salta por tabla -> $DA00 para el nivel 2
    $DA00  JSR $A9E6 / JSR $A9F2        -> A = lista[$3B56 + $3B9E]
    $DA14  JSR $AEEC                    -> monta $18/$19 con LDY #$0A
    $AF24  X = A*2 ; $18/$19 = tabla $AF4C[X] ; $14/$15 = ($18),Y

La ficha del objeto $09 (raquetas) vive en $B0D6, y su campo $0A apunta a
$B0F0. **El primer word de $B0F0 estaba corrupto:**

    JP  $B0F0:  AC B1   -> $B1AC   tabla de textos («Nadie», «Come»…)
    ES  $B0F0:  00 B1   -> $B100   cae en MEDIO DE CÓDIGO

Con el puntero apuntando a código, el bucle $D68C recorría opcodes como si
fueran caracteres: nunca encontraba el terminador, dibujaba basura e iteraba
82 veces en vez de 14.

**Un solo byte, seguramente pisado al traducir el texto contiguo.**

EL ARREGLO
----------
    0x430F0   $00 -> $AC
"""
import hashlib
import zlib

SRC = 'roms/Momotaro Katsugeki (Español).pce'
JP = 'roms/Momotarou Katsugeki (Japan).pce'
DST = 'roms/momotaro_es_v389.pce'
OFF = 0x430F0

rom = bytearray(open(SRC, 'rb').read())
jp = open(JP, 'rb').read()
orig = bytes(rom)

# el byte está donde creo y vale lo que creo
assert rom[OFF] == 0x00 and rom[OFF + 1] == 0xB1, 'no está el puntero roto'
assert jp[OFF] == 0xAC and jp[OFF + 1] == 0xB1, 'la japonesa no dice $B1AC'

rom[OFF] = 0xAC

# y no se ha movido nada más
distintos = {i for i in range(len(rom)) if rom[i] != orig[i]}
assert distintos == {OFF}, sorted(distintos)[:10]

# el destino tiene que ser la tabla de textos, no código
dest = 0x42000 + (0xB1AC & 0x1FFF)
assert rom[dest:dest + 2] == bytes([0xD4, 0xB1]), 'el destino no es la tabla'

open(DST, 'wb').write(bytes(rom))
print('%s  %d B' % (DST, len(rom)))
print('  0x%05X  $00 -> $AC   (puntero $B100 -> $B1AC)' % OFF)
print('  bytes cambiados: %d' % len(distintos))
print('  MD5   %s' % hashlib.md5(rom).hexdigest())
print('  SHA-1 %s' % hashlib.sha1(rom).hexdigest())
print('  CRC32 %08X' % (zlib.crc32(rom) & 0xFFFFFFFF))
