#!/usr/bin/env python3
"""
mock_abuelo.py - simula BAJAR el bocadillo del abuelo por debajo del HUD.

Toma un volcado de VRAM real, desplaza en el SAT los sprites del bocadillo
(celdas 0x170-0x1AF) y vuelve a pasar el simulador de ranuras del VDC.

  cuerpo del bocadillo : +DY  (baja)
  rabillo (celda 1AF)  :  0   (se queda apuntando al abuelo)
"""
import struct
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from vdc_slots import informe, simular, sat
from render_sprites import dibujar

SATB = 0x7F00


def mover(vram, dy, celdas=range(0x170, 0x1B0), excepto=(0x1AF,)):
    v = bytearray(vram)
    for i in range(64):
        o = (SATB + i * 4) * 2
        y, x, pat, at = struct.unpack('<4H', v[o:o + 8])
        if (y, x, pat, at) == (0, 0, 0, 0) or y > 0x3FF:
            continue
        c = (pat >> 1) & 0x7FF
        if c in celdas and c not in excepto:
            struct.pack_into('<H', v, o, y + dy)
    return bytes(v)


def visible_solo(vram):
    vis, _ = simular(vram)
    return {i for i, s in vis.items() if s}


if __name__ == '__main__':
    src, dy, out = sys.argv[1], int(sys.argv[2]), sys.argv[3]
    v = open(src, 'rb').read()
    p = open(src.replace('_vram', '_pal'), 'rb').read()
    v2 = mover(v, dy)
    li, uso = informe(v2)
    print('desplazamiento %+d px' % dy)
    if li:
        for i, c, y, x, pr in li:
            print('   MUTILADO sprite %2d celda %03X y=%3d x=%3d  %d filas'
                  % (i, c, y, x, len(pr)))
    else:
        print('   ningun sprite mutilado')
    print('   pico de ranuras: %d/16' % max(uso.values()))
    vis, _ = simular(v2)
    dibujar(v2, p, solo={i for i, s in vis.items() if s}).save(out)
    print('   -> %s' % out)
