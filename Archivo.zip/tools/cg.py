"""Codec del CG comprimido del PCE ($861F/$867F).

Formato por celda: 4 grupos (X=4), cada grupo = 4 llamadas a $867F con
Y = 0, 1, $10, $11. Cada llamada:
    1 byte de mascara + literales.
    bit 7..0 (ASL: primero el bit 7).
    bit=1 -> leer literal en A ; bit=0 -> reutilizar A (A=0 en la pos 0)
    posiciones: Y, Y+2, Y+4 ... Y+14  (8 bytes)
Cada grupo llena 32 B del buffer; el grupo n empieza en buffer+n*0x20.
"""

def decode_call(data, i, buf, base, y):
    m = data[i]; i += 1
    a = 0
    for k in range(8):
        bit = (m >> (7 - k)) & 1
        if k == 0:
            if bit:
                a = data[i]; i += 1
            else:
                a = 0
        else:
            if bit:
                a = data[i]; i += 1
        buf[base + y + k * 2] = a
    return i


def decode_cell(data, i):
    buf = bytearray(128)
    for g in range(4):
        for y in (0, 1, 0x10, 0x11):
            i = decode_call(data, i, buf, g * 0x20, y)
    return buf, i


def decode_stream(data, off):
    n = data[off]
    i = off + 1
    cells = []
    for _ in range(n):
        c, i = decode_cell(data, i)
        cells.append(bytes(c))
    return cells, i - off


def encode_call(buf, base, y):
    vals = [buf[base + y + k * 2] for k in range(8)]
    m = 0
    out = bytearray()
    a = 0
    for k, v in enumerate(vals):
        if v == a:
            pass                      # bit 0: reutiliza A
        else:
            m |= 1 << (7 - k)
            out.append(v)
            a = v
    return bytes([m]) + bytes(out)


def encode_cell(buf):
    out = bytearray()
    for g in range(4):
        for y in (0, 1, 0x10, 0x11):
            out += encode_call(buf, g * 0x20, y)
    return bytes(out)


def encode_stream(cells):
    out = bytearray([len(cells)])
    for c in cells:
        out += encode_cell(c)
    return bytes(out)
