#!/usr/bin/env python3
"""
mockup_bocadillo.py - compone el bocadillo del guion con las piezas REALES
del CG volcado del state de aldeano, para dimensionarlo antes de tocar la ROM.

Piezas medidas en docs/aldeano_vram.bin (celdas de 16x16 px del CG de sprites):

    19C  esquina SUP-IZQ (diagonal) + borde sup     dibuja filas  9..15
    19D  borde SUPERIOR recto                       dibuja filas  9..15  REPETIBLE
    1AC  esquina SUP-DER                            dibuja filas  9..15
    19E  esquina INF-IZQ (diagonal) + borde inf     dibuja filas  0.. 6
    19F  borde INFERIOR recto                       dibuja filas  0.. 6  REPETIBLE
    1AE  esquina INF-DER                            dibuja filas  0.. 6
    1A0  lateral IZQUIERDO (3 px de trazo)                              REPETIBLE
    1A1  lateral DERECHO  (trazo a 13 px) + blanco                      REPETIBLE
    1A6  RELLENO blanco                                                 REPETIBLE
    1AD  RABILLO (flip H en el original)

El motor de texto escribe los glifos DENTRO de estas mismas celdas blancas
(1A1/1A3/1A5/1A6/1A7/1A8...), por eso una celda de relleno = 2x2 celdas de
texto de 8x8.
"""
import sys, struct
from PIL import Image

sys.path.insert(0, __file__.rsplit('/', 1)[0])
from render_sprites import tile16, leer_words

ROM = 'roms/test_horizontal_v157.pce'
VRAM = 'docs/aldeano_vram.bin'
PAL = 'docs/aldeano_pal.bin'

# celdas del marco
SUP_IZQ, SUP_MED, SUP_DER = 0x19C, 0x19D, 0x1AC
INF_IZQ, INF_MED, INF_DER = 0x19E, 0x19F, 0x1AE
LAT_IZQ, LAT_DER, RELLENO = 0x1A0, 0x1A1, 0x1A6
RABILLO = 0x1AD

# el lateral derecho lleva el trazo en la columna 12 del tile: +3 px
DESP_LAT_DER = 3


class Marco:
    def __init__(self, rom=ROM, vram=VRAM, pal=PAL):
        self.rom = open(rom, 'rb').read()
        self.w = leer_words(open(vram, 'rb').read())
        c = struct.unpack('<512H', open(pal, 'rb').read()[:1024])
        self.cols = [((x >> 3 & 7) * 36, (x >> 6 & 7) * 36, (x & 7) * 36) for x in c]

    def rgb(self, i, paleta=15):
        return self.cols[(16 + paleta) * 16 + i]

    def pega(self, im, cell, x0, y0, fh=False, blanco_relleno=False):
        px = im.load()
        t = tile16(self.w, cell * 64)
        for y in range(16):
            for x in range(16):
                p = t[15 - y if False else y][15 - x if fh else x]
                if p == 0:
                    if not blanco_relleno:
                        continue
                    continue
                X, Y = x0 + x, y0 + y
                if 0 <= X < im.width and 0 <= Y < im.height:
                    px[X, Y] = self.rgb(p)

    # ---- fuente de dialogo -------------------------------------------
    def glifo(self, code):
        if code >= 0xA0:
            return self.rom[0x41CF3 + (code - 0xA0)]
        return self.rom[0x43F9B + (code - 0x30)]

    def bitmap(self, g):
        d = self.rom[0x3D660 + g * 8: 0x3D660 + g * 8 + 8]
        return [[(b >> (7 - x)) & 1 for x in range(8)] for b in d]

    def texto(self, im, s, x0, y0):
        from charset_oficial import CHAR_TO_CODE
        px = im.load()
        for i, ch in enumerate(s):
            if ch == ' ':
                continue
            bmp = self.bitmap(self.glifo(CHAR_TO_CODE[ch]))
            for y in range(8):
                for x in range(8):
                    if bmp[y][x]:
                        X, Y = x0 + i * 8 + x, y0 + y
                        if 0 <= X < im.width and 0 <= Y < im.height:
                            px[X, Y] = (0, 0, 0)

    def componer(self, ncel_x, nfil_relleno, lineas, rabillo_x=None,
                 fondo=(70, 110, 170), interlinea=12, margen=8,
                 rabillo_sim=False):
        """ncel_x = celdas de 16 px de relleno horizontal.
           nfil_relleno = celdas de 16 px de relleno vertical.
        No pega las celdas de RELLENO (arrastran texto del state): el
        interior se pinta por INUNDACION desde el centro, que es lo que
        hace el propio marco en pantalla."""
        W = (ncel_x + 2) * 16
        H = (nfil_relleno + 2) * 16 + 8
        im = Image.new('RGB', (W, H), fondo)
        yb = 0
        yi = 16 + nfil_relleno * 16
        self.pega(im, SUP_IZQ, 0, yb)
        self.pega(im, INF_IZQ, 0, yi)
        for i in range(ncel_x):
            self.pega(im, SUP_MED, 16 + i * 16, yb)
            self.pega(im, INF_MED, 16 + i * 16, yi)
        self.pega(im, SUP_DER, 16 + ncel_x * 16, yb)
        self.pega(im, INF_DER, 16 + ncel_x * 16, yi)
        # OJO: el trazo del lateral derecho vive en la columna 12 del tile,
        # no en la 15. En el original el sprite va +3 px a la derecha para
        # que el trazo case con las esquinas (medido: LAT-DER x=156 frente a
        # SUP-DER x=153). Sin ese desplazamiento el borde derecho queda 3 px
        # metido hacia dentro. Lo detecto David mirando la captura.
        for f in range(nfil_relleno):
            y = 16 + f * 16
            self.pega(im, LAT_IZQ, 0, y)
            self.pega(im, LAT_DER, 16 + ncel_x * 16 + DESP_LAT_DER, y)
        # rabillo. El original es una CUNA ASIMETRICA (ancha arriba, punta a
        # un lado). En el bocadillo vertical quedaba bien porque el bocadillo
        # estaba descentrado respecto al aldeano; en el apaisado y centrado
        # canta. rabillo_sim=True pega la cuna y su espejo -> punta central.
        if rabillo_x is None:
            rabillo_x = W // 2 - 8
        if rabillo_sim:
            # la punta de la cuna esta en la columna 12 del tile, no en la 15.
            # Para que las dos mitades se toquen en la punta hay que separar
            # los sprites 2*(15-12)+1 = 7 px respecto al centro, no 8.
            # NOTA: pegar la cuna y su espejo NO da una punta limpia; el
            # sprite original no esta disenado para eso (se estrecha pero no
            # cierra). Un rabillo simetrico de verdad hay que DIBUJARLO.
            # De momento se centra la cuna original, que es lo mas parecido.
            self.pega(im, RABILLO, rabillo_x - 4, yi + 6, fh=False)
            self.pega(im, RABILLO, rabillo_x - 2, yi + 6, fh=True)
        else:
            self.pega(im, RABILLO, rabillo_x, yi + 6, fh=True)
        self.inundar(im, (W // 2, yi - 8), fondo, (252, 252, 252))
        self.limpiar_relleno(im)
        # margen=8: el interior blanco va de x=1 a x=174 (174 px) y el texto
        # de 20 celdas ocupa 160, asi que sobran 14 px. Con el margen a 4 el
        # reparto era 4 izq / 14 der y David lo vio descentrado (los glifos
        # ademas traen su propio aire a la derecha). Con 8 queda 8/10, que a
        # ojo es simetrico. NO se puede subir mas sin comerse el borde.
        for n, ln in enumerate(lineas):
            self.texto(im, ln, margen, 16 + 1 + n * interlinea)
        return im

    @staticmethod
    def capacidad(ncel_x, nfil_relleno, interlinea=12):
        """Devuelve (caracteres por linea, lineas) de un bocadillo dado.
        Interior blanco medido: x 1..W-5 ; el texto respeta 3 px de aire."""
        W = (ncel_x + 2) * 16
        chars = (W - 10) // 8
        alto = nfil_relleno * 16 + 10
        lineas = alto // interlinea
        return chars, lineas

    @staticmethod
    def inundar(im, semilla, viejo, nuevo):
        px = im.load()
        if px[semilla] != viejo:
            return
        pila = [semilla]
        W, H = im.size
        while pila:
            x, y = pila.pop()
            if not (0 <= x < W and 0 <= y < H) or px[x, y] != viejo:
                continue
            px[x, y] = nuevo
            pila += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]

    def limpiar_relleno(self, im):
        """Borra los glifos que las piezas del state traian dentro."""
        px = im.load()
        W, H = im.size
        for y in range(9, H):
            fila = [x for x in range(W) if px[x, y] == (252, 252, 252)]
            if not fila:
                continue
            a, b = min(fila), max(fila)
            for x in range(a, b + 1):
                if px[x, y] == (0, 0, 0):
                    px[x, y] = (252, 252, 252)


if __name__ == '__main__':
    m = Marco()
    # bocadillo ORIGINAL reconstruido: 2 celdas de relleno x 3 filas
    m.componer(2, 3, ['ブキヤ'.ljust(0)][:0] or []).save('capturas/mk_original.png')
    print('ok')
