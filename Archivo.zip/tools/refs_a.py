#!/usr/bin/env python3
"""
refs_a.py - busca saltos a un rango, RESPETANDO los limites de instruccion.

Buscar los bytes 20/4C + operando a pelo da falsos positivos: en ROM 0x0DBE
"LDA $20A7 / CMP #$FF" se lee como "JSR $FFC9" si empiezas a leer en medio.
Aqui se desensambla linealmente el banco y solo se acepta el salto si cae
en un limite de instruccion real.

Como la sincronia depende de donde empieces, se prueban VARIOS puntos de
arranque y solo se da por bueno el salto si aparece en TODOS (una zona de
codigo real se resincroniza sola en pocos bytes).
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dis6280 import longitud as LONG


def limites(datos, ini, fin):
    """Conjunto de offsets que son comienzo de instruccion."""
    out = set()
    p = ini
    while p < fin:
        out.add(p)
        p += LONG(datos[p])
    return out


def buscar(rom, lo, hi, arranques=8):
    """Devuelve los ROM offsets con un JSR/JMP a [lo,hi) bien alineado."""
    hits = []
    for banco in range(len(rom) // 0x2000):
        a = banco * 0x2000
        b = a + 0x2000
        # varios arranques -> interseccion de limites
        conj = None
        for k in range(arranques):
            s = limites(rom, a + k, b - 8)
            conj = s if conj is None else (conj & s)
        for i in sorted(conj):
            if i + 2 >= b:
                continue
            if rom[i] in (0x20, 0x4C):
                v = rom[i + 1] | (rom[i + 2] << 8)
                if lo <= v < hi:
                    hits.append((i, banco, rom[i], v))
    return hits


if __name__ == '__main__':
    rom = open(sys.argv[1], 'rb').read()
    lo = int(sys.argv[2], 16)
    hi = int(sys.argv[3], 16)
    h = buscar(rom, lo, hi)
    print('saltos ALINEADOS a $%04X..$%04X: %d' % (lo, hi - 1, len(h)))
    for i, bk, op, v in h:
        print('   ROM %05X banco %02X  %s $%04X'
              % (i, bk, 'JSR' if op == 0x20 else 'JMP', v))
