# Cómo retomar — estado a la v338

**ROM buena: `Momotaro/roms/momotaro_es_v338.pce`**
MD5 `dd7cf0125e17ee27617c9c98b610e9de`
CRC32 `FD835B3E`
Parche: `Momotaro/parches/momotaro_v338.ips`

> **v335, v336 y v337 están DESCARTADAS** (en `roms/descartadas/`). Los
> finales quedaron ilegibles y David ordenó volver a la v334 limpia, sin
> revertir paso a paso. La línea válida es **v334 → v338**.
>
> La v338 sólo hace una cosa: devolver el «!» de «¡Introduce el canto de
> Jizo!», que se perdió en la **v320**. 98 bytes, 2 tramos, y 400 puntos de
> comparación en el emulador confirman que **no cambia nada más**.

## ORDEN VIGENTE DE DAVID

**No se genera ninguna ROM hasta haber visto capturas de cómo quedan los
cambios.**

## SE PUEDE EMULAR (desde la v335)

```
tools/bin/mednafen_pce_libretro.so   Beetle PCE compilado aquí
tools/pce.py                         frames, botones, peek/poke, VRAM, PNG
```

```python
from pce import PCE
p = PCE('roms/momotaro_es_v338.pce')
p.run(300); p.press('A'); p.png('/tmp/x.png')
p.poke(0x3B00, 6)            # forzar mundo
```

Trampas: hace falta `retro_set_controller_port_device` (ya está en pce.py) o
**ningún botón llega**; el botón de diálogo es **A**; y los savestates de
David son de RetroArch — hay que empezar en el offset del `MDFNSVST`.

Los seis savestates (4 finales + sound/graphics test) están en
`descargas/finales/`.

### Teclear passwords sin savestate: `tools/password.py`

```python
from password import boot, escribe
p = boot('roms/momotaro_es_v338.pce')
escribe(p, 'rGAPad')                     # final Fácil
p.press('START', frames=4); p.run(300)   # se acepta con START
```

Rejilla medida celda a celda. **Tres trampas**: tiene 14 columnas y no 16;
la fila 2 empieza por **Ñ** y no por O (si no, sale «rGAO» en vez de
«rGAP»); y se acepta con START, no con el menú lateral.

    Muy difícil  wCpeIfP     Difícil  GoFIBM
    Normal       cJQIep      Fácil    rGAPad

### Prueba de no-regresión

Antes de dar por buena una ROM, comparar el hash del framebuffer contra la
versión anterior en varios escenarios (partida nueva con entradas
aleatorias + los 4 passwords). Si sólo cambian las pantallas que se querían
tocar, el parche está limpio. Es lo que validó la v338.

## Leer primero, en este orden

1. `Momotaro/docs/PENDIENTES.md` — registro único de lo que falta
2. `Momotaro/docs/INFORME_v306_a_v338.md` — la tanda entera, con los errores
3. `Momotaro/LEEME.md` — normas 12-320
4. `Momotaro/docs/PROMPT_METODO.md` — el método obligatorio

## Lo que se cerró en esta tanda (v324-v332)

- **El QUIZ completo**: 40 preguntas y 120 opciones. Tabla en `0x11818`.
- Los 7 nombres del ermitaño (**Hien**, Janpu, Korokoro…) y su frase.
- 12 de 14 técnicas que estaban rotas desde la v317.
- «Aldea Bambú» en los tres charsets.
- «Faltan momos» → «0 momos» (`0x19BFA`).
- El bug del `©` y el de la `p` (`KaÇÇa`).

## Trampas de esta zona, para no repetirlas

```
0x4AD56..0x4AD76   32 bytes de $20 = BLOQUE LIMPIADOR. NO es relleno.
0x4AD9A            corte de PÁGINA por código ($CFE7), no por terminador.
tabla 0x11818      96 entradas: 0-1 mensajes, 2-41 preguntas,
                   42-81 respuestas, 82-95 TÉCNICAS. No mezclar familias.
$D8BC[0..6]        NOMBRE del ermitaño.  $D8CA[7..13] ARTES del premio.
preguntas          bytes DIRECTOS ($B0 = p).  Alias $5B/$5D/$5E dan ©.
opciones           alias $5E = p.  El $B0 directo da Ç.
límite de línea    15 columnas visibles en preguntas, 7 en opciones.
```

## Siguiente paso sugerido

Testeo del quiz en pantalla y, si sale limpio, **créditos y final**
(`0x4A480`, 896 B). La casa mutilada de Kachiyama sigue bloqueada por la SAT.

## Aviso para el testeo

En la v333 aparecieron **8 bytes de japonés sin traducir** al final de la
ranura `$4834` de las posadas: llevaban ahí desde la v307 y no se veían
porque el motor corta antes. Puede haber más casos iguales — una ranura llega
hasta el siguiente puntero USADO de su tabla, no hasta donde acaba nuestro
texto (norma 321).
