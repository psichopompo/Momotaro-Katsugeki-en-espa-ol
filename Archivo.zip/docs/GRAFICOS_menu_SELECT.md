# Menú SELECT — instrucciones para editar los rótulos

Para David. Los rótulos de sección (体力, 技, 金, ぶき, ぼうぐ, どうぐ, じゅつ)
**son dibujo**, no texto, así que hay que pintarlos.

El resto (los nombres de armas, objetos y artes) **sí es texto** y lo
escribo yo por código: ahí no tienes que hacer nada.

## Archivos

| archivo | para qué |
|---|---|
| `capturas/EDITAR_menu_select_limpio_1x.png` | **el que hay que editar**, 256×176, rótulos ya borrados |
| `capturas/EDITAR_menu_select_limpio_4x.png` | el mismo, ×4, para verlo cómodo |
| `capturas/EDITAR_menu_select_zonas.png` | el original con las zonas marcadas en magenta |
| `capturas/EDITAR_menu_select_1x.png` | el original intacto, por si hace falta comparar |

**Edita el `_1x`** (o el 4x y lo reduzco yo, como prefieras).

## Reglas de color — IMPORTANTE

Usa **solo estos dos colores** dentro de los recuadros:

```
fondo del panel   gris   RGB (216, 216, 216)
tinta             negro  RGB (0, 0, 0)
```

Nada de antialias, ni grises intermedios, ni transparencias. La consola no
puede representarlos aquí y el conversor los rechazará.

No toques el marco de madera ni los bordes de los recuadros: si cambian,
tengo que recolocar celdas y se complica.

## Espacio disponible

Coordenadas en píxeles de `EDITAR_menu_select_limpio_1x.png` (origen 0,0
arriba a la izquierda). **Medidas verificadas contra los paneles reales.**

| rótulo | significado | posición | zona |
|---|---|---|---|
| 体力 | **VIDA** | x=16, y=20 | 56 × 14 |
| 技 | **TÉCNICA** | x=16, y=36 | 56 × 14 |
| 金 | **ORO** | x=16, y=52 | 28 × 14 |
| ぶき | **ARMA** | x=16, y=78 | 80 × 14 |
| ぼうぐ | **ARMADURA** | x=16, y=118 | 80 × 14 |
| どうぐ | **OBJETOS** | x=112, y=22 | 64 × 14 |
| じゅつ | **ARTES** | x=192, y=22 | 48 × 14 |

Las zonas están dibujadas en magenta en
`capturas/EDITAR_menu_select_GUIA_4x.png` (a escala ×4: divide entre 4 para
pasar a píxeles reales).

Notas:

- **ORO** solo tiene 28 px porque el importe empieza en x=48. Para poner
  `RYOS` habría que mover el importe una columna: un byte en `$D5D1`
  (`LDX #$06` → `LDX #$07`). Dímelo si lo quieres.
- **VIDA** y **TÉCNICA** tienen 56 px: la cifra se imprime en x=80.
- Altura **14 px**: la última fila del recuadro es el borde.
- Los paneles interiores completos son: izquierdo x=12..100, centro
  x=107..180, derecho x=187..243.

## Dos avisos técnicos

1. **La rejilla es de 8×8.** Puedes dibujar donde quieras dentro de la zona,
   pero cuantas menos celdas de 8×8 toques, mejor comprime. No es una
   restricción dura: hay sitio de sobra (ver abajo).

2. **Los rótulos japoneses actuales miden 12 px y no están alineados** a la
   rejilla, así que invadían la fila de arriba. Ya lo he corregido en la
   imagen limpia. Si dibujas dentro de la zona indicada, no vuelve a pasar.

## ¿Cabe?

Sí, con margen. Medido sobre el bloque comprimido real:

```
bloque actual                    1427 B
si los rótulos fueran letras     1376 B  (51 B MENOS)
espacio libre hasta el final     379 B
```

Las letras latinas comprimen mejor que los kanji, así que el bloque encoge.

## Sugerencia de estilo

Los rótulos son **encabezados de sección**, y el contenido irá en fuente
fina y minúsculas. Para que la jerarquía se lea, conviene que los rótulos
sean **gruesos** — al estilo de las cifras «2390両» que ya ves en pantalla,
que son de la fuente gruesa del juego.

Si prefieres no dibujar a mano, dímelo y monto los rótulos con la fuente
gruesa del propio juego: quedaría coherente y es cuestión de un rato. La
ventaja de dibujarlos tú es que puedes ajustar el espaciado a ojo.

## Cuando termines

Pásame el PNG editado y yo:

1. lo troceo en tiles de 8×8,
2. compruebo que solo usa los dos colores,
3. lo recomprimo con el compresor validado (round-trip exacto),
4. lo escribo en `0x7F8F2` y verifico que el bloque cabe,
5. escribo el texto de armas, objetos y artes por código,
6. te paso la v146 con MD5.
