# Maquetación de los VÍTORES (pancarta de fin de fase)

Rejilla: **2 líneas × 18 caracteres**. El motor cuenta 18 caracteres
*visibles* por línea y para ahí: sobran o faltan letras, no hay
terminador. Los espacios de relleno son `$A0`.

Cada bloque ocupará **36 B exactos** (18+18) y todos los huecos actuales
son de 37 B o más, así que **no hay que repuntar la tabla `$C433`**.

**Las traducciones de abajo son una PRIMERA PROPUESTA, no están cerradas.**
La maquetación la decides tú: cámbialas a tu gusto respetando el límite de
18 caracteres por línea. El constructor leerá este documento, no llevará
las frases dentro.

Criterios aplicados: mayúscula inicial, punto final salvo exclamaciones,
«Momotaro» sin la `u`, texto alineado a la izquierda, sin abreviaturas.

---

## Los 19 bloques de la tabla

### Bloque 0 — `$418A` (ROM `04818A`) — hueco 42 B — fases 1-1, 1-4

```
         123456789012345678
JP  L1  | \フレーフレー! \モモタロウサン! |
JP  L2  | ガンバレガンバレ モモタロウサン!|
ES  L1  |¡Ánimo! ¡Momotaro!|  18
ES  L2  |¡Vamos, Momotaro! |  17
```

### Bloque 1 — `$41B4` (ROM `0481B4`) — hueco 45 B — fases 1-2

```
         123456789012345678
JP  L1  | \サンキュー ミスター\モモタロウ  |
JP  L2  |  \ベリーベリー グッド\デスヨ!  |
ES  L1  |Thanks, míster.   |  15
ES  L2  |¡Very good, Momo! |  17
```

> **Cerrado: inglés correcto** (decisión de David — la transcripción
> fonética sonaría marciana). Aplica a los bloques 1 y 2, que son los dos
> que llevan inglés en katakana.
> `Momotaro` entero no cabe en L2 (`¡Very good, Momotaro!` son 21), así que
> va abreviado a `Momo`, que el juego ya usa en otros vítores.

### Bloque 2 — `$41E1` (ROM `0481E1`) — hueco 39 B — fases 1-3

```
         123456789012345678
JP  L1  | モエル トウコン! モモタロウ! |
JP  L2  |  \ネクストステージ レッツゴー! |
ES  L1  |¡Qué coraje, Momo!|  18
ES  L2  |¡Next stage, go!  |  16
```

> Inglés correcto, en coherencia con el bloque 1.

### Bloque 3 — `$4208` (ROM `048208`) — hueco 38 B — fases 2-1

```
         123456789012345678
JP  L1  |  カットバセー モモチャン!   |
JP  L2  |  エンマヲ タオセー!\オー!   |
ES  L1  |¡Dale duro, Momo! |  17
ES  L2  |¡A por Enma! ¡Oh! |  17
```

### Bloque 4 — `$422E` (ROM `04822E`) — hueco 37 B — fases 2-2, 2-4

```
         123456789012345678
JP  L1  |  オトコイッピキ モモタロウ!  |
JP  L2  |  ニクイネ! コノイロオトコ!  |
ES  L1  |¡Todo un hombre!  |  16
ES  L2  |¡Menudo galán!    |  14
```

### Bloque 5 — `$4253` (ROM `048253`) — hueco 37 B — fases 2-3

```
         123456789012345678
JP  L1  |   イケイケ モモチャン!    |
JP  L2  | オセオセ モモチャン! \ワーイ! |
ES  L1  |¡Vamos allá, Momo!|  18
ES  L2  |¡Empuja, Momo!    |  14
```

### Bloque 6 — `$4278` (ROM `048278`) — hueco 38 B — fases 3-1, 3-4

```
         123456789012345678
JP  L1  |  ニッポンイチノ モモタロウ!  |
JP  L2  |   ヨッ! ダイトウリョウ!   |
ES  L1  |Momo, el mejor.   |  15
ES  L2  |¡Eh, presidente!  |  16
```

### Bloque 7 — `$429E` (ROM `04829E`) — hueco 38 B — fases 3-2

```
         123456789012345678
JP  L1  | カンシャカンゲキ アメアラレ!  |
JP  L2  | カツトオモウナ オモエバマケヨ! |
ES  L1  |¡Gracias mil!     |  13
ES  L2  |Confiarse, perder.|  18
```

### Bloque 8 — `$42C4` (ROM `0482C4`) — hueco 40 B — fases 3-3

```
         123456789012345678
JP  L1  |  \ファイトー! \イッパーツ!   |
JP  L2  |  モモタロウハ フメツデス!   |
ES  L1  |¡Fight! ¡Clavado! |  17
ES  L2  |¡Momotaro no cae! |  17
```

> **`ファイトー` se queda, `イッパーツ` se traduce.** El primero es inglés
> en katakana (*fight*); el segundo es japonés (一発, «de un solo golpe»).
>
> Sobre el guiño: **Lipovitan D** es una bebida energética japonesa, el
> equivalente a nuestro Red Bull pero de los años 60, que se vende en
> farmacias. Su eslogan televisivo desde 1977 es literalmente
> `ファイト! 一発!` gritado por un tipo haciendo algo heroico. Es una
> muletilla que en Japón entiende todo el mundo, como aquí «¿te gusta
> conducir?». No tiene equivalente español: cualquier traducción pierde el
> guiño, así que lo que toca es conservar el **sentido** («ánimo, y a la
> primera»), que es lo que hace `¡Clavado!`.
>
> `¡A la primera!` no cabe (`¡Fight! ¡A la primera!` = 22).
> Alternativas medidas: `¡Fight! ¡De una!` (16) · `¡Fight! ¡Clavado!` (17).

### Bloque 9 — `$42EC` (ROM `0482EC`) — hueco 44 B — fases 4-1

```
         123456789012345678
JP  L1  |     \パンパカパーン!     |
JP  L2  |   \メン\クリア \オメデトウ!   |
ES  L1  |¡Tachán!          |  8
ES  L2  |¡Fase superada!   |  15
```

### Bloque 10 — `$4318` (ROM `048318`) — hueco 38 B — fases 4-2

```
         123456789012345678
JP  L1  |  サッスガ モモタロウサン!   |
JP  L2  | エンマダイオウモ ヤッツケテネ! |
ES  L1  |¡Así se hace!     |  13
ES  L2  |¡Y ahora, Enma!   |  15
```

### Bloque 11 — `$433E` (ROM `04833E`) — hueco 43 B — fases 4-3, 4-4

```
         123456789012345678
JP  L1  |  バンザイグンダン サンジョウ! |
JP  L2  | マタ ツギノメンデ アイマショウ!|
ES  L1  |¡Pelotón banzai!  |  16
ES  L2  |¡Hasta otra fase! |  17
```

### Bloque 12 — `$4369` (ROM `048369`) — hueco 39 B — fases 5-1

```
         123456789012345678
JP  L1  |   ニッポン \チャチャチャ!   |
JP  L2  |  \モモチャン チャチャチャ!   |
ES  L1  |Japón, cha-chá.   |  15
ES  L2  |Momo, cha-cha-chá.|  18
```

### Bloque 13 — `$4390` (ROM `048390`) — hueco 38 B — fases 5-2, 5-4

```
         123456789012345678
JP  L1  |   ヤッタネ モモタロウサン!  |
JP  L2  |   ショウリハ モウスグデス!  |
ES  L1  |¡Bien hecho, Momo!|  18
ES  L2  |¡Casi has ganado! |  17
```

### Bloque 14 — `$43B6` (ROM `0483B6`) — hueco 39 B — fases 5-3

```
         123456789012345678
JP  L1  |   アンタガ タイショウ!    |
JP  L2  | イツモ アナタノオソバニイル\ワ! |
ES  L1  |¡Tú eres el jefe! |  17
ES  L2  |¡Siempre contigo! |  17
```

### Bloque 15 — `$43DD` (ROM `0483DD`) — hueco 40 B — fases 6-1

```
         123456789012345678
JP  L1  |   \ナイス\ダゼ モモチャン!   |
JP  L2  | セカイノ ヘイワヲ マモッテネ! |
ES  L1  |¡Muy bien, Momo!  |  16
ES  L2  |¡Protege la paz!  |  16
```

### Bloque 16 — `$4405` (ROM `048405`) — hueco 43 B — fases 6-2, 6-4

```
         123456789012345678
JP  L1  | テンガヨブ チガヨブ ヒトガヨブ |
JP  L2  | エンマヲ タオセト オレヲヨブ  |
ES  L1  |Todos te llaman:  |  16
ES  L2  |¡derrota a Enma!  |  16
```

### Bloque 17 — `$4430` (ROM `048430`) — hueco 38 B — fases 6-3

```
         123456789012345678
JP  L1  |    メデタシ メデタシ!    |
JP  L2  |  モモタロウハ キョウモイク!  |
ES  L1  |¡Colorín colorado!|  18
ES  L2  |¡Momotaro no para!|  18
```

### Bloque 18 — `$4456` (ROM `048456`) — hueco 39 B — fases 7-1, 7-2, 7-3, 7-4

```
         123456789012345678
JP  L1  |    タスケテ モモチャン!   |
JP  L2  |   アナタダケガ タヨリデス!  |
ES  L1  |¡Ayúdanos, Momo!  |  16
ES  L2  |¡Confiamos en ti! |  17
```

---

## Los 4 bloques huérfanos

Encajan en la misma rejilla y están justo antes de `$418A`, pero la tabla
`$C433` **no apunta a ellos**. [HIPÓTESIS] los alcanza otra rutina.
Se traducen igual: cuesta poco y evita dejar japonés suelto.

### Huérfano 0 — `$40E8` (ROM `0480E8`) — hueco 42 B

```
         123456789012345678
JP  L1  |  バンザイグンダン サンジョウ! |
JP  L2  | タレマク ツクルノモ タイヘンダ!|
ES  L1  |¡Pelotón banzai!  |  16
ES  L2  |La pancarta cansa.|  18
```

### Huérfano 1 — `$4112` (ROM `048112`) — hueco 39 B

```
         123456789012345678
JP  L1  |  モモタロウカツゲキ ドウヨウ  |
JP  L2  | モモタロウデンセツモ ヨロシク! |
ES  L1  |Momotaro en acción|  18
ES  L2  |¡Y Densetsu, eh!  |  16
```

> **Katsugeki traducido, Densetsu no** (decisión de David): este juego lo
> llamamos *Momotaro en acción*, pero `Momotaro Densetsu` es otro juego de
> la saga y se deja con su nombre.
> ⚠ **L1 se queda sin punto final** y hay que decidirlo: son 18 clavados,
> no cabe el punto. Alternativas medidas:
> `Momotaro en acción.` (19, no cabe) · `Momotaro en acción` (18, sin punto)
> · `Momotaro en Acción` (18) · `Juega a Momotaro.` (17, con punto pero
> pierde el título exacto) · `Momotaro en acción,` (19, no cabe).
> Si el criterio del punto final es innegociable, la salida es acortar:
> `Momo en acción.` (15) o `Momotaro en acción` partido de otro modo.

### Huérfano 2 — `$4139` (ROM `048139`) — hueco 42 B

```
         123456789012345678
JP  L1  |   ナーホーザ \ワールド!    |
JP  L2  | \ミンナノ \ヒーロー \モモタロウ! |
ES  L1  |¡Naaa, hooo, zaaa!|  18
ES  L2  |¡Héroe de todos!  |  16
```

### Huérfano 3 — `$4163` (ROM `048163`) — hueco 39 B

```
         123456789012345678
JP  L1  |   モモモモモモモモタロウ!   |
JP  L2  | スモモモモモモモヘンゲ! \ピーチ!|
ES  L1  |¡Momomomomomotaro!|  18
ES  L2  |¡Momo, momo, momo!|  18
```
