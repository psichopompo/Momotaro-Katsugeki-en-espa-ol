# Los 23 textos del abuelo — para tu repaso

Tabla `$C969` → ROM `0x16969`. Son los mensajes de obtención de ítem y las
cantidades de dinero de los minijuegos. Terminador `$A0`.

Maquetados a **14 columnas × 2 líneas**, que es la geometría nueva.

| # | Japonés | Castellano | Cómo queda |
|---|---|---|---|
| 0 | Karada no onigiri wo te ni ireta | Coges la bola de la salud | `Coges la bola` / `de la salud` |
| 1 | Waza no onigiri wo te ni ireta | Coges la bola de la técnica | `Coges la bola` / `de la técnica` |
| 2 | Yuki no onigiri wo te ni ireta | Coges la bola de la nieve | `Coges la bola` / `de la nieve` |
| 3 | Kibidango wo te ni ireta | Coges un kibidango | `Coges un` / `kibidango` |
| 4 | Onara no moto wo te ni ireta | Coges el pedo mágico | `Coges el pedo` / `mágico` |
| 5 | Nichirin no tsubute wo te ni ireta | Coges la piedra solar | `Coges la` / `piedra solar` |
| 6 | Hyōga no tsubute wo te ni ireta | Coges la piedra glacial | `Coges la piedra` / `glacial` |
| 7 | Kakuremino wo te ni ireta | Coges la capa mágica | `Coges la capa` / `mágica` |
| 8 | Momotarō wa 100 mon wo te ni ireta | Ganas 100 mon | `Ganas 100 mon` |
| 9 | Momotarō wa 50 mon wo te ni ireta | Ganas 50 mon | `Ganas 50 mon` |
| 10 | Momotarō wa 30 mon wo te ni ireta | Ganas 30 mon | `Ganas 30 mon` |
| 11 | Momotarō wa 10 mon wo te ni ireta | Ganas 10 mon | `Ganas 10 mon` |
| 12 | Momotarō wa kore ijō motenai! | No puedes llevar más | `No puedes` / `llevar más` |
| 13 | Momotarō wa inu wo otomo ni shita | El perro te acompaña | `El perro te` / `acompaña` |
| 14 | Momotarō wa kiji wo otomo ni shita | El faisán te acompaña | `El faisán te` / `acompaña` |
| 15 | Momotarō wa saru wo otomo ni shita | El mono te acompaña | `El mono te` / `acompaña` |
| 16 | Momotarō wa kōra wo te ni ireta | Coges el caparazón | `Coges el` / `caparazón` |
| 17 | Momofure bōzu wo te ni ireta | Coges al bonzo Momofure | `Coges al bonzo` / `Momofure` |
| 18 | Momotarō wa 80 mon wo te ni ireta | Ganas 80 mon | `Ganas 80 mon` |
| 19 | Momotarō wa 20 mon wo te ni ireta | Ganas 20 mon | `Ganas 20 mon` |
| 20 | Bakamon! 2 do to kuru na! | ¡Bakamon! ¡No vuelvas! | `¡Bakamon! ¡No` / `vuelvas!` |
| 21 | Ue wo mezashite susumu no ja | Sigue hacia arriba | `Sigue hacia` / `arriba` |
| 22 | Migi wo mezashite susumu no ja | Sigue a la derecha | `Sigue a la` / `derecha` |

## Dudas para ti

1. **`mon`** — lo he dejado como en el original (la moneda japonesa). Si
   prefieres «monedas» habría que acortar: `Ganas 100` / `monedas`.
2. **`kibidango`** — sin traducir, como nombre propio del dulce. Alternativa:
   «bola de mijo».
3. **`bonzo Momofure`** — es el `モモフレ坊主`. ¿Lo dejamos así?
4. **`¡Bakamon!`** — literalmente «¡idiota!». ¿Lo dejo en japonés o pongo
   «¡Menudo idiota!»? El original tiene gracia por lo brusco.
5. Los tres primeros son las «bolas de arroz» (`onigiri`) de salud, técnica
   y nieve. He puesto solo «bola» para que quepa; si prefieres «onigiri»,
   cabe igual: `Coges el onigiri` / `de la salud`.
