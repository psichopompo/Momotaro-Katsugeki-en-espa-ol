# Respuesta al otro chat — el final Difícil

Método: **trazador compilado dentro del emulador**. Recompilé Beetle PCE
con dos hooks (watchpoint de ejecución que vuelca los 8 registros MPR, y
watchpoint de escritura que registra *quién* escribe). Eso da el offset
físico de ROM de cualquier dirección CPU sin necesidad de Mesen ni de poner
breakpoints a mano.

Todo lo que sigue está **medido ejecutando**, con los savestates de David y
la ROM japonesa virgen.

---

## Resumen: la premisa del prompt es falsa

**`$AA38` no se ejecuta nunca en el final Difícil. El motor `$DBA2` /
`$DBBD` / `$DBDD` tampoco.** Difícil y Muy difícil los pinta **otro motor,
en otro banco, y no lee el stream en secuencia sino por una tabla de
punteros**.

El desensamblado de `$DBDD` que os pasó Claude es **correcto byte a byte**
(lo he verificado). El problema es que esa rutina pertenece al motor de
**Fácil**, y no interviene en Difícil.

| Lo que decía el prompt | Lo medido |
|---|---|
| `$5C` se trata dentro de `$AA38` | `$AA38` **0 hits en 600 frames** |
| `$3CE4` es el FSM del ticker | Vale **`$00`** todo el rato en Difícil |
| Un solo stream alimenta Fácil y Difícil | Difícil usa **tabla de punteros** por ficha |
| `$00` cierra la fila | `$00` cierra **el bloque entero** |
| `$FF` acaba el rollo | En Difícil el fin es un **puntero `$0000`** |
| Hace falta el stash `$3D33` | **No hace falta: existe `$37F8`** |

---

## 1. El motor real: `$D277`, banco `$01` = ROM `0x03277`

Watchpoint de **escritura** sobre `$20BF` (el puntero de texto) con el
Difícil ya rodando: un solo escritor, `PC $D287`, banco `$01`.

```
ROM 03277  D277  a91d       LDA #$1D
ROM 03279  D279  18         CLC
ROM 0327A  D27A  6520       ADC $20
ROM 0327C  D27C  5304       TAM #$04      ; banco $1D en $4000-$5FFF
ROM 0327E  D27E  ad6a3d     LDA $3D6A     ; <- indice de FICHA
ROM 03281  D281  0a         ASL A
ROM 03282  D282  a8         TAY
ROM 03283  D283  b1ce       LDA ($CE),Y   ; <- TABLA DE PUNTEROS
ROM 03285  D285  85bf       STA $BF
ROM 03287  D287  c8         INY
ROM 03288  D288  b1ce       LDA ($CE),Y
ROM 0328A  D28A  85c0       STA $C0
ROM 0328C  D28C  05bf       ORA $BF
ROM 0328E  D28E  f017       BEQ $D2A7     ; puntero $0000 = FIN de creditos
ROM 03290  D290  ad6a3d     LDA $3D6A
ROM 03293  D293  2907       AND #$07
ROM 03295  D295  0a         ASL A
ROM 03296  D296  aa         TAX
ROM 03297  D297  bddcd2     LDA $D2DC,X   ; destino VRAM
ROM 0329A  D29A  8516       STA $16
ROM 0329C  D29C  bdddd2     LDA $D2DD,X
ROM 0329F  D29F  8517       STA $17
ROM 032A1  D2A1  20aed2     JSR $D2AE     ; prepara el DMA a VRAM
ROM 032A4  D2A4  4c27aa     JMP $AA27     ; rasterizador (banco de MPR5)
```

**Consecuencia práctica:** cada ficha se localiza por su puntero. No hay
que respetar ningún orden físico ni longitud original: **se puede repuntar
cada bloque por separado**. Eso quita de golpe el problema de «no cabe».

`$D2DC` (ROM `0x032DC`), 8 destinos de VRAM rotando con `$3D6A AND 7`:

```
$5008  $5308  $5608  $5908  $5C08  $5F08  $6208  $6508
```

---

## 2. ⭐ `$37F8` es el discriminador de dificultad

Esto es lo que lleváis buscando desde la v363.

```
ROM 0321C  D21C  adf837     LDA $37F8
ROM 0321F  D21F  0a         ASL A
ROM 03220  D220  aa         TAX
ROM 03221  D221  bd07dd     LDA $DD07,X   ; tabla de LISTAS de bloques
ROM 03224  D224  85ce       STA $CE
ROM 03226  D226  bd08dd     LDA $DD08,X
ROM 03229  D229  85cf       STA $CF
```

Tabla `$DD07` = ROM `0x03D07`:

```
$37F8=0 -> $0000     Facil        NO usa este motor
$37F8=1 -> $0000     Normal       NO usa este motor
$37F8=2 -> $DD0F     DIFICIL      ROM 0x03D0F   25 bloques + $0000
$37F8=3 -> $DD43     MUY DIFICIL  ROM 0x03D43   28 bloques + $0000
```

**Medido en vivo con los cuatro savestates de David:**

```
Final Fácil.state        $37F8=00   $CE/$CF=$0000
Final Normal.state       $37F8=01   $CE/$CF=$0000
Final Difícil.state      $37F8=02   $CE/$CF=$DD0F
Final Muy Difícil.state  $37F8=03   $CE/$CF=$DD43
```

Por qué esto resuelve el atasco:

- `$37F8` **ya vale 0/1/2/3 por dificultad**. No hay que inventar un stash
  ni hookear el init. Se escribe al empezar partida (ROM `0x00B4D`,
  `0x00B55`, `0x00B5D`, `0x00B65`) y se lee en 27 sitios: es una global
  del motor, no un residuo que se pise.
- **Fácil y Normal no pasan por este código** (puntero `$0000`). Editar las
  listas `$DD0F`/`$DD43` o los bloques que sólo ellas apuntan **no puede
  romperlos**. Ése era justo el riesgo que tumbó v363/v365/v366.
- Sigue valiendo lo que ya sabíais: hay que entrar por password o partida
  nueva, no por states viejos.

**Recomendación:** quitad el hook de `$3D33` y ramificad por `$37F8 >= 2`,
o mejor todavía: no ramifiquéis nada y **editad directamente los bloques de
las listas `$DD0F`/`$DD43`**, que ya están separados de Fácil por
construcción.

---

## 3. La gramática real de un bloque

Bloques del Difícil decodificados desde la lista `$DD0F` (`_` = `$A0`):

```
[ 4] $5DB1   <5C> t1(15 B) <5C> t2(8 B)  $00
[ 5] $5DCB   <5C> t1(14 B) <5C> t2(8 B)  $00
[13] $5C69   t0(8) <5C> t1(5) <5C> t2(8) <5C> t3(2)  $00
[24] $5E5F   t0(23 B, ni un solo $5C)  $00
```

Cuatro correcciones al modelo del prompt:

1. **`$00` cierra el BLOQUE (la ficha), no la fila.** El paso a la ficha
   siguiente lo hace `$3D6A`, no el stream.
2. **`$FF` no aparece** dentro de estos bloques. El final de los créditos
   es el **puntero `$0000`** al final de la lista.
3. **Un bloque puede tener 1, 2, 3 o 4 tramos.** El patrón
   `$5C cargo $5C nombre $00` sólo describe los de 3 tramos. Los bloques
   12-23 tienen **cuatro**, y el 24 (`HUDSON SOFT`) no tiene ninguno.
4. **`$A0` es relleno de tira; `$20` es el espacio real.** En `$5DB1` el
   tramo 1 acaba en `b0 a0 a0 a0 a0` y el tramo 2 lleva `$20` entre las dos
   palabras. Esto no estaba en el prompt y **es probablemente la causa de
   que la maquetación descuadre**: si rellenáis con `$20` en lugar de
   `$A0`, la tira no cuadra.

### Inventario completo del pack Difícil (637 B)

| # | CPU | ROM | total | tramos |
|---|---|---|---|---|
| 0 | $5F21 | 0x3BF21 | 26 | [0, 4, 19] |
| 1 | $5F3B | 0x3BF3B | 25 | [0, 14, 8] |
| 2 | $5F54 | 0x3BF54 | 25 | [0, 4, 18] |
| 3 | $5D99 | 0x3BD99 | 24 | [0, 14, 7] |
| 4 | $5DB1 | 0x3BDB1 | 26 | [0, 15, 8] |
| 5 | $5DCB | 0x3BDCB | 25 | [0, 14, 8] |
| 6 | $5DE4 | 0x3BDE4 | 25 | [0, 14, 8] |
| 7 | $5DFD | 0x3BDFD | 25 | [0, 14, 8] |
| 8 | $5E16 | 0x3BE16 | 25 | [0, 13, 9] |
| 9 | $5E2F | 0x3BE2F | 22 | [0, 13, 6] |
| 10 | $5E45 | 0x3BE45 | 26 | [0, 13, 10] |
| 11 | $5F6D | 0x3BF6D | 23 | [0, 4, 16] |
| 12 | $5C5D | 0x3BC5D | 12 | [6, 4] |
| 13 | $5C69 | 0x3BC69 | 27 | [8, 5, 8, 2] |
| 14 | $5C84 | 0x3BC84 | 30 | [9, 5, 10, 2] |
| 15 | $5CA2 | 0x3BCA2 | 28 | [8, 5, 9, 2] |
| 16 | $5CBE | 0x3BCBE | 27 | [10, 3, 8, 2] |
| 17 | $5CD9 | 0x3BCD9 | 26 | [7, 5, 8, 2] |
| 18 | $5CF3 | 0x3BCF3 | 29 | [9, 4, 10, 2] |
| 19 | $5D10 | 0x3BD10 | 26 | [8, 4, 8, 2] |
| 20 | $5D2A | 0x3BD2A | 28 | [8, 5, 9, 2] |
| 21 | $5D46 | 0x3BD46 | 29 | [10, 5, 8, 2] |
| 22 | $5D63 | 0x3BD63 | 27 | [8, 4, 9, 2] |
| 23 | $5D7E | 0x3BD7E | 27 | [8, 4, 9, 2] |
| 24 | $5E5F | 0x3BE5F | 24 | [23] |

Lista **Muy difícil** (`$DD43`, ROM `0x03D43`), 28 punteros: reutiliza los
bloques 3-24 del Difícil y añade 7 propios al principio
(`$5E77 $5E91 $5EAA $5EC3 $5EDA $5EF2 $5F0A`). Ojo: **comparten bloques**,
así que traducir uno afecta a los dos finales — que probablemente sea justo
lo que queréis.

---

## 4. Verificado en pantalla

Sustituí el bloque `[4] $5DB1` por una regla graduada
`$5C ABCDEFGHIJKLMNO $5C 01234567 $00` y ejecuté con el savestate del
Difícil hasta `$3D6A=5`. **La regla sale en pantalla**, en la posición del
cargo (captura `capturas/dificil_regla.png`).

Confirma que la tabla, el índice y el bloque son los correctos, y que **se
puede maquetar bloque a bloque comprobando cada uno en pantalla**.

---

## 5. Sobre el pack ES que propone Claude

El pack `DIRECC.` / `Shoji` `Masuda` está bien **en cuanto a bytes**
(charset correcto, sin `Á/Ó/Ú`, cargo de 7 ≤ 8). Pero **el sitio donde lo
metéis no es el correcto**: tras el `$FF` del rollo de Fácil, en `$5C66`.
Ese texto sólo lo alcanzaría el motor de Fácil, que en Difícil no corre.

Lo correcto es **repuntar la entrada de la lista `$DD0F`** a donde pongáis
cada ficha. Como el acceso es por puntero, podéis colocarlas donde haya
hueco y con la longitud que necesitéis.

Y **usad `$A0` como relleno de tira, no `$20`.**

---

## 6. Lo que todavía NO afirmo

- **[HIPÓTESIS]** el reparto exacto de columnas por tira y si `$5C` cambia
  el color además de saltar de tira. Mis capturas de prueba salieron a
  media transición y no son concluyentes. Se mide en 10 minutos con reglas
  por bloque, pero prefiero no dárosla a medias.
- **[HIPÓTESIS]** dónde vive `$AA27` (el rasterizador). Depende del banco
  en MPR5 **en ese instante**; hay que capturarlo con el watchpoint puesto
  en `$AA27`, no en `$AA38`. No lo he cerrado.

No he generado ninguna ROM de entrega: las pruebas están en `/tmp`.

---

## Herramientas nuevas (en el repo)

```
tools/bin/mednafen_pce_trace.so   Beetle PCE con watchpoints
tools/pce.py                      watch(), mpr(), rom_off(), watch_write(), writes()
tools/estados.py                  carga los .state de David (son RZIP+zlib)
tools/password.py                 teclea passwords en el emulador
```

Los savestates de David **no son MDFNSVST plano**: son `#RZIPv\x01#` + 16 B
+ zlib, y el core traga desde el offset 16 del descomprimido. Si os fallaba
`load_state` en silencio, era eso.
