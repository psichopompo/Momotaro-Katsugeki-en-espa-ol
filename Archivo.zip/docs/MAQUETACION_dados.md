# Maquetación — juego de DADOS (rehecho)

> **Esta versión CORRIGE la anterior.** El troceo estaba desplazado una
> línea entera: empecé en `0x4AC9C` cuando el bloque empieza en
> `0x4AC8B`. Cada «mensaje» que traduje era la 2.ª línea de uno y la 1.ª
> del siguiente. De ahí el japonés suelto que vio David.

## Estructura real — 12 líneas de 16 columnas

Cinco bocadillos de 2 líneas **más dos líneas de OPCIONES** que se
pintan en una ventana lateral estrecha, no en el bocadillo.

```
L0 + L1   bocadillo   «si aciertas, el gordo / ¿te animas?»
L2        OPCIONES    hago / no hago
L3 + L4   bocadillo   «¡así me gusta! ¿par o impar? / ¡hagan juego!»
L5        OPCIONES    par / impar
L6 + L7   bocadillo   «¡qué suerte! / ¡vuelve otra vez!»
L8 + L9   bocadillo   «¡qué lástima! / ¡hasta otra!»
L10 + L11 bocadillo   «¡bah, qué rácano! / ¡lárgate!»
```

### Las opciones van en COLUMNAS FIJAS

Medido en el japonés: la 1.ª opción empieza en la **columna 1** y la 2.ª
en la **columna 9**.

```
| スル      シナイ    |
  ^col 1    ^col 9
```

En la v318 puse `Par` en la col 2 e `Impar` en la 11: por eso la captura
de David muestra **«Pa»** y **«I»** — se salen de la ventana. Y el `Sí`
en la col 2 en vez de la 1 es el desalineado que señaló.

**La ventana solo muestra ~4 columnas desde cada posición**, así que
`Impar` (5) no cabe. David acepta **`Par` / `Non`**, que además es como
se dice en castellano: «pares o nones».

---

## Las 12 líneas

| # | tipo | ROM | B | japonés | significado | ES | col |
|---|---|---|---|---|---|---|---|
| 0 | msg | `04AC8B` | 17 | `サア アタレバ イッカクセンキン` | si aciertas, el premio gordo | `¡Acierta y ganas` | 16 |
| 1 | msg | `04AC9C` | 18 | `ドウダイ ヤッテイクカイ?` | ¿qué tal? ¿te animas? | `el gordo! ¿Vamos?` | 17 ⚠ |
| 2 | **OPC** | `04ACAE` | 16 | `スル      シナイ` | hago / no hago | *(ver abajo)* | — |
| 3 | msg | `04ACBE` | 18 | `サスガダネ! チョウカ ハンカ?` | ¡así me gusta! ¿par o impar? | `¡Así me gusta!` | 14 |
| 4 | msg | `04ACD0` | 16 | `サア ハッタ ハッタア!` | ¡hagan juego! | `¿Par o non?` | 11 |
| 5 | **OPC** | `04ACE0` | 16 | `チョウ     ハン` | par / impar | *(ver abajo)* | — |
| 6 | msg | `04ACF0` | 16 | `オニイサン ツイテルネ!` | ¡chaval, qué suerte! | `¡Vaya suerte que` | 16 |
| 7 | msg | `04AD00` | 16 | `マタ キテオクレ!` | ¡vuelve otra vez! | `tienes! ¡Vuelve!` | 16 |
| 8 | msg | `04AD10` | 18 | `ザンネン ダッタネ!` | ¡qué lástima! | `¡Qué lástima!` | 13 |
| 9 | msg | `04AD22` | 18 | `ソレジャ マタオイデ!` | ¡pues hasta otra! | `¡Hasta la vista!` | 16 |
| 10 | msg | `04AD34` | 16 | `ケッ シケテルワネッ!` | ¡bah, qué rácano! | `¡Qué rácano!` | 12 |
| 11 | msg | `04AD44` | 18 | `トット キエウセヤガレ ダワ!` | ¡lárgate de una vez! | `¡Largo de aquí!` | 15 |

### Las dos líneas de opciones

```
         1234567890123456
L2      | Sí      No     |    Sí en col 1, No en col 9
L5      | Par     Non    |   Par en col 1, Non en col 9
```

---

## Cambios respecto de la v318

| antes | ahora | por qué |
|---|---|---|
| `¿Te animas?` suelto | `¡Acierta y ganas / el gordo! ¿Vamos?` | era media frase |
| `  Par      Impar` | `| Par     Non    |` | se salía de la ventana |
| `  Sí        No` | `| Sí      No     |` | desalineado |
| `¡Bah, qué rácano!` (17) | `¡Qué rácano!` (12) | no cabía en 16 |

> `¡Bah, qué rácano!` son 17 y el límite es 16. Se queda `¡Qué rácano!`,
> que es lo que ya aprobaste para esta misma frase.