# Guía para el otro chat — ver imágenes y montar el emulador

Escrito el 2026-08-27. Dos cosas que David pide aclarar: **cómo mirar de
verdad lo que sale en pantalla** y **cómo tener el core de PC Engine
funcionando**. Al final, la revisión de tu informe del bug de los cerezos.

---

## PARTE 1 — Cómo «ver» las imágenes

No hay ningún truco de visión. Lo que hay es un método. Si generas un PNG y no
lo abres, no lo has visto: has *supuesto* lo que contiene. Ese fue mi error más
grave del proyecto (norma 352), así que te lo cuento sin adornos.

### 1.1 El paso que se olvida: abrir el fichero

Generar el PNG **no es verlo**:

```python
p.png('/tmp/foto.png')     # esto NO es mirar la imagen
```

Hay que abrirlo con la herramienta de lectura de ficheros (`read_file` sobre la
ruta del PNG). El visor devuelve la imagen y entonces **la ves de verdad**.

Yo mandé cinco capturas a David como prueba de un arreglo. El bug estaba
visible en las cinco. No las había abierto. De ahí salió la norma:

> **352 — Mirar la captura ENTERA antes de enviarla**, no sólo la zona que has
> tocado. Si la presentas como prueba de un arreglo, tiene que demostrarlo en
> toda la pantalla.

### 1.2 Ampliar, porque 256x240 es diminuto

Un artefacto de 16x16 en una imagen de 256x240 no se aprecia. Recorta y amplía
**con `NEAREST`**, nunca con interpolación: cualquier otro filtro inventa
píxeles intermedios y te hace ver colores que no existen.

```python
from PIL import Image
im = Image.open('/tmp/foto.png')
im.crop((0, 95, 90, 145)).resize((450, 250), Image.NEAREST).save('/tmp/zoom.png')
# y ahora ABRIR /tmp/zoom.png
```

Así es como se ve el cuadrado de los cerezos con claridad. A tamaño original
casi no se distingue.

### 1.3 Comparar dos imágenes con números, no con la vista

Para saber **si** dos imágenes difieren y **dónde**, no te fíes del ojo:

```python
from PIL import Image, ImageChops
a = Image.open('/tmp/jp.png').convert('RGB')
b = Image.open('/tmp/es.png').convert('RGB')
d = ImageChops.difference(a, b)
print(d.getbbox())        # None = idénticas; si no, el rectángulo que cambia
```

Y para localizar el patrón, cuenta píxeles por fila y por columna:

```python
px = d.load()
for y in range(d.size[1]):
    n = sum(1 for x in range(d.size[0]) if px[x, y] != (0, 0, 0))
    if n: print('y=%3d  %3d px' % (y, n))
```

Esto me evitó dos falsas alarmas en la v386: parecían regresiones y eran
**desfases de un frame** (el scroll y un destello que parpadea en contrafase).
Un `bbox` en los bordes izquierdo y derecho = scroll desplazado, no un fallo
gráfico.

### 1.4 Antes de mirar, asegúrate de estar mirando la escena correcta

Un savestate cargado y un `run(5)` no basta: muchas escenas tardan cientos de
frames en montarse. En los vítores, el bug aparece **hacia el frame 660**.
Barre varios instantes y mira cuál sirve:

```python
for n in (200, 400, 660, 900):
    p.run(n - p.nframe)
    p.png('/tmp/v_%d.png' % n)
```

### 1.5 Regla que resume todo

> **La verdad es lo que se ve en pantalla, no el hex.**

Un diff de ROM te dice que unos bytes cambiaron; **no** te dice si el jugador
lo nota. Y al revés: bytes idénticos pueden verse mal por culpa de la VRAM. Las
dos mitades hay que comprobarlas, y la que manda es la pantalla.

Corolario que costó una entrada entera del diario:

> **354 — Un savestate tomado DESPUÉS de que ocurra el bug no sirve para saber
> cómo era la escena ANTES.** Reproduce la escena limpia y mide los dos
> estados. Yo diagnostiqué sobre el estado ya dañado, lo llamé «diseño
> original» y escribí que «el bocadillo nunca tuvo marco». Sí lo tenía.

---

## PARTE 2 — Montar el emulador (Beetle PCE)

Si `PCE(...)` te falla o no te llegan los botones, es que no lo tienes bien.

### 2.1 Comprobar primero si ya lo tienes

Los `.so` están **en el repo**, no hace falta compilar nada:

```bash
ls -la tools/bin/
# mednafen_pce_libretro.so   el normal
# mednafen_pce_trace.so      con watchpoints (watch, watch_write, log_on)
```

Prueba de humo:

```python
import sys; sys.path.insert(0, 'tools')
from pce import PCE
p = PCE('roms/Momotaro Katsugeki (Español).pce')
p.run(240)
p.png('/tmp/boot.png')     # y ABRIRLO: debe verse la pantalla de título
```

Si eso funciona, ya está. No compiles.

### 2.2 Recompilar (sólo si los .so faltan o no cargan)

Tarda unos 16 segundos:

```bash
git clone --depth 1 https://github.com/libretro/beetle-pce-libretro.git /tmp/bpce
cd /tmp/bpce && make -j2
cp mednafen_pce_libretro.so /home/user/Momotaro/tools/bin/
```

Para la versión con watchpoints hay que parchear el core antes de compilar:

- Hook en `HuC6280::RunSub`, **antes** de `RdOp(PC)` → captura el PC, los
  registros y el MPR.
- Hook en `HuC6280::WrMem` → captura las escrituras.
- Exportar los símbolos añadiendo `mkt_*;` al fichero `link.T`. **Sin esto los
  símbolos no salen del `.so`** y `ctypes` no los encuentra.

### 2.3 Las cuatro trampas que hacen perder horas

**a) Sin declarar el mando no llega ningún botón.**
Falta `retro_set_controller_port_device(0, 1)` y `press()` no hace nada, sin
error ninguno. Ya está puesto en `pce.py`; si escribes tu propio arnés,
acuérdate.

**b) `p.vram()` devuelve 0 bytes.** El core **no** expone la VRAM por
`retro_get_memory_data`. Hay que sacarla de la sección `VRAM` del savestate
serializado. Está resuelto en `tools/sat.py`:

```python
import sat
v = sat.vram(p)            # 64 KB
sat.celda(v, 0x2B7)        # los 128 B de una celda de sprite
sat.visibles(v)            # sprites en pantalla
```

**c) El word 2 del SAT es el patrón POR DOS** (norma 346):

```python
celda = (word2 >> 1) & 0x3FF
```

Leerlo como patrón directo te hará «descubrir» un envolvimiento de VRAM que no
existe. Me pasó.

**d) Los `.state` de David son RZIP**, no savestates planos: `#RZIPv\x01#` +
16 B + zlib, y el core traga desde el offset 16 del descomprimido. Usa
`estados.carga(p, ruta)`, que ya lo maneja.

### 2.4 Bonus: capstone no sirve

En modo 65C02 lee `TAM ($53)` como `nop` y se desincroniza. Usa
`tools/dis6280.py`, que tiene las instrucciones propias del HuC6280.

**Y traduce bien el banco**, o desensamblarás basura que parece código real:

```
ROM = banco * 0x2000 + (PC & 0x1FFF)
```

Hoy mismo me equivoqué con `$861F`: lo busqué en el banco `$02` (ROM `0x2061F`)
cuando está en el `$20` (ROM `0x4061F`). Salió un listado plausible y falso.
Para saber el banco de verdad, ponle un `watch()` y lee el MPR:

```python
p.watch(0xD287)
p.run(1)
print([hex(x) for x in p.mpr()])
print('ROM 0x%05X' % p.rom_off(0x6CA0))
```

---

## PARTE 3 — Revisión de tu informe del bug de los cerezos

He verificado tu trabajo midiendo, no leyendo. **Tu diagnóstico es correcto**
en lo esencial, y el gancho lo encontraste tú. Enhorabuena, porque no era obvio.

### Lo que confirmo [HECHO]

| Lo que dices | Verificado |
|---|---|
| 209 bytes de diff en `0x4900-0x4E5F` | **Exacto: 209** |
| Tres tramos: `0x4920`, `0x4B0F`, `0x4C07` | **Correcto** |
| Gancho añadido en `0x1DFAE`, llamado desde `$D955` | **Correcto**, desensamblado byte a byte |
| `$D955`: `JSR $BAE2` → `JSR $DFAE`, y `LDY #$18` → `#$24` | **Correcto** |
| v334 ya tiene 7 tiles corruptos; v378 → 9; v385/v386 → 10 | **Exacto, los cinco hitos** |
| El cuadrado visible ya está en v334 | **Confirmado EN PANTALLA** |
| La japonesa sale limpia | **Confirmado** con el state nuevo de David |

Reproduje el bug con el savestate «pre-vítores» que David acaba de pasar
(`states/vitores_jp_david.state`, frame **660**) y lo tengo en capturas.

### Corrección: el reparto de culpas no es el que dices

Hice el experimento de restaurar tramos y mirar la pantalla:

| Qué restauro | Tiles corruptos | En pantalla |
|---|---|---|
| Nada (v386) | 10 | cuadrado bien visible |
| **Sólo** `0x4B0F` + `0x4C07` (datos de sprite) | 3 | **el cuadrado grande desaparece**; queda un resto arriba |
| Además `0x4920` (glifos del menú) | 0 | **copa completamente limpia** |

Tú escribes que la v379 «solo rompió `$2B7-$2B9`, que quedan tapados por la
copa (no cambian la imagen)». **No es así: sí se ven.** Son la banda de
artefactos que queda en la parte superior. Lo tienes en
`capturas/bug_vitores/zoom_solo_sprites.png` (con los sprites ya restaurados) y
en `zoom_todo_limpio.png`. Ábrelas y compáralas: la diferencia está arriba.

Es justo el error del que va la Parte 1: dedujiste del hex que estaban tapados,
en vez de mirar la pantalla.

### Hallazgo nuevo que cambia el arreglo [HECHO]

**El gancho `$DFAE` no se ejecuta nunca.**

```
watch(0xDFAE) en la escena de los vítores, 900 frames  -> 0 hits
watch(0xDFAE) en los 54 savestates del proyecto        -> 0 hits en NINGUNO
```

Y mira lo que copia:

```
0x4C07 (ES): 04 00 00 18 FF      (JP: 00 FF 00 FF 00)
0x4B0F (ES): 02 00 80 80 00      (JP: 00 00 FF 00 FF)
```

El primer byte es el contador de `$F1B9`: **4 y 2**. Son transferencias
minúsculas, de un cargador que no llega a ejecutarse en ninguna escena
conocida. Antes de mover nada, hay que averiguar **qué disparaba `$D955`** y si
sigue vivo. Puede que sea código muerto de una prueba abandonada, en cuyo caso
el arreglo es mucho más simple de lo que planteas.

### Sobre tus tres opciones de arreglo

**Opción 1 (mover el árbol): la descartaría.** Son 1376 B contiguos y hay que
repuntar un `TIA` que vuelca 8 KB de tiles del nivel. Mucho riesgo para un bug
cosmético.

**Opción 2 (mover los glifos): tiene una trampa que no mencionas.** La fuente
del menú va de `0x4000` a `0x4CFF` y el árbol empieza en `0x4900`. **Se solapan
1024 B**, o sea 64 glifos (`$C0-$FF`) contra 32 tiles (`$2B6-$2E0`). No es que
la traducción invadiera el árbol por descuido: **la zona ya estaba compartida
en el original**. El japonés no lo nota porque no usa esos glifos altos.

Además busqué hueco: de `$30` a `$BF` (fuera del árbol) **sólo hay un glifo
vacío en la japonesa**, el `$3C` en `0x40C0`. Necesitas cinco. Así que
reubicar dentro de la fuente no cabe: hay que sacar los glifos a otro banco y
tocar el renderer.

**Opción 3 (mover los datos de sprite): es la que yo atacaría primero**, y no
por lo que dices. No es «lo pequeño que por sí solo no basta»: **es lo que
quita el cuadrado grande**, que es el 90 % del problema visible. Y si además
se confirma que `$DFAE` es código muerto, se restauran los dos tramos y listo.

### Lo que yo haría, en este orden

1. Averiguar **quién llama a `$D955`** y si esa ruta se ejecuta alguna vez.
   Si está muerta: restaurar `0x4B0F` y `0x4C07`, quitar el gancho, y el
   cuadrado grande desaparece con riesgo casi nulo.
2. Sólo entonces, atacar los glifos `$C2-$C6` (la banda de arriba), que exige
   sacarlos del solape y repuntar el renderer del menú.
3. Verificar **en pantalla** a frame 660 con el state de David, mirando la
   captura entera y comparando contra la japonesa con `ImageChops`.

**Ojo:** los glifos `$C2-$C6` son las vocales acentuadas que **diseñó David a
mano** en la v379. No se pueden perder ni rehacer por tu cuenta. Si hay que
moverlas, se mueven tal cual, y **la decisión es de David**.

### Material que te dejo

```
states/vitores_jp_david.state          el state nuevo, frame 660
capturas/bug_vitores/repro_ES_bug.png       el bug reproducido
capturas/bug_vitores/repro_JP_limpio.png    la japonesa, misma escena
capturas/bug_vitores/zoom_ES_bug.png        copa ampliada, con el cuadrado
capturas/bug_vitores/zoom_JP_limpio.png     copa ampliada, limpia
capturas/bug_vitores/zoom_solo_sprites.png  restaurando SOLO los sprites
capturas/bug_vitores/zoom_todo_limpio.png   restaurando también los glifos
```

Ábrelas todas. Es el mejor ejercicio de la Parte 1.
