# Escena de los padres — ROM `0x1F077`

**CORRECCIÓN.** La primera versión de este documento analizaba el bloque
`0x1F366`, que **no es esta escena**: es una de las cuatro variantes del
aviso previo a los minijuegos (el mismo guion que el tutorial de los
ñordos). David lo detectó comparando con la ROM japonesa:

> «Creo que te estás confundiendo. Lo que le dicen a Momotaro es otra cosa.
> Creo que le mandan a comprar kibidango. Además le dan dinero.»

Tenía razón. El bloque real es **`0x1F077`–`0x1F10B`**, **149 bytes**,
localizado por el puntero `$5077` que carga `$C181` (el arranque del banco
`0x0D`).

---

## Códigos de control de este bloque

Distintos de los del tutorial, conviene tenerlos claros:

```
0x01        cabecera
0x00        fin de línea
0xFC        FIN DE PÁGINA        (aquí no es 0xFE)
0xF0        espera / pulsación
0x3C, 0x5C  espacio
0x20        espacio
0xFB        MARCADOR DE CANTIDAD  <- ver abajo
0x24        símbolo 両 (dinero)
0xFF        fin del bloque
0xDE / 0xDF dakuten / handakuten: NO consumen celda
```

### El marcador `0xFB` (importante)

En `0x1F0A6` hay **tres bytes `0xFB` seguidos** justo antes del `$` (両):

```
ももたろうは
[FB][FB][FB]両 てにいれた!
```

En la captura se lee `ももたろうは  50両 てにいれた!`. Es decir: el juego
**inserta la cantidad en tiempo de ejecución** sobre esos tres huecos.
Reserva 3 dígitos.

**Consecuencia para la traducción: esos tres `0xFB` y el `0x24` hay que
conservarlos tal cual, y en ese orden.** Si se mueven o se borran, el
importe no saldrá o saldrá donde no debe.

---

## Volcado y traducción, línea a línea

Celdas = celdas reales en pantalla (el dakuten no cuenta).

### Página 1

| | texto | celdas |
|---|---|---|
| **hiragana** | `「ももたろうや!` | **8** |
| romaji | `"Momotarō ya!` | |
| **directa** | `«¡Momotaro!` | **11** |

| | texto | celdas |
|---|---|---|
| **hiragana** | `おに たいじに おかねが` | **12** |
| romaji | `Oni taiji ni okane ga` | |
| **directa** | `Para vencer a los ogros` | **23** |

| | texto | celdas |
|---|---|---|
| **hiragana** | `ひつようじゃろう!」` | **10** |
| romaji | `hitsuyō ja rō!"` | |
| **directa** | `necesitarás dinero!»` | **20** |

### Página 2 — línea del importe

| | texto | celdas |
|---|---|---|
| **hiragana** | `ももたろうは` | **6** |
| romaji | `Momotarō wa` | |
| **directa** | `¡Momotaro consigue` | **18** |

| | texto | celdas |
|---|---|---|
| **hiragana** | `[FB][FB][FB]両 てにいれた!` | **12** |
| romaji | `50 ryō te ni ireta!` | |
| **directa** | `[FB][FB][FB]$ de oro!` | **12** |

### Página 3

| | texto | celdas |
|---|---|---|
| **hiragana** | `「きびだんごも` | **7** |
| romaji | `"Kibidango mo` | |
| **directa** | `«¡Llévate también` | **17** |

| | texto | celdas |
|---|---|---|
| **hiragana** | `もっていくがよい!」` | **10** |
| romaji | `motte iku ga yoi!"` | |
| **directa** | `unos kibidango!»` | **16** |

### Página 4

| | texto | celdas |
|---|---|---|
| **hiragana** | `ももたろうは きびだんごを` | **13** |
| romaji | `Momotarō wa kibidango o` | |
| **directa** | `¡Momotaro consigue` | **18** |

| | texto | celdas |
|---|---|---|
| **hiragana** | `ひとつ てにいれた!` | **10** |
| romaji | `hitotsu te ni ireta!` | |
| **directa** | `un kibidango!` | **13** |

### Página 5

| | texto | celdas |
|---|---|---|
| **hiragana** | `「ももたろうや!` | **8** |
| romaji | `"Momotarō ya!` | |
| **directa** | `«¡Momotaro!` | **11** |

| | texto | celdas |
|---|---|---|
| **hiragana** | `よのため ひとのため` | **10** |
| romaji | `Yo no tame hito no tame` | |
| **directa** | `¡Esfuérzate por el mundo` | **24** |

| | texto | celdas |
|---|---|---|
| **hiragana** | `はげむのじゃ!」` | **8** |
| romaji | `hagemu no ja!"` | |
| **directa** | `y por la gente!»` | **16** |

---

## Resumen

| pág | línea | hiragana | directa |
|---|---|---|---|
| 1 | 1 | 8 | 11 |
| 1 | 2 | 12 | 23 |
| 1 | 3 | 10 | 20 |
| 2 | 1 | 6 | 18 |
| 2 | 2 | 12 | 12 |
| 3 | 1 | 7 | 17 |
| 3 | 2 | 10 | 16 |
| 4 | 1 | 13 | 18 |
| 4 | 2 | 10 | 13 |
| 5 | 1 | 8 | 11 |
| 5 | 2 | 10 | 24 |
| 5 | 3 | 8 | 16 |

```
japonés   máximo 13 celdas
directa   máximo 24 celdas
```

**David tenía razón: hay margen de sobra.** El japonés no pasa de 13 celdas
y algunas páginas usan solo 2 de las 3 líneas. Con el límite actual de
**16 celdas** de este bocadillo (sin ensanchar), casi todo cabe adaptando
un poco.

Solo dos líneas de la directa se pasan de 16: `Para vencer a los ogros` (23)
y `¡Esfuérzate por el mundo` (24). Ambas se arreglan repartiendo en la
tercera línea, que en esas páginas está libre.

---

## Propuesta de adaptación a 16 celdas

Sin tocar el bocadillo ni la geometría. Respeta los tres `0xFB` y el `0x24`.

```
pág1  «¡Momotaro!            (11)
      Para vencer            (11)
      a los ogros            (11)      <- 3ª línea, antes vacía

pág2  ¡Momotaro consigue     (18)  -> ¡Consigue           (10)
      [FB][FB][FB]$ de oro!  (12)      [FB][FB][FB]$!     ( 5)

pág3  «¡Llévate también      (17)  -> «¡Llévate unos      (15)
      unos kibidango!»       (16)      kibidango!»        (11)

pág4  ¡Momotaro consigue     (18)  -> ¡Consigue           (10)
      un kibidango!          (13)      un kibidango!      (13)

pág5  «¡Momotaro!            (11)
      ¡Esfuérzate por        (15)
      el mundo y la gente!   (20)  -> por el mundo!»      (14)
```

Queda **pendiente de tu revisión**: es una adaptación mecánica para que
quepa, no una propuesta de estilo.

---

## Espacio disponible

```
bloque:  0x1F077 - 0x1F10B  =  149 bytes
detrás:  0x1F10C empieza otro bloque (01 b5 ca de b1 bb dd ...) — PEGADO
```

No hay hueco detrás. La versión adaptada debe caber en 149 bytes o habrá que
reubicar el bloque. Se comprobará al codificar.

---

## Notas de traducción

1. **`きびだんご` (kibidango)**: bolas de mijo, el dulce clásico del cuento.
   Momotaro las usa para reclutar al perro, el mono y el faisán. Se puede
   dejar el préstamo (`kibidango`) o traducir (`bolas de mijo`, 13 celdas).
   Recomiendo dejarlo: es icónico y más corto.

2. **`両` (ryō)**: la moneda de la época Edo. En el charset del proyecto ya
   está mapeada al símbolo `$` (código `0x24`), decisión heredada del chat
   original. **No tocar.**

3. **`おに` (oni)**: los ogros/demonios de la isla Onigashima, el objetivo
   del juego.

4. **`のじゃ` / `じゃろう`**: habla de anciano. El original marca así a los
   padres. En castellano no hay equivalente natural breve; el chat original
   optó por no marcarlo y creo que es lo correcto.

5. **Las comillas `「」`** están en el charset como `0xA2`/`0xA3`. Se pueden
   mantener como `«»` o quitarlas.

---

# ゲロゲロモード — qué falta

## Ya resuelto (del chat original)

| | |
|---|---|
| **Desbloqueo** | al completar `むずかし` (difícil) |
| **El limitador** | `$C4F1: CPY #$03` — ROM `0x1A4F2`, cambiar `03` → `04` |
| **Los textos** | la tabla `0x1F4AE` ya tiene 4 entradas: `FÁCIL / NORMAL / DIFÍCIL / MUY DIFÍCIL` |
| **El string** | `MUY DIFÍCIL` existe en ROM (dos copias, una en `0x1FC51`) |
| **La tabla CG** | `$C5A2` tiene datos válidos en el índice 3 (`08 70`) |
| **El bocadillo** | ya se ensanchó a 14 tiles / 112 px **a propósito** para que quepa |

**El contenido está hecho. Falta la estructura.**

## El bloqueo

```
0x1A598: 9c c5          puntero a la lista del modo 0 ($C59C)
0x1A59A: 9f c5          puntero a la lista del modo 1 ($C59F)
0x1A59C: 02 01 00       lista modo 0, TRES elementos
0x1A59F: 03 02 01       lista modo 1, TRES elementos
0x1A5A2: 08 70 88 71... tabla CG $C5A2
```

Las dos listas son de 3 elementos y están **pegadas** entre sí y con la
tabla CG. Con `CPY #$04` el bucle leería un cuarto byte:

- lista del modo 0 → el `03`, primer byte de la lista del modo 1;
- lista del modo 1 → el `08`, primer byte de la tabla CG, fuera de rango.

## Lo que falta, en orden

1. **Hueco en el banco `0x0D`** (el bucle lee por puntero de 16 bits dentro
   del banco mapeado). Ya tenemos uno: `$DDC8` tenía 568 B y la v109 usa
   133 → quedan **~435 B libres desde `$DE4D`**.
2. **Reubicar las dos listas** ahí, ampliadas a 4 elementos, y repuntar
   `$C598`.
3. **Decidir el orden de rotación.** Las listas actuales (`02 01 00` y
   `03 02 01`) parecen ventanas deslizantes; con 4 modos harían falta
   `03 02 01 00` y quizá una tercera lista. **Solo se confirma viéndolo.**
4. **Cambiar `0x1A4F2`: `03` → `04`.**
5. **Verificar el desbloqueo**: localizar dónde se guarda «difícil
   completado» y comprobar que el cuarto modo queda oculto hasta entonces.

## Riesgo

El bucle `$C4C0` vive en el banco `0x0D`, que es **código muy compartido**
(el bucle `$C000` tiene 20 llamantes). Cualquier cambio hay que verificarlo
en la pantalla de título y en las escenas, no solo en el selector.

## Recomendación

**Dejarlo para el final.** Mucho riesgo en código compartido, verificación
solo visual, y el resultado es un modo oculto. El guion sin traducir
(tiendas, aldeanos, objetos, mapa) da bastante más valor por hora.
