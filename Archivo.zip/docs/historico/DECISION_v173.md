# ¿Partir de la v157, arreglar la v173, o mezclar?

**Recomendación: arreglar la v173.** Lo que falla son datos, no arquitectura.

---

## Lo que la v173 ya tiene bien (y no conviene tirar)

- **El guion traducido**, con la revisión que ya hiciste.
- **Compresión por diccionario**: 48 códigos nuevos en `$3E-$8F` para frases
  repetidas. Eso resuelve el problema de los 3358 B que faltaban, que era el
  bloqueo más gordo que teníamos.
- **El bocadillo apaisado**: el SATB muestra el marco en `y=32..106` con 5
  sprites de texto por fila. La geometría funciona.

Rehacerlo desde la v157 obligaría a reimplementar la compresión desde cero.

---

## Por qué se corrompe todo: son DOS problemas distintos

### 1. Hay cinco bloques que siguen en japonés

Comparados byte a byte con la ROM japonesa:

| bloque | estado | bytes en `$B1-$DF` |
|---|---|---|
| vítores | **idéntico al japonés** | 64 % |
| dinero | **idéntico** | 69 % |
| mensajes de victoria | **idéntico** | 64 % |
| final y créditos | **idéntico** | 63 % |
| quiz | **idéntico** | 58 % |
| guion | traducido | 21 % |

La tabla `$9CF3` está repuntada al alfabeto latino, así que los códigos
`$B1-$DF` que antes daban katakana **ahora dan letras**. Todo bloque que siga
en japonés se ve como galimatías.

Esto **no es un bug del bocadillo**: es texto pendiente de traducir. Es justo
lo que dijiste hace sesiones — *«el problema lo tenemos sólo nosotros porque
fuimos quienes lo ocasionamos»*.

### 2. Los sprites de texto SE SOLAPAN entre sí ← **el destrozo de verdad**

Leído directamente del SATB de tu state, sin interpretar formatos:

```
ranura 46 -> celdas 1A6 1A7 1A8 1A9
ranura 47 -> celdas 1A8 1A9 1AA 1AB    <-- solapa con la 46
ranura 48 -> celdas 1AA 1AB 1AC 1AD    <-- solapa con la 47
```

**Los sprites de 32×32 avanzan de 2 en 2 celdas, pero cada uno ocupa 4.**
Cada sprite pisa la mitad del anterior, así que los caracteres se machacan
unos a otros. Un sprite de 32×32 necesita 4 celdas propias y la base
alineada a 4.

Y además invaden:

- **`1AF` y `1B3`** → celdas del **HUD** (por eso se rompe la barra al hablar);
- **`1A4 1A5 1AC 1AD`** → el **propio marco** del bocadillo;
- `1D0 1D1 1D8 1D9 1E0 1E1 1F0 1F1 1FC 1FD` → otros gráficos.

**De las 18 ranuras de texto, 11 pisan algo.**

En el diseño que medí (entrada 159 del diario) las bases eran
`1A8 1C0 1C4 1CC 1D4`: separadas de 4 en 4, alineadas a 4, sin solapes y
todas libres. Es justo el error que evité allí.

### 3. Y encima el fondo sin inicializar

Ya diagnosticado (entrada 162): `$9D33` escribe el glifo pero **no el fondo**.
Las celdas nuevas salen con el ruido de lo que hubiera antes en VRAM.

---

## Plan propuesto, en este orden

1. **Reasignar el área de texto** a las celdas libres `1A8 1C0 1C4 1CC 1D4`.
   Esto solo quita la corrupción del HUD y del marco.
2. **Inicializar su fondo** (planos 0-2 = `$FFFF`) al abrir el bocadillo.
   Esto quita el ruido.
3. **Cerrar las dos esquinas** izquierdas (ya localizado: tile `19C` fila 13
   y `19E` fila 3, un bit cada uno).
4. **Traducir los cinco bloques** que siguen en japonés. Tres de ellos ya los
   tengo hechos: mensajes de victoria (1616 B, caben) y nombres de artes
   (92 B, caben exactos).

Los pasos 1-3 son los que dejan los bocadillos limpios. El 4 es lo que quita
el galimatías del resto del juego.

---

## Dónde está el reparto en la v173

Localizado: la v173 **no tocó** la tabla de destinos `$9BBD` (sigue igual que
en la v157). Lo que hizo fue reescribir `$9A95`, que ahora mapea el banco
`$23` y lee una lista de sprites nueva en `$7C02` (= ROM `0x47C02`).

Esa lista es la que hay que corregir: cambiar las bases para que vayan de 4
en 4 sobre `1A8 1C0 1C4 1CC 1D4` en vez de solaparse de 2 en 2.
