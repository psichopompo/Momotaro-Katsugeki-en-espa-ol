# INFORME DE TRASPASO — Momotarou Katsugeki en castellano

**Fecha:** 2026-08-28 · **Estado:** v393 promocionada a **ROM OFICIAL**

Este informe cubre **de la v386 a la v393** y deja fijado lo que toca hacer
ahora. Sustituye a `INFORME_TRASPASO_v386.md`, que queda como histórico.

Si retomas el proyecto sin contexto: lee esto entero, después
`docs/PENDIENTES.md` (registro único de tareas) y `LEEME.md` (normas).

---

## 1. El proyecto

Traducción al castellano de **Momotarou Katsugeki** (PC Engine, 512 KB, HuCard).

- **Dirige: David** (*Psicopompo*, elotrolado.net). Las decisiones de diseño
  y de maquetación **son suyas**.
- Repo: `https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol`
- ROM base: `Momotarou Katsugeki (Japan).pce`,
  MD5 `ec7358edb3672a8aa8850623eec72a71` — **INTOCABLE**

### La ROM oficial

```
roms/Momotaro Katsugeki (Español).pce
MD5    5ea09ef86fc219cc58b6194f9f0afe96
SHA-1  b23981b4c690b2ff50609f8042757f989592d941
CRC32  4811A63E
```

Parche: `parches/Momotaro Katsugeki (Español).ips` (contra la virgen,
round-trip verificado). `roms/momotaro_es_v393.pce` es el mismo fichero.

**Testeo acumulado.** Sobre la v391: fase completa, todos los aldeanos, todas
las tiendas, varios minijuegos, el quiz, el jefe final, los cuatro finales y
las dos pantallas secretas. Sobre la v393: primer nivel jugado —aldeanos,
objetos y minijuegos, ocultos y de tienda—, sin errores. Falta el testeo del
juego completo, pero los niveles son estructuralmente iguales.

---

## 2. Cómo tratar con David

No es opcional. Está aquí porque saltárselo ha costado disgustos reales.

- **Siempre en castellano.** Tutear.
- Reconocer los errores propios **explícitamente**, diciendo qué falló en el
  razonamiento. No maquillarlos, no diluirlos.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- Estilo: ingeniero explicando su trabajo. Conciso. **No ser condescendiente.**
  No insistir en que descanse. David: *«Ni de coña. Seguimos. Sin avances aquí
  no duerme ni Dios. 😸»*
- **Una sola pregunta por mensaje**, al final, con `¿` de apertura.
- Capturas individuales, nunca rejillas.
- **Si David contradice el análisis, comprobarlo antes de descartarlo: ha
  tenido razón SIEMPRE.** En esta tanda volvió a pasar dos veces: el
  «recuerda que estamos usando el espacio del katakana» que tumbó un
  diagnóstico falso, y el **«esto sólo pasa en la v392, en la v391 no»** que
  redujo la caza del bug de los diálogos a cuatro grupos de bytes.
- No sacar una versión por cada cambio mínimo: agrupar.

### Órdenes permanentes

- **No se genera ROM hasta ver capturas de cómo quedan los cambios.**
- **No se toca el bocadillo apaisado** (comparte formato con otros).
- **No bloquear el menú RUN cuando habla el abuelo.**
- **No se puede recortar texto: tiene que caber.**
- **Todo fallo se puede revertir, pero con cautela de no pisar nada.**

---

## 3. Qué se ha hecho de la v386 a la v393

| Ver | MD5 | Qué |
|---|---|---|
| v386 | `eaf7751123990575182612e52f34192c` | el bocadillo del abuelo conserva su marco al abrir el menú RUN |
| v387 | *(retirada)* | cerezos limpios, pero sin marco en los minijuegos |
| v388 | `57d842ae19561a89e2f94feb19b7d767` | cerezos limpios **y** marco de minijuegos intacto |
| v389 | *(retirada)* | arreglaba el submenú de raquetas pero rompía su nombre |
| v390 | `b33f3dd104f20d508b85d36b2d526459` | submenú de raquetas y nombre, los dos bien |
| v391 | `84076021d76a1a35cb89f0f6033e1a91` | «Janpu» y «Paropunte» con la `p` correcta |
| v392 | *(retirada)* | minijuego PPT traducido, **pero pisaba un byte de código** |
| **v393** | **`5ea09ef86fc219cc58b6194f9f0afe96`** | **OFICIAL**: lo mismo, con el tope corregido |

Todas con IPS contra la virgen y round-trip verificado. No-regresión
sistemática en cada una: **57 states × 300 frames, 0 diferencias**.

### v386 — el bocadillo del abuelo se ponía azul al abrir el menú RUN

El cargador `$D268` subía el CG del menú desde ROM `0x22CA0` y arrasaba
`$1C0-$1F9`: **58 celdas cuando el menú sólo usa 8**. Arreglo: partir el
stream en 3 bloques (`$1C0` 4 celdas, `$1D0` 4, `$1E0` 26) y meter el
despachador en la cueva `$DFE1`.

Para esto hubo que escribir **`tools/cg.py`**, el codec del CG comprimido
(descompresor en `$861F`, banco `$20`, ROM `0x4061F`), con round-trip
verificado antes de tocar nada (norma 355).

### v388 — cerezos de los vítores y marco de los minijuegos

Dos causas superpuestas:

1. Un gancho en `$DFAE` que la traducción había añadido y que guardaba datos
   dentro del bloque del árbol.
2. **Solape que ya existía en la japonesa**: la fuente del menú
   (`0x4000-0x4CFF`) pisa el árbol (`0x4900-0x4E5F`).

La **v387 quitó el gancho creyéndolo código muerto y se retiró**: `$DFAE`
carga el marco del bocadillo de los minijuegos (`0x4C07`→`$1EC`,
`0x4B0F`→`$1F8`, rabillo incluido). De ahí salió la norma 360.

Arreglo definitivo: conservar el gancho y **mover el árbol** de `0x04900` a
`0x7F900` (banco `$3F`), copiando los datos **de la ROM original limpia**
(norma 358):

```
0x19B61  $02 -> $3F      0x19BD3  $44 -> $54
```

### v390 — submenú de las raquetas

La ficha del objeto `$09` apuntaba a `$B100`, que es **código**, en vez de a
la tabla de textos `$B1AC`: el bucle `$D68C` recorría opcodes como caracteres
y no encontraba nunca el terminador.

```
0x430F0  $00 -> $AC      (puntero $B100 -> $B1AC)
0x430EF  ---- -> $00     (nombre acortado a «Raqueta»)
```

Hicieron falta **los dos** bytes: `0x430EF` era a la vez el terminador del
nombre y el byte bajo del puntero (norma 367). La v389, que sólo cambió el
primero, rompió el nombre y se retiró.

### v391 — la `p` de «Janpu» y «Paropunte»

`0x4B7DE` y `0x4B808`, `$B0` → `$5E`. El `$B0` es la `p` de
`charset_vitores`; en este motor daba «Ç».

### v392 → v393 — el minijuego de piedra, papel o tijeras

**No era un gráfico.** Es texto en claro que entra por la ruta katakana
(`byte >= $A0` → el glifo es el byte, directo); se veía mal el latino porque
ocupa el espacio del kana. Lo dijo David y tenía razón.

```
Motor:      $C79A, banco $08 (ROM 0x1079A). Hornea 16 celdas $0EC-$0FB
Montador:   $C6D1 (ROM 0x106D1)
  0x106E3   LDX #$02  <- Nº DE LÍNEAS
  $C6E5     LDX #$10     columnas
Ancho real medido en pantalla: 14 columnas
Charset: charset_oficial (la `p` es $5E)
Controles: $00 pausa · $80 fin de línea · $FF fin de mensaje
```

**Los punteros no están en tabla**: son inmediatos dentro del banco `$08`
(norma 369), y por eso cada mensaje se puede mover por separado.

```
$DD1B  LDA #$08/STA $BF ; LDA #$79/STA $C0  -> $7908  mensaje A
       ROM 0x11D1C (bajo) / 0x11D20 (alto)
$DD26  LDA #$23/STA $BF ; LDA #$79/STA $C0  -> $7923  mensaje B
       ROM 0x11D27 (bajo) / 0x11D2B (alto)
```

Reparto final (`tools/build_v393.py`):

```
0x106E3   LDX #$02 -> #$03                    (tres líneas)
A (38 B) -> 0x4B826, hueco de 55 B            puntero $7908 -> $7826
B (22 B) -> 0x4B908, 51 B hasta el código     puntero $7923 -> $7908

A = «¡Piedra, papel» / «o tijeras!» / «¡Mira allá!»
B = «¡Iguales!» / «¡Mira allá!»
```

«¡Iguales!» y no «¡Empate!», por decisión de David: el mensaje sale cuando
ambos sacan la misma mano, o sea una tirada nula, no un empate de la partida.

**Por qué se retiró la v392 (entrada 260, léela entera).** Puse el tope del
bloque B en `0x4B93C` porque en el volcado hex vi `A5 DD F0 60 4C 42 79…` y
decidí que ahí empezaba el código. **Ese `A5 DD` ya era la instrucción**: el
código empieza en `0x4B93B`. Mi relleno `$A0` se comió un byte:

```
v391  4B93B  a5 dd   LDA $DD      correcto
v392  4B93B  a0 dd   LDY #$DD     pisado
```

`$793B` es la **cabecera del intérprete de texto de todo el juego** (se entra
por `JSR $793B` desde ROM `0x41807` y `0x4B9F3`, y por `JMP $793B` desde
`$79AC`):

```
793B  LDA $DD      ; ¿queda anidamiento abierto?
793D  BEQ $799F    ; no -> emitir el carácter siguiente
793F  JMP $7942    ; sí -> desapilar
```

`LDA` carga A **y fija Z**; `LDY #$DD` fija Z con un inmediato que nunca es
cero, así que el `BEQ` no se tomaba jamás y el intérprete se saltaba el
carácter que iba a emitir. **Todos los diálogos del juego perdían una letra
en la primera lectura**, y salían enteros en la segunda.

Y el assert que debía cazarlo estaba mal **por el mismo byte**:
`rom[0x4B93C:...] == orig[...]` arrancaba justo detrás del byte que yo estaba
pisando. Un assert escrito con la misma suposición que el bug no verifica
nada. De ahí la **norma 371**.

La no-regresión de 57 states tampoco lo cazó: cubre estados, no la
**apertura** de un bocadillo nuevo (norma 359, otra vez).

### [HECHO] «¡Mira allá!» no sobra

David preguntó si esa frase salía de más. **Viene igual en el japonés.**
Decodificados los dos mensajes de la ROM virgen:

```
0x4B908  ｼﾞｬﾝ{00}ｹﾝ{00}ﾎﾟﾝ! {80} ｱｯﾁﾑｲﾃ{00}ﾎｲ!{FF}
0x4B923  ｱｲ{00}ｺﾃﾞ{00}ｼｮ!  {80} ｱｯﾁﾑｲﾃ{00}ﾎｲ!{FF}
```

Los **dos** llevan «acchi muite hoi» pegado detrás: el juego canta la tirada
y el reto de la mirada en un solo bocadillo, porque en el juego real es un
único ritmo (*jan-ken-pon!* → salen las manos → *acchi muite hoi!* → se
señala). En el código, `$D2D0 JSR $DD1B` / `$D2D5 JSR $DD26` sueltan cada uno
el mensaje entero de una tirada. Separarlos exigiría partir ambos mensajes y
añadir una llamada nueva al motor. **Se deja como está**, por fidelidad y por
decisión de David.

---

## 4. Normas nuevas de esta tanda (352-371)

Están todas en `LEEME.md`. Las de esta etapa:

| # | Norma |
|---|---|
| 352 | Mirar la captura **ENTERA** antes de enviarla. |
| 353 | No dar por bueno un arreglo con **prueba artificial**. Reproducir la escena como la vive el jugador. |
| 354 | Un savestate tomado **después** del bug no dice cómo era **antes**. |
| 355 | Antes de tocar un cargador, escribir su **codec** y probar el round-trip. |
| 356 | Medir qué celdas **referencia la SAT** frente a cuáles se sobrescriben. |
| 357 | Una dirección lógica puede existir en **varios bancos**: leer el MPR en el hit. |
| 358 | Al **mover** datos para sacarlos de un solape, copiarlos de la fuente **limpia** (la ROM original). |
| 359 | «No se ejecuta en ningún savestate» **NO** demuestra código muerto: los savestates cubren estados, no transiciones. |
| 360 | Antes de borrar código que la traducción **añadió**, decodificar qué datos mueve y **mirarlos**. |
| 361 | Si David dice que algo funcionaba en una versión, es un **dato medido**: comparar contra ESA versión. |
| 362 | Antes de describir lo que se ve en una captura, **ampliarla** (crop + resize NEAREST). |
| 363 | Si un bug no se reproduce, probar en **otro emulador** (Mesen dio el dato clave). |
| 364 | Un savestate hecho con una ROM **no sirve** para juzgar otra ROM. |
| 365 | Para comparar volcados de VRAM, comparar los **bytes**, no una firma resumida. |
| 366 | Si un bucle de dibujado «no termina», sospechar del **puntero**, no del bucle. |
| 367 | Un byte puede tener **dos dueños** (terminador de texto + parte de un puntero). |
| 368 | Si un texto «no aparece», probar **las dos rutas** del renderer (tabla `<$A0` / katakana `>=$A0`). |
| 369 | Un puntero puede no existir como **word**: puede estar partido en dos `LDA #$xx / STA $zp`. |
| 370 | Tras mover un texto, **verificar leyendo desde el puntero**, no desde donde se escribió. |
| **371** | Antes de rellenar hasta el límite de un bloque, **desensamblar el byte del límite**: en hex un opcode y un dato se ven igual. Y el assert que protege ese límite debe **incluir** el byte límite. |

### Traducción

Fidelidad y naturalidad, con **puntos finales**. Sin abreviaturas.
**Momotaro** sin `u` final. **Sólo** con tilde. Staff en orden occidental con
inicial si no cabe (`H. Iizuka`, nunca `IiDuka`). Cargos en MAYÚSCULAS. En
créditos, nombres sin punto final; frases sí.
Finales: Muy difícil / Difícil / Normal / Fácil.

---

## 5. Arrancar en 30 segundos

```python
import sys; sys.path.insert(0, 'tools')
from pce import PCE
import estados, sat

p = PCE('roms/Momotaro Katsugeki (Español).pce')
estados.carga(p, 'states/7_item.state')
p.run(30)
p.png('/tmp/foto.png')              # MIRARLA ENTERA, Y AMPLIADA
p.press('A', frames=3, after=25)    # avanzar diálogo

v = sat.vram(p)
for d in sat.visibles(v):
    print(hex(d['cel']), d['x'], d['y'])
```

### Trampas del emulador (medidas, no supuestas)

- Sin `retro_set_controller_port_device(0,1)` **no llega ningún botón**. Ya
  está en `pce.py`.
- Botón de diálogo = **A**. Menú = **START**.
- **`p.vram()` devuelve 0 bytes**: usar `sat.vram(p)`, que la saca del savestate.
- Los `.state` de David son RZIP (`#RZIPv\x01#` + 16 B + zlib) y el core traga
  desde el offset 16 del descomprimido. `estados.carga()` se encarga.
- **`p.png()` revienta si aún no hay frame**: comprobar `p.frame` antes.
- **Los watchpoints de página cero (`$BF`, `$18`…) NO disparan en Beetle.**
  Usar `log_on()` y rastrear.
- **capstone en modo 65C02 NO sirve**: lee `TAM ($53)` como `nop` y se
  desincroniza. Usar `tools/dis6280.py`.
- Traducir bien el banco: `ROM = banco*0x2000 + (PC & 0x1FFF)`.
- El word 2 del SAT es el patrón **por dos**: `celda = (word2 >> 1) & 0x3FF`.

### Reconstruir cualquier versión desde su IPS

Las ROMs intermedias se borran a propósito. Para recuperar una:

```python
def aplica(base, ips, out):
    d = bytearray(open(base,'rb').read()); p = open(ips,'rb').read()
    assert p[:5] == b'PATCH'
    i = 5
    while p[i:i+3] != b'EOF':
        off = int.from_bytes(p[i:i+3],'big'); i += 3
        ln  = int.from_bytes(p[i:i+2],'big'); i += 2
        if ln == 0:
            rl = int.from_bytes(p[i:i+2],'big'); i += 2
            b = p[i]; i += 1
            d[off:off+rl] = bytes([b])*rl
        else:
            d[off:off+ln] = p[i:i+ln]; i += ln
    open(out,'wb').write(bytes(d))
```

Verificado: los IPS reproducen v385, v386, v388, v390, v391 y v393 byte a byte.

### El toolkit (`tools/`, 52 ficheros)

| Fichero | Para qué |
|---|---|
| `pce.py` | emulador: `run/press/png/ram/poke/peek/state`, `watch`, `log_on`, `mpr`, `rom_off` |
| `sat.py` | `vram()`, `sat()`, `visibles()`, `celda()` |
| `estados.py` | carga los `.state` de David (RZIP) |
| `cg.py` | codec del CG comprimido (`$861F`), round-trip verificado |
| `state.py` | secciones de un savestate |
| `dis6280.py` | desensamblador HuC6280 |
| `password.py` | teclea contraseñas |
| `charset_oficial.py` / `charset_vitores.py` / `charset_rotulos.py` | los tres juegos de caracteres |
| `build_v386.py` … `build_v393.py` | los builds vigentes (`historico/`, los de versiones borradas) |
| `bin/mednafen_pce_libretro.so` | Beetle PCE estándar |
| `bin/mednafen_pce_trace.so` | con watchpoints y log de ejecución |

Recompilar el core (~16 s):
```
git clone --depth 1 https://github.com/libretro/beetle-pce-libretro.git /tmp/bpce
cd /tmp/bpce && make -j2
```
Hooks en `HuC6280::RunSub` (antes de `RdOp(PC)`) y `HuC6280::WrMem`; exportar
símbolos añadiendo `mkt_*;` a `link.T`.

---

## 6. Conocimiento técnico vigente

### Contraseñas y rejilla

Cursor `$3C91` (col) / `$3C92` (fila), buffer `$3C94`. **14 columnas, no 16.**
La fila 2 empieza por **Ñ**. Se acepta con **START**.

```
fila 0  A B C D E F G  a b c d e f g   códigos $01..$0E
fila 1  H I J K L M N  h i j k l m n   códigos $0F..$1C
fila 2  Ñ O P Q R S T  ñ o p q r s t   códigos $1D..$2A
fila 3  U V W X Y Z    u v w x y z     códigos $2B..$36
fila 4      0 1 2 3 4 5 6 7 8 9        códigos $37..$40
```

Muy difícil `wCpeIfP` · Difícil `GoFIBM` · Normal `cJQIep` · Fácil `rGAPad`
Sound test `BqdGlCIWÑI` · Graphics test `BqdGlDWÑI`

### Renderizado de texto: las dos rutas

```
byte >= $A0  ->  ruta KATAKANA: el glifo es el BYTE, directo
byte <  $A0  ->  ruta TABLA:    glifo = tabla[byte-0x30]   (0x43F9B)
```

Si un texto «no aparece» o sale con signos raros, **probar las dos** (norma 368).

### El intérprete de texto (banco `$25`)

```
$793B  LDA $DD / BEQ $799F      cabecera: ¿anidamiento abierto?
$7942  LDA ($DB)                lee el byte del stream
$79B9  SBC #$60 / ASL / tabla $7A13,Y     salto a submensaje
$799F  LDA ($92)                continuación
Punteros de trabajo en pagina cero: $DB/$DC (actual), $DE/$DF (retorno), $DD (nivel)
```

**El código de este banco empieza en `0x4B93B`.** Los textos van por debajo.

### El bocadillo del abuelo (cerrado en v386)

- Identificador **`$368F`**: `2` = abuelo, `1` = aldeano, `0` = resto.
- Listas de sprites: `celda = $170 + byte0`.
  - `0x47C02..0x47C97` lista compartida, 30 registros
  - `0x47C99..0x47CA0` tabla de punteros — **INTOCABLE**
  - `0x47CA1..0x47CFA` lista del abuelo, 18 registros
  - `0x47CFC..0x47FFF` **LIBRE, 772 B**
- El rabillo **no va en la lista**: lo emite `$9A78`, eligiendo entre las 4
  variantes de `$9ADD` según `$368F`.
- Un sprite de 32 px **redondea su celda a par**.

### El menú RUN

```
$3B50  menú abierto     $3B51  nivel activo (0,1,2)   $3BA2  ventana que se dibuja
$D59B  JSR $DFC3   dibuja marco+texto sólo si $3BA2 == $3B51   (cueva v383)
$D3C7  redibujado del AVANCE      $D3E4  JMP $DFD2 (retroceso, cueva v385)
$D304  destino VRAM; tabla en $D320 (ROM 0x19320), 12 entradas
$D268  sube el CG del menú (stream ROM 0x22CA0, ahora en 3 bloques)
$DFE1  cueva del despachador de los 3 bloques (banco $0C, ROM 0x19FE1)
$DFAE  gancho del marco del bocadillo de minijuegos — NO es código muerto
```

### El CG comprimido (`tools/cg.py`)

Descompresor en `$861F` (banco `$20`, ROM `0x4061F`); rutina de byte `$867F`.
Por celda, 4 grupos de 4 llamadas (`Y` = 0, 1, `$10`, `$11`). Cada llamada =
1 byte de máscara + literales; bit a 1 lee literal nuevo, bit a 0 repite el
anterior; escribe 8 bytes en `Y, Y+2, … Y+14`.

Stream del menú en ROM `0x22CA0`: 1 byte de cuenta + datos. Original 58
celdas / 1329 B; ahora 3 bloques (4+4+26) / 755 B.

### Otros hallazgos

- **`$3BA6`** elige tabla de glifos: `0`→`$9CF3`, `1`→`$9CB3`. Con `$3BA6=1`
  el código `$C6` da `$7F` (ú minúscula), no la Ú. **Evitar mayúsculas
  acentuadas en esas pantallas** (Sound Test, entre otras).
- **`$37F8`** = dificultad en los créditos: 0=Fácil … 3=Muy difícil.
  Tabla `$DD07` (ROM `0x03D07`).
- **Fuentes:** diálogo 1bpp en `0x3D660 + glifo*8` (A-Z = `$70`-`$89`);
  menú 2bpp en `0x4000 + (g-$30)*16`, con sombra
  `dilatar(cuerpo,{(+1,0),(0,+1),(+1,+1)}) - cuerpo`.
- **Vocales acentuadas de David** (v379): Á=`$C2` É=`$C3` Í=`$C4` Ó=`$C5`
  Ú=`$C6`.
- **Tres charsets:** `charset_oficial.py` (alias b=$5B c=$5D p=$5E),
  `charset_vitores.py` (motor `$9B0B`, bytes directos), `charset_rotulos.py`
  (motor `$AAB4`). El **Sound Test usa ASCII puro** (A=`$41`).

---

## 7. LO QUE TOCA AHORA — orden fijado por David (2026-08-28)

Textual: *«En unas horas seguiremos con los frames que sobran de los cerezos,
y luego iremos a por la casa mutilada del mapa en la Aldea Kachiyama. Luego ya
veríamos lo del texto de borrar la partida corrupta (que yo no puedo
localizar, pero ya lo hiciste tú), arreglar algunas mutilaciones por exceso de
sprites por línea y, claro, los gráficos que hay que traducir, que no son
muchos y lo haré yo.»*

### 1. ⭐ A-VIT2 — los frames que sobran en los cerezos

Justo antes de que los cerezos aparezcan bien se ven **2-3 frames con
artefactos**, como una transición defectuosa.

**Ya medido:** tiles del árbol incorrectos por frame — la japonesa queda
limpia en el **frame 387**, la nuestra en el **389**. Las copias del TIA
arrancan en el 385 (JP) y en el 387 (nosotros). **v386, v387 y v388 son
idénticas en esos frames**, así que **no lo causó mover el árbol**: es
anterior.

Material: `capturas/bug_vitores/transicion_artefactos_{1,2}.png`,
`states/Vitores.state`, `states/vitores_jp_david.state`.

Siguiente paso sugerido: comparar frame a frame contra la japonesa en la
ventana 380-395 y localizar **quién escribe esas celdas** en los 2 frames de
diferencia. Recordar la norma 365: comparar **bytes** de VRAM, no firmas.

### 2. A-CASA / B1 — casa mutilada en el mapa (Aldea Kachiyama)

Diagnosticado, con dos soluciones ya simuladas sobre el savestate real:

```
ACTUAL                                 pico=16  pierde 6 px del tejado
tejado (i=32) el primero               pico=16  pierde 6 px del sprite 31
borde inferior 32px -> 16px            pico=14  LIMPIO  [DESCARTADO]
mapa (22-34) antes que rótulo (0-21)   pico=16  LIMPIO  <-- la buena
```

Estrechar el borde queda descartado: las dos mitades de cada sprite dibujan.
Queda **reordenar la SAT** para que los sprites del mapa (22-34) se compongan
antes que los del rótulo (0-21): cero píxeles perdidos, porque el descarte
cae entonces en el sprite 20, que en esas filas no dibuja nada.

**BLOQUEO:** la SAT se compone en ejecución; no hay lista estática que editar.
Comprobado que no está en `0x2FBA2` (esas listas usan la celda `$708`) y que
no existe ningún registro `[48 03 8e]` ni `[4c 03 8e]` en toda la ROM.

**Lo que falta:** localizar la rutina que compone la SAT. No se puede por
barrido de bytes: hay que **seguir el código** desde el bucle de dibujado del
mapa, o pedirle a David un breakpoint de escritura en VRAM `$FE00` en Mesen
(`docs/MESEN_como_mirar_la_RAM.md`).

**Ni B1 ni B2 se tocan hasta tener esa rutina.** Escribir a ciegas en la zona
de sprites es lo que costó la v309 (fondo destrozado) y la v293 (título).

### 3. A-BORRA — texto corrupto de borrar la partida guardada

Localizado: **`0x1F79E`, banco `$0F`**, un «¿borrar los datos? HAI / IIE» del
menú de guardado (entrada 293). Es un **segundo** menú HAI/IIE, distinto del
de la password, que sí está traducido.

**Dato de David: él no sabe cómo llegar a esa pantalla jugando.** La localicé
yo en la ROM. Antes de tocar nada hay que **conseguir verla en pantalla**
(norma 353). Dos vías: seguir quién salta a la rutina que lee `0x1F79E`, o
provocarla desde un savestate con la backup RAM ya escrita.

Mirar a la vez la ficha **A6: backup RAM** (`0x1F51E`, 674 B, sin tocar):
probablemente es el mismo bloque de mensajes.

### 4. A-SPR — mutilaciones por exceso de sprites por línea

Casos conocidos: el niño aldeano sin cabeza y las bolas del minijuego.

**Aviso:** una parte **ya existe en la ROM japonesa**. Antes de tocar nada,
comparar el mismo frame contra la virgen; si la japonesa se mutila igual, se
cierra como «del original». Además, la medición antigua decía *«bolas
mutiladas: peor línea 56, con 11 sprites; no llega a 16»* → **en ese caso el
límite duro no era la causa**. Hay que volver a medirlo.

Emparentado con B1 y B2: los tres dependen de la rutina de la SAT.

### 5. A-GRAF — gráficos con texto por traducir. **LOS EDITA DAVID**

Nuestro trabajo es **localizarlos, extraerlos a PNG y pasárselos**, y luego
**reinsertar** lo que devuelva. Nada de editar píxeles por nuestra cuenta.
Si el gráfico está comprimido, escribir su codec y probar el round-trip antes
(norma 355); para el CG ya existe `tools/cg.py`.

### Y sin fecha, en `docs/PENDIENTES.md`

- **A-NOM**: «Raqueta» en singular. «Raquetas» no cabe (comprobado).
  Alternativas de 6 letras: «Nieve», «Calzas», «Zuecos». **Decide David**, que
  ya dijo: *«No es que me convenza, pero si no queda otra, habrá que aceptarlo.»*
- **3 bloques sin traducir en el banco `$25`**: `0x4A484` (53 B, el final),
  `0x4A71F` (154 B, créditos con «HUDSON SOFT»), `0x4AC44` (71 B, baño de mujeres).
- Bug gráfico bajo la cabeza del ogro rosa (final Difícil).
- Tabla `0x24DE` (presentación de enemigos): apunta a offsets japoneses.
- 15 `$00` de relleno en `0x4A476`: páginas fantasma.
- Colas invisibles en las descripciones de objeto.
- Posadero: falta «ogros.». Abuelo: «El perro te acompaña» sin punto final.
- 5 mensajes sueltos del menú (`0x435E6`, `0x4363D`, `0x4366B`, `0x4369C`, `0x436CC`).
- Texto de vítores 4 px por encima del bocadillo (B2).

---

## 8. El workspace

```
COMO_RETOMAR.md              arranque rápido (leer primero)
Momotaro/
  LEEME.md                   normas 12-371 + estado
  investigation.md           diario, 261 entradas
  roms/                      japonesa virgen + oficial + v393
  parches/                   oficial + 12 hitos (v334…v393)
  states/                    57 savestates, todos verificados
  capturas/                  bug_vitores/ · bugs_nuevos/{mesen,mesen2,ppt}/
  docs/                      PENDIENTES.md (registro único), PROMPT_METODO.md,
                             MESEN_como_mirar_la_RAM.md, MAQUETACION_*,
                             QUIZ.md, GUION_para_traducir.md,
                             Log_completo_hasta_v83.txt, este informe
    historico/               informes de etapas cerradas
  tools/                     el toolkit (52 ficheros)
    historico/               los build_* de versiones borradas
Nekketsu/                    proyecto aparte, TERMINADO (v2.18)
                             (rom/*.md es Mega Drive, NO Markdown)
```

### El método (`docs/PROMPT_METODO.md`)

Diario en `investigation.md`. **Las hipótesis falsas NO se borran**: se marcan
`[DESCARTADO]` y se explica por qué fallaron — la 229 corrige a la 228 y las
dos siguen ahí; la 260 corrige a la 258. Una medición → una causa → un arreglo
→ una verificación. Prohibido escribir bytes a ciegas. Cada versión con
MD5/SHA-1/CRC32. Asserts con byte esperado, hueco libre y zonas intactas —
**y que incluyan el byte del límite** (norma 371). IPS contra la virgen con
round-trip. `docs/PENDIENTES.md` es el registro único: si algo no está ahí,
se olvida.
