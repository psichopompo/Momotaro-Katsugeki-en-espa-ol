# Guion de la v198, sin puntos suspensivos

192 paginas, 626 lineas. Sustituciones: `...` -> punto si la frase acaba, coma si sigue en minuscula.

### [0]

- antes: ¡Momotaro! Si pulsas el botón II podrás atacar a los ogros...
- ahora: ¡Momotaro! Si pulsas el botón II podrás atacar a los ogros.

```
+----------------+
|¡Momotaro! Si   |
|pulsas el botón |
|II podrás atacar|
|a los ogros.    |
+----------------+
```

### [1]

- antes: Si compras armas y armaduras, todo se te hará mucho más fácil...
- ahora: Si compras armas y armaduras, todo se te hará mucho más fácil.

```
+----------------+
|Si compras armas|
|y armaduras,    |
|todo se te hará |
|mucho más fácil.|
+----------------+
```

### [3]

- antes: Cuando les des su merecido a los ogros... ¡compra armas, compra armaduras, compra objetos! ¡Wahaha...!
- ahora: Cuando les des su merecido a los ogros. ¡compra armas, compra armaduras, compra objetos! ¡Wahaha!

```
+----------------+
|Cuando les des  |
|su merecido a   |
|los ogros.      |
|¡compra armas,  |
+----------------+
|compra          |
|armaduras,      |
|compra objetos! |
|¡Wahaha!        |
+----------------+
```

### [5]

- antes: El ermitaño vive en lo alto... Deberías pedirle que te enseñe sus artes.
- ahora: El ermitaño vive en lo alto. Deberías pedirle que te enseñe sus artes.

```
+----------------+
|El ermitaño vive|
|en lo alto.     |
|Deberías pedirle|
|que te enseñe   |
+----------------+
|sus artes.      |
+----------------+
```

### [6]

- antes: Si pulsas el botón RUN podrás usar artes y objetos... Claro que, si no tienes ninguno, no podrás usar nada...
- ahora: Si pulsas el botón RUN podrás usar artes y objetos. Claro que, si no tienes ninguno, no podrás usar nada.

```
+----------------+
|Si pulsas el    |
|botón RUN podrás|
|usar artes y    |
|objetos. Claro  |
+----------------+
|que, si no      |
|tienes ninguno, |
|no podrás usar  |
|nada.           |
+----------------+
```

### [7]

- antes: Salta con el botón I y ataca con el botón II... Yo mismo derroté a 1000 ogros de esta manera...
- ahora: Salta con el botón I y ataca con el botón II. Yo mismo derroté a 1000 ogros de esta manera.

```
+----------------+
|Salta con el    |
|botón I y ataca |
|con el botón II.|
|Yo mismo derroté|
+----------------+
|a 1000 ogros de |
|esta manera.    |
+----------------+
```

### [8]

- antes: Haz florecer los cerezos, por favor... ¡Te lo suplico!
- ahora: Haz florecer los cerezos, por favor. ¡Te lo suplico!

```
+----------------+
|Haz florecer los|
|cerezos, por    |
|favor. ¡Te lo   |
|suplico!        |
+----------------+
```

### [9]

- antes: Oh... Qué hermosos están los cerezos... La aldea vuelve a florecer... Muchísimas gracias.
- ahora: Oh, qué hermosos están los cerezos. La aldea vuelve a florecer. Muchísimas gracias.

```
+----------------+
|Oh, qué hermosos|
|están los       |
|cerezos. La     |
|aldea vuelve a  |
+----------------+
|florecer.       |
|Muchísimas      |
|gracias.        |
+----------------+
```

### [10]

- antes: Buaaa... Los ogros marchitaron los cerezos de esta aldea. ¡Con lo bonita que era! Buaaa...
- ahora: Buaaa, los ogros marchitaron los cerezos de esta aldea. ¡Con lo bonita que era! Buaaa.

```
+----------------+
|Buaaa, los ogros|
|marchitaron los |
|cerezos de esta |
|aldea. ¡Con lo  |
+----------------+
|bonita que era! |
|Buaaa.          |
+----------------+
```

### [11]

- antes: Vaya... Qué perro tan fuerte... ¿Sabías que los perros de ahora lanzan bombas de mano?
- ahora: Vaya, qué perro tan fuerte. ¿Sabías que los perros de ahora lanzan bombas de mano?

```
+----------------+
|Vaya, qué perro |
|tan fuerte.     |
|¿Sabías que los |
|perros de ahora |
+----------------+
|lanzan bombas de|
|mano?           |
+----------------+
```

### [12]

- antes: A los ogros que giran sin parar no puedes vencerlos mientras dan vueltas...
- ahora: A los ogros que giran sin parar no puedes vencerlos mientras dan vueltas.

```
+----------------+
|A los ogros que |
|giran sin parar |
|no puedes       |
|vencerlos       |
+----------------+
|mientras dan    |
|vueltas.        |
+----------------+
```

### [13]

- antes: Me he enterado hace poco de que el anciano de los cerezos ha abierto una tienda de objetos para ayudar a Momotaro...
- ahora: Me he enterado hace poco de que el anciano de los cerezos ha abierto una tienda de objetos para ayudar a Momotaro.

```
+----------------+
|Me he enterado  |
|hace poco de que|
|el anciano de   |
|los cerezos ha  |
+----------------+
|abierto una     |
|tienda de       |
|objetos para    |
|ayudar a        |
+----------------+
|Momotaro.       |
+----------------+
```

### [14]

- antes: Que quede entre nosotros... El punto débil del jefe es la diana que lleva en el cuerpo. Que quede entre nosotros... ¡No se lo cuentes a nadie!
- ahora: Que quede entre nosotros. El punto débil del jefe es la diana que lleva en el cuerpo. Que quede entre nosotros. ¡No se lo cuentes a nadie!

```
+----------------+
|Que quede entre |
|nosotros. El    |
|punto débil del |
|jefe es la diana|
+----------------+
|que lleva en el |
|cuerpo. Que     |
|quede entre     |
|nosotros. ¡No se|
+----------------+
|lo cuentes a    |
|nadie!          |
+----------------+
```

### [15]

- antes: Dicen que los cerezos son preciosos, pero en esta aldea florecieron antes de que yo naciera...
- ahora: Dicen que los cerezos son preciosos, pero en esta aldea florecieron antes de que yo naciera.

```
+----------------+
|Dicen que los   |
|cerezos son     |
|preciosos, pero |
|en esta aldea   |
+----------------+
|florecieron     |
|antes de que yo |
|naciera.        |
+----------------+
```

### [16]

- antes: ¿Así que estos son los cerezos...? Qué bonitos son... Al mirar estas flores el corazón se llena de alegría...
- ahora: ¿Así que estos son los cerezos? Qué bonitos son. Al mirar estas flores el corazón se llena de alegría.

```
+----------------+
|¿Así que estos  |
|son los cerezos?|
|Qué bonitos son.|
|Al mirar estas  |
+----------------+
|flores el       |
|corazón se llena|
|de alegría.     |
+----------------+
```

### [18]

- antes: Ce-re-zos, ce-re-zos... Muchísimas gracias. Parece que la aldea ha recuperado la alegría de antaño... De verdad, gracias...
- ahora: Ce-re-zos, ce-re-zos. Muchísimas gracias. Parece que la aldea ha recuperado la alegría de antaño. De verdad, gracias.

```
+----------------+
|Ce-re-zos,      |
|ce-re-zos.      |
|Muchísimas      |
|gracias. Parece |
+----------------+
|que la aldea ha |
|recuperado la   |
|alegría de      |
|antaño. De      |
+----------------+
|verdad, gracias.|
+----------------+
```

### [19]

- antes: Ésta es la aldea de Kintaro, al pie del monte Ashigara...
- ahora: Ésta es la aldea de Kintaro, al pie del monte Ashigara.

```
+----------------+
|Ésta es la aldea|
|de Kintaro, al  |
|pie del monte   |
|Ashigara.       |
+----------------+
```

### [20]

- antes: Por culpa de los caramelos Kintaro gigantes que caen del monte Ashigara no se pueden cosechar los cultivos... Tampoco se puede andar por fuera... ¡Esto es llover sobre mojado!
- ahora: Por culpa de los caramelos Kintaro gigantes que caen del monte Ashigara no se pueden cosechar los cultivos. Tampoco se puede andar por fuera. ¡Esto es llover sobre mojado!

```
+----------------+
|Por culpa de los|
|caramelos       |
|Kintaro gigantes|
|que caen del    |
+----------------+
|monte Ashigara  |
|no se pueden    |
|cosechar los    |
|cultivos.       |
+----------------+
|Tampoco se puede|
|andar por fuera.|
|¡Esto es llover |
|sobre mojado!   |
+----------------+
```

### [21]

- antes: ¿Has acabado con los ogros...? Gracias a ti esta aldea ha vuelto a vivir en paz como antaño... De verdad, muchas gracias...
- ahora: ¿Has acabado con los ogros? Gracias a ti esta aldea ha vuelto a vivir en paz como antaño. De verdad, muchas gracias.

```
+----------------+
|¿Has acabado con|
|los ogros?      |
|Gracias a ti    |
|esta aldea ha   |
+----------------+
|vuelto a vivir  |
|en paz como     |
|antaño. De      |
|verdad, muchas  |
+----------------+
|gracias.        |
+----------------+
```

### [22]

- antes: ¿Caramelos de Kintaro...? ¿Nadie quiere caramelos ...? Buaaa... Con tanto caramelo tirado por ahí, mi negocio se ha ido a pique.
- ahora: ¿Caramelos de Kintaro? ¿Nadie quiere caramelos? Buaaa, con tanto caramelo tirado por ahí, mi negocio se ha ido a pique.

```
+----------------+
|¿Caramelos de   |
|Kintaro? ¿Nadie |
|quiere          |
|caramelos?      |
+----------------+
|Buaaa, con tanto|
|caramelo tirado |
|por ahí, mi     |
|negocio se ha   |
+----------------+
|ido a pique.    |
+----------------+
```

### [23]

- antes: ¡Caramelos de Kintaro! ¡Caramelos de Kintaro! Ja, ja, ja... Gracias a que acabaste con los ogros, mi negocio va viento en popa...
- ahora: ¡Caramelos de Kintaro! ¡Caramelos de Kintaro! Ja, ja, ja. Gracias a que acabaste con los ogros, mi negocio va viento en popa.

```
+----------------+
|¡Caramelos de   |
|Kintaro!        |
|¡Caramelos de   |
|Kintaro! Ja, ja,|
+----------------+
|ja. Gracias a   |
|que acabaste con|
|los ogros, mi   |
|negocio va      |
+----------------+
|viento en popa. |
+----------------+
```

### [24]

- antes: Dicen que los ogros han puesto muchas escaleras en el monte Ashigara y arrojan cosas a los viajeros que intentan subir a la cima...
- ahora: Dicen que los ogros han puesto muchas escaleras en el monte Ashigara y arrojan cosas a los viajeros que intentan subir a la cima.

```
+----------------+
|Dicen que los   |
|ogros han puesto|
|muchas escaleras|
|en el monte     |
+----------------+
|Ashigara y      |
|arrojan cosas a |
|los viajeros que|
|intentan subir a|
+----------------+
|la cima.        |
+----------------+
```

### [25]

- antes: ¿Dices que has acabado con los ogros...? Ay, de verdad, cuánto te lo agradezco...
- ahora: ¿Dices que has acabado con los ogros? Ay, de verdad, cuánto te lo agradezco.

```
+----------------+
|¿Dices que has  |
|acabado con los |
|ogros? Ay, de   |
|verdad, cuánto  |
+----------------+
|te lo agradezco.|
+----------------+
```

### [27]

- antes: Para conmemorar vuestra hazaña, todos los vecinos hemos decidido fabricar a partir de ahora caramelos Momotaro...
- ahora: Para conmemorar vuestra hazaña, todos los vecinos hemos decidido fabricar a partir de ahora caramelos Momotaro.

```
+----------------+
|Para conmemorar |
|vuestra hazaña, |
|todos los       |
|vecinos hemos   |
+----------------+
|decidido        |
|fabricar a      |
|partir de ahora |
|caramelos       |
+----------------+
|Momotaro.       |
+----------------+
```

### [28]

- antes: Poder comer caramelos a montones está muy bien, pero papá y mamá lloran porque no hay negocio...
- ahora: Poder comer caramelos a montones está muy bien, pero papá y mamá lloran porque no hay negocio.

```
+----------------+
|Poder comer     |
|caramelos a     |
|montones está   |
|muy bien, pero  |
+----------------+
|papá y mamá     |
|lloran porque no|
|hay negocio.    |
+----------------+
```

### [29]

- antes: Oye, oye... ¿Sabías que con el faisán puedes volar libre por el cielo?
- ahora: Oye, oye. ¿Sabías que con el faisán puedes volar libre por el cielo?

```
+----------------+
|Oye, oye.       |
|¿Sabías que con |
|el faisán puedes|
|volar libre por |
+----------------+
|el cielo?       |
+----------------+
```

### [31]

- antes: ¿Vaya? ¿Llevas contigo al mono? Dicen que los monos siempre han sido buenos imitando... ¿Qué tal se le dará a ése?
- ahora: ¿Vaya? ¿Llevas contigo al mono? Dicen que los monos siempre han sido buenos imitando. ¿Qué tal se le dará a ése?

```
+----------------+
|¿Vaya? ¿Llevas  |
|contigo al mono?|
|Dicen que los   |
|monos siempre   |
+----------------+
|han sido buenos |
|imitando. ¿Qué  |
|tal se le dará a|
|ése?            |
+----------------+
```

### [33]

- antes: Donde el suelo está helado, resbala y cuesta andar... Ve con cuidado...
- ahora: Donde el suelo está helado, resbala y cuesta andar. Ve con cuidado.

```
+----------------+
|Donde el suelo  |
|está helado,    |
|resbala y cuesta|
|andar. Ve con   |
+----------------+
|cuidado.        |
+----------------+
```

### [34]

- antes: Te daré un buen consejo... Por aquí conviene calzarse unas raquetas... Las venden en esa tienda de objetos.
- ahora: Te daré un buen consejo. Por aquí conviene calzarse unas raquetas. Las venden en esa tienda de objetos.

```
+----------------+
|Te daré un buen |
|consejo. Por    |
|aquí conviene   |
|calzarse unas   |
+----------------+
|raquetas. Las   |
|venden en esa   |
|tienda de       |
|objetos.        |
+----------------+
```

### [35]

- antes: Qué frío... Desde que llegaron los ogros hace aún más frío por aquí. Los niños son inocentes y no lo notan... pero a los viejos el frío nos puede.
- ahora: Qué frío. Desde que llegaron los ogros hace aún más frío por aquí. Los niños son inocentes y no lo notan, pero a los viejos el frío nos puede.

```
+----------------+
|Qué frío. Desde |
|que llegaron los|
|ogros hace aún  |
|más frío por    |
+----------------+
|aquí. Los niños |
|son inocentes y |
|no lo notan,    |
|pero a los      |
+----------------+
|viejos el frío  |
|nos puede.      |
+----------------+
```

### [36]

- antes: Qué frío... Qué helada... Gracias a que acabaste con los ogros ahora se está algo más templado. De verdad, muchísimas gracias.
- ahora: Qué frío. Qué helada. Gracias a que acabaste con los ogros ahora se está algo más templado. De verdad, muchísimas gracias.

```
+----------------+
|Qué frío. Qué   |
|helada. Gracias |
|a que acabaste  |
|con los ogros   |
+----------------+
|ahora se está   |
|algo más        |
|templado. De    |
|verdad,         |
+----------------+
|muchísimas      |
|gracias.        |
+----------------+
```

### [37]

- antes: Momotaro, acaba con los ogros, por favor... La abuela ya no aguanta el frío. Te lo suplico, acaba con ellos.
- ahora: Momotaro, acaba con los ogros, por favor. La abuela ya no aguanta el frío. Te lo suplico, acaba con ellos.

```
+----------------+
|Momotaro, acaba |
|con los ogros,  |
|por favor. La   |
|abuela ya no    |
+----------------+
|aguanta el frío.|
|Te lo suplico,  |
|acaba con ellos.|
+----------------+
```

### [38]

- antes: Momotaro, gracias a ti la abuela parece estar un poco mejor. Muchísimas gracias...
- ahora: Momotaro, gracias a ti la abuela parece estar un poco mejor. Muchísimas gracias.

```
+----------------+
|Momotaro,       |
|gracias a ti la |
|abuela parece   |
|estar un poco   |
+----------------+
|mejor.          |
|Muchísimas      |
|gracias.        |
+----------------+
```

### [40]

- antes: Yo, de joven, era buceadora y recogía caracolas en el mar. De lo que hay bajo el agua sé un rato...
- ahora: Yo, de joven, era buceadora y recogía caracolas en el mar. De lo que hay bajo el agua sé un rato.

```
+----------------+
|Yo, de joven,   |
|era buceadora y |
|recogía         |
|caracolas en el |
+----------------+
|mar. De lo que  |
|hay bajo el agua|
|sé un rato.     |
+----------------+
```

### [41]

- antes: ¿Conoces las aletas de kappa? Con ellas se nada libremente bajo el agua. Las tienen en la tienda de objetos, más te vale comprarlas ...
- ahora: ¿Conoces las aletas de kappa? Con ellas se nada libremente bajo el agua. Las tienen en la tienda de objetos, más te vale comprarlas.

```
+----------------+
|¿Conoces las    |
|aletas de kappa?|
|Con ellas se    |
|nada libremente |
+----------------+
|bajo el agua.   |
|Las tienen en la|
|tienda de       |
|objetos, más te |
+----------------+
|vale comprarlas.|
+----------------+
```

### [42]

- antes: Dicen que sin el caparazón de tortuga no se puede uno sumergir en el mar... Pero ¿cómo se consigue?
- ahora: Dicen que sin el caparazón de tortuga no se puede uno sumergir en el mar. Pero ¿cómo se consigue?

```
+----------------+
|Dicen que sin el|
|caparazón de    |
|tortuga no se   |
|puede uno       |
+----------------+
|sumergir en el  |
|mar. Pero ¿cómo |
|se consigue?    |
+----------------+
```

### [43]

- antes: Dicen que si salvas a una tortuga te presta su caparazón... Yo también quiero salvar una y bajar al fondo del mar.
- ahora: Dicen que si salvas a una tortuga te presta su caparazón. Yo también quiero salvar una y bajar al fondo del mar.

```
+----------------+
|Dicen que si    |
|salvas a una    |
|tortuga te      |
|presta su       |
+----------------+
|caparazón. Yo   |
|también quiero  |
|salvar una y    |
|bajar al fondo  |
+----------------+
|del mar.        |
+----------------+
```

### [45]

- antes: Bendito seas... La paz ha vuelto al mar... Todo gracias a ti...
- ahora: Bendito seas. La paz ha vuelto al mar. Todo gracias a ti.

```
+----------------+
|Bendito seas. La|
|paz ha vuelto al|
|mar. Todo       |
|gracias a ti.   |
+----------------+
```

### [46]

- antes: El mar se ha embravecido y no podemos salir a faenar... Como siga así acabaremos muriéndonos ... ¿Qué podemos hacer?
- ahora: El mar se ha embravecido y no podemos salir a faenar. Como siga así acabaremos muriéndonos. ¿Qué podemos hacer?

```
+----------------+
|El mar se ha    |
|embravecido y no|
|podemos salir a |
|faenar. Como    |
+----------------+
|siga así        |
|acabaremos      |
|muriéndonos.    |
|¿Qué podemos    |
+----------------+
|hacer?          |
+----------------+
```

### [47]

- antes: Oh... El mar ha vuelto a su ser... Y también es gracias a ti... De verdad, muchísimas gracias.
- ahora: Oh, el mar ha vuelto a su ser. Y también es gracias a ti. De verdad, muchísimas gracias.

```
+----------------+
|Oh, el mar ha   |
|vuelto a su ser.|
|Y también es    |
|gracias a ti. De|
+----------------+
|verdad,         |
|muchísimas      |
|gracias.        |
+----------------+
```

### [48]

- antes: Si te ves en apuros, súbete al faisán y asciende. Lo dijo el autor del juego, así que es verdad...
- ahora: Si te ves en apuros, súbete al faisán y asciende. Lo dijo el autor del juego, así que es verdad.

```
+----------------+
|Si te ves en    |
|apuros, súbete  |
|al faisán y     |
|asciende. Lo    |
+----------------+
|dijo el autor   |
|del juego, así  |
|que es verdad.  |
+----------------+
```

### [49]

- antes: Del monte Kachikachi salen volando chispas, es peligrosísi- mo. Ten cuidado tú también, chaval. Si te alcanzan, el daño es grande...
- ahora: Del monte Kachikachi salen volando chispas, es peligrosísimo. Ten cuidado tú también, chaval. Si te alcanzan, el daño es grande.

```
+----------------+
|Del monte       |
|Kachikachi salen|
|volando chispas,|
|es              |
+----------------+
|peligrosísimo.  |
|Ten cuidado tú  |
|también, chaval.|
|Si te alcanzan, |
+----------------+
|el daño es      |
|grande.         |
+----------------+
```

### [50]

- antes: Ay... qué calor... ¿Y si me quito el kimono de una vez? ...... ¿Qué miras tú?
- ahora: Ay, qué calor. ¿Y si me quito el kimono de una vez? ¿Qué miras tú?

```
+----------------+
|Ay, qué calor.  |
|¿Y si me quito  |
|el kimono de una|
|vez? ¿Qué miras |
+----------------+
|tú?             |
+----------------+
```

### [52]

- antes: Si caes en la lava recibirás daño... Lo que está anaranjado es lava... Ándate con mucho ojo...
- ahora: Si caes en la lava recibirás daño. Lo que está anaranjado es lava. Ándate con mucho ojo.

```
+----------------+
|Si caes en la   |
|lava recibirás  |
|daño. Lo que    |
|está anaranjado |
+----------------+
|es lava. Ándate |
|con mucho ojo.  |
+----------------+
```

### [53]

- antes: Por culpa de los ogros ya no podemos acercarnos al monte. Y las aguas termales del Kachikachi eran nuestro único placer...
- ahora: Por culpa de los ogros ya no podemos acercarnos al monte. Y las aguas termales del Kachikachi eran nuestro único placer.

```
+----------------+
|Por culpa de los|
|ogros ya no     |
|podemos         |
|acercarnos al   |
+----------------+
|monte. Y las    |
|aguas termales  |
|del Kachikachi  |
|eran nuestro    |
+----------------+
|único placer.   |
+----------------+
```

### [54]

- antes: Gracias a ti podemos volver a las termas del Kachikachi ... Mi mujer y yo seguiremos bañándonos juntos y viviremos en paz...
- ahora: Gracias a ti podemos volver a las termas del Kachikachi. Mi mujer y yo seguiremos bañándonos juntos y viviremos en paz.

```
+----------------+
|Gracias a ti    |
|podemos volver a|
|las termas del  |
|Kachikachi. Mi  |
+----------------+
|mujer y yo      |
|seguiremos      |
|bañándonos      |
|juntos y        |
+----------------+
|viviremos en    |
|paz.            |
+----------------+
```

### [55]

- antes: Sí, sí, abuelo, ya te oigo. Aunque no lo parezca, yo fui Miss Calabaza en mis tiempos. Hoy también hace buen día...
- ahora: Sí, sí, abuelo, ya te oigo. Aunque no lo parezca, yo fui Miss Calabaza en mis tiempos. Hoy también hace buen día.

```
+----------------+
|Sí, sí, abuelo, |
|ya te oigo.     |
|Aunque no lo    |
|parezca, yo fui |
+----------------+
|Miss Calabaza en|
|mis tiempos. Hoy|
|también hace    |
|buen día.       |
+----------------+
```

### [56]

- antes: Sí, sí, abuelo, ya te oigo. Aunque no lo parezca, la calabaza era mi comida favorita. Hoy también hace buen día...
- ahora: Sí, sí, abuelo, ya te oigo. Aunque no lo parezca, la calabaza era mi comida favorita. Hoy también hace buen día.

```
+----------------+
|Sí, sí, abuelo, |
|ya te oigo.     |
|Aunque no lo    |
|parezca, la     |
+----------------+
|calabaza era mi |
|comida favorita.|
|Hoy también hace|
|buen día.       |
+----------------+
```

### [57]

- antes: En las termas del Kachikachi, si te subes encima cuando brota el agua, te lleva hasta muy alto... Cuando no había ogros jugábamos mucho.
- ahora: En las termas del Kachikachi, si te subes encima cuando brota el agua, te lleva hasta muy alto. Cuando no había ogros jugábamos mucho.

```
+----------------+
|En las termas   |
|del Kachikachi, |
|si te subes     |
|encima cuando   |
+----------------+
|brota el agua,  |
|te lleva hasta  |
|muy alto. Cuando|
|no había ogros  |
+----------------+
|jugábamos mucho.|
+----------------+
```

### [58]

- antes: ¡Bien! Ahora podremos jugar en las termas como antes... ¡Gracias, Momotaro!
- ahora: ¡Bien! Ahora podremos jugar en las termas como antes. ¡Gracias, Momotaro!

```
+----------------+
|¡Bien! Ahora    |
|podremos jugar  |
|en las termas   |
|como antes.     |
+----------------+
|¡Gracias,       |
|Momotaro!       |
+----------------+
```

### [61]

- antes: Ese ogro enorme de las afueras... Si despierta volverá a arrasar la aldea... Del miedo no pego ojo por las noches.
- ahora: Ese ogro enorme de las afueras. Si despierta volverá a arrasar la aldea. Del miedo no pego ojo por las noches.

```
+----------------+
|Ese ogro enorme |
|de las afueras. |
|Si despierta    |
|volverá a       |
+----------------+
|arrasar la      |
|aldea. Del miedo|
|no pego ojo por |
|las noches.     |
+----------------+
```

### [62]

- antes: Ay, de verdad, muchísimas gracias... Ahora podré dormir a pierna suelta. Para un viejo, dormir es el mayor placer. De verdad, gracias...
- ahora: Ay, de verdad, muchísimas gracias. Ahora podré dormir a pierna suelta. Para un viejo, dormir es el mayor placer. De verdad, gracias.

```
+----------------+
|Ay, de verdad,  |
|muchísimas      |
|gracias. Ahora  |
|podré dormir a  |
+----------------+
|pierna suelta.  |
|Para un viejo,  |
|dormir es el    |
|mayor placer. De|
+----------------+
|verdad, gracias.|
+----------------+
```

### [63]

- antes: Por culpa de ese ogro no podemos jugar a voces... Y jugar bajito no tiene ninguna gracia.
- ahora: Por culpa de ese ogro no podemos jugar a voces. Y jugar bajito no tiene ninguna gracia.

```
+----------------+
|Por culpa de ese|
|ogro no podemos |
|jugar a voces. Y|
|jugar bajito no |
+----------------+
|tiene ninguna   |
|gracia.         |
+----------------+
```

### [65]

- antes: Ese ogro que duerme ahí fuera... Dicen que se hizo enorme con el mazo mágico... Y que desde entonces lleva todo el tiempo dormido ahí.
- ahora: Ese ogro que duerme ahí fuera. Dicen que se hizo enorme con el mazo mágico. Y que desde entonces lleva todo el tiempo dormido ahí.

```
+----------------+
|Ese ogro que    |
|duerme ahí      |
|fuera. Dicen que|
|se hizo enorme  |
+----------------+
|con el mazo     |
|mágico. Y que   |
|desde entonces  |
|lleva todo el   |
+----------------+
|tiempo dormido  |
|ahí.            |
+----------------+
```

### [66]

- antes: ¡Bravo! Derrotar a semejante ogro... Digno del mejor de Japón, Momotaro. A ese ogro de piedra lo usaremos para pasar.
- ahora: ¡Bravo! Derrotar a semejante ogro. Digno del mejor de Japón, Momotaro. A ese ogro de piedra lo usaremos para pasar.

```
+----------------+
|¡Bravo! Derrotar|
|a semejante     |
|ogro. Digno del |
|mejor de Japón, |
+----------------+
|Momotaro. A ese |
|ogro de piedra  |
|lo usaremos para|
|pasar.          |
+----------------+
```

### [67]

- antes: Para derrotar a ese ogro no queda más que entrar por su boca y armarla dentro. Pero dicen que en sus tripas hay muchos ogros temibles...
- ahora: Para derrotar a ese ogro no queda más que entrar por su boca y armarla dentro. Pero dicen que en sus tripas hay muchos ogros temibles.

```
+----------------+
|Para derrotar a |
|ese ogro no     |
|queda más que   |
|entrar por su   |
+----------------+
|boca y armarla  |
|dentro. Pero    |
|dicen que en sus|
|tripas hay      |
+----------------+
|muchos ogros    |
|temibles.       |
+----------------+
```

### [68]

- antes: ¡Cómo! ¿Tú has vencido a ese ogro...? Qué gran valor escondido en un cuerpo tan pequeño... Me quito el sombrero.
- ahora: ¡Cómo! ¿Tú has vencido a ese ogro? Qué gran valor escondido en un cuerpo tan pequeño. Me quito el sombrero.

```
+----------------+
|¡Cómo! ¿Tú has  |
|vencido a ese   |
|ogro? Qué gran  |
|valor escondido |
+----------------+
|en un cuerpo tan|
|pequeño. Me     |
|quito el        |
|sombrero.       |
+----------------+
```

### [69]

- antes: Dicen que en el estómago del ogro el techo y el suelo son una trampa entera... Meterse ahí es una temeridad...
- ahora: Dicen que en el estómago del ogro el techo y el suelo son una trampa entera. Meterse ahí es una temeridad.

```
+----------------+
|Dicen que en el |
|estómago del    |
|ogro el techo y |
|el suelo son una|
+----------------+
|trampa entera.  |
|Meterse ahí es  |
|una temeridad.  |
+----------------+
```

### [70]

- antes: Vaya... ¿Estás sano y salvo? Increíble... Eres un joven de verdadero valor.
- ahora: Vaya, ¿Estás sano y salvo? Increíble. Eres un joven de verdadero valor.

```
+----------------+
|Vaya, ¿Estás    |
|sano y salvo?   |
|Increíble. Eres |
|un joven de     |
+----------------+
|verdadero valor.|
+----------------+
```

### [72]

- antes: La princesa Kaguya ha aprendido hace poco a... ¡apostar! Dicen que anda probando suerte por todas partes. ¿Y si lo intento yo también?
- ahora: La princesa Kaguya ha aprendido hace poco a. ¡apostar! Dicen que anda probando suerte por todas partes. ¿Y si lo intento yo también?

```
+----------------+
|La princesa     |
|Kaguya ha       |
|aprendido hace  |
|poco a.         |
+----------------+
|¡apostar! Dicen |
|que anda        |
|probando suerte |
|por todas       |
+----------------+
|partes. ¿Y si lo|
|intento yo      |
|también?        |
+----------------+
```

### [73]

- antes: Dicen que sobre las nubes hay un mundo donde viven los ogros... Nosotros jamás podríamos llegar...
- ahora: Dicen que sobre las nubes hay un mundo donde viven los ogros. Nosotros jamás podríamos llegar.

```
+----------------+
|Dicen que sobre |
|las nubes hay un|
|mundo donde     |
|viven los ogros.|
+----------------+
|Nosotros jamás  |
|podríamos       |
|llegar.         |
+----------------+
```

### [74]

- antes: ¡Huyyy! ¿Que has subido sobre las nubes y has acabado con los ogros...? Menudo tipo estás hecho...
- ahora: ¡Huyyy! ¿Que has subido sobre las nubes y has acabado con los ogros? Menudo tipo estás hecho.

```
+----------------+
|¡Huyyy! ¿Que has|
|subido sobre las|
|nubes y has     |
|acabado con los |
+----------------+
|ogros? Menudo   |
|tipo estás      |
|hecho.          |
+----------------+
```

### [75]

- antes: A los ogros no sólo hay que castigarlos: a veces conviene aprovecha- rlos. Sobre todo a los del taparrabos ... ¡Ja, ja, ja!
- ahora: A los ogros no sólo hay que castigarlos: a veces conviene aprovecharlos. Sobre todo a los del taparrabos. ¡Ja, ja, ja!

```
+----------------+
|A los ogros no  |
|sólo hay que    |
|castigarlos: a  |
|veces conviene  |
+----------------+
|aprovecharlos.  |
|Sobre todo a los|
|del taparrabos. |
|¡Ja, ja, ja!    |
+----------------+
```

### [77]

- antes: La abuela ha vuelto en sí, y también es gracias a ti... Je, je, ¡gracias!
- ahora: La abuela ha vuelto en sí, y también es gracias a ti. Je, je, ¡gracias!

```
+----------------+
|La abuela ha    |
|vuelto en sí, y |
|también es      |
|gracias a ti.   |
+----------------+
|Je, je,         |
|¡gracias!       |
+----------------+
```

### [78]

- antes: Oh, señor Fuujin, señor Fuujin... Nuestro dios protector... Siempre nos vela desde el cielo... Cuánto se lo agradecemos. Namu Amida Butsu, Namu Amida Butsu.
- ahora: Oh, señor Fuujin, señor Fuujin. Nuestro dios protector. Siempre nos vela desde el cielo. Cuánto se lo agradecemos. Namu Amida Butsu, Namu Amida Butsu.

```
+----------------+
|Oh, señor       |
|Fuujin, señor   |
|Fuujin. Nuestro |
|dios protector. |
+----------------+
|Siempre nos vela|
|desde el cielo. |
|Cuánto se lo    |
|agradecemos.    |
+----------------+
|Namu Amida      |
|Butsu, Namu     |
|Amida Butsu.    |
+----------------+
```

### [79]

- antes: ¿Qué he estado haciendo yo hasta ahora...? Pero si sigo sano y salvo es gracias a Buda. Namu Amida Butsu, Namu Amida Butsu.
- ahora: ¿Qué he estado haciendo yo hasta ahora? Pero si sigo sano y salvo es gracias a Buda. Namu Amida Butsu, Namu Amida Butsu.

```
+----------------+
|¿Qué he estado  |
|haciendo yo     |
|hasta ahora?    |
|Pero si sigo    |
+----------------+
|sano y salvo es |
|gracias a Buda. |
|Namu Amida      |
|Butsu, Namu     |
+----------------+
|Amida Butsu.    |
+----------------+
```

### [80]

- antes: Momotaro, ya sólo podemos confiar en ti... Derrota a Enma con tu fuerza, te lo suplicamos ...
- ahora: Momotaro, ya sólo podemos confiar en ti. Derrota a Enma con tu fuerza, te lo suplicamos.

```
+----------------+
|Momotaro, ya    |
|sólo podemos    |
|confiar en ti.  |
|Derrota a Enma  |
+----------------+
|con tu fuerza,  |
|te lo           |
|suplicamos.     |
+----------------+
```

### [81]

- antes: No puedo más... Ya no lo aguanto... Viviendo en un sitio así uno acaba perdiendo la cabeza.
- ahora: No puedo más. Ya no lo aguanto. Viviendo en un sitio así uno acaba perdiendo la cabeza.

```
+----------------+
|No puedo más. Ya|
|no lo aguanto.  |
|Viviendo en un  |
|sitio así uno   |
+----------------+
|acaba perdiendo |
|la cabeza.      |
+----------------+
```

### [82]

- antes: Momotaro, sabía que llegarías hasta aquí... Bien vale la pena vivir muchos años.
- ahora: Momotaro, sabía que llegarías hasta aquí. Bien vale la pena vivir muchos años.

```
+----------------+
|Momotaro, sabía |
|que llegarías   |
|hasta aquí. Bien|
|vale la pena    |
+----------------+
|vivir muchos    |
|años.           |
+----------------+
```

### [83]

- antes: Mi espada se partió y se me acabaron las flechas. Enma es terribleme- nte fuerte... Si sigues adelante solo perderás la vida en vano. Si no quieres morir, no avances más.
- ahora: Mi espada se partió y se me acabaron las flechas. Enma es terriblemente fuerte. Si sigues adelante solo perderás la vida en vano. Si no quieres morir, no avances más.

```
+----------------+
|Mi espada se    |
|partió y se me  |
|acabaron las    |
|flechas. Enma es|
+----------------+
|terriblemente   |
|fuerte. Si      |
|sigues adelante |
|solo perderás la|
+----------------+
|vida en vano. Si|
|no quieres      |
|morir, no       |
|avances más.    |
+----------------+
```

### [84]

- antes: Mi padre fue a enfrentarse a Enma y nunca volvió... Momotaro, venga a mi padre... Te lo pido, también por toda la aldea... ¡Mucho ánimo, Momotaro!
- ahora: Mi padre fue a enfrentarse a Enma y nunca volvió. Momotaro, venga a mi padre. Te lo pido, también por toda la aldea. ¡Mucho ánimo, Momotaro!

```
+----------------+
|Mi padre fue a  |
|enfrentarse a   |
|Enma y nunca    |
|volvió.         |
+----------------+
|Momotaro, venga |
|a mi padre. Te  |
|lo pido, también|
|por toda la     |
+----------------+
|aldea. ¡Mucho   |
|ánimo, Momotaro!|
+----------------+
```

### [85]

- antes: Tras muchos años de estudio, el punto débil de Enma resultó ser, como imaginaba, la diana. La diana está dentro de su boca... Pero eso sólo sirve si logras llegar hasta él.
- ahora: Tras muchos años de estudio, el punto débil de Enma resultó ser, como imaginaba, la diana. La diana está dentro de su boca. Pero eso sólo sirve si logras llegar hasta él.

```
+----------------+
|Tras muchos años|
|de estudio, el  |
|punto débil de  |
|Enma resultó    |
+----------------+
|ser, como       |
|imaginaba, la   |
|diana. La diana |
|está dentro de  |
+----------------+
|su boca. Pero   |
|eso sólo sirve  |
|si logras llegar|
|hasta él.       |
+----------------+
```

### [86]

- antes: Casi todos los aldeanos han huido ya... Momotaro... Las esperanzas de todos están puestas en ti... Castiga a Enma y trae la paz al mundo. Ve... Momotaro...
- ahora: Casi todos los aldeanos han huido ya. Momotaro, las esperanzas de todos están puestas en ti. Castiga a Enma y trae la paz al mundo. Ve. Momotaro.

```
+----------------+
|Casi todos los  |
|aldeanos han    |
|huido ya.       |
|Momotaro, las   |
+----------------+
|esperanzas de   |
|todos están     |
|puestas en ti.  |
|Castiga a Enma y|
+----------------+
|trae la paz al  |
|mundo. Ve.      |
|Momotaro.       |
+----------------+
```

