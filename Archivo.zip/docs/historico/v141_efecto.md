# v141 — el sonido cuádruple y el bloque negro

`test_efecto_v141.pce` — MD5 `d6c9cbf7a54b602564e7a19a92c56230`

**Tenías razón en las dos cosas: es el mismo fallo, y viene de la v125.**

---

## Qué es el byte `$F0`

Hay **dos** despachadores de texto distintos en el juego. El de los niveles
ocultos sólo entiende `$00 $FF $FE $FD $FC`. Pero la escena de los padres
pasa por otro, en `$A1DE`, que además reconoce:

```
CMP #$F0 / JMP $C2B7
```

`$F0` dispara el efecto de **«obtienes un objeto»**: el sonido *y* la
animación de sprites que sube por la pantalla.

Por eso no lo había visto antes: analicé el motor equivocado.

---

## El fallo

El japonés pone el efecto **sólo donde Momotaro recibe algo**:

| | página | efecto |
|---|---|---|
| 1 | «Momotaro, para vencer a los ogros necesitas dinero» | — |
| 2 | «Momotaro consigue ### ryos» | **sí** |
| 3 | «Llévate también un kibidango» | — |
| 4 | «Momotaro consigue un kibidango» | **sí** |
| 5 | «Momotaro, esfuérzate por el bien de todos» | — |

**Dos** efectos. El nuestro tenía **cuatro**: uno en cada página.

Al reconstruir el bloque en la v125 se tomó `F0 FC` como si fuera el
separador de página y se repitió en todas. No lo es: **`$FC` es el salto de
página, `$F0` es un efecto** que casualmente aparecía antes de dos de ellos.

De ahí salen tus dos síntomas de golpe:

- **El sonido suena 4 veces** en vez de 2.
- **El bloque negro**: el efecto se dispara donde no toca y sus sprites se
  meten encima del bocadillo. En tu state están en los índices 43-46, con
  patrones `$0352`/`$0356` y **paletas 2 y 4** — distintas de la paleta 14
  del bocadillo, por eso se ve un rectángulo de color ajeno. Y salen
  **duplicados** (43=45, 44=46), justo lo que cabe esperar si se dispara de
  más.

Así que tu sospecha de que el bloque negro y el sonido eran la misma cosa
era correcta.

---

## Un detalle extra

Comparando byte a byte encontré que el japonés escribe siempre

```
F0 00 FC        efecto, salto de línea, fin de página
```

y nosotros escribíamos `F0 FC`, sin el salto. Reproducido el patrón entero.
El bloque queda en 196 bytes de 196: encaja clavado.

---

## Verificado

```
                      japonés   v140      v141
bytes $F0                2        4         2
páginas con efecto     [2,4]  [1,2,3,4]   [2,4]
secuencia F0 00 FC       2        0         2
```

Estructura de control releída byte a byte contra el original. 63 bytes
cambiados, todos dentro del bloque de los padres.

Intactos: intro, tutorial, los tres niveles ocultos, tabla de punteros,
menú de dificultad, botón II, fuente, y el código del despachador.

---

## Sobre el `$FD` que no bloquea

Dices que en la v140 no hay pausa de botón, sino un avance automático. El
código de `$D20A` lee el mando y espera... pero tú ves que avanza solo, y
la pantalla manda sobre la teoría.

Así que **[HIPÓTESIS, sin verificar]** debe haber otra ruta que también
libera esa espera por tiempo. No lo he medido y no lo afirmo.

Lo que sí es firme: el original lleva ese byte en los cuatro bloques,
nuestra v89 lo perdió, y reponerlo no cambia nada de lo que se ve. Queda
anotado como cabo suelto, sin urgencia.

---

## Para probar

La escena de los padres al salir de casa: el sonido debe sonar **sólo dos
veces** —al recibir los ryos y al recibir el kibidango— y no debe aparecer
ningún rectángulo sobre el bocadillo.
