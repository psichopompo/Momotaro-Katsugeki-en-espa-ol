# Momotarou Katsugeki (PC Engine) — traspaso al otro chat

Este documento es para el asistente que va a echar una mano. Lo escribe el
que ha trabajado la tanda v306→v338. Está ordenado para leerse de arriba
abajo antes de tocar un solo byte.

**Todo lo que pone «medido» está medido en el emulador o en la ROM.** Donde
hubo hipótesis, se dice. Los errores propios vienen con su causa, porque
son la parte útil.

---

## 0. Lo primero: quién dirige y cómo se trabaja

Dirige **David** (*Psicopompo* en elotrolado.net). No es el cliente: es el
que conoce el juego. **Ha tenido razón siempre.** Cuando ha contradicho el
análisis, el análisis estaba mal, sin una sola excepción. Si dice que algo
se ve mal, se comprueba antes de discutirlo.

Repo: `https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol`

### Reglas de trato

- **Siempre en castellano**, tuteando.
- Reconocer los errores propios **explícitamente**, diciendo qué falló en el
  razonamiento. Sin maquillarlos.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- Estilo: ingeniero explicando su trabajo. Conciso.
- **Una sola pregunta por mensaje**, al final, abriendo con `¿`.
- Capturas **individuales**, no rejillas de imágenes.
- No sacar una versión por cada cambio mínimo: agrupar.
- La maquetación **la decide David**.
- **No ser condescendiente.** No insistirle en que descanse.

### Órdenes vigentes (críticas)

1. **No se genera ninguna ROM hasta haber visto capturas de cómo quedan los
   cambios.**
2. Se parte de la **v334 limpia**, no de reconstruirla revirtiendo cambios.
   David: *«no quiero que pierdas el tiempo en recrearla, como has hecho en
   otras ocasiones en las que te ha dado problemas de residuos
   posteriores»*.
3. *«Ya queda poco por traducir, así que no haría cambios estructurales,
   sino arreglar sólo lo que esté mal.»*

---

## 1. Estado: de dónde se parte

    ROM virgen   roms/Momotarou Katsugeki (Japan).pce
                 512 KB   MD5 ec7358edb3672a8aa8850623eec72a71   INTOCABLE

    ROM BUENA    roms/momotaro_es_v338.pce
                 MD5   dd7cf0125e17ee27617c9c98b610e9de
                 CRC32 FD835B3E
                 Parche: parches/momotaro_v338.ips (round-trip verificado)

    Base previa  roms/momotaro_es_v334.pce
                 MD5 7608edb92eeccae3eed71f8c618d1a0e   CRC32 130477DD

### v335, v336 y v337 están DESCARTADAS

Están en `roms/descartadas/` y sus constructores en `tools/descartados/`.
Intentaron traducir los créditos y los cuatro finales y **salió mal**.
David, literal:

> «Los finales de créditos descendentes (Muy Difícil y Difícil) son un
> horror.»
> «Todo el principio y el final están sin traducir. La traducción comienza
> cuando ya han sido presentados unos cuantos enemigos. Además, los nombres
> y las frases están cortados de mala manera. No se puede cortar una
> palabra de ninguna manera.»
> «tiene bien la mayoría de los nombres, pero cuando salen frases o cargos,
> están cortados. Nada más empezar ya lo hace cortado "ado,.Momotaro.".»

**La línea válida es v334 → v338.** Todo lo que las descartadas decían
haber cerrado vuelve a estar abierto.

### Qué hace la v338 (lo único nuevo)

Devuelve el «!» a «¡Introduce el canto de Jizo!». **98 bytes en 2 tramos.**
Ver la sección 6, porque su historia enseña el error más caro de la tanda.

---

## 2. Cómo montar el emulador (se puede, y es imprescindible)

Durante media sesión estuve diciendo que no se podía emular en el sandbox.
**Nunca lo intenté.** David insistió, lo probé y funcionó a la primera. Es
el error de método más grave que he cometido: descarté una capacidad sin
medirla.

### Compilar el core

```bash
git clone --depth 1 https://github.com/libretro/beetle-pce-libretro.git /tmp/bpce
cd /tmp/bpce && make -j2
cp mednafen_pce_libretro.so /home/user/Momotaro/tools/bin/
```

Hay `gcc`, `make`, `git` y red. Tarda unos 16 segundos. **Ya está
compilado** en `tools/bin/mednafen_pce_libretro.so`.

### El arnés: `tools/pce.py`

```python
from pce import PCE
p = PCE('roms/momotaro_es_v338.pce')
p.run(300)                  # 300 frames
p.press('A', frames=4)      # pulsar un botón
p.png('/tmp/foto.png')      # captura
ram = p.ram()               # 24576 B
p.peek(0x3BA6); p.poke(0x3BA6, 0)
p.vram(); p.state(); p.load_state(blob)
```

### Cuatro trampas que costaron tiempo

1. Falta `retro_set_controller_port_device(0, 1)` → **ningún botón llega**.
   Ya está puesto en `pce.py`, pero si se rehace el arnés, es lo primero.
2. El botón de avanzar diálogos es **A**, no START.
3. Los savestates de David son de **RetroArch**: cabecera `RASTATE` y el
   `MDFNSVST` empieza en el **offset 16**. Cargar `raw[16:16+len(p.state())]`.
4. Los `.state` usan **tildes descompuestas** en el nombre: usar `glob` y
   filtrar por substring, no comparar cadenas.

### Teclear passwords: `tools/password.py`

Permite saltar a cualquier punto sin savestate.

```python
from password import boot, escribe
p = boot('roms/momotaro_es_v338.pce')
escribe(p, 'rGAPad')
p.press('START', frames=4); p.run(300)
```

Rejilla **medida celda a celda** (cursor en `$3C91`/`$3C92`, buffer en
`$3C94`):

    fila 0   A B C D E F G  a b c d e f g     códigos $01..$0E
    fila 1   H I J K L M N  h i j k l m n     códigos $0F..$1C
    fila 2   Ñ O P Q R S T  ñ o p q r s t     códigos $1D..$2A
    fila 3   U V W X Y Z    u v w x y z       códigos $2B..$36
    fila 4       0 1 2 3 4 5 6 7 8 9          códigos $37..$40

**Tres trampas**: la rejilla tiene **14 columnas** (no 16); la fila 2
empieza por **Ñ** (si se supone que empieza por O, todo se desplaza una
celda y sale «rGAO» en vez de «rGAP»); y el password se acepta con
**START**, no con el menú lateral de la derecha.

Passwords de David:

    Muy difícil  wCpeIfP        Sound test     BqdGlCIWÑI
    Difícil      GoFIBM         Graphics test  BqdGlDWÑI
    Normal       cJQIep
    Fácil        rGAPad

Ruta manual: `PULSA BOTÓN RUN → CONTINUAR → CANTO DE JIZO`.

Savestates en `/home/user/descargas/finales/` (4 finales + sound/graphics
test), descargados de `Finales.zip` del repo.

### La prueba de no-regresión (hacerla siempre)

Comparar el **hash del framebuffer** entre la ROM anterior y la nueva, en
varios escenarios, y exigir que sólo cambien las pantallas que se querían
tocar. Es lo que validó la v338:

    partida nueva, 4 semillas aleatorias    280 puntos   0 diferencias
    password Fácil / Normal / Difícil       120 puntos   0 diferencias

Plantilla en `/tmp/regresion.py` (recrear si hace falta; es corta).

---

## 3. Mapa de la ROM

    banco $0B  0x16000   vítores de fin de fase
    banco $0C  0x18000   menú RUN
    banco $0F  0x1E000   escenas, rótulos de aldea, PASSWORD
    banco $1D  0x3A000   CRÉDITOS LARGOS  (los 4 finales usan 0x3B800)
    banco $20  0x40000   motor de texto $9B0B
    banco $21  0x42000   menú RUN, $AAB4, tabla B de rótulos (0x4379D)
    banco $24  0x48000   tiendas y guion
    banco $25  0x4A000   créditos, ermitaño, QUIZ

### Tablas conocidas

| Dónde | Qué |
|---|---|
| `0x11818` | Tabla del quiz, 96 entradas: `[0-1]` ermitaño, `[2-41]` 40 preguntas, `[42-81]` 40 tríos de respuestas, `[82-95]` 14 técnicas |
| `0x11CD0` (`$DCD0`) | 40 bytes con la respuesta correcta (0-2). **El orden de las opciones es INTOCABLE** |
| `0x1ED6E` | Tabla de escenas (aquí estaba el bug del jefe de Kintaro) |
| `0x24DE` | Presentación de enemigos: 38 entradas de **8 bytes**. **ABIERTA**, ver sección 7 |
| `0x43712` | Tabla A: menú de destinos del teletransporte (ventana de 8 celdas) |
| `0x4379D` | **Tabla B: los 9 rótulos de aldea.** Cuidado con ella |
| `0x434B5` | Menú SELECT |
| `0x1F51E` | Backup RAM, 674 B. Sin traducir |

`$D8BC[0..6]` son los **nombres** del ermitaño (Hien, Janpu, Korokoro,
Mawashi, Bakuhatsu, Tsunami, Paropunte) y `$D8CA[7..13]` las **artes** del
premio. Son nombres propios: no se traducen (lección de la v330).

El **bloque limpiador** `0x4AD56..0x4AD76` son 32 bytes de `$20` que borran
el bocadillo. Lo usan `$CDFE`, `$D9B6`, `$DD37`. **No es texto: no
escribir ahí.** Lo pisé en la v327 y hubo que restaurarlo en la v328.

---

## 4. Los charsets: TRES, y hay que elegir bien

Este es el error que más veces se ha repetido en todo el proyecto.

| Fichero | Motor | Particularidad |
|---|---|---|
| `tools/charset_oficial.py` | menú | alias `b`=$5B `c`=$5D `p`=$5E |
| `tools/charset_vitores.py` | `$9B0B` | bytes directos (tiendas, vítores) |
| `tools/charset_rotulos.py` | `$AAB4` | alias `b`/`c` **y además** `e`=$3D `o`=$62 |

Patrón general: mayúsculas y espacio en ASCII directo, minúsculas en
`$A1 + (c-'a')`, tildes en `$BB..$C8`, `¡`=$CA, `¿`=$C9, `.`=$CB, `,`=$CC.

**Un mismo bloque contiguo puede llevar dos charsets distintos.** El
password (`0x1F881`) usa `charset_oficial` y los rótulos que van pegados
justo detrás usan `charset_rotulos`. Lo cazó un assert al construir la
v338. Antes de recomponer un bloque, verificar con qué codificación está
escrito **cada tramo**.

### ⭐ El origen común de la Ç y las letras raras — RESUELTO

David lo intuyó: *«es algo que nos ha ocurrido en tres o cuatro ocasiones.
Tienen que tener un origen común»*. Tenía razón.

    $3BA6 = 0  ->  tabla $9CF3  ->  minúsculas normales
    $3BA6 = 1  ->  tabla $9CB3  ->  j->A   l->B   n->C   z->D

`$AB91` hace `EOR #$01` con **cada `$5C`** que encuentra. Sólo cambian esas
cuatro letras.

Eso explica de golpe «IiDuka» (por Iizuka), «IDawa» (por Izawa) y la **Ç en
lugar de la `p`**. **No es un charset roto: es `$3BA6` que queda sucio.**
El japonés no lo notaba porque el katakana es idéntico en ambas tablas.

Verificado escribiendo el alfabeto entero: minúsculas → `klmnoÇqrstu wxyz`;
MAYÚSCULAS `$41..$5A` → `KLMNOPQRSTU WX` **perfectas**. Por eso los cargos
del staff van en mayúsculas: esquivan el problema.

Consecuencia práctica, la `p` tiene cuatro reglas según la zona:

    preguntas del quiz    $B0 directo   ($5E da ©)
    opciones del quiz     $5E alias     ($B0 da Ç)
    créditos 0x3B800      $5E alias     ($B0 da Ç)
    zona 0x4A446          $B0 directo   ($5E da @)

### El `$3B` no siempre es salto de línea

David: *«sale una especie de coma y punto `,.` cada dos por tres»*.

    $3B en los créditos (0x3B800):  el japonés lo usa 0 veces en 1923 B
    $3B en la zona 0x4A446:         52 veces

En los créditos el salto de línea es el **`$5C`**, que además conmuta el
color (cargo en amarillo / nombre en blanco). Ahí el `$3B` se pinta como
`,.`, que es exactamente lo que veía David.

---

## 5. Geometría: cuántas columnas caben

    $DD53  preguntas del quiz:  CMP #$20 -> 32 columnas, $80 salta a col 16
           -> 2 líneas de 16, PERO la columna 16 no se pinta: MÁXIMO 15
    $DAC0  opciones del quiz:   CMP #$08 -> 8 columnas, 1 la ocupa el cursor
           -> 7 ÚTILES
    password (0x1F881):         hasta $FF o hasta 28 columnas
    descripciones de objeto:    el motor corta a 16 columnas

### Créditos (`0x3B800`)

    $5C cargo(12 columnas exactas, rellenas) $5C nombre
        ^línea 1, amarilla                       ^línea 2, blanca

Medido en los bloques B84/B93/B95: el tramo entre los dos `$5C` ocupa
**siempre 12 columnas**. El bloque **empieza por `$5C`**.

El motor lee **en secuencia**, sin tabla de punteros. Verificado siguiendo
el cursor `$20BF`: `$5800 → $5805 → $580F → $5818 → $5824`.

Ancho medido con la regla `ABCDEFGHIJKLMNOPQRS`: se ven **17** columnas, el
resto envuelve.

---

## 6. El bug del «!» del password: la lección más cara

Es el caso que mejor resume qué hay que evitar. Vale la pena leerlo entero.

### Lo que veía David

> «En la pantalla de password, en lugar de poner "¡Introduce el canto de
> Jizo!", pone "¡Introduce el canto de JizoA". Esto me molesta
> especialmente porque es algo que solucionamos hace casi un mes, y nos
> costó un huevo.»

Y su sospecha: *«ha aparecido por algo que hemos hecho estos días, quizá
por las tiendas, los dados, el quiz, el menú SELECT o el menú RUN»*.

### [HECHO] La bisección

Volcando `0x1F878..0x1F8B0` en las 26 ROMs del proyecto:

    v306..v319   ...Jiz{AF}!  <01>Aldea Dormilón     <- el «!» está
    v320..v337   ...Jiz{AF}   <01>Aldea Dormilón     <- el «!» no está

David acertaba en que era cosa nuestra, pero es **tres semanas más viejo**
de lo que parecía: murió en la **v320**.

### [HECHO] La causa

La v320 metía «Aldea Taketori» (3 B más que «Bambú») y reescribía el bloque
de rótulos `0x1F89C..0x1F900`. Pero **el bloque de rótulos no empieza en
0x1F89C**: ahí acaba el password. Empieza en `0x1F89D`.

El assert que tenía era:

```python
assert p == 0x1F8F9, 'el bloque no acaba donde creo'
```

Comprobaba dónde **acababa**, no dónde **empezaba**. Pasó limpio mientras
se comía el «!» del vecino de arriba.

Y la v324, al revertir «Taketori»→«Bambú», no recompactó: dejó 3 B muertos
en `0x1F8EC..0x1F8EE`.

### [DESCARTADO] Mi propio diagnóstico anterior era falso

En la sesión previa dejé escrito, con la etiqueta «medido»:

> «Falta el `!` y el `$FF` de cierre. Arreglo medido: `¡Escribe el canto de
> Jizo!` = 26 B, CABE. (`¡Introduce el canto de Jizo!` son 28, no cabe.)»

**No estaba medido.** Lo deduje contando bytes hasta el rótulo siguiente.
Tres ROMs de prueba en el emulador lo desmontaron:

    test1   27 caracteres «ABC...Za»    -> se ven los 27 y sigue con la 'A'
    test2   $FF forzado en 0x1F89B      -> corta ahí: «...canto de Jiz»
    test3   28 caracteres «ABC...Zab»   -> se ven los 28 y NO sigue

El motor pinta **hasta `$FF` o hasta 28 columnas, lo que llegue antes**. O
sea que el texto original de David cabe exacto y **no había que cambiarlo**.
Si me hubiera creído mi propia nota, habría reescrito un texto correcto sin
necesidad.

### [HECHO] El arreglo aplicado en la v338

    0x1F880  $01
    0x1F881  «¡Introduce el canto de Jizo!»  28 car. (charset_oficial)
    0x1F89D  $FF                             cierre explícito
    0x1F89E  «Aldea Dormilón»    B[3]=$589E
    0x1F8AE  «Aldea Urashima»    B[4]=$58AE
    0x1F8BE  «Aldea Kachiyama»   B[5]=$58BE
    0x1F8CF  «Aldea Issunboshi»  B[6]=$58CF
    0x1F8E1  «Aldea Bambú»       B[7]=$58E1
    0x1F8EE  «Isla Ogros»        B[8]=$58EE
    0x1F8FA..0x1F8FF  6 B libres

Constructor: `tools/fix_password.py`. Recompactar recupera de paso los 3 B
muertos de la v324.

### [HECHO] Cómo se comprobó que no rompe nada

Como el arreglo desplaza 2 bytes los seis rótulos, se barrieron los 524288
bytes buscando **cualquier** puntero little-endian con valor en
`$5878..$5900`: aparecen **200 coincidencias**. Todas menos las 6 de la
tabla B son **byte a byte idénticas a la ROM japonesa** → son gráficos y
código, no referencias. La única tabla que apunta ahí es la B.

Diff final: **98 bytes en 2 tramos** (`0x1F89C-0x1F8F9` y
`0x437A3-0x437AD`). Zonas verificadas intactas: bancos 00-0A, vítores, menú
RUN, escenas, motor de texto, menú SELECT, tiendas, créditos, dados, bloque
limpiador, **el QUIZ entero** y el resto de la ROM.

Y 400 puntos de no-regresión en el emulador con **0 diferencias** fuera de
la pantalla del password. Capturas del antes y el después en
`capturas/v334_password_zoom.png` y `capturas/v338_password_zoom.png`.

---

## 7. Qué queda pendiente

El registro único es **`docs/PENDIENTES.md`**. Resumen:

### Abierto y reclamado por David

| # | Qué |
|---|---|
| **A5** | **Los 4 finales y los créditos.** Todos usan `0x3B800`. Sin traducir en la v338. Lo de v336/v337 queda anulado. Inventario en `docs/MAQUETACION_finales.md` |
| **A000c** | **Bug gráfico bajo la cabeza del ogro rosa** en el final Difícil. David: *«A partir de cierto momento vemos un error gráfico en la parte inferior, justo debajo de la cabeza del ogro de pelo rosa que hay de espaldas.»* **Sin investigar** |
| **A000d** | **Tabla `0x24DE`** (presentación de enemigos): sigue apuntando a offsets japoneses, los textos van desfasados. El repunte de la v335 se perdió al descartarla |
| **A000e** | **15 `$00` de relleno** en `0x4A476..0x4A483`: abren páginas fantasma (28 terminadores en japonés, 43 en el nuestro) |
| **A00** | **Colas invisibles** en casi todas las descripciones de objeto: `e vida.`, `écnica.`, `liado.`, `cotone`, `s ogro`, `en hi`, `bertad.Cor`, `lejosE`. No se ven (el motor corta a 16 columnas) pero están |
| A4 | 5 mensajes sueltos del menú: `0x435E6`, `0x4363D`, `0x4366B`, `0x4369C`, `0x436CC`. Sin tabla localizada |
| — | Backup RAM (`0x1F51E`, 674 B), 4 huérfanos de vítores, menú RUN en cascada, passwords amigables |

### Bloqueado

**Casa mutilada de Kachiyama** y **pancarta de 4 px**: la SAT se compone en
ejecución (DMA a VRAM `$FE00`), no hay tabla estática que tocar. Solución
simulada: reordenar la SAT (mapa 22-34 antes que rótulo 0-21) da pico=16
limpio. No aplicado.

---

## 8. Cómo quiere David los textos

Esto no se negocia; son decisiones suyas.

### Criterio general

Fidelidad, naturalidad y **puntos finales**. **Sin abreviaturas.**
**Momotaro** sin `u` final. **Sólo** con tilde.

### Nunca partir una palabra

> «No se puede cortar una palabra de ninguna manera.»

Si no cabe en la línea, **la palabra entera baja** a la siguiente.

### Presentación de enemigos

La frase en su línea, el nombre en la suya, y **punto final** si no acaba
en exclamación:

    ¿Cayó sin estallar?
    ¡Ogro Explosivo!

### Nombres del staff

**Orden occidental** (nombre y luego apellido) y con **inicial** si no cabe:
`M. Kuya`, `H. Iizuka`.

Ojo con la transcripción. David:

> «¿Estás seguro de que el nombre Hiroyuki IiDuka es correcto? IiDuka tiene
> una D mayúscula intercalada, y tú lo has transcrito del japonés, que no
> tiene mayúsculas. No lo entiendo.»

Tenía toda la razón: esa `D` **no existe**, es el efecto de `$3BA6` de la
sección 4 (`z` → `D`). El apellido es **Iizuka**. Cualquier mayúscula rara
intercalada en medio de un nombre es este bug, no una transcripción.

### Nomenclatura de los finales

**Muy difícil / Difícil / Normal / Fácil.** Nunca «corto/largo».

### Nombres propios

Los del ermitaño (**Hien**, Janpu, Korokoro, Mawashi, Bakuhatsu, Tsunami,
Paropunte) son nombres, no artes. En la v329 los traduje («Vuelo») y hubo
que revertirlo en la v330.

---

## 9. El método (`docs/PROMPT_METODO.md`)

Obligatorio. Resumido:

1. **Diario `investigation.md`** (~31.000 líneas, 214 entradas). Las
   hipótesis falsas **no se borran**: se marcan `[DESCARTADO]` y se explica
   por qué fallaron. Eso es lo que evita repetir errores.
2. **Una medición → una causa → un arreglo → una verificación.** Nada de
   arreglar dos cosas a la vez.
3. **Prohibido escribir bytes a ciegas.**
4. Numerar cada versión con **MD5 / SHA-1 / CRC32**.
5. Los constructores llevan **asserts** de: byte esperado antes de escribir,
   hueco libre suficiente, zonas intactas, y **relectura siguiendo el
   puntero** (no basta con que el texto esté ahí: hay que llegar a él por
   donde llega el motor).
6. **`docs/PENDIENTES.md` es el registro único.** Nada se cierra sin que
   David lo confirme en pantalla.
7. El IPS se genera contra la ROM virgen y se verifica con **round-trip**.

### Normas nuevas que salieron de la v338

    332  Al reescribir un bloque entero, el assert debe fijar CABEZA Y COLA.
         Comprobar sólo dónde acaba deja libre la cabeza para comerse al
         vecino de arriba (así la v320 se comió el «!» del password).
    333  Un bloque contiguo puede llevar DOS CHARSETS distintos.
    334  Antes de mover texto, barrer los 512 KB buscando punteros a la zona
         y comparar cada coincidencia con la ROM japonesa: si es idéntica,
         es código o gráficos, no una referencia.
    335  Si escribo «medido», tiene que estar medido.
    336  No se genera ROM sin capturas antes.

---

## 10. Los errores cometidos, en una tabla

Están aquí porque son más útiles que los aciertos.

| Versión | Qué hice mal | Por qué |
|---|---|---|
| v318 | Repunté la tabla B pensando que era «el rótulo al viajar». Desapareció «Aldea» de todo el juego | Identifiqué la tabla por su lector sin comprobar **el contenido apuntado** |
| **v320** | Me comí el «!» del password | El assert verificaba la **cola** del bloque, no la cabeza. Tardó 18 versiones en detectarse |
| v322 | «Texto raro» del ermitaño: escribí 14 B corridos | Moví el marcador de sustitución sin darme cuenta |
| v324 | Dejé 3 B muertos al revertir «Taketori»→«Bambú» | Reverti el texto pero no recompacté ni repunté |
| v326 | 12 de 14 técnicas llevaban **rotas desde la v317** | No releí siguiendo el puntero después de escribir |
| v327 | Pisé el bloque limpiador → texto fugaz en el bocadillo | Supuse que 32 bytes de `$20` eran relleno. Eran código de borrado |
| v329 | Traduje «Hien» como «Vuelo» | Son nombres propios. Lo cazó David |
| v335-337 | Los finales quedaron ilegibles | Maqueté sin ver capturas. De ahí la orden de David |
| toda la sesión | Dije que no se podía emular | **No lo intenté.** Se podía, y cambió el proyecto entero |
| informe previo | Escribí «arreglo medido: 26 B» sin medirlo | Deducción disfrazada de medición. El motor admite 28 |

El patrón se repite: **suponer en vez de medir**, y **verificar la mitad**
de lo que se toca.

---

## 11. Ficheros

```
/home/user/
├── COMO_RETOMAR.md                     arranque rápido, al día en v338
└── Momotaro/
    ├── LEEME.md                        normas 12-336
    ├── investigation.md                diario, 214 entradas
    ├── roms/
    │   ├── Momotarou Katsugeki (Japan).pce   INTOCABLE
    │   ├── momotaro_es_v338.pce        ★ LA BUENA
    │   ├── momotaro_es_v334.pce        base de la v338
    │   ├── v306..v333                  puntos de retorno
    │   └── descartadas/                v335, v336, v337
    ├── parches/momotaro_v308..v338.ips
    ├── capturas/                       v334_password_zoom.png, v338_password_zoom.png
    ├── tools/
    │   ├── bin/mednafen_pce_libretro.so   ★ Beetle PCE compilado
    │   ├── pce.py                         ★ arnés de emulación
    │   ├── password.py                    ★ tecleador de passwords
    │   ├── fix_password.py                el constructor de la v338
    │   ├── build_v314..v334.py
    │   ├── quiz_texto.py                  40 preguntas + 120 opciones
    │   ├── charset_oficial.py / _vitores.py / _rotulos.py
    │   ├── kana.py, state.py, dis6280.py, vdc_slots.py
    │   └── descartados/                   build_v335/336/337.py
    └── docs/
        ├── PENDIENTES.md               ★ registro único
        ├── PROMPT_METODO.md            ★ el método
        ├── QUIZ.md                     estructura del quiz
        ├── MAQUETACION_finales.md      inventario 27+104 bloques
        └── INFORME_v306_a_v334.md      la tanda anterior en detalle
/home/user/descargas/finales/           6 savestates de David
```

---

## 12. Por dónde empezar

Lo más rentable, en este orden:

1. **Los 4 finales** (A5). Es lo que más le duele a David y lo que ya falló
   dos veces. **Maquetar, capturar, enseñar, y sólo entonces generar ROM.**
   Ojo al `$5C` (salto + cambio de color), a las 12 columnas del cargo, al
   `$3BA6` de las minúsculas y a no partir jamás una palabra.
2. **El bug gráfico del ogro rosa** (A000c). Ni se ha mirado.
3. **La tabla `0x24DE`** de presentación de enemigos (A000d), con el formato
   de dos líneas que quiere David.

Y la regla que resume todo: **si no lo has visto en pantalla, no está
arreglado.**
