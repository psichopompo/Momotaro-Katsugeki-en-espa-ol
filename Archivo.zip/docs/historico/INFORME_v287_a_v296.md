# Informe v287 → v296

**ROM vigente:** `momotaro_es_v296.pce` · MD5 `781fb22da4b5cba725ca73afc6f6a1bf` · CRC32 `DE8DC70D`

Cubre: la `Ç` del password de Game Over, el menú de Game Over completo, la
pantalla de «¡Guardado!», y la primera tanda de las tiendas. Incluye los
errores cometidos con su causa, porque tres de ellos rompieron cosas.

---

## Cadena de versiones

| Ver | MD5 | Qué |
|---|---|---|
| v287 | `426a0a25…` | punto de partida (menú GO con palabras cortas) |
| v288 | `4a835482…` | la `Ç` del canto de Game Over — **1 byte** |
| v290 | `3fe6cc23…` | menú GO: lista de sprites reubicada + textos |
| v291 | `32ae497b…` | arregla el terminador pisado; opciones a x=96; cursor |
| v292 | `778c26e3…` | `Ó` alineada; «Terminar» −1 px; cursor a x=81 |
| v293 | `1234b3a1…` | **REVERTIDA** — rompió la pantalla de título |
| v294 | `1ebc049f…` | «¡Guardado!» sin romper el título |
| v295 | `8fb4a20c…` | tiendas: 20 descripciones + 24 diálogos |
| v296 | `781fb22d…` | los alias `b/c/p/Ç` del motor de tienda — 56 bytes |

---

## 1. La `Ç` del password (v288)

**Lo detectó David a ojo:** *«el último carácter del password es una Ç, que
no figura en la parrilla»*.

No era cosmético: si un password contiene el valor 38, el jugador ve un
carácter **que no existe en la rejilla de entrada** y no puede volver a
teclear su propia contraseña.

Causa: la tabla del canto de Game Over (`$57B6` = ROM `0x1F7B6`) usaba `$B0`
para la `p`, y `$B0` está en la tabla de sustitución previa `$AB34`:

```
origen  20 21 2D B0 A2 A3 24
destino 3C 5C 5F 5F 5B 5D 3E
              ^^ ^^
$B0 → $5F → ruta baja → glifo $DE = Ç
```

La `p` buena en ese motor es **`$5E`**. Un byte en `0x1F800`.

**Barrido de las tres tablas de 64 códigos:**

```
parrilla de entrada  0x1BBBA   64/64 OK
tabla del Jizo       0x16AD6   64/64 OK   (índices de glifo directos)
Game Over            0x1F7B6   1 fallo, posición 37
```

El fallo era único en toda la ROM.

---

## 2. El menú de Game Over (v290 → v292)

### La lista de sprites real

El menú **no** lo monta la lista `0x1F900` del banco `$0F`. La monta
`$D76B` (ROM `0x1B76B`):

```
$D76B  LDA #$17 / CLC / ADC $20 / TAM #$04   ← mapea el banco $17
       LDX #$40 / LDY #$28                    origen x=$40 y=$28
       $53/$54 = $5812                        la lista
       $55/$56 = $0380                        base de patrón
       STZ $52 / JMP $E3EB
```

`$5812` en el banco `$17` = **ROM `0x2F812`**, 13 registros, `$FF` en
`0x2F853`. Verificado contra el Sprite Viewer: **13 de 13 coinciden**.

Formato: `[rel][$0E][$01][dx][dy]`, `tile = $1C0 + rel`, `$01` = 32×16 =
**4 glifos**. Pantalla: `x = $40+dx`, `y = $28+dy` (Mesen muestra +32/+64).

> **Cómo se descartó la pista falsa:** la lista `0x1F900` tiene sus sprites
> a **32 px** y el SAT real del Game Over los tiene a **36** (x = 58, 94,
> 130, 166). La separación es una resta y no depende de la base elegida,
> así que esa lista no puede generar ese SAT. Además tiene 20 registros en
> rejilla 5×4 y el SAT real tiene 13 en filas de 2/1/1/1/4/4.

### Lo que se hizo

La lista pasó de 13 a 17 registros (cada opción gana sprites). No cabía en
el banco `$17` (único hueco: 66 B, necesarios 86), así que se **mudó al
banco `$23`** (`0x47CFC`, 773 B) y se repuntaron 3 bytes de `$D76B`.

Destinos VRAM reordenados para que ningún bloque se derrame en el siguiente
(el motor `$D619` escribe hasta el `$00` y **no corta**):

```
           VRAM    glifos   sprites
título     $7008     8         2      SE ACABÓ
op1        $7108    12         3      Continuar
op2        $7288     8         2      Terminar
op3        $7388     8         2      Guardar
password   $7488    32         8
```

Textos reubicados a `0x1F9D5` (43 B a `$FF` **en la ROM original**) y
repuntada la tabla `0x1F72D`.

### Detalles de maquetación

- **Opciones a x=96**, alineadas.
- **Cursor (melocotón) a x=81.** Lo dibuja `$D7BB` con su propia lista
  (`0x2F854`, 1 registro 16×16) y una tabla de Y en `0x1B7E2` para las tres
  posiciones. Solo hubo que cambiar su `dx`.
- **«Terminar» 1 px a la izquierda** (x=95): el glifo de la `T` (`$83`)
  tiene la primera columna vacía y las otras iniciales no. Se mueve el
  sprite, no la fuente.
- **Glifo `Ó` (`$C5`) redibujado grueso**, cuerpo en las filas 2-6 para que
  acabe donde la `O` normal (`$7E`).

---

## 3. [ERROR PROPIO] La v290 rompió el bocadillo del abuelo

Escribí la lista nueva en `0x47CFB`, que es **el `$FF` que termina la lista
B** (la del abuelo).

```
v288   0x47CFB = $FF   ← terminador
v290   0x47CFB = $00   ← primer byte de mi lista
```

Sin terminador, la lista B siguió leyendo mis 17 registros: de 18 sprites
pasó a 35. Los sprites fantasma que vio David eran mi menú de Game Over.

**Causa:** conté los `$FF` libres **desde** `0x47CFB` en vez de **después**
de él. Un byte de desfase.

Arreglado en la v291 moviendo la lista a `0x47CFC`, con un assert que
verifica que `0x47CFB` sigue valiendo `$FF`.

---

## 4. [ERROR PROPIO] La v293 rompió la pantalla de título

La pantalla de «¡Guardado!» la monta `$D94F` (ROM `0x1B94F`): carga la
cadena `$57AA`, el destino VRAM `$7008`, y su lista de sprites está en
`0x2F8AB` (2 registros).

Vi 91 bytes tras esa lista que en la virgen son `$FF` y en nuestras ROMs
tienen datos. Los di por basura que había pisado el terminador y los limpié.

**No eran basura.** Hay una tabla de punteros en `0x48046` (banco `$24`)
cuya entrada `[6]` apunta a `$58B5` = `0x2F8B5`: es la lista de sprites de
la **pantalla de título**. Al borrarla, COMENZAR y CONTINUAR se quedaron sin
sprites.

**Causa:** busqué referencias solo con el patrón `[cmd][word]` del
intérprete de texto. Esta es una **tabla de listas de sprites**, con otro
formato, y el barrido no la vio.

Arreglado en la v294: `0x2F8B5` restaurado e intocable (con assert), y la
lista de «¡Guardado!» **reubicada** al banco `$23` con 3 sprites y
desplazada 8 px a la izquierda.

---

## 5. Las tiendas (v295 → v296)

### Estructura

```
tabla maestra  $C929 = ROM 0x10929   24 entradas de 4 B:
               [puntero lo][puntero hi][precio lo][precio hi]
lector         $9B0B (banco $20)     LDA ($14) byte a byte
```

Los precios confirman la tabla: salen **200 y 500**, los que se ven en la
tienda de armas.

Códigos del lector:

```
< $20    control
$5C      conmuta resaltado  ($9AFD: EOR #$01 sobre $3666)
>= $A0   glifo directo
resto    SBC #$20 (una o dos veces) → tabla $9C73
```

Texto en **líneas de 20**, relleno `$A0`. Alineación a la izquierda por
decisión de David (el centrado japonés es porque el original es vertical).

> **Sobre el `$5C`:** puse un assert exigiendo paridad y saltó. El original
> **tampoco está balanceado** (17 en `0x484C0`-`0x488A1`, impar): el
> resaltado se abre y cierra *entre* mensajes, no dentro de cada uno. El
> assert se cambió por «no añadir ninguno».

### Lo traducido

20 descripciones de objeto (`0x488A1`-`0x48B7A`) y 24 diálogos de tendero
(`0x484C0`-`0x488A1`). Nombres coherentes con la tabla `$AF4C` que ya usa el
juego: Onigiri, Manjar, Banquete, Dango, Pedos, Solar, **Glacial**,
Raquetas, Bonzo, Capa, Aletas. Equipo con «Espada X» / «Coraza X».

### El motor de tienda usa OTROS alias

David: *«pone Es©ada en lugar de Espada. Siempre es la p.»*

```
motor MENÚ    ($AAB4)   tabla de sustitución $AB34 → tabla $43F9B
motor TIENDA  ($9B0B)   SBC #$20 → tabla $9C73
```

Los alias `b`/`c`/`p` = `$5B`/`$5D`/`$5E` funcionan en el menú porque pasan
por la tabla de sustitución. **En la tienda esa tabla no existe** y los tres
caen en el glifo `$8B`, que es una **©**.

Barrido de los 90 caracteres comparando ambos motores: **solo discrepan 4**.

```
       menú    tienda      en tienda hay que usar
'b'    $A2      $8B ©      $A2
'c'    $A3      $8B ©      $A3
'p'    $B0      $8B ©      $B0
'Ç'    $DE      $8B ©      $DE
```

Justo lo contrario que en el menú. 56 bytes corregidos en la v296.

> **Para el futuro:** `charset_oficial.encode()` sirve para el motor de
> MENÚ. Para lo que pinte `$9B0B` hay que convertir esos cuatro códigos.

---

## 6. [ABIERTO] La corrupción gráfica de las tiendas

**No es texto japonés sin traducir.** Esa hipótesis (norma 250) explicaba el
menú SELECT y la extendí aquí sin comprobarla. Es falsa para este caso.

Medido sobre el savestate de David (`states/9_tienda_v296.state`),
decodificando las celdas del bocadillo plano a plano:

```
celda $0EC    61 píxeles en los planos 0-2      24 en el plano 3
celda $0F0   152 píxeles en los planos 0-2      19 en el plano 3
```

El motor de texto **solo escribe en el plano 3** (color 8). Si únicamente
hubiera texto, los únicos valores de píxel serían 0 y 8. Hay 1, 2, 3, 4, 5,
6, 7, 9, 10…

**El juego escribe el texto encima de gráficos anteriores sin limpiar la
celda.** Los planos 0-2 conservan el CG previo, y por eso el texto sale
entrelazado con revoltijo de colores dentro de sus propias celdas.

Lo que falta: localizar quién debería limpiar esas celdas antes de escribir.
En el bocadillo del abuelo eso ya funciona (`$9C29` pone el buffer a cero),
así que el motor de tienda tiene un equivalente que falta o no se llama.

**Hasta que esto se resuelva no se puede juzgar la maquetación del texto de
las tiendas** (centrado, saltos de línea): lo que se ve no es fiable.

---

## 7. Pendiente en el banco `$24`

834 bytes de japonés intacto, en 54 tramos. **Ojo:** casi todos son de la
pancarta final y los mensajes de victoria (`0x480EA`, `0x48406`…), que
comparten banco pero **no se pintan en la tienda**.

El único tramo de tienda sin traducir es **`0x4846B`** (85 B): la primera
línea del tendero (`ｱﾅﾀﾀﾞｹｶﾞ ﾀﾖﾘﾃﾞｽ` / `ｲﾗｯｼｬｲ` / `ﾌﾞｷ ｶｯﾃｲｸﾄ ｲｲﾄﾞ`).

---

## 8. Normas nuevas

- **Un hueco de `$FF` empieza DESPUÉS del terminador de la lista anterior**,
  no en él. Contar desde el `$FF` se come el terminador (v290).
- **Buscar referencias con un solo patrón no basta.** `[cmd][word]` no
  encuentra las tablas de listas de sprites, que tienen otro formato (v293).
- **Un hueco de `$FF` no es un hueco si no lo era en la ROM virgen.**
  `0x1F61C` parecía libre (273 B) y es texto que borramos nosotros, con dos
  punteros vivos apuntando dentro.
- **El juego tiene DOS motores de texto con codificaciones distintas.**
  Verificar en cuál se va a pintar antes de codificar.
- **Ausencia de síntoma no es prueba.** «He jugado tres partidas y no sale
  la Ç» no verifica el arreglo: la probabilidad de que el valor 38 aparezca
  en un password es del 40 %, y con 3 partidas hay un 22 % de que no salga
  por azar.
- **No extender una causa verificada en un sitio a otro sitio distinto**
  sin volver a medirla (los artefactos de las tiendas).
