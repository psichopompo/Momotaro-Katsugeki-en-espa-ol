# v140 — los tres niveles ocultos

`test_ocultos_v140.pce` — MD5 `847be4be16657c0d0d9d4fe71149d06e`

---

## Qué es el `$FD` exactamente

Lo desensamblé antes de tocarlo, y **me equivoqué al llamarlo «pausa»**:

```
$D20A   LDA $3CE7 / BEQ ...      ¿estamos esperando?
        LDA $44 / BIT #$01       <- LEE EL MANDO (botón I)
        BEQ ...                  sin botón: sigue esperando
        STZ $3CE7                con botón: continúa
```

`$44` es el mando. **`$FD` detiene el texto hasta que pulsas el botón.** No
cuenta tiempo ni pinta flechita: se queda esperándote, sin más.

Por eso el final de cada página normal es `$FD $FD $FE` — dos esperas y
cambio de página.

Tu descripción de lo que veías era exacta; lo que estaba mal era mi
explicación de por qué.

## ¿Se les olvidó a los japoneses?

No. **Los cuatro bloques lo llevan**: el tutorial tiene 9 bytes `$FD` y cada
nivel oculto, 7. Es deliberado y sistemático.

**El que lo perdió fue nuestro parche v89**, que se quedó en 8. Así que tu
observación de que «al final del tutorial no se detiene nada y tienes que
leer rápido» era un fallo nuestro, no del original.

**Repuesto en el tutorial**, como pediste. Ahora el abuelo dice «¡Ve a la
derecha», te espera, y remata con «hasta la meta! ¡Ya!».

---

## El espacio: no hizo falta la cirugía

Elegiste la opción B —mudar de banco y tocar el `LDA #$0F`— y tenías razón
en el fondo: había que buscar sitio de verdad, no recortar tu texto. Pero
no hizo falta llegar tan lejos.

Faltaban 37 bytes. Buscando en el propio banco aparecieron **392 libres** en
`0x1F5A5`: **la intro japonesa original**, huérfana desde que la tradujimos
en la v83.

Prueba de que está muerta:

```
ROM virgen  ->  LDA #$A5 / STA $BF     apunta al japonés
v139        ->  LDA #$5F / STA $BF     apunta a tu traducción
```

La repuntamos nosotros y es el único sitio de toda la ROM que la cargaba.
El constructor lo comprueba con un `assert` antes de escribir nada.

```
zona de los 3 bloques   328 B
intro japonesa muerta   392 B
                        ─────
disponible              720 B      necesito 365    sobran 355
```

Todo en el mismo banco, así que **no se ha tocado ni una instrucción**. Los
bloques se colocan reescribiendo la tabla de punteros: seis bytes.

Quedan **358 bytes libres** para lo que venga.

---

## El texto, tal como quedó

### Oculto 1 — el de los ñordos

```
¡Oh, Momotaro!
¿Un ejercicio suave?          «espera botón»

¡Esquiva los ñordos
que caen! ¡Ja, ja!            «espera botón»

¡Ve a la derecha              «espera botón»
hasta la meta! ¡Ya!
```

### Oculto 2 — la kusudama

```
¡Oh, Momotaro!
¿Un ejercicio suave?          «espera botón»

¡Rompe bien la bola!
¡Habrá premio! ¡Ja!           «espera botón»

¡Venga! ¿Preparado?           «espera botón»
¡A empezar!
```

### Oculto 3 — fortuna y pobreza

```
¡Vaya! ¿Has llegado
hasta aquí? ¿Juegas?          «espera botón»

Tocar al rico, bien.
Tocar al pobre...             «espera botón»

¡En fin, de eso va!           «espera botón»
¿Listo? ¡A empezar!
```

El chiste del dios pobre queda como en el original: la amenaza se corta con
puntos suspensivos y nunca se dice qué pasa.

---

## Verificado

Releí los cuatro bloques **siguiendo la tabla de punteros**, igual que hace
el juego: las 24 líneas correctas, las esperas en su sitio, los cuatro
terminan bien.

Intactos: intro en español, escena de los padres, menú de dificultad (que
está pegado justo detrás y era el peligro), botón II, fuente, rótulos del
mapa y de aldea, cadenas de dinero, y los tres trozos de código implicados.

---

## Para probar

- **El tutorial de los ñordos**: ahora debe esperarte antes del «¡Ya!».
- **El nivel oculto que encontraste**: las tres páginas en español.
- Si te topas con **la kusudama** o con **fortuna/pobreza**, avisa: son los
  dos que aún no habías visto.
