# v144 — el bloque negro, resuelto

`test_terminador_v144.pce` — MD5 `4887028c2f7d33421af89b833075a173`

---

## Era un byte

La lista de sprites del bocadillo de los padres ocupa esto:

```
0x2FAE2 .. 0x2FB8C     34 registros + el terminador $FF
                ↑
        el $FF final cae justo aquí
```

Y en la v134 puse las tablas del rótulo de aldea empezando en… `0x2FB8C`.

**El mismo byte.** Me comí el terminador.

Sin ese `$FF`, el motor de sprites no sabe dónde acaba la lista: sigue
leyendo mis tablas de índices y punteros como si fueran registros de
sprites, y emite basura. Esos sprites usan paletas 2, 3, 4, 9, 10, 11, 13 y
15 — que en esa escena están **todas a negro**. De ahí el rectángulo.

Y como esa basura agota las 64 ranuras del hardware, no quedan para el
resto del diálogo: por eso el texto se cortaba en la primera letra.

```
lista $5AE2 leída:   v128  39 registros    v134  76    v143  105
sprites de la escena: v128  48 de 64       v142  63 de 64
```

---

## Tus tres aportaciones fueron las que lo resolvieron

1. **La bisección** (v130/v132/v133 bien, v134 mal) acotó el cambio a una
   sola versión. Sin eso habría seguido mirando donde no era.
2. **El breakpoint que no saltó** en `$DE4B` eliminó una vía entera en la
   que llevaba tres mensajes.
3. **El breakpoint de escritura** en `$270B` dio la pila de llamadas
   `$C2DB ← $C031 ← $C000` y con eso caí en la rutina exacta en un minuto.

---

## Cuatro teorías mías que eran falsas

Las anoto porque ocuparon buena parte de la sesión:

- «El bocadillo gasta demasiados sprites» → medido: gasta **cuatro menos**
  que en la v128, que funcionaba.
- «Se dibuja el rótulo de aldea sobre la escena» → sólo hay **1** sprite con
  sus patrones, no 30. Aquella cuenta fue numerología.
- «El bucle de limpieza de CG desborda» → encaja justo, no se pasa.
- **Y una que estuvo a punto de costar caro:** iba a redirigir tres saltos
  (`$C149`, `$C187` y otro) creyendo que entraban al rótulo. Ninguno de esos
  bancos mapea el 0x0C: su `$DE4B` es **otra rutina distinta**. Lo paró un
  assert al obligarme a mirar los bancos. Si llego a construirlo, habría
  desviado tres funciones ajenas.

---

## El arreglo

Mover el bloque de aldea dos bytes (`0x2FB8C` → `0x2FB8E`), restaurar el
terminador, y repuntar 6 direcciones del código y 16 punteros de listas.

**Verificado:**

```
lista del bocadillo   34 registros y terminador OK, idénticos a la v128
bocadillo simulado    34 sprites, 5 filas limpias, 0 con paleta rara
escena                42 sprites de 64   (antes 63, al borde)
los 10 rótulos        caja y texto correctos, todos dentro del bloque
```

Intactos: mapa, textos de padres, intro, tutorial, los tres niveles
ocultos, fuente, tablas de glifos, fuente del menú y botón II.

---

## Para probar

- **La escena de los padres**: sin rectángulo, con el diálogo completo y el
  sonido sonando dos veces.
- De paso, un repaso a los rótulos del mapa y de las aldeas: he movido el
  bloque entero, así que conviene confirmar que siguen bien.

---

## Si sale bien, esto entra en la versión oficial

- Los tres niveles ocultos traducidos
- Mayúsculas y minúsculas alineadas
- Tildes de `FÁCIL` / `DIFÍCIL` corregidas
- El bloque negro de la escena de los padres
- El sonido cuádruple al recibir dinero y kibidango
- Los rótulos del mapa y las aldeas, sin huecos ni columnas vacías
- El `$FD` de pausa que el tutorial había perdido

---

## Lo siguiente: menú de SELECT y pausa (RUN)

Ya tengo localizadas las lecturas del mando:

```
SELECT   0x1126C   0x1B2E5   0x43B99   0x19376
RUN      0x02949   0x1858A   0x185A9   0x1A806   0x429C9
```

Tu intuición de que son **gráficos y no texto** encaja: esas pantallas
muestran japonés correctamente, cosa que el motor de texto no haría.

El primer paso será un state con cada menú abierto para volcar el fondo y
confirmarlo. Si es como dices, te paso la imagen completa para que la
edites, igual que con el cartel del Nekketsu.
