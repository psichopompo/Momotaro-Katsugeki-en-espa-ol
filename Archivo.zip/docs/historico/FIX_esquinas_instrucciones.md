# Las dos esquinas izquierdas abiertas — dónde está y cómo se cierra

## El fallo

Medido sobre la captura (219×138). El borde izquierdo tiene **un píxel sin
trazo** en la transición de la diagonal a la vertical, arriba y abajo:

```
   IZQUIERDA (rota)        DERECHA (correcta)
y=36  .#WWWW                 WWWW#.
y=37  .WWWWW   <-- hueco     WWWW#.
y=38  #WWWWW                 WWWWW#
```

En la derecha el trazo baja **dos filas por columna** (x190, x190, x191,
x191). En la izquierda salta de x=25 a x=24 y deja una fila sin trazo. Por
ese píxel se escapa el blanco del interior.

## Los dos píxeles exactos

```
pantalla y= 37  ->  tile 19C (esquina SUP-IZQ), fila 13, columna 0
pantalla y=100  ->  tile 19E (esquina INF-IZQ), fila  3, columna 0
```

Confirmado volcando el CG del state `Aldeana.state`: en `19C` la fila 13 es
`.#WWWW` cuando debería ser `##WWWW`, igual que la fila 14.

## El color

El negro del marco es el **color 6** de la paleta del sprite, no el 0.
En planos: `6 = 0b0110` → **planos 1 y 2 a uno**, planos 0 y 3 a cero.

## Dónde tocarlo en la ROM

El CG de las esquinas está **comprimido** en `ROM 0x3D401` (mismo stream que
la entrada 147 del diario). Descomprime a 256 B = celdas `19C` y `19D`,
verificado byte a byte contra la VRAM del state.

Estructura: **4 unidades de 32 B por celda**, cada unidad son 2 planos
entrelazados (bytes pares = plano A, impares = plano B).

```
unidad 0 -> planos 0 y 1
unidad 1 -> planos 2 y 3

celda 19C, fila 13:
    plano1 = u0[27] = $3F  ->  $BF     (poner el bit 7)
    plano2 = u1[26] = $FF  ->  $FF     (ya está)
```

**Basta con poner el bit 7 del plano 1.** Lo mismo para `19E` en su fila 3.

Como el stream está comprimido: descomprimir con `tools/descomp_cg.py`,
tocar el byte y recomprimir. Ese módulo tiene el round-trip validado.

### Alternativa más simple

Si el bocadillo recarga su CG cada vez que se abre, es más barato parchear
la VRAM justo después de la carga: son **2 words**.

## Verificación

`tools/fix_esquinas.py` aplica el arreglo sobre un volcado de VRAM y enseña
el antes/después:

```
celda 19C fila 13:  antes .#WWWWWW   después ##WWWWWW
celda 19E fila  3:  antes .#WWWWWW   después ##WWWWWW
```

Comparativa visual en `capturas/FIX_esquina_sup.png` (izquierda como está
ahora, derecha corregido).
