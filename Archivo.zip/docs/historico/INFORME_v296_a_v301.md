# Informe v296 → v301 · Las tiendas, el HUD y la ©

Para el otro chat. Todo lo que sigue está medido; donde hay hipótesis, se
dice. Incluye **tres errores propios** con su causa, porque son la parte
más útil del informe.

**ROM vigente: `roms/momotaro_es_v301.pce`**
MD5 `ec66b395a3132a5f322e3dfc9b549726` · CRC32 `302ED78E`

---

## 0. Resumen

Estaba abierto desde hacía decenas de versiones: las tiendas se veían con
ruido y, al salir, el HUD quedaba corrupto. Causa encontrada: **un byte de
un glifo pisaba un contador de bucle**. Con eso resuelto, el HUD ya no se
rompe y el CG de la tienda deja de arrasar la VRAM.

Queda pendiente el texto del bocadillo de tienda, que necesita reubicar 47
glifos — y eso exige un inventario que aún no está completo.

---

## 1. La pista que lo desbloqueó

David:

> «cuando salimos de las tiendas, el HUD queda corrompido, pero al salir de
> la aldea y volver a entrar ya se ve bien.»

Que un síntoma **se cure solo al recargar la escena** significa que el
código está sano y lo que está mal es la VRAM. Eso descarta de golpe toda
la lógica y obliga a buscar un volcado que se pasa de largo.

---

## 2. La causa raíz

`0x3DBE8` **no es un glifo: es el contador de bloques del CG del bocadillo
de tienda**, que lee `$C5F3` (ROM `0x105F3`, banco `$08`):

```
C5F3  LDA #$1E / CLC / ADC $20 / TAM #$04    mapea el banco $1E
C5FA  LDX $5BE8                <-- CONTADOR  = ROM 0x3DBE8
C5FD  LDA #$E9 / STA $14                     origen $5BE9 = ROM 0x3DBE9
C601  LDA #$5B / STA $15
C605  PHX / JSR $861F / PLX / DEX / BNE $C605
```

Los cinco llamantes fijan antes el destino `$3B00` = celda `$0EC`.

```
                 0x3DBE8    bloques   celdas escritas
japonesa           $18         24     $0EC .. $103
v296               $00        256     $0EC .. $1EB
```

**`LDX <cero> / DEX / BNE` da 256 vueltas, no cero.** El HUD son los tiles
`$1B0-$1BF` y cae dentro. Ese byte es la fila 0 del glifo 177 (la `q`): al
ampliar el alfabeto se dibujó encima del contador.

### Verificación

Descomprimiendo 256 celdas desde `0x3DBE9` al destino `$0EC` y comparando
**los planos 0-2** (el motor de texto solo escribe el plano 3) contra
`9_tienda_v296.state`: idénticos en `$0EC..$102`, primer fallo en `$103`.
23-24 celdas y corte justo ahí = **exactamente las 24 del japonés**.

### Por qué el HUD no se recuperaba

`$D2B1` (ROM `0x1D2B1`, banco `$0E`) repinta el HUD hacia `$6C00` = celda
`$1B0`, pero con caché: `LDA $3B3C,X / CMP $3B2E,X / BEQ`. Si la vida y el
dinero no han cambiado, no repinta aunque su CG esté destruido. La
invalidación (`$E912`, ROM `0x01912`) solo corre al recargar la escena.

---

## 3. La © del título

David: *«tendría que poner ©1990 HUDSON SOFT, pero pone É1990.»*

La cadena está **en claro** en `0x18E75`: `<@1990HUDSONSOFT...`. La pantalla
de título tiene **motor y fuente propios**, distintos de todo lo demás:

```
motor    $CE3A (ROM 0x18E3A), SBC #$30
glifos   16 B cada uno, banco $02, vía $F589 (índice*16 + $4000)
```

`$40 - $30 = 16` → glifo 16 = ROM `0x04100`. Alguien lo reaprovechó para
una `É`. Comprobado que **ninguna otra cadena de ese motor usa `$40`**
(barridas todas las del banco `$0C` terminadas en `$FF`), así que
restaurar el símbolo japonés es limpio.

Inventario de esa fuente: solo **tres** glifos modificados en todo el banco
`$02` — el 16 (`$40`, la ©), el 36 (`$54`, la `T`) y el 43 (`$5B`, una `Ó`
para "BOTÓN"). Los dos últimos se conservan.

---

## 4. El "palito" de la q

En la v300, con el contador ya a `$18`, David vio que la `q` tenía un
palito encima. **No era un glifo mal dibujado: era el contador.**

`0x3DBE8` es a la vez el byte que lee `LDX $5BE8` y la fila 0 del glifo
177. El `$18` se dibuja literalmente como `...##...`.

Es la misma colisión vista desde el otro lado: antes el glifo pisaba al
contador, ahora el contador pisaba al glifo.

**Arreglo**: `$5BE8` tiene **un solo lector** en toda la ROM, así que se
mueve el parámetro, no el glifo (4 bytes en vez de reubicar dibujos):

```
0x3DEA7  $FF -> $18     nuevo contador (lógico $5EA7), en el relleno
                        que hay tras el stream (345 B libres)
0x105FA  AE E8 5B -> AE A7 5E     LDX $5BE8 -> LDX $5EA7
0x3DBE8  $18 -> $00     la q recupera su fila 0 limpia
```

---

## 5. Tres errores propios

### (a) La entrada 134 del diario es falsa

Dice que el HUD usa los patrones `$360-$37F`. **No.** Medido en la SAT: son
los **`$1B0-$1BF`** (pal 12/13/14). `$360-$37F` está a cero en los cuatro
states, aldea sana incluida, así que compararlo no medía nada.
*Causa*: me fié de un rango escrito en el diario sin releer la SAT.

### (b) La v298 movió 47 glifos y rompió media ROM

Para liberar el stream moví los glifos 177-223 a los huecos 2-48 y repunté
las tablas f0 (`$9CF3`) y f1 (`$9CB3`). Comprobé que los destinos
estuvieran libres **mirando solo esas dos tablas**.

Hay al menos **tres más con índices de glifo DIRECTOS**:

```
parrilla de entrada  0x1BBBA   12 índices en 177..223
tabla del Jizo       0x16AD6   12 índices en 177..223
canto Game Over      0x1F7B6    1 índice
```

Resultado en pantalla: password del Jizo con rayas horizontales, `Á` de
FÁCIL e `Í` de DIFÍCIL rotas, tiendas desordenadas, Momotaro moviéndose
mal. Revertido entero (norma 107).

*Causa*: es la **norma 255**, que yo mismo escribí tras romper la v293 por
buscar con un solo patrón, incumplida otra vez. Y las tres tablas estaban
listadas en mi propio resumen del proyecto.

### (c) Subí la p y la descuadré

Comparé la `p` con la `o` para decidir que estaba 1 px baja. Mal patrón de
comparación: la `o` no tiene descendente. Medido después:

```
g (167), y (185), q (177), p (176)   cuerpo filas 2..5 + rabillo 6..7
```

La `p` **ya estaba bien**; toda la fuente dibuja los descendentes así.
Revertido.

### (d) Error corregido dentro de la propia sesión

Afirmé que `$861F` volcaba 4 celdas por llamada y monté con eso una
explicación completa sobre `$9C32`/`$53FF`. Falso: escribe **una** celda;
las 4 iteraciones internas son los 4 grupos de planos del mismo tile. Lo
tumbó un control (la carga casaba al 76 % con el bocadillo del abuelo y al
8 % con la tienda) y hubo que rehacer el análisis desde cero.

---

## 6. Herramienta nueva

`tools/descomp_cg2.py` — el cargador de CG **real**:

```
$F1B9 (0x011B9)  primer byte = nº de bloques ; bucle -> $E5C2
$E5C2 (0x005C2)  mapea el banco $20 y llama a $861F
$861F (0x4061F)  UNA celda: 4 grupos x 4 planos -> buffer $313F,
                 y TIA $313F,$0002,$0080 (128 B) al VDC
$867F (0x4067F)  un plano de 8 filas hacia ($16),Y con paso 2.
                 bit 1 = literal ; bit 0 = REPITE el acumulador.
                 El primer bit, si es 0, hace CLA -> escribe $00.
```

Distinto de `$C1CC`/`$C206`, que es otro descompresor.

**Validado**: comprimir celdas de la VRAM real y buscarlas en la ROM las
encuentra literalmente (`$1B0`→`0x4104E`, `$1C0`→`0x4148F`,
`$1B8`→`0x41270`); descomprimir da 5120/5120 bytes exactos. Controles
negativos: origen +1 byte → 651/5120; destino +1 celda → 445/5120.

---

## 7. Estado de la v301

Cambios respecto a la v296: **4 zonas, 21 bytes**.

```
0x04100  16 B  el símbolo (c) del título
0x105FA   3 B  LDX $5BE8 -> LDX $5EA7
0x3DBE8   1 B  $18 -> $00   la q, limpia
0x3DEA7   1 B  $FF -> $18   el contador, en su hueco
```

Verificado por David en pantalla: HUD limpio al salir de la tienda, ©
correcta, password del Jizo bien, menú de carga bien, movimiento normal.

---

## 8. Lo que queda abierto

**El texto del bocadillo de tienda.** El stream `0x3DBE9..0x3DEA7` sigue
pisado por los glifos 177-223, así que el bocadillo se dibuja con lo que
haya. Ya no arrasa el HUD, pero el texto sale mal.

Para arreglarlo hay que reubicar esos 47 glifos (376 B). Hay sitio: los
glifos 1-111 son katakana del original, 888 B, intactos respecto a la
japonesa. **Pero antes hace falta el inventario COMPLETO de tablas que
indexan glifos.** Van cinco conocidas:

```
f0                   0x41CF3   64 entradas   códigos $A0-$DF
f1                   0x41CB3   64 entradas
parrilla de entrada  0x1BBBA   64 índices directos
tabla del Jizo       0x16AD6   64 índices directos
canto Game Over      0x1F7B6  128 (64 words)
```

Y puede haber más: el motor de tienda (`$9B0B`) usa su propia tabla
`$9C73`. **No mover ni un glifo hasta cerrar esa lista.**

Otra vía, más barata, siguiendo el patrón que funcionó con el contador:
en vez de mover 47 glifos, **mover el stream**. Los cinco llamantes fijan
el origen con inmediatos (`$5BE9`), así que serían 5 parejas de bytes más
un sitio donde quepan 703 B.

---

## 9. Normas nuevas (260-270)

```
260. El HUD son los patrones $1B0-$1BF, pal 12/13/14. La entrada 134
     ($360-$37F) es FALSA.
261. El cargador de CG es $F1B9 -> $E5C2 -> $861F -> $867F. $861F escribe
     UNA celda de 128 B por llamada.
262. El HUD se repinta con caché ($3B2E-$3B33 vs $3B3C-$3B41). Un síntoma
     que "se cura al recargar" es VRAM, nunca lógica.
263. LDX <cero> / DEX / BNE da 256 vueltas, no cero.
264. Antes de escribir un glifo, comprobar que ese offset no lo lee
     ninguna instrucción como PARÁMETRO.
265. Los glifos 1..111 (0x3D668..0x3D9E0, 888 B) son katakana y no los
     referencia f0 ni f1: es el mayor hueco libre.
266. La pantalla de título tiene fuente y motor PROPIOS. El código $40 es
     la ©: no reutilizarlo.
267. Los índices de glifo NO se leen solo desde f0 y f1. Hay CINCO tablas.
     Repuntarlas TODAS antes de mover un glifo.
268. La 'p' del password es el glifo 176 (0x3DBE0), posición 37 de la
     tabla del Jizo. Su último byte está pegado al contador.
269. Un byte de la zona de fuente puede ser a la vez PÍXELES y PARÁMETRO.
     Si el parámetro tiene un solo lector, mover el PARÁMETRO.
270. Las minúsculas con descendente (g, y, p, q) llevan cuerpo en filas
     2..5 y rabillo en 6..7. Compararlas con sus iguales, no con la 'o'.
```
