# Dos comprobaciones en Mesen — instrucciones exactas

Hay dos cosas que **no se pueden resolver leyendo la ROM** y que bloquean el
avance. Las dos son rápidas.

Usa la **v157** (`roms/test_horizontal_v157.pce`), la última validada.

---

## 1. ¿Está libre la RAM `$36F1`? (5 minutos)

Es donde quiero mover el búfer de texto para poder ampliar el bocadillo.
Está a cero en los 7 states que tengo, pero 7 instantes no son una prueba.

**Cómo:**

1. Mesen → `Debug` → `Debugger`.
2. Pestaña **Breakpoints** → `Add`.
3. Configúralo así:
   - Tipo: **Write** (solo escritura)
   - Marca **CPU memory** (no ROM, no VRAM)
   - Rango: **`36F1`** a **`3740`**
4. `OK` y deja el debugger abierto.
5. **Juega unos minutos tocando de todo:** habla con aldeanos, entra en una
   tienda y compra, abre el menú SELECT, abre el menú RUN, usa un arte,
   pasa de pantalla, muere una vez si puedes.

**Qué me tienes que decir:**

- **Si NO salta nunca** → perfecto, la zona es nuestra. Dímelo y sigo.
- **Si salta** → apunta la dirección de la instrucción que aparece arriba
  (algo como `$8A3F` o `$D412`) y el banco. Con eso busco otro sitio.

---

## 2. ¿Quién lee el quiz? (10 minutos)

Necesito 3358 bytes para el guion traducido y el mejor sitio es la zona del
quiz, pero **no consigo encontrar quién la lee**: no hay ninguna tabla de
punteros que apunte ahí, así que debe recorrerse de otra forma. Sin saberlo,
moverla es escribir a ciegas, y eso no lo hago.

**Cómo:**

1. Mismo debugger, `Add` otro breakpoint.
2. Configúralo así:
   - Tipo: **Read** (lectura)
   - Marca **ROM / PRG** (importante: **no** CPU memory)
   - Rango: **`4AEE4`** a **`4AEF4`**
3. Ahora **entra en el quiz** (el juego de preguntas). Si no recuerdas dónde
   sale, vale con jugar hasta que aparezca.

**Qué me tienes que decir:**

- La dirección de la instrucción donde para (arriba del todo del debugger).
- Y si puedes, dale a `Step` unas 10 veces y pásame lo que aparece en la
  ventana de desensamblado. Con eso reconstruyo cómo se recorre el bloque.

---

## 3. ¿De dónde sale el rabillo simétrico? (5 minutos, el más fácil)

Tenías razón: el rabillo simétrico **ya está en el juego**, en la misma celda
de VRAM (`1AD`) que el asimétrico. La intro carga un triángulo que cierra en
punta y los diálogos de aldeano cargan la cuña. Solo falta saber qué rutina
escribe cada uno.

**Cómo:**

1. `Add` un breakpoint:
   - Tipo: **Write**
   - Marca **VRAM**
   - Rango: **`D68`** a **`D70`**
2. Arranca el juego y **déjalo llegar a la intro** (la escena de los padres).

**Qué me tienes que decir:** la dirección de la instrucción donde para.
Con eso sé qué tabla de CG usa la intro y se lo pongo al bocadillo de
diálogo. No hay que dibujar nada.

---

## Por qué te pido esto y no lo hago yo

Lo intenté de tres maneras distintas leyendo la ROM y las tres fallaron:
buscar cualquier puntero en rango daba 1198 falsos positivos; exigir que
cayera en inicio exacto de bloque solo encontró la tabla de las artes; y
buscar el puntero como par de inmediatos dio cero. Los dos "aciertos" que
parecían buenos resultaron ser `LDA $CA67,Y` y `LDA $D664,Y` al
desensamblarlos — coincidencias dentro de otra instrucción.

Prefiero decírtelo así a inventarme una respuesta.
