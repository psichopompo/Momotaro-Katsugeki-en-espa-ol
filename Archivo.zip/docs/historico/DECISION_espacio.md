# El guion traducido no cabe: qué hay medido y qué opciones tenemos

Estado: **los 87 textos están traducidos** (`docs/traduccion.py`), ninguno usa
un carácter que no exista en la ROM. Falta decidir **dónde se guardan**.

---

## El número

```
guion japonés    5415 B
guion español    8773 B     +3358 B   (162 %)
```

No es un fallo de la traducción: es lo que pasa al pasar de kana a alfabeto
latino. Es exactamente el «pie del 45» de David, con número.

---

## Dónde vive el texto (medido)

El motor mapea `TAM #$04` (MPR2, `$4000-$5FFF`) e inmediatamente
`INC A / TAM #$08` (MPR3, `$6000-$7FFF`). Los punteros llegan a `$6446`, así
que la ventana real del texto son **16 KB**:

```
$4000-$7FFF  =  ROM 0x48000-0x4BFFF
```

Y está llena:

| tramo | tamaño | qué es |
|---|---|---|
| `0x48000..0x480E8` | 232 B | tabla de 116 punteros |
| `0x480E8..0x48C71` | 2953 B | vítores del público (ancho fijo 18) |
| `0x48C71..0x48F91` | 800 B | mensajes de dinero y varios |
| `0x48F91..0x4A4B9` | 5416 B | **el guion** |
| `0x4A4B9..0x4B93B` | 5250 B | final, créditos, quiz, minijuego |
| `0x4B93B..0x4C000` | **1733 B** | **libre (`$FF`)** |

**Faltan 3358 B y hay 1733.** No llega.

> Corrijo un dato que yo mismo tenía mal en el diario: detrás del guion **no
> hay relleno**, hay 5250 B de contenido vivo. Lo decodifiqué: está el texto
> del final, los créditos, un quiz y un piedra-papel-tijera.

---

## Opciones, con su coste real

### A. Diccionario de palabras repetidas
Sustituir las 52 palabras que más se repiten por un código de 1 byte.

- ahorro bruto 1119 B, coste del diccionario 351 B → **neto 768 B**
- hay que escribir el descompresor y meterlo en el motor
- **no basta** (768 de 3358)

### B. Quitar el relleno de los vítores
Son 2953 B de los que **670 son espacios** de la rejilla de 18.

- ahorro **~670 B**
- exige tocar la rutina de vítores, que usa ancho fijo
- **no basta**, y los vítores también hay que traducirlos (crecerán)

### C. Mover el final/créditos/quiz a otro banco
Esos 5250 B **no los apunta la tabla de 116 punteros**: los alcanza otro
código. Si se mueven, el guion tendría `1733 + 5250 = 6983 B` libres para
crecer 3358. **Sobraría de largo.**

- es la opción que más espacio da
- falta medir quién los lee y con qué punteros (rastreo estático dio
  demasiado ruido; hace falta breakpoint en Mesen)

### D. Byte de banco por entrada en la tabla
Pasar las 116 entradas de 2 B a 3 B (banco + puntero) y que el motor cargue
el banco de la tabla. Quita el techo **para siempre**.

- **más caro de lo que dije**: hay **8 sitios en 4 bancos** que mapean esta
  ventana (`$819E`, `$86D4`, `$9AD2`, `$9D53`, `$899A`, `$9768`, `$97F4`,
  `$995F`), no uno solo como afirmé. Hay que revisarlos todos.
- coste: 116 B más de tabla + parche en cada punto de mapeo

### E. Recortar la traducción
**Descartada.** David pidió fidelidad. Recortar 3358 B es mutilar el guion.
Primero se agranda el contenedor.

---

## Recomendación

**C primero, D si C no da lo suficiente.** C no toca el mapeo de bancos (lo
más delicado) y da 6983 B de un golpe. A y B se pueden sumar después si
hiciera falta, pero por sí solas no resuelven nada.

---

## De paso: el ancho ya no cambia el resultado

Con los 87 textos ya traducidos:

```
ancho 20  ->  156 páginas,  máx 3 por texto
ancho 22  ->  142 páginas,  máx 3 por texto
```

Catorce páginas de diferencia en todo el juego y **el mismo máximo**. El
argumento para elegir 22 se cae: **20×4 por proporción en pantalla**.
