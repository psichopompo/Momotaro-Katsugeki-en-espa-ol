# Informe v306 → v334

Todo lo que sigue está medido. Donde hubo hipótesis, se dice. Incluye los
**errores propios** con su causa, porque son la parte más útil.

**ROM vigente: `roms/momotaro_es_v334.pce`**
MD5 `7608edb92eeccae3eed71f8c618d1a0e` · CRC32 `130477DD`
Parche: `parches/momotaro_v334.ips` (contra la virgen, round-trip verificado).

> **Registro de pendientes: `docs/PENDIENTES.md`.** Creado a petición de
> David — se estaban perdiendo cosas mencionadas hace decenas de versiones.

---

## 0. Resumen de la tanda

| Ver | MD5 | Qué |
|---|---|---|
| v307 | `442161df13429b5af286cebbc6749dc1` | Los 48 diálogos de tienda, maquetados y revisados |
| v308 | `05de5af123244e3d970f78a5d78057bf` | La **novena** tienda (posada de 100) + «Cura vida y momo» |
| v309-v311 | — | **REVERTIDAS**. Tres intentos fallidos con el menú SELECT |
| v312 | `be7b3223ea3f49de5b0ec1d4f47efacc` | Menú SELECT: VIDA → SALUD, con el rediseño de David |
| v313 | `5fccbebdc0520496dd6135dcd6835527` | Descripciones de los onigiri: Salud/Técnica/Todo +1. |
| v314 | `d3ee96488f99aa2cc4abe9d0a4ebb2f3` | **Arreglo del bug del jefe de Kintaro**: tabla de escenas `0x1ED6E` |
| v315 | `27b3557eea4bf760143ded5309deeded` | Los **19 vítores** de la pancarta de fin de fase |
| v316 | `834afa5be5f535fea56032d065eb62dd` | **Dados** (6 bloques) + los 2 mensajes del **ermitaño** |
| v317 | `ed42393598926fe107e11a6121c32099` | Los **14 nombres de técnica** + 2 correcciones de traducción |
| v318 | `7291a7d8a56733916ad4fada899198e4` | **Menú RUN**: 10 destinos, `Usar`/`Dejar` y la línea del ermitaño |
| v319 | `8e8fbe16b6d078f1ca159a36a8a0971e` | **Dados rehechos**, «poco a.» y los 19 vítores **centrados** |
| v320 | `9469caf05942325ee122a06abebc1273` | **REVIERTE** la tabla de rótulos que rompí en la v318 + «Taketori» |
| v321 | `1019a547950fe60515c3886f961f4cf7` | «Ve. Momotaro.os» → «Ve, Momotaro.» (solape con el diccionario) |
| v322 | `a286de61353582b79b2a206063528ecd` | El «texto raro» del ermitaño: escribí 14 B corrido |
| v323 | `7056a5c3eaac15e5fdef6a2839912ef3` | El ermitaño, **bien**: había movido el marcador de sustitución |
| v324 | `fd2fc68e3245bfdd78391d6afb6f4d4e` | **El QUIZ entero** (40 preguntas, 120 opciones) + «Aldea Bambú» |
| v325 | `e0aaf6e16c625afda2961b5f8dc92b94` | P21 y P35 corregidas; el `$` era el ryo, no un dólar |
| v326 | `20bdaae7ff13351c08f577e54d35638c` | **12 de 14 técnicas estaban rotas** desde la v317. Repuntadas |
| v327 | `3e60866ab88d56b5191997a96c099460` | El `©`: alias → bytes directos. Preguntas a 15 columnas |
| v328 | `936a68d560b4e9ef325add0490be0c34` | **Restaurado el bloque limpiador** que pisé en la v327 |
| v329 | `2108160a50b517e26164073cd7662e95` | «¡Yo soy el ermitaño …!» + 7 preguntas reformuladas |
| v330 | `39fa8d9d2c62f12108988facfb8d2df3` | **Hien**, no «Vuelo»: son nombres propios, no artes |
| v331 | `605160e0e669d9dd607ee2dfeab7dc90` | La `p` de las opciones (`KaÇÇa`) y «Faltan momos» → «0 momos» |
| v332 | `9de8abb9f2197a1f1cafdb235ce846ae` | El corte de **página** del ermitaño y «Toma: +Vuelo» |
| v333 | `ffdefd8dc6c8d83371ff259e2ecb92ae` | «la isla de los ogros», «¡A por los ogros!» y 8 B de japonés oculto |
| v334 | `7608edb92eeccae3eed71f8c618d1a0e` | «Los ogros no te ven.» + inventario de restos invisibles |

---

## 1. v307 — Los diálogos de tienda

**Método nuevo que conviene mantener.** El constructor **no lleva las frases
escritas dentro**: las lee de `docs/MAQUETACION_tiendas.md`, el documento que
revisa David. Así se inserta exactamente lo aprobado, sin copiar a mano. Y
comprueba que los punteros del documento sean **exactamente** los de la tabla
`0x10854`.

Tres fallos propios cazados por los asserts antes de sacar la ROM:

1. `$4834` aparece **tres veces** en el documento (las ranuras que comparten
   puntero) y solo corregí una. El parser se quedó con la última y coló
   «¡A por los ogros» sin cierre. Añadido un assert que falla si un mismo
   puntero aparece con dos propuestas distintas.
2. Dos frases sin punto final por llegar justo a 16 caracteres.
3. El de siempre: recortar a 16 sin releer el resultado.

---

## 2. v308 — La tienda que faltaba

David: *«en una de las posadas del pingüino el texto no está traducido»*, con
captura de la nuestra **y de la japonesa**. Esa segunda captura fue la clave:
me dio el texto exacto a buscar.

**[HECHO] La tabla de tiendas tiene NUEVE entradas, no ocho.**

```
t0..t7   0x10854..0x108B3   las conocidas
t8       0x108B4            $4C57 $485C $4834 $487E $4834 $4834
t9       0x108C0            $C8D2 ...  -> fuera del rango $4000-$5FFF
```

La novena es la **posada de 100 monedas**. Sus ranuras [1]-[5] comparten
puntero con las otras posadas, por eso ya salían traducidas: **solo la
ranura [0] (`$4C57`, ROM `0x48C57`) tiene texto propio**.

*Error propio*: di por hecho que eran 8 sin comprobar dónde acaba la tabla.
Conté lo que veía en vez de medir el límite. El síntoma tardó en salir
justamente porque 5 de las 6 ranuras estaban bien.

**«Cura ambos» era ambiguo** (lo detectó David). El japonés dice
`カラダト ワザガソレゾレ 1コ カイフク` = «recupera 1 de cuerpo y 1 de
técnica».

**Un assert mío, mal planteado.** Puse
`assert rom[R+32:R+48] == jp[R+32:R+48]` para detectar desbordamiento. Saltó,
pero era **falsa alarma**: esos bytes ya llevaban traducción nuestra de una
versión anterior. **Un assert de no-desbordamiento se compara contra la BASE
de la que se parte, no contra la ROM japonesa.**

---

## 3. v309-v311 — Tres ROMs malas por una sola causa

Esta parte es la más importante del informe.

### La causa raíz

Estuve **horas midiendo sobre `docs/select_vram.bin`**, que es un volcado de
la **ROM JAPONESA**. Describe una pantalla que ya no existe: en él la BAT
tiene los kanji y el CG está en otro sitio.

David lo dijo en su segundo mensaje: *«si ese png ya estaba en el juego, sólo
estamos cambiando VIDA por SALUD»*. Tenía razón y tardé demasiado en
comprobarlo.

### Lo que hay de verdad (medido sobre un savestate real de la v308)

```
CG   0x0F3D9  UN stream de 201 tiles -> VRAM $100..$1C8
              cargador $D32D (ROM 0x1B32D): banco $07, puntero $53D9
              (la japonesa lo tenía en el banco $3F, puntero $58F2 = 0x7F8F2;
               el diario seguía diciendo eso y estaba OBSOLETO)
BAT  0x1E7EA  es la JAPONESA, idéntica a la ROM original. Difiere de la
              pantalla real en 160 celdas: la buena la compone el juego en
              ejecución. NO se puede repuntar desde la ROM.
```

### Los cuatro errores, en orden

1. **Medir sobre el volcado japonés.** Origen de todo lo demás. Con esa foto
   vieja calculé que hacían falta 97 tiles nuevos y 2219 B, y me puse a
   buscar huecos para un problema inventado.
2. **v309: reubicar la BAT** a un hueco del banco `$23` y repuntar su
   cargador. Destrozó el fondo del menú, porque esa BAT no es la que usa el
   juego.
3. **v310: dibujar yo las letras** en vez de copiarlas del PNG. Inventé una
   fuente de 6×8 que no se parecía en nada, y luego fui recortándola de 43 a
   34 px peleándome con el encaje en vez de parar y preguntar.
4. **v311: diagnosticar mal los conflictos.** Le dije a David que sus erres
   eran distintas y que moviera ORO y ARMADURA a la derecha. **Falso**: las
   erres eran idénticas; lo que cambiaba era la letra **vecina** que se
   colaba en la celda. Le hice revisar tres veces algo que estaba bien.

---

## 4. v312 — El menú SELECT, resuelto

### La solución la encontró David

> «¿Se solucionaría si cada letra ocupara una celda de 8x8px? TÉCNICA
> ocuparía 7 celdas, ARMADURA 8, OBJETOS 7, SALUD 5, ORO 3, ARMA 4,
> ARTES 5.»

**Sí, y es como está hecho el original.** Verificado sobre la v308: cada
letra del menú ocupa exactamente una celda, y la misma letra usa el mismo
tile.

Por qué era imprescindible: **el juego reutiliza tiles entre rótulos**.

```
$1A3 = la A final de TÉCNICA  y  la A inicial de ARMADURA
$1A8 = la R de ORO            y  la R de ARMADURA
```

Si una letra se derrama sobre la celda vecina, esas dos celdas piden dibujos
distintos del **mismo** tile y es imposible. Con una letra por celda
coinciden solas.

Con el PNG rehecho así: **100 celdas cambian, CERO conflictos**.

### El cuelgue de las aldeas

David probó la primera v312: *«el menú sale bien, pero ahora no entra en las
aldeas, se queda colgado. Suena la música y vemos la aldea y el rótulo, pero
no podemos movernos.»*

**[HECHO] Le pedí al descompresor más tiles de los que hay.**

```
stream real   0x0F3D9 .. 0x0FE2B   201 tiles
relleno $FF   0x0FE2B .. 0x10000   469 B
banco $08     0x10000              código de aldeas y tiendas
```

Llamaba con 256. El descompresor pasaba de largo el relleno y **seguía
leyendo el banco `$08` como si fueran gráficos**; al recomprimir, machacaba
**289 bytes de código**. El menú se veía bien porque los 201 primeros tiles
sí eran correctos: el daño estaba fuera de la pantalla.

**El assert no lo cazó** porque su límite salía del mismo descompresor mal
llamado. Es la norma 212 —escrita en este diario— incumplida otra vez.

Asserts nuevos: los 201 tiles deben coincidir **al 100 %** con la VRAM del
state; el stream no puede acabar pasado `0x0FE2B`; y **ningún byte de
`0x10000` en adelante puede cambiar**.

---

## 5. v313 — Las descripciones de los onigiri

Cadena de correcciones de David:

1. «Cura ambos.» → ambiguo.
2. «Recupera 1 vida.» → engañoso: la barra son **puntos** de vida, no vidas.
3. «momo» no lo entiende nadie, y el menú SELECT llama **TÉCNICA** a esa barra.

```
Onigiri:    Salud +1.
Manjar:     Técnica +1.
Banquete:   Todo +1.
```

Las tres con punto final. Norma de David, literal: *«que falte un punto final
para mí es un error garrafal, y si das por hecho que al no caber el punto es
mejor no ponerlo, te equivocas. Ante algo así siempre hay que buscar una
alternativa.»*

Verificado que **las 20 descripciones** acaban en punto.

---

## 6. Normas nuevas (271-282)

```
271. La tabla de tiendas 0x10854 tiene NUEVE entradas y acaba en 0x108C0.
272. Cuando varias ranuras comparten puntero, un fallo puede quedar TAPADO.
273. Un assert de no-desbordamiento se compara contra la BASE, no contra la
     ROM japonesa: ahí puede haber ya traducción de versiones anteriores.
274. El constructor de textos debe LEER las cadenas del documento revisado
     por David, no llevarlas escritas dentro.
275. ANTES de medir una pantalla, comprobar que el volcado corresponde a la
     ROM en la que se trabaja. Un state viejo es una foto vieja.
276. El CG del menú SELECT está en 0x0F3D9 (banco $07, puntero $53D9).
     El diario decía 0x7F8F2: eso es la ROM japonesa.
277. La BAT del menú SELECT de 0x1E7EA es la JAPONESA. La real la compone el
     juego en ejecución. Solo se pueden REDIBUJAR tiles.
278. El menú SELECT reutiliza tiles entre rótulos. Regla de oro: UNA LETRA
     POR CELDA de 8x8, sin invadir la vecina, y la misma letra siempre igual.
279. Al adaptar un PNG de David, COPIAR sus píxeles. No redibujar «con el
     mismo estilo». Si algo no cabe, se le dice y se para.
280. El stream de CG del menú son 201 tiles, no 256. Pedir más hace que el
     descompresor lea el banco $08 y al reescribirlo cuelgue el juego.
281. [REPITE la 212] Un assert cuyo límite sale del MISMO cálculo que se
     quiere verificar no comprueba nada. Atarlo a algo independiente.
282. Todo constructor que escriba en un banco debe llevar un assert de que
     NO se toca ni un byte del banco siguiente.
```

---

## 7. Estado del proyecto

**Traducido y verificado en pantalla:** menú SELECT completo, menú de Game
Over, tiendas (9, con sus 48 diálogos y 20 descripciones), password del Jizo,
bocadillos del abuelo y aldeanos, rótulos de aldea, pantalla de título con su
©.

**Lo que queda**, por orden de dificultad:

1. **Vítores, finales y créditos.** El bloque está localizado en
   `0x48401..0x4847C` (seis frases separadas por relleno `$A0`) más los
   tramos de `0x480EA`-`0x483CE`. Criterios ya fijados por David: mayúscula
   inicial, punto final salvo exclamaciones, **Momotaro** sin `u`, **Sólo**
   con tilde.
2. **El menú RUN en cascada.** Hoy se abre en tres recuadros escalonados que
   revientan el límite de sprites por línea. David quiere que solo se vea el
   recuadro activo, siempre centrado donde va hoy el segundo. Se navega con
   I / RUN para bajar y II para volver. **Es lo más difícil que queda.**
3. **Textos en gráficos** (sprites que llevan texto dibujado).
4. **Passwords originales traducidos** y vinculados al valor interno: que
   escribir «Iwasaki canta mal» cargue el password real.
5. **Testeo profundo** y suavizar mutilaciones.


---

## 6. v314 — El bug del jefe de Kintaro. Error propio de la v237.

### El síntoma

David: en la subfase del jefe final de la aldea Kintaro no aparecían ni el
jefe ni ningún elemento activo, solo el HUD, y Momotaro entraba cayendo
cuando debía entrar caminando (viene de la etapa anterior).

Yo diagnostiqué mal la fase: creí que era Issunboshi porque era donde él
entraba. **Lo corrigió él**: cargando su state en la ROM japonesa aparece
la fase correcta, luego el problema no estaba donde yo miraba.

### La medición que lo señaló

Diff de RAM entre el state japonés bueno y el nuestro, 120 B distintos:

```
              $3B00 $3B01 $3B02
japonesa (OK)   05    00    03
nuestra  (OK)   05    00    03
bug             05    00    FF
```

`$3B02` se escribe en un solo sitio, `$4836` (ROM `0x42836`), **idéntico a
la japonesa**. Lee de una tabla de 8 punteros en `0x1ED6E`:

```
        ES        JP
[5]   $7F70    $4E67
[6]   $7FE7    $4E98
[7]   $7FE7    $4EC9
```

Son los 6 bytes que repunté en la v237.

### Por qué no podía funcionar

Metí texto en `0x4BF70` (banco `$25`) y le di la dirección `$7F70`
suponiendo la ventana MPR3. Pero esa rutina mapea el banco `$0F` en
**MPR2**, y MPR3 vale `$1E` en los cuatro states. `$7F70` se lee del banco
`$1E` = ROM `0x3DF70`, que es **relleno `$FF`**.

Predicción antes de comprobar: `$3B02` debe valer `$FF`.

```
JP: primer byte de $4E67 = $03  ->  $3B02 = 03   = state bueno
ES: primer byte de $7F70 = $FF  ->  $3B02 = FF   = state del bug
```

Cuadra al byte. Esos registros no son texto: son **datos de escena**.

### El origen del error (norma 288)

Dos bancos dan la MISMA dirección CPU:

```
ROM 0x48E2A  banco $24  ->  $4E2A   TEXTO del Jizo
ROM 0x1EE2A  banco $0F  ->  $4E2A   DATOS de escena
```

Busqué «quién apunta a `$4E2A`», encontré `0x1ED76` y di por hecho que era
el puntero del texto. **Nunca miré el contenido apuntado.**

### Lo que no se perdió

El diálogo del Jizo **nunca dependió de esa tabla**: vive entero en
`0x48E2A`, 235 B, y lo lee `$CC0C` del banco `$0E`. La «parte 2» que
escribí en `0x4BF70` estaba **huérfana desde el primer día** — su único
apuntador era la tabla de escenas. Nunca se mostró en pantalla.

**Arreglo: 6 bytes.** Verificado siguiendo el puntero como hace el motor.

---

## 7. v315 — Los vítores

### La tabla estaba donde no la buscaba

Mi inventario previo decía «44 frases sin tabla». **Falso**: troceé la zona
por rachas de `$A0` creyendo que separaban frases, cuando son relleno
*dentro* del bloque. Inventé 44 fronteras y luego busqué punteros a
offsets que me había inventado yo.

Son **19 bloques** de 2 líneas × 18 columnas, con tabla en `$C433`
(ROM `0x16433`), en el banco `$0B` junto al código.

```
$C419  LDA $3B00 / ASL / ASL / ORA ($3B28 & 3) -> Y
       LDA $C459,Y      28 B = 7 mundos x 4 fases
       LDA $C433,Y      19 punteros
$C997  banco $24 en MPR2; LDX #$02 líneas, LDX #$12 columnas
```

Verificado: el simulador reproduce los **72 B exactos** del buffer `$2593`
del savestate de David.

### Codificación

`tools/charset_vitores.py`, nuevo. El motor es `$9B0B`, el de las tiendas,
no el de menú: los alias `$5B/$5D/$5E` de `charset_oficial` pintarían una ©.
Tabla deducida de texto ya validado en pantalla y **contra-verificada**
reproduciéndolo byte a byte.

Prohibidos: `$5C` (conmuta el juego de glifos) y `$DE`/`$DF` (ponen carry y
pintan en la fila de arriba). El codificador aborta si aparecen.

### Los 4 huérfanos no entran

`$40E8 $4112 $4139 $4163` forman una cadena secuencial exacta que aterriza
en `$418A`. El japonés consume 42/39/42/39 B y el latino 36 clavados; el
sobrante solo se puede absorber con **pares** de `$5C`, y 3 es impar. Y
sigue sin saberse quién los lee. Se quedan en japonés.

---

## 8. v316 — Dados y ermitaño

### Rejilla de 2×16, no 2×18

Verificado contra el buffer `$2593` de los savestates `Juego dados.state` y
`Piedra, papel, tijera.state`.

```
DADOS      0x4AC9C   6 bloques encadenados
ERMITAÑO   0x4AE3B   2 bloques
TÉCNICAS   0x4AE86   14 cadenas con $00 — PENDIENTES
```

Los bloques van **encadenados**, así que se rellena con `$A0` hasta el
hueco original de cada uno en vez de escribir 32 B a secas.

### Dos errores propios que cazó David

**1. «Una parrafada de cuatro líneas».** Escribí que los dos bloques del
ermitaño eran continuación uno de otro. Falso: cada uno es un mensaje
completo y son **alternativos** (dos caminos a la misma técnica). Fallé por
ver que el primero acababa en «te concederé» sin traducir el japonés
entero. Norma 289.

**2. Los `\` no son saltos de línea.** David preguntó y la respuesta estaba
en su propia captura: `$5C` va **en pareja** encerrando `クイズ` y `ホイ`, y
en pantalla se ve esa palabra en katakana y el resto en hiragana. Es el
conmutador de juego de glifos. En castellano se quita.

### Los nombres de los juegos (decisión de David)

- Dados = *chō-han* → **«pares o nones»**, que funciona igual en lo esencial.
- PPT = *acchi muite hoi* → **«Mira hacia allá»**. No llamarlo «piedra,
  papel o tijera»: el jugador vería que no funciona igual.

---

## 9. v317 — Las técnicas, cerradas. Presupuesto real 96 B.

**No hay tabla de punteros.** Los 14 inicios reales no aparecen en la ROM en
ninguna forma. El motor cuenta terminadores `$00`, así que el reparto entre
las cadenas es **libre** y solo el total es fijo.

> [DESCARTADO] `0x2EE2A` parecía la tabla (14 words al banco `$25`), pero es
> una progresión aritmética `$4E56 + 6k` que coincide con las cadenas reales
> solo en 5 de 14, por azar. Cazada releyendo el contenido apuntado.

### [ERROR PROPIO, cazado antes de escribir] El presupuesto no era 107 B

Dije que los dos bloques del ermitaño liberaban 11 B y daban 107. Falso en
la práctica: esos 11 B están **delante** de la lista, y aprovecharlos exige
arrancarla en `0x4AE7B`, es decir **mover su inicio**. No se sabe cómo llega
el motor hasta ella (no hay tabla ni `LDA #$86`/`LDA #$4E` en 512 KB), así
que moverlo es repuntar a ciegas: el error de la v237.

```
PRESUPUESTO SEGURO = 96 B (0x4AE86..0x4AEE6, bloque intacto)
```

Lo que pidió David en primera instancia (`Ola`/`MomoOla` + `Parapunte` ×2)
daba 110 B. Eligió la **opción A**:

```
Vuelo Salto Rodar Giro Bomba Ola Parapunte
+Vuelo +Salto +Rodar +Giro +Bomba +Ola Parapunte
```

**92 B de 96**, 4 de relleno `$A0` al final. El `+` se lee como «versión
mejorada» y los dos `Parapunte` quedan idénticos, como en el original.

Verificado releyendo las 14 cadenas contando `$00` como hace el motor, que
la cola es relleno limpio y que el primer byte del quiz (`0x4AEE6`) no se
ha tocado.

### Dos correcciones de traducción

**1. `¿Jugamos, majo?` → `¿Te animas?`** El «majo» me lo inventé;
`doudai yatteikukai?` es «¿qué tal? ¿te animas?».

**2. `¡Bah, qué sosa!` → `¡Qué rácano!`** David preguntó a quién se refería
y por qué iba en femenino. Al releer el japonés, dos errores a la vez:

```
ケッ シケテルワネッ!  =  ke! shiketeru wa ne!
```

- **シケてる** no es «soso»: es **rácano, tacaño**. En una mesa de apuestas,
  «apuestas una miseria».
- **ワネ** es partícula final **femenina de HABLANTE**: marca que habla una
  mujer, la crupier. El femenino es de su boca, no del receptor — que es
  Momotaro, un chico.

En japonés esas partículas marcan al hablante; en castellano el género del
adjetivo marca al referente. **No son la misma marca gramatical.** Norma 291.

### Un assert que hizo su trabajo

El documento llegó a decir `¡Bah, qué cutre!` en un paso intermedio, pero en
la ROM v316 lo que había era `¡Bah, qué sosa!`. El assert de byte esperado
paró el constructor al primer intento en vez de escribir sobre lo que no era.

---

## 10. [ABIERTO] La pancarta, 4 px alta

Medido sobre la SAT del savestate:

```
marco   y = 112..176  -> centro 144
texto   y = 128..151  -> centro 139,5
```

4,5 px alto. El buffer tiene **4 filas**: las 0 y 2 son los dakuten, que en
castellano quedan vacías. Bajarlo 4 px lo centra.

No localizada la rutina que fija la Y (`$00B8` en la SAT). `LDA #$B8`
aparece 9 veces y ninguna es de la pancarta; la SAT se compone y se DMAea.
Sin prisa: David tampoco puede verificarlo hasta pasarse otra fase.


---

## 11. v318 — El menú RUN

### Lo que David detectó

Tres cosas de sus capturas de la v317: el ermitaño soltaba una línea en
japonés **antes** de la traducida, al usar un Arte salían `たびだちの村` y
`さいごのじぞう` sin traducir, y avisó de que *«sólo has buscado lo
relacionado con el arte de vuelo»*.

### El `$00` es un marcador de sustitución

`0x4AE18`, 35 B. El byte `$00` en +25 es donde el motor **inserta el nombre
de la técnica**:

```
キンモツヂャ! \ウヒャヒャ!  ワシハ <<TÉCNICA>>センニンヂャ!<<$80>>
= «¡prohibido! ¡ujujú! yo soy el ermitaño <<TÉCNICA>>»
```

Por eso salía «Vuelo» incrustado en japonés. Es el primer texto del
proyecto con sustitución dinámica. Traducido a `¡Nada de eso!` /
`Soy <<T>>.`, que cabe con el punto final incluso con `Parapunte` (9).

### Las demás artes: ya estaban

Barrido completo del banco `$21`. **Las acciones de las seis artes ya
estaban traducidas** y repuntadas a `0x434B5`-`0x43505` en una tanda
anterior: `Rodar`, `Salto`, `Azar`, `Vuelo`, `Giro`, `Oleada`. Lo que
faltaba era el texto que las rodea.

### Dos listas de destinos, las dos en uso

```
A)  tabla 0x43712 (14 entradas)  -> el MENÚ de destinos
B)  tabla 0x4379D ( 9 entradas)  -> el rótulo AL VIAJAR
    lector $ADA1: LDA $3B0E / ASL / TAX / LDA $B79D,X
```

La B la había dado por código muerto en la v268 y me equivoqué; ahora está
verificada con su lector.

### La solución: compartir cadenas

**Hueco de `$FF` en el banco `$21`: cero.** Y los «98 B libres» de
`0x42000` son una tabla de datos con ceros entremezclados — descartada
antes de tocarla (norma 232).

Pero la tabla A **ya comparte**: sus entradas `[0]` y `[3]` apuntan las dos
a `$B72E`. El motor no exige cadenas distintas. Apuntando las dos tablas a
las mismas 10 cadenas:

```
presupuesto 0x43737..0x4380A   211 B
escrito                         95 B    sobran 116 B
```

### El límite real: 8 celdas

Medido sobre la lista B, que centraba con espacios y daba **8 celdas
justas** en todas sus entradas. Cuatro nombres no cabían enteros y David
aceptó recortarlos a palabras más cortas, no a abreviaturas con punto:
`Kachiyama`→`Kachi`, `Issunboshi`→`Issun`, `Isla Ogros`→`Ogros`,
`Último Jizo`→`Jizo`.

Correcciones suyas aplicadas: `Inicial`→**`Partida`** (*«se llama Aldea de
la Partida»*, y `tabidachi` es literalmente «partida»), fuera `Jizo fin`
(*«no es lo mismo último que fin»*), y el **punto final** que faltaba en
las dos propuestas del ermitaño.

---

## 12. [BLOQUEADO] La casa mutilada y los 4 px de la pancarta

Los dos son el mismo problema: **la SAT no existe como tabla editable**. Se
compone en ejecución y se vuelca por DMA a VRAM `$7F00`. Comprobado:

- La SAT del savestate **no está en la RAM** como bloque contiguo.
- Sí coincide byte a byte con `VRAM[0xFE00]`, destino del DMA.
- Las listas estáticas que sí existen (`0x2FBA2`, 16 listas indexadas por
  anchura de rótulo) usan la celda `$708`, **no** las `$1A4`-`$1B5` del
  rótulo del mapa.
- No existe ningún registro `[48 03 8e]` en toda la ROM.

### La casa mutilada: solución ya elegida, falta poder aplicarla

```
ACTUAL                                 pico=16  pierde 6 px del tejado
tejado el primero                      pico=16  pierde 6 px de otro sprite
borde inferior 32px -> 16px            pico=14  LIMPIO pero rompe el marco
mapa (22-34) antes que rótulo (0-21)   pico=16  LIMPIO
```

Estrechar el borde queda **descartado**: medido que las dos mitades de cada
sprite dibujan (`izq=15/7 px`, `der=7 px`).

Queda reordenar la SAT. Cero píxeles perdidos, porque el descarte cae en el
sprite 20, que en esas 6 filas no dibuja nada.

**Falta la rutina que compone la SAT.** No se puede localizar por barrido
de bytes: hay que seguir el código desde el bucle del mapa, o un breakpoint
de escritura en VRAM `$FE00`. Ni B1 ni B2 se tocan hasta tenerla — escribir
a ciegas en la zona de sprites costó la v309 y la v293.


---

## 13. v319 — Tres errores propios que caza David

### (1) Los dados: troceo desplazado UNA LÍNEA

David: *«partes sin traducir, Par/Impar cortados, SÍ mal alineado»*.

Troceé el bloque desde `0x4AC9C`. **Empieza en `0x4AC8B`.** Cada «mensaje»
que traduje era la 2.ª línea de uno y la 1.ª del siguiente.

Estructura real, medida línea a línea:

```
L0+L1    bocadillo   0x4AC8B  0x4AC9C
L2       OPCIONES    0x4ACAE   <- ventana lateral, columnas 1 y 9
L3+L4    bocadillo   0x4ACBE  0x4ACD0
L5       OPCIONES    0x4ACE0   <- columnas 1 y 9
L6+L7    bocadillo   0x4ACF0  0x4AD00
L8+L9    bocadillo   0x4AD10  0x4AD22
L10+L11  bocadillo   0x4AD34  0x4AD44
```

**Las líneas de opciones no van en el bocadillo**: se pintan en una ventana
lateral estrecha, en **columnas fijas 1 y 9**. Yo puse `Par` en la col 2 e
`Impar` en la 11 → se salían, de ahí «Pa» e «I». Y `Sí` en la col 2 en vez
de la 1 era el desalineado.

`Impar` (5) no cabe en las ~4 columnas útiles. David acepta **`Par`/`Non`**,
que además es como se dice en castellano: «pares o nones».

**Qué falló:** validé el troceo contra el buffer del savestate y dio
coincidencia, pero **solo comparé dos filas de las cuatro**. Un
desplazamiento de una línea no se detecta así. Norma 292.

### (2) «poco a.» — punto en mitad de la frase

```
había:  ...aprendido hace poco a. / ¡apostar! Dicen...
ahora:  ...aprendido hace poco a  / apostar. Dicen...
```

Dos errores en uno: el punto partía «a apostar» y «apostar» llevaba una
exclamación que no toca. Redacción mía de una tanda antigua; el texto va
comprimido con diccionario (`0x4BA13`, banco `$24`), lo que lo hacía menos
visible.

### (3) Los vítores iban sin centrar

David: *«bien la traducción, pero la veo muy ajustada a la izquierda»*.

Medido: **el japonés centra sus vítores**.

```
JP  |    メデタシ メデタシ!      |   sangrado
ES  |Todos te llaman:  |            pegado a la izquierda
```

Apliqué el criterio de «texto latino a la izquierda», que es para
**bocadillos de diálogo**, no para una pancarta — que es un cartel.
Norma 293: la alineación depende del CONTENEDOR, no del idioma.

Centrados los 19 con sangría `(18-len)//2`, releídos con el motor para
comprobar que siguen consumiendo 36 B.

### Dos asserts que hicieron su trabajo

```
AssertionError: «el gordo! ¿Vamos?» son 17 columnas
AssertionError: la correccion cambia la longitud
```

El primero paró un texto que no cabía; el segundo, que `apostar.` es un
carácter más corto que `¡apostar!` y hacía falta un `$A0` de relleno para
no desplazar el resto de la frase.


---

## 14. v320 — Revertida la regresión de la v318

### El error

David: *«En el mapa se muestra Bambú, sin el "Aldea"... también he iniciado
la primera fase y ha desaparecido "Aldea" de todos los rótulos»*.

En la v318 escribí que la tabla `0x4379D` era «el rótulo AL VIAJAR» y la
repunté a mis nombres cortos del banco `$21`. **Falso.** Es la tabla de los
**rótulos de aldea** — mapa y entrada — y apuntaba a textos que **ya
estaban traducidos** desde hace muchas versiones, en el banco `$0F`:

```
$425B -> 0x1E25B  «Aldea de la Partida»
$4270 -> 0x1E270  «Aldea Florecer»
$4280 -> 0x1E280  «Aldea Kintaro»
$589D -> 0x1F89D  «Aldea Dormilón»
...
$58E0 -> 0x1F8E0  «Aldea Bambú»
$58ED -> 0x1F8ED  «Isla Ogros»
```

**Volví a incumplir la norma 288**, la que yo mismo escribí tras el
desastre de la v237: identifiqué la tabla por su lector (`$ADA1`) sin
comprobar el CONTENIDO de lo apuntado. Dos veces el mismo fallo.

La tabla A (`0x43712`) sí había que traducirla: apuntaba a japonés y es el
menú de destinos, donde la ventana mide 8 celdas. Esa se queda.

### Un TERCER charset

Los rótulos usan el motor `$AAB4`, con **cuatro** alias:

```
b = $5B    c = $5D    e = $3D    o = $62
```

Los dos primeros son los del motor de menú; `e` y `o` son propios. Es el
tercer charset del proyecto — `tools/charset_rotulos.py`, nuevo.

Deducido de los 9 rótulos que David lleva viendo bien decenas de versiones,
sin un solo conflicto, y **contra-verificado**: el codificador reproduce
los nueve byte a byte.

### «Bambú» → «Taketori»

David: el rótulo decía «Aldea Bambú» pero la aldeana dice «la aldea de
Taketori». Los demás rótulos usan el nombre propio (Urashima, Kachiyama,
Issunboshi, Kintaro), así que lo coherente es **«Aldea Taketori»**.

Como los rótulos van pegados y «Taketori» son 3 B más, se reescribió el
bloque entero `0x1F89C..0x1F900` (92 B usados + 8 de hueco contiguo) y se
repuntaron las 6 entradas correspondientes.

### Un assert que evitó romper la tabla

Al mover el destino del menú, la «cola» que arrastraba llegaba hasta
`0x4380A`... y **la tabla B está en `0x4379D`, dentro de ese rango**. La
habría desplazado 3 bytes, corrompiendo los 9 punteros. El assert de
relectura lo cazó:

```
AssertionError: rotulo 0 sin comando
```


---

## 15. v321 — «Ve. Momotaro.os»

### El bug

David, en un aldeano de Isla Ogros:

```
había:  ...trae la paz al / mundo. Ve. / Momotaro.os
ahora:  ...trae la paz al / mundo. Ve, / Momotaro.
```

### El error que estuve a punto de cometer

Mi primer diagnóstico fue *«la `o` y la `s` de `0x4BF1F` son basura»*.
**Falso y peligroso**: son la **entrada `$60` del diccionario**, `«os »`,
que usan **30 diálogos** del banco `$25` — «todos», «aldeanos»,
«esperanzas»... Ponerlas a relleno las habría roto todas.

La v321 llegó a construirse con ese arreglo y **se borró** al detectarlo en
la relectura: el diálogo salía bien pero aparecían `??` donde antes había
palabras. Norma 295: si un byte «sobra» en mitad de un bloque de texto,
comprobar que no sea el principio de otra estructura.

### La causa real: un solape

El diálogo `0x4BEBE` **no tenía terminador propio**. Su texto llegaba hasta
`0x4BF1E` y a partir de `0x4BF1F` empieza la entrada del diccionario, así
que el motor seguía leyendo, imprimía `«os »` y solo paraba en el `$00` de
`0x4BF22` — que es el terminador de la ENTRADA.

```
0x4BF1B  $CB  '.'          <- debía ser ','
0x4BF1C  $3B  salto
0x4BF1D  $65  DICC «Momotaro»
0x4BF1E  $CB  '.'
0x4BF1F  $AF ─┐
0x4BF20  $B3  ├ entrada $60 = «os »
0x4BF21  $20 ─┘
0x4BF22  $00  terminador de la ENTRADA, usado por accidente
```

### El arreglo: 6 bytes

Mover la entrada `$60` al hueco libre del final del banco `$25`, repuntar
su casilla en la tabla `0x4BA13`, y poner el `$00` del diálogo en
`0x4BF1F`.

El hueco `0x4BFE7` se verificó libre por tres vías: era `$FF` en la
japonesa, ninguna de las 48 entradas llega más allá de `0x4BF6F`, y el
último diálogo acaba justo ahí.

Verificado que las 47 entradas restantes no se han tocado y que los 30 usos
del código `$60` siguen expandiendo a «os ».

### Un barrido que dio limpio

Antes de tocar se barrió todo el banco `$25` buscando el mismo patrón
(cadena que acaba en `.` + minúsculas sueltas) y variantes. **Este era el
único caso.**


---

## 16. v322 — El «texto raro» del ermitaño

### El bug

David: *«la pregunta inicial estaba traducida a medias, se colaba un texto
raro antes»*.

En la v318 escribí la línea del ermitaño empezando en `0x4AE18`. **El
bloque empieza en `0x4AE0A`.** Los 14 bytes de delante se quedaron en
japonés y en pantalla salían como basura latina, justo antes de mi texto.

### La estructura real

```
0x4AE0A .. 0x4AE2C   bloque 1, acaba en el $00 MARCADOR
0x4AE2D .. 0x4AE3A   bloque 2, acaba en $80
```

La frase es **[bloque 1] + ‹nombre de técnica› + [bloque 2]**. El `$00` no
es un terminador: es el punto de inserción. Por eso David veía «Vuelo»
incrustado entre japonés.

### Traducción

```
|¡Sin excesos!   |
|¡Jujú! Soy      |<<TÉCNICA>>.
```

En pantalla: «¡Sin excesos! / ¡Jujú! Soy Vuelo.»

Verificado que no queda **ni un byte** idéntico al japonés en el bloque.

---

## 17. [ABIERTO] El quiz — inventario completo

```
PREGUNTAS   0x4AEE6 .. 0x4B466   41 bloques, longitud VARIABLE,
                                  delimitados por el «?» final
RESPUESTAS  0x4B466 .. 0x4B893   celdas de 10 BYTES fijos
CIERRE      0x4B893 ..            «¿jugamos a acchi muite hoi?» y reacciones
```

La primera «pregunta» es el rótulo de la ventana: `オコタエハ?` = «¿tu
respuesta?».

> **AVISO: esta sección quedó obsoleta.** El inventario de aquí (41
> preguntas, celdas de 10 bytes, sin tabla de punteros) es **incorrecto**.
> La estructura real está medida en la **sección 19**: son 40 preguntas, hay
> tabla en `0x11818` y las opciones son de 8 columnas con 7 útiles. Se deja
> el texto original porque el error forma parte del registro.

Las respuestas van en **celdas de 10 bytes**, tres por pregunta.
Verificado contra la captura de David (`たまてばこ` / `びっくりばこ` /
`ふでばこ`). Un dakuten gasta byte pero no columna, así que las opciones
con sonoras tienen menos espacio útil. Ancho visible: **unos 8 caracteres**.

**El problema no es técnico, es de contenido**: las preguntas son de
folclore japonés (Urashima Taro, Kintaro, Hanasaka Jijii, Kaguya-hime,
Issunboshi, Kachi-kachi Yama, Yamata no Orochi, Ikkyu-san...). Un jugador
español no puede responder a casi ninguna.

Tres vías en `docs/QUIZ.md`. **David eligió la fiel** y está hecha (sección 19).


---

## 18. v323 — El ermitaño, a la tercera

### Lo que seguía mal

David, sobre la v322: sale «. / Vuelo» y luego, ya bien, «Acierta todas y
te daré un don.»

### La causa

En la v322 **moví el marcador de sustitución**. La geometría japonesa es:

```
0x4AE0A .. 0x4AE30   39 B de texto
0x4AE31              $00  <- marcador: aquí se inserta el nombre
0x4AE32 .. 0x4AE39    8 B de texto
0x4AE3A              $80  fin
```

Yo puse el `$00` en `0x4AE2C`, cinco bytes antes. El motor cortaba ahí,
insertaba «Vuelo» y luego seguía leyendo mi `.` suelto de `0x4AE2D`.

**Tres versiones seguidas equivocándome en la misma zona** (v318 el offset
de inicio, v322 el del marcador). La lección: en un bloque con inserción
dinámica hay que **respetar la geometría byte a byte**, no solo el texto.

### El arreglo: 4 bytes

```
0x4AE0A  |¡Sin excesos!   |
         |¡Jujú! Soy      | ← acaba en espacio
0x4AE31  $00               ← marcador restaurado
0x4AE32  «.»
0x4AE3A  $80
```

En pantalla: «¡Sin excesos! / ¡Jujú! Soy Vuelo.»

Verificado que los dos terminadores coinciden con la japonesa y que no
queda ningún `$00` suelto dentro del bloque.

---

## 19. El QUIZ (v324-v332) — la tanda más larga y la que más errores míos tuvo

**Decisión de David: traducción fiel.** *«Los jugadores sabrán dónde se
meten, así que, que se apañen.»*

### 19.1 La estructura, que describí mal dos veces

En el informe anterior escribí: *«41 bloques de longitud variable, SIN TABLA,
delimitados por el `?` final»*. **Falso.** La tabla existe:

```
0x11818 + 2*i     96 punteros, base CPU $6000 -> ROM 0x4A000 + p - 0x6000
  [ 0.. 1]  los dos mensajes del ermitaño
  [ 2..41]  las 40 PREGUNTAS
  [42..81]  los 40 tríos de RESPUESTAS
  [82..95]  las 14 TÉCNICAS
```

Apareció desensamblando la rutina del ermitaño: estaba pegada al código.
Son **40** preguntas, no 41 — el bloque que yo llamaba «pregunta 0» es el
rótulo `Elige:`, y ni siquiera va por tabla (`$D94A` lo carga inmediato).

### 19.2 Geometría real, leída del código

```
$DD53  bucle de PREGUNTA   LDA $3D28 / CMP #$20 / BCC   -> 32 columnas
       $DD93 (byte $80)    LDA #$10 / STA $3D28         -> salto a col 16
       => 2 líneas de 16. El $80 NO es terminador, es salto de línea.

$DAC0  bucle de OPCIÓN     LDA $3D28 / CMP #$08 / BCC   -> 8 columnas
       llamado con $3D29 = 0..3  (0 = rótulo, 1-3 = opciones)
       => 8 columnas, 1 la ocupa el cursor -> 7 ÚTILES
```

**Corrección incómoda sobre el ancho.** David dijo que cabía «algo más» de lo
que yo decía, con el ejemplo `C. Mágica`. Le di la razón y dije 10. **Los dos
íbamos altos y yo más que él**: son 8, con 7 útiles. Conté períodos de 8 en el
volcado y aun así interpreté celdas de 10.

Y un segundo límite, medido sobre capturas: **la columna 16 de las preguntas
no se pinta**. La P4 y la P10 tenían 16 caracteres exactos y perdían el «?».
Máximo real: **15**.

### 19.3 La tabla de respuestas correctas

```
$DCA7  LDX $3D1D / LDA $3D2A,X / TAY / LDA $DCD0,Y / CMP $3D14
```

`$DCD0` = ROM `0x11CD0`, 40 bytes con valores 0-2. **El orden de las tres
opciones es intocable.** Sirvió para validar la traducción: la única que
fallaba era la P21, donde la correcta es *kusanagi-no-ken* y yo había puesto
«Hierba», que no se lee como una espada.

### 19.4 El bug del `©` — lo resolvió David con una frase

*«En las tiendas y diálogos de los aldeanos se ve bien. Solo parece pasar en
el quiz.»* Eso descartó de golpe charset, fuente y VRAM.

El renderer `$AAB4` bifurca en `$AAB9` (`CMP #$A0`), y **cada rama deja un
banco distinto en MPR4**:

```
byte >= $A0   $AAC5 tabla $ABAF -> $AAD4 -> $AAEA   banco $1E
byte <  $A0   $AB23 tabla $BF9B -> $AAD4 ...        y si vale 0: banco $02
```

Prueba definitiva en su captura de la P8: en «¿Qué **@**omió el gorrión
goloso?» falla exactamente el byte `$5D` (la `c`) y la línea 2, que no lleva
ningún alias, sale perfecta.

**Pero la moneda tiene dos caras**, y esto es lo importante:

```
PREGUNTAS ($DD53)   byte directo $B0 -> p     BIEN
                    alias $5B/$5D/$5E -> ©    MAL
OPCIONES  ($DAC0)   alias $5E -> p            BIEN
                    byte directo $B0 -> Ç     MAL   («KaÇÇa»)
```

**Justo al revés.** En la v327 pasé todo a bytes directos para matar el `©`
y con eso rompí la `p` de las opciones. Afectaba a **cinco** opciones (Kappa,
Topo, Espada, Copita, Empate), no solo a la que David vio.

### 19.5 Las técnicas: 12 de 14 rotas desde la v317

Al ir a comprobar una preocupación de David («Vuelo es una de las artes»)
resultó que la tabla `$D8BC` conservaba los **offsets japoneses** mientras
los nombres castellanos tenían otras longitudes:

```
[0] «Vuelo»   OK, por casualidad
[1] «o»       debía ser «Salto»
[2] «odar»    debía ser «Rodar»
[7] «»        debía ser «+Vuelo»
```

Nadie lo vio porque **la única que se probó en pantalla fue la [0]**, que
acierta de chiripa. De ahí la norma 305: *un bloque indexado se verifica
entero*.

### 19.6 Hien: tres avisos hasta que lo entendí

David, tres mensajes seguidos, el último: *«NO QUIERO QUE SE LLAME "VUELO",
SINO HIEN»*. `hien` (ヒエン) es el **nombre propio** del ermitaño. Lo traduje
como «Vuelo» porque la tabla tiene pinta de lista de artes, y **no comprobé
quién la lee**:

```
$D7CE  LDA $D8BC,X   entradas 0..6  -> el NOMBRE del ermitaño (único lector)
$D610  LDA $D8CA,X   entradas 7..13 -> las ARTES del premio
0x434B5              el menú SELECT, otro bloque, intacto
```

Podía llevar el nombre propio desde el principio sin romper nada. Lo peor:
la norma que lo habría evitado (**307**) la escribí yo dos versiones antes.

### 19.7 El «Vuelo.» que no sobraba

Tres versiones intentando **redactar mejor** un bocadillo, y una cuarta
matándolo con `NOP`. David lo intuyó: *«no es que sobre, sino que tendría que
ir otro texto»*. El código concatena **tres trozos en el mismo bocadillo**:

```
$D7C6  «washi wa »  -> «¡Yo soy el ermitaño »
$D7D8  tabla $D8BC  -> «Hien»
$D7E3  «sennin ja!» -> «!»
```

Al poner `NOP` en el primero borré el principio de la frase. Error de
**comprensión**, no de offset: di por sobrante un texto que era el arranque de
una frase compuesta. De ahí la norma 303.

No cabía «¡Yo soy el ermitaño » en sus 12 bytes útiles, pero eso no era motivo
para rebajar el texto: el puntero es inmediato, así que **mover cuesta dos
bytes** (norma 313).

### 19.8 El bloque limpiador (v328)

David: *«cada vez sale una nueva frase, primero sale otro texto fugazmente,
incluso en el panel de respuestas. Es como si no se limpiara el texto.»*

Literal: no se limpiaba **porque yo había machacado el limpiador**.
`0x4AD56..0x4AD76` son 32 bytes de `$20` que el motor escribe para **borrar**
el bocadillo, y lo llaman desde tres sitios (`$CDFE`, `$D9B6`, `$DD37`). Yo
empecé a escribir el cierre ocho bytes dentro.

**Una racha larga de espacios no es relleno: puede ser una estructura con
dueño** (norma 310).

### 19.9 Páginas, no bloques (v332)

Dos versiones seguidas fallando en el mismo troceo. El mensaje del ermitaño
tras superar el quiz **está partido en dos páginas por código**:

```
$CFDC  LDA #$76 / #$6D  -> pinta $6D76           PÁGINA 1
$CFE7  LDA #$9A / #$6D  -> STA $3D3A/$3D3B       PÁGINA 2
```

El corte está en `0x4AD9A`, a mitad de mi frase: «arte» quedaba al final de la
página 1 y **el punto abría la página 2**. Y en la v331 me había equivocado
antes de rama, metiendo «¡Ve a la Isla!» en el bloque de **fallo** — al
suspender te mandaba igualmente a la isla.

También el premio: el orden es `$6DE2` + técnica + `$6DF5`. En japonés la
partícula *wo* va **detrás** del nombre; en castellano «Toma:» va **delante**,
o sea en otro bloque. Yo lo puse en el tercero y salía «+VueloToma:».

### 19.10 Estado del quiz

```
40 preguntas   2 líneas de 15 columnas útiles
120 opciones   7 caracteres útiles (1 la ocupa el cursor)
2280 B de los 2445 disponibles
```

Todo verificado **simulando el motor sobre la ROM final**: se sigue cada
puntero de la tabla, se decodifica con el charset correcto de cada ventana y
se compara con el texto esperado. Asserts que quedan puestos:

- cero alias `$5B/$5D/$5C` en preguntas; `$B0` prohibido en opciones
- toda pregunta que abre `¿` cierra `?`
- las 14 técnicas, releídas una a una por su puntero
- el bloque limpiador, 32 bytes de `$20` exactos
- la tabla de respuestas correctas, intacta y con valores 0-2

---

## 20. Otros arreglos de la tanda

### «Aldea Bambú» — eran TRES sitios, con tres charsets

```
0x1F8DF  rótulo del mapa y de la entrada   charset_rotulos
0x43783  menú RUN                          charset_oficial
0x4A3F9  diálogo de la aldeana             charset_vitores
```

El tercero era la incoherencia que David denunció en la v318 al revés: la
aldeana decía «Ésta es la aldea de Taketori» mientras el rótulo decía otra
cosa. **Al cambiar un nombre propio hay que buscarlo en los tres charsets**
(norma 300).

### Por qué se cortaba «Aldea Taketori» — sin resolver

Dos teorías mías, las dos tumbadas por David con datos:

1. *«se corta por longitud»* → «Aldea Florecer» también tiene 14 y no se corta.
2. *«límite fijo de 12 celdas»* → sus capturas dan marcos de **anchura
   variable** (138 px en Kachiyama, 233 px en Florecer).

Lo que queda en pie [HECHO]: el rótulo se dibuja con **sprites** (7-14 y 21 =
letras; 0-6 y 15-20 = marco) y el lector `$D649` corta en `CMP #$18` = 24
caracteres, que no es donde se veía el corte. **Causa real sin determinar.**
Cerrado en la práctica con «Aldea Bambú» por decisión de David.

### «Faltan momos» → «0 momos»

Localizado en `0x19BFA` (banco `$0C`), con 4 bytes de `$FF` detrás. Límite: 8
caracteres. Sale en el menú RUN al usar un arte sin puntos.

### El `$` no era un dólar

David saltó, con razón aparente: *«ni de coña vamos a poner el símbolo del
dólar»*. Pero el byte `$24` pasa por la tabla `$AB34` (`$24`→`$3E`) y acaba en
el **glifo `$FF`**, el mismo que usa el japonés (`100` + `$3E`): el símbolo del
**ryo** que ya sale en todo el juego. Renderizado desde la VRAM para
confirmarlo.

**En pantalla ya se veía bien; lo que estaba mal era mi documentación**, que lo
llamaba «dólar» y encima ponía «mon» en vez de «ryo». Un error de descripción
que casi provoca un cambio innecesario (norma 302).

---

## 21. Errores propios de la tanda v324-v332

Ordenados por lo que costaron.

| # | Error | Causa | Lo cazó |
|---|---|---|---|
| 1 | «Hien» traducido como «Vuelo», 3 avisos | asumí que una tabla con forma de lista de artes lo era | David, tres veces |
| 2 | 12 de 14 técnicas rotas (v317-v326) | repunté texto sin actualizar la tabla que lo indexa | un assert nuevo |
| 3 | Machacar el bloque limpiador | tomé 32 bytes de `$20` por relleno | David, en pantalla |
| 4 | El `©` y luego la `p` | no verifiqué el mismo byte en las **dos** ventanas | David, en pantalla |
| 5 | `NOP` a un `JSR` que no sobraba | leí tres `JSR` seguidos como mensajes sueltos | David |
| 6 | Rótulo en el índice 95 → machacó la técnica [13] | los índices 82-95 eran otra familia | assert de técnicas |
| 7 | Corte de página ignorado (v331, v332) | no listé los `LDA #imm` internos del bloque | David |
| 8 | Afirmar que «ermitaño» no estaba traducido | no hice el grep antes de hablar | David, con captura |

**El patrón que se repite en 1, 2, 4, 6 y 7 es el mismo**: dar por conocida la
estructura en vez de medirla, y verificar solo el primer elemento de un
conjunto. Las normas 305, 307 y 311 nacieron de esto y **me las salté después
de escribirlas**.

**Lo que funcionó**: los asserts de relectura por puntero cazaron los errores
2 y 6 antes de que salieran de aquí. Sin ellos habría entregado dos ROMs con
técnicas rotas.

---

## 22. Normas nuevas (298-320)

```
298  Un texto que aparece en pantalla no es necesariamente un texto que haya
     que traducir. Preguntarse QUIÉN lo llama.
299  Antes de afirmar que no hay tabla de punteros, desensamblar la rutina
     que usa el primer bloque. Suele estar pegada al código.
300  Al cambiar un nombre propio, buscarlo en LOS TRES charsets.
301  Si el usuario aporta un CONTRAEJEMPLO, la teoría se tira, no se remienda.
302  Antes de proponer un cambio de símbolo, RENDERIZAR el glifo real.
303  Varios JSR consecutivos a la misma rutina de texto son UNA frase.
304  Bloque troceado por $00: comprobar si hay tabla que lo indexa.
305  Un bloque indexado se verifica ENTERO. La [0] puede acertar por azar.
306  Si un texto falla en un sitio y el mismo texto va bien en otro, la causa
     es la RUTA del renderer, no el charset.
307  Una tabla de punteros puede servir a VARIAS familias. Comprobar a cuál
     pertenece el índice antes de escribir.
308  Un texto cargado con LDA #imm no está en ninguna tabla.
309  El último carácter de una línea de 16 no se pinta. Máximo 15.
310  Una racha larga de $20 puede ser el bloque de BORRADO, no relleno.
311  Antes de escribir en un bloque, listar TODOS los punteros inmediatos que
     caen dentro de él.
312  Antes de afirmar que algo NO está traducido, hacer el grep.
313  Que un texto no quepa NO es motivo para rebajarlo: si el puntero es
     inmediato, mover cuesta dos bytes.
314  Para juzgar si una pregunta se entiende, leerla junto a su RESPUESTA
     CORRECTA.
315  Un nombre PROPIO japonés no se traduce aunque signifique algo.
316  Al reformular un grupo de frases, tocar SOLO las señaladas.
317  Un mismo byte puede dar glifos distintos en dos ventanas del MISMO motor.
318  Al repartir texto entre bloques encadenados, comparar el troceo con el
     volcado japonés línea a línea.
319  Un mensaje puede estar partido en PÁGINAS por código. Buscar los
     STA $3D3A/$3D3B.
320  Si el original pone una partícula DETRÁS de un nombre insertado, en
     castellano la preposición va DELANTE: cambia de BLOQUE, no de texto.
```

---

## 23. Qué queda

Registro único: **`docs/PENDIENTES.md`**.

### Sin verificar en pantalla
- El quiz completo con las 40 preguntas (David ha visto unas cuantas)
- El premio «Toma: +Vuelo» y el mensaje de las dos páginas (v332)
- Las 14 técnicas con **otra** distinta de Hien
- Menú RUN de la v318, «Ve, Momotaro.» de la v321, 18 de los 19 vítores

### Traducción pendiente
- Créditos y final (`0x4A480`, 896 B)
- Backup RAM (`0x1F51E`, 674 B)
- Cinco mensajes sueltos del menú (`0x435E6`, `0x4363D`, `0x4366B`, `0x4369C`, `0x436CC`)
- Cuatro huérfanos de vítores (`$40E8 $4112 $4139 $4163`), sin lector conocido
- Textos en gráficos, passwords amigables

### Gráficos, bloqueado
- **Casa mutilada de Kachiyama** y **pancarta 4 px alta**: la solución está
  simulada (reordenar la SAT) pero la SAT se compone en ejecución. Hace falta
  un breakpoint de escritura en VRAM `$FE00`, que Beetle no da.
- Menú RUN en cascada: *«lo más difícil que nos queda»* (David)
- Por qué se cortaba «Aldea Taketori» (ver 20)

### Resuelto en la v333
David eligió **«¡Ve a la isla de los ogros!»**, coherente con cómo habla el
resto del guion. El rótulo del mapa sigue diciendo «Isla Ogros» como etiqueta
abreviada, igual que «Aldea Bambú».

También «¡A por ogros!» → **«¡A por los ogros!»**, y al medir la ranura
apareció un **hallazgo**: la ranura `$4834` de las posadas mide **40 bytes**,
no 32, y los 8 últimos **seguían en japonés desde la v307**
(`ッテクダサイネ`). No se veían porque el motor corta antes.

> **Una ranura llega hasta el siguiente puntero USADO de su tabla**, no hasta
> donde acaba el texto que uno escribió. Si el original ocupaba más columnas,
> queda japonés invisible detrás (norma 321). **Hay que revisar el resto de
> ranuras de tienda con este criterio.**

```
321  Una ranura llega hasta el siguiente puntero USADO de su tabla.
322  El assert «cero japonés» por comparación de bytes NO vale donde nuestro
     charset pisa el rango katakana ($AF es «o» aquí y ッ allí).
323  Al ACORTAR un texto, rellenar la celda ENTERA hasta el siguiente
     puntero. Si no, queda la cola del anterior.
```

### v334 — «Los ogros no te ven.» y el patrón, generalizado

La celda de la Capa: nombre `0x48A06` (16 B) y descripción `0x48A16` (**20 B**,
no 16). La frase nueva entra exacta. El motor corta a 16 columnas y parte
entre palabras: `|Los ogros no te |ven.            |`.

Al inventariar las 19 descripciones apareció que **casi todas arrastran colas
de traducciones anteriores**:

```
Onigiri    |Salud +1.       e vida.  |
Manjar     |Técnica +1.     écnica.  |
Dango      |Llama un aliado.liado.|
Bonzo      |Llueven momos.  cotone|
Raquetas   |No resbalas.    en hi|
Aletas     |Nadas deprisa.  bertad.Cor|
```

Tercer caso del mismo tipo en tres versiones (v333 japonés, v334 « te », v334
las colas). **Nada de esto se ve** porque el motor corta antes, pero un cambio
de maquetación futuro lo sacaría de golpe. Inventariado en `PENDIENTES.md`
como **A00**; solo se limpió la celda de la Capa, que es la que David pidió.
