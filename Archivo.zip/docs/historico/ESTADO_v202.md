# Estado del proyecto — v202

`roms/momotaro_es_v202.pce`
MD5 `60417e1613455fad8ee018dd7ab3bbe6` · CRC32 `9B748954`

Repaso completo cruzando el diario (140 entradas) con todo lo que has ido
reportando. Lo he ordenado por **estado**, no por antigüedad.

---

## ✅ RESUELTO Y VERIFICADO EN PARTIDA (lo has probado tú)

| # | Qué | Versión |
|---|---|---|
| 1 | Bocadillo horizontal **16×4** funcionando, marco de 144 px | v185-v195 |
| 2 | Guion traducido insertado y maquetado a 16 columnas | v183-v184 |
| 3 | **Flecha de continuar** a la esquina inferior derecha | v178 |
| 4 | **Rabillo simétrico** y centrado con el personaje | v190 |
| 5 | Las cabezas de los personajes ya no se mutilan al hablar | v192-v195 |
| 6 | **Líneas perdidas entre páginas** (faltaba `INC $3657`) | v197 |
| 7 | **Puntos suspensivos** eliminados: 125 grupos → 0 | v198 |
| 8 | 8 textos que no cuadraban con tu REPASO (palabras partidas) | v198 |
| 9 | Fuente del menú: `T` alineada, `É` gruesa, sombra en `Ó` | v145 |

---

## 🟡 RESUELTO, PENDIENTE DE QUE LO PRUEBES

| # | Qué | Versión | Cómo comprobarlo |
|---|---|---|---|
| 10 | **El bocadillo ya no se sale por los lados**. Margen de 8 px, y el rabillo se queda con el personaje | v199 | El Jizo al empezar pantalla, y aldeanos caminando por los bordes |
| 11 | **Bocadillo del abuelo bajado** bajo el HUD (ya no lo mutila) | v199 | Ya confirmado por ti |
| 12 | **Abuelo alineado con el rabillo lateral**: −23 px X, −5 px Y, +1 px | v200-**v201** | Todas sus apariciones: minijuegos, caja, final |
| 12b | **Ñordo mutilado bajo el abuelo**: el borde inferior solapaba 9 px con la fila de texto y gastaba 8 ranuras de más | **v201** | Minijuego oculto de los ñordos |

---

## 🔴 BUGS ABIERTOS

### A. Diagnosticados, con causa conocida

**Resueltos en la v202** (pendientes de que los pruebes):

| # | Bug | Estado |
|---|---|---|
| 13 | Cuadro verde sobre el arma proyectil | v202 |
| 14 | Cuadro verde sobre el jefe final | v202 |
| 15 | A la bola del minijuego le falta un cuadro | v202 |

Los tres eran el mismo bug: el buffer de texto vivía en las celdas VRAM
`170-17F`, que el juego usa para el proyectil y el jefe. **Mudado a
`18E-19D`**, con el marco repaquetado de 20 a 10 celdas en `19E-1A7`.

Verificación concluyente: se reconstruyó la VRAM como la deja la v202, se
pusieron `170-17F` **a cero** y el bocadillo se dibuja entero.

### B. Bugs de solapamiento (todos la misma familia)

| # | Bug | Estado |
|---|---|---|
| 16 | **Menú RUN** sobre el mensaje del abuelo al abrir caja | **Diagnosticado** |
| 17 | **Rótulo de la aldea** sobre el diálogo de un aldeano | Igual que el 16 |
| 18 | Artefactos en las tiendas | Fuente katakana; se ve al traducir |

**16 y 17 son el mismo bug, y NO son de lógica: es el límite del VDC.**
Medido en `Superposición.state`: el menú RUN gasta 6 ranuras (celdas
`1F0/1C0/1D0`, dos de 32 px) y el bocadillo 10. Total 16 justas → se caen
las dos últimas celdas de texto (`176`, `177`). En la japonesa limpia no
pasa porque el bocadillo original era de 3 columnas.

Salida posible: que el bocadillo gaste menos de 10 ranuras por fila.

Del 18 te confirmo tu recuerdo: el diagnóstico era la fuente katakana, y la
prueba es traducir la primera tienda.

### C. Límite de sprites por scanline

| # | Bug | Estado |
|---|---|---|
| 19 | **Mutilaciones por el chorro de agua** (escena de la caja) | Medido |
| 20 | Falta un cuadro a la cabaña bajo el bocadillo (aldea Kachiyama) | Sin medir |

Del 19 tengo la medida: en `y=64..87` ya hay 15-16 ranuras entre el chorro
(`0C0`/`0CA`/`0CC`) y la caja. El bocadillo aporta 10. **No tiene arreglo
fácil sin quitarle sprites al bocadillo**; el VDC solo pinta 16.

---

## 📝 SIN TRADUCIR

| # | Bloque | Tamaño | Nota |
|---|---|---|---|
| 21 | Vítores | 2953 B | |
| 22 | Quiz | 2522 B | |
| 23 | Nombres de enemigos | 1745 B | |
| 24 | Final y créditos | 821 B | |
| 25 | Dinero | 800 B | |
| 26 | Tiendas | — | Ibas a probar con la primera |
| 27 | Ermitaño y casino | — | |
| 28 | Menú RUN, rótulos | — | Pendiente desde la v145 |
| 29 | ゲロゲロモード | — | |

Capacidad libre total: **6880 B**. Cabe todo.

---

## ❓ DECISIÓN TUYA, NO ES UN BUG

| # | Qué |
|---|---|
| 30 | **Diálogos de las estatuas Jizo** (el nº 5 es el del ermitaño): dices que la primera frase queda incompleta. El texto de la ROM es idéntico al que aprobaste; si quieres otra redacción, dímela |
| 31 | **Menú de guardar/continuar/abandonar** tras perder todas las vidas (sale si has pasado por un punto de guardado). Sin traducir |

---

## Nota sobre el original japonés

David corrige un dato que yo tenía mal: **los diálogos japoneses son de 3
columnas verticales, no 4**. No afecta a lo hecho, pero explica por qué el
bocadillo original gastaba menos ranuras que el nuestro, y por tanto por
qué los bugs 16, 17 y 19 no salen en la ROM limpia.

## Los Jizo (punto 30): localizado

No eran «los diálogos» en plural: es **un único texto de 121 bytes** en
`0x48F18`. De los 88 textos de esa zona, 87 ya estaban traducidos; este se
quedó fuera porque el guion traducido empieza en `0x48F91`, justo 121 bytes
después. Traducción ya aprobada por David, entra en la próxima tanda.

## Lo que propongo como siguiente paso

1. **Que pruebes la v202**: arma proyectil, jefe final y bola del minijuego.
2. **La traducción completa**: Jizo + vítores + dinero + final/créditos +
   enemigos + quiz + tiendas. Caben en los 6880 B libres.
3. El 20 (mapa) es el mismo caso que el rótulo de la primera aldea, que ya
   resolvimos: debería salir rápido.

Los bugs 16, 17 y 19 son **límite de hardware**, no fallos de lógica. La
única salida real es adelgazar el bocadillo: hoy gasta 10 ranuras por fila
de texto. Se puede bajar a 8 quitando los dos laterales (`1A0`/`1A1`) y
metiendo su trazo en el CG de las celdas de los extremos (norma 145: tapar
un hueco rellenando el CG no cuesta ranura). Eso daría margen en los tres.
