# Estado del proyecto — Momotarou Katsugeki en castellano

Última ROM validada: **v157** (`roms/test_horizontal_v157.pce`,
MD5 `294f0c20ef190860391267c330007dad`) — texto horizontal, aprobada por David.

---

## Traducción

| bloque | estado | tamaño ES | ¿cabe? |
|---|---|---|---|
| menú SELECT | **hecho** (v148) | — | sí |
| guion, 87 textos | **hecho** | 8773 B | **no** (+3358 B) |
| mensajes de victoria, 35 | **hecho** | 1616 B | **sí** (1621 disp.) |
| nombres de artes, 13 | **hecho** | 92 B | **sí**, exacto (92/92) |
| vítores | pendiente | 2953 B jp | rejilla fija de 18 |
| dinero y varios | pendiente | 800 B jp | |
| final + créditos | pendiente | 768 B jp | |
| quiz | pendiente | 2524 B jp | |
| ermitaño y casino | pendiente | 492 B jp | |

Ficheros: `docs/traduccion.py`, `docs/traduccion_enemigos.py`.
Todos verificados contra el juego de glifos de la ROM: **ningún carácter falta**.

---

## El bocadillo

- **Es modular**: los bordes rectos y las cuatro esquinas ya existen en el CG.
  No hay que redibujar nada (rectifiqué la norma 87, que no aplicaba).
- Tamaño elegido: **20×4** (176×88 px). Con los 87 textos ya traducidos,
  20 da 156 páginas y 22 da 142, **con el mismo máximo de 3 por diálogo**:
  no compensa hacerlo más ancho.
- Compositor con piezas reales: `tools/mockup_bocadillo.py`.
- **El problema de la RAM se disuelve.** No hay ningún hueco de 80 B en los
  8 KB (comprobado cruzando referencias y los 7 states), pero resulta que
  **el búfer no hace falta**: `$9D33` escribe una celda en VRAM sin tocarlo,
  y ya espera al VDC en cada celda (`$E185`), así que escribir carácter a
  carácter no cambia el patrón de acceso.

  El nudo real es otro: los 9 tiles del bocadillo **no son contiguos en
  VRAM** (`$69B0 $69F0 $6870`…), herencia del diseño vertical, y por eso
  hace falta una tabla de destinos. Plan: reubicar el CG a 20 tiles
  contiguos → el destino se calcula → sobran 240 B de tablas → cabe todo.

---

## El espacio del guion

Los 3358 B que faltan. Tres vías medidas:

- **A. Repartir por los huecos de todos los bancos** — hay 12215 B y los 87
  textos caben con 3442 de sobra, pero obliga al byte de banco por entrada
  y a tocar los 8 puntos de mapeo.
- **B. Liberar el quiz** ← **la propuesta**. Todo dentro de la ventana, sin
  tocar el mapeo. Con el quiz entero **sobran 900 B**.
- **C. Diccionario de frases** — medido aplicándolo de verdad: solo 20
  entradas útiles. Sirve de complemento, no de solución.

**Ampliar la ROM no hace falta** (y se descartó: es arriesgado y complica el IPS).

---

## Ajustes de la última sesión (los tres los pidió David)

- **Lateral derecho**: iba 3 px metido. Causa medida: en la celda `1A1` el
  trazo vive en la columna 12 del tile, no en la 15. Corregido con
  `DESP_LAT_DER = 3`; verificado que esquina y lateral caen ambos en x=215.
- **Margen del texto**: era 4 izq / 14 der. Subido a **8**, queda 8/10. Los
  glifos traen su propio aire a la derecha, por eso un margen simétrico en
  código se veía descentrado.
- **Puntos suspensivos**: el `$CF` que yo daba por «…» son DOS PUNTOS.
  Sustituidos por tres puntos normales (+248 B, +3 páginas).
- **Rabillo**: el simétrico **ya existe en el juego**, en la misma celda
  `1AD`, cargado por la intro. No hay que dibujar nada.

## Maquetación

`tools/maquetar.py`: equilibra las líneas minimizando los huecos al cuadrado
y reparte las líneas entre páginas a partes iguales (5 líneas en páginas de
4 → 3+2, no 4+1). Resultado con 20×4:

```
1 página: 20 diálogos    hueco medio 3,9 caracteres
2 páginas: 62 diálogos   solo el 1% de las líneas pasa de 10 de hueco
3 páginas:  5 diálogos
```

## Lo que necesito de David

`docs/BREAKPOINTS_para_David.md` — tres comprobaciones en Mesen:

1. ~~Write en CPU `36F1`–`3740`~~ **HECHO**: la zona NO está libre.
2. ~~Read en ROM `4AEE4`–`4AEF4`~~ **HECHO**: el quiz se lee con el puntero
   de página cero `$BF/$C0`, y los 12 sitios que lo cargan están **todos en
   el banco `$08`**. La vía B es viable.
3. ~~Write en VRAM `D68`–`D70`~~ **ANULADO**: le pasé una dirección mal
   calculada (multipliqué la celda por 8 en vez de por 64; la buena era
   `$6B40`). Ya no hace falta: el rabillo simétrico está localizado en
   **ROM `0x5292`**, 46 B comprimidos, encontrado con el descompresor.

**No necesito nada más de momento.**

## Repaso de la traducción

`docs/REPASO_traduccion.md` — los 87 textos con el japonés original, la
traducción y cómo queda cada uno maquetado en el bocadillo 20x4. Al final
hay 5 dudas concretas que quiero que decidas (guijarros, tratamiento,
chistes locales, nombres propios y ogro/oni).
