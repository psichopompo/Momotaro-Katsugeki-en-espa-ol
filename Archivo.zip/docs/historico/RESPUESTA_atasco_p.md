# La `p` de «Capa» — resuelto

**Para:** el chat actual · **De:** el chat original · 19 de agosto de 2026
**ROM:** `momotaro_es_v264.pce` · MD5 `695965973173f0a960eb3c0095f8cef0` · CRC32 `7B00D67C`
**2 bytes sobre la v263.**

---

## La respuesta corta

**El código de la `p` en el menú es `$5E`, no `$B0`.**

```
0x43143:  $B0 -> $5E
```

Y de paso, el espacio final que había que quitar:

```
0x43145:  $20 -> $00
```

---

## Por qué `$B0` daba `$DE`

No hace falta ninguna teoría nueva. **Estaba en vuestro informe anterior**,
el de v202→v225, sección 3.3 — se pasó por alto al retomar el problema.

Hay una **tabla de sustitución previa** en `$AB34` que intercepta el código
antes de que llegue a la tabla de fuente:

```
origen  0x42B4C:  20 21 2D B0 A2 A3 24
destino 0x42B54:  3C 5C 5F 5F 5B 5D 3E
                        ^^  $B0 -> $5F
```

**Son dos arrays paralelos de 7 bytes, no pares intercalados.** Ese es el
motivo de que se descartara: volcados «en pares» dan `$20→$21`, `$2D→$B0`,
`$A2→$A3`… puro ruido. Leídos como dos arrays, cuadran.

Después, `$CB1B` elige la ruta:

```
si (cod - $30) < $54  ->  BAJA: idx = rom[0x43F9B + cod - $30]
si no                 ->  ALTA: idx = rom[0x41C73 + cod - $20]
```

## La cadena explica los dos experimentos

```
v260:  $B0 -> sustitución -> $5F -> ruta BAJA -> glifo $DE     ✓ visteis $DE
v261:  $70 -> (sin sust.)        -> ruta BAJA -> glifo $EA     ✓ visteis $EA
```

Los dos resultados que «ninguna tabla explicaba» salen del mismo camino de
tres pasos. **Fallaba el modelo, no los datos.**

## Y el alias también estaba escrito

En vuestro propio mapa técnico, sección 8.2:

> RUTA A (canto): alias **SÓLO aquí**: `b=$5B` `c=$5D` `p=$5E`

El «sólo aquí» era el malentendido: **el menú usa la misma ruta baja**, así
que los tres alias valen igual. Barrido de los 224 códigos posibles: solo
`$5E` produce el glifo `$B0`, y además no lo intercepta la sustitución.

---

## El cuadrado negro de los espacios finales

David lo reportó y está medido:

```
$20 -> sustitución -> $3C -> ruta baja -> glifo $00
```

Y **el glifo `$00` no está en blanco: pinta un cuadrado**. Por eso los
nombres no pueden llevar relleno con espacios.

Comprobados los 11 nombres del inventario: ninguno más lo lleva.

---

## Lo que NO había que tocar (y no se tocó)

Con `assert` en el constructor:

```
código CPY #$03 / CMP #$B3   0x43439+
tabla de sustitución $AB34
tabla baja 0x43F9B
tabla T0 0x41C73
fuente 0x3D660
```

Solo cambian **2 bytes**, los dos dentro de la cadena «Capa».

---

## Nota sobre las dos ramas

Este workspace venía de una rama distinta (v231, con el bocadillo del abuelo
de 2 filas). La v264 está construida **sobre vuestra v263**, así que se
integra sin conflicto. Se conserva la v231 solo como referencia histórica de
aquella geometría.
