# Momotarou Katsugeki — informe v225 → v231

**De:** el chat original · **Para:** el chat actual
**Fecha:** 16 de agosto de 2026
**ROM resultante:** `momotaro_es_v231.pce`
MD5 `1e105cc9c9c1aa08c4eca6b4395f0248` · SHA-1 `0061af28138a88c7bc9a77cc17a19d14de38c5c2` · CRC32 `485A8AA1` · 524.288 B

Gracias por el informe v202→v225 y por las dos respuestas sobre `$52C2` y la
recarga del CG: **sin ese dato esta versión no habría salido**. Va marcado
abajo dónde fue decisivo.

---

## 0. Resumen

- La v231 parte de la **v225** y son **772 bytes** en 7 regiones.
- El bocadillo del abuelo tiene ahora **lista propia**: 128×32 px, 2 filas,
  con marco inferior y esquinas. **La lista compartida no se toca.**
- Se acabaron las mutilaciones de la escena de los ogros: pico **12/16**.
- Rabillo del tutorial **rotado 90°** a la izquierda, apuntando a la derecha.
- «Glaciar» → **«Glacial»** en el menú (1 byte).
- **Los textos de ítem NO están insertados.** Lo intenté y salió mal; el
  motivo está en el §5 y es la pista más útil de este informe.
- Cuatro versiones intermedias (v226, v228, v229, v230, v232) **borradas**
  por romper cosas. Los fallos van documentados: son informativos.

---

## 1. Mapa de diferencias v225 → v231

| Región ROM | Bytes | Banco | Qué |
|---|---|---|---|
| `0x01FA0-0x01FC2` | 35 | `$00` | selector `$FFA0` + suma `$FFB0` |
| `0x3D3FF-0x3D65B` | 605 | `$1E` | CG del bocadillo (rabillo rotado) |
| `0x41A9F-0x41AA6` | 8 | `$20` | `$9A9F` → `JSR $FFA0` + 5 NOP |
| `0x41AF4-0x41AF5` | 2 | `$20` | rabillo variante 2: `dX=60 dY=28` |
| `0x41C3D-0x41C50` | 20 | `$20` | repunte del cargador de CG |
| `0x41FEA-0x41FED` | 4 | `$20` | `$9FEA` → `JSR $FFB0 / RTS` |
| `0x47C99-0x47CFA` | 98 | `$23` | tabla de 4 punteros + lista del abuelo |

**Intactos:** la lista compartida `0x47C02-0x47C98`, las tablas `$9BBD` y
`$9C05`, el CG `$52C2`, la fuente, el guion y la cabecera. Hay `assert` de
cada uno en el constructor.

---

## 2. La lista propia del abuelo

Vuestro diagnóstico era correcto: había que duplicarla. Así quedó:

```
tabla de 4 punteros en $7C99 (ROM 0x47C99)
   var 0,1,3 -> $7C02   la compartida (aldeanos / Jizo)
   var 2     -> $7CA1   la del ABUELO, 18 sprites

lista del abuelo: 2 filas de 16 px, ancho 128 px, alto 32 px
   fila 1  dY=20   1C4..1CA  +  1DC / 1DC-flip
   fila 2  dY=36   1D4..1DA  +  1DD / 1DD-flip
```

**El selector** va en el banco `$00`, que está siempre mapeado en MPR7:

```
$FFA0  LDA $368F / ASL A / TAY
       LDA $7C99,Y / STA $53
       LDA $7C9A,Y / STA $54
       RTS
$9A9F  JSR $FFA0 + 5 NOP        (8 bytes justos, sin trampolín)
```

**Ojo con la `Y`:** vuestra idea de reusar la que calcula `$9A87` no
funciona, porque en medio hay un `JSR $E3EB` y esa rutina hace `CLY`
(`$E417`) y usa `Y` de índice propio. Hay que **recalcularla** leyendo
`$368F`, como arriba.

---

## 3. Presupuesto de ranuras, medido

Sobre `Ogros y abuelo.state`, ocupación **ajena** al bocadillo:

```
y=40..79    2-3 ranuras     ← sitio de sobra
y=80..119  11-12 ranuras    ← los 4 ogros + el objeto
```

De ahí la conclusión que nos costó tres versiones entender:

> **Lo caro es el ALTO, no el ancho.** Con 3 filas el bocadillo llega a
> `y=90` y entra en la franja de los ogros haga lo que haga el ancho. Con
> 2 filas acaba en `y=74` y no hay conflicto.

```
geometría            pico    veredicto
16x3 (compartida)     22     se pasa
12x3 sin laterales    18     se pasa
14x2 con laterales    12     OK ← elegida
```

Coincide con vuestra tabla de subir 12 px: las dos salidas valen, y son la
misma idea (sacar el bocadillo de la franja congestionada).

---

## 4. El marco inferior sin crecer, y el dato que lo desbloqueó

Aquí es donde vuestra respuesta fue decisiva. Al medir el CG salió esto:

```
1C4..1CB   arriba = borde superior   abajo = LÍNEA 1
1CC..1D3   arriba = LÍNEA 2          abajo = blanco
1D4..1DB   arriba = blanco           abajo = borde inferior (fila 14)
```

El texto **ocupa media celda**, y el cuadrante lo fija `$9C05` por índice de
buffer (0-15 → mitad inferior; 16-31 → mitad superior). Por eso el bocadillo
compartido tiene **3 filas de sprites pero solo 2 de texto**.

Con vuestro dato de que **el CG se carga por escena y no por apertura**, se
pudo poner la fila 2 del abuelo en `1D4..1DA` (que ya llevan el borde
inferior dibujado) sin miedo a corromper el marco de los aldeanos.

Y no hizo falta duplicar la tabla `$9BBD`: `1D4` está 8 celdas por encima de
`1CC`, o sea **+$200 en el word = +2 en el byte alto**, que calcula `$9FE0`.

```
$9FE0  ... ADC $9BBE,Y / JSR $FFB0 / RTS
$FFB0  CPY #$20 / BCC salir
       PHX / LDX $368F / CPX #$02 / BNE restaurar
       PLX / CLC / ADC #$02 / RTS
restaurar  PLX
salir      RTS
```

---

## 5. LO QUE NO FUNCIONA — y es lo que más os interesa

**El texto de la línea 2 no se ve.** Medido en el state de David con el
bocadillo de ítem abierto:

```
celda 1C4   tiene TEXTO (32 px)   y SÍ se dibuja     ✓
celda 1CC   tiene TEXTO (29 px)   y NO se dibuja     ✗
celda 1D4   VACÍA (solo borde)    y SÍ se dibuja     ✗
```

O sea: **el motor sigue escribiendo la línea 2 en `1CC`**, y mi parche de
`$9FE0` no la redirige a `1D4`. La hipótesis que manejo es que este
bocadillo concreto **no pasa por `$9FE0`** (va por el clon `$9952`, como
vosotros documentasteis), o que `$368F` no vale 2 en el momento de escribir
el texto, solo al emitir los sprites.

**No lo he resuelto.** La salida limpia es la contraria: que la fila 2 use
`1CC..1D2` —donde el motor sí escribe— y meter el borde inferior en el CG de
esas celdas. Eso sí toca `$52C2`, que es vuestro.

### La pregunta concreta

> **¿El bocadillo de ítem (`$C969` → clon `$9952`) pasa por `$9FE0`, o
> calcula el destino por otra vía?** Si va por otro sitio, ¿cuál?

Con eso se cierra en una pasada.

---

## 6. Sobre `$C969`: confirmo lo vuestro y corrijo un dato

Confirmado: la tabla **sigue viva** y sus textos **siguen en katakana**.

Un matiz: decís 12 entradas y en la ROM hay **23 punteros válidos**
consecutivos (`$4C7E`…`$4E2B`), y la 24 ya es basura (`$0843`). Los 23
decodifican como mensajes coherentes de obtención de ítem y de dinero:

```
[0] karada no onigiri   [8..11,18,19] Momotaro wa N mon   [12] kore ijou motenai
[3] kibidango           [13..15] inu/kiji/saru wo otomo   [20] Bakamon!
[7] kakuremino          [17] Momofure bouzu              [21,22] Ue/Migi wo mezashite
```

Puede que vuestra ficha cubriera solo las 12 primeras. **El separador de
línea de este bloque es `$A0`, no `$3B`** — importante para cuando se
inserten.

Traducción ya aprobada por David, lista para meter cuando se resuelva el §5:
nombres del menú (`Onigiri`, `Manjar`, `Banquete`, `Dango`, `Pedos`, `Solar`,
`Glacial`, `Capa`, `Bonzo`), moneda **ryo/ryos**, y `Bakamon` traducido como
«¡Menudo idiota!».

---

## 7. Los cinco fallos propios, por si os ahorran el rodeo

Van sin adornos: cuatro de estas versiones rompieron el juego.

| Ver. | Fallo | Causa |
|---|---|---|
| v226 | se cargó los bocadillos de Jizo y aldeanos | puse la tabla **encima del terminador `$FF`** de la lista compartida, en `0x47C98`. El hueco empieza en `0x47C99` |
| v226 | la geometría no cambiaba | dejé los laterales en `dX=-72/+56`; van **8 px por fuera** del texto, no 16 |
| v228 | bocadillo de 48 px, subido al HUD | añadí una **tercera fila de sprites** sin saber que el texto ocupa media celda |
| v229 | freeze al hablar | usé `$3693` de marca, y `$3692` **se indexa con `,Y`** hasta `$3699` |
| v230 | freeze en todo | `LDX $368F`, y **`X` es el contador del bucle** de `$9B7C` (`CLX`…`INX`/`CPX #$20`) |

Dos lecciones que nos sirven a los dos:

- **`PLX` y `PLA` machacan N y Z.** No vale comparar, restaurar y ramificar:
  hay que ramificar antes y restaurar en cada rama.
- **`CPX`/`CPY` ensucian el carry.** Si detrás hay un `ADC`, hace falta `CLC`
  aunque el original no lo llevara.

Y un error de lectura que casi me lleva a un diagnóstico falso: leí el
puntero `$92/$93 = $5662` como banco `$24` cuando el state dice **MPR2 =
`$26`**. Salía un texto que no existía. **Los MPR del state, siempre.**

---

## 8. Estado de los pendientes

| # | Qué | Estado |
|---|---|---|
| 1 | Bocadillo del abuelo, geometría | **cerrado**, validado por David |
| 2 | Rabillo rotado y colocado | **cerrado** |
| 3 | «Glaciar» → «Glacial» | **cerrado** |
| 4 | Textos de ítem (`$C969`) | **bloqueado** por el §5 |
| 5 | Diálogos del abuelo | sin localizar la tabla |
| 6 | Jizo (121 B en `0x48F18`) | traducido y aprobado, sin insertar |
| 7 | Menú RUN, tiendas | pendiente |
| 8 | `$CEE7` carga en `1D0..1D7` | **riesgo abierto**: pisa la fila 2 del abuelo |

El 8 lo levantasteis vosotros en la entrada (251) y sigue vivo: ahora la
línea 2 del abuelo vive en `1D4..1DA`, dentro de ese rango. Si esa escena
coincide con un bocadillo suyo, saldría corrupto por la derecha.
