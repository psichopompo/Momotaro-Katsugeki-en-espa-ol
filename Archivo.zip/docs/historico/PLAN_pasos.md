# Reconstrucción por pasos seguros

Se abandona la vía de arreglar la v173/v175. Volvemos al último estado
correcto y avanzamos **de uno en uno**, como acordamos en Nekketsu.

**Base: v158** — bocadillo bien (vertical), texto como cuadros tipo QR.

---

## Paso 1 — v176 ← **AHORA**

**Un solo cambio: 10 bytes.** Sumar 48 a las diez entradas de la tabla de
destinos.

**Por qué**: el motor escribe el glifo en el **plano 3** de la celda
(+48 words), no al principio. Lo confirmé en la v157: sus 36 entradas
acaban en +48, **sin una sola excepción**. Mis tablas daban resto 0, así
que el glifo se pintaba en el plano 0 y salían bloques de color — eso es
exactamente el «QR» que viste.

Simulado con la 'A':

```
antes (plano 0)        después (plano 3)
   66WWW666               WW###WWW
   6WW6WW66               W##W##WW
   WW666WW6               ##WWW##W
```

**Qué esperar**: el bocadillo sigue **vertical** (no toco sprites), pero el
texto debería dejar de ser cuadros. Probablemente se vea descolocado y con
algunas celdas sucias — es normal en este paso.

**Qué mirar**: ¿se distinguen letras, aunque estén mal puestas?

---

## Pasos siguientes (uno por entrega)

| paso | qué añade | riesgo |
|---|---|---|
| 2 | Fondo blanco de las celdas nuevas | medio: toca VRAM |
| 3 | Sprites apaisados (5×2 en vez de vertical) | bajo: solo datos |
| 4 | Guion traducido de la v173 | bajo: solo datos |
| 5 | Diccionario y descompresor de la v173 | alto: toca el motor |
| 6 | Rabillo simétrico (ROM `0x5292`) | bajo |
| 7 | Las dos esquinas (1 bit cada una) | bajo |

Nada de la v173 se pierde: su guion traducido y su diccionario están
guardados y entran en los pasos 4 y 5, **una vez el bocadillo funcione**.

---

## Regla para esta fase

Cada entrega toca **una sola cosa** y su constructor lleva `assert` de que
no se ha modificado nada fuera de esa zona. Si un paso falla, se sabe
exactamente qué lo causó y se revierte solo ése.
