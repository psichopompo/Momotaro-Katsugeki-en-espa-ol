# INFORME DE TRASPASO — Momotarou Katsugeki en castellano

**Fecha:** 2026-08-29 · **Estado:** v401 promocionada a **ROM OFICIAL**

Este informe cubre **de la v393 a la v401** y deja fijado lo que toca hacer
ahora. Sustituye a `INFORME_TRASPASO_v393.md`, que pasa a `docs/historico/`.

Si retomas el proyecto sin contexto: lee esto entero, después
`docs/PENDIENTES.md` (registro único de tareas) y `LEEME.md` (normas 12-392).

---

## 1. El proyecto

Traducción al castellano de **Momotarou Katsugeki** (PC Engine, 512 KB, HuCard).

- **Dirige: David** (*Psicopompo*, elotrolado.net). Las decisiones de diseño
  y de maquetación **son suyas**.
- Repo: `https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol`
- ROM base: `Momotarou Katsugeki (Japan).pce`,
  MD5 `ec7358edb3672a8aa8850623eec72a71` — **INTOCABLE**

### La ROM oficial

```
roms/Momotaro Katsugeki (Español).pce
MD5    289bb157d371716033f982734e478f12
SHA-1  838bf3e6fcb01bcb35c9ae6e0aa8214a3289e123
CRC32  6D36C750           524.288 B
```

Parche: `parches/Momotaro Katsugeki (Español).ips` (contra la virgen,
**regenerado en esta tanda**: el que había reproducía todavía la v393).
`roms/momotaro_es_v401.pce` es el mismo fichero.

**Verificado ahora mismo**: los IPS de v395, v396, v398, v401 y el oficial
reconstruyen su ROM byte a byte desde la japonesa virgen.

---

## 2. Cómo tratar con David

No es opcional. Está aquí porque saltárselo ha costado disgustos reales.

- **Siempre en castellano.** Tutear.
- Reconocer los errores propios **explícitamente**, diciendo qué falló en el
  razonamiento. No maquillarlos, no diluirlos.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- Estilo: ingeniero explicando su trabajo. Conciso. **No ser condescendiente.**
  No insistir en que descanse. David: *«Ni de coña. Seguimos. Sin avances aquí
  no duerme ni Dios. 😸»*
- **Una sola pregunta por mensaje**, al final, con `¿` de apertura.
- Capturas individuales, nunca rejillas.
- **Si David contradice el análisis, comprobarlo antes de descartarlo: ha
  tenido razón SIEMPRE.** En esta tanda, **cinco veces**:
  1. *«los arreglos han derivado en franjas entre las líneas… creo que ya nos
     pasó algo así»* → era una regresión real, la v396 se retiró.
  2. *«para el bocadillo del abuelo le pusimos un identificador propio»* →
     existía (`$368F` + cueva `$FFC3`, v234) y yo estaba peleándome con una
     tabla compartida. Eso cerró N4.
  3. *«las líneas del baño no parecen ser de 17, sino de 16»* → correcto.
  4. *«cambia "por todas partes." por "por todos lados."»* → no era estilo:
     era lo único que hacía que cupiera, y mi assert estaba mal.
  5. La captura de la **página 2** del baño tumbó mi modelo de maquetación.
- No sacar una versión por cada cambio mínimo: agrupar.
- **«No dejemos cosas a medias. Es mejor pasar a la siguiente cuando hayamos
  terminado. Hasta entonces, hay que seguir hasta solucionarlo.»**
- **«Recuerda revisar el log. Tiene que haber información útil.»** Ha
  resuelto varios atascos, N4 entre ellos.

### Órdenes permanentes

- **No se genera ROM hasta ver capturas de cómo quedan los cambios.**
- **Mirar la captura ENTERA antes de enviarla** (norma 352).
- **La verdad es lo que se ve en pantalla, no el hex.**
- **NUNCA partir una palabra.** Si no cabe, la palabra entera baja de línea.
- **No se toca el bocadillo apaisado.** **No bloquear el menú RUN cuando
  habla el abuelo.**
- **No se puede recortar texto: tiene que caber.**
- **Todo fallo se puede revertir, pero con cautela de no pisar nada.**

---

## 3. Qué se ha hecho de la v393 a la v401

| Ver | MD5 | Qué |
|---|---|---|
| v394 | *(hito, ROM borrada)* | **A-VIT2**: cerezos de la transición, 95 B |
| v395 | `f77d07c2d4c910e2ec9ff6df4bb8030e` | **A-CASA**: casa de Kachiyama, 58 B |
| v396 | `4e073a4c466dac2c63cd151277a1d67f` | **N5**: vítores 4 px, **un byte** |
| v397 | *(retirada)* | N4 por la vía buena, pero rompía los vítores |
| **v398** | `68ffe9bcf98d169d1e63c30a9ee072bd` | **N4** cerrado + vítores intactos |
| v399 | *(retirada)* | los 3 textos, con 3 fallos míos |
| v400 | *(retirada)* | corregía 2 de los 3 |
| **v401** | **`289bb157d371716033f982734e478f12`** | **OFICIAL**: N1, N2 y N3 |

Todas con IPS contra la virgen y round-trip verificado. No-regresión en cada
una: **60 states, 800 frames, paso 50 → 960 comparaciones reales**.

### v394 — A-VIT2, los frames sucios de los cerezos

El cargador `$DB60` barre **83 tiles** (t=0..82) con fórmula lineal
`base + t*tam`; la v388 sólo había movido 43. La parte «limpia» del bloque no
estaba libre: la barrían los índices altos.

Solución: **remapear los 40 índices de los pases 0 y 1** a los tiles del
pase 2, que reescribe todo. Los pases intermedios son animación, así que
basta repuntar índices en vez de mover datos. 95 bytes. Normas 372 y 373.

### v395 — A-CASA, la casa mutilada del mapa

Medido: **16/16 ranuras ocupadas en y=120..127**, y el borde inferior del
rótulo de aldea se lleva 10 de ellas.

Solución: subir el rótulo 8 px en las **tres** listas del grupo 5
(`0x1DDF0`, `0x1DEDD`, `0x1DE14`) y dar al rabillo una copia propia mediante
la cueva `$DFDE` (ROM `0x1DFDE`, 24 B) → `$DFF6` (ROM `0x1DFF6`), porque
`$DF06` es una lista global compartida. 58 bytes.

**Ojo:** la primera v395 se retiró por tocar `$CCCF` (ROM `0x1CCCF`,
16 mapas × 4 B), cuyo **byte 1 es la Y BASE DE TODO EL GRUPO** — movía la
casa entera. **No tocar esa tabla.**

Kachiyama = **mapa 4 = grupo 5** (tabla `$DC90` = `[2,3,2,2,5,4,1,0]`×2,
listas en `$DCA0` = ROM `0x1DCA0`, indexadas por grupo*4).

### v396 — N5, la pancarta de vítores

**Un byte.** `ROM 0x169F2`, `ADC #$30` → `#$34` en `$C9EE`.

Cadena: `$C419` (ROM `0x16419`) → `$C997` (ROM `0x16997`, llena el buffer
`$2593`, 2 líneas × 18 columnas) → `$C9EE`.

### v397 → v398 — N4, el bocadillo del abuelo descentrado

**Esta es la parte con más chicha del traspaso. Léela entera.**

El texto de los bocadillos no viene en el stream comprimido: `$52C2` sube
sólo la **plantilla vacía**. El texto lo pega **`$9D33`** (ROM `0x41D33`) en
3 pasadas de 8 filas, leyendo el destino de `$3663/$3664`, que se cargan en
`0x41BA5` desde la tabla **`$9BBD`** (ROM `0x41BBD`, **32 words**, nuestra).

**Intento fallido (v396 original, retirada):** sumar `+2` a los 32 bytes
bajos de `$9BBD`. Centraba al abuelo… y **rompía los bocadillos de 3 filas**:

```
2 filas (abuelo)    $1C4  glifo en filas 4..10   margen abajo 5 px
3 filas (aldeano)   $1C4  glifo en filas 8..14   margen abajo 1 px  <--
```

El glifo desbordaba a la fila 0 de `$1CC`, que es el **borde**:
`7777777777777777` → `6777766666776666`. Ésas eran las franjas negras que
vio David. Norma 383.

**La vía buena, que David recordó y estaba en el diario desde la v234:** el
bocadillo del abuelo **ya tiene identificador propio** (`$368F = 2`) y **su
propia cueva** (`$FFC3`, enganchada en `$9D43` con `JSR $FFC3` + 8 NOP).

Su defecto era usar una **constante**, `LDA #$04`, que sólo desplazaba el
renglón de la mitad baja del cuadrante; el otro se quedaba en 0. Por eso el
texto salía descentrado. Ahora **deriva** del valor que ya hay:

```
FFC3  STZ  $10
FFC5  LDA  $3665      ; cuadrante
FFC8  AND  #$02
FFCA  BEQ  $FFCE
FFCC  SMB3 $10        ; mitad baja -> $10 = 8   (igual que siempre)
FFCE  LDA  $368F
FFD1  CMP  #$02
FFD3  BNE  $FFDB      ; no es el abuelo -> sale sin tocar nada
FFD5  LSR  $10        ; 8 -> 4 ; 0 -> 0
FFD7  INC  $10
FFD9  INC  $10        ; -> 6 y 2 : los DOS renglones bajan 2 px
FFDB  RTS
```

`$9BBD` **no se toca** (assert de las 32 words). Hueco útil de la cueva:
`$FFC3..$FFDF` — en `$FFE0` está la firma `MOMOKATSU 1.07 900518` y en
`$FFF6` los vectores.

**Quién pasa por la cueva (medido con `p.watch(0xFFC3)`):**

```
aldeano 3 filas   $368F=01   327 hits
Jizo              $368F=01   197 hits
perro (abuelo)    $368F=02    33 hits
pancarta vítores  $368F=02   105 hits   <-- ¡también!
bocadillo de ITEM $368F=02     0 hits   <-- otro motor
caja / minijuego  $368F=02     0 hits
```

**Regresión de la v397:** yo había escrito en el diario que los vítores eran
un «sistema independiente» porque usan celdas propias (`$178..$189`) y
constante propia. Es verdad para la VRAM y **falso para el código**: pasan
por la misma cueva. Con la cueva sumando 2 px, los vítores acumulaban
`+4` (`$C9EE`) `+2` = 6 y desbordaban → franjas negras.

**v398** lo arregla con **un byte**: `ROM 0x169F2`, `ADC #$34` → `#$32`.
Normas 384, 385 y 386.

### v399 → v400 → v401 — los tres textos (N1, N2, N3)

Tres versiones porque metí tres fallos distintos. Los tres los cazó David.

**N1 — La Capa** (`0x48A16`, 20 B exactos). «Los ogros no te ven.» se cortaba
en «Los ogros no te » porque la ventana es de **16 columnas y UNA línea**, sin
scroll. Ahora **«Nadie te verá.»** (14). El bloque no puede crecer: «Aletas:»
empieza en `0x48A2A` y los registros de la tabla de objetos son de **longitud
variable** (deltas medidos entre los ':': 33..44).

**N2 — El baño de mujeres** (`0x4AC45`). Tres cosas mal, en cascada:

1. *Los «©»*: `charset_oficial` codifica **b/c/p** con los alias ASCII
   `$5B/$5D/$5E` porque el bocadillo de diálogo los traduce con la tabla
   `$43F9B`. **Esta pantalla no pasa por esa tabla**: pinta el byte directo,
   y el glifo directo de `$5E` es un recuadro. El testigo estaba a 6 bytes:
   el bloque del quiz (`0x4AC8B`), que lleva años bien, usa `$A2/$A3/$B0` y
   ni un solo alias. Norma 388.
2. *El ancho*: deduje 17 columnas porque «encajaba exacto»… pero barriendo
   inicio y ancho **encajan muchas combinaciones**. Lo que sí lo prueba: en
   JIS X 0201 el **dakuten `$DE` y el handakuten `$DF` no ocupan columna**;
   descontándolos, el bloque japonés da **4 líneas de 16**. Normas 389 y 390.
3. *La estructura*: no son 4 líneas contiguas. Son **DOS PÁGINAS de 34 bytes**,
   de las que se ven los **32 primeros** como 2 líneas de 16:

```
página 1   0x4AC45 + 0    líneas en +0  y +16
página 2   0x4AC45 + 34   líneas en +34 y +50
```

Validado contra **tres capturas de David en dos ROMs distintas**: el modelo
de 34 reproduce exactamente lo que se ve y el de 32 no. La página 1 encaja
con los dos modelos, así que **no discrimina**; sólo la página 2 lo hace.
Norma 392.

Texto final (redacción de David):

```
pág.1   ¡Sí existía el      (14)
        baño femenino!      (14)
pág.2   ¡Qué suerte,        (12)
        chaval! ¡Gufufu!    (16)
```

Sus razones: `oniisan` es apelativo cercano sin parentesco y «hermano» suena
a jerga adolescente; «¡Suerte, chaval!» parecía **desearle** suerte cuando le
están diciendo que **es afortunado**; y la risa pícara japonesa es
**«gufufu»** (グフフ), no «je, je». Se conserva «femenino» porque «¡Baño de
mujeres!» son 17 y no cabe — el chiste del easter egg se mantiene.

**N3 — La aldeana de Kaguya** (`0x4A403`, 114 B + 15 B de relleno `$00` =
**129 B**). Reflujo de David, 130 B en crudo → **104 B con el diccionario**.

Mi tercer fallo: escribí en el diario que `$00` era «fin de página». **Es fin
de BLOQUE.** El texto original no tiene ni un `$00` intermedio: son líneas
separadas por `$3B` y **el motor pagina solo cada 4 líneas** (`CMP #$04` en
`0x418AF`, dato que ya estaba en el diario). Mis `$00` cortaban el texto y
sólo se veía la primera página. Norma 391.

```
pág.1   La princesa / Kaguya ha / aprendido hace / poco a apostar.
pág.2   Dicen que anda / probando suerte / por todos lados. / (vacía)
pág.3   ¿Y si lo intento / yo también?
```

La línea vacía es deliberada: rellena la página 2 para que «por todos lados.»
la cierre. «por todos lados.» (16) en vez de «por todas partes.» (17) fue
corrección de David — y destapó que **mi assert estaba a 17 columnas**,
copiado del baño, cuando el bocadillo de diálogo usa la lista compartida
`0x47C02` = **16 columnas**. Norma 387.

---

## 4. Normas nuevas de esta tanda (372-392)

Están todas en `LEEME.md`.

| # | Norma |
|---|---|
| 372 | Si un cargador usa fórmula lineal (`base + t*tam`), el bloque es **todo el rango que barren los índices**, no la parte que se ve sucia. |
| 373 | Si la última pasada reescribe todo, las intermedias son **animación**: repuntar índices en vez de mover datos. |
| 374 | Un candidato a puntero sacado de un barrido **no es un puntero hasta desensamblarlo**. `20 xx` casi siempre es `JSR`. |
| 375 | `$FF` no significa hueco: en datos comprimidos es **un byte más**. |
| 376 | Toda ROM se prueba **arrancando desde el RESET** (900 frames + 24 START), no sólo desde savestates. |
| 377 | Antes de afirmar que un sprite «no pinta», **volcar su celda** y mirar esas filas. |
| 378 | **Un verificador que no puede fallar no verifica.** Contar las comparaciones y exigir > 0. |
| 379 | Antes de dar por bueno un cambio de posición, comparar **la SAT entera**, no sólo el sprite que se quería mover. |
| 380 | Un `.sav`/`.srm` de cualquier emulador vale para Beetle (`HUBM`). |
| 381 | **Una ficha de PENDIENTES no es una medición**: volver a decodificar los bytes antes de trabajar sobre una entrada vieja. |
| 382 | **Ajustar la ventana de la no-regresión a la escena**: 300 frames/paso 25 no llegan (los vítores salen en el frame 620). |
| 383 | Si un cambio toca una **tabla o rutina compartida**, probarlo en TODAS las variantes; medir el margen de la **más apretada**. |
| 384 | Antes de tocar una tabla compartida, buscar si **ya existe una cueva propia** aguas abajo. `grep` en el diario antes de diseñar. |
| 385 | **Un identificador no garantiza que la ruta se ejecute**: contar los *hits* del código tocado. Sin hits, esa escena no ha probado nada. |
| 386 | **«Sistema independiente» hay que verificarlo de los DATOS y del CÓDIGO por separado.** |
| 387 | **Cada bocadillo tiene su ancho** y el assert debe usar el de la variante que se toca: baño/quiz 17, diálogo 16, abuelo 14 de 16. |
| 388 | Antes de codificar texto, **mirar qué bytes usa el texto que YA funciona en esa misma pantalla** (alias vs byte directo). |
| 389 | Al medir un ancho en japonés, **dakuten `$DE` y handakuten `$DF` NO ocupan columna**. |
| 390 | **«Encaja exacto» no es una medición** mientras no se compruebe que las alternativas NO encajan. |
| 391 | **`$00` es fin de BLOQUE, no fin de página.** El motor pagina solo cada 4 líneas; las líneas van con `$3B`. |
| 392 | Un modelo de maquetación no está verificado hasta contrastarlo con **la pantalla que lo distingue de sus alternativas**. |

### Traducción

Fidelidad y naturalidad, con **puntos finales**. Sin abreviaturas.
**Momotaro** sin `u` final. **Sólo** con tilde. Staff en orden occidental con
inicial si no cabe (`H. Iizuka`, nunca `IiDuka`). Cargos en MAYÚSCULAS. En
créditos, nombres sin punto final; frases sí.
Finales: Muy difícil / Difícil / Normal / Fácil.

---

## 5. Arrancar en 30 segundos

```python
import sys; sys.path.insert(0, 'tools')
from pce import PCE
import estados, sat

p = PCE('roms/Momotaro Katsugeki (Español).pce')
estados.carga(p, 'states/tras_jefe_david.state')
p.run(400)                          # abuelo. Vítores en el 620
p.png('/tmp/foto.png')              # MIRARLA ENTERA, Y AMPLIADA
p.press('A', frames=3, after=25)    # avanzar diálogo
```

Comprobar una ROM nueva:

```bash
python3 tools/noregresion.py "roms/Momotaro Katsugeki (Español).pce" \
        roms/momotaro_es_vXXX.pce 800 50
python3 tools/dis6280.py <rom> <offset_hex> <n> <addr_carga>
```

### Trampas del emulador (medidas, no supuestas)

- **NO se pueden tener dos instancias de `PCE` vivas a la vez**: `CDLL`
  devuelve el mismo handle, la segunda roba los callbacks y `frame` queda a
  `None`. Una ROM cada vez (norma 378).
- `p.vram()` devuelve 0 bytes: usar `sat.vram(p)`.
- **Los watchpoints de página cero NO disparan en Beetle**, y `watch_write`
  sólo guarda 64 escrituras. Para página cero, usar `p.watch(pc)` sobre el
  código que escribe.
- `p.watch()` en bucle rompe la ejecución: instancia limpia por medición.
- `p.png()` revienta si `p.frame` es `None`.
- Botón de diálogo = **A**. Menú = **START**. **En el menú CONTINUAR el
  aceptar es B, no START.**
- `ROM = banco*0x2000 + (PC & 0x1FFF)`; leer el MPR en el hit.
- El word 2 del SAT es el patrón **por dos**: `celda = (word2 >> 1) & 0x3FF`.
- Los nombres de los `.state` llevan tildes descompuestas: filtrar por
  substring, nunca por igualdad.
- capstone en modo 65C02 **no sirve**: usar `tools/dis6280.py`.

### El toolkit (`tools/`, 58 ficheros)

| Fichero | Para qué |
|---|---|
| `pce.py` | emulador: `run/press/png/ram/poke/peek/state`, `watch`, `log_on`, `mpr`, `rom_off` |
| `sat.py` | `vram()`, `sat()`, `visibles()`, `celda()` |
| `estados.py` | carga los `.state` de David (RZIP) |
| `sram.py` | inyecta `.sav`/`.srm` en la Backup RAM |
| `cg.py` | codec del CG comprimido (`$861F`), round-trip verificado |
| `dis6280.py` | desensamblador HuC6280 |
| **`texto.py`** | **NUEVO**: lector/escritor con el diccionario de 48 entradas |
| **`render_texto.py`** | **NUEVO**: dibuja una cadena con la **fuente real** de la ROM |
| `noregresion.py` | compara dos ROMs sobre los 60 states, contando comparaciones |
| `repaso_cadena.py` | compara toda la cadena de hitos |
| `vdc_slots.py` | simula el límite de 16 ranuras por scanline |
| `charset_oficial.py` / `charset_vitores.py` / `charset_rotulos.py` | los tres juegos de caracteres |
| `build_v394.py` … `build_v401.py` | los builds vigentes (`historico/`, los retirados) |
| `bin/mednafen_pce_trace.so` | core con watchpoints y log |

**`tools/sram.py` estaba roto y nadie lo había ejecutado**:
`retro_get_memory_data` sin `restype` devuelve un int de 32 bits, el puntero
se truncaba y `memmove` daba **segfault**. Arreglado con
`restype = ctypes.c_void_p`. Ahora la partida de David carga y el juego
arranca en español desde la Backup RAM — es la vía para llegar a las
pantallas que no tienen savestate.

---

## 6. Conocimiento técnico vigente

### El motor de diálogo (lo más usado)

```
$52C2  (ROM 0x3D2C2)  sube la PLANTILLA VACÍA del bocadillo
$9D33  (ROM 0x41D33)  pega el TEXTO, 3 pasadas de 8 filas
$9BBD  (ROM 0x41BBD)  tabla de 32 words: destino del texto   COMPARTIDA
$FFC3  (ROM 0x01FC3)  cueva del abuelo (identificador $368F = 2)
0x4187D  CMP #$10  -> 16 columnas   ($3658)
0x418AF  CMP #$04  ->  4 líneas     ($3657)
```

Anchos **por bocadillo** (norma 387):

```
lista compartida 0x47C02 (aldeanos, Jizo, tiendas)  8 celdas -> 16 columnas
lista del abuelo 0x47CA1                            7 celdas -> 14 visibles
rejilla del baño / quiz                                        17 columnas
```

Tabla de 4 punteros en `0x47C99` → `$7C02 $7C02 $7CA1 $7C02`. **INTOCABLE**
(pisarla costó la v238). Hueco libre: `0x47CFC..0x47FFF`, 772 B.

### Renderizado de texto: las dos rutas, y los alias

```
byte >= $A0   ruta KATAKANA: el glifo es el byte, DIRECTO
byte <  $A0   ruta TABLA:    glifo = tabla[byte-0x30]  (0x43F9B)
fuente:       ROM 0x3D660 + glifo*8,  1 bit por píxel, 8 filas
```

`charset_oficial` usa **alias** `$5B/$5D/$5E` para b/c/p. **Sólo valen donde
actúa la tabla `$43F9B`.** En Kaguya, el baño y el quiz hay que escribir los
**bytes directos** `$A2/$A3/$B0` o sale un recuadro (norma 388).

### El intérprete de texto y el diccionario (banco `$25`)

```
$3B        salto de línea
$00        FIN DE BLOQUE  (no de página: se pagina cada 4 líneas)
$60-$8F    token del diccionario de 48 entradas
tabla:     $7A13 = ROM 0x4BA13   ·   offset = puntero + 0x44000
$793B      cabecera del intérprete (NO pisar: costó la v392)
```

Las entradas del diccionario pueden contener tokens a su vez (un nivel).
`tools/texto.py` lo maneja y **verifica el round-trip** antes de dar por
buena una compresión.

### Mapa de aldea y rótulos

```
$E3EB  (ROM 0x003EB)  compone la SAT del mapa
$E417  bucle de registros de 5 B (byte0=celda/2+base, byte3=X, byte4=Y)
$E55A  vuelca a VRAM $7F00
$E5BC  tabla de 5 pasadas (00 40 80 81 88)
$DC90  grupos por mapa = [2,3,2,2,5,4,1,0] x2
$DCA0  (ROM 0x1DCA0) listas del rótulo, indexadas por grupo*4
$CCCF  (ROM 0x1CCCF) 16 mapas x 4 B: byte1 = Y BASE DEL GRUPO   NO TOCAR
```

### Bloques de texto localizados

```
0x48900-0x48C00  descripciones de objeto (16 col, UNA línea, long. variable)
0x48A06 / 0x48A16  la Capa: nombre (16 B) / descripción (20 B)
0x4A403-0x4A484  aldeana de Kaguya, 129 B de presupuesto
0x4AC45-0x4AC8B  baño de mujeres, 2 páginas de 34 B
0x4AC8B+         quiz (traducido) — el testigo de codificación
0x1F9C4          «COMIENZA EL JUEGO» (banco $0F), 152 px vs ~96 del japonés
```

### Otros hallazgos vigentes

- **A-BORRA no existe**: `0x1F79E` es el HAI/IIE de la password (ya
  traducido) y `0x1F7AA` es «¡Guardado!». La entrada 293 lo etiquetó mal y yo
  arrastré el error hasta abrirle ficha. Retirada.
- Bocadillo de items: `$368F = 2` pero **no pasa por `$9D33`** — es otro
  motor, sin localizar aún.
- Sound Test en **ASCII puro** (A = `$41`).

---

## 7. LO QUE TOCA AHORA

### 1. ⭐ N6 — el Jizo mutilado (lo único que queda de los bugs)

David: *«Hay que saber por qué parpadea y se mutila y en la versión japonesa
no. Está claro que el rótulo de "COMIENZA EL JUEGO" es mucho más largo que en
la japonesa, y también vemos que al desaparecer el rótulo el Jizo comienza a
verse bien, así que el problema está ahí. Sin embargo, el rótulo y el Jizo no
comparten líneas para superar el límite de sprites por línea, por eso no lo
entiendo.»*

**[HECHO] Medido en su captura:** rótulo en y=108..131, Jizo en y=157..167.
**26 scanlines de separación** → el límite de 16 ranuras por línea **no puede
ser la causa**. Y que se cure solo al desaparecer el rótulo tampoco encaja con
saturación, que daría un recorte estable.

**[HIPÓTESIS, sin comprobar] Solape de celdas en VRAM.** «COMIENZA EL JUEGO»
es nuestro y mide **152 px** frente a los ~96 del `ゲーム スタート` japonés
(ROM `0x1F9C4`, banco `$0F`). Al ser más largo consume más celdas; si pisan
las del Jizo, éste se dibuja incompleto mientras el rótulo está en pantalla y
se recupera cuando el motor las libera. Es el mismo patrón que el bocadillo
del abuelo (entrada 229) y el marco de los minijuegos (v387).

**Lo que falta:** volcar la VRAM **con y sin rótulo** y ver qué celdas del
Jizo cambian. Ahora se puede llegar a esa pantalla con `tools/sram.py`
arreglado. **No se toca nada hasta tener la medición.**

### 2. A-SPR — mutilaciones por exceso de sprites por línea

Casos: el niño aldeano sin cabeza, las bolas del minijuego. **Aviso: parte de
ellas ya existe en la ROM japonesa** — comparar el mismo frame contra la
virgen antes de tocar nada. La medición antigua decía *«bolas mutiladas: peor
línea 56, con 11 sprites; no llega a 16»*, o sea que ahí **el límite duro no
era la causa**. Hay que rehacerla con `tools/vdc_slots.py`.

### 3. A-GRAF — gráficos con texto por traducir. **LOS EDITA DAVID**

Nuestro trabajo: **localizarlos, extraerlos a PNG y pasárselos**, y luego
**reinsertar** lo que devuelva. Nada de editar píxeles por nuestra cuenta.

### 4. Y en `docs/PENDIENTES.md`

- **A-NOM**: «Raqueta» en singular. Alternativas de 6 letras: «Nieve»,
  «Calzas», «Zuecos». **Decide David.**
- **2 bloques japoneses del banco `$25`**: `0x4A484` (53 B, el final) y
  `0x4A71F` (154 B, créditos con «HUDSON SOFT»). *(El tercero, el baño, se
  cerró en la v401.)*
- Bug gráfico bajo la cabeza del ogro rosa (final Difícil).
- Tabla `0x24DE` (presentación de enemigos): apunta a offsets japoneses.
- Colas invisibles en las descripciones de objeto.
- Posadero: falta «ogros.».
- Backup RAM `0x1F51E` (674 B, sin revisar).
- 5 mensajes del menú (`0x435E6`, `0x4363D`, `0x4366B`, `0x4369C`, `0x436CC`).

### Testeo acumulado

Sobre la v391: fase completa, todos los aldeanos, todas las tiendas, varios
minijuegos, el quiz, el jefe final, los cuatro finales y las dos pantallas
secretas. Sobre la v393: primer nivel completo. Sobre la v398 y la v401:
bocadillos del abuelo y de aldeanos, vítores, la aldeana de Kaguya, la tienda
y las dos páginas del baño, confirmados por David en pantalla.

**Aviso de método:** la no-regresión de los textos dio **0 diferencias**, y
eso **no prueba los textos**: ninguno de los 60 states está en la tienda, el
baño ni ante la aldeana. Sólo prueba que no se rompió lo demás. Los textos
los validó David jugando (norma 385).

---

## 8. El workspace

```
COMO_RETOMAR.md              arranque rápido (leer primero)
Momotaro/
  LEEME.md                   normas 12-392 + estado
  investigation.md           diario, 282 entradas, ~36.600 líneas
  roms/                      japonesa virgen + oficial + v395/396/398/401
  parches/                   oficial + 16 hitos (v334…v401)
  states/                    60 savestates + la .sav de David
  capturas/                  N4_*, N5_*, A-CASA_*, v400_textos, v401_bano,
                             bug_vitores/, bugs_nuevos/{mesen,mesen2,ppt}/
  docs/                      PENDIENTES.md (registro único), PROMPT_METODO.md,
                             MESEN_como_mirar_la_RAM.md, MAQUETACION_*,
                             QUIZ.md, GUION_para_traducir.md, este informe
    historico/               informes de etapas cerradas (v386, v393…)
  tools/                     el toolkit (58 ficheros)
    historico/               los build_* de versiones retiradas
Nekketsu/                    proyecto aparte, TERMINADO (v2.18)
                             (rom/*.md es Mega Drive, NO Markdown)
```

### El método (`docs/PROMPT_METODO.md`)

Diario en `investigation.md`. **Las hipótesis falsas NO se borran**: se marcan
`[DESCARTADO]` o `[ERROR PROPIO]` y se explica **qué falló en el
razonamiento** — la 277 corrige a la 275, la 279 a la 277, la 281 a la 280 y
la 282 a la 281, y todas siguen ahí. Una medición → una causa → un arreglo →
una verificación. Prohibido escribir bytes a ciegas. Cada versión con
MD5/SHA-1/CRC32, asserts con byte esperado y zonas intactas, IPS contra la
virgen con round-trip. `docs/PENDIENTES.md` es el registro único: si algo no
está ahí, se olvida.

**Lo que más ha costado en esta tanda, en una frase:** cinco de los siete
errores propios fueron *dar por medido algo que estaba escrito en el diario
pero no comprobado* — la tabla `$9BBD` teniendo ya una cueva, los vítores
«independientes», el `$00` de fin de página, el ancho de 17, el assert
copiado. **Antes de construir sobre una entrada vieja, volver a medirla**
(normas 381, 384 y 390).
