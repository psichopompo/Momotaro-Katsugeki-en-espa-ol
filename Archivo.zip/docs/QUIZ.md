# El QUIZ del ermitaño — maquetación completa

> **Decisión de David: vía fiel.** *«Los jugadores sabrán dónde se meten,
> así que, que se apañen.»*

---

## 1. Corrección: existe una TABLA DE PUNTEROS. Me equivoqué. [HECHO]

En la versión anterior de este documento escribí:

> *«41 bloques, longitud VARIABLE, SIN TABLA, delimitados por el «?» final»*

**Es falso.** La tabla existe y está en **`0x11818`** (banco `$08`, ventana
`$C000-$DFFF`, punteros con base `$6000` → ROM `0x4A000 + p - 0x6000`).

Cómo la encontré: desensamblando la rutina que pinta el bocadillo del
ermitaño (`$D7E6`, ROM `0x117E6`) apareció justo detrás, en `0x11818`, una
lista de words crecientes. Seguí cada puntero y todos aterrizan en el quiz.

```
0x11818 + 2*i     84 punteros
  i =  0          $6E3B   texto «acierta todas y te daré un don»
  i =  1          $6E63   texto «si me ganas, te doy una técnica»
  i =  2 .. 41    las 40 PREGUNTAS
  i = 42 .. 81    los 40 tríos de RESPUESTAS
  i = 82 .. 95    los 14 nombres de técnica
```

**Consecuencias:**

1. **No son 41 preguntas, son 40.** El bloque `0x4AEE6` («オコタエハ?» =
   «¿tu respuesta?») **no** es la pregunta 0: es el **rótulo** de la ventana
   de opciones, y lo apunta el índice 95, no el 0.
2. **Las longitudes se pueden cambiar.** Al haber tabla, cada bloque se
   puede alargar o acortar; solo hay que reescribir su puntero. Ya no hace
   falta que el total cuadre al byte.
3. El troceo que hice «por el `?` final» estaba **desplazado**: metía el
   relleno del bloque siguiente al final del anterior. Por eso me salían
   longitudes raras (26, 47, 44...). Con la tabla, **todos los bloques miden
   exactamente 32 columnas**, sin excepción.

Norma 283 («antes de trocear texto, encontrar el LECTOR») incumplida otra
vez: troceé por un byte que parecía delimitador y resultó ser texto.

---

## 2. La geometría real, leída del código [HECHO]

### Preguntas: 2 líneas de 16 columnas

Rutina `$DD53` (ROM `0x11D53`):

```
$DD8B   LDA $3D28 / CMP #$20 / BCC $DD53      -> 32 columnas en total
$DD93   (al leer el byte $80)  LDA #$10 / STA $3D28   -> salta a la col 16
```

O sea: el contador de columna llega a `$20` (32) y el byte `$80` **no es un
terminador**, es un **salto de línea** que fuerza la columna 16.

```
+----------------+
|línea 1: 16 col |
|línea 2: 16 col |
+----------------+
```

### Opciones: 4 líneas de 8 columnas

Rutina `$DAC0` (ROM `0x11AC0`), llamada con `$3D29` = 0, 1, 2, 3:

```
$DB00   LDA $3D28 / CMP #$08 / BCC $DAD2      -> 8 columnas por línea
$DB0B   LDA $3D29 / ASL / ASL / ORA (col>>1)  -> indexa la tabla VRAM $78E8
```

La línea 0 es el rótulo; las líneas 1, 2 y 3 son las tres opciones. **La
columna 0 la ocupa el cursor `▶`**, así que quedan **7 caracteres útiles**.

### Corrección a David sobre el ancho

David dijo: *«yo diría que cabe algo más de lo que dices. Tal vez cosas como
"C. Mágica"»*. En mi respuesta anterior contesté «caben 10». **Las dos cifras
están mal, y la mía era la peor.** El máximo medido en el código es **8
columnas por línea, 7 útiles**. `C. Mágica` son 9: no cabe.

De dónde salió mi error: conté las columnas del volcado japonés y me salían
períodos de 8, pero interpreté el bloque de 24 columnas como *una celda de
10 bytes* en vez de *tres líneas de 8*. La prueba definitiva es la captura de
David: `オコタエハ?` ocupa 6 columnas y el marco tiene exactamente 8 de
ancho, no 10.

---

## 3. Las 40 preguntas traducidas

Formato: `|línea 1 (16)|línea 2 (16)|` y las tres opciones (7 útiles).
El **orden de las opciones es intocable**: la respuesta correcta se
identifica por su índice, no por su texto.

| # | Línea 1 | Línea 2 | Opción 1 | Opción 2 | Opción 3 |
|---|---|---|---|---|---|
| 1 | `¿Qué dio Otohime` | `a Urashima?` | `Joyero` | `Sustos` | `Plumier` |
| 2 | `¿En qué monte` | `nació Kintaro?` | `Kintoki` | `Fuji` | `Everest` |
| 3 | `¿Qué brotó de la` | `tumba de Shiro?` | `Pino` | `Bambú` | `Ciruelo` |
| 4 | `¿Al quemar qué` | `salió la ceniza?` | `Cebolla` | `Mortero` | `Salsa` |
| 5 | `¿Quién le quitó` | `el bulto?` | `Kappa` | `Ogro` | `Médico` |
| 6 | `¿Adónde volvió` | `Kaguya?` | `Sol` | `Marte` | `Luna` |
| 7 | `Issunboshi, ¿qué` | `usó por espada?` | `Palitos` | `Aguja` | `Palillo` |
| 8 | `¿Qué comió el` | `gorrión goloso?` | `Pollo` | `Trigo` | `Engrudo` |
| 9 | `¿Qué había en el` | `cesto pesado?` | `Duendes` | `Leña` | `Cuervos` |
| 10 | `¿Cuántos vecinos` | `hay en tu aldea?` | `6` | `7` | `8` |
| 11 | `¿Qué había en el` | `agujero?` | `Mamut` | `Topo` | `Ratones` |
| 12 | `¿Quién castigó` | `al tanuki?` | `Zorro` | `Conejo` | `Jirafa` |
| 13 | `Mono y cangrejo:` | `¿qué le tiró?` | `Caqui` | `Piedra` | `Bola` |
| 14 | `¿Qué recogió el` | `cangrejo antes?` | `Semilla` | `Onigiri` | `Dinero` |
| 15 | `¿Quién era la` | `tetera mágica?` | `Zorro` | `Camello` | `Tanuki` |
| 16 | `¿En qué árbol` | `brotaron flores?` | `Pino` | `Cerezo` | `Abedul` |
| 17 | `El chas-chas del` | `monte, ¿qué es?` | `Tablas` | `Reloj` | `Sílex` |
| 18 | `¿Quién cubrió a` | `los Jizo?` | `Abuelo` | `Abuela` | `Niño` |
| 19 | `Ushiwakamaru,` | `¿contra quién?` | `Ogro` | `Tengu` | `Benkei` |
| 20 | `¿Quién hizo sumo` | `con Kintaro?` | `Asashio` | `Oso` | `Tigre` |
| 21 | `¿Qué llevaba` | `Orochi dentro?` | `Caca` | `Valor` | `Espada` |
| 22 | `¿Cómo se llama` | `la princesa?` | `Toyo` | `Otohime` | `Peach` |
| 23 | `¿Qué pez tragó` | `el anzuelo?` | `Platija` | `Besugo` | `Luna` |
| 24 | `¿Qué dios mató` | `a Orochi?` | `Izanagi` | `Susanoo` | `Pobreza` |
| 25 | `¿A qué isla fue` | `el conejo?` | `Sakura` | `Sado` | `Oki` |
| 26 | `¿Cuándo salió a` | `vender gorros?` | `Mayores` | `Fin año` | `Navidad` |
| 27 | `¿Qué deporte` | `hizo Kintaro?` | `Aeróbic` | `Lucha` | `Sumo` |
| 28 | `¿Cuánto cuestan` | `los momos?` | `100$` | `200$` | `300$` |
| 29 | `¿De qué nació` | `Kaguya?` | `Pino` | `Bambú` | `Col` |
| 30 | `¿Quién no entró` | `en el zodiaco?` | `Perro` | `Gato` | `Lagarto` |
| 31 | `Y con el gorro,` | `¿qué más?` | `Peluca` | `Medias` | `Toalla` |
| 32 | `¿Quién compró la` | `tetera mágica?` | `Señor` | `Bonzo` | `Artista` |
| 33 | `¿Qué le untó al` | `tanuki?` | `Chile` | `Wasabi` | `Ajo` |
| 34 | `¿En qué barco` | `iba Issunboshi?` | `Plato` | `Copita` | `Cuenco` |
| 35 | `¿Con qué creció` | `Issunboshi?` | `Porra` | `Mazo` | `Tacones` |
| 36 | `La rata, al fin,` | `¿con quién casó?` | `Sol` | `Muro` | `Ratón` |
| 37 | `En el biombo,` | `¿qué cazó Ikkyu?` | `Mamut` | `Tigre` | `Lagarto` |
| 38 | `¿Qué enseñó el` | `viejo al ogro?` | `Calva` | `Culo` | `Baile` |
| 39 | `En la carrera,` | `¿quién ganó?` | `Liebre` | `Tortuga` | `Empate` |
| 40 | `Este juego es` | `Momotaro ¿qué?` | `Leyenda` | `Acción` | `Tren` |

**Rótulo de la ventana de opciones** (`オコタエハ?` = «¿tu respuesta?»):
`Elige:` — 6 columnas de 8. En esa línea el cursor no aparece, así que puede
empezar en la columna 0.

### Decisiones de traducción que conviene revisar

- **P2, Everest.** Hecho, como pediste. El chiste japonés era meter el
  Chomolungma entre dos montes japoneses reales; con «Everest» se conserva
  igual y ahorra 4 columnas.
- **P13, `Bola`.** El original dice *bola de bolos*: no cabe en 7. «Bola»
  mantiene lo absurdo de la opción.
- **P21.** La pregunta original que redacté («Del cuerpo de / Orochi,
  ¿qué?») **no se entendía**; reformulada a «¿Qué llevaba / Orochi
  dentro?». Las opciones son *la espada del valor* (inventada) y *Kusanagi*
  (la real, **correcta**). `Kusanagi` son 8 y no cabe, y `Kusanag` sería
  abreviar, así que queda `Espada`.
- **P28, `100$`. El `$` NO pinta un dólar.** [HECHO] El byte `$24` pasa por
  la tabla de sustitución `$AB34` (`$24` → `$3E`) y acaba en el **glifo
  `$FF`**, que es exactamente el que usa el japonés aquí (`100` + `$3E`): el
  símbolo del **ryo** que ya se ve en todo el juego. Renderizado desde la
  VRAM para confirmarlo. Lo que estaba mal era mi comentario, que además
  decía «mon» en vez de «ryo».
- **P35, `Porra` / `Mazo` / `Tacones`.** Las tres reales son *tonkachi*
  (martillo corriente), *uchide-no-kozuchi* (el mazo mágico que concede
  deseos, **la correcta**) y *haihiiru* (tacones). `Mágico` era un adjetivo
  y no decía qué objeto era; David propuso cambiar la falsa por `Porra`,
  que deja `Mazo` limpio para la correcta.
- **P37, `Lagarto`.** El original es el *lagarto de gorguera*, que es el
  chiste. No cabe. Igual en P30.

Todo esto está en `tools/quiz_texto.py`, que **falla ruidosamente** si algún
texto se pasa de columnas.

---

## 4. Espacio: sobra de largo [HECHO]

```
zona actual del quiz   0x4AEEE .. 0x4B87B   = 2445 B
necesario en castellano  40 x 32 + 40 x 24  = 2240 B
sobran                                        205 B
hueco de $FF tras 0x4B93B                    1733 B
```

No hace falta ni repuntar: el castellano ocupa **menos** que el japonés,
porque el japonés gasta bytes en dakuten que no consumen columna. Aun así
**reescribiré la tabla `0x11818` entera**, porque es más seguro que confiar
en que cada bloque caiga donde caía (norma 287: el assert seguirá el puntero
como hace el motor).

---

## 5. Lo que queda por decidir

1. Las alternativas señaladas arriba (P21, P28, P35).
2. Nada más: la estructura está cerrada y medida.

---

## 6. La tabla de respuestas correctas — `$DCD0` (ROM `0x11CD0`) [HECHO]

```
$DCA7   LDX $3D1D / LDA $3D2A,X / TAY
$DCAE   LDA $DCD0,Y / CMP $3D14      <- compara con la opcion elegida
```

40 bytes, valores 0-2. **El orden de las tres opciones es INTOCABLE**: la
correcta se identifica por índice, no por texto.

Verificado que mi traducción cuadra con las 40 correctas. La única que
chirriaba era la P21: la correcta es la opción 2 (`kusanagi-no-ken`, la
espada real) y yo había puesto ahí `Hierba`, que en castellano no se lee
como una espada. Corregido a `Espada`.

## 7. Charset: es `charset_oficial`, no `charset_rotulos` [HECHO]

El renderer `$AAB4` bifurca en `$AAB9` (`CMP #$A0 / BCC`):

```
byte >= $A0   ruta katakana:  glifo = byte
byte <  $A0   ruta tabla:     glifo = $BF9B[byte - $30]     (ROM 0x43F9B)
```

En esa tabla: `$5B`→`$A2` (**b**), `$5D`→`$A3` (**c**), `$5E`→`$B0` (**p**),
que son exactamente los tres alias de `charset_oficial`.

Los alias `e=$3D` / `o=$62` de `charset_rotulos` dan los glifos `$A5` y `$AF`:
sirven para el motor de rótulos, **no** para este. En el primer intento
escribí un codificador que forzaba `e/o/b/c` a ASCII puro; **lo cazó el
assert de relectura por puntero** (norma 287), no yo.
