# Rótulos del menú SELECT — tanda completa, para revisar

Base: `momotaro_es_v308.pce`. **Nada escrito en la ROM todavía.**

---

## Cómo funciona (medido hoy, no de notas viejas)

Los siete rótulos son **gráficos**, no texto. Viven en el bloque de CG
comprimido del menú:

```
bloque CG    ROM 0x0F3D9 .. 0x0F96C   1427 B   96 tiles ($100-$15F)
descompresor $C1CC/$C206  (tools/descomp_cg.py)
```

Verificado hoy: descomprime **96/96 tiles idénticos** al state del menú, y
recomprimir devuelve los 1427 B exactos. Round-trip bueno.

**Ojo, el bloque se movió.** El diario lo situaba en `0x7F8F2`; en la v308
está en `0x0F3D9`. Ahí ya no hay margen (0 B), pero la zona vieja
`0x7F8F2` quedó libre: **1806 B**. Y hay otro hueco de 2182 B en
`0x7EF7A`. Espacio no falta.

### Por qué NO se pueden escribir como texto

Sería lo cómodo, y la sección 9 de `menu_SELECT.md` llegó a decirlo, pero
está rectificado y lo he vuelto a medir:

```
celdas estáticas de la BAT   byte alto $01  ->  patrones $100-$1FF
celdas de texto dinámico     byte alto $02  ->  patrones $2xx   (38 celdas)
```

La fuente vive en `$2xx`. El RLE de la BAT (`0x1E7EA`) solo guarda el byte
bajo, así que un rótulo escrito en la BAT no puede apuntar a la fuente.
Las 38 celdas que sí lo hacen (las cifras, el nombre del arma) las escribe
el código en ejecución, celda a celda.

**Conclusión: hay que redibujar los glifos dentro del CG.**

---

## El espacio de cada rótulo (medido sobre el state)

El límite no es el ancho del panel: es la primera celda ocupada a la
derecha (la cifra, o el borde del recuadro).

```
rótulo            fila  ancho    lo que hay a la derecha
体力  vitalidad     3     8 celdas   la cifra, en la columna 10
技    técnica       5     8 celdas   la cifra, en la columna 10
金    dinero        7     4 celdas   el importe, desde la columna 6
ぶき   arma         10    10 celdas   el nombre del arma
ぼうぐ armadura      15    10 celdas   el nombre de la armadura
どうぐ objetos        3     8 celdas   (panel central)
じゅつ artes          3     6 celdas   (panel derecho, el más estrecho)
```

---

## La línea base

Lo que avisaste. Medido en los tres rótulos del panel izquierdo: la tinta
está **exactamente en y=6..15** de la banda de 24 px (10 px de alto), y
los tres coinciden al píxel. Cualquier letra nueva tiene que caer en ese
mismo carril.

Ya tengo dibujadas las cinco letras de SALUD a esa altura
(`tools/rotulo_salud.py`), verificado que las cinco empiezan en la fila 0
y acaban en la 9: ninguna sobresale arriba ni abajo.

```
 y 6  ..####...####..##.....##..##.#####
 y 7  .##..##.##..##.##.....##..##.##..##
 y 8  .##.....##..##.##.....##..##.##...#
 y 9  .##.....##..##.##.....##..##.##...#
 y10  ..####..######.##.....##..##.##...#
 y11  .....##.##..##.##.....##..##.##...#
 y12  .....##.##..##.##.....##..##.##...#
 y13  .....##.##..##.##.....##..##.##...#
 y14  .##..##.##..##.##.....##..##.##..##
 y15  ..####..##..##.######..####..#####
```

35 px de los 64 disponibles.

---

## Propuesta: qué pondría en cada rótulo

```
kanji   significado      celdas   PROPUESTA   alternativas que caben
体力     vitalidad         8       SALUD       VIDA
技      técnica           8       TÉCNICA     TECNICA, ARTE
金      dinero            4       ORO         DIN, YEN, MON
ぶき     arma             10       ARMA        ESPADA, ARMAS
ぼうぐ    armadura         10       ARMADURA    CORAZA, DEFENSA
どうぐ    objetos           8       OBJETOS     ITEMS, BOLSA
じゅつ    artes             6       ARTES       MAGIA, GOLPES
```

Notas:

- **SALUD** en vez de VIDA es lo que acordamos: la barra son puntos, no
  vidas, y así casa con «Salud +1.» de las descripciones.
- **TÉCNICA** cabe con tilde (7 de 8 celdas). Si prefieres que case con
  «Técnica +1.», es la misma palabra.
- **DINERO no cabe**: solo hay 4 celdas porque el importe empieza en la
  columna 6. `ORO` es lo más natural. La alternativa sería mover el
  importe, que es tocar código.
- **ARTES** son las técnicas de combate; el proyecto ya decidió que no son
  magia (norma del diario: «son técnicas físicas de acción»).

---

## Trabajo que supone

Hay que dibujar **22 letras distintas**: A B C D E I J L M N O R S T U Z
más É y las que salgan de tu revisión. Cada una a 7x10 px, todas con la
misma línea base.

Luego se recomprime el bloque y se reubica a `0x7F8F2` (1806 B libres) si
crece por encima de los 1427 B actuales.

**Decide tú los siete textos.** Cuando estén cerrados dibujo el alfabeto
completo y te paso una vista previa de cada rótulo antes de tocar la ROM.