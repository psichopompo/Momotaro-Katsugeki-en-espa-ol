# Guion de Momotarou Katsugeki — 87 textos, 5415 bytes

## CÓMO SE MUESTRA ESTE TEXTO — leer antes de traducir

Los bocadillos de aldeanos, tiendas y ermitaño son **VERTICALES**:
el texto se lee de arriba abajo, y las columnas de DERECHA A IZQUIERDA.

El byte `$3B` separa columnas. Medido sobre los 87 textos:

```
caracteres por columna:  máximo 9, la mayoría 5-6
columnas por texto:      de 3 a 23, lo típico 12
```

Una columna admite **6 caracteres cómodos, 9 como tope**. En japonés
eso es una palabra entera; en castellano, media.

## Notación

- Cada `col` es una columna vertical. La `col 0` es la de MÁS A LA DERECHA.
- `…` es el byte `$3D`, `！` y `？` son `$21` y `$3F`.
- Las columnas vacías son separaciones entre frases.
- `entradas` = qué posiciones de la tabla de punteros usan ese texto.
  Varias entradas significan que el mismo texto sale en varias situaciones.

---

## [0]  0x48F91   42 bytes   6 columnas

entradas de tabla: 0, 1

```
col  0 (6) モモタロヨ…
col  1 (8) {2B}ボタンヲ
col  2 (4) タタケバ
col  3 (3) オニヲ
col  4 (4) コウゲキ
col  5 (5) デキルゾ…
```

**ES:**

## [1]  0x48FBB   41 bytes   6 columnas

entradas de tabla: 2, 3

```
col  0 (3) ブキヤ
col  1 (4) ボウグヲ
col  2 (6) カッテイケバ
col  3 (4) ドンドン
col  4 (5) ラクチンニ
col  5 (6) ナルノジャ…
```

**ES:**

## [2]  0x48FE4   43 bytes   6 columnas

entradas de tabla: 4, 5

```
col  0 (4) オミセニ
col  1 (5) ハイルニハ
col  2 (5) イリグチデ
col  3 (4) ジュウジ
col  4 (4) ボタンヲ
col  5 (6) ウエ　デスダ
```

**ES:**

## [3]  0x4900F   46 bytes   6 columnas

entradas de tabla: 6, 7

```
col  0 (3) オニヲ
col  1 (6) コラシメタラ
col  2 (6) ブキヲ　カエ
col  3 (6) ボウグ　カエ
col  4 (6) ドウグ　カエ
col  5 (6) ワッハッハ…
```

**ES:**

## [4]  0x4903D   34 bytes   5 columnas

entradas de tabla: 8, 9

```
col  0 (4) ジブンノ
col  1 (4) ツヨサヲ
col  2 (5) ミタイナラ
col  3 (5) セレクトヲ
col  4 (6) オスノデスヨ
```

**ES:**

## [5]  0x4905F   42 bytes   6 columnas

entradas de tabla: 10, 11

```
col  0 (5) センニンハ
col  1 (6) タカイトコニ
col  2 (6) スンデオル…
col  3 (6) センジュツヲ
col  4 (4) オシエテ
col  5 (6) モラウガヨイ
```

**ES:**

## [6]  0x49089   57 bytes   9 columnas

entradas de tabla: 12, 13

```
col  0 (6) ランボタンヲ
col  1 (3) オスト
col  2 (0) 
col  3 (4) ジュツヤ
col  4 (4) ドウグガ
col  5 (6) ツカエルゾ…
col  6 (4) モットモ
col  7 (6) モッテナイト
col  8 (6) ツカエンガ…
```

**ES:**

## [7]  0x490C2   86 bytes   12 columnas

entradas de tabla: 14, 15

```
col  0 (8) {2A}ボタンデ
col  1 (4) ジャンプ
col  2 (4) シナガラ
col  3 (8) {2B}ボタンデ
col  4 (4) コウゲキ
col  5 (5) スルノダ…
col  6 (5) セッシャモ
col  7 (2) コノ
col  8 (5) ヤリカタデ
col  9 (3) オニヲ
col 10 (18) {31}{30}{30}{30}ビキ
col 11 (6) タオシタゾ…
```

**ES:**

## [8]  0x49118   26 bytes   4 columnas

entradas de tabla: 16

```
col  0 (4) サクラヲ
col  1 (4) サカセテ
col  2 (5) クダセー…
col  3 (6) オネゲーダ…
```

**ES:**

## [9]  0x49132   52 bytes   8 columnas

entradas de tabla: 17

```
col  0 (3) オオ…
col  1 (4) サクラガ
col  2 (6) ウツクシイ…
col  3 (4) フタタビ
col  4 (6) サクラノサク
col  5 (4) ムラニ…
col  6 (5) アリガトウ
col  7 (6) ゴゼエマスダ
```

**ES:**

## [10]  0x49166   58 bytes   10 columnas

entradas de tabla: 18

```
col  0 (4) シクシク
col  1 (5) オニタチガ
col  2 (0) 
col  3 (5) コノムラノ
col  4 (4) サクラヲ
col  5 (5) チラセタノ
col  6 (4) トッテモ
col  7 (6) キレイナムラ
col  8 (5) ダッタノニ
col  9 (4) シクシク
```

**ES:**

## [11]  0x491A0   59 bytes   12 columnas

entradas de tabla: 19

```
col  0 (3) マア…
col  1 (5) ツヨソウナ
col  2 (4) イヌネ…
col  3 (5) シッテル？
col  4 (0) 
col  5 (0) 
col  6 (5) サイキンノ
col  7 (3) イヌハ
col  8 (0) 
col  9 (6) テナゲダンヲ
col 10 (6) ツカウンデス
col 11 (3) ッテ…
```

**ES:**

## [12]  0x491DB   39 bytes   6 columnas

entradas de tabla: 20

```
col  0 (4) グルグル
col  1 (6) マワルオニハ
col  2 (0) 
col  3 (5) マワッテル
col  4 (4) アイダハ
col  5 (6) タオセンゾ…
```

**ES:**

## [13]  0x49202   69 bytes   12 columnas

entradas de tabla: 21

```
col  0 (6) ツイサイキン
col  1 (6) キイタノダガ
col  2 (0) 
col  3 (5) ハナサカノ
col  4 (5) ジイサマハ
col  5 (0) 
col  6 (6) モモタロウヲ
col  7 (6) タスケルタメ
col  8 (0) 
col  9 (5) ドウグヤヲ
col 10 (5) カイギョウ
col 11 (6) シタンダト…
```

**ES:**

## [14]  0x49247   85 bytes   14 columnas

entradas de tabla: 22, 23

```
col  0 (5) ココダケノ
col  1 (6) ハナシジャ…
col  2 (0) 
col  3 (6) ボスキャラノ
col  4 (6) ジャクテンハ
col  5 (0) 
col  6 (4) カラダニ
col  7 (5) ツイテイル
col  8 (6) マト　ラシイ
col  9 (5) ココダケノ
col 10 (6) ハナシジャ…
col 11 (0) 
col 12 (5) ミンナニハ
col 13 (6) ナイショダゾ
```

**ES:**

## [15]  0x4929C   69 bytes   9 columnas

entradas de tabla: 24

```
col  0 (5) サクラッテ
col  1 (6) スゴクキレイ
col  2 (5) ラシイケド
col  3 (5) コノムラニ
col  4 (4) サクラガ
col  5 (6) サイテタノハ
col  6 (3) ボクガ
col  7 (6) ウマレルマエ
col  8 (6) ナンダッテ…
```

**ES:**

## [16]  0x492E1   63 bytes   12 columnas

entradas de tabla: 25

```
col  0 (3) コレガ
col  1 (6) サクラカア…
col  2 (0) 
col  3 (4) ホントニ
col  4 (6) キレイダネ…
col  5 (0) 
col  6 (5) コノハナヲ
col  7 (4) ミテルト
col  8 (0) 
col  9 (4) ココロガ
col 10 (6) ウキウキシテ
col 11 (4) クルネ…
```

**ES:**

## [17]  0x49320   21 bytes   3 columnas

entradas de tabla: 26

```
col  0 (5) コノムラニ
col  1 (4) サクラガ
col  2 (6) マタサクラ？
```

**ES:**

## [18]  0x49335   83 bytes   14 columnas

entradas de tabla: 27

```
col  0 (6) サークーラー
col  1 (6) サークーラー
col  2 (0) 
col  3 (5) アリガトウ
col  4 (6) ゴザイマシタ
col  5 (0) 
col  6 (3) コレデ
col  7 (5) コノムラモ
col  8 (4) ムカシノ
col  9 (5) アカルサヲ
col 10 (6) トリモドシタ
col 11 (5) ヨウデス…
col 12 (5) ホントウニ
col 13 (6) アリガトウ…
```

**ES:**

## [19]  0x49388   39 bytes   6 columnas

entradas de tabla: 28, 29

```
col  0 (3) ココハ
col  1 (6) キンタロウノ
col  2 (6) 　　　　ムラ
col  3 (6) アシガラヤマ
col  4 (5) ノフモトデ
col  5 (4) ゴワス…
```

**ES:**

## [20]  0x493AF   79 bytes   14 columnas

entradas de tabla: 30

```
col  0 (6) アシガラヤマ
col  1 (2) カラ
col  2 (5) オチテクル
col  3 (4) デッケエ
col  4 (6) キンタロアメ
col  5 (6) ノセイデヨオ
col  6 (5) サクモツハ
col  7 (5) トレネエ…
col  8 (0) 
col  9 (3) ソトモ
col 10 (6) アルケネエ…
col 11 (0) 
col 12 (4) フンダリ
col 13 (6) ケッタリダ…
```

**ES:**

## [21]  0x493FE   75 bytes   14 columnas

entradas de tabla: 31

```
col  0 (6) オニタイジヲ
col  1 (6) シテクレタノ
col  2 (3) カイ…
col  3 (4) アンタノ
col  4 (4) オカゲデ
col  5 (0) 
col  6 (5) コノムラモ
col  7 (6) ムカシミタク
col  8 (0) 
col  9 (4) ヘイワニ
col 10 (6) ナッタダヨ…
col 11 (0) 
col 12 (4) ホントニ
col 13 (6) アリガトヨ…
```

**ES:**

## [22]  0x49449   88 bytes   12 columnas

entradas de tabla: 32

```
col  0 (6) キンタロアメ
col  1 (6) イランカア…
col  2 (0) 
col  3 (6) キンタロアメ
col  4 (6) イランカア…
col  5 (4) ウウッ…
col  6 (6) キンタロアメ
col  7 (6) ガ　ゴロゴロ
col  8 (6) シトルセイデ
col  9 (4) コチトラ
col 10 (5) ショウバイ
col 11 (6) アガッタリダ
```

**ES:**

## [23]  0x494A1   85 bytes   15 columnas

entradas de tabla: 33

```
col  0 (6) キンタロアメ
col  1 (6) イランカア…
col  2 (0) 
col  3 (6) キンタロアメ
col  4 (6) イランカア…
col  5 (0) 
col  6 (6) ハッハッハ…
col  7 (0) 
col  8 (0) 
col  9 (5) オニタイジ
col 10 (5) シテクレタ
col 11 (4) オカゲデ
col 12 (4) コチトラ
col 13 (5) ショウバイ
col 14 (6) ハンジョウ…
```

**ES:**

## [24]  0x494F6   84 bytes   14 columnas

entradas de tabla: 34

```
col  0 (5) オニタチガ
col  1 (6) アシガラヤマ
col  2 (1) ニ
col  3 (4) ハシゴヲ
col  4 (4) タクサン
col  5 (5) カケテネエ
col  6 (5) テッペンニ
col  7 (5) ノボロウト
col  8 (2) スル
col  9 (5) タビビトニ
col 10 (3) モノヲ
col 11 (5) ナゲツケテ
col 12 (5) ジャマスル
col 13 (4) ソウナ…
```

**ES:**

## [25]  0x4954A   43 bytes   6 columnas

entradas de tabla: 35

```
col  0 (6) オニタイジヲ
col  1 (6) シテクレタト
col  2 (6) イウノカイ…
col  3 (6) イヤ　ホンニ
col  4 (5) アリガタイ
col  5 (4) コッテ…
```

**ES:**

## [26]  0x49575   37 bytes   5 columnas

entradas de tabla: 36

```
col  0 (6) コノムラデハ
col  1 (6) キンタロアメ
col  2 (6) ヲ　ツクッテ
col  3 (4) セイカツ
col  4 (6) シテルノデス
```

**ES:**

## [27]  0x4959A   75 bytes   12 columnas

entradas de tabla: 37

```
col  0 (3) コンド
col  1 (6) コノムラデハ
col  2 (0) 
col  3 (6) アナタサマノ
col  4 (5) コウセキヲ
col  5 (5) キネンシテ
col  6 (6) モモタロアメ
col  7 (6) ヲ　ツクッテ
col  8 (5) イクコトニ
col  9 (4) ソンミン
col 10 (5) イチドウデ
col 11 (6) キメマシタ…
```

**ES:**

## [28]  0x495E5   74 bytes   12 columnas

entradas de tabla: 38

```
col  0 (6) キンタロアメ
col  1 (6) ガ　イッパイ
col  2 (6) タベレルノハ
col  3 (6) ウレシイケド
col  4 (0) 
col  5 (0) 
col  6 (6) トウチャンヤ
col  7 (6) カアチャンガ
col  8 (0) 
col  9 (6) ショウバイニ
col 10 (6) ナラナイッテ
col 11 (6) ナイテルノ…
```

**ES:**

## [29]  0x4962F   48 bytes   9 columnas

entradas de tabla: 39

```
col  0 (5) ネエネエ…
col  1 (5) シッテル？
col  2 (0) 
col  3 (5) キジサンガ
col  4 (3) イレバ
col  5 (0) 
col  6 (4) ジユウニ
col  7 (3) ソラヲ
col  8 (6) トベルンダヨ
```

**ES:**

## [30]  0x4965F   42 bytes   6 columnas

entradas de tabla: 40

```
col  0 (5) ニチリンノ
col  1 (6) 　　　ツブテ
col  2 (5) サエアレバ
col  3 (6) ココラヘンノ
col  4 (3) オニハ
col  5 (6) コワクナイゾ
```

**ES:**

## [31]  0x49689   77 bytes   12 columnas

entradas de tabla: 41

```
col  0 (6) オヤ？オヌシ
col  1 (3) サルヲ
col  2 (6) ツレトルノカ
col  3 (3) サルハ
col  4 (5) ムカシカラ
col  5 (0) 
col  6 (5) サルマネガ
col  7 (5) トクイダト
col  8 (3) キクガ
col  9 (5) ソノサルハ
col 10 (5) ドウナノデ
col 11 (6) アロウカノ…
```

**ES:**

## [32]  0x496D6   17 bytes   3 columnas

entradas de tabla: 42, 43

```
col  0 (3) ココハ
col  1 (5) ネタロウノ
col  2 (6) 　　　　ムラ
```

**ES:**

## [33]  0x496E7   54 bytes   8 columnas

entradas de tabla: 44, 45

```
col  0 (4) ジメンガ
col  1 (6) コオッテイル
col  2 (4) トコロハ
col  3 (4) スベッテ
col  4 (6) アルキニクイ
col  5 (5) モンジャ…
col  6 (6) チュウイスル
col  7 (6) コトジャナ…
```

**ES:**

## [34]  0x4971D   56 bytes   9 columnas

entradas de tabla: 46, 47

```
col  0 (6) ワルイコトハ
col  1 (5) イワネエ…
col  2 (0) 
col  3 (6) ココラヘンハ
col  4 (5) カンジキヲ
col  5 (6) ハクコッタ…
col  6 (3) ソコノ
col  7 (5) ドウグヤデ
col  8 (6) ウットルダ…
```

**ES:**

## [35]  0x49755   91 bytes   15 columnas

entradas de tabla: 48

```
col  0 (5) オーサム…
col  1 (0) 
col  2 (0) 
col  3 (6) ココラヘンモ
col  4 (6) オニガヤッテ
col  5 (4) キテカラ
col  6 (5) イチダント
col  7 (4) サムサガ
col  8 (6) マシタノジャ
col  9 (4) コドモハ
col 10 (5) ムジャキデ
col 11 (5) エエノウ…
col 12 (6) トシヨリニハ
col 13 (4) サムサガ
col 14 (6) コタエテノウ
```

**ES:**

## [36]  0x497B0   74 bytes   12 columnas

entradas de tabla: 49

```
col  0 (5) オーサム…
col  1 (4) コサム…
col  2 (0) 
col  3 (5) オニタイジ
col  4 (5) シテクレタ
col  5 (4) オカゲデ
col  6 (4) スコシハ
col  7 (5) アタタカク
col  8 (5) ナリマシタ
col  9 (6) イヤ　ホンニ
col 10 (5) アリガトウ
col 11 (6) ゴゼエマシタ
```

**ES:**

## [37]  0x497FA   81 bytes   12 columnas

entradas de tabla: 50

```
col  0 (6) モモタロウノ
col  1 (6) オニイチャン
col  2 (0) 
col  3 (3) オニヲ
col  4 (5) タイジシテ
col  5 (6) チョウダイ…
col  6 (6) オバアサンガ
col  7 (4) サムサデ
col  8 (6) マイッテルノ
col  9 (6) オネガイダヨ
col 10 (3) オニヲ
col 11 (6) タイジシテネ
```

**ES:**

## [38]  0x4984B   61 bytes   11 columnas

entradas de tabla: 51

```
col  0 (6) モモタロウノ
col  1 (6) オニイチャン
col  2 (0) 
col  3 (4) オカゲデ
col  4 (6) オバアサンモ
col  5 (0) 
col  6 (4) スコシハ
col  7 (6) ラクニナッタ
col  8 (3) ミタイ
col  9 (5) ホントウニ
col 10 (6) アリガトウ…
```

**ES:**

## [39]  0x49888   17 bytes   3 columnas

entradas de tabla: 52, 53

```
col  0 (3) ココハ
col  1 (5) ウラシマノ
col  2 (6) 　　　　ムラ
```

**ES:**

## [40]  0x49899   58 bytes   9 columnas

entradas de tabla: 54, 55

```
col  0 (3) ワシハ
col  1 (4) ムカシハ
col  2 (3) ウミデ
col  3 (6) サザエナドヲ
col  4 (12) トル{A2}アマ{A3}
col  5 (4) ジャッタ
col  6 (6) ウミノナカノ
col  7 (4) コトナラ
col  8 (6) クワシイゾヨ
```

**ES:**

## [41]  0x498D3   76 bytes   12 columnas

entradas de tabla: 56, 57

```
col  0 (4) カッパノ
col  1 (6) ミズカキッテ
col  2 (5) シッテル？
col  3 (6) スイチュウデ
col  4 (4) ジユウニ
col  5 (6) オヨゲルノヨ
col  6 (6) ドウグヤサン
col  7 (5) ニアルカラ
col  8 (0) 
col  9 (6) カッテイッタ
col 10 (3) ホウガ
col 11 (5) イイワヨ…
```

**ES:**

## [42]  0x4991F   56 bytes   9 columnas

entradas de tabla: 58

```
col  0 (6) カメノコウラ
col  1 (4) ガナイト
col  2 (0) 
col  3 (4) ウミニハ
col  4 (5) モグレナイ
col  5 (6) ンダッテサ…
col  6 (2) デモ
col  7 (6) ドウヤッタラ
col  8 (7) テニハイルノ？
```

**ES:**

## [43]  0x49957   59 bytes   11 columnas

entradas de tabla: 59

```
col  0 (3) カメヲ
col  1 (5) タスケタラ
col  2 (0) 
col  3 (4) コウラヲ
col  4 (6) カシテクレタ
col  5 (5) ンダッテ…
col  6 (3) ボクモ
col  7 (3) カメヲ
col  8 (4) タスケテ
col  9 (3) ウミニ
col 10 (6) ハイリタイナ
```

**ES:**

## [44]  0x49992   40 bytes   6 columnas

entradas de tabla: 60

```
col  0 (5) ウラシマガ
col  1 (5) オトズレタ
col  2 (6) リュウグウモ
col  3 (4) イマデハ
col  4 (5) オニタチノ
col  5 (3) モノニ
```

**ES:**

## [45]  0x499BA   42 bytes   6 columnas

entradas de tabla: 61

```
col  0 (6) アリガタヤ…
col  1 (6) マタ　ウミニ
col  2 (5) ヘイワガ…
col  3 (3) ミンナ
col  4 (6) アナタサマノ
col  5 (6) オカゲジャ…
```

**ES:**

## [46]  0x499E4   73 bytes   11 columnas

entradas de tabla: 62

```
col  0 (3) ウミガ
col  1 (6) アレテシモテ
col  2 (0) 
col  3 (6) リョウニデル
col  4 (3) コトガ
col  5 (5) デキネエ…
col  6 (6) コノママジャ
col  7 (4) オラタチ
col  8 (6) シンジマウ…
col  9 (6) ドナイスレバ
col 10 (6) イインジャ…
```

**ES:**

## [47]  0x49A2D   59 bytes   9 columnas

entradas de tabla: 63

```
col  0 (3) オオ…
col  1 (6) ウミガモトニ
col  2 (6) モドッタダ…
col  3 (3) コレモ
col  4 (4) アンタノ
col  5 (6) オカゲジャ…
col  6 (4) ホントニ
col  7 (4) アリガト
col  8 (6) ゴゼエヤシタ
```

**ES:**

## [48]  0x49A68   49 bytes   6 columnas

entradas de tabla: 64, 65

```
col  0 (5) コマッタラ
col  1 (6) キジニノッテ
col  2 (6) ノボルンダヨ
col  3 (5) サクシャガ
col  4 (6) イッテタカラ
col  5 (6) ホントダヨ…
```

**ES:**

## [49]  0x49A9A   76 bytes   12 columnas

entradas de tabla: 66, 67

```
col  0 (6) カチカチヤマ
col  1 (2) カラ
col  2 (4) ヒノコガ
col  3 (5) トンデキテ
col  4 (6) アブネッタラ
col  5 (6) アリャシネエ
col  6 (6) ニイチャンモ
col  7 (5) キヲツケナ
col  8 (0) 
col  9 (4) アタルト
col 10 (4) ダメージ
col 11 (5) デカイゼ…
```

**ES:**

## [50]  0x49AE6   60 bytes   11 columnas

entradas de tabla: 68

```
col  0 (3) ハア…
col  1 (6) アツイワア…
col  2 (0) 
col  3 (6) オモイキッテ
col  4 (4) キモノヲ
col  5 (6) ヌゴウカナ？
col  6 (24) {2E}{2E}{2E}{2E}{2E}{2E}
col  7 (20) {2E}{2E}{2E}{2E}{2E}
col  8 (16) {2E}{2E}{2E}{2E}
col  9 (2) ナニ
col 10 (6) ミテンノヨ…
```

**ES:**

## [51]  0x49B22   39 bytes   6 columnas

entradas de tabla: 69

```
col  0 (2) フー
col  1 (6) モトドオリニ
col  2 (6) ナッタミタイ
col  3 (6) アツイノッテ
col  4 (6) ニガテダッタ
col  5 (4) ノヨネエ
```

**ES:**

## [52]  0x49B49   69 bytes   11 columnas

entradas de tabla: 70, 71

```
col  0 (5) ヨウガンニ
col  1 (4) オチルト
col  2 (0) 
col  3 (5) ダメージヲ
col  4 (5) クラウゾ…
col  5 (0) 
col  6 (6) ダイダイイロ
col  7 (5) シテルノガ
col  8 (6) ヨウガンダ…
col  9 (4) セイゼイ
col 10 (6) キヲツケナ…
```

**ES:**

## [53]  0x49B8E   70 bytes   12 columnas

entradas de tabla: 72

```
col  0 (5) オニドモノ
col  1 (3) セイデ
col  2 (0) 
col  3 (3) ヤマニ
col  4 (6) チカヅケナク
col  5 (6) ナッテシモタ
col  6 (6) カチカチヤマ
col  7 (5) オンセンガ
col  8 (0) 
col  9 (5) ユイイツノ
col 10 (4) タノシミ
col 11 (6) ジャッタノニ
```

**ES:**

## [54]  0x49BD4   78 bytes   15 columnas

entradas de tabla: 73

```
col  0 (6) オカゲサマデ
col  1 (6) カチカチヤマ
col  2 (5) オンセンニ
col  3 (2) マタ
col  4 (6) ハイレマス…
col  5 (0) 
col  6 (5) コレカラモ
col  7 (3) フウフ
col  8 (4) ナカヨク
col  9 (5) オンセンニ
col 10 (4) ツカッテ
col 11 (0) 
col 12 (4) ヘイワニ
col 13 (4) クラシテ
col 14 (5) イキマス…
```

**ES:**

## [55]  0x49C22   73 bytes   12 columnas

entradas de tabla: 74

```
col  0 (4) ハイハイ
col  1 (5) オジイサン
col  2 (6) キコエテマス
col  3 (4) コレデモ
col  4 (4) アタシャ
col  5 (0) 
col  6 (4) ムカシハ
col  7 (6) ミスカボチャ
col  8 (6) ダッタンジャ
col  9 (4) キョウモ
col 10 (5) イイテンキ
col 11 (5) ジャネエ…
```

**ES:**

## [56]  0x49C6B   75 bytes   12 columnas

entradas de tabla: 75

```
col  0 (4) ハイハイ
col  1 (5) オジイサン
col  2 (6) キコエテマス
col  3 (4) コレデモ
col  4 (4) アタシャ
col  5 (0) 
col  6 (5) カボチャガ
col  7 (6) ダイコウブツ
col  8 (6) ダッタンジャ
col  9 (4) キョウモ
col 10 (5) イイテンキ
col 11 (5) ジャネエ…
```

**ES:**

## [57]  0x49CB6   85 bytes   14 columnas

entradas de tabla: 76

```
col  0 (6) カチカチヤマ
col  1 (5) オンセンハ
col  2 (0) 
col  3 (6) フキダシテル
col  4 (3) トキニ
col  5 (6) ウエニノルト
col  6 (5) イッショニ
col  7 (6) タカイトコニ
col  8 (6) イケルンダ…
col  9 (3) オニガ
col 10 (5) イナカッタ
col 11 (3) コロハ
col 12 (2) ヨク
col 13 (6) アソンダンダ
```

**ES:**

## [58]  0x49D0B   48 bytes   8 columnas

entradas de tabla: 77

```
col  0 (3) ワーイ
col  1 (3) コレデ
col  2 (6) マエミタイニ
col  3 (5) オンセンデ
col  4 (6) アソベルゾ…
col  5 (0) 
col  6 (6) オニイチャン
col  7 (6) アリガトネ…
```

**ES:**

## [59]  0x49D3B   32 bytes   5 columnas

entradas de tabla: 78

```
col  0 (3) ココハ
col  1 (4) イッスン
col  2 (6) ボウシノムラ
col  3 (5) オオゴエヲ
col  4 (6) ダサンヨウニ
```

**ES:**

## [60]  0x49D5B   34 bytes   6 columnas

entradas de tabla: 79

```
col  0 (3) ココハ
col  1 (4) イッスン
col  2 (6) ボウシノムラ
col  3 (3) モトニ
col  4 (4) モドッテ
col  5 (6) ヨカッタワイ
```

**ES:**

## [61]  0x49D7D   70 bytes   12 columnas

entradas de tabla: 80

```
col  0 (6) ムラノソトノ
col  1 (6) オオキナオニ
col  2 (0) 
col  3 (5) アノオニガ
col  4 (4) オキタラ
col  5 (0) 
col  6 (6) マタ　ムラヲ
col  7 (4) アラシニ
col  8 (5) クルダヨ…
col  9 (6) オソロシクテ
col 10 (3) ヨルモ
col 11 (6) ネムレンノダ
```

**ES:**

## [62]  0x49DC3   81 bytes   12 columnas

entradas de tabla: 81

```
col  0 (4) イヤハヤ
col  1 (5) ホントウニ
col  2 (6) アリガトウ…
col  3 (4) オカゲデ
col  4 (4) グッスリ
col  5 (6) ネレマスワイ
col  6 (5) ロウジンハ
col  7 (4) ネルノガ
col  8 (5) イチバンノ
col  9 (6) タノシミダテ
col 10 (5) ホントウニ
col 11 (6) アリガトウ…
```

**ES:**

## [63]  0x49E14   82 bytes   14 columnas

entradas de tabla: 82

```
col  0 (5) アノオニノ
col  1 (4) オカゲデ
col  2 (0) 
col  3 (4) オラタチ
col  4 (6) オオキナコエ
col  5 (3) ダシテ
col  6 (5) アソベナク
col  7 (5) ナッタダ…
col  8 (0) 
col  9 (5) チッチャイ
col 10 (3) コエデ
col 11 (6) アソンデテモ
col 12 (5) チィットモ
col 13 (6) タノシクネエ
```

**ES:**

## [64]  0x49E66   71 bytes   11 columnas

entradas de tabla: 83

```
col  0 (5) ワーーイ…
col  1 (6) オオキナコエ
col  2 (5) ダセルダ…
col  3 (4) ヤッパリ
col  4 (6) アソブトキハ
col  5 (4) コウダベ
col  6 (4) ソトニモ
col  7 (4) アソビニ
col  8 (4) イケルシ
col  9 (4) ホントニ
col 10 (6) アリガトウ…
```

**ES:**

## [65]  0x49EAD   93 bytes   15 columnas

entradas de tabla: 84

```
col  0 (6) ソトデネトル
col  1 (6) オニダガナ…
col  2 (0) 
col  3 (3) アリャ
col  4 (4) ウチデノ
col  5 (6) 　　コヅチデ
col  6 (6) デカクナッタ
col  7 (5) ンダトヨ…
col  8 (0) 
col  9 (4) ナンデモ
col 10 (5) ソレイライ
col 11 (4) ズーット
col 12 (4) アソコデ
col 13 (6) ネムッテイル
col 14 (5) ンダトヨ…
```

**ES:**

## [66]  0x49F0A   84 bytes   12 columnas

entradas de tabla: 85

```
col  0 (5) ブラボー…
col  1 (5) アノオニヲ
col  2 (5) タオストハ
col  3 (4) サスガハ
col  4 (6) ニホンイチノ
col  5 (6) モモタロサン
col  6 (6) アノカセキト
col  7 (6) ナッタオニハ
col  8 (0) 
col  9 (6) トオリミチト
col 10 (6) シテ　ツカワ
col 11 (6) セテモラウヨ
```

**ES:**

## [67]  0x49F5E   81 bytes   12 columnas

entradas de tabla: 86

```
col  0 (5) アノオニヲ
col  1 (5) タオスニハ
col  2 (4) クチカラ
col  3 (4) ハイッテ
col  4 (4) アバレル
col  5 (4) シカナイ
col  6 (6) ダガ　ヤツノ
col  7 (6) カラダノナカ
col  8 (2) ニモ
col  9 (6) テゴワイオニ
col 10 (6) ガ　タクサン
col 11 (6) オルソウダ…
```

**ES:**

## [68]  0x49FAF   70 bytes   12 columnas

entradas de tabla: 87

```
col  0 (4) ナント…
col  1 (4) オマエガ
col  2 (6) アノオニヲ…
col  3 (2) イヤ
col  4 (6) ソノチイサナ
col  5 (4) カラダニ
col  6 (5) ヒメラレタ
col  7 (4) オオキナ
col  8 (4) ユウキ…
col  9 (4) セッシャ
col 10 (4) カンプク
col 11 (6) ツカマッタ…
```

**ES:**

## [69]  0x49FF5   65 bytes   9 columnas

entradas de tabla: 88

```
col  0 (3) オニノ
col  1 (5) イブクロニ
col  2 (5) ハイッタラ
col  3 (6) テンジョウモ
col  4 (6) ユカモゼンブ
col  5 (6) ワナミタイ…
col  6 (6) ソンナトコニ
col  7 (5) イクナンテ
col  8 (5) ムボウヨ…
```

**ES:**

## [70]  0x4A036   45 bytes   9 columnas

entradas de tabla: 89

```
col  0 (3) マア…
col  1 (3) アナタ
col  2 (6) ブジダッタノ
col  3 (5) スゴイワ…
col  4 (0) 
col  5 (0) 
col  6 (5) アナタコソ
col  7 (5) ユウキアル
col  8 (5) ワカモノネ
```

**ES:**

## [71]  0x4A063   17 bytes   3 columnas

entradas de tabla: 90, 91

```
col  0 (3) ココハ
col  1 (5) タケトリノ
col  2 (6) 　　　　ムラ
```

**ES:**

## [72]  0x4A074   82 bytes   12 columnas

entradas de tabla: 92, 93

```
col  0 (6) カグヤサマガ
col  1 (4) サイキン
col  2 (4) ナント…
col  3 (6) ギャンブルヲ
col  4 (4) オボエテ
col  5 (6) シマッタノ…
col  6 (5) アチコチデ
col  7 (5) ウデダメシ
col  8 (6) シテルトカ？
col  9 (4) アタシモ
col 10 (6) ヤッテミヨウ
col 11 (4) カシラ…
```

**ES:**

## [73]  0x4A0C6   52 bytes   9 columnas

entradas de tabla: 94

```
col  0 (6) クモノウエニ
col  1 (5) オニドモガ
col  2 (6) スムセカイガ
col  3 (6) アルソウナ…
col  4 (0) 
col  5 (0) 
col  6 (5) ワシラニハ
col  7 (3) トテモ
col  8 (6) イケンガノ…
```

**ES:**

## [74]  0x4A0FA   48 bytes   8 columnas

entradas de tabla: 95

```
col  0 (6) ヒョエエエー
col  1 (6) クモノウエニ
col  2 (3) イッテ
col  3 (5) オニタイジ
col  4 (6) シテキタト…
col  5 (0) 
col  6 (4) タイシタ
col  7 (6) オヒトジャ…
```

**ES:**

## [75]  0x4A12A   73 bytes   13 columnas

entradas de tabla: 96, 97

```
col  0 (3) オニハ
col  1 (5) コラシメル
col  2 (5) ダケデナク
col  3 (4) トキニハ
col  4 (5) リヨウスル
col  5 (3) コトモ
col  6 (6) タイセツジャ
col  7 (0) 
col  8 (0) 
col  9 (3) トクニ
col 10 (6) フンドシオニ
col 11 (6) ナンカハノウ
col 12 (6) ハッハッハ…
```

**ES:**

## [76]  0x4A173   46 bytes   6 columnas

entradas de tabla: 98

```
col  0 (5) コノババア
col  1 (4) スッカリ
col  2 (6) ダマサレテヨ
col  3 (5) オニドモヲ
col  4 (6) カミサマダト
col  5 (6) オモッテンダ
```

**ES:**

## [77]  0x4A1A1   46 bytes   8 columnas

entradas de tabla: 99

```
col  0 (5) バアサンモ
col  1 (3) モトニ
col  2 (5) モドッタシ
col  3 (3) コレモ
col  4 (4) アンタノ
col  5 (5) オカゲダ…
col  6 (2) ヘヘ
col  7 (6) アリガトヨ…
```

**ES:**

## [78]  0x4A1CF   88 bytes   14 columnas

entradas de tabla: 100

```
col  0 (6) フウジンサマ
col  1 (6) フウジンサマ
col  2 (0) 
col  3 (2) アア
col  4 (4) ワシラノ
col  5 (6) シュゴシン…
col  6 (4) ソラカラ
col  7 (3) イツモ
col  8 (5) ミマモッテ
col  9 (5) クダサル…
col 10 (5) アリガタイ
col 11 (6) コッテスジャ
col 12 (6) ナンマンダブ
col 13 (6) ナンマンダブ
```

**ES:**

## [79]  0x4A227   67 bytes   11 columnas

entradas de tabla: 101

```
col  0 (3) ワシハ
col  1 (4) イママデ
col  2 (5) ナニヲシテ
col  3 (3) シカシ
col  4 (4) コウシテ
col  5 (5) ブジナノモ
col  6 (6) ホトケサマノ
col  7 (5) オカゲジャ
col  8 (0) 
col  9 (6) ナンマンダブ
col 10 (6) ナンマンダブ
```

**ES:**

## [80]  0x4A26A   71 bytes   12 columnas

entradas de tabla: 102, 103

```
col  0 (6) モモタロサン
col  1 (3) モハヤ
col  2 (6) アンタダケガ
col  3 (4) タヨリデ
col  4 (4) ゴワス…
col  5 (0) 
col  6 (4) アンタノ
col  7 (4) チカラデ
col  8 (4) エンマヲ
col  9 (4) タオシテ
col 10 (5) クダセー…
col 11 (5) デ ゴワス
```

**ES:**

## [81]  0x4A2B1   52 bytes   8 columnas

entradas de tabla: 104, 105

```
col  0 (5) ダメダア…
col  1 (5) オラ　モウ
col  2 (6) タエレネエ…
col  3 (6) コンナトコデ
col  4 (6) クラシテチャ
col  5 (0) 
col  6 (4) オカシク
col  7 (6) ナッチマウダ
```

**ES:**

## [82]  0x4A2E5   54 bytes   8 columnas

entradas de tabla: 106, 107

```
col  0 (6) モモタロサン
col  1 (4) アンタガ
col  2 (3) キット
col  3 (4) ココマデ
col  4 (6) キテクレルト
col  5 (6) オモッテタ…
col  6 (5) ナガイキハ
col  7 (6) スルモンジャ
```

**ES:**

## [83]  0x4A31B   96 bytes   18 columnas

entradas de tabla: 108, 109

```
col  0 (6) カタナ　オレ
col  1 (6) ヤモ　ツキタ
col  2 (0) 
col  3 (4) エンマハ
col  4 (5) オソロシク
col  5 (4) ツヨイ…
col  6 (6) コレイジョウ
col  7 (5) ススンデモ
col  8 (0) 
col  9 (5) イタズラニ
col 10 (4) イノチヲ
col 11 (6) ステルダケダ
col 12 (6) シニタクナイ
col 13 (3) ノナラ
col 14 (0) 
col 15 (4) サキニハ
col 16 (6) ススマンコト
col 17 (2) ダナ
```

**ES:**

## [84]  0x4A37B   107 bytes   18 columnas

entradas de tabla: 110, 111

```
col  0 (6) トーチャンハ
col  1 (4) エンマニ
col  2 (6) ムカッテッテ
col  3 (5) ソレッキリ
col  4 (4) カエッテ
col  5 (6) コナインダ…
col  6 (6) オニイチャン
col  7 (6) トーチャンノ
col  8 (5) カタキヲ…
col  9 (6) オネガイダヨ
col 10 (0) 
col 11 (0) 
col 12 (6) ムラノミンナ
col 13 (6) ノタメニモ…
col 14 (0) 
col 15 (6) ガンバッテネ
col 16 (6) モモタロウノ
col 17 (6) オニイチャン
```

**ES:**

## [85]  0x4A3E6   96 bytes   18 columnas

entradas de tabla: 112, 113

```
col  0 (5) ナガネンノ
col  1 (6) ケンキュウノ
col  2 (3) ケッカ
col  3 (4) エンマノ
col  4 (6) ジャクテンハ
col  5 (0) 
col  6 (4) ヤッパリ
col  7 (6) マトジャッタ
col  8 (4) 　　　　
col  9 (3) マトハ
col 10 (6) クチノナカニ
col 11 (3) アル…
col 12 (2) ダガ
col 13 (3) ソレモ
col 14 (0) 
col 15 (4) エンマノ
col 16 (5) トコロマデ
col 17 (5) イケレバダ
```

**ES:**

## [86]  0x4A446   115 bytes   23 columnas

entradas de tabla: 114, 115

```
col  0 (3) スデニ
col  1 (5) ホトンドノ
col  2 (5) ムラビトハ
col  3 (5) ニゲダシテ
col  4 (4) シモタ…
col  5 (0) 
col  6 (0) 
col  7 (6) モモタロウ…
col  8 (0) 
col  9 (5) ヒトビトノ
col 10 (4) キタイハ
col 11 (4) オマエニ
col 12 (5) アツマッテ
col 13 (3) オル…
col 14 (0) 
col 15 (3) ドウカ
col 16 (4) エンマヲ
col 17 (4) コラシメ
col 18 (5) ヨノナカニ
col 19 (4) ヘイワヲ
col 20 (6) モタラスノダ
col 21 (3) ユケ…
col 22 (6) モモタロウ…
```

**ES:**
