# Por qué la v174 no sale todavía, y qué he encontrado

## La causa raíz de la v173, localizada

**El motor y los sprites apuntan a sitios distintos.**

```
el MOTOR escribe el texto en:  1A1 1A3 1A5 1A6 1A7 1A8 1A9 1AA 1AB
los SPRITES muestran:          1A6 1A8 1AA 1C0 1C2 1D8 1DA ... 1D6
coinciden en:                  1A6 1A8 1AA      (sólo 3 de 20)
```

El otro chat amplió la lista de sprites pero **no** la tabla de destinos del
motor: `$9BBD` sigue byte a byte igual que en la v157, apuntando a las 9
celdas del bocadillo vertical original.

Eso explica **exactamente** lo que se ve en tu captura:

- en las 3 celdas comunes sí hay texto → por eso se lee «ésta es la aldea de
  Kintaro»;
- en las otras 17 **no escribe nadie** → salen los restos de VRAM, el ruido
  tipo QR;
- el motor escribe además en `1A1 1A3 1A5`, que son **del marco**;
- y algunos sprites caen sobre `1D8-1E9`, que son gráficos vivos.

Del HUD: el bocadillo invade `1AF` y `1B3`, y el HUD vive en `1B0-1B6`,
`1B8`, `1BC-1BF`. De ahí que se rompa la barra de melocotones al hablar.

---

## Construí la v174 y la descarté antes de dártela

Llegué a tener el motor corregido y verificado:

- rutina de 104 B que **calcula** destino y cuadrante (240 B de tablas no
  caben en los 108 disponibles);
- tabla de 10 parejas de celdas, todas libres;
- contadores a 20×4, índice a `fila*20+pos`;
- lista de sprites reducida a 10, **con las mismas celdas que el motor**;
- las 80 celdas simuladas una a una: correctas;
- guion, diccionario y fuente intactos.

Un bug pillado al desensamblar: un `BEQ` caía en el operando de `INC $15` en
vez de en la instrucción siguiente.

**Pero al revisar el código que rodea al búfer encontré dos cosas que la
invalidan:**

1. `$9C29` limpia el búfer con `LDX #$23`, o sea **36 celdas**. Con 80, las
   otras 44 conservarían el texto de la página anterior.
2. Y lo grave: 80 celdas desde `$3667` llegan a `$36B6`, pero **`$368B-$368F`
   son las coordenadas del bocadillo** (20 punteros en 3 bancos). Se las
   machacaría.

Es el mismo fallo que ya detecté en mi v158 hace sesiones. Lo tenía anotado y
volví a construirlo igual. Mi error.

---

## Y hay un tercer límite, medido

Descomprimí el CG del bocadillo entero (`0x3D401`, 272 B → 30 celdas) y
comprobé cuáles traen **fondo blanco**:

```
celdas con fondo:  1A6 1A7 1A8 1A9 1AA 1AB   -> 6
parejas:           1A6 1A8 1AA               -> 3  = 6 caracteres
```

Justo el ancho del bocadillo japonés. Para 20 caracteres hacen falta 10
parejas, o sea **7 sin fondo**. Y como `$9D33` sólo escribe el glifo, esas 14
celdas saldrían con ruido pase lo que pase.

---

## Lo que propongo

Los tres problemas (búfer, limpieza y fondo) **caen a la vez** con la
solución que ya tenía medida en la v158: **escribir cada carácter en VRAM en
el momento, sin búfer**.

- sin búfer no hay problema de 80 celdas ni de `$9C29`;
- es seguro: `$9D33` ya espera al VDC en cada celda (`$E185`), así que el
  patrón de acceso no cambia;
- y la misma rutina puede rellenar el fondo de una celda la primera vez que
  la toca.

O sea: **portar la solución de la v158 a la v173**, quedándome con su guion
traducido y su diccionario.

Es más trabajo que un parche de datos, pero es lo que hace que funcione de
verdad. ¿Tiro por ahí?
