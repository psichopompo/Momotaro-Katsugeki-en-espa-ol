# Maquetación — DADOS, PIEDRA-PAPEL-TIJERA y técnicas

**Rejilla: 2 líneas × 16 caracteres** (los vítores eran 18).

[HECHO] El simulador con 16 columnas reproduce **byte a byte** el buffer
`$2593` de tus dos savestates. Motor: el mismo `$9B0B` de las tiendas.

Cada bloque ocupará **32 B exactos**; los huecos son de 32 a 40 B, así que
**no hay que repuntar nada**.

> Propuestas ya ajustadas a 16 columnas. La maquetación la decides tú.

---

## 1. Juego de DADOS — `0x4AC9C`

Es el *chō-han*: apuestas con dos dados en un cubilete a **par** (丁 *chō*)
o **impar** (半 *han*). La crupier es la mujer del kimono rojo.

Aquí lo llamaríamos **pares o nones**, y funciona igual en lo esencial
(apostar a par/impar), así que el nombre no engaña. Lo que cambia es el
gesto: en Japón son dados en cubilete, no dedos.

### Bloque 0 — ROM `04AC9C` — hueco 34 B

```
         1234567890123456
JP  L1  |ドウダイ ヤッテイクカイ?   |
JP  L2  | スル      シナイ    |
ES  L1  |¿Te animas?     |  11
ES  L2  |  Sí        No  |  14
```

> **Corregido:** `¿Jugamos, majo?` metía un «majo» que no está en el
> original. `doudai yatteikukai?` es «¿qué tal? ¿te animas?» →
> `¿Te animas?` (11).

### Bloque 1 — ROM `04ACBE` — hueco 34 B

```
         1234567890123456
JP  L1  |サスガダネ! チョウカ ハンカ?|
JP  L2  |サア ハッタ ハッタア!    |
ES  L1  |¿Par o impar?   |  13
ES  L2  |¡Hagan juego!   |  13
```

### Bloque 2 — ROM `04ACE0` — hueco 32 B

```
         1234567890123456
JP  L1  | チョウ     ハン     |
JP  L2  |オニイサン ツイテルネ!    |
ES  L1  |  Par      Impar|  16
ES  L2  |¡Vaya suerte!   |  13
```

### Bloque 3 — ROM `04AD00` — hueco 34 B

```
         1234567890123456
JP  L1  |マタ キテオクレ!       |
JP  L2  |ザンネン ダッタネ!      |
ES  L1  |¡Vuelve pronto! |  15
ES  L2  |¡Qué lástima!   |  13
```

### Bloque 4 — ROM `04AD22` — hueco 34 B

```
         1234567890123456
JP  L1  |ソレジャ マタオイデ!     |
JP  L2  |ケッ シケテルワネッ!     |
ES  L1  |¡Hasta la vista!|  16
ES  L2  |¡Qué rácano!    |  12
```

> ⚠ **CORRECCIÓN — «¡Bah, qué sosa!» estaba mal por partida doble.**
> David preguntó a quién se refería y por qué iba en femenino. Al releer el
> japonés:
>
> ```
> ケッ シケテルワネッ!   =   ke!  shiketeru wa ne!
> ```
>
> 1. **シケてる** *(shiketeru)* no es «soso»: es **rácano, tacaño, cutre**.
>    En una mesa de apuestas significa «apuestas una miseria».
> 2. **ワネ** *(wa ne)* es una partícula final **femenina de HABLANTE**:
>    marca que quien habla es mujer — la crupier. El femenino es de su boca,
>    no de quien recibe el insulto, que es **Momotaro, un chico**.
>
> O sea que mi frase erraba el género *y* el significado. **Decisión de
> David:** quitar el «Bah» para que quepa la palabra correcta →
> `¡Qué rácano!` (12). Así se dice lo que dice el original, en masculino.
>
> Lo mismo pasa en el bloque 5: **ダワ** *(da wa)* también es femenino de
> hablante, no del receptor.

### Bloque 5 — ROM `04AD44` — hueco 34 B

```
         1234567890123456
JP  L1  |トット キエウセヤガレ ダワ! |
JP  L2  |                |
ES  L1  |¡Largo de aquí! |  15
ES  L2  |                |   0
```

---

## 2. PIEDRA-PAPEL-TIJERA — `0x4AE3B`

El original **no es piedra-papel-tijera**: es *acchi muite hoi*. Se juega
al chifumi, el ganador señala una dirección con el dedo y si el perdedor
gira la cara hacia ese lado, pierde del todo.

> **Decisión de David:** no llamarlo «piedra, papel o tijera», porque el
> jugador vería que no funciona igual y se confundiría. Se deja
> **«Mira hacia allá»**, que es la traducción literal de *acchi muite hoi*
> y describe lo que de verdad hay que hacer.

### Bloque 0 — ROM `04AE3B` — hueco 40 B

```
         1234567890123456
JP  L1  |\クイズ\ニ ゼンブ セイカイスレハ|
JP  L2  |゛ジュツヲ サズケテヤロウ!   |
ES  L1  |Acierta todas y |  15
ES  L2  |te daré un don. |  15
```

### Bloque 1 — ROM `04AE63` — hueco 35 B

```
         1234567890123456
JP  L1  |ワシト アッチムイテ\ホイ\ヲシテ |
JP  L2  |カッタナラ ジュツヲオシエヨウ |
ES  L1  |Si me ganas, te |  15
ES  L2  |doy una técnica.|  16
```

> **CORRECCIÓN.** Escribí que eran «una parrafada de cuatro líneas».
> **Falso, y David lo cazó.** Medido: cada bloque es un mensaje COMPLETO de
> 2 líneas, y son **alternativos**, no consecutivos:
>
> - bloque 0 = *«si aciertas todo el quiz, te concederé una técnica»*
> - bloque 1 = *«si juegas conmigo a acchi-muite-hoi y ganas, te la enseño»*
>
> En pantalla se ven **2 líneas de 16**, nunca cuatro. Tu state muestra el
> bloque 1, que confirma exactamente eso.

> **Tus dos opciones, medidas:**
>
> ```
> Opción 1   |Si me ganas, te    |  15  cabe
>            |enseño una técnica.|  19  NO CABE
>
> Opción 2   |Gáname y te        |  11  cabe
>            |enseñaré algo.     |  14  cabe
> ```
>
> Acertaste: **solo cabe la 2**, y es la que va puesta arriba. La 1 se pasa
> por 3 caracteres en la segunda línea.
>
> Si quieres decir *qué* enseña y que no suene incompleto, con 16+16 caben
> por ejemplo:
>
> ```
> |Gáname y te     |  11
> |daré una técnica|  16
>
> |Si me ganas, te |  15
> |doy una técnica.|  16
>
> |Gáname a «Mira  |  15
> |hacia allá».    |  12
> ```


---

## 3. Nombres de TÉCNICAS — `0x4AE86`

### [HECHO] Lo investigado antes de proponer nada

**No hay tabla de punteros.** Comprobado: los 14 inicios reales
(`$4E86 $4E8A $4E93 $4E9A $4E9E $4EA4 $4EA8 $4EB0 $4EB6 $4EC1 $4ECA $4ED0
$4ED8 $4EDE`) no aparecen en la ROM ni como lista de bytes bajos, ni de
altos, ni como words. El motor las recorre **secuencialmente contando
terminadores `$00`**.

> [DESCARTADO] `0x2EE2A` parecía la tabla (14 words hacia el banco `$25`),
> pero es una **progresión aritmética** `$4E56 + 6k`: paso fijo de 6 y
> coincide con las cadenas reales solo en 5 de 14, por azar. Aplicada la
> norma 288 antes de creérmela. Los otros dos candidatos, `0x50EB8` y
> `0x57279`, son datos gráficos.

**La consecuencia es buena:** al ser secuencial, el reparto entre las 14
cadenas es **libre**. Lo único fijo es el total.

```
bloque 0x4AE86 .. 0x4AEE6  =  96 B
suma de las 14 cadenas + sus $00 = 96 B   ← cuadra al byte
```

Y se puede ampliar: los dos bloques del ermitaño de arriba pasan de 40+35 B
japoneses a 32+32 castellanos, **liberando 11 B**.

```
PRESUPUESTO TOTAL:  96 + 11 = 107 B para las 14 técnicas
```

### El límite real no es la ROM, es la pantalla

Los nombres se muestran en una ventana de selección como la del quiz. En
japonés los más largos son `モモジャンプ` y `モモバクハツ`: **6 caracteres
visibles**. O sea que el hueco ronda los **6-7 caracteres**, y
«Momoexplosión» (13) no cabría en pantalla aunque cupiese en la ROM.

### ⚠ CORRECCIÓN: el presupuesto seguro es 96 B, no 107

Dije que los 2 bloques del ermitaño liberaban 11 B y daban 107. **Es falso
en la práctica**, y lo he cazado al ir a escribir.

Esos 11 B están **delante** de la lista. Para aprovecharlos habría que
arrancar la lista en `0x4AE7B` en vez de `0x4AE86`, es decir **mover su
inicio**. Y no sé cómo llega el motor hasta ella:

- no hay tabla de punteros — verificado
- no hay `LDA #$86` / `LDA #$4E` en toda la ROM — verificado, 0 casos

Si llega por recorrido secuencial desde antes, moverlo funcionaría. Si la
base está codificada de otra forma, lo rompe. **No lo puedo comprobar sin
ejecutar**, y es exactamente el error que costó la v237: repuntar a ciegas.

```
PRESUPUESTO SEGURO = 96 B, con el bloque intacto en 0x4AE86..0x4AEE6
```

### Tus decisiones, medidas contra los 96 B reales

| propuesta | bytes | ¿cabe? |
|---|---|---|
| `Ola`/`MomoOla` + `Parapunte` ×2 (lo que pediste) | 110 | **no**, se pasa 14 |
| `MomoX` → `M.X`, `Parapunte` ×2 | 98 | no, se pasa 2 |
| `MomoX` → `+X`, `Parapunte` ×2 | **92** | **sí**, sobran 4 |
| `MomoX` → `M.X`, 2.º `Parapunte` → `Azar` | **93** | **sí**, sobran 3 |

Las siete primeras (`Vuelo Salto Rodar Giro Bomba Ola Parapunte`) son
**intocables**, como pediste: son 43 B. El problema son las siete `Momo`,
que solo tienen 53 B.

### Las dos que caben, renderizadas

```
OPCIÓN A  (92 B)          OPCIÓN B  (93 B)
  +Vuelo                    M.Vuelo
  +Salto                    M.Salto
  +Rodar                    M.Rodar
  +Giro                     M.Giro
  +Bomba                    M.Bomba
  +Ola                      M.Ola
  Parapunte                 Azar        ← el 2.º Parapunte
```

Comprobado en la fuente real: las dos se leen bien.

**La A** conserva tus dos `Parapunte` y marca las Momo con `+`, que se
entiende como «versión mejorada».
**La B** mantiene el prefijo con letra pero sacrifica el segundo
`Parapunte`.

> Ojo: los dos `パロプンテ` del original son **idénticos** (entradas 6 y 13),
> así que dejarlos iguales es lo fiel; la opción B rompe esa simetría.

### Propuesta

| # | japonés | qué es | propuesta | letras |
|---|---|---|---|---|
| 0 | ヒエン | *hien*, vuelo de golondrina | Vuelo | 5 |
| 1 | ジャンプ | *jump* | Salto | 5 |
| 2 | コロコロ | *korokoro*, rodar | Rodar | 5 |
| 3 | マワシ | *mawashi*, giro | Giro | 4 |
| 4 | バクハツ | *bakuhatsu*, explosión | Bomba | 5 |
| 5 | ツナミ | *tsunami* | Ola | 3 |
| 6 | パロプンテ | *parupunte*, conjuro azaroso de Dragon Quest | Parapunte | 9 |
| 7 | モモヒエン | | +Vuelo | 6 |
| 8 | モモジャンプ | | +Salto | 6 |
| 9 | モモコロコロ | | +Rodar | 6 |
| 10 | モモマワシ | | +Giro | 5 |
| 11 | モモバクハツ | | +Bomba | 6 |
| 12 | モモツナミ | | +Ola | 4 |
| 13 | パロプンテ | | Parapunte | 9 |

**Total: 92 B de 96.** Sobran 4 B (opción A).

### ✅ ELEGIDA LA OPCIÓN A (decisión de David)

Tabla definitiva que lee el constructor. **92 B de 96**, sobran 4.

| # | ROM | japonés | ES |
|---|---|---|---|
| 0 | `04AE86` | ヒエン | `Vuelo` |
| 1 | `04AE8A` | \ジャンプ\ | `Salto` |
| 2 | `04AE93` | \コロコロ\ | `Rodar` |
| 3 | `04AE9A` | マワシ | `Giro` |
| 4 | `04AE9E` | バクハツ | `Bomba` |
| 5 | `04AEA4` | ツナミ | `Ola` |
| 6 | `04AEA8` | パロプンテ | `Parapunte` |
| 7 | `04AEB0` | モモヒエン | `+Vuelo` |
| 8 | `04AEB6` | モモ\ジャンフ\゜ | `+Salto` |
| 9 | `04AEC1` | モモ\コロコロ\ | `+Rodar` |
| 10 | `04AECA` | モモマワシ | `+Giro` |
| 11 | `04AED0` | モモバクハツ | `+Bomba` |
| 12 | `04AED8` | モモツナミ | `+Ola` |
| 13 | `04AEDE` | パロプンテ | `Parapunte` |

```
TEC = Vuelo Salto Rodar Giro Bomba Ola Parapunte
      +Vuelo +Salto +Rodar +Giro +Bomba +Ola Parapunte
```

Las siete primeras quedan como pediste. Las Momo- van con `+`, que se lee
como «versión mejorada», y los dos `Parapunte` se mantienen idénticos, como
en el original.
