# Los créditos y el final — maquetación para revisar

**Zona pendiente: `0x4A484` .. `0x4A7B9` = 821 bytes**, en el banco `$25`.

---

## Cómo funciona esta pantalla [HECHO]

- El separador de línea es **`;`** (`$3B`), no el `$80` de los bocadillos.
- Los terminadores son `$00`, `$01` y `$03` (distintas pausas/efectos).
  **Hay que respetarlos en su sitio exacto**: no hay tabla de punteros, el
  motor recorre el bloque en secuencia.
- El ancho **no es fijo**: hay líneas de 7 columnas y otras de 40, así que
  el motor envuelve solo. Me ciño al ancho del original en cada línea.
- Charset: motor de vítores (`charset_vitores`, **bytes directos**). Nada de
  alias `$5B/$5D/$5E`, que aquí pintarían `©`.

---

## AVISO 1 — hay un bloque a medio traducir, y este SÍ se ve

El discurso del abuelo (`0x4A446`..`0x4A4B8`) está traducido **a medias**:
nuestro texto acaba en `0x4A475` y de `0x4A484` en adelante quedaron
**52 bytes en japonés**. A diferencia de los restos invisibles de la v333 y
la v334, este **se ve en pantalla**, porque el `$00` final está en `0x4A4B8`
y el motor llega hasta él.

```
japonés:  «casi todos los aldeanos han huido ya. Momotaro, la esperanza
           de la gente está puesta en ti. Derrota a Enma y trae la paz
           al mundo. ¡Ve, Momotaro!»

nuestro:  «...ban suerte por todas partes. ¿Y si lo intento yo...?»
          + 52 bytes de japonés suelto
```

**Propuesta** (107 de los 114 bytes disponibles):

```
Casi todos los
aldeanos han huido.
La esperanza de
todos está en ti.
Derrota a Enma y
trae la paz al mundo.
```

> El hueco es de 114 B contando el `;` de cada salto, así que no entra
> «¡Ve, Momotaro!» al final. Alternativa de 101 B si prefieres conservar el
> nombre: `Casi todos los` / `aldeanos han huido.` / `La esperanza está` /
> `en ti, Momotaro.` / `Derrota a Enma` / `y trae la paz.`

## AVISO 2 — los nombres del equipo

Los bloques 5 a 20 son los **créditos con nombres propios japoneses**
(Iizuka Hiroyuki, Hattori Takahiko, Okuno Hitoshi…). Mi criterio, salvo que
digas otra cosa:

- **Los nombres NO se traducen** ni se alteran (norma 315, la de «Hien»).
- El sufijo `クン` / `サン` (*-kun*, *-san*) **se quita**: en castellano no
  aporta y gasta columnas. En su lugar, los cargos sí se traducen.
- Se respeta el orden y la sangría del original.

---

## Los 27 bloques, con propuesta

Formato: `japonés` → **propuesta**. Entre paréntesis, las columnas.

### B0 · `04A484` (52 B, `$00`) — cola del discurso del abuelo
Ver AVISO 1. Se reescribe junto con `0x4A446`.

### B1 · `04A4B9` (33 B, `$03`) — enhorabuena
→ **`¡Enhorabuena!` / `¡Lo has logrado!`**  (30 de 33)

> «Has completado Momotaro Katsugeki» son 38 y no caben. Alternativa de
> 26: `¡Enhorabuena!` / `¡Has ganado!`

### B2 · `04A4DB` (48 B, `$01`) — «juego de acción»
```
Como obra maestra           (15)
de los juegos de acción,    (13)
disfrútalo mucho.           (11)
```
→ **`Esperamos que` / `hayas disfrutado` / `de esta aventura.`**

### B3 · `04A50D` (36 B, `$01`) — presenta enemigos
→ **`Y ahora, te` / `presento a los` / `enemigos.`**  (36 de 36, justo)

### B4 · `04A534` (32 B, `$01`) — presenta staff
→ **`¡El equipo de` / `Momotaro!`**  (23 de 32)

### B5 · `04A556` (38 B, `$03`)
`ゲームデザインの アシスタント: 飯塚 ヒロユキ`
→ **`Diseño adjunto:` / `Iizuka Hiroyuki`**

### B6-B11 · `04A57D`..`04A5D6` (89 B) — los seis nombres

**`Hattori Takahiko` son 16 y su hueco individual es 15**: se pasa por UN
byte. En vez de recortar un nombre propio, se reescribe el tramo **de
corrido** recolocando los terminadores `$03`. Los seis suman 85 B de los 89
disponibles, así que caben con 4 de sobra.

→ **`Hakuya Masagasu`** / **`Hattori Takahiko`** / **`Araki Hitoshi`** /
**`Kuniyake Santa`** / **`Izawa Hiroshi`** / **`Ooi Tomoo`**

### B12 · `04A5D8` (32 B, `$01`)
`バトソンの 優秀なスタッフも ご紹介!`
→ **`¡Y el gran equipo` / `de Hudson!`**

### B13 · `04A5F9` (33 B, `$03`)
→ **`Programador jefe:` / `Okuno Hitoshi`**

### B14 · `04A61B` (32 B, `$03`)
→ **`Programación:` / `Kosaka Yasuhiro`**

### B15 · `04A63C` (26 B, `$03`)
→ **`Diseño:` / `Takaoka Fumie`**

### B16 · `04A657` (18 B, `$03`) → **`Kakutani Atsushi`**
### B17 · `04A66A` (19 B, `$03`) → **`Bushimoto Kayo`**

### B18 · `04A67E` (25 B, `$03`)
→ **`Sonido:` / `Takimoto Toshiaki`**

### B19 · `04A698` (18 B, `$03`) → **`Hoshi Keita`**

### B20 · `04A6AB` (29 B, `$01`)
→ **`Dirección:` / `Bushiwara Jikeki`**

### B21 · `04A6CA` (76 B, `$01`) — despedida
```
みなさん 本当にありがとう      (40)
いつまでも 桃太郎のような
愛と勇気を 忘れないでください  (11)
また どこかで お会いしましょう (16)
```
→ **`¡Gracias a todos!` / `No olvides el amor y el` / `valor de Momotaro.` /
`¡Hasta pronto!`**  (75 de 76)

> Con «¡Muchas gracias a todos!» se va a 89 y no cabe.

### B22 · `04A718` (32 B, `$00`) — productora
`      製作        HUDSON SOFT   `
→ **`      Desarrollo     HUDSON SOFT`** *(decisión de David)*

---

## Los cuatro últimos: presentación de enemigos

Estos siguen el patrón «descripción graciosa + nombre del ogro», igual que
los que ya están traducidos a partir de `0x4A7B9`.

### B23 · `04A739` (35 B, `$00`)
`おにぎりが 入ってて うれしかった ヅツラおにクン!`
→ **`Feliz con su onigiri` / `¡Ogro Cesto!`**  (33 de 35)

### B24 · `04A75D` (27 B, `$00`)
`意味なく歩くだけだった 歩きおにクン!`
→ **`Paseaba y ya` / `¡Ogro Andarín!`**  (27 de 27, justo)

### B25 · `04A779` (36 B, `$00`)
`べはりつくような 歩き方が かわいかった キノコおにクン!`
→ **`Pegajoso y resultón` / `¡Ogro Seta!`**  (31 de 36)

### B26 · `04A79E` (27 B, `$00`) — **bloque cortado**
`なんで いくつも 入れ歯を 持ってるんだろ 入れ...`
→ **`¿Para qué tanta` / `dentadura?`**  (26 de 27)

> Este bloque **continúa después de `0x4A7B9`**, donde el texto ya está en
> castellano («¡Ogro Bocah!»). Hay que empalmar sin tocar lo que ya existe.

---

## Comprobación de espacio [HECHO]

Las 27 propuestas están medidas contra su hueco real. **Todas caben.** Nueve
no cabían en la primera redacción y están ajustadas arriba; el caso más
interesante es B6-B11, donde en vez de recortar «Hattori Takahiko» se
reescribe el tramo entero recolocando terminadores.

---

## Decisiones de David [CERRADO]

1. **Los nombres propios se dejan tal cual.**
2. **B22 → «Desarrollo»**.
3. Las frases propuestas, aprobadas.

Cuando esté revisado el final largo, el constructor **leerá de este
documento**, como se hizo con las tiendas (`MAQUETACION_tiendas.md`): así se
inserta exactamente lo aprobado y no lo que yo recuerde.


---

# PARTE 2 — el final LARGO (el que ha visto David)


> **Esto no estaba inventariado.** David: *«yo he visto el final de la
> dificultad fácil y es bastante más largo que todo lo que has mostrado»*.
> Tenía razón: hay un **segundo bloque de créditos** en otra zona de la ROM
> que no había mirado.

```
0x3B800 .. 0x3BF83   1923 bytes, 104 bloques   ÍNTEGRAMENTE EN JAPONÉS
0x3BF84 .. 0x3C000    124 bytes libres ($FF)
                     ------
                     2048 B utilizables en total
```

Lo encontré buscando en la ROM el texto de sus capturas (`ダレデモ`,
`モウイチド`). El bloque que yo tenía (`0x4A484`, 821 B) **es otro final
distinto**, más corto — probablemente el de otra dificultad.

## Estructura

| Bloques | Qué |
|---|---|
| B0-B10 | Presentación y agradecimiento |
| B11-B32 | El equipo principal: cargo + nombre |
| B33-B57 | Los **22 colaboradores** del concurso de ideas |
| B58-B71 | Supervisor, cierre y «製作 HUDSON SOFT» |
| B72-B103 | **La lista final en dos columnas** (cargo + nombre) |

## Los nombres que no caben en su hueco individual

Doce de los 22 colaboradores se pasan de su celda. Contando el **tramo
B35-B57 de corrido** (320 B disponibles) hacen falta 338: **faltan 18**.

**Solución**: los 124 bytes libres de `0x3BF84` están pegados al bloque, así
que hay sitio de sobra. Se reescribe el tramo entero recolocando los `$00`,
igual que con «Hattori Takahiko» en el final corto.

```
Yoshida Michiko    15 > 12     Kobori Hirotaka     15 > 14
Tsukahara Tetsuya  17 > 13     Noda Katsuyoshi     15 > 13
Miyazaki Shigeki   16 > 15     Hiwatari Kenichi    16 > 14
Yoshida Kimiyo     14 > 13     Matsuo Katsuhito    16 > 13
Terada Takashi     14 > 13     Kurusu Yonekuni     15 > 13
                               Morimoto Yasuhiro   17 > 14
                               Miyashita Katsuyuki 19 > 14
```

## Los 104 bloques

`B0   03B800 15B`  オメデトウ! アリガトウ!
`B1   03B810 19B`  モモタロウカツゲキ\クリア\デス!
`B2   03B824 19B`  モモタロウカツゲキガ ダレデモ
`B3   03B838 21B`  \クリア\デキル\ゲーム\ト アナタハ
`B4   03B84E 14B`  ショウメイ シテクレマシタ!
`B5   03B85D 18B`  モウイチド アナタニ アリガトウ
`B6   03B870 12B`  ト イワセテクダサイ!
`B7   03B87D 10B`  ソレデハ ココデ
`B8   03B888 11B`  モモタロウカツゲキノ
`B9   03B894 17B`  \メイン=スタッフ\ヲ ショウカイ
`B10  03B8A6  4B`  シマス!
`B11  03B8AB 15B`  \ゲーム\カントクハ ツイニ
`B12  03B8BB 15B`  カントクニ ショウシン シタ!
`B13  03B8CB 14B`  マスダ ショウジ\クン!
`B14  03B8DA 15B`  ゲーム\オンガクハ ココロ
`B15  03B8EA 17B`  アタタマル キョクヲ アリガトウ
`B16  03B8FC 12B`  ヨシダ ミチコ\サン!
`B17  03B909 17B`  キャラ=デザイン\ハ ヨメサン
`B18  03B91B 12B`  サガシテ 3000リ!
`B19  03B928 12B`  ドイ タカユキ\クン!
`B20  03B935 14B`  メイン=プログラマー\ハ
`B21  03B944 17B`        オクノ ヒトシ\クン!
`B22  03B956 14B`  サブ=プログラマー\ハ
`B23  03B965 17B`       コサカ ヤスヒロ\クン!
`B24  03B977  8B`  デザイン\ハ
`B25  03B980 17B`       タカオカ フミエ\サン!
`B26  03B992 18B`       \カクタニ アツシ\クン!
`B27  03B9A5 19B`        \フジモト カヨ\サン!
`B28  03B9B9  7B`  サウンド\ハ
`B29  03B9C1 17B`      タキモト トシアキ\クン!
`B30  03B9D3 18B`         \ホシ ケイタ\クン!
`B31  03B9E6  9B`  ディレクター\ハ
`B32  03B9F0 19B`       フジワラ シゲキ\クン!
`B33  03BA04 19B`  アイデア\ボシュウ ニュウセンシャ
`B34  03BA18 15B`  ニヨル キョウリョク\スタッフ
`B35  03BA28 13B`  \ノダ ノリユキ\クン!
`B36  03BA36 13B`  \ツカハラ テツヤ\クン!
`B37  03BA44 14B`  \ヨシダ タクジ\クン!
`B38  03BA53 15B`  \ミヤザキ シゲキ\クン!
`B39  03BA63 13B`  \ヨシダ キミヨ\サン!
`B40  03BA71 14B`  \マトバ シゲル\クン!
`B41  03BA80 15B`  \イガラシ ヨウイチ\クン!
`B42  03BA90 13B`  \サトウ コウイチ\クン!
`B43  03BA9E 12B`  \カワイ ケンヤ\クン!
`B44  03BAAB 13B`  \テラダ タカシ\クン!
`B45  03BAB9 14B`  \コボリ ヒロタカ\クン!
`B46  03BAC8 15B`  \ナガナワ セイジ\クン!
`B47  03BAD8 13B`  \サトウ マサヒロ\クン!
`B48  03BAE6 13B`  \ノダ カツヨシ\クン!
`B49  03BAF4 13B`  \タガタ ユタカ\クン!
`B50  03BB02 14B`  \ヒワタリ ケンイチ\クン!
`B51  03BB11 15B`  \ツノダ ダイゴ\クン!
`B52  03BB21 13B`  \マツオ カツヒト\クン!
`B53  03BB2F 13B`  \クルス ヨネクニ\クン!
`B54  03BB3D 14B`  \モリモト ヤスヒロ\クン!
`B55  03BB4C 13B`  \タハラ コウヘイ\クン!
`B56  03BB5A 14B`  \ミヤシタ カツユキ\クン!
`B57  03BB69 18B`  \ミナサン ホントウニ アリガトウ
`B58  03BB7C 12B`  \ゲーム\カンシュウハ
`B59  03BB89 19B`       \ボク \サクマ アキラ!
`B60  03BB9D 19B`  コンカイハ ズノウロウドウ ダケ
`B61  03BBB1 15B`  ソシテ イツモ \ゲーム\ヲ
`B62  03BBC1 15B`  タノシイモノニ シテクレルノハ
`B63  03BBD1  9B`  モモタロウ\クン!
`B64  03BBDB 10B`  \コノヒト アッテノ
`B65  03BBE6 15B`  モモタロウカツゲキ デス!
`B66  03BBF6 17B`  モモタロウ\クン\ヲ イツマデモ
`B67  03BC08 17B`  ミナサンノ テデ カワイガッテ
`B68  03BC1A  6B`  クダサイ!
`B69  03BC21 15B`  ソレデハ マタ ドコカデ
`B70  03BC31 18B`  モモタロウ\クン\ト アイマショウ!
`B71  03BC44 10B`        セイサク
`B72  03BC4F 25B`    HUDSON SOFT{FF}キョウリョク\スタッフ
`B73  03BC69 26B`  ノダ ノリユキ\クン   \ツカハラ テツヤ\クン
`B74  03BC84 29B`  ヨシダ タクジ\クン   \ミヤザキ シゲキ\クン
`B75  03BCA2 27B`  ヨシダ キミヨ\サン   \マトバ シゲル\クン
`B76  03BCBE 26B`  イガラシ ヨウイチ\クン \サトウ コウイチ\クン
`B77  03BCD9 25B`  カワイ ケンヤ\クン   \テラダ タカシ\クン
`B78  03BCF3 28B`  ニボリ ヒロタカ\クン  \ナガナワ セイジ\クン
`B79  03BD10 25B`  サトウ マサヒロ\クン  \ノダ カツヨシ\クン
`B80  03BD2A 27B`  タガタ ユタカ\クン   \ヒワタリ ケンイチ\クン
`B81  03BD46 28B`  ツノダ ダイゴ\クン   \マツオ カツヒト\クン
`B82  03BD63 26B`  クルス ヨネクニ\クン  \モリモト ヤスヒロ\クン
`B83  03BD7E 26B`  タハラ コウヘイ\クン  \ミヤシタ カツユキ\クン
`B84  03BD99 23B`  \メイン=プログラマー  \オクノ ヒトシ
`B85  03BDB1 25B`  \サブ=プログラマー   \コサカ ヤスヒロ
`B86  03BDCB 24B`  \デザイン        \タカオカ フミエ
`B87  03BDE4 24B`  \デザイン        \カクタニ アツシ
`B88  03BDFD 24B`  \デザイン        \フジモト カヨ
`B89  03BE16 24B`  \サウンド        \タキモト トシアキ
`B90  03BE2F 21B`  \サウンド        \ホシ ケイタ
`B91  03BE45 25B`  \ディレクター      \フジワラ シゲキ
`B92  03BE5F 23B`     セイサク     HUDSON SOFT
`B93  03BE77 25B`  \ゲーム=アシスタント  \イイヅカ ヒロユキ
`B94  03BE91 24B`  \ゲーム=アシスタント  \ハクヤ マサカズ
`B95  03BEAA 24B`  \ゲーム=アシスタント  \ハットリ タカヒコ
`B96  03BEC3 22B`  \ゲーム=アシスタント  \アラキ ヒトシ
`B97  03BEDA 23B`  \ゲーム=アシスタント  \クニヤケ サンタ
`B98  03BEF2 23B`  \ゲーム=アシスタント  \イザワ ヒロシ
`B99  03BF0A 22B`  \ゲーム=アシスタント  \オオイ トモオ
`B100 03BF21 25B`  \ゲーム\カントク     マスダ ショウジ
`B101 03BF3B 24B`  \キャラ=デザイン    \ドイ タカユキ
`B102 03BF54 24B`  \ゲーム\オンガク     ヨシダ ミチコ
`B103 03BF6D 22B`  \ゲーム\カンシュウ    サクマ アキラ