#!/usr/bin/env python3
"""
traduccion_enemigos.py - mensajes de victoria sobre cada enemigo.

Bloque ROM 0x4A7B9..0x4AC45 (36 mensajes, 1621 B). Cada mensaje es un
comentario burlon del narrador seguido del NOMBRE del enemigo, y usa `$3B`
como separador de linea igual que el guion.

Estos mensajes salen en el recuento de fin de fase (la pantalla de vitores),
que es de ancho fijo. Hasta no medir esa rejilla en pantalla NO se inyectan:
aqui solo queda fijada la traduccion.

Formato: (comentario, nombre_del_enemigo)
"""

ENEMIGOS = [
 ("",                                        "¡Ogro Bah!"),
 ("No atacan, son unos bichos raros",        "¡Ogros de la Danza!"),
 ("Cuando giran no puedes tumbarlos",        "¡Ogro Girador!"),
 ("Recuerda a los juguetes de cuerda",       "¡Ogro Robot!"),
 ("Al principio iba sobre una bola",         "¡Ogro Malabarista!"),
 ("Si el fuego durase menos, mejor",         "¡Ogro Lanzallamas!"),
 ("¿Adónde se esfuma?",                      "¡Ogro Escurridizo!"),
 ("¡No te acerques tan contento!",           "¡Ogro Saltarín!"),
 ("Sus cuernos misil eran odiosos",          "¡Ogro Robot!"),
 ("¡Mal bicho, tenía preso al faisán!",      "¡Ogro del Ashigara!"),
 ("¡No aparezcas de repente!",               "¡Ogro Patinador!"),
 ("¿Lo tumbaste antes de que estallara?",    "¡Ogro Explosivo!"),
 ("No lanzaba bolas de fuego, sino de hielo","¡Dama de las Nieves!"),
 ("Para lo mono que es, menuda fuerza",      "¡Muñeco de Nieve!"),
 ("¡No ruedes de aquí para allá!",           "¡Gran Muñeco de Nieve!"),
 ("¡Se parece a alguien de la tele!",        "¡Ogro Pulpo!"),
 ("Sus burbujitas eran un fastidio",         "¡Ogro Cangrejo!"),
 ("Cuidemos el mar",                         "¡Ogro Buceador!"),
 ("Más tonto que descarado",                 "¡Ogro en Pelotas!"),
 ("¡No enseñes así la diana!",               "¡Ogro Pulpo Gigante!"),
 ("¿El hombre en llamas?",                   "¡Ogro del Kachikachi!"),
 ("¡Vaya patadas, qué belleza!",             "¡Ogro Bailarín!"),
 ("¡Tira algo mejor, hombre!",               "¡Ogro Tirador!"),
 ("¡Vamos allá, pon, pon, pon!",             "¡Ogro de Fuego!"),
 ("¿Y ese cuerpo qué es?",                   "¡Ogro Partido!"),
 ("Con casco, qué formalito",                "¡Ogro Zapador!"),
 ("En toda clase hay uno así",               "¡Ogro Gordo!"),
 ("¡Un 9,85! Nada mal",                      "¡Ogro Gimnasta!"),
 ("¿Así que era un robot?",                  "¡Ogro Murciélago!"),
 ("El rayo era un incordio",                 "¡Ogro del Trueno!"),
 ("¿Y ese aro para qué era?",                "¡Ogro Alado!"),
 ("Montarse en esto es divertido",           "¡Ogro Saltimbanqui!"),
 ("Papel higiénico… ¿lo sacas del culo?",    "¡Ogro del Taparrabos!"),
 ("Qué bien jugabas con el momento justo",   "¡Ogro Globo!"),
 ("Si has llegado hasta aquí, dabas miedo",  "¡Ogro Final!"),
]


def lineas():
    """Devuelve los 35 mensajes como pares listos para medir."""
    return [(c, n) for c, n in ENEMIGOS]


if __name__ == '__main__':
    import sys
    sys.path.insert(0, 'tools')
    from charset_oficial import CHAR_TO_CODE
    malos = set()
    tot = 0
    for c, n in ENEMIGOS:
        for ch in c + n:
            if ch != ' ' and ch not in CHAR_TO_CODE:
                malos.add(ch)
        tot += len(c) + len(n) + 3
    print('mensajes: %d' % len(ENEMIGOS))
    print('bytes estimados: %d   (japones: 1621)' % tot)
    print('caracteres sin glifo:', sorted(malos) if malos else 'ninguno')
    ancho = max(max(len(c), len(n)) for c, n in ENEMIGOS)
    print('linea mas larga: %d caracteres' % ancho)
