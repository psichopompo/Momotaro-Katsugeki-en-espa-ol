# Maquetación de los textos de TIENDA — para revisar

Base: `momotaro_es_v306.pce`. **Nada escrito en la ROM todavía.**

## Cómo funciona (medido)

- El lector `$C6C4` hace `LDX #$02` / `LDX #$10`: **2 líneas de 16**, 32 bytes.
- Relleno con `$A0`. Texto **alineado a la izquierda**.
- Tabla `0x10854`: **8 tiendas × 6 ranuras**.
- Varias ranuras **comparten puntero** en el original. Si dos casillas apuntan
  al mismo sitio el texto es forzosamente el mismo: se avisa en cada caso.
- En el motor de tienda `b`=`$A2`, `c`=`$A3`, `p`=`$B0`, `Ç`=`$DE` (norma 256).

**Regla de oro: 16 caracteres por línea. Ni uno más.**

«actual» = lo que hay hoy en la v306. «propuesta» = mi sugerencia partiendo
del japonés. Donde no propongo cambio es que lo veo correcto.
**Decide tú**: reescribe lo que quieras respetando los 16 y lo inserto.

Las líneas van con un contador debajo para que puedas medir a ojo.

---

## Tienda 0 — ARMAS

*El tendero habla en tono campechano y remata en «-do» (dialectal).*

### [0] al entrar  ·  `$447D`  ·  hueco 34 B

```
japonés   |イラッシャイ!         |
          |ブキ カッテイクト イイド!  |
romaji    irasshyai! / buki katteikuto iido!

actual    |¡Pasa!          |
          |¡Llévate armas! |

PROPUESTA |¡Pasa!          |
          |¡Llévate armas! |
           1234567890123456
```

### [1] al salir sin comprar  ·  `$449F`  ·  hueco 33 B

```
japonés   |オキニ メサナカッタ ヨウダナ |
          |!マタ キテクレヨナッ!    |
romaji    okini mesanakatta youdana / !mata kitekureyona!

actual    |¿Nada, eh?      |
          |Vuelve otro día.|

PROPUESTA |¿Nada, eh?      |
          |Vuelve otro día.|
           1234567890123456
```

### [2] al comprar  ·  `$44C0`  ·  hueco 33 B

```
japonés   |マイドアリィ!         |
          | マタ キテクレヨナッ!    |
romaji    maidoarii! /  mata kitekureyona!

actual    |¡Gracias!       |
          |¡Vuelve pronto! |

PROPUESTA |¡Gracias!       |
          |¡Vuelve pronto! |
           1234567890123456
```

### [3] sin dinero bastante  ·  `$44E1`  ·  hueco 37 B

```
japonés   |ザンネン!オカネガ タリナイ  |
          |ヨ モウヒトガンバリダ!    |
romaji    zannen!okanega tarinai / yo mouhitoganbarida!

actual    |¡Vaya!          |
          |Te falta dinero.|

PROPUESTA |¡Vaya!          |
          |No te llega.    |
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$4506`  ·  hueco 39 B

```
japonés   |ソノブキヨリ ツヨイブキハナ  |
          |イネヤクニ タテナクテ \ゴメ |
romaji    sonobukiyori tsuyoibukihana / ineyakuni tatenakute \gome

actual    |No hay más.     |
          |Lo siento.      |

PROPUESTA |No hay arma     |
          |mejor.          |
           1234567890123456
```

### [5] tras comprar: ¿algo más?  ·  `$4B9E`  ·  hueco 34 B

```
japonés   |マイドアリィ!         |
          | マダ ナニカ イルカイ?   |
romaji    maidoarii! /  mada nanika irukai?

actual    |¡Gracias!       |
          |¿Algo más?      |

PROPUESTA |¡Gracias!       |
          |¿Algo más?      |
           1234567890123456
```


## Tienda 1 — ARMADURAS

*Tendero formal, de usted: «gozaimasu», «mattemasu».*

### [0] al entrar  ·  `$452D`  ·  hueco 36 B

```
japonés   |イラッシャイマセ!       |
          |ボウグハ イカガデスカ?    |
romaji    irasshyaimase! / bouguha ikagadesuka?

actual    |¡Bienvenido!    |
          |¿Una coraza?    |

PROPUESTA |¡Bienvenido!    |
          |¿Una coraza?    |
           1234567890123456
```

### [1] al salir sin comprar  ·  `$4551`  ·  hueco 33 B

```
japonés   |オキニ メサナカッタ ヨウデス |
          |ネマタノ オコシヲ マッテイマス|
romaji    okini mesanakatta youdesu / nematano okoshiwo matteimasu

actual    |¿Nada, eh?      |
          |Te espero.      |

PROPUESTA |¿No te gusta?   |
          |Te espero aquí. |
           1234567890123456
```

### [2] al comprar  ·  `$4572`  ·  hueco 36 B

```
japonés   |マイドアリガトウゴザイマ    |
          |シタ! マタノ オコシヲ マッテ|
romaji    maidoarigatougozaima / shita! matano okoshiwo matte

actual    |¡Muchas gracias!|
          |Te espero.      |

PROPUESTA |¡Muchas gracias!|
          |Te espero.      |
           1234567890123456
```

### [3] sin dinero bastante  ·  `$4596`  ·  hueco 35 B

```
japonés   |オヤ オキャクサン!      |
          |オカネガ タリナイヨウデスカ  |
romaji    oya okyakusan! / okanega tarinaiyoudesuka

actual    |¡Vaya, cliente! |
          |Te falta dinero.|

PROPUESTA |¡Vaya, cliente! |
          |Te falta dinero.|
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$45B9`  ·  hueco 35 B

```
japonés   |ソレイジョウノ ボウグハ    |
          |ナイヨオヤクニ タテナクテ スミ|
romaji    soreijyouno bouguha / naiyooyakuni tatenakute sumi

actual    |No hay mejor.   |
          |Lo siento.      |

PROPUESTA |No hay armadura |
          |mejor.          |
           1234567890123456
```

### [5] tras comprar: ¿algo más?  ·  `$4BC0`  ·  hueco 38 B

```
japonés   |マイドアリガトウゴザイマ    |
          |ス!  ホカニ イルモノハ ゴ |
romaji    maidoarigatougozaima / su!  hokani irumonoha go

actual    |¡Muchas gracias!|
          |¿Algo más?      |

PROPUESTA |¡Muchas gracias!|
          |¿Algo más?      |
           1234567890123456
```


## Tienda 2 — ONIGIRI (técnicas)

*Vende onigiri de técnica. Trato cercano.*

### [0] al entrar  ·  `$45DC`  ·  hueco 36 B

```
japonés   |イラッシャーイ!        |
          |ワザノ\オニギリ\ヲ カッテ  |
romaji    irasshya-i! / wazano\onigiri\wo katte

actual    |¡Bienvenido!    |
          |¡Lleva onigiri! |

PROPUESTA |¡Bienvenido!    |
          |¡Compra onigiri!|
           1234567890123456
```

### [1] al salir sin comprar  ·  `$4600`  ·  hueco 37 B

```
japonés   |アリガトウゴザイマシタ!    |
          |   ワザガ ナクナッタラ   |
romaji    arigatougozaimashita! /    wazaga nakunattara

actual    |¡Muchas gracias!|
          |Gasta y vuelve. |

PROPUESTA |¡Muchas gracias!|
          |Vuelve pronto.  |
           1234567890123456
```

### [2] al comprar  ·  `$4600`  —  **mismo texto que la ranura [1]**

### [3] sin dinero bastante  ·  `$4625`  ·  hueco 33 B

```
japonés   |オヤ オキャクサン!      |
          |オカネガ タリマセンヨ!    |
romaji    oya okyakusan! / okanega tarimasenyo!

actual    |¡Vaya, cliente! |
          |Te falta dinero.|

PROPUESTA |¡Vaya, cliente! |
          |Te falta dinero.|
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$4646`  ·  hueco 37 B

```
japonés   |コレイジョウ ワザノ\オニキ  |
          |゛リ\ヲ オウリスルワケニハ イ|
romaji    koreijyou wazano\oniki / ゛ri\wo ourisuruwakeniha i

actual    |No puedo        |
          |venderte más.   |

PROPUESTA |No puedo vender |
          |más onigiri.    |
           1234567890123456
```

### [5] tras comprar: ¿algo más?  ·  `$4BE6`  ·  hueco 37 B

```
japonés   |アリガトウゴザイマス!     |
          |   ホカニ イルモノハ ゴサ |
romaji    arigatougozaimasu! /    hokani irumonoha gosa

actual    |¡Muchas gracias!|
          |¿Algo más?      |

PROPUESTA |¡Muchas gracias!|
          |¿Algo más?      |
           1234567890123456
```


## Tienda 3 — OBJETOS (chica)

*Chica joven, amable: «kudasai ne».*

### [0] al entrar  ·  `$466B`  ·  hueco 32 B

```
japonés   |イラッシャイマセー!      |
          |ナニニ ナサイマスカ?     |
romaji    irasshyaimase-! / nanini nasaimasuka?

actual    |¡Bienvenido!    |
          |¿Qué va a ser?  |

PROPUESTA |¡Bienvenido!    |
          |¿Qué va a ser?  |
           1234567890123456
```

### [1] al salir sin comprar  ·  `$468B`  ·  hueco 33 B

```
japonés   |オキニ メサナカッタミタイネ! |
          |マタ イラシテクダサイネ!   |
romaji    okini mesanakattamitaine! / mata irashitekudasaine!

actual    |¿Nada, eh?      |
          |Vuelve otro día.|

PROPUESTA |¿Nada, eh?      |
          |Vuelve otro día.|
           1234567890123456
```

### [2] al comprar  ·  `$46AC`  ·  hueco 36 B

```
japonés   |アリガトウゴザイマシタ!    |
          |   マタ イラシテクダサイネ |
romaji    arigatougozaimashita! /    mata irashitekudasaine

actual    |¡Muchas gracias!|
          |Vuelve otro día.|

PROPUESTA |¡Muchas gracias!|
          |Vuelve otro día.|
           1234567890123456
```

### [3] sin dinero bastante  ·  `$46D0`  ·  hueco 33 B

```
japonés   |アラ オキャクサン!      |
          |オカネガ タリマセンヨ!    |
romaji    ara okyakusan! / okanega tarimasenyo!

actual    |¡Vaya, cliente! |
          |Te falta dinero.|

PROPUESTA |¡Vaya, cliente! |
          |Te falta dinero.|
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$46F1`  ·  hueco 34 B

```
japonés   |マア! モチモノガ イッパイ  |
          |ヨ!              |
romaji    maa! mochimonoga ippai / yo!

actual    |¡Llevas las     |
          |manos llenas!   |

PROPUESTA |¡Llevas las     |
          |manos llenas!   |
           1234567890123456
```

### [5] tras comprar: ¿algo más?  ·  `$4C0B`  ·  hueco 38 B

```
japonés   |アリガトウゴザイマシタ!    |
          |   マダ ナニカ ゴイリヨ  |
romaji    arigatougozaimashita! /    mada nanika goiriyo

actual    |¡Muchas gracias!|
          |¿Algo más?      |

PROPUESTA |¡Muchas gracias!|
          |¿Algo más?      |
           1234567890123456
```


## Tienda 4 — OBJETOS (anciano)

*Anciano, habla en «-ja» (dialecto de mayor).*

### [0] al entrar  ·  `$4713`  ·  hueco 33 B

```
japonés   |ヨク キナスッタ!       |
          |ナニカ ゴヨウカナ?      |
romaji    yoku kinasutta! / nanika goyoukana?

actual    |¡Qué bien verte!|
          |¿Necesitas algo?|

PROPUESTA |¡Qué bien verte!|
          |¿Necesitas algo?|
           1234567890123456
```

### [1] al salir sin comprar  ·  `$4734`  ·  hueco 34 B

```
japonés   |マタ オイデクダサレ!     |
          |                |
romaji    mata oidekudasare! / 

actual    |Vuelve por aquí.|
          |                |

PROPUESTA |¡Vuelve pronto! |
          |                |
           1234567890123456
```

### [2] al comprar  ·  `$4756`  ·  hueco 35 B

```
japonés   |アリガトウデスジャ!      |
          |                |
romaji    arigatoudesujya! / 

actual    |¡Gracias!       |
          |                |

PROPUESTA |¡Gracias!       |
          |                |
           1234567890123456
```

### [3] sin dinero bastante  ·  `$4779`  ·  hueco 35 B

```
japonés   |オオ! オキャクサン!     |
          |オカネガ タリマセンデスジ   |
romaji    oo! okyakusan! / okanega tarimasendesuji

actual    |¡Vaya, cliente! |
          |Te falta dinero.|

PROPUESTA |¡Vaya, cliente! |
          |Te falta dinero.|
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$479C`  ·  hueco 35 B

```
japonés   |モチモノガ イッパイノヨウシ  |
          |゛ャ!             |
romaji    mochimonoga ippainoyoushi / ゛ya!

actual    |¡Llevas las     |
          |manos llenas!   |

PROPUESTA |¡Llevas las     |
          |manos llenas!   |
           1234567890123456
```

### [5] tras comprar: ¿algo más?  ·  `$4C31`  ·  hueco 40 B

```
japonés   |アリガトウデスジャ!      |
          |   ホカニハ ドウデスジ   |
romaji    arigatoudesujya! /    hokaniha doudesuji

actual    |¡Gracias!       |
          |¿Algo más?      |

PROPUESTA |¡Gracias!       |
          |¿Algo más?      |
           1234567890123456
```


## Tienda 5 — POSADA 300

*Gorrión posadero: pía. 300 monedas.*

### [0] al entrar  ·  `$47BF`  ·  hueco 39 B

```
japonés   |\チュンチュン!\スズメノオヤ |
          |ドデスイッパク300$デ    |
romaji    \chyunchyun!\suzumenooya / dodesuippaku300$de

actual    |¡Pío, pío!      |
          |Posada: 300.    |

PROPUESTA |¡Pío, pío!      |
          |Posada: 300.    |
           1234567890123456
```

### [1] al salir sin comprar  ·  `$485C`  ·  hueco 34 B

```
japonés   |アンマリ ムリヲ シナイデネ! |
          | キヲツケテネ! \チュンチュン|
romaji    anmari muriwo shinaidene! /  kiwotsuketene! \chyunchyun

actual    |No te pases.    |
          |¡Ten cuidado!   |

PROPUESTA |No te esfuerces.|
          |¡Ten cuidado!   |
           1234567890123456
```

### [2] al comprar  ·  `$4834`  ·  hueco 40 B

```
japonés   |オハヨウゴザイマス!      |
          |  \オニ\タイジ ガンバ   |
romaji    ohayougozaimasu! /   \oni\taiji ganba

actual    |¡Buenos días!   |
          |¡A por ogros!   |

PROPUESTA |¡Buenos días!   |
          |¡A por ogros!   |
           1234567890123456
```

### [3] sin dinero bastante  ·  `$487E`  ·  hueco 800 B

```
japonés   |\チュンチュン!        |
          | \オカネガ タリマセンヨ!  |
romaji    \chyunchyun! /  \okanega tarimasenyo!

actual    |¡Pío, pío!      |
          |Te falta dinero.|

PROPUESTA |¡Pío, pío!      |
          |Te falta dinero.|
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$4834`  —  **mismo texto que la ranura [2]**

### [5] tras comprar: ¿algo más?  ·  `$4834`  —  **mismo texto que la ranura [2]**


## Tienda 6 — POSADA 500

*Gorrión posadero: pía. 500 monedas.*

### [0] al entrar  ·  `$47E6`  ·  hueco 39 B

```
japonés   |\チュンチュン!\スズメノオヤ |
          |ドデスイッパク500$デ    |
romaji    \chyunchyun!\suzumenooya / dodesuippaku500$de

actual    |¡Pío, pío!      |
          |Posada: 500.    |

PROPUESTA |¡Pío, pío!      |
          |Posada: 500.    |
           1234567890123456
```

### [1] al salir sin comprar  ·  `$485C`  ·  hueco 34 B

```
japonés   |アンマリ ムリヲ シナイデネ! |
          | キヲツケテネ! \チュンチュン|
romaji    anmari muriwo shinaidene! /  kiwotsuketene! \chyunchyun

actual    |No te pases.    |
          |¡Ten cuidado!   |

PROPUESTA |No te esfuerces.|
          |¡Ten cuidado!   |
           1234567890123456
```

### [2] al comprar  ·  `$4834`  ·  hueco 40 B

```
japonés   |オハヨウゴザイマス!      |
          |  \オニ\タイジ ガンバ   |
romaji    ohayougozaimasu! /   \oni\taiji ganba

actual    |¡Buenos días!   |
          |¡A por ogros!   |

PROPUESTA |¡Buenos días!   |
          |¡A por ogros!   |
           1234567890123456
```

### [3] sin dinero bastante  ·  `$487E`  ·  hueco 800 B

```
japonés   |\チュンチュン!        |
          | \オカネガ タリマセンヨ!  |
romaji    \chyunchyun! /  \okanega tarimasenyo!

actual    |¡Pío, pío!      |
          |Te falta dinero.|

PROPUESTA |¡Pío, pío!      |
          |Te falta dinero.|
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$4834`  —  **mismo texto que la ranura [2]**

### [5] tras comprar: ¿algo más?  ·  `$4834`  —  **mismo texto que la ranura [2]**


## Tienda 7 — POSADA 1000

*Gorrión posadero: pía. 1000 monedas.*

### [0] al entrar  ·  `$480D`  ·  hueco 39 B

```
japonés   |\チュンチュン!\スズメノオヤ |
          |ドデスイッパク1000$テ   |
romaji    \chyunchyun!\suzumenooya / dodesuippaku1000$te

actual    |¡Pío, pío!      |
          |Posada: 1000.   |

PROPUESTA |¡Pío, pío!      |
          |Posada: 1000.   |
           1234567890123456
```

### [1] al salir sin comprar  ·  `$485C`  ·  hueco 34 B

```
japonés   |アンマリ ムリヲ シナイデネ! |
          | キヲツケテネ! \チュンチュン|
romaji    anmari muriwo shinaidene! /  kiwotsuketene! \chyunchyun

actual    |No te pases.    |
          |¡Ten cuidado!   |

PROPUESTA |No te esfuerces.|
          |¡Ten cuidado!   |
           1234567890123456
```

### [2] al comprar  ·  `$4834`  ·  hueco 40 B

```
japonés   |オハヨウゴザイマス!      |
          |  \オニ\タイジ ガンバ   |
romaji    ohayougozaimasu! /   \oni\taiji ganba

actual    |¡Buenos días!   |
          |¡A por ogros!   |

PROPUESTA |¡Buenos días!   |
          |¡A por ogros!   |
           1234567890123456
```

### [3] sin dinero bastante  ·  `$487E`  ·  hueco 800 B

```
japonés   |\チュンチュン!        |
          | \オカネガ タリマセンヨ!  |
romaji    \chyunchyun! /  \okanega tarimasenyo!

actual    |¡Pío, pío!      |
          |Te falta dinero.|

PROPUESTA |¡Pío, pío!      |
          |Te falta dinero.|
           1234567890123456
```

### [4] no queda / vas lleno  ·  `$4834`  —  **mismo texto que la ranura [2]**

### [5] tras comprar: ¿algo más?  ·  `$4834`  —  **mismo texto que la ranura [2]**


## Tienda 8 — POSADA 100  *(la que faltaba)*

*Gorrión posadero. La tabla `0x10854` tiene **NUEVE** tiendas, no ocho: la
novena empieza en `0x108B4`. Sus ranuras [1]-[5] comparten puntero con las
otras posadas y por eso ya salían traducidas; solo la ranura [0] tiene
texto propio, y era la que David vio en japonés.*

### [0] al entrar  ·  `$4C57`  ·  hueco 32 B

```
japonés   |\チュンチュン!\スズメノオヤ |
          |ドデスイッパク100$デ    |
romaji    \chyunchyun!\suzumenooya / dodesuippaku100$de

actual    |(sin traducir)  |
          |                |

PROPUESTA |¡Pío, pío!      |
          |Posada: 100.    |
           1234567890123456
```

### [1]-[5]  —  **mismo texto que las posadas 300/500/1000**

---

---

## El tramo japonés pendiente: NO es de tienda

`0x4846B` no lo apunta la tabla de tiendas. Medido: forma parte de un
bloque de **vítores y mensajes de final** que va de `0x48401` a `0x4847C`,
con las frases separadas por relleno `$A0`:

```
0x48406  22 B  テンガヨブ チガヨブ ヒトガヨブ      tenga yobu, chiga yobu, hitoga yobu
0x4841E  16 B  エンマヲ タオセト オレヲヨブ        Enma wo taose to ore wo yobu
0x48434  12 B  メデタシ メデタシ!             medetashi medetashi!
0x48446  14 B  モモタロウハ キョウモイク!         Momotarou wa kyou mo iku!
0x4845A  11 B  タスケテ モモチャン!            tasukete Momo-chan!
0x4846B  16 B  アナタダケガ タヨリデス!          anata dake ga tayori desu!
```

Es decir: «el cielo llama, la tierra llama, la gente llama», «me llaman
para derrotar a Enma», «¡colorín colorado!», «¡Momotarou sale hoy también!»,
«¡ayúdanos, Momo!», «¡solo podemos contar contigo!».

**Sí se puede insertar ya**, y sin riesgo: cada frase tiene su hueco
delimitado por `$A0` y basta con no pasarse de su longitud. Para
`0x4846B` hay **16 bytes**:

```
|¡Cuento contigo!|   16  CABE
|Solo confío en ti|  17  se pasa
|¡Confío en ti!|     14  CABE
|Eres mi esperanza|  17  se pasa
|¡Sálvanos!|         10  CABE
```

Pero son **vítores y finales**, no tienda: es el otro bloque que quedaba
pendiente en el proyecto. Lo suyo es hacerlo entero de una vez, con las
seis frases maquetadas y revisadas por ti, en vez de traducir una suelta.

Lo dejo preparado para la siguiente tanda.
