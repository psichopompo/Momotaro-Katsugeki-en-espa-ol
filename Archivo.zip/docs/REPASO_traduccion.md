# Repaso de la traducción — los 87 textos

**Revisión 2** — aplicadas las correcciones de David sobre los textos 0-31.

Cada bloque trae el **japonés original**, la **traducción** y **cómo queda
maquetada** en el bocadillo 20x4.

---


## Aldea de la Partida

### [0]

```
JP: モモタロヨ… / {2B}ボタンヲ / タタケバ / オニヲ / コウゲキ / デキルゾ…
```

**ES:** ¡Momotaro! Si pulsas el botón II podrás atacar a los ogros...

```
+--------------------+  pág 1
|¡Momotaro! Si       |
|pulsas el botón     |
|II podrás atacar    |
|a los ogros...      |
+--------------------+
```

### [1]

```
JP: ブキヤ / ボウグヲ / カッテイケバ / ドンドン / ラクチンニ / ナルノジャ…
```

**ES:** Si compras armas y armaduras, todo se te hará mucho más fácil...

```
+--------------------+  pág 1
|Si compras armas    |
|y armaduras, todo   |
|se te hará mucho    |
|más fácil...        |
+--------------------+
```

### [2]

```
JP: オミセニ / ハイルニハ / イリグチデ / ジュウジ / ボタンヲ / ウエ　デスダ
```

**ES:** Para entrar en una tienda, pulsa la cruceta hacia arriba en la entrada.

```
+--------------------+  pág 1
|Para entrar en una  |
|tienda, pulsa la    |
|cruceta hacia arriba|
|en la entrada.      |
+--------------------+
```

### [3]

```
JP: オニヲ / コラシメタラ / ブキヲ　カエ / ボウグ　カエ / ドウグ　カエ / ワッハッハ…
```

**ES:** Cuando les des su merecido a los ogros... ¡compra armas, compra armaduras, compra objetos! ¡Wahaha...!

```
+--------------------+  pág 1
|Cuando les des      |
|su merecido a los   |
|ogros... ¡compra    |
+--------------------+
```
```
+--------------------+  pág 2
|armas, compra       |
|armaduras, compra   |
|objetos! ¡Wahaha...!|
+--------------------+
```

### [4]

```
JP: ジブンノ / ツヨサヲ / ミタイナラ / セレクトヲ / オスノデスヨ
```

**ES:** Si quieres ver lo fuerte que eres, pulsa el botón SELECT.

```
+--------------------+  pág 1
|Si quieres ver      |
|lo fuerte que       |
|eres, pulsa el      |
|botón SELECT.       |
+--------------------+
```

### [5]

```
JP: センニンハ / タカイトコニ / スンデオル… / センジュツヲ / オシエテ / モラウガヨイ
```

**ES:** El ermitaño vive en lo alto... Deberías pedirle que te enseñe sus artes.

```
+--------------------+  pág 1
|El ermitaño vive en |
|lo alto... Deberías |
|pedirle que te      |
|enseñe sus artes.   |
+--------------------+
```

### [6]

```
JP: ランボタンヲ / オスト /  / ジュツヤ / ドウグガ / ツカエルゾ… / モットモ / モッテナイト / ツカエンガ…
```

**ES:** Si pulsas el botón RUN podrás usar artes y objetos... Claro que, si no tienes ninguno, no podrás usar nada...

```
+--------------------+  pág 1
|Si pulsas el botón  |
|RUN podrás usar     |
|artes y objetos...  |
+--------------------+
```
```
+--------------------+  pág 2
|Claro que, si no    |
|tienes ninguno, no  |
|podrás usar nada... |
+--------------------+
```

### [7]

```
JP: {2A}ボタンデ / ジャンプ / シナガラ / {2B}ボタンデ / コウゲキ / スルノダ… / セッシャモ / コノ / ヤリカタデ / オニヲ / {31}{30}{30}{30}ビキ / タオシタゾ…
```

**ES:** Salta con el botón I y ataca con el botón II... Yo mismo derroté a 1000 ogros de esta manera...

```
+--------------------+  pág 1
|Salta con el botón  |
|I y ataca con el    |
|botón II... Yo mismo|
+--------------------+
```
```
+--------------------+  pág 2
|derroté a 1000 ogros|
|de esta manera...   |
+--------------------+
```

### [8]

```
JP: サクラヲ / サカセテ / クダセー… / オネゲーダ…
```

**ES:** Haz florecer los cerezos, por favor... ¡Te lo suplico!

```
+--------------------+  pág 1
|Haz florecer        |
|los cerezos,        |
|por favor...        |
|¡Te lo suplico!     |
+--------------------+
```

### [9]

```
JP: オオ… / サクラガ / ウツクシイ… / フタタビ / サクラノサク / ムラニ… / アリガトウ / ゴゼエマスダ
```

**ES:** Oh... Qué hermosos están los cerezos... La aldea vuelve a florecer... Muchísimas gracias.

```
+--------------------+  pág 1
|Oh... Qué hermosos  |
|están los cerezos...|
|La aldea vuelve     |
+--------------------+
```
```
+--------------------+  pág 2
|a florecer...       |
|Muchísimas gracias. |
+--------------------+
```

### [10]

```
JP: シクシク / オニタチガ /  / コノムラノ / サクラヲ / チラセタノ / トッテモ / キレイナムラ / ダッタノニ / シクシク
```

**ES:** Buaaa... Los ogros marchitaron los cerezos de esta aldea. ¡Con lo bonita que era! Buaaa...

```
+--------------------+  pág 1
|Buaaa... Los        |
|ogros marchitaron   |
|los cerezos de      |
+--------------------+
```
```
+--------------------+  pág 2
|esta aldea. ¡Con    |
|lo bonita que       |
|era! Buaaa...       |
+--------------------+
```

### [11]

```
JP: マア… / ツヨソウナ / イヌネ… / シッテル？ /  /  / サイキンノ / イヌハ /  / テナゲダンヲ / ツカウンデス / ッテ…
```

**ES:** Vaya... Qué perro tan fuerte... ¿Sabías que los perros de ahora lanzan bombas de mano?

```
+--------------------+  pág 1
|Vaya... Qué perro   |
|tan fuerte...       |
|¿Sabías que         |
+--------------------+
```
```
+--------------------+  pág 2
|los perros de       |
|ahora lanzan        |
|bombas de mano?     |
+--------------------+
```

### [12]

```
JP: グルグル / マワルオニハ /  / マワッテル / アイダハ / タオセンゾ…
```

**ES:** A los ogros que giran sin parar no puedes vencerlos mientras dan vueltas...

```
+--------------------+  pág 1
|A los ogros         |
|que giran sin       |
|parar no puedes     |
+--------------------+
```
```
+--------------------+  pág 2
|vencerlos mientras  |
|dan vueltas...      |
+--------------------+
```

### [13]

```
JP: ツイサイキン / キイタノダガ /  / ハナサカノ / ジイサマハ /  / モモタロウヲ / タスケルタメ /  / ドウグヤヲ / カイギョウ / シタンダト…
```

**ES:** Me he enterado hace poco de que el anciano de los cerezos ha abierto una tienda de objetos para ayudar a Momotaro...

```
+--------------------+  pág 1
|Me he enterado      |
|hace poco de que    |
|el anciano de los   |
|cerezos ha abierto  |
+--------------------+
```
```
+--------------------+  pág 2
|una tienda de       |
|objetos para ayudar |
|a Momotaro...       |
+--------------------+
```

### [14]

```
JP: ココダケノ / ハナシジャ… /  / ボスキャラノ / ジャクテンハ /  / カラダニ / ツイテイル / マト　ラシイ / ココダケノ / ハナシジャ… /  / ミンナニハ / ナイショダゾ
```

**ES:** Que quede entre nosotros... El punto débil del jefe es la diana que lleva en el cuerpo. Que quede entre nosotros... ¡No se lo cuentes a nadie!

```
+--------------------+  pág 1
|Que quede entre     |
|nosotros... El      |
|punto débil del     |
|jefe es la diana que|
+--------------------+
```
```
+--------------------+  pág 2
|lleva en el cuerpo. |
|Que quede entre     |
|nosotros... ¡No se  |
|lo cuentes a nadie! |
+--------------------+
```

### [15]

```
JP: サクラッテ / スゴクキレイ / ラシイケド / コノムラニ / サクラガ / サイテタノハ / ボクガ / ウマレルマエ / ナンダッテ…
```

**ES:** Dicen que los cerezos son preciosos, pero en esta aldea florecieron antes de que yo naciera...

```
+--------------------+  pág 1
|Dicen que los       |
|cerezos son         |
|preciosos, pero     |
+--------------------+
```
```
+--------------------+  pág 2
|en esta aldea       |
|florecieron antes   |
|de que yo naciera...|
+--------------------+
```

### [16]

```
JP: コレガ / サクラカア… /  / ホントニ / キレイダネ… /  / コノハナヲ / ミテルト /  / ココロガ / ウキウキシテ / クルネ…
```

**ES:** ¿Así que estos son los cerezos...? Qué bonitos son... Al mirar estas flores el corazón se llena de alegría...

```
+--------------------+  pág 1
|¿Así que estos son  |
|los cerezos...? Qué |
|bonitos son... Al   |
+--------------------+
```
```
+--------------------+  pág 2
|mirar estas flores  |
|el corazón se       |
|llena de alegría... |
+--------------------+
```

### [17]

```
JP: コノムラニ / サクラガ / マタサクラ？
```

**ES:** ¿En esta aldea han vuelto a florecer los cerezos?

```
+--------------------+  pág 1
|¿En esta aldea han  |
|vuelto a florecer   |
|los cerezos?        |
+--------------------+
```

### [18]

```
JP: サークーラー / サークーラー /  / アリガトウ / ゴザイマシタ /  / コレデ / コノムラモ / ムカシノ / アカルサヲ / トリモドシタ / ヨウデス… / ホントウニ / アリガトウ…
```

**ES:** Ce-re-zos, ce-re-zos... Muchísimas gracias. Parece que la aldea ha recuperado la alegría de antaño... De verdad, gracias...

```
+--------------------+  pág 1
|Ce-re-zos,          |
|ce-re-zos...        |
|Muchísimas gracias. |
|Parece que la       |
+--------------------+
```
```
+--------------------+  pág 2
|aldea ha recuperado |
|la alegría de       |
|antaño... De        |
|verdad, gracias...  |
+--------------------+
```


## Aldea de Kintaro

### [19]

```
JP: ココハ / キンタロウノ / 　　　　ムラ / アシガラヤマ / ノフモトデ / ゴワス…
```

**ES:** Esta es la aldea de Kintaro, al pie del monte Ashigara...

```
+--------------------+  pág 1
|Esta es la aldea de |
|Kintaro, al pie del |
|monte Ashigara...   |
+--------------------+
```

### [20]

```
JP: アシガラヤマ / カラ / オチテクル / デッケエ / キンタロアメ / ノセイデヨオ / サクモツハ / トレネエ… /  / ソトモ / アルケネエ… /  / フンダリ / ケッタリダ…
```

**ES:** Por culpa de los caramelos Kintaro gigantes que caen del monte Ashigara no se pueden cosechar los cultivos... Tampoco se puede andar por fuera... ¡Esto es llover sobre mojado!

```
+--------------------+  pág 1
|Por culpa de los    |
|caramelos Kintaro   |
|gigantes que        |
|caen del monte      |
+--------------------+
```
```
+--------------------+  pág 2
|Ashigara no se      |
|pueden cosechar los |
|cultivos... Tampoco |
+--------------------+
```
```
+--------------------+  pág 3
|se puede andar por  |
|fuera... ¡Esto es   |
|llover sobre mojado!|
+--------------------+
```

### [21]

```
JP: オニタイジヲ / シテクレタノ / カイ… / アンタノ / オカゲデ /  / コノムラモ / ムカシミタク /  / ヘイワニ / ナッタダヨ… /  / ホントニ / アリガトヨ…
```

**ES:** ¿Has acabado con los ogros...? Gracias a ti esta aldea ha vuelto a vivir en paz como antaño... De verdad, muchas gracias...

```
+--------------------+  pág 1
|¿Has acabado con    |
|los ogros...?       |
|Gracias a ti esta   |
|aldea ha vuelto a   |
+--------------------+
```
```
+--------------------+  pág 2
|vivir en paz como   |
|antaño... De verdad,|
|muchas gracias...   |
+--------------------+
```

### [22]

```
JP: キンタロアメ / イランカア… /  / キンタロアメ / イランカア… / ウウッ… / キンタロアメ / ガ　ゴロゴロ / シトルセイデ / コチトラ / ショウバイ / アガッタリダ
```

**ES:** ¿Caramelos de Kintaro...? ¿Nadie quiere caramelos...? Buaaa... Con tanto caramelo tirado por ahí, mi negocio se ha ido a pique.

```
+--------------------+  pág 1
|¿Caramelos de       |
|Kintaro...? ¿Nadie  |
|quiere caramelos...?|
|Buaaa... Con tanto  |
+--------------------+
```
```
+--------------------+  pág 2
|caramelo tirado     |
|por ahí, mi negocio |
|se ha ido a pique.  |
+--------------------+
```

### [23]

```
JP: キンタロアメ / イランカア… /  / キンタロアメ / イランカア… /  / ハッハッハ… /  /  / オニタイジ / シテクレタ / オカゲデ / コチトラ / ショウバイ / ハンジョウ…
```

**ES:** ¡Caramelos de Kintaro! ¡Caramelos de Kintaro! Ja, ja, ja... Gracias a que acabaste con los ogros, mi negocio va viento en popa...

```
+--------------------+  pág 1
|¡Caramelos de       |
|Kintaro! ¡Caramelos |
|de Kintaro! Ja, ja, |
|ja... Gracias a que |
+--------------------+
```
```
+--------------------+  pág 2
|acabaste con los    |
|ogros, mi negocio   |
|va viento en popa...|
+--------------------+
```

### [24]

```
JP: オニタチガ / アシガラヤマ / ニ / ハシゴヲ / タクサン / カケテネエ / テッペンニ / ノボロウト / スル / タビビトニ / モノヲ / ナゲツケテ / ジャマスル / ソウナ…
```

**ES:** Dicen que los ogros han puesto muchas escaleras en el monte Ashigara y arrojan cosas a los viajeros que intentan subir a la cima...

```
+--------------------+  pág 1
|Dicen que los ogros |
|han puesto muchas   |
|escaleras en el     |
|monte Ashigara y    |
+--------------------+
```
```
+--------------------+  pág 2
|arrojan cosas a     |
|los viajeros que    |
|intentan subir      |
|a la cima...        |
+--------------------+
```

### [25]

```
JP: オニタイジヲ / シテクレタト / イウノカイ… / イヤ　ホンニ / アリガタイ / コッテ…
```

**ES:** ¿Dices que has acabado con los ogros...? Ay, de verdad, cuánto te lo agradezco...

```
+--------------------+  pág 1
|¿Dices que has      |
|acabado con los     |
|ogros...? Ay, de    |
+--------------------+
```
```
+--------------------+  pág 2
|verdad, cuánto te   |
|lo agradezco...     |
+--------------------+
```

### [26]

```
JP: コノムラデハ / キンタロアメ / ヲ　ツクッテ / セイカツ / シテルノデス
```

**ES:** En esta aldea vivimos de fabricar caramelos Kintaro.

```
+--------------------+  pág 1
|En esta aldea       |
|vivimos de fabricar |
|caramelos Kintaro.  |
+--------------------+
```

### [27]

```
JP: コンド / コノムラデハ /  / アナタサマノ / コウセキヲ / キネンシテ / モモタロアメ / ヲ　ツクッテ / イクコトニ / ソンミン / イチドウデ / キメマシタ…
```

**ES:** Para conmemorar vuestra hazaña, todos los vecinos hemos decidido fabricar a partir de ahora caramelos Momotaro...

```
+--------------------+  pág 1
|Para conmemorar     |
|vuestra hazaña,     |
|todos los vecinos   |
|hemos decidido      |
+--------------------+
```
```
+--------------------+  pág 2
|fabricar a partir   |
|de ahora caramelos  |
|Momotaro...         |
+--------------------+
```

### [28]

```
JP: キンタロアメ / ガ　イッパイ / タベレルノハ / ウレシイケド /  /  / トウチャンヤ / カアチャンガ /  / ショウバイニ / ナラナイッテ / ナイテルノ…
```

**ES:** Poder comer caramelos a montones está muy bien, pero papá y mamá lloran porque no hay negocio...

```
+--------------------+  pág 1
|Poder comer         |
|caramelos a montones|
|está muy bien,      |
+--------------------+
```
```
+--------------------+  pág 2
|pero papá y mamá    |
|lloran porque no    |
|hay negocio...      |
+--------------------+
```

### [29]

```
JP: ネエネエ… / シッテル？ /  / キジサンガ / イレバ /  / ジユウニ / ソラヲ / トベルンダヨ
```

**ES:** Oye, oye... ¿Sabías que con el faisán puedes volar libre por el cielo?

```
+--------------------+  pág 1
|Oye, oye... ¿Sabías |
|que con el faisán   |
|puedes volar libre  |
|por el cielo?       |
+--------------------+
```

### [30]

```
JP: ニチリンノ / 　　　ツブテ / サエアレバ / ココラヘンノ / オニハ / コワクナイゾ
```

**ES:** Con el guijarro de fuego no hay que temer a los ogros de por aquí.

```
+--------------------+  pág 1
|Con el guijarro     |
|de fuego no hay     |
|que temer a los     |
|ogros de por aquí.  |
+--------------------+
```

### [31]

```
JP: オヤ？オヌシ / サルヲ / ツレトルノカ / サルハ / ムカシカラ /  / サルマネガ / トクイダト / キクガ / ソノサルハ / ドウナノデ / アロウカノ…
```

**ES:** ¿Vaya? ¿Llevas contigo al mono? Dicen que los monos siempre han sido buenos imitando... ¿Qué tal se le dará a ése?

```
+--------------------+  pág 1
|¿Vaya? ¿Llevas      |
|contigo al mono?    |
|Dicen que los       |
|monos siempre       |
+--------------------+
```
```
+--------------------+  pág 2
|han sido buenos     |
|imitando... ¿Qué tal|
|se le dará a ése?   |
+--------------------+
```


## Aldea de Netaro (nieve)

### [32]

```
JP: ココハ / ネタロウノ / 　　　　ムラ
```

**ES:** Esta es la aldea de Netaro.

```
+--------------------+  pág 1
|Esta es la          |
|aldea de Netaro.    |
+--------------------+
```

### [33]

```
JP: ジメンガ / コオッテイル / トコロハ / スベッテ / アルキニクイ / モンジャ… / チュウイスル / コトジャナ…
```

**ES:** Donde el suelo está helado se resbala y cuesta andar... Anda con cuidado...

```
+--------------------+  pág 1
|Donde el suelo está |
|helado se resbala   |
|y cuesta andar...   |
|Anda con cuidado... |
+--------------------+
```

### [34]

```
JP: ワルイコトハ / イワネエ… /  / ココラヘンハ / カンジキヲ / ハクコッタ… / ソコノ / ドウグヤデ / ウットルダ…
```

**ES:** No te lo digo por mal... Por aquí conviene calzarse unas raquetas... Las venden en esa tienda de objetos...

```
+--------------------+  pág 1
|No te lo digo por   |
|mal... Por aquí     |
|conviene calzarse   |
+--------------------+
```
```
+--------------------+  pág 2
|unas raquetas...    |
|Las venden en esa   |
|tienda de objetos...|
+--------------------+
```

### [35]

```
JP: オーサム… /  /  / ココラヘンモ / オニガヤッテ / キテカラ / イチダント / サムサガ / マシタノジャ / コドモハ / ムジャキデ / エエノウ… / トシヨリニハ / サムサガ / コタエテノウ
```

**ES:** Qué frío... Desde que llegaron los ogros hace aún más frío por aquí. Los niños son inocentes y no lo notan... pero a los viejos el frío nos puede.

```
+--------------------+  pág 1
|Qué frío... Desde   |
|que llegaron los    |
|ogros hace aún más  |
|frío por aquí. Los  |
+--------------------+
```
```
+--------------------+  pág 2
|niños son inocentes |
|y no lo notan...    |
|pero a los viejos   |
|el frío nos puede.  |
+--------------------+
```

### [36]

```
JP: オーサム… / コサム… /  / オニタイジ / シテクレタ / オカゲデ / スコシハ / アタタカク / ナリマシタ / イヤ　ホンニ / アリガトウ / ゴゼエマシタ
```

**ES:** Qué frío... Qué helada... Gracias a que acabaste con los ogros ahora se está algo más templado. De verdad, muchísimas gracias.

```
+--------------------+  pág 1
|Qué frío... Qué     |
|helada... Gracias   |
|a que acabaste con  |
|los ogros ahora     |
+--------------------+
```
```
+--------------------+  pág 2
|se está algo más    |
|templado. De verdad,|
|muchísimas gracias. |
+--------------------+
```

### [37]

```
JP: モモタロウノ / オニイチャン /  / オニヲ / タイジシテ / チョウダイ… / オバアサンガ / サムサデ / マイッテルノ / オネガイダヨ / オニヲ / タイジシテネ
```

**ES:** Momotaro, acaba con los ogros, por favor... La abuela ya no aguanta el frío. Te lo suplico, acaba con ellos.

```
+--------------------+  pág 1
|Momotaro, acaba     |
|con los ogros, por  |
|favor... La abuela  |
+--------------------+
```
```
+--------------------+  pág 2
|ya no aguanta el    |
|frío. Te lo suplico,|
|acaba con ellos.    |
+--------------------+
```

### [38]

```
JP: モモタロウノ / オニイチャン /  / オカゲデ / オバアサンモ /  / スコシハ / ラクニナッタ / ミタイ / ホントウニ / アリガトウ…
```

**ES:** Momotaro, gracias a ti la abuela parece estar un poco mejor. Muchísimas gracias...

```
+--------------------+  pág 1
|Momotaro, gracias   |
|a ti la abuela      |
|parece estar un poco|
+--------------------+
```
```
+--------------------+  pág 2
|mejor. Muchísimas   |
|gracias...          |
+--------------------+
```


## Aldea de Urashima (mar)

### [39]

```
JP: ココハ / ウラシマノ / 　　　　ムラ
```

**ES:** Esta es la aldea de Urashima.

```
+--------------------+  pág 1
|Esta es la aldea    |
|de Urashima.        |
+--------------------+
```

### [40]

```
JP: ワシハ / ムカシハ / ウミデ / サザエナドヲ / トル{A2}アマ{A3} / ジャッタ / ウミノナカノ / コトナラ / クワシイゾヨ
```

**ES:** Yo, de joven, era una "ama" y recogía caracolas en el mar. De lo que hay bajo el agua sé un rato...

```
+--------------------+  pág 1
|Yo, de joven,       |
|era una "ama" y     |
|recogía caracolas   |
+--------------------+
```
```
+--------------------+  pág 2
|en el mar. De lo    |
|que hay bajo el     |
|agua sé un rato...  |
+--------------------+
```

### [41]

```
JP: カッパノ / ミズカキッテ / シッテル？ / スイチュウデ / ジユウニ / オヨゲルノヨ / ドウグヤサン / ニアルカラ /  / カッテイッタ / ホウガ / イイワヨ…
```

**ES:** ¿Conoces las aletas de kappa? Con ellas se nada libremente bajo el agua. Las tienen en la tienda de objetos, más te vale comprarlas...

```
+--------------------+  pág 1
|¿Conoces las aletas |
|de kappa? Con ellas |
|se nada libremente  |
|bajo el agua. Las   |
+--------------------+
```
```
+--------------------+  pág 2
|tienen en la tienda |
|de objetos, más te  |
|vale comprarlas...  |
+--------------------+
```

### [42]

```
JP: カメノコウラ / ガナイト /  / ウミニハ / モグレナイ / ンダッテサ… / デモ / ドウヤッタラ / テニハイルノ？
```

**ES:** Dicen que sin el caparazón de tortuga no se puede uno sumergir en el mar... Pero ¿cómo se consigue?

```
+--------------------+  pág 1
|Dicen que sin       |
|el caparazón de     |
|tortuga no se       |
+--------------------+
```
```
+--------------------+  pág 2
|puede uno sumergir  |
|en el mar... Pero   |
|¿cómo se consigue?  |
+--------------------+
```

### [43]

```
JP: カメヲ / タスケタラ /  / コウラヲ / カシテクレタ / ンダッテ… / ボクモ / カメヲ / タスケテ / ウミニ / ハイリタイナ
```

**ES:** Dicen que si salvas a una tortuga te presta su caparazón... Yo también quiero salvar una y bajar al fondo del mar.

```
+--------------------+  pág 1
|Dicen que si        |
|salvas a una        |
|tortuga te presta   |
|su caparazón...     |
+--------------------+
```
```
+--------------------+  pág 2
|Yo también quiero   |
|salvar una y bajar  |
|al fondo del mar.   |
+--------------------+
```

### [44]

```
JP: ウラシマガ / オトズレタ / リュウグウモ / イマデハ / オニタチノ / モノニ
```

**ES:** Hasta el Palacio del Dragón que visitó Urashima está ahora en manos de los ogros.

```
+--------------------+  pág 1
|Hasta el Palacio    |
|del Dragón que      |
|visitó Urashima     |
+--------------------+
```
```
+--------------------+  pág 2
|está ahora en       |
|manos de los ogros. |
+--------------------+
```

### [45]

```
JP: アリガタヤ… / マタ　ウミニ / ヘイワガ… / ミンナ / アナタサマノ / オカゲジャ…
```

**ES:** Bendito seáis... La paz ha vuelto al mar... Todo gracias a vos...

```
+--------------------+  pág 1
|Bendito seáis...    |
|La paz ha vuelto    |
|al mar... Todo      |
|gracias a vos...    |
+--------------------+
```

### [46]

```
JP: ウミガ / アレテシモテ /  / リョウニデル / コトガ / デキネエ… / コノママジャ / オラタチ / シンジマウ… / ドナイスレバ / イインジャ…
```

**ES:** El mar se ha embravecido y no podemos salir a faenar... Como siga así acabaremos muriéndonos... ¿Qué podemos hacer?

```
+--------------------+  pág 1
|El mar se ha        |
|embravecido y no    |
|podemos salir a     |
|faenar... Como      |
+--------------------+
```
```
+--------------------+  pág 2
|siga así acabaremos |
|muriéndonos...      |
|¿Qué podemos hacer? |
+--------------------+
```

### [47]

```
JP: オオ… / ウミガモトニ / モドッタダ… / コレモ / アンタノ / オカゲジャ… / ホントニ / アリガト / ゴゼエヤシタ
```

**ES:** Oh... El mar ha vuelto a su ser... Y también es gracias a ti... De verdad, muchísimas gracias.

```
+--------------------+  pág 1
|Oh... El mar ha     |
|vuelto a su ser...  |
|Y también es gracias|
+--------------------+
```
```
+--------------------+  pág 2
|a ti... De verdad,  |
|muchísimas gracias. |
+--------------------+
```

### [48]

```
JP: コマッタラ / キジニノッテ / ノボルンダヨ / サクシャガ / イッテタカラ / ホントダヨ…
```

**ES:** Si te ves en apuros, súbete al faisán y asciende. Lo dijo el autor del juego, así que es verdad...

```
+--------------------+  pág 1
|Si te ves en apuros,|
|súbete al faisán y  |
|asciende. Lo dijo   |
+--------------------+
```
```
+--------------------+  pág 2
|el autor del juego, |
|así que es verdad...|
+--------------------+
```


## Monte Kachikachi (fuego)

### [49]

```
JP: カチカチヤマ / カラ / ヒノコガ / トンデキテ / アブネッタラ / アリャシネエ / ニイチャンモ / キヲツケナ /  / アタルト / ダメージ / デカイゼ…
```

**ES:** Del monte Kachikachi salen volando chispas, es peligrosísimo. Ten cuidado tú también, chaval. Si te alcanzan, el daño es grande...

```
+--------------------+  pág 1
|Del monte           |
|Kachikachi salen    |
|volando chispas,    |
|es peligrosísimo.   |
+--------------------+
```
```
+--------------------+  pág 2
|Ten cuidado tú      |
|también, chaval.    |
|Si te alcanzan, el  |
|daño es grande...   |
+--------------------+
```

### [50]

```
JP: ハア… / アツイワア… /  / オモイキッテ / キモノヲ / ヌゴウカナ？ / {2E}{2E}{2E}{2E}{2E}{2E} / {2E}{2E}{2E}{2E}{2E} / {2E}{2E}{2E}{2E} / ナニ / ミテンノヨ…
```

**ES:** Ay... qué calor... ¿Y si me quito el kimono de una vez? ...... ¿Qué miras tú?

```
+--------------------+  pág 1
|Ay... qué calor...  |
|¿Y si me quito      |
|el kimono de        |
+--------------------+
```
```
+--------------------+  pág 2
|una vez? ......     |
|¿Qué miras tú?      |
+--------------------+
```

### [51]

```
JP: フー / モトドオリニ / ナッタミタイ / アツイノッテ / ニガテダッタ / ノヨネエ
```

**ES:** Uf, parece que todo ha vuelto a la normalidad. Nunca he llevado bien el calor.

```
+--------------------+  pág 1
|Uf, parece que      |
|todo ha vuelto      |
|a la normalidad.    |
+--------------------+
```
```
+--------------------+  pág 2
|Nunca he llevado    |
|bien el calor.      |
+--------------------+
```

### [52]

```
JP: ヨウガンニ / オチルト /  / ダメージヲ / クラウゾ… /  / ダイダイイロ / シテルノガ / ヨウガンダ… / セイゼイ / キヲツケナ…
```

**ES:** Si caes en la lava recibirás daño... Lo que está anaranjado es lava... Ándate con mucho ojo...

```
+--------------------+  pág 1
|Si caes en la lava  |
|recibirás daño... Lo|
|que está anaranjado |
+--------------------+
```
```
+--------------------+  pág 2
|es lava... Ándate   |
|con mucho ojo...    |
+--------------------+
```

### [53]

```
JP: オニドモノ / セイデ /  / ヤマニ / チカヅケナク / ナッテシモタ / カチカチヤマ / オンセンガ /  / ユイイツノ / タノシミ / ジャッタノニ
```

**ES:** Por culpa de los ogros ya no podemos acercarnos al monte. Y las aguas termales del Kachikachi eran nuestro único placer...

```
+--------------------+  pág 1
|Por culpa de los    |
|ogros ya no podemos |
|acercarnos al monte.|
|Y las aguas termales|
+--------------------+
```
```
+--------------------+  pág 2
|del Kachikachi      |
|eran nuestro        |
|único placer...     |
+--------------------+
```

### [54]

```
JP: オカゲサマデ / カチカチヤマ / オンセンニ / マタ / ハイレマス… /  / コレカラモ / フウフ / ナカヨク / オンセンニ / ツカッテ /  / ヘイワニ / クラシテ / イキマス…
```

**ES:** Gracias a ti podemos volver a las termas del Kachikachi... Mi mujer y yo seguiremos bañándonos juntos y viviremos en paz...

```
+--------------------+  pág 1
|Gracias a ti podemos|
|volver a las termas |
|del Kachikachi...   |
|Mi mujer y          |
+--------------------+
```
```
+--------------------+  pág 2
|yo seguiremos       |
|bañándonos juntos y |
|viviremos en paz... |
+--------------------+
```

### [55]

```
JP: ハイハイ / オジイサン / キコエテマス / コレデモ / アタシャ /  / ムカシハ / ミスカボチャ / ダッタンジャ / キョウモ / イイテンキ / ジャネエ…
```

**ES:** Sí, sí, abuelo, ya te oigo. Aunque no lo parezca, yo fui Miss Calabaza en mis tiempos. Hoy también hace buen día...

```
+--------------------+  pág 1
|Sí, sí, abuelo, ya  |
|te oigo. Aunque no  |
|lo parezca, yo fui  |
+--------------------+
```
```
+--------------------+  pág 2
|Miss Calabaza en mis|
|tiempos. Hoy también|
|hace buen día...    |
+--------------------+
```

### [56]

```
JP: ハイハイ / オジイサン / キコエテマス / コレデモ / アタシャ /  / カボチャガ / ダイコウブツ / ダッタンジャ / キョウモ / イイテンキ / ジャネエ…
```

**ES:** Sí, sí, abuelo, ya te oigo. Aunque no lo parezca, la calabaza era mi comida favorita. Hoy también hace buen día...

```
+--------------------+  pág 1
|Sí, sí, abuelo,     |
|ya te oigo. Aunque  |
|no lo parezca, la   |
|calabaza era mi     |
+--------------------+
```
```
+--------------------+  pág 2
|comida favorita.    |
|Hoy también         |
|hace buen día...    |
+--------------------+
```

### [57]

```
JP: カチカチヤマ / オンセンハ /  / フキダシテル / トキニ / ウエニノルト / イッショニ / タカイトコニ / イケルンダ… / オニガ / イナカッタ / コロハ / ヨク / アソンダンダ
```

**ES:** En las termas del Kachikachi, si te subes encima cuando brota el agua, te lleva hasta muy alto... Cuando no había ogros jugábamos mucho.

```
+--------------------+  pág 1
|En las termas del   |
|Kachikachi, si te   |
|subes encima cuando |
|brota el agua, te   |
+--------------------+
```
```
+--------------------+  pág 2
|lleva hasta muy     |
|alto... Cuando      |
|no había ogros      |
|jugábamos mucho.    |
+--------------------+
```

### [58]

```
JP: ワーイ / コレデ / マエミタイニ / オンセンデ / アソベルゾ… /  / オニイチャン / アリガトネ…
```

**ES:** ¡Bien! Ahora podremos jugar en las termas como antes... ¡Gracias, Momotaro!

```
+--------------------+  pág 1
|¡Bien! Ahora        |
|podremos jugar      |
|en las termas       |
+--------------------+
```
```
+--------------------+  pág 2
|como antes...       |
|¡Gracias, Momotaro! |
+--------------------+
```


## Aldea de Issun-boshi

### [59]

```
JP: ココハ / イッスン / ボウシノムラ / オオゴエヲ / ダサンヨウニ
```

**ES:** Esta es la aldea de Issun-boshi. No levantes la voz.

```
+--------------------+  pág 1
|Esta es la aldea    |
|de Issun-boshi. No  |
|levantes la voz.    |
+--------------------+
```

### [60]

```
JP: ココハ / イッスン / ボウシノムラ / モトニ / モドッテ / ヨカッタワイ
```

**ES:** Esta es la aldea de Issun-boshi. Menos mal que todo ha vuelto a su ser.

```
+--------------------+  pág 1
|Esta es la aldea    |
|de Issun-boshi.     |
|Menos mal que todo  |
|ha vuelto a su ser. |
+--------------------+
```

### [61]

```
JP: ムラノソトノ / オオキナオニ /  / アノオニガ / オキタラ /  / マタ　ムラヲ / アラシニ / クルダヨ… / オソロシクテ / ヨルモ / ネムレンノダ
```

**ES:** Ese ogro enorme de las afueras... Si despierta volverá a arrasar la aldea... Del miedo no pego ojo por las noches.

```
+--------------------+  pág 1
|Ese ogro enorme de  |
|las afueras... Si   |
|despierta volverá a |
+--------------------+
```
```
+--------------------+  pág 2
|arrasar la aldea... |
|Del miedo no pego   |
|ojo por las noches. |
+--------------------+
```

### [62]

```
JP: イヤハヤ / ホントウニ / アリガトウ… / オカゲデ / グッスリ / ネレマスワイ / ロウジンハ / ネルノガ / イチバンノ / タノシミダテ / ホントウニ / アリガトウ…
```

**ES:** Ay, de verdad, muchísimas gracias... Ahora podré dormir a pierna suelta. Para un viejo dormir es el mayor placer. De verdad, gracias...

```
+--------------------+  pág 1
|Ay, de verdad,      |
|muchísimas          |
|gracias... Ahora    |
|podré dormir a      |
+--------------------+
```
```
+--------------------+  pág 2
|pierna suelta. Para |
|un viejo dormir es  |
|el mayor placer. De |
|verdad, gracias...  |
+--------------------+
```

### [63]

```
JP: アノオニノ / オカゲデ /  / オラタチ / オオキナコエ / ダシテ / アソベナク / ナッタダ… /  / チッチャイ / コエデ / アソンデテモ / チィットモ / タノシクネエ
```

**ES:** Por culpa de ese ogro no podemos jugar a voces... Y jugar bajito no tiene ninguna gracia.

```
+--------------------+  pág 1
|Por culpa de        |
|ese ogro no         |
|podemos jugar a     |
+--------------------+
```
```
+--------------------+  pág 2
|voces... Y jugar    |
|bajito no tiene     |
|ninguna gracia.     |
+--------------------+
```

### [64]

```
JP: ワーーイ… / オオキナコエ / ダセルダ… / ヤッパリ / アソブトキハ / コウダベ / ソトニモ / アソビニ / イケルシ / ホントニ / アリガトウ…
```

**ES:** ¡Bieeen! ¡Ya podemos gritar! Así es como hay que jugar. Y además podemos salir a jugar fuera. ¡Muchísimas gracias!

```
+--------------------+  pág 1
|¡Bieeen! ¡Ya podemos|
|gritar! Así es      |
|como hay que jugar. |
+--------------------+
```
```
+--------------------+  pág 2
|Y además podemos    |
|salir a jugar fuera.|
|¡Muchísimas gracias!|
+--------------------+
```

### [65]

```
JP: ソトデネトル / オニダガナ… /  / アリャ / ウチデノ / 　　コヅチデ / デカクナッタ / ンダトヨ… /  / ナンデモ / ソレイライ / ズーット / アソコデ / ネムッテイル / ンダトヨ…
```

**ES:** Ese ogro que duerme ahí fuera... Dicen que se hizo enorme con el mazo mágico... Y que desde entonces lleva todo el tiempo dormido ahí.

```
+--------------------+  pág 1
|Ese ogro que        |
|duerme ahí fuera... |
|Dicen que se hizo   |
|enorme con el mazo  |
+--------------------+
```
```
+--------------------+  pág 2
|mágico... Y que     |
|desde entonces      |
|lleva todo el       |
|tiempo dormido ahí. |
+--------------------+
```

### [66]

```
JP: ブラボー… / アノオニヲ / タオストハ / サスガハ / ニホンイチノ / モモタロサン / アノカセキト / ナッタオニハ /  / トオリミチト / シテ　ツカワ / セテモラウヨ
```

**ES:** ¡Bravo! Derrotar a semejante ogro... Digno del mejor de Japón, Momotaro. A ese ogro hecho fósil lo aprovecharemos como camino.

```
+--------------------+  pág 1
|¡Bravo! Derrotar a  |
|semejante ogro...   |
|Digno del mejor de  |
|Japón, Momotaro. A  |
+--------------------+
```
```
+--------------------+  pág 2
|ese ogro hecho fósil|
|lo aprovecharemos   |
|como camino.        |
+--------------------+
```

### [67]

```
JP: アノオニヲ / タオスニハ / クチカラ / ハイッテ / アバレル / シカナイ / ダガ　ヤツノ / カラダノナカ / ニモ / テゴワイオニ / ガ　タクサン / オルソウダ…
```

**ES:** Para derrotar a ese ogro no queda más que entrar por su boca y armarla dentro. Pero dicen que en sus tripas hay muchos ogros temibles...

```
+--------------------+  pág 1
|Para derrotar a     |
|ese ogro no queda   |
|más que entrar por  |
|su boca y armarla   |
+--------------------+
```
```
+--------------------+  pág 2
|dentro. Pero        |
|dicen que en sus    |
|tripas hay muchos   |
|ogros temibles...   |
+--------------------+
```

### [68]

```
JP: ナント… / オマエガ / アノオニヲ… / イヤ / ソノチイサナ / カラダニ / ヒメラレタ / オオキナ / ユウキ… / セッシャ / カンプク / ツカマッタ…
```

**ES:** ¡Cómo! ¿Tú has vencido a ese ogro...? Qué gran valor escondido en un cuerpo tan pequeño... Me quito el sombrero.

```
+--------------------+  pág 1
|¡Cómo! ¿Tú has      |
|vencido a ese       |
|ogro...? Qué gran   |
|valor escondido     |
+--------------------+
```
```
+--------------------+  pág 2
|en un cuerpo tan    |
|pequeño... Me       |
|quito el sombrero.  |
+--------------------+
```

### [69]

```
JP: オニノ / イブクロニ / ハイッタラ / テンジョウモ / ユカモゼンブ / ワナミタイ… / ソンナトコニ / イクナンテ / ムボウヨ…
```

**ES:** Dicen que en el estómago del ogro el techo y el suelo son una trampa entera... Meterse ahí es una temeridad...

```
+--------------------+  pág 1
|Dicen que en el     |
|estómago del ogro el|
|techo y el suelo son|
+--------------------+
```
```
+--------------------+  pág 2
|una trampa entera...|
|Meterse ahí es      |
|una temeridad...    |
+--------------------+
```

### [70]

```
JP: マア… / アナタ / ブジダッタノ / スゴイワ… /  /  / アナタコソ / ユウキアル / ワカモノネ
```

**ES:** Vaya... ¿Estás sano y salvo? Increíble... Eres un joven de verdadero valor.

```
+--------------------+  pág 1
|Vaya... ¿Estás      |
|sano y salvo?       |
|Increíble...        |
+--------------------+
```
```
+--------------------+  pág 2
|Eres un joven de    |
|verdadero valor.    |
+--------------------+
```


## Aldea de Taketori

### [71]

```
JP: ココハ / タケトリノ / 　　　　ムラ
```

**ES:** Esta es la aldea de Taketori.

```
+--------------------+  pág 1
|Esta es la aldea    |
|de Taketori.        |
+--------------------+
```

### [72]

```
JP: カグヤサマガ / サイキン / ナント… / ギャンブルヲ / オボエテ / シマッタノ… / アチコチデ / ウデダメシ / シテルトカ？ / アタシモ / ヤッテミヨウ / カシラ…
```

**ES:** La princesa Kaguya ha aprendido hace poco a... ¡apostar! Dicen que anda probando suerte por todas partes. ¿Y si lo intento yo también?

```
+--------------------+  pág 1
|La princesa Kaguya  |
|ha aprendido        |
|hace poco a...      |
|¡apostar! Dicen     |
+--------------------+
```
```
+--------------------+  pág 2
|que anda probando   |
|suerte por todas    |
|partes. ¿Y si lo    |
|intento yo también? |
+--------------------+
```

### [73]

```
JP: クモノウエニ / オニドモガ / スムセカイガ / アルソウナ… /  /  / ワシラニハ / トテモ / イケンガノ…
```

**ES:** Dicen que sobre las nubes hay un mundo donde viven los ogros... Nosotros jamás podríamos llegar...

```
+--------------------+  pág 1
|Dicen que sobre     |
|las nubes hay       |
|un mundo donde      |
+--------------------+
```
```
+--------------------+  pág 2
|viven los ogros...  |
|Nosotros jamás      |
|podríamos llegar... |
+--------------------+
```

### [74]

```
JP: ヒョエエエー / クモノウエニ / イッテ / オニタイジ / シテキタト… /  / タイシタ / オヒトジャ…
```

**ES:** ¡Huyyy! ¿Que has subido sobre las nubes y has acabado con los ogros...? Menuda persona estás hecho...

```
+--------------------+  pág 1
|¡Huyyy! ¿Que has    |
|subido sobre las    |
|nubes y has acabado |
+--------------------+
```
```
+--------------------+  pág 2
|con los ogros...?   |
|Menuda persona      |
|estás hecho...      |
+--------------------+
```

### [75]

```
JP: オニハ / コラシメル / ダケデナク / トキニハ / リヨウスル / コトモ / タイセツジャ /  /  / トクニ / フンドシオニ / ナンカハノウ / ハッハッハ…
```

**ES:** A los ogros no solo hay que castigarlos: a veces conviene aprovecharlos. Sobre todo a los del taparrabos... ¡Ja, ja, ja!

```
+--------------------+  pág 1
|A los ogros no solo |
|hay que castigarlos:|
|a veces conviene    |
|aprovecharlos.      |
+--------------------+
```
```
+--------------------+  pág 2
|Sobre todo a los    |
|del taparrabos...   |
|¡Ja, ja, ja!        |
+--------------------+
```

### [76]

```
JP: コノババア / スッカリ / ダマサレテヨ / オニドモヲ / カミサマダト / オモッテンダ
```

**ES:** A esta vieja la han engañado del todo: se cree que los ogros son dioses.

```
+--------------------+  pág 1
|A esta vieja la han |
|engañado del todo:  |
|se cree que los     |
|ogros son dioses.   |
+--------------------+
```

### [77]

```
JP: バアサンモ / モトニ / モドッタシ / コレモ / アンタノ / オカゲダ… / ヘヘ / アリガトヨ…
```

**ES:** La abuela ha vuelto en sí, y también es gracias a ti... Je, je, ¡gracias!

```
+--------------------+  pág 1
|La abuela ha vuelto |
|en sí, y también    |
|es gracias a ti...  |
|Je, je, ¡gracias!   |
+--------------------+
```

### [78]

```
JP: フウジンサマ / フウジンサマ /  / アア / ワシラノ / シュゴシン… / ソラカラ / イツモ / ミマモッテ / クダサル… / アリガタイ / コッテスジャ / ナンマンダブ / ナンマンダブ
```

**ES:** Oh, señor Fuujin, señor Fuujin... Nuestro dios protector... Siempre nos vela desde el cielo... Cuánto se lo agradecemos. Namu Amida Butsu, Namu Amida Butsu.

```
+--------------------+  pág 1
|Oh, señor Fuujin,   |
|señor Fuujin...     |
|Nuestro dios        |
+--------------------+
```
```
+--------------------+  pág 2
|protector... Siempre|
|nos vela desde el   |
|cielo... Cuánto     |
+--------------------+
```
```
+--------------------+  pág 3
|se lo agradecemos.  |
|Namu Amida Butsu,   |
|Namu Amida Butsu.   |
+--------------------+
```

### [79]

```
JP: ワシハ / イママデ / ナニヲシテ / シカシ / コウシテ / ブジナノモ / ホトケサマノ / オカゲジャ /  / ナンマンダブ / ナンマンダブ
```

**ES:** ¿Qué he estado haciendo yo hasta ahora...? Pero si sigo sano y salvo es gracias a Buda. Namu Amida Butsu, Namu Amida Butsu.

```
+--------------------+  pág 1
|¿Qué he estado      |
|haciendo yo hasta   |
|ahora...? Pero si   |
|sigo sano y salvo   |
+--------------------+
```
```
+--------------------+  pág 2
|es gracias a Buda.  |
|Namu Amida Butsu,   |
|Namu Amida Butsu.   |
+--------------------+
```


## Castillo de Enma

### [80]

```
JP: モモタロサン / モハヤ / アンタダケガ / タヨリデ / ゴワス… /  / アンタノ / チカラデ / エンマヲ / タオシテ / クダセー… / デ ゴワス
```

**ES:** Momotaro, ya solo podemos confiar en ti... Derrota a Enma con tu fuerza, te lo suplicamos...

```
+--------------------+  pág 1
|Momotaro, ya solo   |
|podemos confiar en  |
|ti... Derrota a Enma|
+--------------------+
```
```
+--------------------+  pág 2
|con tu fuerza, te   |
|lo suplicamos...    |
+--------------------+
```

### [81]

```
JP: ダメダア… / オラ　モウ / タエレネエ… / コンナトコデ / クラシテチャ /  / オカシク / ナッチマウダ
```

**ES:** No puedo más... Ya no lo aguanto... Viviendo en un sitio así uno acaba perdiendo la cabeza.

```
+--------------------+  pág 1
|No puedo más... Ya  |
|no lo aguanto...    |
|Viviendo en un      |
+--------------------+
```
```
+--------------------+  pág 2
|sitio así uno acaba |
|perdiendo la cabeza.|
+--------------------+
```

### [82]

```
JP: モモタロサン / アンタガ / キット / ココマデ / キテクレルト / オモッテタ… / ナガイキハ / スルモンジャ
```

**ES:** Momotaro, sabía que llegarías hasta aquí... Bien vale la pena vivir muchos años.

```
+--------------------+  pág 1
|Momotaro, sabía     |
|que llegarías       |
|hasta aquí...       |
+--------------------+
```
```
+--------------------+  pág 2
|Bien vale la pena   |
|vivir muchos años.  |
+--------------------+
```

### [83]

```
JP: カタナ　オレ / ヤモ　ツキタ /  / エンマハ / オソロシク / ツヨイ… / コレイジョウ / ススンデモ /  / イタズラニ / イノチヲ / ステルダケダ / シニタクナイ / ノナラ /  / サキニハ / ススマンコト / ダナ
```

**ES:** Mi espada se partió y se me acabaron las flechas. Enma es terriblemente fuerte... Si sigues adelante solo perderás la vida en vano. Si no quieres morir, no avances más.

```
+--------------------+  pág 1
|Mi espada se partió |
|y se me acabaron    |
|las flechas. Enma   |
|es terriblemente    |
+--------------------+
```
```
+--------------------+  pág 2
|fuerte... Si        |
|sigues adelante     |
|solo perderás la    |
+--------------------+
```
```
+--------------------+  pág 3
|vida en vano. Si    |
|no quieres morir,   |
|no avances más.     |
+--------------------+
```

### [84]

```
JP: トーチャンハ / エンマニ / ムカッテッテ / ソレッキリ / カエッテ / コナインダ… / オニイチャン / トーチャンノ / カタキヲ… / オネガイダヨ /  /  / ムラノミンナ / ノタメニモ… /  / ガンバッテネ / モモタロウノ / オニイチャン
```

**ES:** Mi padre fue a enfrentarse a Enma y nunca volvió... Momotaro, venga a mi padre... Te lo pido, también por toda la aldea... ¡Mucho ánimo, Momotaro!

```
+--------------------+  pág 1
|Mi padre fue a      |
|enfrentarse a Enma  |
|y nunca volvió...   |
|Momotaro, venga a mi|
+--------------------+
```
```
+--------------------+  pág 2
|padre... Te lo pido,|
|también por toda    |
|la aldea... ¡Mucho  |
|ánimo, Momotaro!    |
+--------------------+
```

### [85]

```
JP: ナガネンノ / ケンキュウノ / ケッカ / エンマノ / ジャクテンハ /  / ヤッパリ / マトジャッタ / 　　　　 / マトハ / クチノナカニ / アル… / ダガ / ソレモ /  / エンマノ / トコロマデ / イケレバダ
```

**ES:** Tras muchos años de estudio, el punto débil de Enma resultó ser, como imaginaba, la diana. La diana está dentro de su boca... Pero eso solo sirve si logras llegar hasta él.

```
+--------------------+  pág 1
|Tras muchos años    |
|de estudio, el      |
|punto débil de      |
|Enma resultó ser,   |
+--------------------+
```
```
+--------------------+  pág 2
|como imaginaba,     |
|la diana. La diana  |
|está dentro de su   |
+--------------------+
```
```
+--------------------+  pág 3
|boca... Pero eso    |
|solo sirve si logras|
|llegar hasta él.    |
+--------------------+
```

### [86]

```
JP: スデニ / ホトンドノ / ムラビトハ / ニゲダシテ / シモタ… /  /  / モモタロウ… /  / ヒトビトノ / キタイハ / オマエニ / アツマッテ / オル… /  / ドウカ / エンマヲ / コラシメ / ヨノナカニ / ヘイワヲ / モタラスノダ / ユケ… / モモタロウ…
```

**ES:** Casi todos los aldeanos han huido ya... Momotaro... Las esperanzas de todos están puestas en ti... Castiga a Enma y trae la paz al mundo. Ve... Momotaro...

```
+--------------------+  pág 1
|Casi todos los      |
|aldeanos han huido  |
|ya... Momotaro...   |
+--------------------+
```
```
+--------------------+  pág 2
|Las esperanzas de   |
|todos están puestas |
|en ti... Castiga    |
+--------------------+
```
```
+--------------------+  pág 3
|a Enma y trae       |
|la paz al mundo.    |
|Ve... Momotaro...   |
+--------------------+
```
