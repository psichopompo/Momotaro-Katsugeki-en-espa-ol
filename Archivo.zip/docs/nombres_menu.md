# Inventario completo del menú SELECT — nombres y espacio

Todos los nombres se dibujan con `$D41C`, **una celda por carácter**.
El límite es el ancho útil de cada panel, medido sobre el state:

| lista | rutina | celda inicial | **ancho útil** |
|---|---|---|---|
| ぶき ARMA | `$D4C3` | X=2, Y=12 | **10** |
| ぼうぐ ARMADURA | `$D4E3` | X=2, Y=17 | **10** |
| どうぐ OBJETOS | `$D55A` | X=14, Y=5 (+2 filas) | **8** |
| じゅつ ARTES | `$D58F` | X=24, Y=5 (+2 filas) | **6** |

Las cadenas se leen **por puntero**, así que se pueden reubicar a un hueco
libre: no estamos atados a los 65 bytes del bloque original. El límite duro
es el ancho de pantalla de la tabla de arriba.

---

## ぶき — ARMAS (7). Ancho 10

| # | ROM | original | literal | propuesta | letras |
|---|---|---|---|---|---|
| 1 | `0x43CB6` | ﾎ゛ｸﾄｳ | bokutou | **ESP. MADERA** ❌ 11 → `MADERA` | 6 |
| 2 | `0x43CBD` | ｶﾀﾅ | katana | `KATANA` | 6 |
| 3 | `0x43CC2` | ﾋ゛ｬｯｺﾉｹﾝ | byakko no ken (Tigre Blanco) | `TIGRE` | 5 |
| 4 | `0x43CCC` | ﾋﾘｭｳﾉｹﾝ | hiryuu no ken (Dragón Volador) | `DRAGON` / `DRAGÓN` | 6 |
| 5 | `0x43CD5` | ｱｼｭﾗﾉｹﾝ | ashura no ken (Asura) | `ASURA` | 5 |
| 6 | `0x43CDE` | ﾎｳｵｳﾉｹﾝ | houou no ken (Fénix) | `FENIX` / `FÉNIX` | 5 |
| 7 | `0x43CE7` | ﾕｳｷﾉｹﾝ | yuuki no ken (Valor) | `VALOR` | 5 |

Idea de David — **quitar «espada de»** y dejar solo el nombre: funciona
perfectamente, todas caben con holgura. En el original 5 de las 7 son
「〜のけん」 (espada de ~), así que el patrón se mantiene coherente.

Alternativa si se quiere marcar que son espadas, cabe en 10:
`E. TIGRE`, `E. DRAGON`, `E. ASURA`, `E. FENIX`, `E. VALOR`, `KATANA`,
`E. MADERA`.

---

## ぼうぐ — ARMADURAS (4). Ancho 10

| # | ROM | original | literal | propuesta | letras |
|---|---|---|---|---|---|
| 1 | `0x43CF7` | ﾀｹﾉﾄ゛ｳ | take no dou (coraza de bambú) | `BAMBU` / `BAMBÚ` | 5 |
| 2 | `0x43CFF` | ｱｶﾄ゛ｳ | aka dou (coraza roja) | `ROJA` | 4 |
| 3 | `0x43D06` | ｻﾂｷﾉﾄ゛ｳ | satsuki no dou | `SATSUKI` | 7 |
| 4 | `0x43D0F` | ﾕｳｷﾉﾄ゛ｳ | yuuki no dou (del Valor) | `VALOR` | 5 |

Mismo criterio: どう = coraza. Cabría `C. BAMBU`, `C. ROJA`, `C. SATSUKI`,
`C. VALOR` (máx. 9).

---

## どうぐ — OBJETOS (11). Ancho 8 ← **el más apretado**

| # | ROM | original | literal | propuesta | letras |
|---|---|---|---|---|---|
| 1 | `0x42F74` | ｶﾗﾀ゛ﾉｵﾆｷ゛ﾘ | karada no onigiri (del cuerpo) | `ONIGIRI` | 7 |
| 2 | `0x42FA3` | ﾜｻ゛ﾉｵﾆｷ゛ﾘ | waza no onigiri (de la técnica) | `ONIGIRI2` ⚠ | 8 |
| 3 | `0x42FD1` | ﾕｷﾉｵﾆｷ゛ﾘ | yuki no onigiri (de nieve) | `O. NIEVE` | 8 |
| 4 | `0x43007` | ｷﾋ゛ﾀ゛ﾝｺ゛ | kibidango | `KIBIDANGO` ❌ 9 → `KIBIDANG` ⚠ | 8 |
| 5 | `0x43113` | ﾓﾓﾌﾚﾎ゛ｳｽ゛ | momofure bouzu | `BONZO` | 5 |
| 6 | `0x43063` | ｵﾅﾗﾉﾓﾄ | onara no moto (polvo de pedos) | `PEDOS` | 5 |
| 7 | `0x4308D` | ﾆﾁﾘﾝﾉﾂﾌ゛ﾃ | nichirin no tsubute (guijarro solar) | `P. SOLAR` | 8 |
| 8 | `0x430B9` | ﾋｮｳｶ゛ﾉﾂﾌ゛ﾃ | hyouga no tsubute (guijarro glaciar) | `P. HIELO` | 8 |
| 9 | `0x430E6` | ｶﾝｼ゛ｷ | kanjiki (raquetas de nieve) | `RAQUETAS` | 8 |
| 10 | `0x43140` | ｶｸﾚﾐﾉ | kakuremino (capa invisible) | `CAPA` | 4 |
| 11 | `0x4316B` | ｶｯﾊ゜ﾉﾐｽ゛ｶｷ | kappa no mizukaki (aletas de kappa) | `ALETAS` | 6 |

**Problema real: los tres onigiri.** Con 8 celdas no se distingue cuál es
cuál. Tres salidas posibles:
- `ONIGIRI` / `ONIGIRI2` / `ONIGIRI3` — feo.
- `O. VIDA` / `O. TECNICA` ❌(10) / `O. NIEVE` — el segundo no cabe.
- **`O. VIDA` / `O. TEC` / `O. NIEVE`** — cabe, y es coherente con los
  rótulos VIDA y TÉCNICA de la columna izquierda. **Es mi recomendación.**

Nota: 1 y 2 restauran VIDA y TÉCNICA respectivamente, así que la referencia
cruzada tiene sentido de juego, no solo de espacio.

---

## じゅつ — ARTES (7). Ancho 6 ← **el más estrecho**

| # | ROM | original | literal | propuesta | letras |
|---|---|---|---|---|---|
| 1 | `0x433E4` | ﾓﾓﾋｴﾝ | momo-hien (golondrina) | `HIEN` / `VUELO` | 5 |
| 2 | `0x4342B` | ﾓﾓｼ゛ｬﾝﾌ゜ | momo-jump | `SALTO` | 5 |
| 3 | `0x4345E` | ﾓﾓｺﾛｺﾛ | momo-korokoro (rodar) | `RODAR` | 5 |
| 4 | `0x43487` | ﾓﾓﾏﾜｼ | momo-mawashi (giro) | `GIRO` | 4 |
| 5 | `0x434B5` | ﾓﾓﾊ゛ｸﾊﾂ | momo-bakuhatsu (explosión) | `BOMBA` | 5 |
| 6 | `0x434DE` | ﾓﾓﾂﾅﾐ | momo-tsunami | `OLEADA` | 6 |
| 7 | `0x43505` | ﾊ゜ﾛﾌ゜ﾝﾃ | (por confirmar) | — | |

Las siete llevan el prefijo モモ (melocotón) en japonés. **Con 6 celdas es
imposible conservarlo**; se pierde inevitablemente, igual que se pierde
「〜のけん」 en las armas. La entrada 7 no lleva モモ y hay que confirmarla
viéndola en el juego.

---

# Resumen de decisiones pendientes

1. **Armas y armaduras**: ¿solo el nombre (`TIGRE`, `BAMBU`) o con prefijo
   (`E. TIGRE`, `C. BAMBU`)? Las dos caben.
2. **Los tres onigiri**: propuesta `O. VIDA` / `O. TEC` / `O. NIEVE`.
3. **`KIBIDANGO` no cabe** (9 en 8). Opciones: `KIBIDANG` (feo),
   `DANGO` (5), o `KIBI` (4).
4. **Arte nº 7** (ﾊ゜ﾛﾌ゜ﾝﾃ): hay que verla en el juego.

---

# ACTUALIZACIÓN — datos de 1up-games (aportado por David)

El artículo de sanjuro (11/01/2013) confirma y **corrige** las mecánicas:

```
karada no onigiri 「からだのオニギリ」   +1 PV
waza   no onigiri 「わざのオニギリ」    +1 PP
yuki   no onigiri 「ユキのオニギリ」    +1 PV +1 PP   <- el MIXTO, no "de nieve"
kibidango         「きびだんご」        +3 PV   (brocheta)
kakure-mino       「かくれみの」        INVENCIBILIDAD (funciona hasta con jefes)
onara no moto     「オナラのもと」       ataca por delante Y por detrás (pedos)
```

**Corrijo dos errores míos de la tabla anterior:**

1. Traduje ﾕｷﾉｵﾆｷ゛ﾘ como «onigiri de nieve» pensando en una zona helada.
   Es el **onigiri mixto**: cura vida Y técnica a la vez. Traducirlo por
   NIEVE habría dado una pista falsa al jugador.
2. Puse ｶｸﾚﾐﾉ como «capa invisible». Es correcto pero incompleto: es
   **invencibilidad**, no sigilo.

También confirma la estructura: SELECT es «un écran de statut purement
informatif» y RUN «le vrai menu de jeu», dividido en dōgu y jutsu.

## Sobre ﾊ゜ﾛﾌ゜ﾝﾃ — la hipótesis de David

David propone que sea un homenaje al **Parupunte** de Dragon Quest, el
hechizo de efecto aleatorio (traducido HOCUS POCUS en inglés). El katakana
encaja: ﾊ゜ﾛﾌ゜ﾝﾃ = *parupunte* con vocales cambiadas.

[HIPÓTESIS no verificada] — hay que verlo en el juego. Si el efecto es
aleatorio, **AZAR** es la mejor opción: neutro, 4 letras, y no promete un
resultado bueno como haría SUERTE.

## Las tres cuestiones del onigiri de técnica

Espacio: 8 celdas. El problema es nombrar «lo que repone técnica» sin
sonar místico y sin perder la idea de comida.

Descartadas por medición o por sentido:
- `O. TECNICA` — 10 letras, no cabe.
- `ENERGIA` (7) — cabe, pero se asocia a vida, no a técnica.
- `MANJAR` / `BOCADO` / `RACION` — genéricos, no dicen qué reponen.

Opciones que caben y distinguen los tres:

| | +1 PV | +1 PP | +1 PV +1 PP |
|---|---|---|---|
| A | `ONIGIRI` | `O. TECNICA` ❌ | `BANQUETE` |
| B | `ONIGIRI` | `ONIGIRI T` ❌ | `BANQUETE` |
| **C** | **`ONIGIRI`** | **`RIKI`** ⚠ | **`BANQUETE`** |
| **D** | **`ONIGIRI`** | **`DESTREZA`** (8) | **`BANQUETE`** |
| **E** | **`ONIGIRI`** | **`PULSO`** (5) | **`BANQUETE`** |

`DESTREZA` cabe justo en 8 y es sinónimo directo de 技 (waza).
`PULSO` es corto y evoca firmeza de mano sin misticismo.
