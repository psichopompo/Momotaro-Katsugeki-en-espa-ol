# Menú RUN — destinos, verbos y mensajes sueltos

---

## 0. Lo que ya está traducido (comprobado, no supuesto)

David avisó: *«sólo has buscado lo relacionado con el arte de vuelo, pero
hay muchas otras artes»*. Comprobado — y la buena noticia es que **las
acciones de las seis artes ya están traducidas** desde una tanda
anterior, repuntadas a `0x434B5`-`0x43505`:

| ROM | ES | japonés original |
|---|---|---|
| `04342B` | `Rodar` | ジャンプ |
| `04345E` | `Salto` | コロコロ |
| `043487` | `Azar` | マワシ |
| `0434B5` | `Vuelo` | バクハツ |
| `0434DE` | `Giro` | ツナミ |
| `043505` | `Oleada` | パロプンテ |

Lo que falta es **el texto que las rodea**, no las artes en sí.

---

## 1. La línea del ermitaño — sustitución dinámica

`0x4AE18`, 35 B, rejilla 2×16. Lleva un **marcador `$00`**:

```
キンモツヂャ! \ウヒャヒャ!  ワシハ <<TÉCNICA>>センニンヂャ!
= «¡prohibido! ¡ujujú! yo soy el ermitaño <<TÉCNICA>>»
```

El `$00` es donde el motor **inserta el nombre de la técnica**. Por eso
salía «Vuelo» incrustado en japonés.

La L2 tiene que dejar sitio a un nombre de hasta 9 caracteres
(`Parapunte`). Con 16 columnas:

```
         1234567890123456
ES  L1  |¡Nada de eso!   |  13
ES  L2  |Soy <<T>>.      |  con T=9 -> 14   ✓
```

> Corregido: en la versión anterior escribí `Soy <<T>> ermitaño` y
> `Ermitaño <<T>>` **sin punto final**. Con `Soy <<T>>.` cabe el punto
> incluso con el nombre más largo.

---

## 2. Los destinos — DOS listas, y la ventana mide 8 celdas

```
A)  0x43737..0x4379D  102 B  tabla 0x43712  -> el MENÚ de destinos
B)  0x437B1..0x4380A   89 B  tabla 0x4379D  -> el rótulo AL VIAJAR
    lector $ADA1: LDA $3B0E / ASL / TAX / LDA $B79D,X
```

[HECHO] **La ventana mide 8 celdas exactas.** La lista B centra con
espacios y todas sus entradas dan 8 justas — ese es el ancho real.

### Las dos tablas pueden COMPARTIR cadenas

La tabla A ya lo hace: sus entradas `[0]` y `[3]` apuntan las dos a
`$B72E`. O sea que el motor no exige cadenas distintas. Si las dos
tablas apuntan a las mismas 10 cadenas, **el coste se parte por dos**:

```
presupuesto conjunto            191 B
10 cadenas compartidas          103 B   -> caben, sobran 88 B
```

Con eso **no hacen falta abreviaturas por bytes**. El único límite que
queda es el ancho de 8 celdas.

### Propuesta

| # | japonés | significado | propuesta | celdas |
|---|---|---|---|---|
| 0 | `タビダチノ村` | de la partida | `Partida` | 7 |
| 1 | `ハナサカノ村` | hanasaka, el que hace florecer | `Florecer` | 8 |
| 2 | `キンタロウノ村` | Kintaro | `Kintaro` | 7 |
| 3 | `ネタロウノ村` | netarou, el dormilón | `Dormilón` | 8 |
| 4 | `ウラシマノ村` | Urashima | `Urashima` | 8 |
| 5 | `カチカチヤマノ村` | Kachikachiyama | `Kachiyama` | 9 ⚠ |
| 6 | `イッスンボウシ村` | Issunboshi | `Issunboshi` | 10 ⚠ |
| 7 | `タケトリノ村` | taketori, cortador de bambú | `Bambú` | 5 |
| 8 | `オニガシマ` | isla de los ogros | `Isla Ogros` | 10 ⚠ |
| 9 | `サイゴノジゾウ` | el último Jizo | `Último Jizo` | 11 ⚠ |

> **Corregido:** «Inicial» → **`Partida`**. David: *«se llama Aldea de la
> Partida, así que lo lógico sería llamarla Partida»*. Tiene razón, y
> además `tabidachi` es literalmente «partida, ponerse en camino».
>
> **Corregido:** «Jizo fin» estaba mal — David: *«no es lo mismo último
> que fin»*. Cierto.

### Los cuatro que pasan de 8 celdas

| nombre | celdas | alternativas de ≤8, sin abreviar |
|---|---|---|
| `Kachiyama` | 9 | `Kachi` (5) · `Montaña` (7) |
| `Issunboshi` | 10 | `Issun` (5) · `Enanito` (7) · `Pulgarci` (8) |
| `Isla Ogros` | 10 | `Ogros` (5) · `Demonios` (8) |
| `Último Jizo` | 11 | `Jizo` (4) · `Ultimo` (6, sin tilde) |

> Ninguna es abreviatura con punto: son palabras enteras más cortas.
> `Kachi`, `Issun` y `Jizo` conservan el nombre propio recortado, que es
> lo que hace el propio japonés al decir `イッスンボウシ村` sin el `ノ`.

---

## 3. «Usar» y «Dejar»

```
0x43737  ツカウ  (tsukau) = USAR    hueco 5 B
0x4373C  ヤメル  (yameru) = DEJAR   hueco 5 B
```

Con el repunteo entran en los 88 B sobrantes, así que caben enteros:
`Usar` (4) y `Dejar` (5).

---

## 4. Cinco mensajes sueltos, también sin traducir

Aparecieron al barrer el banco `$21` entero. Cada uno tiene su hueco
propio hasta el `$00`:

| ROM | B | celdas | japonés | significado | propuesta |
|---|---|---|---|---|---|
| `0435E6` | 4 | 4 | セレクト | SELECT | `SELECT` ⚠ 6 |
| `04363D` | 5 | 4 | タベタイ | «quiero comer» | `Comer` ⚠ 5 |
| `04366B` | 7 | 7 | カタナ ツヨク | espada más fuerte | `Espada+` |
| `04369C` | 9 | 7 | ボウグ ツヨク | armadura más fuerte | `Armadura+` ⚠ |
| `0436CC` | 10 | 8 | ダレニモ\マケナイ | «invencible» | `Invencible` ⚠ |

> Estos van por libre, sin tabla localizada todavía. Pendiente de
> comprobar si son repuntables antes de decidir los textos.

---

## 5. [DESCARTADO] Hueco libre en el banco `$21`

Los punteros de destino van en ventana `$A000` = **MPR5**, que en el
savestate lleva el banco `$21`. El lector no cambia de banco: solo hace
`LDA $B79D,X`. Así que el texto **tiene que quedarse en el banco `$21`**.

```
hueco de $FF en el banco $21:  0 B
```

Y los «98 B libres» que encontré antes en `0x42000..0x420D9` **no son
relleno**: es una tabla de datos con ceros entremezclados
(`05 00 00 00 00 02 00 03`), y empieza en el primer byte del banco.
Ya costó una versión dar ceros por libres (norma 232).

**La solución no es buscar hueco: es compartir cadenas entre las dos
tablas**, que libera 88 B dentro del propio banco.