# Estado a fecha de hoy — partir de la v157, NO de la v172

**Punto de partida bueno: `roms/test_horizontal_v157.pce`**
MD5 `294f0c20ef190860391267c330007dad`

**Última versión: `roms/momotaro_es_v177.pce`**
MD5 `5537a1e0f32ad33098559af2ebea2301` · parche `parches/momotaro_v177.ips`

---

## Por qué se abandonó la v172/v173

Se intentó arreglar durante cinco entregas y cada una destapaba un fallo
nuevo. La regla que acordamos en Nekketsu — **no parchear parches, volver al
último estado correcto** — se aplicó tarde. Lo que la v173 tenía bien (guion
traducido y diccionario) **no se pierde**: está guardado en
`v173/momotaro_es_v173.pce` y entra en pasos posteriores, como piezas
sueltas y verificadas una a una.

Su fallo de fondo: el motor escribía en unas celdas y los sprites mostraban
otras. Solo coincidían 3 de 20.

---

## Lo que hace la v177 sobre la v157

Bocadillo **apaisado de 12 caracteres × 2 líneas**.

```
dY+24  esqSI@-58 bordS@-26 bordS@-10 bordS@6 bordS@22 esqSD@38
dY+40  latI@-58  rell@-55 rell@-39 rell@-23 rell@-7 rell@9 rell@25  latD@41
dY+56  esqII@-58 bordI@-26 bordI@-10 bordI@6 bordI@22 esqID@38
```

- tablas y contadores: de 6×6 a 12×2
- lista de sprites movida al banco `$23` (`ROM 0x47C02`), porque en `$9AA0`
  solo caben 12 y hacen falta 20
- índice de celda: quitado el `+6` heredado del bocadillo vertical
- píxel (1,14) de la esquina `19C`: negro → blanco
- **no toca** fuente, guion, CG del texto ni la tabla del rabillo

---

## Las siete reglas duras del bocadillo (todas medidas)

1. **El motor escribe el glifo en el PLANO 3** de la celda (+48 words). Un
   destino con resto 0 pinta bloques de color, no letras.
2. **Solo `1A6`-`1AB` son relleno puro** (6 celdas). `1A0/1A2/1A4` son el
   lateral izquierdo y `1A1/1A3/1A5` el derecho: **traen el trazo dibujado**,
   así que puestas en medio meten una raya vertical.
3. **El lateral izquierdo solo dibuja 3 px**; las otras 13 columnas son
   transparentes. Por eso el relleno arranca en `+3` y no en `+16`.
4. **Un sprite de 32 px redondea su celda a par**: el VDC ignora el bit 0 del
   patrón. Para usar una celda impar (`19D`, `19F`) el sprite debe ser de 16.
5. **`dX` y `dY` son de 8 bits con signo** (−128..+127). Un bocadillo ancho
   hay que centrarlo en el ancla.
6. **El rabillo NO va en la lista**: lo emite `$9A78` aparte, eligiendo una
   de las 4 variantes de `$9ADD` según `$368F`. Hay tres legítimos (abajo-izq,
   abajo-der y lateral, este último para el bocadillo del abuelo).
7. **`1B0` no es una flecha**: era la tercera fila de relleno del bocadillo
   vertical. En el apaisado sobra.

---

## Lo siguiente

1. **Subir a 4 líneas.** Solo hay 6 celdas de relleno puro, así que hace
   falta **ampliar el CG**: el cargador está en `$9C32`, la cuenta de tiles
   en `ROM 0x3D400` (hoy 20) y el destino es `$6700` = celda `0x19C`.
2. Meter el guion traducido de la v173.
3. Meter el diccionario y su descompresor (`$793B`, banco `$25`).
4. Rabillo simétrico: está en `ROM 0x5292`, 46 B comprimidos.
5. Traducir vítores, dinero, final, quiz y casino.

Cada paso, **una sola cosa**, con `assert` de que no se toca nada fuera de
su zona.
