# Japonés pendiente en el banco $21 (ROM v269)

> **AVISO 1:** no existe ROM de trabajo para leer esto en pantalla. Se
> intento restaurar la fuente japonesa y no funciono (norma 228).
>
> **AVISO 2:** este listado se hizo ANTES de descubrir que el menu RUN vive
> en el banco `$0C` (no en el `$21`). Puede contener cadenas que no se ven
> nunca en pantalla. Verificar antes de traducir.

| ROM | CPU | Bytes | Katakana | Romaji | Traducción |
|---|---|---|---|---|---|
| `0x433CC` | `$B3CC` | 5 | ﾂｶｳ | tsukau | |
| `0x433D1` | `$B3D1` | 5 | ﾔﾒﾙ | yameru | |
| `0x43586` | `$B586` | 39 | [3B][4A]ｰﾁ[4C][06]ｮ[EE]ｸ[3B][82]ｩﾑ[4C]ﾚ[80][60]ｦｵｭｵｷｵﾏｵｰｵｴｵｶｵ[02]ｽｸﾛ[5F]ﾙ | [3B][4A]-chi[4C][06yo[EE]ku[3B][82]ｩmu[4C]re[80][60]woyuokiomao-oeokao[02]sukuro[5F]ru | |
| `0x435E1` | `$B5E1` | 10 | ﾒﾝ[3C][5C]ｾﾚｸﾄ | men[3C][5C]serekuto | |
| `0x4360C` | `$B60C` | 11 | ｼﾞｭﾂ ﾎｼｲ  | jyutsu hoshii  | |
| `0x43639` | `$B639` | 10 | ﾓﾓ[3C]ﾀﾍﾞﾀｲ | momo[3C]tabetai | |
| `0x4366A` | `$B66A` | 9 | ｶﾀﾅ ﾂﾖｸ | katana tsuyoku | |
| `0x43686` | `$B686` | 32 | [02][03][04][05][06][07][9B]ｶｦｶｰｶｸｶｩｶｭｶｯｶ[01]ﾎﾞｳｸﾞ ﾂﾖｸ | [02][03][04][05][06][07][9B]kawoka-kakukaｩkyukaka[01]bougu tsuyoku | |
| `0x436B9` | `$B6B9` | 30 | [02][03][04]ﾋｶﾗｶ[E1]ｶ[E7]ｶﾚｶﾞｶ[E0]ｶ[01]ﾀﾞﾚﾆﾓ[5C]ﾏｹﾅｲ | [02][03][04]hikaraka[E1]ka[E7]karegaka[E0]ka[01]darenimo[5C]makenai | |
| `0x436F9` | `$B6F9` | 11 | ﾄﾞｳｸﾞ ﾎｼｲ | dougu hoshii | |
| `0x4372E` | `$B72E` | 8 | ﾂｶｴﾏｾﾝ | tsukaemasen | |
| `0x43736` | `$B736` | 5 | ﾂｶｳ | tsukau | |
| `0x4373B` | `$B73B` | 5 | ﾔﾒﾙ | yameru | |
| `0x43740` | `$B740` | 10 | ﾀﾋﾞﾀﾞﾁﾉ[64] | tabidachino[64] | |
| `0x4374A` | `$B74A` | 8 | ﾊﾅｻｶﾉ[64] | hanasakano[64] | |
| `0x43752` | `$B752` | 9 | ｷﾝﾀﾛｳﾉ[64] | kintarouno[64] | |
| `0x4375B` | `$B75B` | 8 | ﾈﾀﾛｳﾉ[64] | netarouno[64] | |
| `0x43763` | `$B763` | 8 | ｳﾗｼﾏﾉ[64] | urashimano[64] | |
| `0x43776` | `$B776` | 11 | ｲｯｽﾝﾎﾞｳｼ[64] | isunboushi[64] | |
| `0x43781` | `$B781` | 8 | ﾀｹﾄﾘﾉ[64] | taketorino[64] | |
| `0x43789` | `$B789` | 8 | ｵﾆｶﾞｼﾏ | onigashima | |
| `0x43791` | `$B791` | 12 | ｻｲｺﾞﾉｼﾞｿﾞｳ | saigonojizou | |
| `0x437AF` | `$B7AF` | 12 |  ﾀﾋﾞﾀﾞﾁﾉ[64]  |  tabidachino[64]  | |
| `0x437BB` | `$B7BB` | 10 |  ﾊﾅｻｶﾉ[64]  |  hanasakano[64]  | |
| `0x437C5` | `$B7C5` | 9 | ｷﾝﾀﾛｳﾉ[64] | kintarouno[64] | |
| `0x437CE` | `$B7CE` | 10 |  ﾈﾀﾛｳﾉ[64]  |  netarouno[64]  | |
| `0x437D8` | `$B7D8` | 10 |  ｳﾗｼﾏﾉ[64]  |  urashimano[64]  | |
| `0x437ED` | `$B7ED` | 11 | ｲｯｽﾝﾎﾞｳｼ[64] | isunboushi[64] | |
| `0x437F8` | `$B7F8` | 10 |  ﾀｹﾄﾘﾉ[64]  |  taketorino[64]  | |
| `0x43802` | `$B802` | 11 |  ｵﾆｶﾞｼﾏ   |  onigashima   | |
