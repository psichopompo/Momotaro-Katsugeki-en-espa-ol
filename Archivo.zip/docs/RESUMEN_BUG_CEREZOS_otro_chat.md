# Resumen — Bug del cuadrado en los cerezos (vítores)

Documento para el chat original. Todo lo que se ha hecho, lo descubierto, los
errores y los aciertos, para poder atacar el problema por más frentes.

---

## 1. El síntoma

En la escena de los vítores (tras eliminar al primer jefe), sobre la copa de
cada cerezo aparece un **cuadrado** con colores del tronco (verde/naranja/
marrón, paleta de fondo 2) incrustado en las flores. La versión japonesa sale
limpia; solo la traducción lo muestra.

## 2. Cómo se ha reproducido

Clave: el savestate **«pre-vítores»** de David (justo tras eliminar al primer
jefe). Mismo estado cargado en ROM JP y en ROM ES, frame 660:

- **JP**: copas limpias.
- **ES**: el cuadrado incrustado.

Esto prueba que el bug lo introduce la traducción, no el juego original.

## 3. La causa raíz (medida, no supuesta)

### El árbol es un bloque raw contiguo

El gráfico del cerezo son los tiles de fondo `$2B6-$2E0` (43 tiles = 1376 B),
que se copian **en bruto** desde **ROM `0x4900-0x4E5F`** (banco `$02`) a VRAM.
Verificado tile a tile: los 43 tiles de VRAM == ROM `0x4900-0x4E5F` byte a byte.

El cargador es un `TIA $4000,$0002,$2000` en **ROM `0x0391B`** (CPU `$F91B`,
banco `$00`): vuelca 8 KB de tiles de fondo del nivel, y el árbol cae dentro de
ese volcado. No hay cargador "del árbol" dedicado.

### La traducción metió datos DENTRO del bloque

El diff JP↔ES en ese bloque (209 bytes) cae en 3 tramos exactos:

| ROM | tiles afectados | qué hay ahora (ES) |
|---|---|---|
| `0x4920-0x496F` | `$2B7-$2B9` | glifos Á É Í Ó Ú de la fuente del MENÚ |
| `0x4B0F-0x4B53` | `$2C6-$2C8` | datos de sprite + copia del stream del rabillo |
| `0x4C07-0x4C75` | `$2CE-$2D1` | datos de sprite |

### El gancho que delata al autor

La traducción **añadió código** en hueco libre **`0x1DFAE`** (banco `$0E`, que
en JP es todo `$FF`) y lo enganchó en **`$D955`** (ROM `0x1D955`), donde el
original hacía `JSR $BAE2`. El nuevo código `$DFAE`:

```
DFAE: LDA #$02  ADC $20  TAM #$04      ; mapea banco $02
      STZ $3126  LDA #$7B STA $3127    ; MAWR = $7B00
      LDA #$07 STA $14  LDA #$4C STA $15   ; src = $4C07
      JSR $F1B9                          ; copia 4 bytes
      STZ $3126  LDA #$7E STA $3127    ; MAWR = $7E00
      LDA #$0F STA $14  LDA #$4B STA $15   ; src = $4B0F
      JSR $F1B9                          ; copia 2 bytes
      JMP $BAE2                          ; encadena lo que $D955 hacía antes
```

Además `$D955` cambió `LDY #$18` → `LDY #$24`.

**Interpretación**: la traducción necesitó datos de sprite y los guardó en
`0x4B0F` y `0x4C07`, que están DENTRO del bloque del árbol, creyendo que era
hueco libre. Igual que hizo con los glifos del menú en `0x4920`. Las dos cosas
pisan el árbol.

### Cronología (bisección con milestones v334/v338/v378/v385/v386)

| versión | tiles corruptos | causa añadida |
|---|---|---|
| v334 / v338 | 7 (`$2C6-$2C8`, `$2CE-$2D1`) | datos de sprite (pre-v334) |
| v378 | 9 (+`$2B8-$2B9`) | — |
| v385 / v386 | 10 (+`$2B7`) | glifos del menú (v379) |

El cuadrado **visible** ya está en v334. La v379 solo rompió `$2B7-$2B9`, que
quedan tapados por la copa (no cambian la imagen).

## 4. Errores cometidos y corregidos

1. **«El cuadrado es un artefacto del juego japonés»** → FALSA. David informó
   que JP sale limpio; con el savestate pre-vítores se confirmó que el bug es
   de la ROM ES.
2. **«La v379 (Á del menú) causó el bug»** → FALSA. Los tiles visibles ya
   estaban corruptos en v334. La v379 solo añadió `$2B7-$2B9`.
3. **«La traducción no tocó CG»** → FALSA. El diff muestra cambios en
   `0x7F8F2..0x7FE85` (CG comprimido del banco `$3F`).
4. **«Los tramos pre-v334 eran glifos 0xE0+/0xF0+ de la fuente»** → FALSA.
   Son datos de sprite y una copia del stream del rabillo (`0x5290`).
5. **«El árbol se carga por stream comprimido CG con el puntero desplazado»**
   → FALSA. Es un bloque raw, sin compresión.
6. **Primer cargador con fuente `$49xx`** (ROM `0x42C9A`) → era el de sprites,
   no el del árbol.

## 5. Datos técnicos clave (para otros frentes)

- **Bloque del árbol**: ROM `0x4900-0x4E5F` → VRAM tiles `$2B6-$2E0`.
- **Cargador**: `TIA $4000,$0002,$2000` en ROM `0x0391B` (CPU `$F91B`).
- **Gancho de la traducción**: `0x1DFAE` (añadido), llamado desde `$D955`
  (ROM `0x1D955`), que copia `$4C07`→VRAM `$7B00` y `$4B0F`→VRAM `$7E00`.
- **Glifos del menú**: fuente en `0x4000`, stride 16, fórmula
  `0x4000+(byte-0x30)*16`. Códigos `$C2-$C8` (ÁÉÍÓÚÜÑ) → `0x4920-0x498F`.
- **Stream del rabillo**: `0x5290` (46 B comprimidos), duplicado en `0x4B24`.
- **Espacio libre en banco $02**: NO hay (solo huecos sueltos de `$00` de
  8-21 bytes). No cabe ni el árbol ni los glifos contiguos.

## 6. Opciones de arreglo (decisión pendiente de David)

1. **Mover el árbol**: copiar ROM `0x4900-0x4E5F` a hueco libre de otro banco
   y repuntar el cargador.
2. **Mover los glifos del menú**: darle al renderer del menú una tabla de
   remapeo (como la `0x43F9B` del diálogo) para sacar `$C2-$C8` de `0x4920`.
3. **Mover los datos de sprite** (`0x4B0F`/`0x4C07`) y repuntar `$DFAE`
   (lo pequeño; por sí solo no basta).
