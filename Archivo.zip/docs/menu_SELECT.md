# Menú SELECT — anatomía completa

Estado: **analizado y medido**. Nada parcheado todavía.

## 0. Rectificación

En la sesión anterior dije que el state de David *«no tenía el menú abierto»*.
**Era falso.** Miré el SATB, vi 18 sprites (Momotaro, perro, mono, faisán) y
concluí que faltaba el menú. El fallo de razonamiento: di por hecho que el
menú de SELECT sería de sprites **porque el de RUN lo es** — exactamente lo
que prohíbe la norma 15 (lo medido en un sitio no vale para el otro).

El menú de SELECT **es FONDO (BAT)**. Por eso el Sprite Viewer de Mesen sale
casi vacío en las capturas de David, y por eso David tenía razón al decir
*«el state sí tiene abierto el menú»*.

**Norma 73. Antes de decir que un state "no tiene" algo, renderizar el FONDO,
no solo los sprites.**

## 1. Parámetros de pantalla [HECHO]

```
BAT en $0000 (NO $0800 como el menú RUN), 64x32 celdas, MWR=$0050
BXR = 0, BYR = 0
área visible del menú: 32 x 22 celdas
```

Renderizado con `tools/render_bg.py` → `capturas/select_bg.png`, que
reproduce la captura de David píxel a píxel.

## 2. Dos clases de celda, y solo una es texto [HECHO]

| rango de patrón | qué es | cómo se traduce |
|---|---|---|
| `$100 – $15F` | **gráficos del menú**: marco de madera, recuadros, y los **rótulos japoneses dibujados a mano** (体力, 技, 金, ぶき, ぼうぐ, どうぐ, じゅつ) | editando el CG en la ROM (comprimido) |
| `$200 – $2FF` | **fuente**, un patrón por código de carácter | reescribiendo las cadenas de texto |

Verificado carácter a carácter: `patrón = $200 + código`.

## 3. Cómo se sube la fuente al CG [HECHO]

Rutina `$D35E` (ROM `0x1B35E`, banco `$0D`), tres tandas:

```
$D39B   ST2 #$22 -> CG $2200 = patrón $220   códigos $30..$5F   fuente MENÚ  (banco $02, ROM 0x4000, 16 B/glifo)
$D380   ST2 #$2A -> CG $2A00 = patrón $2A0   códigos $A0..$DF   ruta ALTA, $3BA6=0 -> tabla $9CF3 (ROM 0x41CF3)
$D398   ST2 #$26 -> CG $2600 = patrón $260   códigos $A0..$DF   ruta ALTA, $3BA6=1 -> tabla $9CB3 (ROM 0x41CB3)
```

El bucle es `$D3B3`: `LDA #$A0 / JSR $AAB4 / JSR $D3F0 / INC A / CMP #$E0`.
Es decir, **el menú usa las mismas tablas y las mismas dos fuentes que los
diálogos**. Comprobación cruzada contra la v144:

```
tabla $9CF3 -> fuente DIÁLOGO 0x3D660 : 63/64 tiles coinciden con el CG del state
tabla $9CB3 -> fuente DIÁLOGO 0x3D660 : 63/64 tiles coinciden
   (la misma ROM japonesa da 1/64 — porque el state es de la traducción)
```

**Consecuencia práctica: todo el trabajo ya hecho sobre las fuentes (tildes,
Ñ, línea base de las mayúsculas, v139/v142/v143) ya está funcionando dentro
del menú SELECT.** No hay nada que rehacer ahí.

## 4. El motor de texto del menú [HECHO]

Distinto del de los diálogos (`$D174`). Es `$D41C` (ROM `0x1B41C`):

```
$D41C  STZ $3BA6              fuente 0 por defecto
$D41F  LDY #$01
$D421  JSR $D4A3              ¿byte de control?
$D424  BCS $D43A              sí -> no dibuja, solo avanza
$D426  JSR $D443              programa MAWR con $16/$17 (posición en la BAT)
$D429  JSR $D48D              traduce el byte a patrón
$D42C  TAX / BEQ $D442        $00 = FIN de la cadena
$D42F  STA $0002 / ST2 #$02   escribe la palabra de BAT
$D434  INC $16                avanza una celda a la derecha
$D43A  INC $BF                siguiente byte del texto
$D440  BRA $D421
```

Bytes de control (`$D4A3`):

| byte | efecto |
|---|---|
| `$01` | fuente 0 (`$3BA6 = 0`) |
| `$02` | fuente 1 (`$3BA6 = 1`) |
| `$5C` | **alterna** de fuente (`EOR #$01`) |
| `$00` | fin de cadena |
| `$DE` / `$DF` | dakuten / handakuten: **retroceden una celda** y escriben en la fila de ARRIBA (`$16 - $40`, una fila de 64 celdas) |

Conversión byte → patrón (`$D48D`):

```
si byte >= $40 (o $3BA6 != 0):  patrón_bajo = byte - $40   ; +$200 lo pone el ST2
```

## 5. Dónde están las cadenas [HECHO]

Dos tablas de punteros en el banco `$1C`:

```
$BCA8 = ROM 0x43CA8   ARMAS      índice en $39B8   (7 entradas: 0x43CB6..0x43CE7)
$BCEF = ROM 0x43CEF   ARMADURAS  índice en $39B9   (4 entradas: 0x43CF7..0x43D0F)
```

Contenido en claro (kana en el juego de códigos del menú), terminador `$00`:

```
0x43CB6  01 DE B8 C4 B3 00
0x43CBD  01 B6 C0 C5 00
0x43CC2  01 CB DE AC AF BA C9 B9 DD 00
0x43CCC  01 CB D8 AD B3 C9 B9 DD 00
0x43CD5  01 B1 BC AD D7 C9 B9 DD 00
0x43CDE  01 CE B3 B5 B3 C9 B9 DD 00
0x43CE7  01 D5 B3 B7 C9 B9 DD 00
0x43CF7  01 C0 B9 C9 C4 DE B3 00
0x43CFF  01 B1 B6 C4 DE B3 00
0x43D06  01 BB C2 B7 C9 C4 DE B3 00
0x43D0F  01 D5 B3 B7 C9 C4 DE B3 00
```

Todas empiezan con el control `$01` (fuente 0). Son las líneas que se ven
bajo ぶき y ぼうぐ. Los objetos (どうぐ) y las técnicas (じゅつ) salen de
otra parte — pendiente de localizar, es la lista de inventario.

## 6. El CG del menú: comprimido, y ya sé descomprimirlo [HECHO]

Los 96 tiles del menú (`$100..$15F`) viven **comprimidos** en:

```
ROM 0x7F8F2 .. 0x7FE85   = 1427 bytes comprimidos -> 96 tiles (3072 B)
```

Verificado: **96/96 tiles idénticos** al CG del state.

El descompresor es `$C1CC`/`$C206` (banco `$0C`, ROM `0x181CC`), transcrito
en `tools/descomp_cg.py`. Formato, por plano de 8 filas:

```
un byte de MAPA de 8 bits, de MSB a LSB:
   bit 1 -> leer un byte literal y escribirlo
   bit 0 -> repetir el ÚLTIMO literal leído   (no es "escribir cero")
```

Cada tile son cuatro planos así, entrelazados con paso 2 en el buffer `$393A`
y volcados con `TIA $393A, $0002, $0020`.

`comprime()` es el inverso exacto: **round-trip byte a byte idéntico** sobre
los 1427 bytes originales.

Espacio: tras el bloque quedan **379 bytes libres** hasta el final de la ROM
(`0x80000`). Como los rótulos nuevos serán letras latinas (más simples que
los kanji), lo esperable es que el bloque recomprimido **encoja**, no que
crezca. Se medirá antes de escribir nada.

## 7. Los rótulos a traducir, medidos en pantalla [HECHO]

| rótulo | significado | posición (px) | tamaño |
|---|---|---|---|
| 体力 | vitalidad / vida | x=16 y=22 | 24 x 12 |
| 技 | técnica | x=16 y=38 | 12 x 12 |
| 金 | dinero | x=16 y=54 | 12 x 12 |
| ぶき | arma | x=16 y=78 | 20 x 12 |
| ぼうぐ | armadura | x=16 y=118 | 28 x 12 |
| どうぐ | objetos | x=113 y=22 | 28 x 12 |
| じゅつ | técnicas (magia) | x=194 y=22 | 28 x 12 |

Ancho útil de cada recuadro (medido sobre el gris del panel):

```
panel izquierdo superior   x = 24 .. 100    (77 px)
panel central (どうぐ)      x = 107 .. 180   (74 px)
panel derecho (じゅつ)      x = 187 .. 243   (57 px)
```

Los rótulos ocupan **12 px de alto**, no 16: no están alineados a la rejilla
de 8 px, cabalgan dos filas de celdas. Al reescribirlos hay que respetar eso
o recolocar las celdas (norma 48).

## 8. Lo que falta

1. Decidir los textos castellanos de los siete rótulos (David).
2. Dibujar los glifos (David edita, yo doy la lámina y monto los tiles).
3. Localizar la lista de OBJETOS y de TÉCNICAS (どうぐ / じゅつ).
4. Traducir las 11 cadenas de armas y armaduras de `0x43CB6`.

## Archivos

```
tools/render_bg.py        renderizador de fondo desde un volcado de VRAM
tools/descomp_cg.py       descompresor y compresor del CG (validados)
capturas/select_bg.png              el menú tal cual, reproducido
capturas/select_texto_vs_grafico.png  en verde, lo que es fuente
capturas/select_rotulos_medidos.png   los siete rótulos, recortados y medidos
capturas/select_celdas.png            cada celda con su número de patrón
docs/cg_select_offs.json  offset comprimido de cada uno de los 96 tiles
```

---

# 9. La BAT del menú, también resuelta [HECHO]

`$D34F/$E61E` carga la BAT desde `$7C00` del banco `$3E` = **ROM `0x1E7EA`**,
comprimida con un RLE distinto del CG:

```
FF <cnt> <val>   ->  repite <val> (cnt+1) veces
<b>              ->  literal
```

22 filas de **32** celdas (no 64) = 704 bytes de índice de patrón bajo, en
510 bytes comprimidos (`0x1E7EA..0x1E9E8`). Transcrito en `tools/rle_bat.py`,
**round-trip byte a byte exacto**.

Descomprime idéntico al state salvo las celdas que el juego sobreescribe
después con texto dinámico: las cifras y los nombres de arma y armadura.
Eso confirma que el fondo es estático y las cifras se pintan encima.

## [RECTIFICADO — ver más abajo] "NO hace falta tocar el CG comprimido"

Los rótulos se pueden escribir **como texto normal**, poniendo en la BAT
patrones `$200 + código`, exactamente igual que hace el juego con los
números. La fuente ya está subida al CG y ya lleva nuestras tildes y la Ñ.

Ventajas frente a redibujar los kanji:
- no se toca el bloque comprimido de 1427 B ni su margen de 379 B;
- David no tiene que dibujar nada;
- se puede cambiar el texto en un minuto si no convence.

# 10. Espacio real disponible [HECHO]

Las cifras se imprimen en **columna 10 fija**, una sola cifra:

```
$D5EE   LDX #$0A / LDY #$03   vitalidad -> celda (10,3)
$D605   LDX #$0A / LDY #$05   técnica   -> celda (10,5)
$D5D1   dinero, 6 dígitos desde la columna 6, fila 7
```

Por tanto, para cada rótulo hay:

| rótulo | celdas libres | caracteres |
|---|---|---|
| 体力 (fila 3) | col 2..9 | **8** |
| 技 (fila 5) | col 2..9 | **8** |
| 金 (fila 7) | col 2..5 | **4** (el dinero empieza en la 6) |
| ぶき (fila 10) | col 2..11 | **10** |
| ぼうぐ (fila 15) | col 2..11 | **10** |
| どうぐ (fila 3, panel centro) | col 14..21 | **8** |
| じゅつ (fila 3, panel derecho) | col 24..29 | **6** |

Simulado y comprobado en `capturas/select_sim_B_larga.png`: entran
VIDA / TEC / ORO / ARMA / DEFENSA / OBJETOS / MAGIA sin tocar el marco.

Nota: el hueco de 金 solo admite 4 letras porque el importe ocupa desde la
columna 6. «ORO» y «DIN» caben; «DINERO» no, salvo que se mueva el importe.

---

# 11. Contenido de las listas [HECHO]

Cadena de punteros: `$D58F` -> `$AE6B`/`$AF24` -> tabla `$AF4C` (ROM `0x42F4C`,
banco `$21`). Cada entrada apunta a un registro cuyo primer word es el
puntero al nombre.

## じゅつ — las 7 entradas (bitmask en `$3C11`) [CORREGIDO]

| # | ROM | katakana | literal | propuesta |
|---|---|---|---|---|
| 1 | `0x42F74` | ｶﾗﾀ゛ﾉｵﾆｷ゛ﾘ | karada no onigiri | onigiri del cuerpo |
| 2 | `0x42FA3` | ﾜｻ゛ﾉｵﾆｷ゛ﾘ | waza no onigiri | onigiri de la técnica |
| 3 | `0x42FD1` | ﾕｷﾉｵﾆｷ゛ﾘ | yuki no onigiri | onigiri de nieve |
| 4 | `0x43007` | ｷﾋ゛ﾀ゛ﾝｺ゛ | kibidango | kibidango |
| 5 | `0x43113` | ﾓﾓﾌﾚﾎ゛ｳｽ゛ | momofure bouzu | — |
| 6 | `0x43063` | ｵﾅﾗﾉﾓﾄ | onara no moto | polvo de pedos |
| 7 | `0x4308D` | ﾆﾁﾘﾝﾉﾂﾌ゛ﾃ | nichirin no tsubute | guijarro solar |

**No son hechizos: son objetos consumibles** (onigiris que restauran, un
kibidango, polvos de pedos, un proyectil). Solo el nº 7 se parece a un
ataque.

## ぶき — las 7 armas (`0x43CB6`)

ﾎ゛ｸﾄｳ (espada de madera) · ｶﾀﾅ (katana) · ﾋ゛ｬｯｺﾉｹﾝ (espada del Tigre Blanco) ·
ﾋﾘｭｳﾉｹﾝ (espada del Dragón Volador) · ｱｼｭﾗﾉｹﾝ (espada de Asura) ·
ﾎｳｵｳﾉｹﾝ (espada del Fénix) · ﾕｳｷﾉｹﾝ (espada del Valor)

## ぼうぐ — las 4 armaduras (`0x43CF7`)

ﾀｹﾉﾄ゛ｳ (coraza de bambú) · ｱｶﾄ゛ｳ (coraza roja) ·
ｻﾂｷﾉﾄ゛ｳ (coraza de Satsuki) · ﾕｳｷﾉﾄ゛ｳ (coraza del Valor)

Los nombres de arma y armadura ocupan hasta 10 celdas en pantalla; varios
de estos superan ese ancho traducidos y habrá que acortarlos.

## CORRECCIÓN de la sección 11

La primera lectura de じゅつ fue **errónea**: seguí la tabla `$AF4C` del
banco `$21`, que es la de OBJETOS consumibles, no la de じゅつ. La ruta buena
es `$D58F` -> `$AE6B` -> `$AEB8` -> tabla **`$B3A5` = ROM `0x433A5`**.

Las siete じゅつ reales son **movimientos de combate de Momotaro**:

| # | ROM | katakana | lectura | sentido |
|---|---|---|---|---|
| 1 | `0x433E4` | ﾓﾓﾋｴﾝ | momo-hien | golondrina de melocotón |
| 2 | `0x4342B` | ﾓﾓｼ゛ｬﾝﾌ゜ | momo-jump | salto del melocotón |
| 3 | `0x4345E` | ﾓﾓｺﾛｺﾛ | momo-korokoro | melocotón rodante |
| 4 | `0x43487` | ﾓﾓﾏﾜｼ | momo-mawashi | giro del melocotón |
| 5 | `0x434B5` | ﾓﾓﾊ゛ｸﾊﾂ | momo-bakuhatsu | explosión de melocotón |
| 6 | `0x434DE` | ﾓﾓﾂﾅﾐ | momo-tsunami | maremoto de melocotón |
| 7 | `0x43505` | ﾊ゜ﾛﾌ゜ﾝﾃ | (por confirmar) | |

**Son técnicas físicas de acción, no magia.** Ninguna invoca nada
sobrenatural: son saltos, giros y embestidas. Eso descarta MAGIA.

La tabla `$AF4C` (banco `$21`) es la de OBJETOS (どうぐ): onigiris,
kibidango, polvo de pedos, guijarro solar.

---

# 12. Los restos sobre los rótulos [HECHO — detectado por David]

David, mirando `select_j_ARTES.png`: *«veo que hay pequeños artefactos sobre
VIDA, OBJETOS, ARTES y ARMADURA, que curiosamente son las palabras que
encabezan los bloques»*.

**Tenía razón, y su observación era además la pista del diagnóstico**: que
solo apareciesen sobre los rótulos que encabezan bloque no es casualidad.

## La causa

Los rótulos japoneses miden **12 px de alto** y **no están alineados a la
rejilla de 8**. Cabalgan tres filas de celdas:

```
fila superior : los 2 px de ARRIBA del kanji, en las filas 6-7 del tile
fila central  : el cuerpo
fila inferior : la cola
```

La fila superior es la misma celda que lleva el **borde del recuadro** en
sus filas 0-5. Es decir, un solo tile contiene borde arriba y punta de kanji
abajo. Al limpiar solo las dos filas de abajo, esos 2 px superiores del
kanji sobrevivían: eso es lo que David vio.

Se comprueba volcando el arte del tile `$10A` (columna de 体力):

```
44444444   <- borde del recuadro
55555555
22222222
55555555
11111111
11111111
11311131   <- PUNTA DEL KANJI, 2 px
11311131
```

frente al tile liso `$10B`, idéntico pero con esas dos filas a `1`.

Son **44 celdas** repartidas en las filas 2, 9 y 14, con 17 patrones
distintos implicados.

## El arreglo

No hace falta dibujar nada: **el CG ya contiene los tiles lisos**.

```
fila 2  (体力 / どうぐ / じゅつ)  -> sustituir por $10B
fila 9  (ぶき)                    -> sustituir por $141
fila 14 (ぼうぐ)                  -> sustituir por $141
```

Verificado por medición sobre la imagen: **0 píxeles de tinta** en toda la
banda superior tras el arreglo (`capturas/select_sin_artefactos.png`).

Como son cambios en la BAT, van dentro del bloque RLE de `0x1E7EA`, que ya
sé recomprimir con round-trip exacto. No toca el CG comprimido.

**Norma 74. Un rótulo que no está alineado a la rejilla de celdas contamina
la fila de arriba: al borrarlo hay que contar TRES filas, no dos.**


---

# 13. RECTIFICACIÓN de la sección 9

La sección 9 concluía que los rótulos se podían escribir como texto tocando
solo la BAT. **Es falso.**

Medido: el byte ALTO de todas las celdas estáticas de la BAT vale `$01`, y
el RLE de `0x1E7EA` solo almacena el byte BAJO. La BAT solo puede expresar
patrones **`$100-$1FF`**. Los patrones de fuente son `$2xx`.

Dos salidas:

1. **Redibujar los rótulos en el CG comprimido** (`0x7F8F2`), como se hizo
   con los del mapa y las aldeas. El compresor está validado y sobran 379 B.
2. Añadir código que escriba esas celdas en ejecución, igual que hace
   `$D5EE` con las cifras (`LDX #$0A / LDY #$03 / JSR $EF2B`).

La opción 1 es la coherente con el resto del proyecto.

Lo que **sí** sigue siendo válido de la sección 9: el RLE está descifrado y
con round-trip exacto, y sirve para mover celdas de gráfico — que es
justamente lo que necesita el arreglo de los restos de 2 px (sección 12).
