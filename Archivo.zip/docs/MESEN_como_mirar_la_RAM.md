# Cómo mirar la RAM que te pido, en Mesen

Respuesta corta a las cuatro preguntas:

| Pregunta | Respuesta |
|---|---|
| ¿Memory Viewer o debugger? | **Memory Viewer** |
| ¿VRAM o CPU Memory? | **CPU Memory** (no VRAM) |
| ¿Uso «Go to Address»? | **Sí** |
| ¿Qué escribo? | `3B99` y luego `2593` |

---

## Paso a paso

1. **Debugger → Memory Tools** (o *Memory Viewer*), la misma ventana que ya
   usaste para las capturas de VRAM.

2. En **Memory Type**, cambia `Video RAM` por **`CPU Memory`**.
   Esto es importante: `$3B99` y `$2593` son direcciones de la CPU, no de la
   VRAM. En la lista pueden aparecer como *CPU Memory*, *Work RAM* o
   *System Bus*; si hay varias, **CPU Memory**.

3. **Search → Go to Address** (o `Ctrl+G` / `Cmd+G`), y escribe **`3B99`**.

4. Verás una fila que empieza en `3B90`. Los bytes que me interesan son los
   **ocho** que van de la columna `09` a la `10`, o sea `$3B99`-`$3BA0`.
   Con una captura de esa fila y la siguiente me vale.

5. Repite con **`2593`** y captura desde `$2593` hasta `$25A3` (17 bytes).

**Hazlo con el menú ya colgado**, en el momento en que se ven los caracteres
repetidos. Si el emulador te deja pausar (`Esc` o *Break*), mejor: los valores
quedan quietos.

---

## Qué significa cada dirección

Por si te sirve para interpretar lo que veas:

```
$3B99  nº de entradas del nivel 0    $3B9D  scroll del nivel 0
$3B9A  nº de entradas del nivel 1    $3B9E  scroll del nivel 1   <-- el sospechoso
$3B9B  nº de entradas del nivel 2    $3B9F  scroll del nivel 2
$3B9C  nº de entradas del nivel 3    $3BA0  scroll del nivel 3
```

Lo que espero encontrar, si mi hipótesis es correcta: **`$3B9E = 2`**.

Y en `$2593` está el buffer de texto que el motor usa para componer los
glifos. Si ahí hay un mismo byte repetido —o algo que cambia al pulsar
botones—, confirma que el puntero al texto está apuntando a donde no debe.

---

## Bonus: la pista más valiosa

Ya me diste el dato clave sin saberlo: **el carácter cambia según el botón
que pulses**. Eso significa que el motor está leyendo, como si fuera texto,
una zona de RAM donde se guarda el estado del mando.

Si en Mesen puedes poner un **breakpoint de escritura** sobre `$2593`
(*Debugger → Breakpoints → Add → Write, Address `2593`, CPU Memory*), me
dirías **qué rutina** escribe ahí. Con esa dirección de PC y su banco, el bug
queda localizado en una tarde.

Pero no te compliques: con las dos capturas de memoria me apaño.
