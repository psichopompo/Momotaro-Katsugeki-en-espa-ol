# Los tres niveles ocultos — listo para tu visto bueno

Localizado. Tu texto no estaba apuntado en ningún sitio: sólo dentro de la
ROM. Lo he sacado de ahí.

---

## Tu tutorial, recuperado

Esto es lo que escribiste en la v89, tal cual está en la v139:

| | español | celdas |
|---|---|---|
| **pág 1** | ¡Primero, calienta | 18 |
| | antes de jugar! | 15 |
| **pág 2** | ¡Esquiva los ñordos | 19 |
| | que caen! ¡Ja, ja! | 18 |
| **pág 3** | ¡Pulsa I y salta | 17 |
| | para esquivarlos! | 17 |
| **pág 4** | ¡Ve a la derecha | 16 |
| | hasta la meta! ¡Ya! | 19 |

---

## Un tropiezo por el camino

Al cruzar tu traducción con el japonés lo hice **línea a línea**, y me salió
que `ヨーイ！ スタートヂャ！` («¡preparados! ¡ya!») significaba «hasta la
meta! ¡Ya!».

Falso. En la página 4 tú **reordenaste**: la idea de «meta» está en la
primera línea del japonés y en la segunda de tu español. Emparejar por
posición mezcla cada frase con la traducción de la otra.

La unidad no es la línea, es la **página** — igual que cuando repartimos la
intro. Rehecho el cruce así, ahora sí cuadra.

---

## Qué se reutiliza de verdad

| | oculto 1 (el tuyo) | oculto 2 (kusudama) | oculto 3 (fortuna) |
|---|---|---|---|
| pág 1 | nueva | = oculto 1 | nueva |
| pág 2 | **= tutorial pág 2** | nueva | nueva |
| pág 3 | **= tutorial pág 4** | nueva | nueva |

Tu bloque reutiliza **dos páginas enteras** del tutorial. Sólo hay que
escribir la primera. Ni siquiera cambia nada: el japonés dice
`ヨケルノヂャ!` en vez de `ヨケルノヂャゾ!`, un matiz que en español no se
nota.

---

## Propuesta

### Oculto 1 — el que has jugado

```
pág 1   ¡Oh! ¡Bienvenido,        17     <- lo único nuevo
        Momotaro!                 9

pág 2   ¡Esquiva los ñordos      19     <- tuya, del tutorial
        que caen! ¡Ja, ja!       18

pág 3   ¡Ve a la derecha         16     <- tuya, del tutorial
        hasta la meta! ¡Ya!      19
```

El japonés de la página 1 dice literalmente «¡Oh! Bien que has venido,
Momotaro / ¿qué tal un poco de ejercicio suave?». Como el abuelo ya te
conoce a estas alturas, «¡Bienvenido!» me parece más natural que repetirte
lo del calentamiento, pero si prefieres mantener el guiño al ejercicio cabe
igual:

```
        ¿Otro poco de            13
        ejercicio, Momotaro?     20
```

### Oculto 2 — la kusudama

La *kusudama* es la bola de papel que cuelga del techo y suelta confeti al
reventarla. No aparece en tu nivel: es otro minijuego distinto.

```
pág 1   ¡Oh! ¡Bienvenido,        17     <- igual que el oculto 1
        Momotaro!                 9

pág 2   ¡Revienta la bola        17
        de un buen golpe!        17

pág 3   ¿Preparado?              11
        ¡Ya!                      4
```

El japonés añade «¡habrá premio! ¡ujujuy!», que no cabe sin comerse otra
cosa. Si lo quieres dentro, dime qué sacrifico.

### Oculto 3 — fortuna y pobreza

Tocar al **dios de la fortuna** (福の神) y evitar al **dios de la pobreza**
(貧乏神).

```
pág 1   ¡Vaya! ¿Has llegado      19
        hasta aquí?              11

pág 2   ¡Toca al dios rico       18
        y esquiva al pobre!      19

pág 3   ¿Preparado?              11
        ¡Ya!                      4
```

En el original la frase del dios de la pobreza queda **cortada a propósito**
—no dice qué te pasa si lo tocas— y luego suelta «en fin, de eso va la
cosa». Es un chiste de dejar la amenaza en el aire. Si te gusta conservarlo:

```
pág 2   Toca al dios rico...     20
        y al pobre ni se te      19
```

Aunque cortar a mitad de frase en dos páginas puede quedar confuso. Tú
dirás.

---

## Todo cabe

Las 18 líneas están dentro de las 20 celdas. Los tres bloques miden 112, 108
y 108 bytes y hay hueco de sobra (1891 B libres en `0x1F89D`).

En cuanto me digas, construyo la v140 con los tres.

---

## Recordatorio de lo otro

- **El dinero del bocadillo vertical**: seis cadenas fijas (100, 80, 50, 30,
  20, 10), una por importe. No hay que dejar etiqueta, pero sí respetar
  **18 celdas exactas** por cadena porque van seguidas sin terminador.
- **El minijuego de preguntas y el *acchi muite hoi***: en el banco de las
  tiendas. Los vemos allí, como dijiste.
