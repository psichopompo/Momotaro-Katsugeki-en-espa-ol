# La corrupción de las tiendas y del HUD: CAUSA RAÍZ LOCALIZADA

Estado: **[HECHO]** medido sobre `roms/momotaro_es_v296.pce`,
`roms/Momotarou Katsugeki (Japan).pce` y `states/9_tienda_v296.state`.
Nada parcheado todavía.

---

## Resumen en una línea

**Nuestros glifos de la fuente de diálogo se han escrito encima del byte
`0x3DBE8`, que no es un glifo: es el CONTADOR DE BLOQUES del CG del
bocadillo de tienda. Valía 24, ahora vale 0, y `LDX 0 / DEX / BNE` da
256 vueltas en vez de 24.**

---

## 1. La pista de David que rompió el atasco

> «cuando salimos de las tiendas, el HUD queda corrompido, pero al salir de
> la aldea y volver a entrar ya se ve bien.»

Que se cure al recargar la aldea significa que **el código está sano y lo
que está mal es la VRAM**: hay que buscar un volcado de CG que se pasa de
largo, no un fallo de lógica.

---

## 2. Dos errores míos anteriores, corregidos

**(a) El HUD NO usa los patrones `$360-$37F`** (entrada 134 del diario).
Medido en la SAT: el HUD son los tiles **`$1B0-$1BF`** (pal 12/13/14).
`$360-$37F` está a cero en los cuatro states, aldea sana incluida:
comparar esa zona no medía nada.
*Qué falló*: di por bueno un rango escrito en el diario sin releer la SAT.

**(b) La norma 257 es un síntoma, no la causa.** Es verdad que los planos
0-2 están sucios, pero no por falta de un borrado: es que **encima de esas
celdas se ha volcado otra cosa**.

**(c) Error cometido y corregido durante esta misma sesión.** Escribí que
cada iteración de `$861F` volcaba 4 celdas y monté con eso una explicación
sobre `$9C32`/`$53FF`. **Falso**: `$861F` escribe **1 celda** (128 B) por
llamada — las 4 iteraciones internas son los 4 grupos de planos del mismo
tile. Un control (la carga de 20 celdas casaba al 76 % con el bocadillo del
abuelo pero al 8 % con la tienda) tumbó esa hipótesis y obligó a rehacerla.

---

## 3. El descompresor real, transcrito y validado

```
$F1B9 (0x011B9)  primer byte = nº de bloques ; bucle -> $E5C2
$E5C2 (0x005C2)  mapea el banco $20 y llama a $861F
$861F (0x4061F)  UNA celda: 4 grupos x 4 planos (Y=0,1,$10,$11) -> buffer
                 $313F, y TIA $313F,$0002,$0080 (128 B) al VDC
$867F (0x4067F)  un plano de 8 filas hacia ($16),Y con paso 2.
                 bit 1 = literal ; bit 0 = REPITE el acumulador.
                 El PRIMER bit, si es 0, hace CLA -> escribe $00.
```

Transcrito en `tools/descomp_cg2.py`.

**Validación dura**: comprimir celdas de la VRAM real y buscarlas en la
ROM las encuentra literalmente (`$1B0`->`0x4104E`, `$1C0`->`0x4148F`,
`$1B8`->`0x41270`). Controles negativos: origen +1 byte -> 651/5120;
destino +1 celda -> 445/5120.

---

## 4. La cadena, completa

El CG del bocadillo de tienda lo carga `$C5F3` (ROM `0x105F3`, banco `$08`):

```
C5F3  LDA #$1E / CLC / ADC $20 / TAM #$04     mapea el banco $1E ($4000)
C5FA  LDX $5BE8                 <-- CONTADOR  = ROM 0x3DBE8
C5FD  LDA #$E9 / STA $14                      origen $5BE9 = ROM 0x3DBE9
C601  LDA #$5B / STA $15
C605  PHX / JSR $861F / PLX / DEX / BNE $C605
```

Los **cinco** llamantes fijan antes el mismo destino:
`LDA #$00 / STA $3126 ; LDA #$3B / STA $3127` -> `$3B00` = **celda `$0EC`**,
que es exactamente donde está el bocadillo de tienda (SAT: `$0EC $0F0 $0F4
$0F8 $0FC $0FE $100 $101 $103`, pal 15).

```
                    ROM 0x3DBE8      bloques      celdas escritas
japonesa               $18              24        $0EC .. $103
nuestra v296           $00             256        $0EC .. $1EB
```

**`LDX #0` seguido de `DEX / BNE` no da cero vueltas: da 256.**

`$0EC + 256 = $1EC`. El HUD (`$1B0-$1BF`) cae de lleno dentro. También caen
el marco del bocadillo, el rótulo y todo lo demás hasta `$1EB`.

### Verificación de la predicción

Descomprimiendo 256 celdas desde `0x3DBE9` al destino `$0EC` y comparando
**los planos 0-2** (el motor de texto solo escribe el plano 3) contra la
VRAM real de la tienda:

```
celdas $0EC .. $102   ->  planos 0-2 IDÉNTICOS   (23 celdas seguidas)
celda  $103            ->  primera que difiere
```

23-24 celdas idénticas y corte justo ahí: **exactamente las 24 del
japonés**. La predicción se cumple al byte.

### Por qué el HUD no se recupera solo

El HUD se redibuja en `$D2B1` (ROM `0x1D2B1`, banco `$0E`) hacia `$6C00`
= celda `$1B0`, pero con **caché**:

```
D2BB  LDA $3B3C,X       valor actual (vida, dinero...)
D2BE  CMP $3B2E,X       ¿igual al ya pintado?
D2C1  BEQ $D2CC         -> no repinta
```

Al salir de la tienda los valores no han cambiado, así que no repinta
aunque su CG esté destruido. La invalidación (`$E912`, ROM `0x01912`:
`LDA #$FF / STA $3B2E,X`) solo corre al recargar la escena — de ahí,
literalmente, lo que observa David.

---

## 5. Quién lo rompió y cuándo

`0x3DBE8` está en medio de la fuente de diálogo del banco `$1E`, en la zona
que el proyecto reescribió al ampliar el alfabeto latino. Los bytes de
alrededor son glifos nuestros:

```
0x3DBE0  es  00 00 F0 88 88 F0 80 80 | 00 00 78 88 88 78 08 08 | 00 00 B0 ...
0x3DBE0  jp  00 6C 6C 6C 6C 00 6C 6C | 18 20 FF 20 FF 80 FF 80 | FF 40 FF ...
                                       ^^
                                       0x3DBE8: el contador
```

Los `F0 88 88 F0 80 80` / `78 88 88 78 08 08` son claramente una **p** y una
**q** dibujadas. El contador cayó dentro del bloque de glifos y se
sobrescribió.

**Alcance del daño**: de los 703 B del stream original
(`0x3DBE8..0x3DEA7`), hay **559 B pisados**, desde `0x3DBE8` hasta
`0x3DE5F`. La cola `0x3DE60..0x3DEA7` sigue intacta.

Es el mismo patrón de error de la norma 75 («un glifo vacío no es un glifo
libre»), pero un paso más allá: **un byte que parece parte de la fuente
puede ser un parámetro de código**.

---

## 6. Qué hay exactamente encima del stream

La rejilla de glifos de 8 B está alineada en `0x3DBE1`, de modo que el
contador `0x3DBE8` es **el último byte del glifo que empieza en
`0x3DBE1`**. Dibujados, se leen sin ninguna duda:

```
0x3DBE1  ####....   0x3DBE9  .####...   0x3DBF1  #.##....
         #...#...            #...#...            ##..#...
         #...#...            #...#...            #.......
         ####....            .####...            #.......
         #.......            ....#...            #.......
         #.......            ....#...
            p                   q                   r
```

y siguen `s t u v w x y z`, acentuadas, etc.

```
zona pisada        0x3DBE1 .. 0x3DE5F   =  79 glifos de 8 B
   con tinta                               74
   vacíos                                   5
hueco libre ($FF)  0x3DEA7 .. 0x3E000   = 345 B  = 43 glifos
```

**No caben**: hacen falta 592 B y hay 345. Faltan 247 B.

---

## 7. El arreglo: no basta con un byte

Restaurar `0x3DBE8 = $18` corta el bucle a 24 celdas y **el HUD deja de
romperse**, pero el bocadillo de tienda se dibujaría con basura: los 559 B
del stream que lo define están pisados por nuestros glifos.

Hay que hacer las dos cosas:

1. **Restaurar el stream** `0x3DBE8..0x3DE5F` tal cual de la ROM japonesa.
2. **Reubicar 74 glifos** (592 B) para los que sólo hay 345 B libres al
   final del banco `$1E`. Las salidas posibles, por orden de menos a más
   invasivo:
   - buscar hueco en **otro** banco y repuntar la tabla de la fuente
     (`$9CF3`/`$9CB3`), que ya sabemos manipular;
   - comprobar cuántos de esos 74 glifos **están realmente en uso** en los
     textos ya traducidos: los que no lo estén no hay que mover;
   - mover el stream de tienda en vez de los glifos, si algún llamante lo
     permite (los cinco fijan el origen con inmediatos `$5BE9`, así que
     son 5 parejas de bytes).

Opción de seguridad complementaria: invalidar la caché `$3B2E-$3B33` al
salir de la tienda para que el HUD se repinte solo. Cura el HUD pero no el
bocadillo: es un cinturón, no el arreglo.

**Antes de tocar nada** conviene una ROM de aislamiento: sólo
`0x3DBE8 = $18` (un byte) y a la tienda. Predicción medida: el HUD deja de
corromperse y el bocadillo sale con las 24 celdas correctas del japonés,
pero faltarán los glifos p-z en el resto de textos. Si eso se cumple, la
cadena causal queda confirmada en pantalla y ya sólo es cuestión de buscar
sitio.

---

## 7. Normas nuevas propuestas

**260.** El HUD son los patrones `$1B0-$1BF`, paletas 12/13/14. La entrada
134 del diario (`$360-$37F`) es **falsa**: esa zona está a cero en todos
los states.

**261.** El cargador de CG comprimido es `$F1B9 -> $E5C2 -> $861F -> $867F`
(`tools/descomp_cg2.py`), distinto de `$C1CC`/`$C206`. `$861F` escribe
**UNA celda** de 128 B por llamada.

**262.** El HUD se repinta con caché (`$3B2E-$3B33` frente a
`$3B3C-$3B41`): si el valor no cambia no se redibuja, aunque su CG esté
destruido. Por eso hay que salir de la aldea y volver.

**263.** `LDX <cero> / DEX / BNE` **da 256 vueltas, no cero**. Un contador
puesto a `$00` por accidente no desactiva un bucle: lo desborda.

**264.** Antes de escribir un glifo en un banco de fuente, comprobar que
ese offset no lo lee ninguna instrucción como **parámetro**. Buscar
`LDX/LDA <dirección absoluta>` apuntando al rango. `0x3DBE8` parecía
fuente y era el contador de bloques del CG de tienda.
