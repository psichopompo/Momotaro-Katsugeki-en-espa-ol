# Informe: pantalla de Game Over y el canto (password)

**ROM de referencia:** `momotaro_es_v287.pce`  
**MD5** `426a0a2555389ec694fd4d4735c7777d`  
**Objetivo:** menú en castellano (Continuar / Terminar / Guardar), título con tilde si la fuente lo permite, mensaje «¡Guardado!», y el canto de 32 caracteres **legible y en el mismo alfabeto que el Jizo**, sin romper Cargar ni la parrilla.

---

## 1. Dónde está esta pantalla

No es la del Jizo ni la de «Introduce el canto».

| | Pantalla | Cómo se llega | Motor |
|---|---|---|---|
| **A** | Introducir el canto | Título → Continuar (sin partida) | Parrilla `0x1BBBA`, `$C844` |
| **B** | Recitar el canto (Jizo) | Hablar con un Jizo, elegir Sí | `$CA73` + tabla `$CAD6` → buffer `$3667` |
| **C** | **Game Over** | Quedarse sin vidas | Banco `$0D`, rutina `$D6xx` / `$D700` |

La **C** es un bocadillo negro sobre fondo azul, con Momotaro y compañeros abajo. Encima: título + tres opciones (melocotón = cursor). Debajo: **dos líneas con el password de esa partida**.

En japonés el menú es `ゲーム オーバー` / `つづける` / `おわる` / `セーブ`. El canto son 32 kana en dos filas, sin barras.

---

## 2. Mapa ROM / CPU (banco `$0F` en `$4000` salvo que se indique)

### 2.1 Tabla de punteros del menú — **HECHO**

```
CPU $572D  =  ROM 0x1F72D
La lee $D709 (ROM 0x1B709, banco $0D):
    LDA ($1A),Y / ASL / TAX / LDA $572D,X → $BF/$C0
```

Cuatro entradas (Y = 0..3):

| X | Word | CPU | ROM | Contenido original | Hueco útil |
|---|---|---|---|---|---|
| 0 | `$5739` | `$5739` | `0x1F739` | `02` + ゲーム オーバー + `$00` | 12 B (título ~8–10) |
| 2 | `$5745` | `$5745` | `0x1F745` | `01` + つづける + `$00` | **7 B → 5 letras** |
| 4 | `$574C` | `$574C` | `0x1F74C` | `01` + おわる + `$00` | **5 B → 3 letras** |
| 6 | `$5751` | `$5751` | `0x1F751` | `02` + セーブ + `$00` | **6 B → 4 letras** |

Tras el save: `$FF` en `0x1F757` (fin de lista).

`$01` / `$02` **no se dibujan**: `$AB91` los usa para `$3BA6` (tabla de glifos). El texto va detrás, termina en `$00`.

**v287 (ahora):**

```
0x1F739  02 SE ACABO 00
0x1F745  01 Sigue 00
0x1F74C  01 Fin 00
0x1F751  02 Save 00
0x1F757  FF
```

### 2.2 Destinos VRAM — **HECHO** (por eso se cortaba a 4)

```
CPU $D75F  =  ROM 0x1B75F   (banco $0D)
    [0] $7008   título
    [2] $7108   opción 1
    [4] $7188   opción 2     ($7188 − $7108 = $80)
    [6] $7208   opción 3
CPU $D767  =  ROM 0x1B767
    $7288       primer glifo del password
```

`$D6BF` escribe un glifo cada `$20` de VRAM. **`$80` = 4 glifos.**  
Continuar (9) no cabe: los bytes 5+ caen en la VRAM de Terminar.

El password: 32 valores × `$20` desde `$7288`.

### 2.3 Quién pinta el menú y luego el canto

```
$D6FD–$D724   bucle Y=0..3: puntero $572D + dest $D75F → JSR $AA16 → $D619
$D726         JSR $D9D5     ← después, los 32 caracteres del password
```

`$AA16` (banco `$21`) mapea `$0C` y llama a `$D619`: lee `($BF)` hasta `$00`/`$FF`, dibuja con `$AAB4` + `$D6BF`.

### 2.4 El canto en Game Over — **HECHO** (v284–v285)

**No es `$CA73`.** Es otra rutina:

```
$D9D5  ROM 0x1B9D5  banco $0D
    STZ $3BA6
    $C1/$C2 ← $D767/$D768     ($7288)
    para X = 0..31:
        LDA $3C94,X           buffer del password (32 valores 1..64)
        DEC A                 (v284; como el Jizo)
        ASL A
        ADC #$B6
        → puntero $57B6 + (valor−1)*2
        LDA ($BF)             SOLO el primer byte
        JSR $AA69             → $D720 → $AAB4
```

**Tabla de 64 words:**

```
CPU $57B6  =  ROM 0x1F7B6   …   0x1F835   (128 B)
```

Japonés: primer byte = kana (`$B1`…), segundo = `$20` o `$DE`/`$DF` (dakuten).

Con la fuente latina esos kana salen como basura (`º`, `¡`, `&`…). **Es el mismo fenómeno que el resto de japonés sin traducir**, no un tilemap roto.

**Parche actual (v285):**

- `DEC A` en `0x1B9F1` (antes `ASL` + `CLC`).
- 64 primeros bytes = códigos de la parrilla  
  `ABCDEFGabcdefgHIJKLMNhijklmnÑOPQRSTñopqrstUVWXYZuvwxyz0123456789`  
  (`b/c/p` = `$A2/$A3/$B0`).
- Segundos bytes **todos `$20`**. Si queda `$DE`/`$DF`, `$D73F` hace `INY / LDA ($BF),Y` y **no pinta la letra** (fallo de la v284).

El Jizo **no pasa por `$AAB4`**: escribe el **índice de glifo** (`$CAD6` → `$3667`). Aquí sí pasa por `$AAB4`. Por eso no basta copiar `$CAD6`.

**Buffer común:** `$3C94..$3CB3` (32 valores). El mismo que el Jizo y que la parrilla de entrada.

### 2.5 «¡Guardado!»

```
0x1F7AA  02 セーブ しました ! FF     (12 B, cierra con $FF, no $00)
0x1F7B6  empieza la tabla del canto
```

No hay sitio para «¡Guardado!» (10 letras + prefijo) sin comerse la tabla o el `$FF`. La v282 escribió encima y se veía `¡Guardad` + artefacto (ala). **Ahora está otra vez en japonés.**

### 2.6 Texto largo detrás (no es el canto)

`0x1F758`–`0x1F7A9`: mensaje de error de guardado en japonés (`セーブがうまくいきません` / borrar datos). Aún sin traducir.

`0x1F836`: `¿Cuál quieres cargar?` (ya en castellano). **No tocar** al alargar la tabla `$57B6`.

### 2.7 Hueco `$5FDD` (ROM `0x1FFDD`, 35 B a `$FF` en la virgen)

Ahí metimos Continuar/Terminar/Guardar (v282, v286). **En Cargar salían letras sueltas arriba a la izquierda.** Esa zona no es un hueco inocente para esta pantalla (o el stream se sigue leyendo). En v287 está otra vez a `$FF`.

---

## 3. Relación con el Jizo (pantalla B)

| | Jizo (`$CA73`) | Game Over (`$D9D5`) |
|---|---|---|
| Valores | `$3C94` 1..64 | igual |
| Conversión | `$CAD6` → **índice de glifo** | tabla `$57B6` → **código** → `$AAB4` |
| Dónde se escribe | buffer `$3667` (bocadillo aldeano) | VRAM directa `$7288+` |
| Maquetación | 4+barra, 2 líneas (v253) | 2×16, grupos de 4 **sin** barras (como el JP) |
| Banco de la tabla | `$0B` (`$CAD6`) | `$0F` (`$57B6`) |

El Jizo ya está cerrado (informe `INFORME_canto_Jizo_latino.md`, v253). Game Over es **otro código y otra tabla**.

---

## 4. Qué hemos hecho y qué rompió

| Ver | Qué | Resultado |
|---|---|---|
| v282 | Punteros a `$5FDD` + «¡Guardado!» en `1F7AA` | Cont/Term/Guar (4 letras); parrilla y Cargar rotos; `¡Guardad` |
| v283 | Revertido GO; caramelos Kintaro se quedan | Cargar/parrilla OK; menú otra vez kana=basura |
| v284 | `DEC A` + 1er byte latino en `$57B6` | Mitad del canto aún basura (`$DE` en el 2º byte) |
| v285 | 2º byte = `$20` | **Canto latino OK** (lo confirmaste) |
| v286 | Otra vez `$5FDD` + `$D75F` a `$140` + password a `$74C8` | Continuar en 3 líneas; Terminar encima del canto; Cargar otra vez sucia |
| v287 | Revertir v286; menú **in situ** Sigue/Fin/Save | Por probar |

**Norma:** no volver a usar `$5FDD` ni mover `$D75F` sin saber qué sprites cubren cada franja de VRAM.

---

## 5. Problemas abiertos

1. **Continuar / Terminar / Guardar** no caben en 5 / 3 / 4 celdas. Hace falta más VRAM **y** sprites que la muestren. `$D75F` a secas pisa el canto (v286).
2. **Tilde de Ó** en el título: `$C5` en esta ruta se ve como ó pequeña (otra fuente o `$AB34`).
3. **«¡Guardado!»** no cabe en 12 B si hay que respetar `$FF` y la tabla en `0x1F7B6`.
4. **Error de guardado** (`0x1F758`) sigue en japonés.
5. **Cargar:** cualquier escritura en `$5FDD` o un recorte malo de `1F7AA` deja glifos arriba a la izquierda.

---

## 6. Objetivo, en orden

1. **No perder el canto latino de Game Over** (v285).
2. Menú: Continuar, Terminar, Guardar y «SE ACABÓ» con tilde, **sin** comerse el password ni Cargar.
3. «¡Guardado!» entero, sin artefactos.
4. (Secundario) Traducir el error de guardado.

Para (2) hace falta **medir el SAT** de esta pantalla (cuántos sprites hay por línea de opción y a qué patrones `$7008/$7108/…` apuntan). Sin eso, ampliar VRAM es adivinar.

Mientras tanto v287 deja palabras que **sí caben** en el layout original, para no bloquear el resto del juego.

---

## 7. Direcciones rápidas

```
0x1B709   $D709    LDA $572D,X          punteros menú
0x1B75F   $D75F    destinos VRAM menú
0x1B767   $D767    destino VRAM password
0x1B726   $D726    JSR $D9D5            pinta el canto
0x1B9D5   $D9D5    bucle 32 caracteres
0x1B9EE   $D9EE    LDA $3C94,X / DEC / ASL / ADC #$B6
0x1F72D   $572D    4 punteros
0x1F739   $5739    título
0x1F745   $5745    opción 1
0x1F74C   $574C    opción 2
0x1F751   $5751    opción 3
0x1F758            error de save (JP)
0x1F7AA            «guardado» (JP, 12 B)
0x1F7B6   $57B6    tabla 64 words del canto GO
0x1F836            «¿Cuál quieres cargar?»
0x16A73   $CA73    canto del JIZO (otra pantalla)
0x16AD6   $CAD6    tabla glifos del Jizo
0x3C94             buffer 32 valores (compartido)
```
