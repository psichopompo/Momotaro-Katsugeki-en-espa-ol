# Propuesta finales largos (Muy difícil / Difícil) — SIN ROM

**Norma David:** tildes, punto final, `¿`/`¡` de apertura. Siempre. `GRÁFICOS`, no `GRAFICOS`.
`AYUD. PROG.` (no AUX).

Fuente: `0x3B800` JP, motor `$5C` = salto + color (cargo 12 cols / nombre).
No se parte ninguna palabra. Momotaro sin u. Staff: nombre + apellido,
inicial si no cabe. Iizuka (no IiDuka). `$3BA6` sucio → cargos en MAYÚSCULAS.

## Intro — 17 columnas, palabra entera

Cada renglón ≤ 17. `$00` = bloque (como el JP).

```
#0  おめでとう！ ありがとう！
    ¡Enhorabuena!
    ¡Gracias!

#1  モモタロウカツゲキ クリアです！
    ¡Has terminado
    Momotaro en
    Acción!

#2-4  …が誰でもクリアできるゲームとあなたは証明してくれました！
    Has demostrado
    que cualquiera
    puede acabar
    este juego.

#5-6  もう一度あなたにありがとうと言わせてください！
    Permíteme
    darte las gracias
    otra vez.

#7-10  それではここで…メインスタッフを紹介します！
    Ahora,
    el equipo de
    Momotaro en
    Acción.
```

## Cinta 1 — staff con chiste (#11-32)

```
#11-13  El director,
        por fin
        ¡ascendido!
        Shoji Masuda.

#14-16  Música: temas
        que dan calor.
        Michiko Yoshida.

#17-19  Personajes:
        ¡Novia a 3000
        leguas!
        Takayuki Doi.

#20-21  PROGRAMADOR
        Hitoshi Okuno.

#22-23  AYUD. PROG.
        Yasuhiro Kosaka.

#24-27  GRÁFICOS
        Fumie Takaoka.
        Atsushi Kakutani.
        Kayo Fujimoto.

#28-30  SONIDO
        Toshiaki Takimoto.
        Keita Hoshi.

#31-32  DIRECTOR
        Shigeki Fujiwara.
```

## Cinta 1 — concurso de ideas (#33-57)

```
#33-34  Colaboradores
        del concurso
        de ideas.

Noriyuki Noda.
Tetsuya Tsukahara.
Takuji Yoshida.
Shigeki Miyazaki.
Kimiyo Yoshida.
Shigeru Matoba.
Yoichi Igarashi.
Koichi Sato.
Kenya Kawai.
Takashi Terada.
Hirotaka Kobori.
Seiji Naganawa.
Masahiro Sato.
Katsuyoshi Noda.
Yutaka Tagata.
Kenichi Hiwatari.
Daigo Tsunoda.
Katsuhito Matsuo.
Yonekuni Kurusu.
Yasuhiro Morimoto.
Kohei Tahara.
Katsuyuki Miyashita.

#57  De verdad,
     ¡gracias a
     todos!
```

## Cinta 1 — cierre (#58-71)

```
#58-60  SUPERVISIÓN
        ¡Yo!
        Akira Sakuma.
        Esta vez, solo
        me he esforzado
        la sesera.

#61-65  Quien hace
        el juego
        divertido
        es Momotaro.
        Sin él no hay
        Momotaro en
        Acción.

#66-68  Queredlo
        siempre.
        ¡Por favor!

#69-70  Nos veremos
        con Momotaro
        en algún sitio.

#71     PRODUCCIÓN
        HUDSON SOFT
```

## Cinta 2 — cargos 12 cols + nombre (#84-103)

`$5C` cargo (12) `$5C` nombre. MAYÚSCULAS en el cargo.

```
PROGRAMADOR     Hitoshi Okuno
AYUD. PROG.     Yasuhiro Kosaka
GRÁFICOS        Fumie Takaoka
GRÁFICOS        Atsushi Kakutani
GRÁFICOS        Kayo Fujimoto
SONIDO          Toshiaki Takimoto
SONIDO          Keita Hoshi
DIRECTOR        Shigeki Fujiwara
PRODUCCIÓN      HUDSON SOFT
ASISTENTE       Hiroyuki Iizuka
ASISTENTE       Masakazu Hakuya
ASISTENTE       Takahiko Hattori
ASISTENTE       Hitoshi Araki
ASISTENTE       Santa Kuniyake
ASISTENTE       Hiroshi Izawa
ASISTENTE       Tomoo Oi
DIRECCIÓN       Shoji Masuda
PERSONAJES      Takayuki Doi
MÚSICA          Michiko Yoshida
SUPERVISIÓN     Akira Sakuma
```

#72-83 repiten colaboradores a dos columnas: mismos 22 nombres.

## Fácil / Normal — SIN ROM

Misma escena de estudio («¡Banzai! Estudio» en JP). Texto en `0x4A4B9..` (felicitación + enemigos + staff corto). Tabla enemigos `0x24DE` → banco `$25` `$6xxx` = ROM `0x4A739+`.

Formato David: frase en su línea, nombre en la suya, punto si no acaba en `!`/`¿`.

### Felicitación (`0x4A4B9`)

```
¡Enhorabuena!
Has terminado
Momotaro
Katsugeki.

Presume ante
todos: eres un
as de la acción.

Y ahora, con
permiso, os
presento a los
enemigos.
```

### Enemigos (`0x24DE`, 38)

```
00  ¿Te gustó el
    relleno?
    ¡Ogro Onigiri!

01  Andar por andar.
    ¡Ogro Andarín!

02  Parecía seta
    y andaba.
    ¡Ogro Seta!

03  ¡Cuántas casas
    llevaba encima!
    ¡Ogro Casas!

04  No paran de
    bailar. ¡Ogros
    Farolillos!

05  Si para, se cae.
    ¡Ogro Peonza!

06  Recuerda a un
    juguete de lata.
    ¡Ogro Robot!

07  Al principio
    costaba subirse.
    ¡Ogro Bola!

08  ¿Un poco más
    de piedad?
    ¡Ogro Faquir!

09  ¿Adónde se
    esconde?
    ¡Ogro Uzaki!

10  ¡Cómo pega
    saltos!
    ¡Ogro Muelle!

11  Esos misiles
    en los cuernos…
    ¡Ogro Robot!

12  ¡Menudo
    aguafiestas!
    ¡Ogro Ajikara!

13  ¡No saltes
    así!
    ¡Ogro Patines!

14  ¿Le diste
    antes de
    partirse?
    ¡Ogro Cosaco!

15  No era fuego:
    eran bolas de
    hielo.
    ¡Yuki-onna!

16  Tan mona y
    tan dura.
    ¡Daruma Chica!

17  ¡Quieta!
    ¡Daruma Gorda!

18  ¿Se parece a
    Enomoto a los
    36?
    ¡Ogro Pulpo!

19  Esas burbujas
    molestaban.
    ¡Ogro Cangrejo!

20  El mar es
    cosa seria.
    ¡Ogro Buzo!

21  El más
    zonzo del
    juego.
    ¡Ogro En cueros!

22  ¡No enseñes
    el blanco!
    ¡Ogro Pulpazo!

23  ¿Un tipo
    ardiente?
    ¡Ogro Kachi!

24  ¡Qué piernas!
    ¡Ogro Sometaro!

25  ¡Estírate
    mejor!
    ¡Ogro Goma!

26  ¡Lets limbo
    dum dum dum!
    ¡Ogro Danza!

27  ¿Qué cuerpo
    es ese?
    ¡Ogro Partido!

28  Con casco,
    más formal.
    ¡Ogro Sugeho!

29  En clase hay
    uno así.
    ¡Ogro Sordo!

30  ¡9,85!
    ¡Ogro Gimnasia!

31  ¿De verdad
    era un robot?
    ¡Ogro Vampiro!

32  El trueno
    estorbaba.
    ¡Raijin!

33  ¿Ese aro qué
    era?
    ¡Ogro Alado!

34  ¿Sabías que
    montarlo
    divierte?
    ¡Ogro Patada!

35  ¿Le sale del
    culo?
    ¡Ogro Fundoshi!

36  ¡Mal timing
    para explotar!
    ¡Ogro Globo!

37  Hasta aquí,
    el más
    chungo.
    ¡Fujin!
```

(15 y 32-37: nombres propios del folclore / del juego, como Hien. Si quieres ogro delante, lo pones.)

### Staff corto (mismo equipo; 12 cols)

Igual que la cinta 2 del largo: ASISTENTE Iizuka… DIRECCIÓN Masuda, etc., y

```
De verdad,
¡gracias a
todos!

No olvidéis
el valor de
Momotaro.

Nos veremos
en algún sitio.

PRODUCCIÓN
HUDSON SOFT
```

### Abuelo `0x4A446` (A5b, 52 B JP visibles)

No es el final: es el discurso al ir a por Enma.

```
Casi todos
han huido.

Momotaro,
ponen en ti
su esperanza.

Castiga a
Enma y trae
la paz.

¡Ve,
Momotaro!
```

## Presupuesto enemigos (medido, sin ROM)

Ranuras JP **pegadas** (holgura 0). Texto ES in situ: **13/38 caben**. Faltan **~158 B**.

**Plan A — repuntar** (lo que toca):
- Hueco **virgen `$FF` en JP y ES**: `0x7EF7A..0x7F800` (**2182 B**). Sobrado.
- Banco `$3F`. Punteros `$6xxx` solo si el lector TAM mapea `$3F` a `$6000` (ahora lee banco `$25`). **Hay que cambiar ese TAM y las 38 words de `0x24DE`.** Antes de escribir: listar TODOS los `LDA #$25` / punteros a `$6739..$6C1B` y no tocar dados `0x4AC8B` ni el limpiador `0x4AD56`.
- `0x47D61..0x48000` = 671 B: **corto** para los 38.
- En `$25` no queda agujero ≥158 B (el de `0x4B93B` lo comió el quiz).

**Plan B — acortar** (si el TAM no se puede tocar). Alternativas que sí caben en la ranura JP:

| # | Ahora (no cabe) | Alternativa |
|---|---|---|
| 00 | ¿Te gustó el relleno? / ¡Ogro Onigiri! | ¿Rico el relleno? / ¡Ogro Onigiri! |
| 01 | Andar por andar. / ¡Ogro Andarín! | Solo anda. / ¡Ogro Andarín! |
| 03 | ¡Cuántas casas llevaba encima! | ¡Cuántas casas! / ¡Ogro Casas! |
| 06 | Recuerda a un juguete de hojalata. | Como un juguete. / ¡Ogro Robot! |
| 08 | ¿Un poco más de piedad? / ¡Ogro Soplafuego! | ¿Más piedad? / ¡Ogro Fuego! |
| 11 | Esos misiles en los cuernos… | ¡Qué misiles! / ¡Ogro Robot! |
| 14 | ¿Le diste antes de partirse? | ¿Le diste a tiempo? / ¡Ogro Cosaco! |
| 15 | No era fuego: eran bolas de hielo. | Bolas de hielo. / ¡Yuki-onna! |
| 18 | ¿Se parece a Enomoto a los 36? | ¿Es Enomoto? / ¡Ogro Pulpo! |
| 19 | Esas burbujas molestaban. | ¡Qué burbujas! / ¡Ogro Cangrejo! |
| 21 | El más zonzo del juego. | El más zonzo. / ¡Ogro En cueros! |
| 23 | ¿Un tipo ardiente? / ¡Ogro Kachikachi! | ¿Ardiente? / ¡Ogro Kachikachi! |
| 31 | ¿De verdad era un robot? / ¡Ogro Murciélago! | ¿Un robot? / ¡Ogro Murciélago! |
| 34 | ¿Sabías que montarlo divierte? | ¿A que mola? / ¡Ogro Patada! |

El resto se deja o se recorta 1–3 B si hace falta.

## Emulador

Beetle en `tools/bin/`, `tools/pce.py`, states en `descargas/finales/`.
Capturas actuales de v338: kana leído como latino (basura). Esperable.
