# PENDIENTES — registro único del proyecto

> **Para qué es este fichero.** David: *«Hay que ir apuntando todo aquello
> que siga pendiente, para no olvidarnos. A lo largo del proyecto hemos ido
> mencionando cosas que había que mirar, como mutilaciones en muchos sitios
> y cosas así, que ahora se han olvidado.»*
>
> Regla: **nada se cierra sin que David lo confirme en pantalla.** Cuando se
> cierre, se mueve a la sección «Cerrado» con la versión en que se arregló.
> Cuando aparezca algo nuevo, se añade AQUÍ, no solo en el diario.

Estado a fecha de la **v338** (`dd7cf0125e17ee27617c9c98b610e9de`).

> **Las v335, v336 y v337 están descartadas** (en `roms/descartadas/`). Los
> finales quedaron ilegibles y David ordenó volver a la v334 limpia. La
> línea válida es **v334 → v338**. Todo lo que esas versiones decían haber
> cerrado vuelve a estar ABIERTO más abajo.

---

## A0. URGENTE — abierto en la v326

| # | Qué | Estado |
|---|---|---|
| ~~A0a~~ | ~~El `©` en las preguntas~~ **RESUELTO v327**: eran los alias `$5B/$5D/$5E`. Ahora bytes directos | Los alias `b=$5B` `c=$5D` `p=$5E` salen bien en las OPCIONES y mal en las PREGUNTAS. Descartado: tabla `$BF9B`, tablas de glifos `$9CF3`/`$9CB3`, y `$5C` suelto (hay cero). Sospecha: `$DB4E` empaqueta 2 caracteres por celda VRAM. **Arreglo seguro: bytes directos `$A2 $A3 $B0`** |
| ~~A0b~~ | ~~Cuatro preguntas~~ **RESUELTO v327**: reformuladas y todas a 15 columnas | 13, 19, 31, 36. David propone repartir distinto entre las dos líneas de 16 |

---

## A00. Aparecido en la v333

| # | Qué | Estado |
|---|---|---|
| **A00** | **Texto invisible al final de las celdas** | Tres casos ya: (1) 8 B de japonés en la ranura `$4834` de las posadas, desde la v307 — **limpiado en v333**; (2) « te » tras la Capa — **limpiado en v334**; (3) **colas de traducciones antiguas en casi todas las descripciones de objeto** (`e vida.`, `écnica.`, `liado.`, `cotone`, `s ogro`, `en hi`, `bertad.Cor`, `lejosE`…). No se ven porque el motor corta a 16 columnas, pero están. **Sin limpiar**: no urge, pero conviene antes de cerrar el parche (norma 323) |

---

## A. Traducción pendiente

| # | Qué | Dónde | Estado |
|---|---|---|---|
| A1 | ~~**Quiz del abuelo**~~ | `0x4AEE6`-`0x4B87B` | **HECHO en v324.** 40 preguntas (2x16 col) + 120 opciones (8 col, 7 útiles). Tabla de punteros en `0x11818`. Sin verificar en pantalla |
| A4b | **Cinco mensajes sueltos** del menú (repetido, ver A4) | — | — |
| A4 | **Cinco mensajes sueltos** del menú | `0x435E6`, `0x4363D`, `0x4366B`, `0x4369C`, `0x436CC` | Sin tabla localizada. Comprobar si son repuntables |
| A5 | **Créditos y los 4 finales** | `0x3B800` (largos) y `0x4A484` (corto) | **ABIERTO otra vez.** Inventariados en `docs/MAQUETACION_finales.md`. Lo hecho en v336/v337 **queda anulado**: David lo vio y son «un horror» — palabras partidas, nombres cortados, principio y final del Normal sin traducir. Se rehace desde cero sobre la v338, **con capturas antes de generar ROM** |
| A5b | **Discurso del abuelo a medias** | `0x4A446`-`0x4A4B8` | Traducido hasta `0x4A475`; **52 bytes en japonés que SÍ se ven**. Propuesta lista |
| A6 | **Backup RAM** — errores de guardado | `0x1F51E`, 674 B | Sin tocar |
| A7 | **4 bloques huérfanos** de los vítores | `$40E8 $4112 $4139 $4163` | Forman cadena secuencial. **Sin lector conocido** |
| A8 | Textos en **gráficos** (sprites) | varios | Sin inventariar |
| A9 | **Passwords amigables** vinculados al valor interno | — | Idea de David, sin empezar |

---

## B. Gráficos y mutilaciones

> Esta es la sección que más se ha ido perdiendo. Muchas de estas se
> mencionaron hace decenas de versiones y nunca se cerraron.

| # | Qué | Estado |
|---|---|---|
| B1 | **Casa mutilada en el mapa (Kachiyama)** | Diagnosticado y con dos soluciones simuladas (ver abajo). **Bloqueado: la SAT se compone en ejecución, no hay lista estática que editar** |
| B2 | **Pancarta de vítores 4 px alta** | Medido: texto en y=128..151, marco 112..176, descuadre de 4,5 px. **Confirmado otra vez 2026-08-24** (fase 1: «¡Ánimo! ¡Momotaro!»). **Mismo bloqueo que B1**: la Y sale de código, no de tabla |
| B3 | **Menú RUN en cascada** — tres recuadros escalonados | Rompen el límite de sprites. Idea de David: mostrar solo el recuadro activo. *«lo más difícil que nos queda»* |
| B4 | **Bocadillo que se sale por los lados** | Entrada del diario: *«localizada la cadena, pero no se puede cerrar sin medir en vivo»* |
| B5 | **Flechas de continuar y cursor SÍ/NO** | `$9A5F` y `$9A56` están en VRAM pero **ninguna lista de sprites las incluye**. Nadie las muestra. Abierto |
| B6 | **Celdas sin limpiar en el motor de tienda** | En el bocadillo del abuelo limpia `$9C29`; el de tienda no tiene equivalente o no se llama |
| B7 | Otras mutilaciones vistas de pasada | Sin inventariar. **David las irá anotando en el testeo completo** |

---

## C. Textos a verificar en pantalla

| # | Qué | Riesgo |
|---|---|---|
| ~~C1~~ | ~~«Faltan momos»~~ **RESUELTO v331**: `0x19BFA`, ahora «0 momos» |
| C1b | ~~«Faltan momos» original~~ | Si usa bocadillo de 8 celdas se verá «Faltan m». Alternativas contadas: `Sin momo` (8), `Faltan` (6), `Pocos` (5) |
| C2 | **Mensajes que solo salen provocándolos** | Comer algo que no se come, usar comida, gastar técnica sin momos. Solo se ven jugando |
| C3 | **Nombres de técnica en pantalla** | `Parapunte` son 9 y en japonés cabían 6 celdas visibles |
| C4 | **Vítores restantes** | David ha visto dos de los 19. Ahora centrados |
| C5 | **Dados rehechos** | Estructura corregida en v319, sin verificar en pantalla |
| C6 | **Menú RUN** (v318) | Destinos, `Usar`/`Dejar` y ermitaño, sin verificar |
| C7 | **Rótulos de aldea** (v320) | Deben volver a decir «Aldea ...». Sin verificar |
| C8 | **El quiz entero** (v324) | 40 preguntas y 120 opciones. Sin verificar en pantalla |
| C9 | ~~El «Vuelo.» que sobraba~~ | **NO sobraba.** Era «Soy » + técnica + «...!» concatenados. NOP revertido en v326 |
| C12 | **Bocadillo del ermitaño** (v326) | Debe decir «¡Sin excesos! / ¡Jujú!» y luego «Soy Vuelo.» |
| C14 | **Cierre del quiz** (v327) | «¡Bien hecho!» + técnica, y «¡Aún te falta entrenamiento!» |
| C13 | **Las 14 técnicas del ermitaño** (v326) | Estaban ROTAS desde la v317 (12 de 14). Probar varias, no solo Vuelo |
| C10 | **«Aldea Bambú»** (v324) | Rótulo, mapa, menú RUN y diálogo de la aldeana. Los tres a la vez |
| C11 | ~~¿Se corta «Aldea Issunboshi»?~~ | **CERRADO por David con dos capturas**: «Aldea Kachiyama» (15) y «Aldea Florecer» (14) se ven enteras. El marco es de **anchura variable** (medido: 138 px y 233 px). Mi teoría del límite fijo de 12 era errónea. **Sólo «Aldea Taketori» se cortaba**; con «Aldea Bambú» queda cerrado |

---

## D. Testeo

| # | Qué |
|---|---|
| D1 | **Testeo profundo completo.** David lo hará y anotará lo que aparezca |
| D2 | Comprobar los mundos 6 y 7, que usaban los registros de escena rotos de la v237 |
| D3 | Suavizar mutilaciones heredadas del original donde se pueda |

---

## Cerrado

| Qué | Versión |
|---|---|
| Bug del jefe de Kintaro (tabla de escenas `0x1ED6E`) | v314 |
| Los 19 vítores | v315 |
| Juego de dados + 2 mensajes del ermitaño | v316 |
| 14 nombres de técnica + `¿Te animas?` / `¡Qué rácano!` | v317 |
| Menú RUN: destinos, verbos, línea del ermitaño | v318 |
| Dados rehechos, «poco a.», vítores centrados | v319 |
| Rótulos de aldea revertidos + «Aldea Taketori» | v320 |
| «Ve, Momotaro.» — solape de diálogo con el diccionario | v321 |
| El «texto raro» del ermitaño | v322 |
| El ermitaño con el marcador en su sitio | v323 |
| **El quiz del ermitaño: 40 preguntas y 120 opciones** | v324 |
| **El «Vuelo.» que sobraba (NOP al `JSR $DD42` de `0x117C6`)** | v324 |
| **«Aldea Bambú» en los tres sitios** | v324 |
| P21 reformulada, P35 con `Porra`/`Mazo`, P28 documentada como ryo | v325 |
| Las 9 tiendas, menú SELECT con SALUD, onigiri | v307-v313 |
| Acciones de las 6 artes (`Rodar` `Salto` `Azar` `Vuelo` `Giro` `Oleada`) | tanda anterior |


---

## Anexo — B1 y B2: por qué están bloqueados

Los dos son el mismo problema de fondo: **la SAT no existe como tabla
editable en la ROM**. Se compone en ejecución y se vuelca por DMA a VRAM
`$7F00`. Comprobado:

- La SAT del savestate **no aparece en la RAM** como bloque contiguo
  (buscados sus primeros 32, 16 y 8 bytes: nada).
- Sí coincide byte a byte con `VRAM[0xFE00]`, que es el destino del DMA.
- Las listas estáticas de sprites que sí existen (`0x2FBA2`, 16 listas de
  marco y texto) usan la celda `$708`, **no** las `$1A4`-`$1B5` del rótulo
  del mapa. No es esa lista.
- No hay ningún registro `[48 03 8e]` ni `[4c 03 8e]` en toda la ROM, que
  sería el patrón del rótulo si estuviera en una lista.

### B1 — casa mutilada: dos soluciones ya simuladas

Sobre el savestate real de David:

```
ACTUAL                                 pico=16  pierde 6 px del tejado
tejado (i=32) el primero               pico=16  pierde 6 px del sprite 31
borde inferior 32px -> 16px            pico=14  LIMPIO
mapa (22-34) antes que rótulo (0-21)   pico=16  LIMPIO
```

**Estrechar el borde inferior a 16 px queda descartado**: comprobado que
las dos mitades de cada sprite dibujan (`izq=15/7 px`, `der=7 px`), así que
recortarlos rompería el marco.

Queda **reordenar la SAT**: que los sprites del mapa (22-34) se compongan
antes que los del rótulo (0-21). Cero píxeles visibles perdidos, porque el
descarte cae entonces en el sprite 20, que en esas 6 filas no dibuja nada.

### Lo que falta para desbloquear los dos

Localizar la rutina que compone la SAT. No se puede por barrido de bytes:
hay que **seguir el código** desde el bucle de dibujado del mapa, o que
David ponga un breakpoint de escritura en VRAM `$FE00`.

**Ni B1 ni B2 se tocan hasta tener esa rutina.** Escribir a ciegas en la
zona de sprites es lo que costó la v309 (fondo destrozado) y la v293
(pantalla de título).


---

## A000. Aparecido en la v338 (2026-08-24)

| # | Qué | Estado |
|---|---|---|
| ~~A000a~~ | ~~El «!» del password: «¡Introduce el canto de JizoA»~~ | **CERRADO en v338.** No era de la tanda de estos días: lo rompió la **v320** al reescribir el bloque de rótulos empezando un byte antes de la cuenta (`0x1F89C` es del password, no de los rótulos). Verificado en pantalla |
| ~~A000b~~ | ~~3 B muertos en `0x1F8EC`~~ | **CERRADO en v338**: los dejó la v324 al revertir «Taketori»→«Bambú» sin recompactar. Recuperados |
| **A000c** | **Bug gráfico bajo la cabeza del ogro rosa** (final Difícil) | **SIN INVESTIGAR.** Lo reclamó David y sigue pendiente |
| **A000d** | **Tabla `0x24DE`** (presentación de enemigos, 38 entradas de 8 B) | **Plan A:** repuntar a hueco virgen `0x7EF7A` (2182 B, banco `$3F`) + TAM del lector. **Plan B:** acortar (alternativas en `MAQUETACION_finales_propuesta.md`). No escribir hasta barrer punteros `$6739–$6C1B` |
| **A000e** | **15 `$00` de relleno** en `0x4A476..0x4A483` | **ABIERTA**: abren páginas fantasma (28 terminadores en japonés, 43 en el nuestro). El arreglo de la v337 se perdió |
| **A001a** | **Posada, al despertar: «¡Buenos días! / ¡A por los»** | Ranura `$4834` = ROM `0x48834`. 2×16: L1 `¡Buenos días!` L2 `¡A por los` + pad; **`ogros!` está en el byte 32+**, fuera del motor. «¡A por los ogros!» = **17** y no cabe en 16 (norma 309/v333). Hay que **repartir en 2 líneas** o acortar con punto, **sin partir palabra**. David lo vio al irse después de dormir |
| **A001b** | **«El perro te acompaña» sin punto** | Tras el 1.er jefe. ROM **`0x48D6D`**: `El perro te` `$3B` `acompaña` `$00`. Falta `$CB`. Siguen `El faisán…` / `El mono…` con el mismo patrón |

### Formato acordado con David (no negociable)

- **Nunca partir una palabra.** Si no cabe, la palabra entera baja de línea.
- **Nomenclatura de finales**: Muy difícil / Difícil / Normal / Fácil. No «corto/largo».
- **Presentación de enemigos**: la frase en su línea, el nombre en la suya, y punto final si no acaba en exclamación:

      ¿Cayó sin estallar?
      ¡Ogro Explosivo!

- **Staff en orden occidental** (nombre-apellido) y con inicial si no cabe: `M. Kuya`, `H. Iizuka`.
- Sin abreviaturas. **Momotaro** sin `u` final. **Sólo** con tilde.
- **No se genera ROM hasta ver capturas de cómo quedan los cambios.**
