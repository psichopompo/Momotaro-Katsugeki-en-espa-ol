#!/usr/bin/env python3
"""
v370 — Difícil/Muy difícil: tabla de punteros $DD0F/$DD43, no el rollo de Fácil.

Base v362. Sin hook $DBA2. Sin $3D33. Fácil 0x3B800 intacto.
Motor $D277: $37F8=2/3, lista, $00 cierra ficha, $0000 acaba.
$5C = tira; $A0 = pad de tira (no $20).
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v362.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v370.pce'
IPS = ROOT / 'parches/momotaro_v370.ips'
MD5_BASE = '311f6adac43ee49af137adda79c23a35'
CRED, BANK_END = 0x3B800, 0x3C000
DD07, DD0F, DD43 = 0x03D07, 0x03D0F, 0x03D43
OGROS = 0x03D7D

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

# cargo, nombre1, nombre2 ('' si uno)
STAFF = [
    ('DIRECC.', 'Shoji', 'Masuda'),
    ('PERSON.', 'Takayuki', 'Doi'),
    ('PROGRAM.', 'Hitoshi', 'Okuno'),
    ('AY.PROG.', 'Yasuhiro', 'Kosaka'),
    ('GRAFICOS', 'Fumie', 'Takaoka'),
    ('GRAFICOS', 'Atsushi', 'Kakutani'),
    ('GRAFICOS', 'Kayo', 'Fujimoto'),
    ('SONIDO', 'T.', 'Takimoto'),
    ('SONIDO', 'Keita', 'Hoshi'),
    ('DIRECTOR', 'Shigeki', 'Fujiwara'),
    ('PRODUCC.', 'HUDSON', 'SOFT'),
    ('ASIST.', 'H.Iizuka', ''),
    ('ASIST.', 'M.Hakuya', ''),
    ('ASIST.', 'T.', 'Hattori'),
    ('ASIST.', 'Hitoshi', 'Araki'),
    ('ASIST.', 'S.', 'Kuniyake'),
    ('ASIST.', 'Hiroshi', 'Izawa'),
    ('ASIST.', 'Tomoo Oi', ''),
    ('MUSICA', 'Michiko', 'Yoshida'),
    ('SUPERV.', 'Akira', 'Sakuma'),
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def strip(s, width=8):
    assert 1 <= len(s) <= width, s
    return enc(s) + bytes([0xA0] * (width - len(s)))


def block(cargo, n1, n2):
    o = bytes([0x5C]) + strip(cargo)
    o += bytes([0x5C]) + enc(n1)
    if n2:
        o += bytes([0x5C]) + enc(n2)
    return o + b'\x00'


def main():
    for c, n1, n2 in STAFF:
        for ch in c + n1 + n2:
            assert ch in ENC, ch
        assert len(c) <= 8 and len(n1) <= 8 and len(n2) <= 8
    blks = [block(c, n1, n2) for c, n1, n2 in STAFF]
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    assert rom[0x3BA2:0x3BA8] == bytes.fromhex('a90085bfa958')
    assert rom[0x11480:0x11483] == bytes.fromhex('9c333d')
    assert rom[DD07:DD07 + 8] == bytes.fromhex('000000000fdd43dd')
    easy_end = CRED
    while rom[easy_end] != 0xFF:
        easy_end += 1
    easy_head = bytes(rom[CRED:CRED + 16])
    easy_len = easy_end - CRED
    keep = {
        OGROS: bytes(rom[OGROS:OGROS + 16]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 8]),
        0x3277: bytes(rom[0x3277:0x32A8]),
    }
    pos = (easy_end + 2) & ~1
    ptrs = []
    for b in blks:
        assert pos + len(b) <= BANK_END
        rom[pos:pos + len(b)] = b
        ptrs.append(0x5800 + (pos - CRED))
        pos += len(b)
    # listas: 20 punteros + $0000. No pisar ogros $3D7D
    raw = b''.join(bytes([p & 0xFF, p >> 8]) for p in ptrs) + b'\x00\x00'
    assert DD0F + len(raw) <= DD43
    assert DD43 + len(raw) <= OGROS
    rom[DD0F:DD0F + len(raw)] = raw
    rom[DD43:DD43 + len(raw)] = raw
    assert bytes(rom[CRED:CRED + 16]) == easy_head
    assert rom[easy_end] == 0xFF
    assert 0x5C not in bytes(rom[CRED:easy_end])
    assert rom[0x3BA2] == 0xA9
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    # releer primer puntero
    p0 = rom[DD0F] | (rom[DD0F + 1] << 8)
    off0 = CRED + (p0 - 0x5800)
    assert rom[off0] == 0x5C
    assert bytes(rom[off0 + 1:off0 + 8]) == enc('DIRECC.')
    d = bytes(rom)
    SALIDA.write_bytes(d)
    Path(IPS).parent.mkdir(parents=True, exist_ok=True)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v370 OK nblk', len(blks), 'first', hex(ptrs[0]), 'easy', easy_len)
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
