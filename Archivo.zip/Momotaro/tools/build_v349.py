#!/usr/bin/env python3
"""
v349 — SOLO el primer bloque de 0x3B800 (Fácil / créditos).

JP 0x3B800..0x3B80E (15 B) + $00 en 0x3B80F. In situ, sin mover el $00.
«¡Enhorabuena!» = 13 + 2×$20. No $3B (en esta zona pinta «,.»).
Siguiente bloque 0x3B810 INTOCABLE. Base v348.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v348.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v349.pce'
IPS = ROOT / 'parches/momotaro_v349.ips'
MD5_BASE = '0c777e44fdf81f924670f732363fe7ee'

OFF = 0x3B800
SLOT = 15

# $C190-ish / créditos: p=$5E si hiciera falta; aquí no hay p
ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,  # alias créditos
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC[c] = ord(c)


def main():
    txt = '¡Enhorabuena!'
    raw = bytes(ENC[ch] for ch in txt)
    assert len(raw) == 13
    blob = raw + bytes([0x20, 0x20])
    assert len(blob) == SLOT
    assert 0x3B not in blob

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    assert orig[OFF + SLOT] == 0x00
    assert rom[OFF + SLOT] == 0x00
    nxt = bytes(rom[OFF + SLOT:OFF + SLOT + 20])
    w0 = bytes(rom[0x24DE:0x24E0])
    hole = bytes(rom[0x7EF7A:0x7EF7A + 8])
    c16c = bytes(rom[0x216C:0x2174])

    rom[OFF:OFF + SLOT] = blob

    assert rom[OFF + SLOT] == 0x00
    assert bytes(rom[OFF + SLOT:OFF + SLOT + 20]) == nxt
    assert bytes(rom[0x24DE:0x24E0]) == w0
    assert bytes(rom[0x7EF7A:0x7EF7A + 8]) == hole
    assert bytes(rom[0x216C:0x2174]) == c16c
    assert bytes(rom[OFF:OFF + 13]) == raw

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v349 OK', raw.hex())
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
