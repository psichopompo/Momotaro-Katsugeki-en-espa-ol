#!/usr/bin/env python3
"""
build_v287.py - revertir VRAM/punteros/1FFDD. Menu GO in situ.

v286: $5FDD + mover $D75F pico el password y dejo restos en Cargar.
Se restaura 1F72D, D75F, D767 y 1FFDD desde v285.

Menu en los huecos originales (5/3/4 kana):
  SE ACABO / Sigue / Fin / Save
Continuar (9) no cabe en 5 celdas sin ensanchar sprites.

Uso:  python3 tools/build_v287.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import encode                        # noqa: E402

BASE = 'roms/momotaro_es_v286.pce'
V285 = 'roms/momotaro_es_v285.pce'
SALIDA = 'roms/momotaro_es_v287.pce'
IPS = 'parches/momotaro_v287.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '6cc8ca3fe42d33eab2a398281496b579'


def main():
    rom = bytearray(open(BASE, 'rb').read())
    v285 = open(V285, 'rb').read()
    orig = open(VIRGEN, 'rb').read()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    rom[0x1F72D:0x1F758] = v285[0x1F72D:0x1F758]
    rom[0x1B75F:0x1B769] = v285[0x1B75F:0x1B769]
    rom[0x1FFDD:0x20000] = v285[0x1FFDD:0x20000]
    print('restaurado 1F72D, D75F, 1FFDD')

    def slot(off, pref, txt, n):
        b = bytes([pref]) + encode(txt) + b'\x00'
        assert len(b) <= n, '%s %d>%d' % (txt, len(b), n)
        rom[off:off + n] = b + bytes(n - len(b))
        print('  %s  %d/%d' % (txt, len(b), n))

    # 02+10+00=12, 01+5+00=7, 01+3+00=5, 02+4+00=6
    slot(0x1F739, 0x02, 'SE ACABO', 12)
    slot(0x1F745, 0x01, 'Sigue', 7)
    slot(0x1F74C, 0x01, 'Fin', 5)
    slot(0x1F751, 0x02, 'Save', 6)
    assert rom[0x1F757] == 0xFF

    assert rom[0x1F7B6] == v285[0x1F7B6]
    assert rom[0x1B9EE + 3] == 0x3A
    assert rom[0x1FFDD] == 0xFF

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
