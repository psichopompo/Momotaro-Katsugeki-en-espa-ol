#!/usr/bin/env python3
"""
build_v305.py - diálogos de tienda según el japonés de cada puntero.

6 slots por tienda (tabla 0x10854):
  [0] entrada  [1] adiós sin compra  [2] gracias al comprar
  [3] sin dinero  [4] no queda / inventario  [5] ¿algo más?

v304 asignó frases a ojo. Aquí cada $xxxx se traduce de su kana (32 B).
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v304.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v305.pce'
IPS = ROOT / 'parches/momotaro_v305.ips'
MD5_BASE = '513894c3f622ddbac3432e23cf534d5c'

ENC = {
    '!': 0x21, '?': 0x3F,
    '¡': 0xCA, '¿': 0xC9, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ñ': 0xC1, 'ó': 0xC5,
    'b': 0xA2, 'c': 0xA3, 'p': 0xB0, 'Ç': 0xDE,
    'a': 0xA1, 'd': 0xA4, 'e': 0xA5, 'f': 0xA6, 'g': 0xA7, 'h': 0xA8,
    'i': 0xA9, 'j': 0xAA, 'k': 0xAB, 'l': 0xAC, 'm': 0xAD, 'n': 0xAE,
    'o': 0xAF, 'q': 0xB1, 'r': 0xB2, 's': 0xB3, 't': 0xB4, 'u': 0xB5,
    'v': 0xB6, 'w': 0xB7, 'x': 0xB8, 'y': 0xB9, 'z': 0xBA,
}
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)
ENC[' '] = 0x20


def enc_line(s):
    assert len(s) <= 16, repr(s)
    out = bytearray(ENC[ch] for ch in s)
    out += b'\xA0' * (16 - len(s))
    return bytes(out)


def msg(l1, l2):
    return enc_line(l1) + enc_line(l2)


ITEMS = [
    ('Onigiri:', 'Recupera 1 vida.'),
    ('Manjar:', 'Recupera 1 momo.'),
    ('Banquete:', 'Cura ambos.'),
    ('Dango:', 'Llama un aliado.'),
    ('Bonzo:', 'Llueven momos.'),
    ('Pedos:', 'Empujas atrás.'),
    ('Solar:', 'Calcina ogros.'),
    ('Glacial:', 'Congela ogros.'),
    ('Raquetas:', 'No resbalas.'),
    ('Capa:', 'Ogros no te ven.'),
    ('Aletas:', 'Nadas deprisa.'),
    ('Coraza Roja:', 'Menos daño.'),
    ('Coraza Satsuki:', 'Daño a la mitad.'),
    ('Coraza Valor:', 'Daño mínimo.'),
    ('Katana:', 'Más alcance.'),
    ('Espada Byakko:', 'Dispara 2 veces.'),
    ('Espada Hiryu:', 'Más alcance.'),
    ('Espada Asura:', 'Dispara 3 veces.'),
    ('Espada Fénix:', 'Balas mayores.'),
    ('Espada Valor:', 'Balas mayores.'),
]

# (ptr, l1, l2)  — 16+16, japonés de cabecera
DIAL = [
    # shop 0 armas
    (0x447D, '¡Pasa!', '¡Lleva armas!'),          # イラッシャイ / 武器買っていくといいど
    (0x449F, '¿Nada, eh?', 'Vuelve otro día.'),  # お気に召さなかった / また来てくれ
    (0x44C0, '¡Gracias!', '¡Vuelve pronto!'),     # 毎度あり / また来てくれ
    (0x44E1, '¡Vaya!', 'Te falta dinero.'),       # 残念お金足りない / もうひとがんばり
    (0x4506, 'No hay más.', 'Lo siento.'),        # それより強い武器はない / 役に立てなくて
    (0x4B9E, '¡Gracias!', '¿Algo más?'),          # 毎度あり / まだ何かいるかい
    # shop 1 armaduras
    (0x452D, '¡Bienvenido!', '¿Una coraza?'),     # いらっしゃいませ / 防具はいかが
    (0x4551, '¿Nada, eh?', 'Te espero.'),         # お気に召さなかった / またのお越しを
    (0x4572, '¡Muchas gracias!', 'Te espero.'),   # 毎度ありがとう / またのお越しを
    (0x4596, '¡Vaya, cliente!', 'Te falta dinero.'),
    (0x45B9, 'No hay mejor.', 'Lo siento.'),
    (0x4BC0, '¡Muchas gracias!', '¿Algo más?'),
    # shop 2 onigiri/técnica
    (0x45DC, '¡Bienvenido!', '¡Lleva onigiri!'),  # いらっしゃい / 技のおにぎり買って
    (0x4600, '¡Muchas gracias!', 'Gasta y vuelve.'),  # ありがとう / 技がなくなったら
    (0x4625, '¡Vaya, cliente!', 'Te falta dinero.'),
    (0x4646, 'No puedo', 'venderte más.'),
    (0x4BE6, '¡Muchas gracias!', '¿Algo más?'),
    # shop 3 tienda general
    (0x466B, '¡Bienvenido!', '¿Qué va a ser?'),
    (0x468B, '¿Nada, eh?', 'Vuelve otro día.'),
    (0x46AC, '¡Muchas gracias!', 'Vuelve otro día.'),
    (0x46D0, '¡Vaya, cliente!', 'Te falta dinero.'),
    (0x46F1, '¡Llevas las', 'manos llenas!'),
    (0x4C0B, '¡Muchas gracias!', '¿Algo más?'),
    # shop 4 anciano
    (0x4713, '¡Qué bien verte!', '¿Necesitas algo?'),
    (0x4734, 'Vuelve por aquí.', ''),
    (0x4756, '¡Gracias!', ''),
    (0x4779, '¡Vaya, cliente!', 'Te falta dinero.'),
    (0x479C, '¡Llevas las', 'manos llenas!'),
    (0x4C31, '¡Gracias!', '¿Algo más?'),
    # posada (5-7, textos compartidos)
    (0x47BF, '¡Pío, pío!', 'Posada: 300.'),
    (0x47E6, '¡Pío, pío!', 'Posada: 500.'),
    (0x480D, '¡Pío, pío!', 'Posada: 1000.'),
    (0x485C, 'No te pases.', '¡Ten cuidado!'),
    (0x4834, '¡Buenos días!', '¡A por ogros!'),
    (0x487E, '¡Pío, pío!', 'Te falta dinero.'),
]


def cpu_off(p):
    return 0x48000 + (p - 0x4000)


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    titulo = bytes(rom[0x2F8B5:0x2F8C5])
    c5f3 = bytes(rom[0x105F3:0x1060E])
    juego = bytes(rom[0x1F9C4:0x1F9D6])
    assert juego == b'COMIENZA EL JUEGO\x00'
    assert rom[0x47CFB] == 0xFF
    tbl_items = bytes(rom[0x10929:0x10929 + 80])
    tbl_dial = bytes(rom[0x10854:0x108C0])

    occupied = []

    def put(ptr, blob):
        o = cpu_off(ptr)
        occupied.append((o, o + len(blob), ptr))
        rom[o:o + len(blob)] = blob

    for n, (a, b) in enumerate(ITEMS):
        p = rom[0x10929 + n * 4] | (rom[0x10929 + n * 4 + 1] << 8)
        nxt = 0x4C00
        if n < 19:
            nxt = rom[0x10929 + (n + 1) * 4] | (rom[0x10929 + (n + 1) * 4 + 1] << 8)
        blob = msg(a, b)
        assert nxt - p >= 32 or n == 19, (n, hex(p), nxt - p)
        put(p, blob)

    for p, a, b in DIAL:
        put(p, msg(a, b))

    occupied.sort()
    for (a1, b1, p1), (a2, b2, p2) in zip(occupied, occupied[1:]):
        assert b1 <= a2, (hex(p1), hex(b1), hex(p2), hex(a2))

    assert bytes(rom[0x10929:0x10929 + 80]) == tbl_items
    assert bytes(rom[0x10854:0x108C0]) == tbl_dial
    assert bytes(rom[0x2F8B5:0x2F8C5]) == titulo
    assert bytes(rom[0x105F3:0x1060E]) == c5f3
    assert bytes(rom[0x1F9C4:0x1F9D6]) == juego
    assert rom[0x47CFB] == 0xFF

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('v305 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
