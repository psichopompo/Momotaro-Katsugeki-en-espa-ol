#!/usr/bin/env python3
"""
build_v302.py - mueve el stream CG de tienda fuera de los glifos 177-223.

El contador ya está en 0x3DEA7 (v301). El stream 0x3DBE9..0x3DEA7 (702 B)
sigue pisado por la fuente. No se tocan glifos ni tablas de índices.

C5F3 es el ÚNICO sitio que fija origen $5BE9 (los 5 JSR solo ponen destino
$3B00). Se copia el stream japonés a un hueco virgen del banco $16 y se
repunta TAM + puntero + LDX.

Uso: python3 tools/build_v302.py
"""
import hashlib
import zlib
import sys
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v301.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v302.pce'
IPS = ROOT / 'parches/momotaro_v302.ips'
MD5_BASE = 'ec66b395a3132a5f322e3dfc9b549726'

HOLE = 0x2C05A          # banco $16, virgen $FF, 934 B
NSTREAM = 702           # JP 0x3DBE9 .. 0x3DEA7
# layout: [0]=contador $18  CPU $405A
#         [1:703]=stream    CPU $405B


def celda(f):
    def get():
        b = f.d[f.p]
        f.p += 1
        return b

    def plano(buf, y):
        mapa = get()
        a = 0
        hi = (mapa << 1) & 0x100
        mapa = (mapa << 1) & 0xFF
        if hi:
            a = get()
            buf[y] = a
        else:
            a = 0
            buf[y] = 0
        for _ in range(7):
            hi = (mapa << 1) & 0x100
            mapa = (mapa << 1) & 0xFF
            y += 2
            if hi:
                a = get()
            buf[y] = a

    out = bytearray(128)
    for g in range(4):
        tmp = bytearray(32)
        plano(tmp, 0)
        plano(tmp, 1)
        plano(tmp, 16)
        plano(tmp, 17)
        out[g * 32:(g + 1) * 32] = tmp
    return bytes(out)


class Flujo:
    def __init__(self, d, p):
        self.d, self.p = d, p


def descomp_24(rom, off):
    f = Flujo(rom, off)
    cells = [celda(f) for _ in range(24)]
    return cells, f.p


def main():
    rom = bytearray((ROOT / 'roms/momotaro_es_v301.pce').read_bytes())
    orig = (VIRGEN).read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    assert len(rom) == 524288

    # --- precondiciones ---
    assert rom[0x105F3:0x105FA] == bytes.fromhex('a91e1865205304')
    assert rom[0x105FA:0x10605] == bytes.fromhex('aea75ea9e98514a95b8515')
    assert all(b == 0xFF for b in rom[HOLE:HOLE + 1 + NSTREAM])
    assert orig[HOLE:HOLE + 1 + NSTREAM] == b'\xff' * (1 + NSTREAM)
    assert rom[0x3DBE8] == 0x00          # q fila 0
    assert rom[0x3DEA7] == 0x18          # contador v301
    assert orig[0x3DBE8] == 0x18
    assert rom[0x47CFB] == 0xFF
    titulo = bytes(rom[0x2F8B5:0x2F8C5])
    f0 = bytes(rom[0x41CF3:0x41D33])
    jizo = bytes(rom[0x16AD6:0x16B16])
    parr = bytes(rom[0x1BBBA:0x1BBFA])
    canto = bytes(rom[0x1F7B6:0x1F836])
    qglyph = bytes(rom[0x3DBE1:0x3DBE9])

    jp_stream = orig[0x3DBE9:0x3DEA7]
    assert len(jp_stream) == NSTREAM
    cells_jp, fin = descomp_24(orig, 0x3DBE9)
    assert fin == 0x3DEA7

    # --- escribir hueco banco $16 ---
    rom[HOLE] = 0x18
    rom[HOLE + 1:HOLE + 1 + NSTREAM] = jp_stream
    assert rom[HOLE + 1 + NSTREAM] == 0xFF

    # --- repuntar C5F3 ---
    rom[0x105F4] = 0x16                    # LDA #$16 (era #$1E)
    rom[0x105FA:0x105FD] = bytes([0xAE, 0x5A, 0x40])  # LDX $405A
    rom[0x105FD:0x10605] = bytes.fromhex('a95b8514a9408515')  # $405B

    # contador viejo ya no se lee
    rom[0x3DEA7] = 0xFF

    # --- releer como el motor ---
    assert rom[0x105F3:0x1060E] == bytes.fromhex(
        'a9161865205304ae5a40a95b8514a9408515da201f86facad0f860'
    )
    cells_new, fin2 = descomp_24(bytes(rom), HOLE + 1)
    assert fin2 == HOLE + 1 + NSTREAM
    assert cells_new == cells_jp

    # --- zonas intocables ---
    assert rom[0x3DBE8] == 0x00
    assert bytes(rom[0x3DBE1:0x3DBE9]) == qglyph
    assert bytes(rom[0x2F8B5:0x2F8C5]) == titulo
    assert rom[0x47CFB] == 0xFF
    assert bytes(rom[0x41CF3:0x41D33]) == f0
    assert bytes(rom[0x16AD6:0x16B16]) == jizo
    assert bytes(rom[0x1BBBA:0x1BBFA]) == parr
    assert bytes(rom[0x1F7B6:0x1F836]) == canto
    assert rom[0x04100:0x04110] == bytes(rom[0x04100:0x04110])  # noop, ©

    d = bytes(rom)
    SALIDA.write_bytes(d)

    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.parent.mkdir(exist_ok=True)
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d

    print('v302 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('hueco', hex(HOLE), '+', 1 + NSTREAM)
    print('C5F3 ', d[0x105F3:0x1060E].hex())


if __name__ == '__main__':
    main()
