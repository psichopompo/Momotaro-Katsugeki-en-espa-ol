#!/usr/bin/env python3
"""
build_v274.py - textos del abuelo en formato de guion + motor bueno.

BASE: v272 (la v273 se descarta: $A0 + clon $9952).

CAUSA MEDIDA
============
$88D2 hace JSR $C8DB / JMP $9952. El clon llama a $79EB (descompresor).
$A0 ya no es salto de linea: es un literal. Sin $00 el lector se come el
guion de 0x48E2A. En pantalla: dos glifos basura y el resto vacio.

El motor bueno ($97EE / $9801) si entiende $3B (linea) y $00 (fin).

ARREGLO
=======
1. Cadenas: encode + $3B entre lineas + $00. Sin $A0. Sin codigos $60-$8F.
2. $88D8  JMP $9952 -> JMP $97EE
   $88D2 ya cargo el puntero en $92/$93; $97EE remapea el banco $24 y lee.

Uso:  python3 tools/build_v274.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE, encode          # noqa: E402
from dis6280 import desensambla                            # noqa: E402

BASE = 'roms/momotaro_es_v272.pce'
SALIDA = 'roms/momotaro_es_v274.pce'
IPS = 'parches/momotaro_v274.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '3043e0bdeffaae160e295b95c9400e4e'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL = 0x3B
FIN = 0x00
COLS = 14
ZONA_INI = 0x48C7E
ZONA_FIN = 0x48E2A
HUELLA0 = bytes.fromhex('b6d7dec0c9')
JMP_ABUELO = 0x168D8
JMP_ESPERADO = bytes([0x4C, 0x52, 0x99])   # JMP $9952
JMP_NUEVO = bytes([0x4C, 0xEE, 0x97])      # JMP $97EE

TEXTOS = [
    'Coges el Onigiri',
    'Coges el Manjar',
    'Coges el Banquete',
    'Coges un Dango',
    'Coges los Pedos',
    'Coges la Solar',
    'Coges la Glacial',
    'Coges la Capa',
    'Ganas 100 ryos',
    'Ganas 50 ryos',
    'Ganas 30 ryos',
    'Ganas 10 ryos',
    'No puedes llevar más',
    'El perro te acompaña',
    'El faisán te acompaña',
    'El mono te acompaña',
    'Coges el caparazón',
    'Coges el Bonzo',
    'Ganas 80 ryos',
    'Ganas 20 ryos',
    '¡Menudo idiota!',
    'Sigue hacia arriba',
    'Sigue a la derecha',
]


def voraz(t, c):
    out, cur = [], ''
    for w in t.split():
        if not cur:
            cur = w
        elif len(cur) + 1 + len(w) <= c:
            cur += ' ' + w
        else:
            out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    return out


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v272'
    print('base %s  OK' % BASE)

    assert bytes(rom[JMP_ABUELO:JMP_ABUELO + 3]) == JMP_ESPERADO, \
        'en $88D8 no esta JMP $9952: %s' % rom[JMP_ABUELO:JMP_ABUELO + 3].hex()
    assert bytes(rom[ZONA_INI:ZONA_INI + 5]) == HUELLA0

    bloques = []
    print('\n--- maquetado 14x2, formato $3B/$00')
    for k, t in enumerate(TEXTOS):
        li = voraz(t, COLS)
        assert 1 <= len(li) <= 2
        b = bytearray()
        for i, l in enumerate(li):
            if i:
                b.append(NL)
            enc = encode(l)
            assert all(not (0x60 <= x <= 0x8F) for x in enc), \
                '[%d] codigo de diccionario en %r' % (k, l)
            assert 0x00 not in enc and 0x3B not in enc
            assert len(enc) <= COLS
            b += enc
        b.append(FIN)
        bloques.append(bytes(b))
        print('   [%2d] %s' % (k, ' / '.join(li)))

    total = sum(len(b) for b in bloques)
    disponible = ZONA_FIN - ZONA_INI
    print('\nnecesito %d B de %d' % (total, disponible))
    assert total <= disponible

    o = ZONA_INI
    for k, b in enumerate(bloques):
        cpu = o - BANCO24
        assert 0x4000 <= cpu < 0x6000
        rom[TABLA + k * 2] = cpu & 0xFF
        rom[TABLA + k * 2 + 1] = cpu >> 8
        rom[o:o + len(b)] = b
        o += len(b)
    if o < ZONA_FIN:
        rom[o:ZONA_FIN] = bytes([FIN]) * (ZONA_FIN - o)

    rom[JMP_ABUELO:JMP_ABUELO + 3] = JMP_NUEVO

    # desensamblar DESDE la ROM escrita
    dsm = desensambla(bytes(rom), JMP_ABUELO, 3, 0xC8D8)
    print('\n--- $88D8 escrito:', dsm[0][3])
    assert dsm[0][3] == 'JMP $97EE', dsm[0][3]
    assert rom[0x417EE] == 0x20 and rom[0x417EF] == 0x32, \
        '$97EE ya no es JSR $9C32'

    inv = {v: k for k, v in CHAR_TO_CODE.items()}
    print('\n--- releido puntero a puntero')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        end = a
        while rom[end] != FIN:
            end += 1
            assert end < ZONA_FIN + 1
        raw = bytes(rom[a:end])
        partes = raw.split(bytes([NL]))
        got = '/'.join(''.join(inv.get(x, '{%02X}' % x) for x in pte)
                       for pte in partes)
        esperado = '/'.join(voraz(TEXTOS[k], COLS))
        assert got == esperado, '[%d] %r != %r' % (k, got, esperado)
        print('   [%2d] $%04X  %s' % (k, p, got))

    intactas = [
        ('guion 0x48E2A', 0x48E2A, 0x4A484),
        ('fuente', 0x3D660, 0x3E200),
        ('menu RUN $0C', 0x197F2, 0x19FD0),
        ('password $DE69', 0x17E69, 0x17E78),
        ('lista compartida', 0x47C02, 0x47C99),
        ('$9952 (clon, no se toca)', 0x41952, 0x419C4),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas:', ', '.join(n for n, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    ok = set(range(TABLA, TABLA + 46)) | set(range(ZONA_INI, ZONA_FIN)) | \
        set(range(JMP_ABUELO, JMP_ABUELO + 3))
    assert set(dif) <= ok, 'cambios fuera: %s' % [hex(i) for i in dif if i not in ok]
    print('%d bytes sobre la v272' % len(dif))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS round-trip OK (%d B)' % len(parche))
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
