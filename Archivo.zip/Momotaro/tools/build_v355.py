#!/usr/bin/env python3
"""
v355 — intro Fácil 0x3B800 compacta, 17 cols, secuencial.

Base v348 (3B800 JP). El motor lee $00 a $00; las ranuras JP no son
tabla. Ancho medido en pantalla: 17. Sin $5C (ensucia $3BA6) ni $3B.
Tras la intro se pega el staff JP desde 0x3B8AB.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v348.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v355.pce'
IPS = ROOT / 'parches/momotaro_v355.ips'
MD5_BASE = '0c777e44fdf81f924670f732363fe7ee'

CRED = 0x3B800
STAFF_JP = 0x3B8AB
STAFF_END = 0x3BF84
BANK_END = 0x3C000
ANCHO = 17

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC[c] = ord(c)

# David: llenar a 17, no partir palabra, no telegrama
INTRO = [
    '¡Enhorabuena!',
    '¡Gracias!',
    '¡Has terminado',
    'Momotaro en',
    'Acción!',
    'Has demostrado',
    'que cualquiera',
    'puede acabar',
    'este juego.',
    'Permíteme',
    'darte las gracias',
    'otra vez.',
    'Ahora, el equipo',
    'de Momotaro en',
    'Acción.',
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def main():
    for L in INTRO:
        assert 1 <= len(L) <= ANCHO, (len(L), L)
        assert '  ' not in L
    body = b'\x00'.join(enc(L) for L in INTRO) + b'\x00'
    assert 0x5C not in body and 0x3B not in body

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    assert orig[STAFF_JP:STAFF_JP + 4] == rom[STAFF_JP:STAFF_JP + 4]
    cola = bytes(orig[STAFF_JP:STAFF_END])
    blob = body + cola
    assert CRED + len(blob) <= BANK_END
    assert all(b == 0xFF for b in orig[STAFF_END:BANK_END])

    keep = {
        0x4A4B9: bytes(rom[0x4A4B9:0x4A4D0]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 16]),
        0x24DE: bytes(rom[0x24DE:0x24E0]),
        0x216C: bytes(rom[0x216C:0x2174]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
    }

    rom[CRED:CRED + len(blob)] = blob
    rom[CRED + len(blob):BANK_END] = bytes([0xFF] * (BANK_END - CRED - len(blob)))

    assert bytes(rom[CRED:CRED + len(body)]) == body
    assert bytes(rom[CRED + len(body):CRED + len(blob)]) == cola
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    # «que cualquiera» entero
    q = enc('que cualquiera')
    assert q in bytes(rom[CRED:CRED + len(body)])

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v355 OK intro', len(body), 'total', len(blob))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    for L in INTRO:
        print(f'  {len(L):2d} {L}')


if __name__ == '__main__':
    main()
