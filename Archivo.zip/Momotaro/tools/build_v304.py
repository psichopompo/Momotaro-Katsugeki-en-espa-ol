#!/usr/bin/env python3
"""
build_v304.py - tiendas a 16×2 (el motor C6C4 lee 32 bytes, no 20).

v295 empaquetó a 20 columnas. $C6C4 hace 2 filas × 16: la 1ª línea se come
4 de la 2ª y el resto se pierde. Punteros JP intactos; se reescribe in situ
sin pasar del siguiente puntero.

Codificación motor tienda ($9B0B): b=$A2 c=$A3 p=$B0 Ç=$DE.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v303.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v304.pce'
IPS = ROOT / 'parches/momotaro_v304.ips'
MD5_BASE = 'aa92f3fd3679925aebc59d43803d5554'

ENC = {
    ' ': 0xA0, '!': 0x21, '?': 0x3F,
    '¡': 0xCA, '¿': 0xC9, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ñ': 0xC1, 'ó': 0xC5, 'ú': 0xB5,
    'b': 0xA2, 'c': 0xA3, 'p': 0xB0, 'Ç': 0xDE,
    'a': 0xA1, 'd': 0xA4, 'e': 0xA5, 'f': 0xA6, 'g': 0xA7, 'h': 0xA8,
    'i': 0xA9, 'j': 0xAA, 'k': 0xAB, 'l': 0xAC, 'm': 0xAD, 'n': 0xAE,
    'o': 0xAF, 'q': 0xB1, 'r': 0xB2, 's': 0xB3, 't': 0xB4, 'u': 0xB5,
    'v': 0xB6, 'w': 0xB7, 'x': 0xB8, 'y': 0xB9, 'z': 0xBA,
}
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC[c] = ord(c)
for c in '0123456789':
    ENC[c] = ord(c)
ENC[' '] = 0x20  # espacio interior; el pad de fin de línea es $A0


def enc_line(s):
    assert len(s) <= 16, repr(s)
    out = bytearray()
    for ch in s:
        assert ch in ENC, ch
        out.append(ENC[ch])
    out += b'\xA0' * (16 - len(s))
    return bytes(out)


def msg(l1, l2):
    return enc_line(l1) + enc_line(l2)


ITEMS = [
    ('Onigiri:', 'Recupera 1 vida.'),
    ('Manjar:', 'Recupera 1 momo.'),
    ('Banquete:', 'Cura vida y momo'),
    ('Dango:', 'Llama un aliado.'),
    ('Bonzo:', 'Llueven momos.'),
    ('Pedos:', 'Empujas atrás.'),
    ('Solar:', 'Calcina ogros.'),
    ('Glacial:', 'Congela ogros.'),
    ('Raquetas:', 'No resbalas.'),
    ('Capa:', 'Ogros no te ven'),
    ('Aletas:', 'Nadas deprisa.'),
    ('Coraza Roja:', 'Menos daño.'),
    ('Coraza Satsuki:', 'Daño a la mitad'),
    ('Coraza Valor:', 'Daño mínimo.'),
    ('Katana:', 'Más alcance.'),
    ('Espada Byakko:', 'Dispara 2 veces'),
    ('Espada Hiryu:', 'Más alcance.'),
    ('Espada Asura:', 'Dispara 3 veces'),
    ('Espada Fénix:', 'Balas mayores.'),
    ('Espada Valor:', 'Balas mayores.'),
]

# diálogos: (cpu_ptr, linea1, linea2)  — huecos JP ≥32 salvo nota
DIAL = [
    (0x447D, '¡Pasa!', '¿Qué te pongo?'),
    (0x449F, 'Eres mi apoyo.', '¡Confío en ti!'),
    (0x44C0, '¡Gracias!', '¡Vuelve pronto!'),
    (0x44E1, '¡Vaya!', 'No te llega.'),
    (0x4506, 'No hay más arma.', 'Lo siento.'),
    (0x452D, '¡Bienvenido!', '¿Te interesa?'),
    (0x4551, '¿Una coraza?', ''),
    (0x4572, 'Te espero.', '¡Muchas gracias!'),
    (0x4596, '¡Vaya, cliente!', 'Te falta dinero.'),
    (0x45B9, 'No hay mejor.', 'Lo siento.'),
    (0x45DC, '¡Bienvenido!', 'Un manjar.'),
    (0x4600, '¡Muchas gracias!', 'Si no te queda'),
    (0x4625, 'técnica, vuelve.', ''),
    (0x4646, '¡Vaya, cliente!', 'Te falta dinero.'),
    (0x466B, 'No puedo', 'venderte más.'),
    (0x468B, '¡Bienvenido!', '¿Qué va a ser?'),
    (0x46AC, 'No te ha gustado', 'Vuelve otro día.'),
    (0x46D0, '¡Muchas gracias!', 'Vuelve otro día.'),
    (0x46F1, '¡Vaya, cliente!', 'Te falta dinero.'),
    (0x4713, '¡Llevas las', 'manos llenas!'),
    (0x4734, '¡Qué bien verte!', '¿Necesitas algo?'),
    (0x4756, 'Vuelve por aquí.', ''),
]


def cpu_off(p):
    return 0x48000 + (p - 0x4000)


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    titulo = bytes(rom[0x2F8B5:0x2F8C5])
    c5f3 = bytes(rom[0x105F3:0x1060E])
    juego = bytes(rom[0x1F9C4:0x1F9D6])
    assert juego == b'COMIENZA EL JUEGO\x00'
    assert rom[0x47CFB] == 0xFF
    tbl_items = bytes(rom[0x10929:0x10929 + 80])
    tbl_dial = bytes(rom[0x10854:0x108C0])

    occupied = []

    def put(ptr, blob):
        o = cpu_off(ptr)
        occupied.append((o, o + len(blob), ptr))
        rom[o:o + len(blob)] = blob

    # items: 32 B en cada puntero de 0x10929
    for n, (a, b) in enumerate(ITEMS):
        p = rom[0x10929 + n * 4] | (rom[0x10929 + n * 4 + 1] << 8)
        nxt = 0xFFFF
        if n < 19:
            nxt = rom[0x10929 + (n + 1) * 4] | (rom[0x10929 + (n + 1) * 4 + 1] << 8)
        blob = msg(a, b)
        assert len(blob) == 32
        span = (nxt - p) if n < 19 else 64
        assert span >= 32, (n, hex(p), span)
        put(p, blob)
        # releer
        o = cpu_off(p)
        assert rom[o:o + 32] == blob

    for p, a, b in DIAL:
        blob = msg(a, b)
        put(p, blob)

    # no solapes
    occupied.sort()
    for (a1, b1, p1), (a2, b2, p2) in zip(occupied, occupied[1:]):
        assert b1 <= a2, (hex(p1), hex(a1), hex(b1), hex(p2), hex(a2))

    assert bytes(rom[0x10929:0x10929 + 80]) == tbl_items
    assert bytes(rom[0x10854:0x108C0]) == tbl_dial
    assert bytes(rom[0x2F8B5:0x2F8C5]) == titulo
    assert bytes(rom[0x105F3:0x1060E]) == c5f3
    assert bytes(rom[0x1F9C4:0x1F9D6]) == juego
    assert rom[0x47CFB] == 0xFF
    assert rom[0x3DBE8] == 0x00

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.parent.mkdir(exist_ok=True)
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('v304 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('msgs', len(ITEMS) + len(DIAL))


if __name__ == '__main__':
    main()
