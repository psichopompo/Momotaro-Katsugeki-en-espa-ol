#!/usr/bin/env python3
"""
build_v275.py - linea 2 del abuelo + Obtienes + puntuacion.

BASE: v274 (textos ya en $3B/$00, salto a $97EE).

CAUSA
=====
[HECHO] «Ganas 100 ryos» son 14 celdas y llenan el marco: el punto NO
cabe en la misma linea (seria la 15). No esta recortado.

[HECHO] «Coges el» deja hueco a la derecha porque la linea 2 («Onigiri»)
no se pinta. $FFB0 solo suma +2 (1CC -> 1D4) si $368F==2. El camino
del item ($C867 JMP $C8D2) NUNCA escribe $368F: esa marca solo la pone
$C8A8, que es otra ruta. Linea 2 se queda en 1CC, que el abuelo no dibuja.

ARREGLO
=======
Trampolin $DE78 (hueco $FF del banco $0B, detras del password):
    LDA #$02 / STA $368F / JSR $9C32 / JSR $C8DB / JMP $97EE
$C8D2: JMP $DE78

Textos: «Obtienes» (cabe en 14x2) y punto / exclamacion.

Uso:  python3 tools/build_v275.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE, encode          # noqa: E402
from dis6280 import desensambla                            # noqa: E402

BASE = 'roms/momotaro_es_v274.pce'
SALIDA = 'roms/momotaro_es_v275.pce'
IPS = 'parches/momotaro_v275.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'f09491a8b05e4c14cdf9bf82af7a60df'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL, FIN, COLS = 0x3B, 0x00, 14
ZONA_INI, ZONA_FIN = 0x48C7E, 0x48E2A
C8D2 = 0x168D2
TRAMP = 0x17E78
TRAMP_CPU = 0xDE78

# linea1, linea2 o una sola
TEXTOS = [
    ('Obtienes el', 'Onigiri.'),
    ('Obtienes el', 'Manjar.'),
    ('Obtienes el', 'Banquete.'),
    ('Obtienes un', 'Dango.'),
    ('Obtienes los', 'Pedos.'),
    ('Obtienes la', 'Solar.'),
    ('Obtienes la', 'Glacial.'),
    ('Obtienes la', 'Capa.'),
    ('¡100 ryos!',),
    ('¡50 ryos!',),
    ('¡30 ryos!',),
    ('¡10 ryos!',),
    ('No puedes', 'llevar más.'),
    ('El perro te', 'acompaña.'),
    ('El faisán te', 'acompaña.'),
    ('El mono te', 'acompaña.'),
    ('Obtienes el', 'caparazón.'),
    ('Obtienes el', 'Bonzo.'),
    ('¡80 ryos!',),
    ('¡20 ryos!',),
    ('¡Menudo', 'idiota!'),
    ('Sigue hacia', 'arriba.'),
    ('Sigue a la', 'derecha.'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v274 OK')

    assert bytes(rom[C8D2:C8D2 + 9]) == bytes.fromhex('20329c20dbc84cee97'), \
        'C8D2 no es JSR $9C32 / JSR $C8DB / JMP $97EE: %s' % rom[C8D2:C8D2+9].hex()
    assert rom[TRAMP:TRAMP + 20] == b'\xFF' * 20, 'hueco $DE78 no esta libre'
    assert orig[TRAMP:TRAMP + 20] == b'\xFF' * 20

    tramp = bytes([
        0xA9, 0x02,             # LDA #$02
        0x8D, 0x8F, 0x36,       # STA $368F
        0x20, 0x32, 0x9C,       # JSR $9C32
        0x20, 0xDB, 0xC8,       # JSR $C8DB
        0x4C, 0xEE, 0x97,       # JMP $97EE
    ])
    assert len(tramp) == 14
    rom[TRAMP:TRAMP + 14] = tramp
    rom[C8D2:C8D2 + 3] = bytes([0x4C, TRAMP_CPU & 0xFF, TRAMP_CPU >> 8])
    # el resto de C8D2 (6 B) ya no se ejecuta; se deja como estaba

    dsm = desensambla(bytes(rom), C8D2, 3, 0xC8D2)
    print('$C8D2:', dsm[0][3])
    assert dsm[0][3] == 'JMP $DE78'
    dsm = desensambla(bytes(rom), TRAMP, 14, TRAMP_CPU)
    for x in dsm:
        print('  $%04X  %s' % (x[1], x[3]))
    assert [x[3] for x in dsm] == [
        'LDA #$02', 'STA $368F', 'JSR $9C32', 'JSR $C8DB', 'JMP $97EE']

    bloques = []
    print('\n--- textos')
    for k, parts in enumerate(TEXTOS):
        for l in parts:
            assert len(encode(l)) <= COLS, '%r = %d' % (l, len(encode(l)))
            assert all(not (0x60 <= c <= 0x8F) for c in encode(l))
        b = encode(parts[0])
        if len(parts) > 1:
            b += bytes([NL]) + encode(parts[1])
        b += bytes([FIN])
        bloques.append(b)
        print('   [%2d] %s' % (k, ' / '.join(parts)))

    total = sum(len(b) for b in bloques)
    assert total <= ZONA_FIN - ZONA_INI, '%d > %d' % (total, ZONA_FIN - ZONA_INI)
    print('caben %d / %d' % (total, ZONA_FIN - ZONA_INI))

    o = ZONA_INI
    for k, b in enumerate(bloques):
        cpu = o - BANCO24
        rom[TABLA + k * 2] = cpu & 0xFF
        rom[TABLA + k * 2 + 1] = cpu >> 8
        rom[o:o + len(b)] = b
        o += len(b)
    if o < ZONA_FIN:
        rom[o:ZONA_FIN] = bytes([FIN]) * (ZONA_FIN - o)

    inv = {v: k for k, v in CHAR_TO_CODE.items()}
    print('\n--- releido')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        end = a
        while rom[end] != FIN:
            end += 1
        got = '/'.join(
            ''.join(inv.get(x, '{%02X}' % x) for x in pte)
            for pte in bytes(rom[a:end]).split(bytes([NL])))
        exp = '/'.join(TEXTOS[k])
        assert got == exp, '[%d] %r' % (k, got)
        print('   [%2d] $%04X  %s' % (k, p, got))

    intactas = [
        ('guion', 0x48E2A, 0x4A484),
        ('fuente', 0x3D660, 0x3E200),
        ('$FFB0', 0x1FB0, 0x1FC3),
        ('password $DE69', 0x17E69, 0x17E78),
        ('$97EE', 0x417EE, 0x41820),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom
    print('intactas OK')

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    ok = set(range(TABLA, TABLA + 46)) | set(range(ZONA_INI, ZONA_FIN)) | \
        set(range(C8D2, C8D2 + 3)) | set(range(TRAMP, TRAMP + 14))
    extra = [hex(i) for i in dif if i not in ok]
    assert not extra, extra
    print('%d bytes sobre v274' % len(dif))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
