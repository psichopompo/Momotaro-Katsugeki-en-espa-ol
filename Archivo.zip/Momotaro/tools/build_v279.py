#!/usr/bin/env python3
"""
build_v279.py - el BEQ se comia el PLX + Piedra Solar/Glacial.

BASE: v278.

El BEQ $05 caia en $C946 y se SALTABA el PLX de $C945 (el PHX de $C8F9
se quedaba en la pila). Freeze al acabar el minijuego. BEQ $04 -> $C945.

Piedra: «¡Obtienes / Piedra Solar!». «Piedra Glacial!» son 15: sin !.

Uso:  python3 tools/build_v279.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE                  # noqa: E402
from dis6280 import desensambla                            # noqa: E402

BASE = 'roms/momotaro_es_v278.pce'
SALIDA = 'roms/momotaro_es_v279.pce'
IPS = 'parches/momotaro_v279.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'e3bdf5ffdc0f8de93d698b173b98eff4'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL, COLS = 0x3B, 14
ZONA_INI, ZONA_FIN = 0x48C7E, 0x48E2A
C938 = 0x16938

MAP = dict(CHAR_TO_CODE)
MAP['b'] = 0xA2
MAP['c'] = 0xA3
MAP['p'] = 0xB0
IEN = bytes([0xA9, 0xA5, 0xAE])


def enc(s):
    return bytes(MAP[ch] for ch in s).replace(IEN, bytes([0x7C]))


TEXTOS = [
    ('Obtienes el', 'Onigiri'),
    ('Obtienes el', 'Manjar'),
    ('Obtienes el', 'Banquete'),
    ('Obtienes un', 'Dango'),
    ('Obtienes los', 'Pedos'),
    ('¡Obtienes', 'Piedra Solar!'),
    ('¡Obtienes', 'Piedra Glacial'),
    ('Obtienes la', 'Capa'),
    ('¡Obtienes 100', 'ryos!'),
    ('¡Obtienes 50', 'ryos!'),
    ('¡Obtienes 30', 'ryos!'),
    ('¡Obtienes 10', 'ryos!'),
    ('No puedes', 'llevar más.'),
    ('El perro te', 'acompaña'),
    ('El faisán te', 'acompaña'),
    ('El mono te', 'acompaña'),
    ('Obtienes el', 'caparazón.'),
    ('Obtienes el', 'Bonzo.'),
    ('¡Obtienes 80', 'ryos!'),
    ('¡Obtienes 20', 'ryos!'),
    ('¡Menudo', 'idiota!'),
    ('Sigue hacia', 'arriba'),
    ('Sigue a la', 'derecha.'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v278 OK')

    assert rom[C938:C938 + 13] == bytes.fromhex('82bd63c9994736f005e8c880f4')
    rom[C938 + 8] = 0x04  # BEQ +4 -> $C945 PLX
    dsm = desensambla(bytes(rom), C938, 13, 0xC938)
    for x in dsm:
        print('  $%04X  %s' % (x[1], x[3]))
    assert any(t[3] == 'BEQ $C945' for t in dsm), dsm
    assert rom[0x16945] == 0xFA  # PLX intacto
    print('BEQ $C945  OK')

    bloques = []
    for parts in TEXTOS:
        for l in parts:
            assert len(l) <= COLS, l
        b = enc(parts[0])
        if len(parts) > 1:
            b += bytes([NL]) + enc(parts[1])
        b += b'\x00'
        bloques.append(b)
    total = sum(len(b) for b in bloques)
    print('abuelo %d / %d' % (total, ZONA_FIN - ZONA_INI))
    assert total <= ZONA_FIN - ZONA_INI

    o = ZONA_INI
    for k, b in enumerate(bloques):
        cpu = o - BANCO24
        rom[TABLA + k * 2] = cpu & 0xFF
        rom[TABLA + k * 2 + 1] = cpu >> 8
        rom[o:o + len(b)] = b
        o += len(b)
    if o < ZONA_FIN:
        rom[o:ZONA_FIN] = bytes(ZONA_FIN - o)

    inv = {v: k for k, v in MAP.items()}
    inv[0x7C] = 'ien'
    print('--- releido')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        end = a
        while rom[end]:
            end += 1
        got = '/'.join(
            ''.join(inv.get(x, '{%02X}' % x) for x in pte)
            for pte in bytes(rom[a:end]).split(bytes([NL])))
        exp = '/'.join(TEXTOS[k])
        assert got == exp, '[%d] %r' % (k, got)
        print('   [%2d] %s' % (k, got))

    intactas = [
        ('$C951', 0x16951, 0x16969),
        ('Nadie', 0x431B4, 0x431BB),
        ('fuente', 0x3D660, 0x3E200),
        ('0x1F09F', 0x1F09F, 0x1F0B1),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
