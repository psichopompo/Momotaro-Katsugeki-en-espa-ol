#!/usr/bin/env python3
"""
v375 — la columna DERECHA recorta el 12.º glifo. Nombres: 12 izq / 11 der.

Sin $5C. Á en GRÁFICOS. Sin Ó/Ú. Base v362.
Índice par = izquierda (medido: Shoji Masuda entero).
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v362.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v375.pce'
IPS = ROOT / 'parches/momotaro_v375.ips'
MD5_BASE = '311f6adac43ee49af137adda79c23a35'
CRED, BANK_END = 0x3B800, 0x3C000
DD0F, DD43, OGROS = 0x03D0F, 0x03D43, 0x03D7D

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'Á': 0xC2,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

STAFF = [
    ('DIRECCION', 'Shoji', 'Masuda'),      # 0 izq 12
    ('PERSONAJES', 'Takayuki', 'Doi'),     # 1 der 11
    ('PROGRAMADOR', 'Hitoshi', 'Okuno'),
    ('AYUD. PROG.', 'Yasuhiro', 'Kosaka'),
    ('GRÁFICOS', 'Fumie', 'Takaoka'),
    ('GRÁFICOS', 'Atsushi', 'Kakutani'),
    ('GRÁFICOS', 'Kayo', 'Fujimoto'),
    ('SONIDO', 'T.', 'Takimoto'),
    ('SONIDO', 'Keita', 'Hoshi'),
    ('DIRECTOR', 'Shigeki', 'Fujiwara'),
    ('PRODUCCION', 'HUDSON', 'SOFT'),
    ('ASISTENTE', 'H. Iizuka', ''),
    ('ASISTENTE', 'M. Hakuya', ''),
    ('ASISTENTE', 'T. Hattori', ''),
    ('ASISTENTE', 'Hitoshi', 'Araki'),
    ('ASISTENTE', 'S. Kuniyake', ''),
    ('ASISTENTE', 'Hiroshi', 'Izawa'),
    ('ASISTENTE', 'Tomoo Oi', ''),
    ('MUSICA', 'Michiko', 'Yoshida'),
    ('SUPERVISION', 'Akira', 'Sakuma'),    # 19 der
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def nombre(n1, n2, ancho):
    if not n2:
        s = n1
    else:
        s = n1 + ' ' + n2
        if len(s) > ancho:
            s = n1[0] + '. ' + n2
    assert 1 <= len(s) <= ancho, (n1, n2, s, ancho)
    return s


def block(i, cargo, n1, n2):
    ancho = 12 if (i % 2 == 0) else 11
    assert 1 <= len(cargo) <= 12, cargo
    pad = bytes([0xA0] * (12 - len(cargo)))
    return enc(cargo) + pad + enc(nombre(n1, n2, ancho)) + b'\x00'


def main():
    blks = []
    for i, t in enumerate(STAFF):
        for ch in t[0] + nombre(t[1], t[2], 12 if i % 2 == 0 else 11):
            assert ch in ENC, ch
        blks.append(block(i, *t))
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    easy_end = CRED
    while rom[easy_end] != 0xFF:
        easy_end += 1
    easy_head = bytes(rom[CRED:CRED + 16])
    keep = {
        OGROS: bytes(rom[OGROS:OGROS + 16]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x3277: bytes(rom[0x3277:0x32A8]),
        0x3BA2: bytes(rom[0x3BA2:0x3BA8]),
    }
    pos = (easy_end + 2) & ~1
    ptrs = []
    for b in blks:
        assert 0x5C not in b
        assert pos + len(b) <= BANK_END
        rom[pos:pos + len(b)] = b
        ptrs.append(0x5800 + (pos - CRED))
        pos += len(b)
    raw = b''.join(bytes([p & 0xFF, p >> 8]) for p in ptrs) + b'\x00\x00'
    assert DD0F + len(raw) <= DD43
    assert DD43 + len(raw) <= OGROS
    rom[DD0F:DD0F + len(raw)] = raw
    rom[DD43:DD43 + len(raw)] = raw
    assert bytes(rom[CRED:CRED + 16]) == easy_head
    assert enc('T. Doi') in bytes(rom)
    assert enc('A. Sakuma') in bytes(rom)
    assert enc('Shoji Masuda') in bytes(rom)
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    d = bytes(rom)
    SALIDA.write_bytes(d)
    rec, i, difv = [], 0, [j for j in range(len(d)) if d[j] != orig[j]]
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v375 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
