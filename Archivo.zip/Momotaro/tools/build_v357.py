#!/usr/bin/env python3
"""
v357 — Toma: ¡+ART; Equipo HUDSON 1 línea; Jizo «¿Así que partes».

Base v356. $00 del premio 0x4B824 INTOCABLE (inserción).
Jizo: +1 B, sobra un $00 de cola.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v356.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v357.pce'
IPS = ROOT / 'parches/momotaro_v357.ips'
MD5_BASE = '35c0846f8293b0e2094b149c31120938'


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    # --- Toma: ¡  (robar un $A0, $00 fijo en 0x4B824)
    assert rom[0x4B824] == 0x00
    pref = bytes(rom[0x4B80E:0x4B825])
    # ¡Bien hecho! (12) + 4 A0 + Toma: space + 00
    assert pref.endswith(bytes.fromhex('54afada1cd2000'))
    assert pref[12:16] == bytes([0xA0] * 4)
    rom[0x4B81A:0x4B825] = bytes([0xA0] * 3) + bytes.fromhex('54afada1cd20ca00')
    assert rom[0x4B824] == 0x00
    assert rom[0x4B823] == 0xCA

    # --- Equipo HUDSON. en una línea (13+pad = 11+1+7)
    pos = 0x4A5E5
    old = bytes(rom[pos:pos + 19])
    assert old == bytes.fromhex('45ac20a5b1b5a9b0af20203b48b5a4b3afaecb')
    ENC = {**{c: ord(c) for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'},
           ' ': 0x20, '.': 0xCB, 'e': 0xA5, 'q': 0xB1, 'u': 0xB5,
           'i': 0xA9, 'p': 0xB0, 'o': 0xAF}
    raw = bytes(ENC[c] for c in 'Equipo HUDSON.')
    assert len(raw) == 14
    rom[pos:pos + 19] = raw + bytes([0x20] * 5)
    assert rom[pos + 19:pos + 21] == bytes([0x01, 0x02])

    # --- Jizo: Con→Así (4=4). «a» sigue en la 2.ª línea.
    oldj = bytes.fromhex('c943afae')
    newj = bytes.fromhex('c941b3bd')  # ¿Así
    j0 = 0x48E2A
    i = bytes(rom[j0:0x48F16]).index(oldj)
    rom[j0 + i:j0 + i + 4] = newj
    assert bytes(rom[j0 + i:j0 + i + 4]) == newj

    keep = {
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x1ED76: bytes(rom[0x1ED76:0x1ED7C]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 8]),
    }
    assert all(rom[0x4AD56:0x4AD76][k] == 0x20 for k in range(32))

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v357 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
