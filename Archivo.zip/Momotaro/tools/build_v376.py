#!/usr/bin/env python3
"""
v376 — DIRECCIÓN (kantoku) / DESARROLLO (ディレクター) + Ó/Ú en las dos fuentes.

Masuda = ゲームカントク. Fujiwara = ディレクター.
Glifos $C5/$C6 en diálogo 1bpp y menú 2bpp. Sin $5C. 12/11. Base v362.
"""
import hashlib
import sys
import zlib
from pathlib import Path

sys.path.insert(0, '/home/user/Momotaro/tools')
from fuente_menu import encode as enc_menu, rom_off as menu_off
from glifos_es import GLIFOS, encode as enc_1bpp

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v362.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v376.pce'
IPS = ROOT / 'parches/momotaro_v376.ips'
MD5_BASE = '311f6adac43ee49af137adda79c23a35'
CRED, BANK_END = 0x3B800, 0x3C000
DD0F, DD43, OGROS = 0x03D0F, 0x03D43, 0x03D7D
DIAL = 0x3D660

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'Á': 0xC2, 'Ó': 0xC5, 'Ú': 0xC6,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

STAFF = [
    ('DIRECCIÓN', 'Shoji', 'Masuda'),
    ('PERSONAJES', 'Takayuki', 'Doi'),
    ('PROGRAMADOR', 'Hitoshi', 'Okuno'),
    ('AYUD. PROG.', 'Yasuhiro', 'Kosaka'),
    ('GRÁFICOS', 'Fumie', 'Takaoka'),
    ('GRÁFICOS', 'Atsushi', 'Kakutani'),
    ('GRÁFICOS', 'Kayo', 'Fujimoto'),
    ('SONIDO', 'T.', 'Takimoto'),
    ('SONIDO', 'Keita', 'Hoshi'),
    ('DESARROLLO', 'Shigeki', 'Fujiwara'),
    ('PRODUCCIÓN', 'HUDSON', 'SOFT'),
    ('ASISTENTE', 'H. Iizuka', ''),
    ('ASISTENTE', 'M. Hakuya', ''),
    ('ASISTENTE', 'T. Hattori', ''),
    ('ASISTENTE', 'Hitoshi', 'Araki'),
    ('ASISTENTE', 'S. Kuniyake', ''),
    ('ASISTENTE', 'Hiroshi', 'Izawa'),
    ('ASISTENTE', 'Tomoo Oi', ''),
    ('MÚSICA', 'Michiko', 'Yoshida'),
    ('SUPERVISIÓN', 'Akira', 'Sakuma'),
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def nombre(n1, n2, ancho):
    if not n2:
        s = n1
    else:
        s = n1 + ' ' + n2
        if len(s) > ancho:
            s = n1[0] + '. ' + n2
    assert 1 <= len(s) <= ancho, (n1, n2, s, ancho)
    return s


def block(i, cargo, n1, n2):
    ancho = 12 if (i % 2 == 0) else 11
    assert 1 <= len(cargo) <= 12, cargo
    pad = bytes([0xA0] * (12 - len(cargo)))
    return enc(cargo) + pad + enc(nombre(n1, n2, ancho)) + b'\x00'


def instala_glifos(rom):
    for nom, byte in (('O_acute', 0xC5), ('U_acute', 0xC6)):
        g1 = enc_1bpp(GLIFOS[nom])
        d_off = DIAL + byte * 8
        rom[d_off:d_off + 8] = g1
        g2 = enc_menu(GLIFOS[nom])
        m_off = menu_off(byte)
        assert 0x4000 <= m_off < 0x4AD00
        rom[m_off:m_off + 16] = g2


def main():
    for t in STAFF:
        assert len(t[0]) <= 12, (t[0], len(t[0]))
    blks = []
    for i, t in enumerate(STAFF):
        for ch in t[0] + nombre(t[1], t[2], 12 if i % 2 == 0 else 11):
            assert ch in ENC, ch
        blks.append(block(i, *t))
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    easy_end = CRED
    while rom[easy_end] != 0xFF:
        easy_end += 1
    easy_head = bytes(rom[CRED:CRED + 16])
    keep = {
        OGROS: bytes(rom[OGROS:OGROS + 16]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x3277: bytes(rom[0x3277:0x32A8]),
        0x3BA2: bytes(rom[0x3BA2:0x3BA8]),
    }
    instala_glifos(rom)
    pos = (easy_end + 2) & ~1
    ptrs = []
    for b in blks:
        assert 0x5C not in b
        assert pos + len(b) <= BANK_END
        rom[pos:pos + len(b)] = b
        ptrs.append(0x5800 + (pos - CRED))
        pos += len(b)
    raw = b''.join(bytes([p & 0xFF, p >> 8]) for p in ptrs) + b'\x00\x00'
    assert DD0F + len(raw) <= DD43
    assert DD43 + len(raw) <= OGROS
    rom[DD0F:DD0F + len(raw)] = raw
    rom[DD43:DD43 + len(raw)] = raw
    assert bytes(rom[CRED:CRED + 16]) == easy_head
    assert enc('DIRECCIÓN') in bytes(rom)
    assert enc('DESARROLLO') in bytes(rom)
    assert enc('MÚSICA') in bytes(rom)
    assert bytes(rom[DIAL + 0xC5 * 8:DIAL + 0xC5 * 8 + 8]) == enc_1bpp(GLIFOS['O_acute'])
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    d = bytes(rom)
    SALIDA.write_bytes(d)
    rec, i, difv = [], 0, [j for j in range(len(d)) if d[j] != orig[j]]
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v376 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
