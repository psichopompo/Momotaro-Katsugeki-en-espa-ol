#!/usr/bin/env python3
"""
build_v273.py - los 23 textos del abuelo, sobre la v272.

POR QUE
=======
David: los bocadillos ya se ven bien; quiere ver las frases. Si sale mal
se revierte a la v272.

La v232 ya inserto estos textos y se revirtio porque la linea 2 no se
veia. Ahora la geometria esta validada (v231 en adelante). Solo se tocan
tabla $C969 y la zona 0x48C7E..0x48E2A.

LIMITE DURO
===========
En la v272 el guion castellano empieza en 0x48E2A (primer diff vs virgen
en este bloque: AC -> CA). NO se escribe ahi ni mas alla.

FORMATO, MEDIDO (entrada 149 / v232)
====================================
Tabla $C969 -> ROM 0x16969, 23 punteros. Banco $24 en $4000:
    ROM = 0x48000 - 0x4000 + puntero
Separador de linea y cierre de cadena: $A0 (NO $3B ni $00).
Ancho 14, maximo 2 lineas.

TEXTOS
======
Nombres del menu (David). Moneda ryo/ryos. Bakamon -> ¡Menudo idiota!
Tildes que el charset ya tiene: más, acompaña, faisán, caparazón.

Uso:  python3 tools/build_v273.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE, encode          # noqa: E402

BASE = 'roms/momotaro_es_v272.pce'
SALIDA = 'roms/momotaro_es_v273.pce'
IPS = 'parches/momotaro_v273.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '3043e0bdeffaae160e295b95c9400e4e'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL = 0xA0
COLS = 14
ZONA_INI = 0x48C7E
ZONA_FIN = 0x48E2A          # exclusivo: ahi empieza el guion

# Huella del primer texto japones (karada no...)
HUELLA0 = bytes.fromhex('b6d7dec0c9')

TEXTOS = [
    'Coges el Onigiri',
    'Coges el Manjar',
    'Coges el Banquete',
    'Coges un Dango',
    'Coges los Pedos',
    'Coges la Solar',
    'Coges la Glacial',
    'Coges la Capa',
    'Ganas 100 ryos',
    'Ganas 50 ryos',
    'Ganas 30 ryos',
    'Ganas 10 ryos',
    'No puedes llevar más',
    'El perro te acompaña',
    'El faisán te acompaña',
    'El mono te acompaña',
    'Coges el caparazón',
    'Coges el Bonzo',
    'Ganas 80 ryos',
    'Ganas 20 ryos',
    '¡Menudo idiota!',
    'Sigue hacia arriba',
    'Sigue a la derecha',
]


def voraz(t, c):
    out, cur = [], ''
    for w in t.split():
        if not cur:
            cur = w
        elif len(cur) + 1 + len(w) <= c:
            cur += ' ' + w
        else:
            out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    return out


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE, 'la base no es la v272'
    print('base %s  OK' % BASE)

    ptrs = [rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
            for k in range(23)]
    assert BANCO24 + ptrs[0] == ZONA_INI
    assert bytes(rom[ZONA_INI:ZONA_INI + 5]) == HUELLA0, \
        'en 0x48C7E no esta el primer texto japones'
    assert rom[ZONA_FIN] == base[ZONA_FIN], 'ZONA_FIN ya distinta?'
    disponible = ZONA_FIN - ZONA_INI
    print('zona: ROM 0x%05X..0x%05X = %d B (el 0x48E2A no se toca)'
          % (ZONA_INI, ZONA_FIN, disponible))

    bloques = []
    print('\n--- maquetado 14x2')
    for k, t in enumerate(TEXTOS):
        li = voraz(t, COLS)
        assert len(li) <= 2, '[%d] %r necesita %d lineas' % (k, t, len(li))
        for l in li:
            assert len(encode(l)) <= COLS, '[%d] linea %r = %d' % (
                k, l, len(encode(l)))
        b = bytearray()
        for i, l in enumerate(li):
            if i:
                b.append(NL)
            b += encode(l)
        bloques.append(bytes(b))
        print('   [%2d] %s' % (k, ' / '.join(li)))

    total = sum(len(b) + 1 for b in bloques)
    print('\nnecesito %d B de %d' % (total, disponible))
    assert total <= disponible, 'no caben'

    o = ZONA_INI
    for k, b in enumerate(bloques):
        cpu = o - BANCO24
        assert 0x4000 <= cpu < 0x6000, 'puntero fuera de MPR2'
        rom[TABLA + k * 2] = cpu & 0xFF
        rom[TABLA + k * 2 + 1] = cpu >> 8
        rom[o:o + len(b)] = b
        o += len(b)
        rom[o] = NL
        o += 1
    if o < ZONA_FIN:
        rom[o:ZONA_FIN] = bytes([NL]) * (ZONA_FIN - o)
    print('escritos %d B, relleno %d B' % (total, ZONA_FIN - o))
    assert o <= ZONA_FIN

    # releer PUNTERO A PUNTERO (no el while de la v232, que mentia)
    inv = {v: k for k, v in CHAR_TO_CODE.items()}
    print('\n--- releido puntero a puntero')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        b = BANCO24 + (rom[TABLA + (k + 1) * 2] |
                       (rom[TABLA + (k + 1) * 2 + 1] << 8)) if k < 22 \
            else ZONA_FIN
        raw = bytes(rom[a:b])
        # quitar $A0 de relleno al final
        while raw.endswith(bytes([NL])):
            raw = raw[:-1]
        partes = raw.split(bytes([NL]))
        got = '/'.join(
            ''.join(inv.get(x, '{%02X}' % x) for x in pte) for pte in partes)
        esperado = '/'.join(voraz(TEXTOS[k], COLS))
        assert got == esperado, '[%d] leido %r esperado %r' % (k, got, esperado)
        print('   [%2d] $%04X  %s' % (k, p, got))

    intactas = [
        ('guion desde 0x48E2A', 0x48E2A, 0x4A484),
        ('fuente', 0x3D660, 0x3E200),
        ('menu RUN $0C', 0x197F2, 0x19FD0),
        ('menu RUN $21', 0x431AC, 0x431EB),
        ('password $DE69', 0x17E69, 0x17E78),
        ('lista compartida', 0x47C02, 0x47C99),
        ('tabla $9BBD', 0x41BBD, 0x41C05),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], 'se ha tocado %s' % nom
    print('\nintactas: %s' % ', '.join(x for x, _, _ in intactas))

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    assert all(TABLA <= i < TABLA + 46 or ZONA_INI <= i < ZONA_FIN
               for i in dif), 'cambios fuera de tabla/textos'
    print('%d bytes sobre la v272, solo tabla + zona' % len(dif))

    open(SALIDA, 'wb').write(d)

    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d, 'el IPS no reproduce la ROM'
    print('IPS round-trip OK (%d B)' % len(parche))

    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
