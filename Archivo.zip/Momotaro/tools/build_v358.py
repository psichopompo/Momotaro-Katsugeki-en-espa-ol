#!/usr/bin/env python3
"""
v358 — Toma en 2 líneas ($80); «Así que» con espacio (+1 B).

Base v357. $00 premio 0x4B824 fijo.
Jizo: +1 en los $00 de cola; no se pisa el $42 del diálogo siguiente.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v357.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v358.pce'
IPS = ROOT / 'parches/momotaro_v358.ips'
MD5_BASE = '37d1452426ee2981f33f7873f5f83e51'


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE

    # Toma: 12 + $80 + Toma: ¡ + $A0*2 + $00  (22+00, $00 @ 4B824)
    assert rom[0x4B824] == 0x00
    assert rom[0x4B80E:0x4B81A] == bytes.fromhex('ca42a9a5ae20a8a5a3a8af21')  # ¡Bien hecho!
    rom[0x4B81A:0x4B825] = bytes.fromhex('8054afada1cd20caa0a000')
    assert rom[0x4B824] == 0x00
    assert rom[0x4B81A] == 0x80
    assert rom[0x4B823] == 0xA0

    # Jizo +1: ¿Así que partes a|
    oldj = bytes.fromhex('c941b3bd6120b0a1b2b472a13b')
    newj = bytes.fromhex('c941b3bd206120b0a1b2b472a13b')
    assert len(newj) == len(oldj) + 1
    j0 = 0x48E2A
    blob = bytes(rom[j0:0x48F18])
    i = blob.index(oldj)
    assert rom[0x48F15] == 0 and rom[0x48F16] == 0 and rom[0x48F17] == 0
    assert rom[0x48F18] == 0x42
    # desplazar 1 B hacia los $00 extra; el $42 no se toca
    end = 0x48F16  # primer $00 terminador
    tail = bytes(rom[j0 + i + len(oldj):end])
    packed = newj + tail  # +1
    assert len(packed) == (end - (j0 + i)) + 1
    rom[j0 + i:end + 1] = packed
    assert rom[0x48F16] == packed[-1]
    assert rom[0x48F17] == 0x00
    assert rom[0x48F18] == 0x42
    assert oldj not in bytes(rom[j0:0x48F18])

    assert all(rom[0x4AD56 + k] == 0x20 for k in range(32))
    assert rom[0x1ED76:0x1ED7C] == orig[0x1ED76:0x1ED7C] or True
    # scene table vs v357 not virgen
    v357 = BASE.read_bytes()
    assert rom[0x1ED76:0x1ED80] == v357[0x1ED76:0x1ED80]

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v358 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
