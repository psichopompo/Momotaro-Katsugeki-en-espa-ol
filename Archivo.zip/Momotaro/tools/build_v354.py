#!/usr/bin/env python3
"""
v354 — intro Fácil bloques 7..18. Base v353 (0-6 ya ES).

Sin $5C ni $3B. Pad $20. Ranuras cortas:
  7 10  «puede»          (puede acabar = 12)
  8 11  «acabar.»
  9 17  «este juego.»
 10  4  (blanco: 4×$20; «otra vez.» no cabe)
 11 15  «Permíteme»
 12 15  «darte las»      (darte las gracias = 17)
 13 14  «gracias»
 14 15  «otra vez.»
 15 17  «Ahora,»
 16 12  «el equipo de»
 17 17  «Momotaro en»
 18 12  «Acción.»
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v353.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v354.pce'
IPS = ROOT / 'parches/momotaro_v354.ips'
MD5_BASE = 'a35cbc2a6189d346dad32f33d5d2afce'

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC[c] = ord(c)


def enc(s):
    return bytes(ENC[ch] for ch in s)


# medido en JP
BLOQUES = [
    (0x3B87D, 10, 'puede'),
    (0x3B888, 11, 'acabar.'),
    (0x3B894, 17, 'este juego.'),
    (0x3B8A6, 4, ''),
    (0x3B8AB, 15, 'Permíteme'),
    (0x3B8BB, 15, 'darte las'),
    (0x3B8CB, 14, 'gracias'),
    (0x3B8DA, 15, 'otra vez.'),
    (0x3B8EA, 17, 'Ahora,'),
    (0x3B8FC, 12, 'el equipo de'),
    (0x3B909, 17, 'Momotaro en'),
    (0x3B91B, 12, 'Acción.'),
]


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    head = bytes(rom[0x3B800:0x3B87D])
    after = 0x3B91B + 12
    tail = bytes(rom[after:after + 8])
    assert rom[after] == 0x00

    zeros = []
    for off, slot, s in BLOQUES:
        raw = enc(s)
        assert len(raw) <= slot, (s, len(raw), slot)
        assert 0x5C not in raw and 0x3B not in raw
        assert rom[off + slot] == 0, hex(off + slot)
        zeros.append(off + slot)
        rom[off:off + slot] = raw + bytes([0x20] * (slot - len(raw)))

    assert bytes(rom[0x3B800:0x3B87D]) == head
    for z in zeros:
        assert rom[z] == 0
    assert bytes(rom[after:after + 8]) == tail

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v354 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
