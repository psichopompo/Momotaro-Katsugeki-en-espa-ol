#!/usr/bin/env python3
"""
v352 — intro 0x3B800 sin $5C (sucia $3BA6: n→C, l→B).

Base v350 (0-1 buenos). Bloques:
2 0x3B824 19  ¡Has terminado
3 0x3B838 21  Momotaro en
4 0x3B84E 14  Acción!
5 0x3B85D 18  Has demostrado
6 0x3B870 12  cualquiera
«que cualquiera»=14 > 12. Cero $5C, cero $3B.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v350.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v352.pce'
IPS = ROOT / 'parches/momotaro_v352.ips'
MD5_BASE = '6de0ed0c25fa5dd2c3fc47d767b8b268'

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC[c] = ord(c)


def enc(s):
    return bytes(ENC[ch] for ch in s)


BLOQUES = [
    (0x3B824, 19, '¡Has terminado'),
    (0x3B838, 21, 'Momotaro en'),
    (0x3B84E, 14, 'Acción!'),
    (0x3B85D, 18, 'Has demostrado'),
    (0x3B870, 12, 'cualquiera'),
]


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    keep01 = bytes(rom[0x3B800:0x3B824])
    z = [0x3B80F, 0x3B823, 0x3B837, 0x3B84D, 0x3B85C, 0x3B86F, 0x3B87C]
    for off in z:
        assert rom[off] == 0

    for off, slot, s in BLOQUES:
        raw = enc(s)
        assert len(raw) <= slot, (s, len(raw), slot)
        assert 0x5C not in raw and 0x3B not in raw
        rom[off:off + slot] = raw + bytes([0x20] * (slot - len(raw)))
        assert rom[off + slot] == 0

    assert bytes(rom[0x3B800:0x3B824]) == keep01
    for off in z:
        assert rom[off] == 0

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v352 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
