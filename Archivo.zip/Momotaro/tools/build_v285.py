#!/usr/bin/env python3
"""
build_v285.py - el 2o byte $DE/$DF saltaba el dibujo del password GO.

$D73F: INY / LDA ($BF),Y. Si el 2o byte es $DE/$DF trata dakuten y
NO pinta el codigo latino. La v284 solo reescribio el 1er byte.

Uso:  python3 tools/build_v285.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE                  # noqa: E402

BASE = 'roms/momotaro_es_v284.pce'
SALIDA = 'roms/momotaro_es_v285.pce'
IPS = 'parches/momotaro_v285.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'e0569a27654a11f6e22a049affcd03ba'

TAB = 0x1F7B6
CHARS = 'ABCDEFGabcdefgHIJKLMNhijklmnÑOPQRSTñopqrstUVWXYZuvwxyz0123456789'
MAP = dict(CHAR_TO_CODE)
MAP['b'] = 0xA2
MAP['c'] = 0xA3
MAP['p'] = 0xB0


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    assert rom[0x1B9EE + 3] == 0x3A  # DEC A de la v284
    codes = bytes(MAP[ch] for ch in CHARS)
    assert rom[TAB] == codes[0]
    n_de = 0
    for i, c in enumerate(codes):
        assert rom[TAB + i * 2] == c
        if rom[TAB + i * 2 + 1] in (0xDE, 0xDF):
            n_de += 1
        rom[TAB + i * 2 + 1] = 0x20
    print('limpiados %d dakuten/handakuten' % n_de)
    assert n_de >= 15
    assert rom[0x1F836] == base[0x1F836]  # prompt Cargar

    intactas = [
        ('1F72D', 0x1F72D, 0x1F739),
        ('CAD6', 0x16AD6, 0x16B16),
        ('D9EE', 0x1B9EE, 0x1B9F6),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
