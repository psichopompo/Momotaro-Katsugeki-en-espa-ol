#!/usr/bin/env python3
"""
v356 — intro Fácil rellena a 17; staff→equipo; quiz isla; Toma: ¡+

Base v355.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v355.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v356.pce'
IPS = ROOT / 'parches/momotaro_v356.ips'
MD5_BASE = '0c94aa7a544114cdbda266071196bb12'

CRED, STAFF_JP, STAFF_END, BANK_END = 0x3B800, 0x3B8AB, 0x3BF84, 0x3C000
ANCHO = 17

ENC_CRED = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC_CRED.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC_CRED[c] = ord(c)

ENC_C190 = dict(ENC_CRED)
ENC_C190['p'] = 0xB0
ENC_C190['b'] = 0xA2
ENC_C190['c'] = 0xA3
ENC_C190['ó'] = 0xC5

ENC_Q = dict(ENC_C190)  # quiz/ermitaño: p directo

INTRO = [
    '¡Enhorabuena!',
    '¡Gracias!',
    '¡Has terminado',
    'Momotaro en',
    'Acción!',
    'Has demostrado',
    'que cualquiera',
    'puede acabar',
    'este juego.',
    'Permíteme darte',
    'las gracias otra',
    'vez.',
    'Ahora, el equipo',
    'de Momotaro en',
    'Acción.',
]


def enc(s, m):
    return bytes(m[ch] for ch in s)


def main():
    for L in INTRO:
        assert 1 <= len(L) <= ANCHO, (len(L), L)
    body = b'\x00'.join(enc(L, ENC_CRED) for L in INTRO) + b'\x00'
    assert 0x5C not in body and 0x3B not in body

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    cola = bytes(orig[STAFF_JP:STAFF_END])
    blob = body + cola
    assert CRED + len(blob) <= BANK_END
    rom[CRED:CRED + len(blob)] = blob
    rom[CRED + len(blob):BANK_END] = bytes([0xFF] * (BANK_END - CRED - len(blob)))

    # staff → equipo (misma longitud 12, $C190)
    # «El staff de»=11; «El equipo de»=12. Sin desplazar: «El equipo  »
    old = enc('El staff de', ENC_C190)
    new = enc('El equipo', ENC_C190) + b'\x20\x20'
    assert len(old) == len(new) == 11
    pos = rom.find(old)
    assert pos == 0x4A5E5, hex(pos)
    rom[pos:pos + 11] = new
    assert rom.find(old) < 0

    # isla: dos celdas de 16 en 0x4AD9A
    l1 = enc('¡Ve a la isla de', ENC_Q)
    l2 = enc('los ogros!', ENC_Q)
    assert len(l1) == 16
    assert len(l2) == 10
    assert rom[0x4AD9A:0x4AD9A + 13] == enc('¡Ve a la isla', ENC_Q)
    rom[0x4AD9A:0x4ADAA] = l1
    rom[0x4ADAA:0x4ADBC] = l2 + bytes([0xA0] * 8)
    assert rom[0x4ADBC] == 0xCA  # ¡Aún

    # Toma: ¡  ($FF de cierre no se mueve)
    assert rom[0x4AE01:0x4AE0A] == bytes.fromhex('54afada1cd20a0a0ff')
    rom[0x4AE01:0x4AE0A] = bytes.fromhex('54afada1cd20caa0ff')  # Toma: ¡ · FF
    assert rom[0x4AE09] == 0xFF

    keep = {
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 8]),
        0x24DE: bytes(rom[0x24DE:0x24E0]),
    }
    # limpiador sigue $20
    assert all(b == 0x20 for b in rom[0x4AD56:0x4AD76])

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v356 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
