#!/usr/bin/env python3
"""
v372 — tras $5C, $3BA6=1: j/l/n/z → A/B/C/D. Codificar al revés.

Cargos ANTES de $5C (limpios): tildes Á/Ó/Ú.
Nombres: mapa sucio. Ancho 12; si no caben, inicial.
Base v362. Tablas $DD0F/$DD43.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v362.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v372.pce'
IPS = ROOT / 'parches/momotaro_v372.ips'
MD5_BASE = '311f6adac43ee49af137adda79c23a35'
CRED, BANK_END = 0x3B800, 0x3C000
DD0F, DD43, OGROS = 0x03D0F, 0x03D43, 0x03D7D
ANCHO = 12

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

# $3BA6=1: el motor pinta j/l/n/z como A/B/C/D. Escribir A/B/C/D para ver j/l/n/z.
SUCIO = dict(ENC)
SUCIO['j'] = ord('A')
SUCIO['l'] = ord('B')
SUCIO['n'] = ord('C')
SUCIO['z'] = ord('D')

STAFF = [
    ('DIRECCIÓN', 'Shoji', 'Masuda'),
    ('PERSONAJES', 'Takayuki', 'Doi'),
    ('PROGRAMADOR', 'Hitoshi', 'Okuno'),
    ('AYUD. PROG.', 'Yasuhiro', 'Kosaka'),
    ('GRÁFICOS', 'Fumie', 'Takaoka'),
    ('GRÁFICOS', 'Atsushi', 'Kakutani'),
    ('GRÁFICOS', 'Kayo', 'Fujimoto'),
    ('SONIDO', 'T.', 'Takimoto'),
    ('SONIDO', 'Keita', 'Hoshi'),
    ('DIRECTOR', 'Shigeki', 'Fujiwara'),
    ('PRODUCCIÓN', 'HUDSON', 'SOFT'),
    ('ASISTENTE', 'H. Iizuka', ''),
    ('ASISTENTE', 'M. Hakuya', ''),
    ('ASISTENTE', 'T. Hattori', ''),
    ('ASISTENTE', 'Hitoshi', 'Araki'),
    ('ASISTENTE', 'S. Kuniyake', ''),
    ('ASISTENTE', 'Hiroshi', 'Izawa'),
    ('ASISTENTE', 'Tomoo Oi', ''),
    ('MÚSICA', 'Michiko', 'Yoshida'),
    ('SUPERVISIÓN', 'Akira', 'Sakuma'),
]


def enc(s, m=ENC):
    return bytes(m[ch] for ch in s)


def nombre(n1, n2):
    if not n2:
        s = n1
    else:
        s = n1 + ' ' + n2
        if len(s) > ANCHO:
            s = n1[0] + '. ' + n2
    assert 1 <= len(s) <= ANCHO, (n1, n2, s)
    return s


def block(cargo, n1, n2):
    assert 1 <= len(cargo) <= ANCHO, cargo
    pad = bytes([0xA0] * (ANCHO - len(cargo)))
    return enc(cargo) + pad + bytes([0x5C]) + enc(nombre(n1, n2), SUCIO) + b'\x00'


def main():
    for c, n1, n2 in STAFF:
        for ch in c:
            assert ch in ENC, ch
        for ch in nombre(n1, n2):
            assert ch in SUCIO, ch
    blks = [block(*t) for t in STAFF]
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    assert rom[0x3BA2:0x3BA8] == bytes.fromhex('a90085bfa958')
    easy_end = CRED
    while rom[easy_end] != 0xFF:
        easy_end += 1
    easy_head = bytes(rom[CRED:CRED + 16])
    keep = {
        OGROS: bytes(rom[OGROS:OGROS + 16]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x3277: bytes(rom[0x3277:0x32A8]),
    }
    pos = (easy_end + 2) & ~1
    ptrs = []
    for b in blks:
        assert pos + len(b) <= BANK_END
        rom[pos:pos + len(b)] = b
        ptrs.append(0x5800 + (pos - CRED))
        pos += len(b)
    raw = b''.join(bytes([p & 0xFF, p >> 8]) for p in ptrs) + b'\x00\x00'
    assert DD0F + len(raw) <= DD43
    assert DD43 + len(raw) <= OGROS
    rom[DD0F:DD0F + len(raw)] = raw
    rom[DD43:DD43 + len(raw)] = raw
    assert bytes(rom[CRED:CRED + 16]) == easy_head
    assert rom[easy_end] == 0xFF
    p0 = rom[DD0F] | (rom[DD0F + 1] << 8)
    off0 = CRED + (p0 - 0x5800)
    assert rom[off0:off0 + 9] == enc('DIRECCIÓN')
    # nombre Shoji: j→A
    assert rom[off0 + ANCHO] == 0x5C
    assert rom[off0 + ANCHO + 1 + 3] == ord('A')  # j de Shoji
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    d = bytes(rom)
    SALIDA.write_bytes(d)
    rec, i, difv = [], 0, [j for j in range(len(d)) if d[j] != orig[j]]
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v372 OK first', hex(ptrs[0]))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
