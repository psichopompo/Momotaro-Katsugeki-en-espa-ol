#!/usr/bin/env python3
"""
build_v339.py — posada L2 + punto en perro/faisán/mono.

Base v338. Tres cadenas de aliado: misma longitud (te→va, acompaña→contigo.).
Posada $4834 línea 2: «A por los ogros.» (16 B justos).
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v338.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v339.pce'
IPS = ROOT / 'parches/momotaro_v339.ips'
MD5_BASE = 'dd7cf0125e17ee27617c9c98b610e9de'

# shop/vitores
TE = bytes([0xB4, 0xA5])
VA = bytes([0xB6, 0xA1])
ACOMP = bytes([0xA1, 0xA3, 0xAF, 0xAD, 0xB0, 0xA1, 0xC1, 0xA1])  # acompaña
CONTI = bytes([0xA3, 0xAF, 0xAE, 0xB4, 0xA9, 0xA7, 0xAF, 0xCB])  # contigo.


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    keep = {
        0x2F8B5: bytes(rom[0x2F8B5:0x2F8C5]),
        0x105F3: bytes(rom[0x105F3:0x1060E]),
        0x1F881: bytes(rom[0x1F881:0x1F89E]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x47CFB: bytes([rom[0x47CFB]]),
    }

    # --- posada $4834 L2 ---
    inn = 0x48834
    assert rom[inn:inn + 16] == bytes.fromhex('ca42b5a5aeafb320a4bda1b321a0a0a0')
    assert rom[inn + 16:inn + 32] == bytes.fromhex('ca4120b0afb220acafb3a0a0a0a0a0a0')
    # A por los ogros.
    l2 = bytes.fromhex('4120b0afb220acafb320afa7b2afb3cb')
    assert len(l2) == 16
    rom[inn + 16:inn + 32] = l2

    # --- aliados ---
    slots = [
        (0x48D6D, 20, bytes([0x45, 0xAC, 0x20, 0xB0, 0xA5, 0xB2, 0xB2, 0xAF, 0x20])),  # El perro
        (0x48D82, 21, bytes([0x45, 0xAC, 0x20, 0xA6, 0xA1, 0xA9, 0xB3, 0xBB, 0xAE, 0x20])),  # El faisán
        (0x48D98, 19, bytes([0x45, 0xAC, 0x20, 0xAD, 0xAF, 0xAE, 0xAF, 0x20])),  # El mono
    ]
    after = bytes(rom[0x48DAC:0x48DC0])
    for off, n, pref in slots:
        old = bytes(rom[off:off + n])
        assert old.startswith(pref + TE + bytes([0x3B]) + ACOMP), (hex(off), old.hex())
        assert rom[off + n] == 0x00
        new = pref + VA + bytes([0x3B]) + CONTI
        assert len(new) == n
        rom[off:off + n] = new
        assert rom[off + n] == 0x00

    assert bytes(rom[0x48DAC:0x48DC0]) == after
    assert rom[inn:inn + 16] == bytes.fromhex('ca42b5a5aeafb320a4bda1b321a0a0a0')
    assert rom[inn + 16:inn + 32] == l2
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.parent.mkdir(exist_ok=True)
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('v339 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
