#!/usr/bin/env python3
"""
v377 — Ó/Ú 1 px más arriba; Jizo «partes a someter».

Base v376. Un $00 de cola + se quita el espacio de «¡Oh! ¡» → «¡Oh!¡»
para ganar el 2.º byte. $42 intacto.
"""
import hashlib
import sys
import zlib
from pathlib import Path

sys.path.insert(0, '/home/user/Momotaro/tools')
from fuente_menu import encode as enc_menu, rom_off as menu_off
from glifos_es import encode as enc_1bpp

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v376.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v377.pce'
IPS = ROOT / 'parches/momotaro_v377.ips'
MD5_BASE = '4efa44386b687c4f5dc61d668d884248'
DIAL = 0x3D660

# tilde fila 0; cuerpo desde fila 1 (antes desde 2)
O_UP = [
    "....##..",
    ".#####..",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    ".#####..",
    "........",
]
U_UP = [
    "....##..",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    ".#####..",
    "........",
]


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE

    for arte, byte in ((O_UP, 0xC5), (U_UP, 0xC6)):
        g1 = enc_1bpp(arte)
        rom[DIAL + byte * 8:DIAL + byte * 8 + 8] = g1
        g2 = enc_menu(arte)
        off = menu_off(byte)
        rom[off:off + 16] = g2
        assert bytes(rom[DIAL + byte * 8:DIAL + byte * 8 + 8]) == g1

    # Jizo: «partes» + nl + «a someter»
    j0 = 0x48E2A
    old = bytes.fromhex('b0a1b2b472a13bb3afada5b4a5b2')  # partes\nsometer
    new = bytes.fromhex('b0a1b2b472a13ba120b3afada5b4a5b2')  # partes\na someter
    blob = bytes(rom[j0:0x48F18])
    i = blob.index(old)
    assert rom[0x48F16] == 0x00 and rom[0x48F17] == 0x00
    assert rom[0x48F18] == 0x42
    # 1 B del $00 extra + 1 B quitando espacio ¡Oh! ¡
    oh = bytes.fromhex('ca4fa82120ca')  # ¡Oh! ¡
    ioh = blob.index(oh)
    assert ioh < i
    # compactar [ioh+4]=$20: mover [ioh+5 .. F17] a [ioh+4], gana 1 B
    # [ioh+4] era $20: compactar 1 B hacia los $00
    rom[j0 + ioh + 4:0x48F17] = bytes(rom[j0 + ioh + 5:0x48F18])
    assert len(rom) == 524288
    assert rom[0x48F18] == 0x42
    blob2 = bytes(rom[j0:0x48F18])
    i2 = blob2.index(old)
    a = j0 + i2
    # hueco de 2 B sobre los dos $00 finales
    assert rom[0x48F16] == 0 and rom[0x48F17] == 0
    rom[a + len(new):0x48F18] = bytes(rom[a + len(old):0x48F16])
    rom[a:a + len(new)] = new
    assert len(rom) == 524288
    assert rom[0x48F18] == 0x42
    assert old not in bytes(rom[j0:0x48F18])
    assert bytes.fromhex('3ba120b3af') in bytes(rom[j0:0x48F18])
    assert rom[0x48F17] == 0x00

    keep = {
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x03D7D: bytes(rom[0x03D7D:0x03D7D + 8]),
        0x3277: bytes(rom[0x3277:0x32A8]),
    }
    # keep was after edits; re-read from original v376 for those
    v376 = BASE.read_bytes()
    for o, n in ((0x4AD56, 32), (0x4B80E, 24), (0x03D7D, 8), (0x3277, 0x31)):
        assert bytes(rom[o:o + n]) == v376[o:o + n], hex(o)

    d = bytes(rom)
    SALIDA.write_bytes(d)
    rec, i, difv = [], 0, [j for j in range(len(d)) if d[j] != orig[j]]
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v377 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
