#!/usr/bin/env python3
"""
v366 — Difícil: si $3CE4 no es 0 ni 2, $BF salta al bloque $5C.

No usa $3B28/$3D31. Fácil (3CE4=0/2) se queda en $5800.
Hook en $DBBD (tick), no en el init. Base v362.
$5C cargo $5C nombre $00, sin pad 12.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v362.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v366.pce'
IPS = ROOT / 'parches/momotaro_v366.ips'
MD5_BASE = '311f6adac43ee49af137adda79c23a35'
CRED, BANK_END = 0x3B800, 0x3C000
CAVE, CAVE_CPU = 0x03E73, 0xDE73
HOOK = 0x03BBD  # $DBBD

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'Á': 0xC2, 'Ó': 0xC5, 'Ú': 0xC6,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

STAFF = [
    ('DIRECCIÓN', 'Shoji Masuda'),
    ('PERSONAJES', 'Takayuki Doi'),
    ('PROGRAMADOR', 'Hitoshi Okuno'),
    ('AYUD. PROG.', 'Yasuhiro Kosaka'),
    ('GRÁFICOS', 'Fumie Takaoka'),
    ('GRÁFICOS', 'Atsushi Kakutani'),
    ('GRÁFICOS', 'Kayo Fujimoto'),
    ('SONIDO', 'T. Takimoto'),
    ('SONIDO', 'Keita Hoshi'),
    ('DIRECTOR', 'Shigeki Fujiwara'),
    ('PRODUCCIÓN', 'HUDSON SOFT'),
    ('ASISTENTE', 'H. Iizuka'),
    ('ASISTENTE', 'M. Hakuya'),
    ('ASISTENTE', 'T. Hattori'),
    ('ASISTENTE', 'Hitoshi Araki'),
    ('ASISTENTE', 'S. Kuniyake'),
    ('ASISTENTE', 'Hiroshi Izawa'),
    ('ASISTENTE', 'Tomoo Oi'),
    ('MÚSICA', 'Michiko Yoshida'),
    ('SUPERVISIÓN', 'Akira Sakuma'),
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def pack_hard():
    o = bytearray()
    for c, n in STAFF:
        o += bytes([0x5C]) + enc(c) + bytes([0x5C]) + enc(n) + b'\x00'
    o.append(0xFF)
    return bytes(o)


def tramp(hard_cpu):
    lo, hi = hard_cpu & 0xFF, hard_cpu >> 8
    code = bytearray()
    code += bytes([0xAD, 0xE4, 0x3C])       # LDA $3CE4
    code += bytes([0xF0, 0x00])               # BEQ rts  placeholder
    beq_rts = len(code) - 2
    code += bytes([0xC9, 0x02])               # CMP #$02
    code += bytes([0xF0, 0x00])               # BEQ go
    beq_go = len(code) - 2
    code += bytes([0xA5, 0xC0, 0xC9, 0x58])  # LDA $C0 / CMP #$58
    code += bytes([0xD0, 0x00])               # BNE go
    bne_go = len(code) - 2
    code += bytes([0xA9, lo, 0x85, 0xBF, 0xA9, hi, 0x85, 0xC0])
    go = len(code)
    code[beq_go + 1] = (go - (beq_go + 2)) & 0xFF
    code[bne_go + 1] = (go - (bne_go + 2)) & 0xFF
    code += bytes([0x4C, 0xC2, 0xDB])         # JMP $DBC2
    rts = len(code)
    code[beq_rts + 1] = (rts - (beq_rts + 2)) & 0xFF
    code += bytes([0x60])
    return bytes(code)


def main():
    for c, n in STAFF:
        for ch in c + n:
            assert ch in ENC, ch
    hard = pack_hard()
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    assert rom[0x3BA2:0x3BA8] == bytes.fromhex('a90085bfa958')
    assert rom[HOOK:HOOK + 3] == bytes.fromhex('ade43c')
    easy_end = CRED
    while rom[easy_end] != 0xFF:
        easy_end += 1
    hard_off = (easy_end + 2) & ~1
    assert hard_off + len(hard) <= BANK_END
    hard_cpu = 0x5800 + (hard_off - CRED)
    tr = tramp(hard_cpu)
    assert all(b == 0xFF for b in rom[CAVE:CAVE + len(tr) + 2])
    keep = {
        0x3BA2: bytes(rom[0x3BA2:0x3BBD]),  # init intact; $DBBD se parchea
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x03D7D: bytes(rom[0x03D7D:0x03D7D + 8]),
    }
    init = bytes(rom[0x3BA2:0x3BBD])
    rom[CAVE:CAVE + len(tr)] = tr
    rom[HOOK:HOOK + 3] = bytes([0x4C, CAVE_CPU & 0xFF, CAVE_CPU >> 8])
    rom[hard_off:hard_off + len(hard)] = hard
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    assert rom[0x3BA2] == 0xA9
    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v366 OK hard', hex(hard_cpu), 'tramp', len(tr))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
