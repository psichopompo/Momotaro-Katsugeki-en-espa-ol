#!/usr/bin/env python3
"""
v351 — 0x3B800 bloques 2..6 (intro Fácil). In situ, $00 fijos.

2 0x3B824 19  ¡Has terminado
3 0x3B838 21  Momotaro en $5C Acción!
4 0x3B84E 14  Has demostrado
5 0x3B85D 18  que cualquiera
6 0x3B870 12  puede acabar

No $3B. c=$5D p=$5E. Base v350. Bloques 0-1 y 7+ INTOCABLES.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v350.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v351.pce'
IPS = ROOT / 'parches/momotaro_v351.ips'
MD5_BASE = '6de0ed0c25fa5dd2c3fc47d767b8b268'

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'Á': 0xC2, 'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC[c] = ord(c)


def enc(s):
    return bytes(ENC[ch] for ch in s)


# (offset, slot, payload) payload may include 0x5C
BLOQUES = [
    (0x3B824, 19, enc('¡Has terminado')),
    (0x3B838, 21, enc('Momotaro en') + bytes([0x5C]) + enc('Acción!')),
    (0x3B84E, 14, enc('Has demostrado')),
    (0x3B85D, 18, enc('que cualquiera')),
    (0x3B870, 12, enc('puede acabar')),
]


def main():
    assert ENC['c'] == 0x5D and ENC['p'] == 0x5E
    assert enc('cualquiera')[0] == ENC['c']
    assert enc('puede')[0] == ENC['p']
    for off, slot, raw in BLOQUES:
        assert len(raw) <= slot, (hex(off), len(raw), slot)
        assert 0x3B not in raw

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    keep = {
        0x3B800: bytes(rom[0x3B800:0x3B824]),  # 0+1 + 00s
        0x3B87D: bytes(rom[0x3B87D:0x3B87D + 8]),
        0x4A4B9: bytes(rom[0x4A4B9:0x4A4C4]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 8]),
        0x24DE: bytes(rom[0x24DE:0x24E0]),
    }
    zeros = [0x3B80F, 0x3B823, 0x3B837, 0x3B84D, 0x3B85C, 0x3B86F, 0x3B87C]
    for z in zeros:
        assert rom[z] == 0x00, hex(z)

    for off, slot, raw in BLOQUES:
        assert rom[off + slot] == 0x00
        pad = bytes([0x20] * (slot - len(raw)))
        rom[off:off + slot] = raw + pad
        assert rom[off + slot] == 0x00

    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    for z in zeros:
        assert rom[z] == 0x00

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v351 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    for off, slot, raw in BLOQUES:
        print(hex(off), len(raw), '/', slot)


if __name__ == '__main__':
    main()
