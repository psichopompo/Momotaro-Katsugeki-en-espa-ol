#!/usr/bin/env python3
"""
v342 — ogros Fácil/Normal: remap por ranura, no por offset lineal.

v341: $94' = $94 - $6739 + $6F7A. El #00 ES es 37 B y el JP 36 B,
así que el word0 del #01 ($675D) cae en el $00 del Onigiri: globo
viejo, sin tecleo. word0 0x24DE INTOCABLE ($A33A tiles).

Trampolín: si $67<=$95<$6D, busca el mayor jp[i]<=$94 y
$94 = es[i] + ($94 - jp[i]). TAM $3F si $6F<=$95<$76.
Base v339. Textos = v341.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v339.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v342.pce'
IPS = ROOT / 'parches/momotaro_v342.ips'
MD5_BASE = 'a1b79c70a57628f87bd110b52485b325'

HOLE = 0x7EF7A
CAVE = 0x03D7D
HOOK = 0x0219E
ANCHO = 16
N = 38

ENC = {
    ' ': 0x20, '!': 0x21, '?': 0x3F, '¡': 0xCA, '¿': 0xC9,
    '.': 0xCB, ',': 0xCC, ':': 0xCD, '…': 0xCB,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xC5, 'ú': 0xB5, 'ñ': 0xC1,
    'Ñ': 0xC8,
    'b': 0xA2, 'c': 0xA3, 'p': 0xB0,
    'a': 0xA1, 'd': 0xA4, 'e': 0xA5, 'f': 0xA6, 'g': 0xA7, 'h': 0xA8,
    'i': 0xA9, 'j': 0xAA, 'k': 0xAB, 'l': 0xAC, 'm': 0xAD, 'n': 0xAE,
    'o': 0xAF, 'q': 0xB1, 'r': 0xB2, 's': 0xB3, 't': 0xB4, 'u': 0xB5,
    'v': 0xB6, 'w': 0xB7, 'x': 0xB8, 'y': 0xB9, 'z': 0xBA,
}
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)


def enc_line(s):
    return bytes(ENC[ch] for ch in s)


def msg(lines):
    return b'\x3B'.join(enc_line(x) for x in lines) + b'\x00'


OGROS = [
    ['¿Te gustó el', 'relleno?', '¡Ogro Onigiri!'],
    ['Andar por andar.', '¡Ogro Andarín!'],
    ['Parecía seta', 'y andaba.', '¡Ogro Seta!'],
    ['¡Cuántas casas', 'llevaba encima!', '¡Ogro Casas!'],
    ['No paran de', 'bailar. ¡Ogros', 'Farolillos!'],
    ['Si para, se cae.', '¡Ogro Peonza!'],
    ['Recuerda a un', 'juguete de lata.', '¡Ogro Robot!'],
    ['Al principio', 'costaba subirse.', '¡Ogro Bola!'],
    ['¿Un poco más', 'de piedad?', '¡Ogro Faquir!'],
    ['¿Adónde se', 'esconde?', '¡Ogro Uzaki!'],
    ['¡Cómo pega', 'saltos!', '¡Ogro Muelle!'],
    ['Esos misiles', 'en los cuernos.', '¡Ogro Robot!'],
    ['¡Menudo', 'aguafiestas!', '¡Ogro Ajikara!'],
    ['¡No saltes', 'así!', '¡Ogro Patines!'],
    ['¿Le diste', 'antes de', 'partirse?', '¡Ogro Cosaco!'],
    ['No era fuego:', 'eran bolas de', 'hielo.', '¡Yuki onna!'],
    ['Tan mona y', 'tan dura.', '¡Daruma Chica!'],
    ['¡Quieta!', '¡Daruma Gorda!'],
    ['¿Se parece a', 'Enomoto a los', '36?', '¡Ogro Pulpo!'],
    ['Esas burbujas', 'molestaban.', '¡Ogro Cangrejo!'],
    ['El mar es', 'cosa seria.', '¡Ogro Buzo!'],
    ['El más', 'zonzo del', 'juego.', '¡Ogro En cueros!'],
    ['¡No enseñes', 'el blanco!', '¡Ogro Pulpazo!'],
    ['¿Un tipo', 'ardiente?', '¡Ogro Kachi Ñac!'],
    ['¡Qué piernas!', '¡Ogro Sometaro!'],
    ['¡Estírate', 'mejor!', '¡Ogro Goma!'],
    ['¡Lets limbo', 'dum dum dum!', '¡Ogro Danza!'],
    ['¿Qué cuerpo', 'es ese?', '¡Ogro Partido!'],
    ['Con casco,', 'más formal.', '¡Ogro Sugeho!'],
    ['En clase hay', 'uno así.', '¡Ogro Sordo!'],
    ['¡9,85!', '¡Ogro Gimnasia!'],
    ['¿De verdad', 'era un robot?', '¡Ogro Vampiro!'],
    ['El trueno', 'estorbaba.', '¡Raijin!'],
    ['¿Ese aro qué', 'era?', '¡Ogro Alado!'],
    ['¿Sabías que', 'montarlo', 'divierte?', '¡Ogro Patada!'],
    ['¿Le sale del', 'culo?', '¡Ogro Fundoshi!'],
    ['¡Mal timing', 'para explotar!', '¡Ogro Globo!'],
    ['Hasta aquí,', 'el más', 'chungo.', '¡Fujin!'],
]


def jp_starts(rom):
    t = rom[0x24DE:0x24DE + N * 8]
    return [t[i * 8] | (t[i * 8 + 1] << 8) for i in range(N)]


def trampoline(jps, ess, cave_cpu=0xDD7D):
    """Y=37..0: primer jp[y]<=$94 → $94 = es[y]+($94-jp[y])."""
    code = bytearray()

    def here():
        return len(code)

    def setrel(at, target):
        code[at + 1] = (target - (at + 2)) & 0xFF

    # if $95 < $67 or $95 >= $6D → solo TAM
    code += bytes([0xA5, 0x95, 0xC9, 0x67])  # LDA $95 / CMP #$67
    bcc_tam = here()
    code += bytes([0x90, 0x00])  # BCC tambanks
    code += bytes([0xC9, 0x6D])
    bcs_tam = here()
    code += bytes([0xB0, 0x00])  # BCS tambanks

    # LDY #37
    code += bytes([0xA0, N - 1])
    loop = here()
    # ptr>=jp: LDA $95 / CMP jphi,y / BCC next / BNE ge / LDA $94 / CMP jplo,y / BCC next
    code += bytes([0xA5, 0x95])
    cmp_jphi = here()
    code += bytes([0xD9, 0x00, 0x00])  # CMP jphi,y
    bcc1 = here()
    code += bytes([0x90, 0x00])  # BCC next  ptr.hi < jp.hi
    bne_ge = here()
    code += bytes([0xD0, 0x00])  # BNE ge    ptr.hi > jp.hi
    code += bytes([0xA5, 0x94])
    cmp_jplo = here()
    code += bytes([0xD9, 0x00, 0x00])  # CMP jplo,y
    bcc2 = here()
    code += bytes([0x90, 0x00])  # BCC next
    ge = here()
    setrel(bne_ge, ge)

    # $94 = $94 - jp[y] + es[y]
    code += bytes([0x38, 0xA5, 0x94])
    sbc_jplo = here()
    code += bytes([0xF9, 0x00, 0x00])  # SBC jplo,y
    code += bytes([0x85, 0x94, 0xA5, 0x95])
    sbc_jphi = here()
    code += bytes([0xF9, 0x00, 0x00])  # SBC jphi,y
    code += bytes([0x85, 0x95, 0x18, 0xA5, 0x94])
    adc_eslo = here()
    code += bytes([0x79, 0x00, 0x00])  # ADC eslo,y
    code += bytes([0x85, 0x94, 0xA5, 0x95])
    adc_eshi = here()
    code += bytes([0x79, 0x00, 0x00])  # ADC eshi,y
    code += bytes([0x85, 0x95])
    beq_tam = here()
    code += bytes([0x80, 0x00])  # BRA tambanks (HuC6280)

    nxt = here()
    setrel(bcc1, nxt)
    setrel(bcc2, nxt)
    code += bytes([0x88])  # DEY
    bpl = here()
    code += bytes([0x10, 0x00])  # BPL loop
    setrel(bpl, loop)

    tambanks = here()
    setrel(bcc_tam, tambanks)
    setrel(bcs_tam, tambanks)
    setrel(beq_tam, tambanks)

    # TAM $24 @ $4000
    code += bytes([0xA9, 0x24, 0x18, 0x65, 0x20, 0x53, 0x04])
    # TAM $3F si $6F<=$95<$76 else $25
    code += bytes([0xA5, 0x95, 0xC9, 0x6F])
    bcc25 = here()
    code += bytes([0x90, 0x00])
    code += bytes([0xC9, 0x76])
    bcs25 = here()
    code += bytes([0xB0, 0x00])
    code += bytes([0xA9, 0x3F, 0xD0, 0x02])
    use25 = here()
    code += bytes([0xA9, 0x25])
    setrel(bcc25, use25)
    setrel(bcs25, use25)
    code += bytes([0x18, 0x65, 0x20, 0x53, 0x08, 0x4C, 0xA8, 0xC1])

    # tablas justo después del código
    base = cave_cpu + len(code)
    jplo = base
    jphi = jplo + N
    eslo = jphi + N
    eshi = eslo + N

    def patch(at, addr):
        code[at + 1] = addr & 0xFF
        code[at + 2] = addr >> 8

    patch(cmp_jphi, jphi)
    patch(cmp_jplo, jplo)
    patch(sbc_jplo, jplo)
    patch(sbc_jphi, jphi)
    patch(adc_eslo, eslo)
    patch(adc_eshi, eshi)

    tables = bytes(p & 0xFF for p in jps) + bytes(p >> 8 for p in jps)
    tables += bytes(p & 0xFF for p in ess) + bytes(p >> 8 for p in ess)
    assert len(tables) == N * 4
    return bytes(code) + tables


def main():
    for i, lines in enumerate(OGROS):
        for L in lines:
            assert len(L) <= ANCHO, (i, len(L), L)
            for ch in L:
                assert ch in ENC, (i, ch, L)

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    jps = jp_starts(rom)
    assert jps[0] == 0x6739 and jps[1] == 0x675D
    packed = b''.join(msg(x) for x in OGROS)
    assert packed.count(0) == N
    ess = []
    o = 0x6F7A
    for x in OGROS:
        ess.append(o)
        o += len(msg(x))
    def remap(ptr):
        if not (0x67 <= (ptr >> 8) < 0x6D):
            return ptr
        for y in range(N - 1, -1, -1):
            if ptr >= jps[y]:
                return ess[y] + (ptr - jps[y])
        return ptr

    assert remap(0x6739) == ess[0]
    assert remap(0x675D) == ess[1]
    assert remap(0x675D) != ess[0]
    assert remap(0x6F7A) == 0x6F7A
    assert ess[0] == 0x6F7A
    # #00 ES 37 B, JP 36 B — el bug de v341
    assert len(msg(OGROS[0])) == 37
    assert jps[1] - jps[0] == 36

    tr = trampoline(jps, ess)
    assert all(b == 0xFF for b in rom[CAVE:CAVE + len(tr) + 1])
    assert all(b == 0xFF for b in orig[CAVE:CAVE + len(tr) + 1])
    assert rom[HOOK:HOOK + 10] == bytes.fromhex('a92418652053041a5308')
    assert len(packed) < 2182
    assert all(b == 0xFF for b in rom[HOLE:HOLE + len(packed)])
    assert all(b == 0xFF for b in orig[HOLE:HOLE + len(packed)])

    w0 = bytes(rom[0x24DE:0x24DE + N * 8])

    keep = {
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4A4B9: bytes(rom[0x4A4B9:0x4A4D0]),
        0x4A739: bytes(rom[0x4A739:0x4A750]),
        0x1F881: bytes(rom[0x1F881:0x1F89E]),
    }

    rom[CAVE:CAVE + len(tr)] = tr
    rom[HOOK:HOOK + 3] = bytes([0x4C, 0x7D, 0xDD])
    rom[HOOK + 3:HOOK + 10] = bytes([0xEA] * 7)
    rom[HOLE:HOLE + len(packed)] = packed

    assert bytes(rom[0x24DE:0x24DE + N * 8]) == w0
    assert bytes(rom[CAVE:CAVE + len(tr)]) == tr
    assert bytes(rom[HOLE:HOLE + len(packed)]) == packed
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    # BRA $80 es HuC6280
    assert 0x80 in tr

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.parent.mkdir(exist_ok=True)
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('v342 OK packed', len(packed), 'tramp', len(tr))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('es1', hex(ess[1]), 'jp0len', jps[1] - jps[0], 'es0len', len(msg(OGROS[0])))


if __name__ == '__main__':
    main()
