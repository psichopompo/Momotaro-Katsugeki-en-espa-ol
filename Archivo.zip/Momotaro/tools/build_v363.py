#!/usr/bin/env python3
"""
v363 — créditos Difícil/Muy difícil en $5C, puntero aparte.

Fácil sigue en $5800 ($00, sin $5C).
Difícil: $3B28&3 >= 2 → $BF al bloque $5C (12 cols cargo).
Cueva $DE73 (tras trampolín ogros). Base v362.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v362.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v363.pce'
IPS = ROOT / 'parches/momotaro_v363.ips'
MD5_BASE = '311f6adac43ee49af137adda79c23a35'
CRED, BANK_END = 0x3B800, 0x3C000
CAVE = 0x03E73
CAVE_CPU = 0xDE73
ANCHO_NOM = 17

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'Á': 0xC2, 'É': 0xC3, 'Í': 0xC4, 'Ó': 0xC5, 'Ú': 0xC6,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

STAFF = [
    ('DIRECCIÓN', 'Shoji Masuda'),
    ('PERSONAJES', 'Takayuki Doi'),
    ('PROGRAMADOR', 'Hitoshi Okuno'),
    ('AYUD. PROG.', 'Yasuhiro Kosaka'),
    ('GRÁFICOS', 'Fumie Takaoka'),
    ('GRÁFICOS', 'Atsushi Kakutani'),
    ('GRÁFICOS', 'Kayo Fujimoto'),
    ('SONIDO', 'T. Takimoto'),
    ('SONIDO', 'Keita Hoshi'),
    ('DIRECTOR', 'Shigeki Fujiwara'),
    ('PRODUCCIÓN', 'HUDSON SOFT'),
    ('ASISTENTE', 'H. Iizuka'),
    ('ASISTENTE', 'Masakazu Hakuya'),
    ('ASISTENTE', 'T. Hattori'),
    ('ASISTENTE', 'Hitoshi Araki'),
    ('ASISTENTE', 'Santa Kuniyake'),
    ('ASISTENTE', 'Hiroshi Izawa'),
    ('ASISTENTE', 'Tomoo Oi'),
    ('MÚSICA', 'Michiko Yoshida'),
    ('SUPERVISIÓN', 'Akira Sakuma'),
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def cargo(s):
    assert len(s) <= 12, s
    return bytes([0x5C]) + enc(s) + bytes([0x20] * (12 - len(s))) + bytes([0x5C])


def pack_hard():
    out = bytearray()
    for c, n in STAFF:
        assert len(n) <= ANCHO_NOM, n
        out += cargo(c) + enc(n) + b'\x00'
    out.append(0xFF)
    return bytes(out)


def tramp(hard_cpu):
    lo, hi = hard_cpu & 0xFF, hard_cpu >> 8
    # LDA $3B28 / AND #3 / CMP #2 / BCS hard
    code = bytearray(bytes.fromhex('ad283b2903c902'))
    bcs = len(code)
    code += bytes([0xB0, 0x00])  # BCS hard
    code += bytes([0xA9, 0x00, 0x85, 0xBF, 0xA9, 0x58, 0x85, 0xC0])
    bra = len(code)
    code += bytes([0x80, 0x00])  # BRA go
    hard = len(code)
    code[bcs + 1] = hard - (bcs + 2)
    code += bytes([0xA9, lo, 0x85, 0xBF, 0xA9, hi, 0x85, 0xC0])
    go = len(code)
    code[bra + 1] = go - (bra + 2)
    code += bytes.fromhex('9ca63b9ce43c9ce33ca90185c3a9108de53c60')
    return bytes(code)


def main():
    for c, n in STAFF:
        for ch in c + n:
            assert ch in ENC, ch
    hard = pack_hard()
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    # Easy body: hasta primer $FF
    easy_end = CRED
    while rom[easy_end] != 0xFF:
        easy_end += 1
    easy_len = easy_end - CRED
    hard_off = easy_end + 1
    while hard_off % 2:
        hard_off += 1
    assert hard_off + len(hard) <= BANK_END
    hard_cpu = 0x5800 + (hard_off - CRED)
    assert 0x5800 < hard_cpu < 0x8000

    tr = tramp(hard_cpu)
    assert all(b == 0xFF for b in rom[CAVE:CAVE + len(tr) + 1])
    assert rom[0x3BA2:0x3BA8] == bytes.fromhex('a90085bfa958')

    keep = {
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 8]),
        0x03D7D: bytes(rom[0x03D7D:0x03D7D + 16]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
    }

    rom[CAVE:CAVE + len(tr)] = tr
    rom[0x3BA2:0x3BA5] = bytes([0x4C, CAVE_CPU & 0xFF, CAVE_CPU >> 8])  # JMP $DE73
    rom[hard_off:hard_off + len(hard)] = hard

    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    assert rom[0x3BA2] == 0x4C
    assert bytes(rom[hard_off:hard_off + 2]) == bytes([0x5C, ord('D')])  # DIRECCIÓN or DIRECTOR
    assert rom[hard_off + len(hard) - 1] == 0xFF
    assert all(rom[0x4AD56 + k] == 0x20 for k in range(32))

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v363 OK easy', easy_len, 'hard', hex(hard_cpu), 'n', len(hard))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
