#!/usr/bin/env python3
"""
v360 — staff Fácil (0x3B800) tras la intro. ≤17, sin $5C ni $3B.

Base v359. Cola JP desde 0x3BA19 (concurso de ideas).
Toshiaki Takimoto. = 18 → T. Takimoto.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v359.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v360.pce'
IPS = ROOT / 'parches/momotaro_v360.ips'
MD5_BASE = '5d0191d2e17622184f6f9450e15df950'

CRED, COLA_JP, STAFF_END, BANK_END = 0x3B800, 0x3BA19, 0x3BF84, 0x3C000
ANCHO = 17

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'Á': 0xC2,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

LINEAS = [
    '¡Enhorabuena!', '¡Gracias!', '¡Has terminado', 'Momotaro en', 'Acción!',
    'Has demostrado', 'que cualquiera', 'puede acabar', 'este juego.',
    'Permíteme darte', 'las gracias otra', 'vez.',
    'Ahora, el equipo', 'de Momotaro en', 'Acción.',
    'El director,', 'por fin', '¡ascendido!', 'Shoji Masuda.',
    'Música: temas', 'que dan calor.', 'Michiko Yoshida.',
    'Personajes:', '¡Novia a 3000', 'leguas!', 'Takayuki Doi.',
    'PROGRAMADOR', 'Hitoshi Okuno.',
    'AYUD. PROG.', 'Yasuhiro Kosaka.',
    'GRÁFICOS', 'Fumie Takaoka.', 'Atsushi Kakutani.', 'Kayo Fujimoto.',
    'SONIDO', 'T. Takimoto.', 'Keita Hoshi.',
    'DIRECTOR', 'Shigeki Fujiwara.',
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def main():
    for L in LINEAS:
        assert 1 <= len(L) <= ANCHO, (len(L), L)
        for ch in L:
            assert ch in ENC, ch
    body = b'\x00'.join(enc(L) for L in LINEAS) + b'\x00'
    assert 0x5C not in body and 0x3B not in body
    orig = VIRGEN.read_bytes()
    cola = bytes(orig[COLA_JP:STAFF_END])
    blob = body + cola
    assert CRED + len(blob) <= BANK_END

    rom = bytearray(BASE.read_bytes())
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    keep = {
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x48E34: bytes(rom[0x48E34:0x48E40]),
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 8]),
        0x4A4B9: bytes(rom[0x4A4B9:0x4A4C8]),
    }
    rom[CRED:CRED + len(blob)] = blob
    rom[CRED + len(blob):BANK_END] = bytes([0xFF] * (BANK_END - CRED - len(blob)))
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    assert enc('Shoji Masuda.') in bytes(rom[CRED:CRED + len(body)])
    assert all(rom[0x4AD56 + k] == 0x20 for k in range(32))

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v360 OK body', len(body), 'total', len(blob))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
