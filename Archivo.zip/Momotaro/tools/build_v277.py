#!/usr/bin/env python3
"""
build_v277.py - Nadie, Guijarro, plantilla de 180 ryos.

BASE: v276.

1. Menu RUN $B1B4: «Sin nadie» (9) se ve «Sin nadi» (8 celdas).
   «Nadie», sin punto: es la entrada vacia de Perro/Faisan/Mono, no un
   mensaje tipo ¡Puaj!.

2. Abuelo: Solar/Glacial -> Guijarro Solar / Guijarro + glacial.
   14x2: «Guijarro glacial» son 16, no cabe en una linea.

3. 0x1F09F: ももたろうは / FB FB FB 両 / てにいれた
   Motor del tutorial ($00 = linea), NO $793B. Sin $7C.
   Bocadillo vertical ~6: «¡Ganas» / [cifra] / «ryos!»

Uso:  python3 tools/build_v277.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE, encode          # noqa: E402

BASE = 'roms/momotaro_es_v276.pce'
SALIDA = 'roms/momotaro_es_v277.pce'
IPS = 'parches/momotaro_v277.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = 'ce279338ee633cb1143e8b36789eefd2'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL, FIN, COLS = 0x3B, 0x00, 14
ZONA_INI, ZONA_FIN = 0x48C7E, 0x48E2A
SIN_NADIE = 0x431B4
PLANTILLA = 0x1F09F
PLANTILLA_N = 18

MAP = dict(CHAR_TO_CODE)
MAP['b'] = 0xA2
MAP['c'] = 0xA3
MAP['p'] = 0xB0
IEN = bytes([0xA9, 0xA5, 0xAE])
IEN_DICC = bytes([0x7C])

TEXTOS = [
    ('Obtienes el', 'Onigiri.'),
    ('Obtienes el', 'Manjar.'),
    ('Obtienes el', 'Banquete.'),
    ('Obtienes un', 'Dango.'),
    ('Obtienes los', 'Pedos.'),
    ('Guijarro', 'solar.'),
    ('Guijarro', 'glacial.'),
    ('Obtienes la', 'Capa.'),
    ('¡Obtienes 100', 'ryos!'),
    ('¡Obtienes 50', 'ryos!'),
    ('¡Obtienes 30', 'ryos!'),
    ('¡Obtienes 10', 'ryos!'),
    ('No puedes', 'llevar más.'),
    ('El perro te', 'acompaña.'),
    ('El faisán te', 'acompaña.'),
    ('El mono te', 'acompaña.'),
    ('Obtienes el', 'caparazón.'),
    ('Obtienes el', 'Bonzo.'),
    ('¡Obtienes 80', 'ryos!'),
    ('¡Obtienes 20', 'ryos!'),
    ('¡Menudo', 'idiota!'),
    ('Sigue hacia', 'arriba'),
    ('Sigue a la', 'derecha.'),
]


def enc(s):
    return bytes(MAP[ch] for ch in s).replace(IEN, IEN_DICC)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v276 OK')

    # --- Nadie ---
    viejo = bytes([0x01]) + encode('Sin nadie') + bytes([0x00])
    nuevo = bytes([0x01]) + encode('Nadie') + bytes([0x00])
    assert bytes(rom[SIN_NADIE:SIN_NADIE + len(viejo)]) == viejo
    assert len(nuevo) <= len(viejo)
    rom[SIN_NADIE:SIN_NADIE + len(viejo)] = nuevo + bytes(len(viejo) - len(nuevo))
    w = rom[0x431CC] | (rom[0x431CD] << 8)
    assert 0x42000 + (w - 0xA000) == SIN_NADIE
    assert rom[SIN_NADIE] == 0x01 and rom[SIN_NADIE + 1 + 5] == 0x00
    print('Nadie  OK  %d B de %d' % (len(nuevo), len(viejo)))

    # --- plantilla 180 ---
    esp_jp = bytes.fromhex('d3d3c0dbb3ca00fbfbfb243cc3c6b2dac021')
    assert bytes(rom[PLANTILLA:PLANTILLA + PLANTILLA_N]) == esp_jp
    assert rom[PLANTILLA + PLANTILLA_N] == 0xF0
    # ¡Ganas $00 FB FB FB $00 ryos!
    plant = encode('¡Ganas') + bytes([0x00, 0xFB, 0xFB, 0xFB, 0x00]) + encode('ryos!')
    assert len(plant) <= PLANTILLA_N, len(plant)
    assert all(len(l) <= 6 for l in ('¡Ganas', 'ryos!'))
    rom[PLANTILLA:PLANTILLA + PLANTILLA_N] = plant + bytes(PLANTILLA_N - len(plant))
    assert rom[PLANTILLA + PLANTILLA_N] == 0xF0
    print('plantilla 0x1F09F  %d B  OK' % len(plant))

    # --- 23 textos ---
    bloques = []
    for parts in TEXTOS:
        for l in parts:
            assert len(l) <= COLS, l
        b = enc(parts[0])
        if len(parts) > 1:
            b += bytes([NL]) + enc(parts[1])
        b += bytes([FIN])
        assert 0x5B not in b and 0x5D not in b and 0x5E not in b
        bloques.append(b)
    total = sum(len(b) for b in bloques)
    print('abuelo %d / %d' % (total, ZONA_FIN - ZONA_INI))
    assert total <= ZONA_FIN - ZONA_INI

    o = ZONA_INI
    for k, b in enumerate(bloques):
        cpu = o - BANCO24
        rom[TABLA + k * 2] = cpu & 0xFF
        rom[TABLA + k * 2 + 1] = cpu >> 8
        rom[o:o + len(b)] = b
        o += len(b)
    if o < ZONA_FIN:
        rom[o:ZONA_FIN] = bytes([FIN]) * (ZONA_FIN - o)

    inv = {v: k for k, v in MAP.items()}
    inv[0x7C] = 'ien'
    print('--- releido')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        end = a
        while rom[end] != FIN:
            end += 1
        got = '/'.join(
            ''.join(inv.get(x, '{%02X}' % x) for x in pte)
            for pte in bytes(rom[a:end]).split(bytes([NL])))
        exp = '/'.join(TEXTOS[k])
        assert got == exp, '[%d] %r' % (k, got)
        print('   [%2d] %s' % (k, got))

    # puntero Nadie
    got = []
    i = SIN_NADIE + 1
    while rom[i]:
        got.append(CHAR_TO_CODE and None)
        i += 1
    s = ''.join({v: k for k, v in CHAR_TO_CODE.items()}.get(x, '?')
                for x in rom[SIN_NADIE + 1:SIN_NADIE + 1 + 5])
    assert s == 'Nadie', s

    intactas = [
        ('guion', 0x48E2A, 0x4A484),
        ('fuente', 0x3D660, 0x3E200),
        ('trampolin', 0x17E78, 0x17E86),
        ('F0 tras plantilla', PLANTILLA + PLANTILLA_N, PLANTILLA + PLANTILLA_N + 3),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
