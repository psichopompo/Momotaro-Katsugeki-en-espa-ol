#!/usr/bin/env python3
"""
build_v278.py - plantilla $C951 (minijuego rico/pobre) + Guijarro.

BASE: v277.

CAUSA DEL «//ü·s i220両»
========================
$363E con bit 7: TII $C951->$3641 (18 B) y mete la cifra en $3647
(offset 6). No es 0x1F09F. El prefijo モモタロウハ se lee como latin.
v277 parcho el sitio equivocado; se REVIERTE 0x1F09F.

ARREGLO
=======
Prefijo 6 B «Ganas » (el offset de la cifra es fijo).
Bucle $C938: copia « ryos»+$00 y PARA en el $00 (ya no CPY #$06,
que metia 両 y $A0).
0x1F09F vuelve a la virgen.

Guijarro: «Obtienes / Guijarro Solar». Glacial son 16: «Guijarro / Glacial.»

Uso:  python3 tools/build_v278.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE, encode          # noqa: E402
from dis6280 import desensambla                            # noqa: E402

BASE = 'roms/momotaro_es_v277.pce'
SALIDA = 'roms/momotaro_es_v278.pce'
IPS = 'parches/momotaro_v278.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '1c0cf9e4766dacb3f5ef8f2f5febe82e'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL, FIN, COLS = 0x3B, 0x00, 14
ZONA_INI, ZONA_FIN = 0x48C7E, 0x48E2A
C938, C951, C963 = 0x16938, 0x16951, 0x16963
PLANTILLA = 0x1F09F

MAP = dict(CHAR_TO_CODE)
MAP['b'] = 0xA2
MAP['c'] = 0xA3
MAP['p'] = 0xB0
IEN = bytes([0xA9, 0xA5, 0xAE])


def enc(s):
    return bytes(MAP[ch] for ch in s).replace(IEN, bytes([0x7C]))


TEXTOS = [
    ('Obtienes el', 'Onigiri'),
    ('Obtienes el', 'Manjar'),
    ('Obtienes el', 'Banquete'),
    ('Obtienes un', 'Dango'),
    ('Obtienes los', 'Pedos.'),
    ('Obtienes', 'Guijarro Solar'),
    ('Guijarro', 'Glacial.'),
    ('Obtienes la', 'Capa.'),
    ('¡Obtienes 100', 'ryos!'),
    ('¡Obtienes 50', 'ryos!'),
    ('¡Obtienes 30', 'ryos!'),
    ('¡Obtienes 10', 'ryos!'),
    ('No puedes', 'llevar más.'),
    ('El perro te', 'acompaña.'),
    ('El faisán te', 'acompaña.'),
    ('El mono te', 'acompaña.'),
    ('Obtienes el', 'caparazón.'),
    ('Obtienes el', 'Bonzo.'),
    ('¡Obtienes 80', 'ryos!'),
    ('¡Obtienes 20', 'ryos!'),
    ('¡Menudo', 'idiota!'),
    ('Sigue hacia', 'arriba'),
    ('Sigue a la', 'derecha.'),
]


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v277 OK')

    # revertir 0x1F09F
    rom[PLANTILLA:PLANTILLA + 18] = orig[PLANTILLA:PLANTILLA + 18]
    assert rom[PLANTILLA + 18] == 0xF0
    print('0x1F09F revertido a virgen')

    # bucle nuevo en $C938 (13 B, igual que el viejo)
    viejo = bytes.fromhex('82bd63c9994736e8c8c00690f4')
    assert bytes(rom[C938:C938 + 13]) == viejo, rom[C938:C938 + 13].hex()
    nuevo = bytes.fromhex(
        '82'          # CLX
        'bd63c9'      # LDA $C963,X
        '994736'      # STA $3647,Y
        'f005'        # BEQ +5 -> $C945
        'e8'          # INX
        'c8'          # INY
        '80f4'        # BRA $C939
    )
    assert len(nuevo) == 13
    rom[C938:C938 + 13] = nuevo
    dsm = desensambla(bytes(rom), C938, 13, 0xC938)
    print('--- $C938')
    for x in dsm:
        print('  $%04X  %s' % (x[1], x[3]))
    assert dsm[0][3] == 'CLX' and dsm[3][3].startswith('BEQ')

    pref = encode('Ganas ')
    assert len(pref) == 6
    rom[C951:C951 + 6] = pref
    rom[C951 + 6:C951 + 12] = b'\x20' * 6
    # cola: no se lee si hay $00
    rom[C951 + 12:C951 + 18] = b'\x00' * 6
    suf = encode(' ryos') + bytes([0x00])
    assert len(suf) == 6
    rom[C963:C963 + 6] = suf
    assert bytes(rom[TABLA:TABLA + 2]) != bytes([0x00, 0x00])
    print('plantilla: «Ganas » + cifra + « ryos»')

    bloques = []
    for parts in TEXTOS:
        for l in parts:
            assert len(l) <= COLS, l
        b = enc(parts[0])
        if len(parts) > 1:
            b += bytes([NL]) + enc(parts[1])
        b += bytes([0x00])
        bloques.append(b)
    total = sum(len(b) for b in bloques)
    print('abuelo %d / %d' % (total, ZONA_FIN - ZONA_INI))
    assert total <= ZONA_FIN - ZONA_INI

    o = ZONA_INI
    for k, b in enumerate(bloques):
        cpu = o - BANCO24
        rom[TABLA + k * 2] = cpu & 0xFF
        rom[TABLA + k * 2 + 1] = cpu >> 8
        rom[o:o + len(b)] = b
        o += len(b)
    if o < ZONA_FIN:
        rom[o:ZONA_FIN] = bytes(ZONA_FIN - o)

    inv = {v: k for k, v in MAP.items()}
    inv[0x7C] = 'ien'
    print('--- releido')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        end = a
        while rom[end]:
            end += 1
        got = '/'.join(
            ''.join(inv.get(x, '{%02X}' % x) for x in pte)
            for pte in bytes(rom[a:end]).split(bytes([NL])))
        exp = '/'.join(TEXTOS[k])
        assert got == exp, '[%d] %r' % (k, got)
        print('   [%2d] %s' % (k, got))

    intactas = [
        ('Nadie', 0x431B4, 0x431BB),
        ('fuente', 0x3D660, 0x3E200),
        ('trampolin', 0x17E78, 0x17E86),
        ('$C8DB LDA', 0x168DB, 0x168ED),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
