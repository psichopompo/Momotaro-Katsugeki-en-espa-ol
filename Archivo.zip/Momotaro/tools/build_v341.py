#!/usr/bin/env python3
"""
v341 — ogros Fácil/Normal: mismos bytes que v340 + maquetación ≤16.

Base v339 (no parche sobre v340). Hueco 0x7EF7A + trampolín $DD7D.
00/06/08/23/24/31: cortes y nombres que David cerró 2026-08-24.
Ñ de «Kachi Ñac» = $C8 (charset $C190 / oficial).
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v339.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v341.pce'
IPS = ROOT / 'parches/momotaro_v341.ips'
MD5_BASE = 'a1b79c70a57628f87bd110b52485b325'

HOLE = 0x7EF7A
CAVE = 0x03D7D  # $DD7D banco $01 @ $C000
HOOK = 0x0219E  # $C19E
ANCHO = 16

ENC = {
    ' ': 0x20, '!': 0x21, '?': 0x3F, '¡': 0xCA, '¿': 0xC9,
    '.': 0xCB, ',': 0xCC, ':': 0xCD, '…': 0xCB,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xC5, 'ú': 0xB5, 'ñ': 0xC1,
    'Ñ': 0xC8,
    'b': 0xA2, 'c': 0xA3, 'p': 0xB0,
    'a': 0xA1, 'd': 0xA4, 'e': 0xA5, 'f': 0xA6, 'g': 0xA7, 'h': 0xA8,
    'i': 0xA9, 'j': 0xAA, 'k': 0xAB, 'l': 0xAC, 'm': 0xAD, 'n': 0xAE,
    'o': 0xAF, 'q': 0xB1, 'r': 0xB2, 's': 0xB3, 't': 0xB4, 'u': 0xB5,
    'v': 0xB6, 'w': 0xB7, 'x': 0xB8, 'y': 0xB9, 'z': 0xBA,
}
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)


def enc_line(s):
    return bytes(ENC[ch] for ch in s)


def msg(lines):
    parts = [enc_line(x) for x in lines]
    return b'\x3B'.join(parts) + b'\x00'


OGROS = [
    ['¿Te gustó el', 'relleno?', '¡Ogro Onigiri!'],
    ['Andar por andar.', '¡Ogro Andarín!'],
    ['Parecía seta', 'y andaba.', '¡Ogro Seta!'],
    ['¡Cuántas casas', 'llevaba encima!', '¡Ogro Casas!'],
    ['No paran de', 'bailar. ¡Ogros', 'Farolillos!'],
    ['Si para, se cae.', '¡Ogro Peonza!'],
    ['Recuerda a un', 'juguete de lata.', '¡Ogro Robot!'],
    ['Al principio', 'costaba subirse.', '¡Ogro Bola!'],
    ['¿Un poco más', 'de piedad?', '¡Ogro Faquir!'],
    ['¿Adónde se', 'esconde?', '¡Ogro Uzaki!'],
    ['¡Cómo pega', 'saltos!', '¡Ogro Muelle!'],
    ['Esos misiles', 'en los cuernos.', '¡Ogro Robot!'],
    ['¡Menudo', 'aguafiestas!', '¡Ogro Ajikara!'],
    ['¡No saltes', 'así!', '¡Ogro Patines!'],
    ['¿Le diste', 'antes de', 'partirse?', '¡Ogro Cosaco!'],
    ['No era fuego:', 'eran bolas de', 'hielo.', '¡Yuki onna!'],
    ['Tan mona y', 'tan dura.', '¡Daruma Chica!'],
    ['¡Quieta!', '¡Daruma Gorda!'],
    ['¿Se parece a', 'Enomoto a los', '36?', '¡Ogro Pulpo!'],
    ['Esas burbujas', 'molestaban.', '¡Ogro Cangrejo!'],
    ['El mar es', 'cosa seria.', '¡Ogro Buzo!'],
    ['El más', 'zonzo del', 'juego.', '¡Ogro En cueros!'],
    ['¡No enseñes', 'el blanco!', '¡Ogro Pulpazo!'],
    ['¿Un tipo', 'ardiente?', '¡Ogro Kachi Ñac!'],
    ['¡Qué piernas!', '¡Ogro Sometaro!'],
    ['¡Estírate', 'mejor!', '¡Ogro Goma!'],
    ['¡Lets limbo', 'dum dum dum!', '¡Ogro Danza!'],
    ['¿Qué cuerpo', 'es ese?', '¡Ogro Partido!'],
    ['Con casco,', 'más formal.', '¡Ogro Sugeho!'],
    ['En clase hay', 'uno así.', '¡Ogro Sordo!'],
    ['¡9,85!', '¡Ogro Gimnasia!'],
    ['¿De verdad', 'era un robot?', '¡Ogro Vampiro!'],
    ['El trueno', 'estorbaba.', '¡Raijin!'],
    ['¿Ese aro qué', 'era?', '¡Ogro Alado!'],
    ['¿Sabías que', 'montarlo', 'divierte?', '¡Ogro Patada!'],
    ['¿Le sale del', 'culo?', '¡Ogro Fundoshi!'],
    ['¡Mal timing', 'para explotar!', '¡Ogro Globo!'],
    ['Hasta aquí,', 'el más', 'chungo.', '¡Fujin!'],
]


def trampoline():
    code = bytearray()

    def here():
        return len(code)

    code += bytes([0xA5, 0x95, 0xC9, 0x67])
    bcc1 = here()
    code += bytes([0x90, 0x00])
    code += bytes([0xC9, 0x6D])
    bcs1 = here()
    code += bytes([0xB0, 0x00])
    code += bytes([
        0x38,
        0xA5, 0x94, 0xE9, 0x39, 0x85, 0x94,
        0xA5, 0x95, 0xE9, 0x67, 0x85, 0x95,
        0x18,
        0xA5, 0x94, 0x69, 0x7A, 0x85, 0x94,
        0xA5, 0x95, 0x69, 0x6F, 0x85, 0x95,
    ])
    skip = here()
    code[bcc1 + 1] = skip - (bcc1 + 2)
    code[bcs1 + 1] = skip - (bcs1 + 2)

    code += bytes([0xA9, 0x24, 0x18, 0x65, 0x20, 0x53, 0x04])
    code += bytes([0xA5, 0x95, 0xC9, 0x67])
    bcc2 = here()
    code += bytes([0x90, 0x00])
    code += bytes([0xC9, 0x76])
    bcs2 = here()
    code += bytes([0xB0, 0x00])
    code += bytes([0xA9, 0x3F, 0xD0, 0x02])
    use25 = here()
    code += bytes([0xA9, 0x25])
    code[bcc2 + 1] = use25 - (bcc2 + 2)
    code[bcs2 + 1] = use25 - (bcs2 + 2)
    code += bytes([0x18, 0x65, 0x20, 0x53, 0x08, 0x4C, 0xA8, 0xC1])
    return bytes(code)


def main():
    for i, lines in enumerate(OGROS):
        for L in lines:
            assert len(L) <= ANCHO, (i, len(L), L)
            for ch in L:
                assert ch in ENC, (i, ch, L)

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    tr = trampoline()
    assert all(b == 0xFF for b in rom[CAVE:CAVE + len(tr) + 1])
    assert all(b == 0xFF for b in orig[CAVE:CAVE + len(tr) + 1])
    assert rom[HOOK:HOOK + 10] == bytes.fromhex('a92418652053041a5308')

    packed = b''.join(msg(x) for x in OGROS)
    assert len(packed) < 2182, len(packed)
    assert all(b == 0xFF for b in rom[HOLE:HOLE + len(packed)])
    assert all(b == 0xFF for b in orig[HOLE:HOLE + len(packed)])

    w0 = bytes(rom[0x24DE:0x24E0])
    assert w0 == bytes([0x39, 0x67])

    keep = {
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4A4B9: bytes(rom[0x4A4B9:0x4A4D0]),
        0x4A739: bytes(rom[0x4A739:0x4A750]),
        0x1F881: bytes(rom[0x1F881:0x1F89E]),
    }

    rom[CAVE:CAVE + len(tr)] = tr
    rom[HOOK:HOOK + 3] = bytes([0x4C, 0x7D, 0xDD])
    rom[HOOK + 3:HOOK + 10] = bytes([0xEA] * 7)
    rom[HOLE:HOLE + len(packed)] = packed

    assert rom[HOOK:HOOK + 3] == bytes([0x4C, 0x7D, 0xDD])
    assert bytes(rom[CAVE:CAVE + len(tr)]) == tr
    assert bytes(rom[HOLE:HOLE + len(packed)]) == packed
    assert rom[0x24DE:0x24E0] == w0
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    assert packed.count(0) == 38

    # primer ogro: ¿Te gustó el $3B relleno? $3B ¡Ogro Onigiri! $00
    first = msg(OGROS[0])
    assert packed.startswith(first)
    assert first.count(0x3B) == 2
    assert packed[len(first) - 1] == 0

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.parent.mkdir(exist_ok=True)
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('v341 OK packed', len(packed), 'tramp', len(tr))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print('first', first.hex())


if __name__ == '__main__':
    main()
