#!/usr/bin/env python3
"""
v378 — Ó/Ú +1 px; Jizo «partes / a someter» sin juntar «¡Oh! ¡».

Base v376 (no v377). $72='es ' comía la «a» al final de la línea 16.
$81='es'+nl: mismas letras, «a someter» en la línea siguiente.
"""
import hashlib
import sys
import zlib
from pathlib import Path

sys.path.insert(0, '/home/user/Momotaro/tools')
from fuente_menu import encode as enc_menu, rom_off as menu_off
from glifos_es import encode as enc_1bpp

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v376.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v378.pce'
IPS = ROOT / 'parches/momotaro_v378.ips'
MD5_BASE = '4efa44386b687c4f5dc61d668d884248'
DIAL = 0x3D660

O_UP = [
    "....##..",
    ".#####..",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    ".#####..",
    "........",
]
U_UP = [
    "....##..",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    "##...##.",
    ".#####..",
    "........",
]


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    assert len(rom) == 524288

    for arte, byte in ((O_UP, 0xC5), (U_UP, 0xC6)):
        g1 = enc_1bpp(arte)
        rom[DIAL + byte * 8:DIAL + byte * 8 + 8] = g1
        rom[menu_off(byte):menu_off(byte) + 16] = enc_menu(arte)

    # ¡Oh! ¡ intacto
    j0 = 0x48E2A
    assert bytes(rom[j0:j0 + 7]) == bytes.fromhex('ca4fa82120ca65')
    old = bytes.fromhex('b0a1b2b472a13b')  # part + es_ + a + nl
    new = bytes.fromhex('b0a1b2b481a120')  # part + es| + a + space
    assert len(old) == len(new)
    blob = bytearray(rom[j0:0x48F18])
    i = bytes(blob).index(old)
    blob[i:i + len(old)] = new
    rom[j0:0x48F18] = blob
    assert rom[0x48F18] == 0x42
    assert bytes(rom[j0:j0 + 7]) == bytes.fromhex('ca4fa82120ca65')
    assert old not in bytes(rom[j0:0x48F18])
    v376 = BASE.read_bytes()
    for o, n in ((0x4AD56, 32), (0x4B80E, 24), (0x03D7D, 8)):
        assert bytes(rom[o:o + n]) == v376[o:o + n]

    d = bytes(rom)
    SALIDA.write_bytes(d)
    rec, i, difv = [], 0, [j for j in range(len(d)) if d[j] != orig[j]]
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v378 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
