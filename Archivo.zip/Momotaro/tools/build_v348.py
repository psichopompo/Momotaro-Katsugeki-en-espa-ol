#!/usr/bin/env python3
"""
v348 — felicitación + staff corto Fácil/Normal en 0x4A4B9.

Base v345 (ogros+trampolín intactos). Mismo ENC $C190.
$3B salto; no $3B tras línea de 16. $01$02 página, $03 pausa (como JP).
$5C alrededor del cargo. Un solo $00 de cierre de bloque (sin relleno $00).
No se pisa 0x4A739+ (ogros JP muertos OK si hace falta), ni 0x4AC8B, ni
0x4AD56. word0 0x24DE INTOCABLE.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v345.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v348.pce'
IPS = ROOT / 'parches/momotaro_v348.ips'
MD5_BASE = '91c7d2fc96ca2e67236b38ca7d79c018'

START = 0x4A4B9
LIMITE = 0x4AC8B  # dados; no tocar
LIMPIADOR = 0x4AD56
ANCHO = 16

ENC = {
    ' ': 0x20, '!': 0x21, '?': 0x3F, '¡': 0xCA, '¿': 0xC9,
    '.': 0xCB, ',': 0xCC, ':': 0xCD, '…': 0xCB,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xC5, 'Ó': 0xC5, 'ú': 0xBF,
    'ñ': 0xC1, 'Ñ': 0xC8, 'Á': 0xC2,
    'b': 0xA2, 'c': 0xA3, 'p': 0xB0,
    'a': 0xA1, 'd': 0xA4, 'e': 0xA5, 'f': 0xA6, 'g': 0xA7, 'h': 0xA8,
    'i': 0xA9, 'j': 0xAA, 'k': 0xAB, 'l': 0xAC, 'm': 0xAD, 'n': 0xAE,
    'o': 0xAF, 'q': 0xB1, 'r': 0xB2, 's': 0xB3, 't': 0xB4, 'u': 0xB5,
    'v': 0xB6, 'w': 0xB7, 'x': 0xB8, 'y': 0xB9, 'z': 0xBA,
}
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)


def enc(s):
    return bytes(ENC[ch] for ch in s)


def lines(xs):
    out = bytearray()
    for i, L in enumerate(xs):
        assert 1 <= len(L) <= ANCHO, (len(L), L)
        out += enc(L)
        if i < len(xs) - 1 and len(L) < ANCHO:
            out.append(0x3B)
    return bytes(out)


def cargo(s):
    assert len(s) <= ANCHO
    raw = enc(s)
    if any(b >= 0x80 for b in raw):
        return raw  # $5C+$3741 rompe Á/Ó
    return bytes([0x5C]) + raw + bytes([0x5C])


def nl_pause(b, last_len):
    """$03 no salta de línea: hace falta $3B si la línea no llenó 16."""
    if last_len < ANCHO:
        b.append(0x3B)
    b.append(0x03)


def pack():
    b = bytearray()
    # página 1
    b += lines(['¡Enhorabuena!', 'Has terminado', 'Momotaro en', 'Acción.'])
    nl_pause(b, len('Acción.'))
    b += lines(['Presume ante', 'todos: eres un', 'as de la acción.'])
    b += bytes([0x01, 0x02])
    # página 2
    b += lines(['Y ahora, con', 'permiso, os', 'presento a los', 'enemigos.'])
    b += bytes([0x01, 0x00])
    staff_at = len(b)
    # staff intro
    b.append(0x02)
    b += lines(['El equipo de', 'Momotaro en', 'Acción.'])
    b += bytes([0x01, 0x02])
    # asistentes
    b += cargo('ASISTENTE')
    b.append(0x3B)
    asis = [
        'Hiroyuki Iizuka.',
        'Masakazu Hakuya.',
        'T. Hattori.',
        'Hitoshi Araki.',
        'Santa Kuniyake.',
        'Hiroshi Izawa.',
        'Tomoo Oi.',
    ]
    for i, n in enumerate(asis):
        b += enc(n)
        if i < 6:
            nl_pause(b, len(n))
        else:
            b.append(0x01)
    b.append(0x02)
    # hudson
    b += lines(['El staff de', 'Hudson.'])
    b += bytes([0x01, 0x02])
    bloques = [
        ('PROGRAMADOR', ['Hitoshi Okuno.']),
        ('AYUD. PROG.', ['Yasuhiro Kosaka.']),
        ('GRÁFICOS', ['Fumie Takaoka.', 'A. Kakutani.', 'Kayo Fujimoto.']),
        ('SONIDO', ['T. Takimoto.', 'Keita Hoshi.']),
        ('DIRECTOR', ['S. Fujiwara.']),
    ]
    for ci, (c, ns) in enumerate(bloques):
        b += cargo(c)
        b.append(0x3B)
        for ni, n in enumerate(ns):
            b += enc(n)
            last = ci == len(bloques) - 1 and ni == len(ns) - 1
            if last:
                b.append(0x01)
            else:
                nl_pause(b, len(n))
    b.append(0x02)
    b += lines(['De verdad,', '¡gracias a', 'todos!'])
    nl_pause(b, len('todos!'))
    b += lines(['No olvidéis', 'el valor de', 'Momotaro.'])
    nl_pause(b, len('Momotaro.'))
    b += lines(['Nos veremos', 'en algún sitio.'])
    b += bytes([0x01, 0x02])
    b += cargo('PRODUCCIÓN')
    b.append(0x3B)
    b += enc('HUDSON SOFT')
    b.append(0x00)
    return bytes(b), staff_at


def main():
    for ch in 'áéíóúñÁÓ¡¿.,:':
        assert ch in ENC
    blob, staff_off = pack()
    assert blob.count(0) == 2, blob.count(0)
    assert blob[0] == ENC['¡']
    assert blob.endswith(b'\x00')
    assert blob[staff_off] == 0x02
    staff_cpu = 0x64B9 + staff_off
    assert 0x6400 <= staff_cpu < 0x6700, hex(staff_cpu)
    print('pack', len(blob), 'staff', hex(staff_cpu), 'limite', LIMITE - START)

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    assert len(blob) <= LIMITE - START

    w0 = bytes(rom[0x24DE:0x24DE + 38 * 8])
    keep = {
        0x0219E: bytes(rom[0x0219E:0x021A1]),  # JMP trampolín
        0x03D7D: bytes(rom[0x03D7D:0x03D7D + 16]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 32]),
        LIMPIADOR: bytes(rom[LIMPIADOR:LIMPIADOR + 32]),
        0x4AC8B: bytes(rom[0x4AC8B:0x4AC8B + 16]),
    }
    assert keep[0x0219E][:1] == b'\x4C'
    assert rom[0x216C:0x2174] == bytes.fromhex('a9338594a9658595')

    fin = START + len(blob)
    rom[START:fin] = blob
    rom[0x216C:0x2174] = bytes([
        0xA9, staff_cpu & 0xFF, 0x85, 0x94,
        0xA9, staff_cpu >> 8, 0x85, 0x95,
    ])
    # no rellenar con $00

    assert bytes(rom[START:fin]) == blob
    assert bytes(rom[0x24DE:0x24DE + 38 * 8]) == w0
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    assert fin <= 0x4A739  # no pisar ranura JP de ogros
    assert bytes(rom[LIMPIADOR:LIMPIADOR + 32]) == keep[LIMPIADOR]

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.parent.mkdir(exist_ok=True)
    IPS.write_bytes(parche)
    print('v348 OK pack', len(blob), 'end', hex(fin))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
