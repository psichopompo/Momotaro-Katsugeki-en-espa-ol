#!/usr/bin/env python3
"""
v369 — experimento: pack Difícil SIN $5C, solo líneas de 8 + $00.

Si $5C se pinta como glifo o se come bytes, las palabras deben verse enteras.
Mismo gancho v367/v368. Base v362.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v362.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v369.pce'
IPS = ROOT / 'parches/momotaro_v369.ips'
MD5_BASE = '311f6adac43ee49af137adda79c23a35'
CRED, BANK_END = 0x3B800, 0x3C000
CAVE, CAVE_CPU = 0x03E73, 0xDE73
STASH = 0x11480

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA, '.': 0xCB, ',': 0xCC, ':': 0xCD,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
    ENC[c] = ord(c)

LINEAS = [
    'DIRECC.', 'Shoji', 'Masuda',
    'PERSON.', 'Takayuki', 'Doi',
    'PROGRAM.', 'Hitoshi', 'Okuno',
    'AY.PROG.', 'Yasuhiro', 'Kosaka',
    'GRAFICOS', 'Fumie', 'Takaoka',
    'GRAFICOS', 'Atsushi', 'Kakutani',
    'GRAFICOS', 'Kayo', 'Fujimoto',
    'SONIDO', 'T.', 'Takimoto',
    'SONIDO', 'Keita', 'Hoshi',
    'DIRECTOR', 'Shigeki', 'Fujiwara',
    'PRODUCC.', 'HUDSON', 'SOFT',
    'ASIST.', 'H.Iizuka',
    'ASIST.', 'M.Hakuya',
    'ASIST.', 'T.', 'Hattori',
    'ASIST.', 'Hitoshi', 'Araki',
    'ASIST.', 'S.', 'Kuniyake',
    'ASIST.', 'Hiroshi', 'Izawa',
    'ASIST.', 'Tomoo Oi',
    'MUSICA', 'Michiko', 'Yoshida',
    'SUPERV.', 'Akira', 'Sakuma',
]


def enc(s):
    return bytes(ENC[ch] for ch in s)


def tramp(hard_cpu):
    lo, hi = hard_cpu & 0xFF, hard_cpu >> 8
    code = bytearray(bytes.fromhex('ad333d2903c902'))
    bcs = len(code)
    code += bytes([0xB0, 0])
    code += bytes([0xA9, 0x00, 0x85, 0xBF, 0xA9, 0x58, 0x85, 0xC0])
    bra = len(code)
    code += bytes([0x80, 0])
    hard = len(code)
    code[bcs + 1] = (hard - (bcs + 2)) & 0xFF
    code += bytes([0xA9, lo, 0x85, 0xBF, 0xA9, hi, 0x85, 0xC0])
    go = len(code)
    code[bra + 1] = (go - (bra + 2)) & 0xFF
    code += bytes.fromhex('9ca63b9ce43c9ce33ca90185c3a9108de53c60')
    return bytes(code)


def main():
    for L in LINEAS:
        assert 1 <= len(L) <= 8, L
        for ch in L:
            assert ch in ENC, ch
    hard = b'\x00'.join(enc(L) for L in LINEAS) + b'\xff'
    assert 0x5C not in hard
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    assert rom[0x3BA2:0x3BA8] == bytes.fromhex('a90085bfa958')
    assert rom[STASH:STASH + 3] == bytes.fromhex('9c333d')
    easy_end = CRED
    while rom[easy_end] != 0xFF:
        easy_end += 1
    easy_head = bytes(rom[CRED:CRED + 8])
    hard_off = (easy_end + 2) & ~1
    assert hard_off + len(hard) <= BANK_END
    hard_cpu = 0x5800 + (hard_off - CRED)
    tr = tramp(hard_cpu)
    assert all(b == 0xFF for b in rom[CAVE:CAVE + len(tr) + 2])
    keep = {
        0x4AD56: bytes(rom[0x4AD56:0x4AD76]),
        0x4B80E: bytes(rom[0x4B80E:0x4B826]),
        0x03D7D: bytes(rom[0x03D7D:0x03D7D + 8]),
        0x7EF7A: bytes(rom[0x7EF7A:0x7EF7A + 8]),
    }
    rom[STASH] = 0x8D
    rom[CAVE:CAVE + len(tr)] = tr
    rom[0x3BA2:0x3BA5] = bytes([0x4C, CAVE_CPU & 0xFF, CAVE_CPU >> 8])
    rom[hard_off:hard_off + len(hard)] = hard
    assert bytes(rom[CRED:CRED + 8]) == easy_head
    assert 0x5C not in bytes(rom[CRED:easy_end])
    assert enc('DIRECC.') in bytes(rom[hard_off:hard_off + len(hard)])
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v, hex(o)
    d = bytes(rom)
    SALIDA.write_bytes(d)
    rec, i, difv = [], 0, [j for j in range(len(d)) if d[j] != orig[j]]
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v369 OK hard', hex(hard_cpu), 'n', len(hard))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
