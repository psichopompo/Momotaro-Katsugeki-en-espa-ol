#!/usr/bin/env python3
"""
build_v286.py - menu Game Over en castellano, sin tocar 1F7B6.

$572D SI es tabla de punteros ($D709). El recorte a 4 letras es VRAM:
$D75F deja $80 (4 glifos de $20) entre opciones; lo que sobra lo pisa
la siguiente. Se abre a $140 (10 glifos) y se mueve el password a $74C8.

Titulo «SE ACABO» in situ (sin tilde: $C5 aqui sale minuscula).
Continuar/Terminar/Guardar en $5FDD (35 B a $FF).

Uso:  python3 tools/build_v286.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import encode                        # noqa: E402

BASE = 'roms/momotaro_es_v285.pce'
SALIDA = 'roms/momotaro_es_v286.pce'
IPS = 'parches/momotaro_v286.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '71ec45d62582f9b63935558d9769dc89'


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v285 OK')

    assert rom[0x1F72D:0x1F735] == bytes.fromhex('395745574c575157')
    assert rom[0x1B75F:0x1B767] == bytes.fromhex('0870087188710872')
    assert rom[0x1B767:0x1B769] == bytes.fromhex('8872')

    # destinos VRAM: 10 celdas ($140) cada opcion
    # titulo $7008, cont $7148, end $7288, save $73C8, pass $74C8
    rom[0x1B75F:0x1B767] = bytes.fromhex('087048718872c873')
    rom[0x1B767:0x1B769] = bytes.fromhex('c874')
    print('VRAM D75F/D767 OK')

    # titulo
    go = bytes([0x02]) + encode('SE ACABO') + b'\x00'
    assert len(go) <= 12
    assert rom[0x1F739] == 0x02
    rom[0x1F739:0x1F739 + 12] = go + bytes(12 - len(go))

    hole = 0x1FFDD
    assert rom[hole:hole + 35] == b'\xFF' * 35
    bloques = [
        bytes([0x01]) + encode('Continuar') + b'\x00',
        bytes([0x01]) + encode('Terminar') + b'\x00',
        bytes([0x02]) + encode('Guardar') + b'\x00',
    ]
    o = hole
    ptrs = []
    for bl in bloques:
        ptrs.append(0x4000 + (o - 0x1E000))
        rom[o:o + len(bl)] = bl
        o += len(bl)
    assert o - hole <= 35
    rom[0x1F72F] = ptrs[0] & 0xFF
    rom[0x1F730] = ptrs[0] >> 8
    rom[0x1F731] = ptrs[1] & 0xFF
    rom[0x1F732] = ptrs[1] >> 8
    rom[0x1F733] = ptrs[2] & 0xFF
    rom[0x1F734] = ptrs[2] >> 8
    print('ptrs', [hex(p) for p in ptrs])

    # password table intacta
    assert rom[0x1F7B6] == base[0x1F7B6]
    assert rom[0x1F7B7] == 0x20
    assert rom[0x1B9EE + 3] == 0x3A

    intactas = [
        ('pass table', 0x1F7B6, 0x1F836),
        ('CAD6', 0x16AD6, 0x16B16),
        ('caramelos', 0x4964D, 0x49670),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
