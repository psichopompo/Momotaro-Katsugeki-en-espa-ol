#!/usr/bin/env python3
"""
v359 — Toma en línea 2 por relleno a 16, no $80.

$80 en este bloque TERMINA (se comió «Toma: ¡»).
¡Bien hecho! (12) + 4×$A0 = col 16; «Toma: ¡» + $00.
El $00 baja de 0x4B824 a 0x4B825 (era $A0 de cola).
Base v358 (Así que OK).
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v358.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v359.pce'
IPS = ROOT / 'parches/momotaro_v359.ips'
MD5_BASE = '38b2582e1a2e8d4a3fce32ccb9deb6cd'


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    assert rom[0x4B80E:0x4B81A] == bytes.fromhex('ca42a9a5ae20a8a5a3a8af21')
    # 12 + 4 A0 + Toma: ¡ + 00
    blob = bytes.fromhex('ca42a9a5ae20a8a5a3a8af21')  # 12
    blob += bytes([0xA0] * 4)
    blob += bytes.fromhex('54afada1cd20ca')  # Toma: ¡
    blob += b'\x00'
    assert len(blob) == 24
    assert blob[16:23] == bytes.fromhex('54afada1cd20ca')
    rom[0x4B80E:0x4B80E + 24] = blob
    assert rom[0x4B824] == 0xCA
    assert rom[0x4B825] == 0x00
    # Así que intacto
    assert bytes.fromhex('c941b3bd2061') in bytes(rom[0x48E2A:0x48E50])
    assert all(rom[0x4AD56 + k] == 0x20 for k in range(32))

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v359 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
