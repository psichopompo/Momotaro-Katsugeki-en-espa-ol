#!/usr/bin/env python3
"""
build_v282.py - caramelos Kintaro + menu GAME OVER.

1. Guion: quitar « de» delante de Kintaro (2 dialogos).
2. Game Over: SE ACABÓ / Continuar / Terminar / Guardar
   y «¡Guardado!». Opciones largas en $5FDD (35 B virgen $FF).

Uso:  python3 tools/build_v282.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE, encode          # noqa: E402

BASE = 'roms/momotaro_es_v281.pce'
SALIDA = 'roms/momotaro_es_v282.pce'
IPS = 'parches/momotaro_v282.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '4a494b4744882cddf001c34b747f2620'

DE = bytes([0xA4, 0xA5])  # 'd''e' oficial


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v281 OK')

    # --- caramelos de -> caramelos ---
    # dos dialogos, « de» es literal $A4 $A5 tras el $60 (os)
    cortes = [
        (0x4964D, 0x496A9),
        (0x496A9, 0x496FE),
    ]
    for a, b in cortes:
        chunk = bytearray(rom[a:b])
        n = chunk.count(DE)
        assert n >= 1, hex(a)
        chunk2 = chunk.replace(DE, b'')
        assert len(chunk2) == len(chunk) - 2 * n or True
        # solo el « de» junto a Kintaro: $60 $A4 $A5 $3B $7D
        old = bytes([0x60, 0xA4, 0xA5, 0x3B, 0x7D])
        new = bytes([0x60, 0x3B, 0x7D])
        c = bytes(rom[a:b])
        k = c.count(old)
        assert k >= 1, (hex(a), c.hex())
        d = c.replace(old, new)
        assert len(d) == len(c) - 2 * k
        d = d + bytes(len(c) - len(d))
        assert len(d) == b - a
        rom[a:b] = d
        print('caramelos %s  -%d de' % (hex(a), k))

    # --- GAME OVER titulo in situ ---
    go = 0x1F739
    assert rom[go:go + 12] == bytes.fromhex('02b9de5fd120b55fcade5f00')
    tit = bytes([0x02]) + encode('SE ACABÓ') + bytes([0x00])
    assert len(tit) <= 12
    rom[go:go + 12] = tit + bytes(12 - len(tit))
    print('titulo', tit, len(tit))

    # --- opciones a $5FDD ---
    hole, hole_n = 0x1FFDD, 35
    assert rom[hole:hole + hole_n] == b'\xFF' * hole_n
    assert orig[hole:hole + hole_n] == b'\xFF' * hole_n
    bloques = [
        bytes([0x01]) + encode('Continuar') + b'\x00',
        bytes([0x01]) + encode('Terminar') + b'\x00',
        bytes([0x02]) + encode('Guardar') + b'\x00',
    ]
    o = hole
    ptrs = []
    for bl in bloques:
        ptrs.append(0x4000 + (o - 0x1E000))
        rom[o:o + len(bl)] = bl
        o += len(bl)
    assert o - hole <= hole_n
    print('opciones', [hex(p) for p in ptrs], 'usan', o - hole)

    # tabla 1F72D: $5739 $5745 $574C $5751 $5757...
    tab = 0x1F72D
    assert rom[tab:tab + 8] == bytes.fromhex('395745574c575157')
    rom[tab + 2] = ptrs[0] & 0xFF
    rom[tab + 3] = ptrs[0] >> 8
    rom[tab + 4] = ptrs[1] & 0xFF
    rom[tab + 5] = ptrs[1] >> 8
    rom[tab + 6] = ptrs[2] & 0xFF
    rom[tab + 7] = ptrs[2] >> 8
    assert rom[tab:tab + 2] == bytes.fromhex('3957')  # GO no se mueve

    # ¡Guardado!
    sv = 0x1F7AA
    assert rom[sv:sv + 12] == bytes.fromhex('02beb0ccde5cbccfbcc021ff')
    msg = bytes([0x02]) + encode('¡Guardado!') + b'\xFF'
    assert len(msg) == 12
    rom[sv:sv + 12] = msg
    print('guardado', len(msg))

    # releer caramelos
    for a, b, extra in ((0x4964D, 0x496A9, 1), (0x496A9, 0x496FE, 2)):
        assert bytes(rom[a:b]).find(bytes([0x60, 0xA4, 0xA5, 0x3B, 0x7D])) < 0
        assert bytes(rom[a:b]).count(bytes([0x60, 0x3B, 0x7D])) >= extra

    intactas = [
        ('abuelo textos', 0x48C7E, 0x48E2A),
        ('fuente', 0x3D660, 0x3E200),
        ('parrilla pass', 0x1F7B8, 0x1F7E0),
        ('Nadie', 0x431B4, 0x431BB),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
