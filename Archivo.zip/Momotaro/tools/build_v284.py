#!/usr/bin/env python3
"""
build_v284.py - password del Game Over en latino (como el Jizo).

$D9EE: LDA $3C94,X / ASL / ADC #$B6 -> tabla $57B6 (ROM 0x1F7B6).
64 words, primer byte = codigo a $AA69. Ahora son kana ($B1..) pintados
con fuente latina = basura.

Igual que $CA73/$CAD6: DEC A (valores 1..64, nunca 0) y la tabla pasa a
ser la parrilla latina. CLC sobra (ASL de 0..63 no genera carry).

Uso:  python3 tools/build_v284.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE                  # noqa: E402
from dis6280 import desensambla                            # noqa: E402

BASE = 'roms/momotaro_es_v283.pce'
SALIDA = 'roms/momotaro_es_v284.pce'
IPS = 'parches/momotaro_v284.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '8afbc66674ecf1be0109a0c40ee6f755'

D9EE = 0x1B9EE
TAB = 0x1F7B6
CHARS = 'ABCDEFGabcdefgHIJKLMNhijklmnÑOPQRSTñopqrstUVWXYZuvwxyz0123456789'
assert len(CHARS) == 64

MAP = dict(CHAR_TO_CODE)
MAP['b'] = 0xA2
MAP['c'] = 0xA3
MAP['p'] = 0xB0


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v283 OK')

    print('D9EE', rom[D9EE:D9EE + 8].hex())
    assert rom[D9EE:D9EE + 3] == bytes.fromhex('bd943c')
    assert rom[D9EE + 3] == 0x0A and rom[D9EE + 4] == 0x18
    rom[D9EE + 3] = 0x3A  # DEC A
    rom[D9EE + 4] = 0x0A  # ASL A
    # 69 B6 ADC se queda; el CLC se sustituye por el ASL y el ASL viejo por DEC
    dsm = desensambla(bytes(rom), D9EE, 7, 0xD9EE)
    for x in dsm:
        print('  $%04X  %s' % (x[1], x[3]))
    assert dsm[0][3] == 'LDA $3C94,X' and dsm[1][3] == 'DEC A'
    assert dsm[2][3] == 'ASL A' and dsm[3][3] == 'ADC #$B6'

    assert rom[TAB:TAB + 4] == bytes.fromhex('2020b120')
    codes = bytes(MAP[ch] for ch in CHARS)
    for i, c in enumerate(codes):
        rom[TAB + i * 2] = c
        # segundo byte se deja ($20 o $DE/$DF): $AA69 solo lee el primero
    # simular
    for v in range(1, 65):
        idx = (v - 1) * 2
        got = rom[TAB + idx]
        assert got == codes[v - 1], (v, got, codes[v - 1])
    print('tabla 64/64 OK  %s' % CHARS)

    intactas = [
        ('1F72D tilemap', 0x1F72D, 0x1F739),
        ('GO japones', 0x1F739, 0x1F758),
        ('cargar prompt', 0x1F836, 0x1F860),
        ('caramelos', 0x4964D, 0x49660),
        ('CAD6 Jizo', 0x16AD6, 0x16B16),
        ('fuente', 0x3D660, 0x3E200),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
