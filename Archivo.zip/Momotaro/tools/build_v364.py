#!/usr/bin/env python3
"""
v364 — revertir JMP $DE73. Fácil otra vez en $5800.

$3B28&3 no distingue Fácil/Difícil (ambos caían al bloque $5C).
Cueva $DE73 y el blob $5C se dejan (no se ejecutan).
Base v363.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v363.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v364.pce'
IPS = ROOT / 'parches/momotaro_v364.ips'
MD5_BASE = '0ccc355f17fd7ce652be0e2bb64535ff'


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_BASE
    assert rom[0x3BA2:0x3BA5] == bytes([0x4C, 0x73, 0xDE])
    # original DBA2 cabeza
    rom[0x3BA2:0x3BA8] = bytes.fromhex('a90085bfa958')
    assert rom[0x3BA2:0x3BA8] == bytes.fromhex('a90085bfa958')
    assert rom[0x3BA8:0x3BBD] == bytes.fromhex('85c09ca63b9ce43c9ce33ca90185c3a9108de53c60')
    assert all(rom[0x4AD56 + k] == 0x20 for k in range(32))

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v364 OK DBA2 restaurado')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
