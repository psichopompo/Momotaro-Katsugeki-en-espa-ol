#!/usr/bin/env python3
"""
build_v283.py - revertir el Game Over. Caramelos se quedan.

CAUSA
=====
Trate 1F72D (39 57 45 57 4C 57 51 57 ...) como tabla de punteros y
escribi $5FDD/$5FE8/$5FF2. Ese bloque es identico en la virgen y va
justo delante del stream: es el mismo patron xx 57 que una tilemap.
Al cambiarlo se rompen parrilla, restos en Cargar y sprites basura.

Las cadenas nuevas en $5FDD se leian (Cont/Term/Guar = 4 celdas) pero
el precio fue corromper datos compartidos.

Se restaura 1F72D-1F757, 1F7AA-1F7B5 y 1FFDD desde la v281.
Los caramelos de 0x4964D no se tocan.

Uso:  python3 tools/build_v283.py
"""
import hashlib
import zlib
import sys

BASE = 'roms/momotaro_es_v282.pce'
BUENA = 'roms/momotaro_es_v281.pce'
SALIDA = 'roms/momotaro_es_v283.pce'
IPS = 'parches/momotaro_v283.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '5981803188e357f3ecbd5735dfb960a9'


def main():
    rom = bytearray(open(BASE, 'rb').read())
    buena = open(BUENA, 'rb').read()
    orig = open(VIRGEN, 'rb').read()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v282 OK')

    for a, b, nom in (
        (0x1F72D, 0x1F758, 'GO stream+tabla'),
        (0x1F7AA, 0x1F7B6, 'Guardado'),
        (0x1FFDD, 0x20000, 'hueco $5FDD'),
    ):
        rom[a:b] = buena[a:b]
        assert bytes(rom[a:b]) == buena[a:b]
        print('restaurado', nom, hex(a))

    assert bytes(rom[0x1F72D:0x1F739]) == bytes.fromhex('395745574c57515757575757')
    assert rom[0x1F739:0x1F73C] == bytes.fromhex('02b9de')
    # caramelos siguen sin « de»
    assert bytes(rom[0x4964D:0x496A9]).find(bytes([0x60, 0xA4, 0xA5, 0x3B, 0x7D])) < 0

    d = bytes(rom)
    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
