#!/usr/bin/env python3
"""
build_v276.py - la 'b' del abuelo + «¡Obtienes 100 ryos!»

BASE: v275 (trampolin $DE78 ya pone $368F=2).

CAUSA DE LA ©
=============
charset_oficial codifica 'b' como $5B (alias de la ruta $AB34 / intro).
Este bocadillo va por $9801: SEC / SBC #$20 / LDA $9C73,Y.
$5B-$20=$3B -> glifo $8B = una C en recuadro (la © negra).

[HECHO] El guion de aldeanos usa $A2='b', $A3='c', $B0='p'. Cero $5B.

ESPACIO
=======
«¡Obtienes 100 ryos!» son 2 lineas y no caben en plano si «Obtienes»
ocupa 8 B. Se usa la entrada $7C del diccionario ('ien'), la misma
que el guion: O $A2 $7C e s. 5 B, se lee «Obtienes».

Uso:  python3 tools/build_v276.py
"""
import hashlib
import zlib
import sys

sys.path.insert(0, 'tools')
from charset_oficial import CHAR_TO_CODE                  # noqa: E402

BASE = 'roms/momotaro_es_v275.pce'
SALIDA = 'roms/momotaro_es_v276.pce'
IPS = 'parches/momotaro_v276.ips'
VIRGEN = 'roms/Momotarou Katsugeki (Japan).pce'
MD5_BASE = '6d60398bf1d31df6397dafce47925f9c'

TABLA = 0x16969
BANCO24 = 0x48000 - 0x4000
NL, FIN, COLS = 0x3B, 0x00, 14
ZONA_INI, ZONA_FIN = 0x48C7E, 0x48E2A

# este motor, no el de la intro
MAP = dict(CHAR_TO_CODE)
MAP['b'] = 0xA2
MAP['c'] = 0xA3
MAP['p'] = 0xB0
IEN = bytes([0xA9, 0xA5, 0xAE])   # i e n
IEN_DICC = bytes([0x7C])          # $7C = «ien»

TEXTOS = [
    ('Obtienes el', 'Onigiri.'),
    ('Obtienes el', 'Manjar.'),
    ('Obtienes el', 'Banquete.'),
    ('Obtienes un', 'Dango.'),
    ('Obtienes los', 'Pedos.'),
    ('Obtienes la', 'Solar.'),
    ('Obtienes la', 'Glacial.'),
    ('Obtienes la', 'Capa.'),
    ('¡Obtienes 100', 'ryos!'),
    ('¡Obtienes 50', 'ryos!'),
    ('¡Obtienes 30', 'ryos!'),
    ('¡Obtienes 10', 'ryos!'),
    ('No puedes', 'llevar más.'),
    ('El perro te', 'acompaña.'),
    ('El faisán te', 'acompaña.'),
    ('El mono te', 'acompaña.'),
    ('Obtienes el', 'caparazón.'),
    ('Obtienes el', 'Bonzo.'),
    ('¡Obtienes 80', 'ryos!'),
    ('¡Obtienes 20', 'ryos!'),
    ('¡Menudo', 'idiota!'),
    ('Sigue hacia', 'arriba'),
    ('Sigue a la', 'derecha.'),
]


def enc(s):
    raw = bytes(MAP[ch] for ch in s)
    return raw.replace(IEN, IEN_DICC)


def main():
    rom = bytearray(open(BASE, 'rb').read())
    orig = open(VIRGEN, 'rb').read()
    base = bytes(rom)
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    print('base v275 OK')
    assert rom[0x168D2:0x168D5] == bytes([0x4C, 0x78, 0xDE])
    assert rom[0x17E78:0x17E7D] == bytes([0xA9, 0x02, 0x8D, 0x8F, 0x36])

    bloques = []
    print('\n--- textos')
    for k, parts in enumerate(TEXTOS):
        for l in parts:
            assert len(l) <= COLS, l
        b = enc(parts[0])
        if len(parts) > 1:
            b += bytes([NL]) + enc(parts[1])
        b += bytes([FIN])
        assert 0x5B not in b and 0x5D not in b and 0x5E not in b, b.hex()
        bloques.append(b)
        print('   [%2d] %s  %d B' % (k, ' / '.join(parts), len(b)))

    total = sum(len(b) for b in bloques)
    print('caben %d / %d' % (total, ZONA_FIN - ZONA_INI))
    assert total <= ZONA_FIN - ZONA_INI

    o = ZONA_INI
    for k, b in enumerate(bloques):
        cpu = o - BANCO24
        rom[TABLA + k * 2] = cpu & 0xFF
        rom[TABLA + k * 2 + 1] = cpu >> 8
        rom[o:o + len(b)] = b
        o += len(b)
    if o < ZONA_FIN:
        rom[o:ZONA_FIN] = bytes([FIN]) * (ZONA_FIN - o)

    inv = {v: k for k, v in MAP.items()}
    inv[0x7C] = 'ien'
    print('\n--- releido')
    for k in range(23):
        p = rom[TABLA + k * 2] | (rom[TABLA + k * 2 + 1] << 8)
        a = BANCO24 + p
        end = a
        while rom[end] != FIN:
            end += 1
        got = '/'.join(
            ''.join(inv.get(x, '{%02X}' % x) for x in pte)
            for pte in bytes(rom[a:end]).split(bytes([NL])))
        exp = '/'.join(TEXTOS[k])
        assert got == exp, '[%d] %r != %r' % (k, got, exp)
        print('   [%2d] $%04X  %s' % (k, p, got))

    intactas = [
        ('guion', 0x48E2A, 0x4A484),
        ('fuente', 0x3D660, 0x3E200),
        ('trampolin', 0x17E78, 0x17E86),
        ('$C8D2', 0x168D2, 0x168D5),
        ('$9C73', 0x41C73, 0x41D00),
    ]
    for nom, a, b in intactas:
        assert bytes(rom[a:b]) == base[a:b], nom

    d = bytes(rom)
    dif = [i for i in range(len(d)) if d[i] != base[i]]
    ok = set(range(TABLA, TABLA + 46)) | set(range(ZONA_INI, ZONA_FIN))
    extra = [hex(i) for i in dif if i not in ok]
    assert not extra, extra
    print('%d bytes sobre v275 (solo textos)' % len(dif))

    open(SALIDA, 'wb').write(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    open(IPS, 'wb').write(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('IPS OK')
    print('\n%s' % SALIDA)
    print('  MD5    %s' % hashlib.md5(d).hexdigest())
    print('  SHA-1  %s' % hashlib.sha1(d).hexdigest())
    print('  CRC32  %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
