#!/usr/bin/env python3
"""build_v306.py - un byte de más: «¡Llévate armas!» (shop 0 [0] línea 2)."""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v305.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v306.pce'
IPS = ROOT / 'parches/momotaro_v306.ips'
MD5_BASE = '37dad557c2fba4bdea01b3e0ccdf9f7b'

OFF = 0x4847D


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    # línea 1 intacta; línea 2 era ¡Lleva armas!
    assert rom[OFF:OFF + 16] == bytes.fromhex('ca50a1b3a121a0a0a0a0a0a0a0a0a0a0')
    assert rom[OFF + 16:OFF + 32] == bytes.fromhex('ca4caca5b6a120a1b2ada1b321a0a0a0')
    keep = {
        0x2F8B5: bytes(rom[0x2F8B5:0x2F8C5]),
        0x105F3: bytes(rom[0x105F3:0x1060E]),
        0x1F9C4: bytes(rom[0x1F9C4:0x1F9D6]),
        0x10854: bytes(rom[0x10854:0x108C0]),
        0x10929: bytes(rom[0x10929:0x10929 + 80]),
    }
    # ¡ L l é v a t e [ ] a r m a s !
    rom[OFF + 16:OFF + 32] = bytes.fromhex('ca4cacbcb6a1b4a520a1b2ada1b321a0')
    assert rom[OFF + 16:OFF + 32] == bytes.fromhex('ca4cacbcb6a1b4a520a1b2ada1b321a0')
    assert rom[OFF:OFF + 16] == bytes.fromhex('ca50a1b3a121a0a0a0a0a0a0a0a0a0a0')
    for o, v in keep.items():
        assert bytes(rom[o:o + len(v)]) == v
    assert rom[0x47CFB] == 0xFF

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('v306 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
