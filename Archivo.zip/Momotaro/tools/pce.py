"""Arnés Beetle PCE (libretro). Ver docs/COMO_RETOMAR.md."""
from __future__ import annotations

import ctypes
import os
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
CORE = ROOT / 'tools/bin/mednafen_pce_libretro.so'

RETRO_DEVICE_JOYPAD = 1
RETRO_ENVIRONMENT_SET_PIXEL_FORMAT = 10
RETRO_PIXEL_FORMAT_RGB565 = 1
RETRO_MEMORY_SYSTEM_RAM = 0
RETRO_MEMORY_VIDEO_RAM = 1
RETRO_MEMORY_SAVE_RAM = 2

BTN = {
    'B': 0, 'II': 0, 'Y': 1, 'SELECT': 2, 'START': 3, 'RUN': 3,
    'UP': 4, 'DOWN': 5, 'LEFT': 6, 'RIGHT': 7,
    'A': 8, 'I': 8, 'X': 9,
}


class retro_game_info(ctypes.Structure):
    _fields_ = [
        ('path', ctypes.c_char_p),
        ('data', ctypes.c_void_p),
        ('size', ctypes.c_size_t),
        ('meta', ctypes.c_char_p),
    ]


class retro_system_av_info(ctypes.Structure):
    _fields_ = [
        ('geometry_base_w', ctypes.c_uint),
        ('geometry_base_h', ctypes.c_uint),
        ('geometry_max_w', ctypes.c_uint),
        ('geometry_max_h', ctypes.c_uint),
        ('geometry_aspect', ctypes.c_float),
        ('timing_fps', ctypes.c_double),
        ('timing_sample_rate', ctypes.c_double),
    ]


class PCE:
    def __init__(self, rom_path: str | Path):
        self._lib = ctypes.CDLL(str(CORE))
        self._fb = None
        self._pitch = 0
        self._w = 0
        self._h = 0
        self._held = 0
        self._rom = Path(rom_path).read_bytes()

        VIDEO_CB = ctypes.CFUNCTYPE(
            None, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_size_t)
        AUDIO_CB = ctypes.CFUNCTYPE(None, ctypes.c_int16, ctypes.c_int16)
        AUDIO_BATCH = ctypes.CFUNCTYPE(
            ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t)
        INPUT_POLL = ctypes.CFUNCTYPE(None)
        INPUT_STATE = ctypes.CFUNCTYPE(
            ctypes.c_int16, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint)
        ENV_CB = ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_uint, ctypes.c_void_p)

        def video(data, width, height, pitch):
            self._w, self._h, self._pitch = int(width), int(height), int(pitch)
            n = height * pitch
            self._fb = ctypes.string_at(data, n)

        def audio(l, r):
            pass

        def audio_batch(data, frames):
            return frames

        def input_poll():
            pass

        def input_state(port, device, index, id_):
            if port != 0:
                return 0
            return 1 if self._held & (1 << id_) else 0

        self._sysdir = ctypes.create_string_buffer(b'/tmp')
        self._savedir = ctypes.create_string_buffer(b'/tmp')

        def env(cmd, data):
            if cmd == RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
                return True
            # GET_SYSTEM_DIRECTORY = 9
            if cmd == 9 and data:
                ctypes.cast(data, ctypes.POINTER(ctypes.c_void_p))[0] = ctypes.cast(
                    self._sysdir, ctypes.c_void_p).value
                return True
            # GET_SAVE_DIRECTORY = 31
            if cmd == 31 and data:
                ctypes.cast(data, ctypes.POINTER(ctypes.c_void_p))[0] = ctypes.cast(
                    self._savedir, ctypes.c_void_p).value
                return True
            # GET_LOG_INTERFACE = 27 — ignore
            if cmd == 27:
                return False
            # SET_VARIABLES = 16
            if cmd == 16:
                return True
            # GET_VARIABLE = 15
            if cmd == 15:
                return False
            # SET_CONTROLLER_INFO = 35
            if cmd == 35:
                return True
            return False

        self._cb_video = VIDEO_CB(video)
        self._cb_audio = AUDIO_CB(audio)
        self._cb_abatch = AUDIO_BATCH(audio_batch)
        self._cb_ipoll = INPUT_POLL(input_poll)
        self._cb_istate = INPUT_STATE(input_state)
        self._cb_env = ENV_CB(env)

        L = self._lib
        L.retro_set_environment(self._cb_env)
        L.retro_set_video_refresh(self._cb_video)
        L.retro_set_audio_sample(self._cb_audio)
        L.retro_set_audio_sample_batch(self._cb_abatch)
        L.retro_set_input_poll(self._cb_ipoll)
        L.retro_set_input_state(self._cb_istate)
        L.retro_init()
        # sin esto no llega ningún botón
        L.retro_set_controller_port_device(0, RETRO_DEVICE_JOYPAD)

        buf = ctypes.create_string_buffer(self._rom)
        info = retro_game_info(
            path=str(rom_path).encode(),
            data=ctypes.cast(buf, ctypes.c_void_p),
            size=len(self._rom),
            meta=None,
        )
        self._rom_buf = buf
        L.retro_load_game.restype = ctypes.c_bool
        ok = L.retro_load_game(ctypes.byref(info))
        if not ok:
            info2 = retro_game_info(
                path=str(Path(rom_path).resolve()).encode(),
                data=None, size=0, meta=None)
            ok = L.retro_load_game(ctypes.byref(info2))
        if not ok:
            raise RuntimeError('retro_load_game failed')

    def run(self, frames: int = 1):
        for _ in range(frames):
            self._lib.retro_run()

    def press(self, *buttons, frames: int = 4):
        mask = 0
        for b in buttons:
            mask |= 1 << BTN[b.upper()]
        self._held = mask
        self.run(frames)
        self._held = 0
        self.run(2)

    def png(self, path: str | Path):
        from PIL import Image
        if not self._fb:
            self.run(1)
        w, h, pitch = self._w, self._h, self._pitch
        raw = self._fb
        img = Image.new('RGB', (w, h))
        px = img.load()
        for y in range(h):
            row = raw[y * pitch:(y + 1) * pitch]
            for x in range(w):
                v = row[x * 2] | (row[x * 2 + 1] << 8)
                r = ((v >> 11) & 31) * 255 // 31
                g = ((v >> 5) & 63) * 255 // 63
                b = (v & 31) * 255 // 31
                px[x, y] = (r, g, b)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        img.save(path)
        return path

    def _mem(self, which):
        L = self._lib
        L.retro_get_memory_data.restype = ctypes.c_void_p
        L.retro_get_memory_size.restype = ctypes.c_size_t
        ptr = L.retro_get_memory_data(which)
        sz = L.retro_get_memory_size(which)
        if not ptr or not sz:
            return b''
        return ctypes.string_at(ptr, sz)

    def ram(self):
        return self._mem(RETRO_MEMORY_SYSTEM_RAM)

    def vram(self):
        return self._mem(RETRO_MEMORY_VIDEO_RAM)

    def peek(self, addr: int) -> int:
        r = self.ram()
        return r[addr] if addr < len(r) else None

    def poke(self, addr: int, val: int):
        L = self._lib
        L.retro_get_memory_data.restype = ctypes.c_void_p
        ptr = L.retro_get_memory_data(RETRO_MEMORY_SYSTEM_RAM)
        ctypes.memset(ptr + addr, val & 0xFF, 1)

    def state(self) -> bytes:
        L = self._lib
        L.retro_serialize_size.restype = ctypes.c_size_t
        n = L.retro_serialize_size()
        buf = ctypes.create_string_buffer(n)
        if not L.retro_serialize(buf, n):
            raise RuntimeError('serialize failed')
        return buf.raw

    def load_state(self, blob: bytes):
        raw = blob
        if raw.startswith(b'#RZIPv'):
            import zlib
            raw = zlib.decompress(raw[24:])
        if raw[:7] == b'RASTATE':
            i = raw.find(b'MDFNSVST')
            if i < 0:
                # cabecera RA: a veces MDFN va tras MEM
                i = raw.find(b'MDFN')
            if i >= 0:
                raw = raw[i:]
            else:
                raw = raw[16:]
        L = self._lib
        L.retro_serialize_size.restype = ctypes.c_size_t
        L.retro_unserialize.restype = ctypes.c_bool
        n = L.retro_serialize_size()
        candidates = [raw]
        if raw[:8] == b'MDFNSVST':
            candidates.append(raw)
        # probar recortes habituales
        for off in (0, 16, 8, 32):
            if off < len(raw):
                candidates.append(raw[off:])
        last = None
        for cand in candidates:
            chunk = cand[:n] if len(cand) >= n else cand + bytes(n - len(cand))
            buf = ctypes.create_string_buffer(chunk)
            if L.retro_unserialize(buf, n):
                return
            last = len(cand)
        raise RuntimeError(f'unserialize failed n={n} last={last}')

    def close(self):
        try:
            self._lib.retro_unload_game()
            self._lib.retro_deinit()
        except Exception:
            pass
