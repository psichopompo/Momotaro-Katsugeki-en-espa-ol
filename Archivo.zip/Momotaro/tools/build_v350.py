#!/usr/bin/env python3
"""
v350 — bloque 1 de 0x3B800 = «¡Gracias!».

Ranura JP 0x3B810..0x3B822 (19 B) + $00 en 0x3B823.
c=$5D (créditos). Pad $20. No $3B. Base v349.
Bloque 0 y 0x3B824 INTOCABLES.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v349.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v350.pce'
IPS = ROOT / 'parches/momotaro_v350.ips'
MD5_BASE = 'a4f80fb9b0cc6d795ca8258d106d9c05'

OFF = 0x3B810
SLOT = 19

ENC = {
    ' ': 0x20, '!': 0x21, '¡': 0xCA,
    'á': 0xBB, 'é': 0xBC, 'í': 0xBD, 'ó': 0xBE, 'ú': 0xBF, 'ñ': 0xC1,
    'b': 0x5B, 'c': 0x5D, 'p': 0x5E,
}
for i, ch in enumerate('abcdefghijklmnopqrstuvwxyz'):
    ENC.setdefault(ch, 0xA1 + i)
for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
    ENC[c] = ord(c)


def main():
    txt = '¡Gracias!'
    raw = bytes(ENC[ch] for ch in txt)
    assert txt[4] == 'c' and raw[4] == 0x5D, raw.hex()
    blob = raw + bytes([0x20] * (SLOT - len(raw)))
    assert len(blob) == SLOT and 0x3B not in blob

    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE
    assert rom[0x3B80F] == 0x00 and rom[0x3B823] == 0x00
    keep0 = bytes(rom[0x3B800:0x3B810])
    nxt = bytes(rom[0x3B823:0x3B823 + 16])

    rom[OFF:OFF + SLOT] = blob

    assert bytes(rom[0x3B800:0x3B810]) == keep0
    assert rom[0x3B80F] == 0x00 and rom[0x3B823] == 0x00
    assert bytes(rom[0x3B823:0x3B823 + 16]) == nxt
    assert bytes(rom[OFF:OFF + len(raw)]) == raw

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    IPS.write_bytes(b'PATCH' + b''.join(rec) + b'EOF')
    print('v350 OK', raw.hex())
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
