#!/usr/bin/env python3
"""
build_v303.py - $00 tras «COMIENZA EL JUEGO» para que D619 no se coma SE ACABÓ.

v302:  ...JUEGO $02 SE ACABÓ $00...
D619 para en $00/$FF. Sin $00 tras JUEGO pinta la S de SE → «JUEGOS».

Se inserta 1 byte $00 en 0x1F9D5 y se desplaza el bloque GO 1 B.
Punteros 0x1F72D +1. 0x1FA00 (lista de sprites) intacto.

Uso: python3 tools/build_v303.py
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Momotaro')
BASE = ROOT / 'roms/momotaro_es_v302.pce'
VIRGEN = ROOT / 'roms/Momotarou Katsugeki (Japan).pce'
SALIDA = ROOT / 'roms/momotaro_es_v303.pce'
IPS = ROOT / 'parches/momotaro_v303.ips'
MD5_BASE = '130d4188e654ed0594f5d063d3724472'


def main():
    rom = bytearray(BASE.read_bytes())
    orig = VIRGEN.read_bytes()
    assert hashlib.md5(rom).hexdigest() == MD5_BASE

    assert rom[0x1F9C4:0x1F9D5] == b'COMIENZA EL JUEGO'
    assert rom[0x1F9D5:0x1F9DF] == bytes.fromhex('0253452041434142c500')
    assert rom[0x1F72D:0x1F735] == bytes.fromhex('d559df59ea59f459')
    assert rom[0x1F9FD:0x1FA00] == b'\xff\xff\xff'
    spr = bytes(rom[0x1FA00:0x1FA10])
    go_tail = bytes(rom[0x1F9D5:0x1F9FD])  # $02SE...Guardar$00 (40 B)
    assert len(go_tail) == 40 and go_tail[-1] == 0x00
    assert rom[0x47CFB] == 0xFF
    titulo = bytes(rom[0x2F8B5:0x2F8C5])
    c5f3 = bytes(rom[0x105F3:0x1060E])

    # $00 en 0x1F9D5; GO se desplaza a 0x1F9D6..0x1F9FD
    rom[0x1F9D6:0x1F9D6 + 40] = go_tail
    rom[0x1F9D5] = 0x00

    # punteros GO +1
    rom[0x1F72D:0x1F735] = bytes.fromhex('d659e059eb59f559')

    # --- releer como D619 ---
    assert rom[0x1F9C4:0x1F9D6] == b'COMIENZA EL JUEGO\x00'
    assert rom[0x1F9D6:0x1F9E0] == bytes.fromhex('0253452041434142c500')
    p0 = rom[0x1F72D] | (rom[0x1F72E] << 8)
    p1 = rom[0x1F72F] | (rom[0x1F730] << 8)
    p2 = rom[0x1F731] | (rom[0x1F732] << 8)
    p3 = rom[0x1F733] | (rom[0x1F734] << 8)
    def cpu_off(p):
        return 0x1E000 + (p - 0x4000)
    assert rom[cpu_off(p0):cpu_off(p0)+10] == bytes.fromhex('0253452041434142c500')
    assert rom[cpu_off(p1)] == 0x01 and rom[cpu_off(p1)+1] == 0x43  # Continuar C
    assert rom[cpu_off(p2)] == 0x01 and rom[cpu_off(p2)+1] == 0x54  # T
    assert rom[cpu_off(p3)] == 0x02 and rom[cpu_off(p3)+1] == 0x47  # G
    # terminadores
    assert rom[cpu_off(p0)+9] == 0x00
    assert rom[0x1F9FE] == 0xFF and rom[0x1F9FF] == 0xFF
    assert bytes(rom[0x1FA00:0x1FA10]) == spr
    assert bytes(rom[0x105F3:0x1060E]) == c5f3
    assert bytes(rom[0x2F8B5:0x2F8C5]) == titulo
    assert rom[0x47CFB] == 0xFF

    d = bytes(rom)
    SALIDA.write_bytes(d)
    difv = [i for i in range(len(d)) if d[i] != orig[i]]
    rec, i = [], 0
    while i < len(difv):
        a = difv[i]
        j = i
        while j + 1 < len(difv) and difv[j + 1] <= difv[j] + 8:
            j += 1
        b = difv[j] + 1
        rec.append(bytes([a >> 16 & 0xFF, a >> 8 & 0xFF, a & 0xFF,
                          (b - a) >> 8, (b - a) & 0xFF]) + d[a:b])
        i = j + 1
    parche = b'PATCH' + b''.join(rec) + b'EOF'
    IPS.parent.mkdir(exist_ok=True)
    IPS.write_bytes(parche)
    prueba = bytearray(orig)
    p = 5
    while parche[p:p + 3] != b'EOF':
        o2 = parche[p] << 16 | parche[p + 1] << 8 | parche[p + 2]
        n2 = parche[p + 3] << 8 | parche[p + 4]
        prueba[o2:o2 + n2] = parche[p + 5:p + 5 + n2]
        p += 5 + n2
    assert bytes(prueba) == d
    print('v303 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('SHA-1 ', hashlib.sha1(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
