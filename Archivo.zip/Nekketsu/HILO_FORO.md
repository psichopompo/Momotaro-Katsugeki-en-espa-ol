# Nekketsu Koukou Dodgeball-bu — Soccer Hen MD · Traducción al castellano

**Mega Drive · Technos Japan · 1992 · Exclusivo de Japón**

---

## Antes de nada: cómo se ha hecho esto

Empiezo por donde toca, que es la honestidad.

**Yo no soy romhacker.** No tengo conocimientos de ingeniería inversa, ni
sé leer ensamblador del 68000, ni sabría por dónde empezar a desmontar un
cartucho de Mega Drive. Todo el trabajo técnico de este proyecto —el
análisis del formato de compresión, el desensamblado, la localización de
punteros, los parches de código, la reubicación de assets— lo ha hecho una
IA con la que he trabajado codo con codo.

Mi aportación ha sido **dirigir el proyecto**: decidir qué se traducía y
cómo, probar cada versión, detectar los fallos, y aportar intuición cuando
el análisis se atascaba. Alguna de esas intuiciones resultó decisiva —por
ejemplo, la idea de tratar los nombres de equipo como texto en lugar de
como gráficos, que redujo el coste de 146 tiles a 35 y desbloqueó un
callejón sin salida—. También he hecho el pixel art: fuentes, rediseño de
sprites y el rótulo del título.

Pero que quede claro el reparto: **la intuición es mía, el trabajo brutal
de código es suyo.**

Y ahora el dato que me parece más relevante de todo esto: **el proyecto
completo ha llevado entre dos y tres días de trabajo intenso.** Un juego
sin traducción a ningún idioma occidental en más de treinta años,
completamente en japonés, con texto comprimido y gráficos que había que
redibujar. Un romhacker en solitario habría tardado **meses, o más**, y
eso teniendo ya la experiencia. No lo digo para restarle mérito a nadie:
lo digo porque creo que evidencia lo que la IA permite hacer hoy en el
romhacking, y me parece una noticia en sí misma.

No descarto que haya errores: **no hemos podido probar el juego entero.**
Si os encontráis alguno, reportadlo y lo abordaremos.

---

## El juego

En 1992 Technos publicó para Mega Drive un juego de fútbol protagonizado
por Kunio-kun, el gamberro del instituto Nekketsu que muchos conocimos
como "el de *Renegade*" o, si tuvimos suerte, como el de *River City
Ransom*. El título completo es un trabalenguas —*Nekketsu Koukou
Dodgeball-bu: Soccer Hen MD*— y viene a significar algo así como "Club de
balón prisionero del instituto Nekketsu: edición fútbol".

De fútbol tiene lo justo. Hay once contra once y una pelota, pero también
placajes, patadas voladoras, bombas y campos con minas. Es el fútbol de
patio de colegio elevado a género, con la estética cabezona de la saga
Kunio y una dificultad que no perdona.

**Nunca salió de Japón.** Ni versión americana, ni europea, ni una mísera
traducción al inglés en más de treinta años. Para cualquiera que no lea
japonés, el juego era jugable a medias: te enterabas de que había que
meter goles, pero la historia, los menús, los nombres de los equipos y las
instrucciones eran un muro.

Eso es lo que ha motivado este proyecto. No hay versión en inglés que
sirva de base: hay que ir directo al japonés y reconstruirlo todo.

---

## Qué se ha traducido

Absolutamente todo el texto visible:

- **Los 86 bloques de diálogo** de la historia
- **Menús, opciones y pantalla de clave**
- **Los trece nombres de equipo** en la selección de DUELO 2J
- **La pantalla de alineación** (`¿CAMBIAR POSICIÓN?`, `RES` / `VEL` / `TIR`)
- **El marcador de resultados** con los nombres de ambos equipos
- **Los rótulos de escena**: sala del club, vestuarios, títulos de partido
- **Los créditos**

Y se han redibujado los gráficos que contenían texto japonés: el rótulo
del título, la placa de selección de escuela, la cinta verde del club y
una fuente gruesa nueva para los nombres de equipo.

---

## Cómo se ha hecho

El proyecto se ha llevado con un método estricto de ingeniería inversa:
nada de escribir bytes a ciegas ni de probar offsets al azar. Cada cambio
se ha demostrado antes con trazas de ejecución, volcados de VRAM, puntos
de ruptura y comparaciones frame a frame contra la ROM japonesa original.

Todo el proceso está documentado en un diario de investigación de más de
**8.700 líneas**, en el que las hipótesis descartadas **no se borran**: se
anotan con el motivo por el que resultaron falsas. Se han escrito unas
**60 herramientas** en Python para el análisis: descompresor y recompresor
del formato propietario del juego, desensamblador 68000, editor de fuentes,
generador de parches y un arnés de emulación instrumentado sobre Genesis
Plus GX.

---

## Los problemas interesantes

No todo fue traducir cadenas. Algunos obstáculos merecen mención porque
son el tipo de cosa con la que uno se encuentra al abrir un cartucho de
1992.

### El espacio no existe

La ROM original son 512 KB apretados. El texto japonés ocupa poco —cada
kanji es un carácter— y el castellano necesita muchas más letras. Además,
los nombres de equipo estaban dibujados como **gráficos**, no como texto.

Mi primer intento renderizaba cada nombre como un mapa de bits continuo y
lo troceaba después en celdas de 8×8 píxeles. Resultado: **146 tiles
únicos** para trece nombres, porque la misma letra caía en posiciones
distintas de la rejilla y generaba tiles diferentes cada vez. No cabía por
390 bytes.

La solución llegó de una observación mía, ya como director del proyecto:
*tratarlos como texto, no como gráficos*. Alineando cada letra a
una celda, una `S` produce siempre los mismos tiles. El coste pasó a
depender solo del alfabeto, y como los trece nombres solo usan **20
letras** (sobran `J L Q V W X`, más la Ñ y los acentos), bajó de 146 tiles
a **35**. Con el contorno negro incluido y 1.466 bytes de margen.

### Assets que se pisan

Al ampliar el rótulo del título, éste creció 37 bytes y machacó el
principio del gráfico de la sala del club, que una versión anterior había
colocado justo detrás. La escena salía completamente corrupta.

Detectarlo requirió bisecar entre versiones —comprobando la misma pantalla
en la ROM japonesa, en la v1.6, v1.7, v1.8 y v1.9— hasta aislar en qué
punto se rompió. Fue la sexta vez en el proyecto que un asset pisaba a
otro, y quedó como norma: **al agrandar algo, comprobar siempre qué hay
inmediatamente detrás**.

### Un byte que colgaba el juego

Para evitar que la cinta verde del rótulo se redibujara en cada fotograma
(lo que producía un parpadeo del borde inferior), añadí un pequeño
envoltorio en ensamblador con un salto condicional. Calculé mal el
desplazamiento por 4 bytes: el salto caía **en mitad de una instrucción**,
la CPU leía basura y el juego se colgaba con una nota de sonido fija.

El 68000 no avisa de estas cosas. Norma nueva: **desensamblar siempre
cualquier salto relativo escrito a mano antes de meterlo en la ROM**.

### El destello fantasma

El más esquivo. En la pantalla de resultados aparecían durante unos
instantes caracteres japoneses sueltos, números romanos y símbolos, justo
antes de que se dibujaran los nombres correctos.

Costó cinco intentos fallidos. El diagnóstico correcto lo aporté yo,
por intuición tras haber visto el mismo patrón antes: *«aparecen cuando
sustituimos un gráfico donde ya había otro»*. Y así era: el código original de la pantalla de resultados
**reutiliza la tabla de descriptores de la pantalla de selección** para
pintar los dos nombres. Esos tilemaps apuntan a una base de tiles que en
esa escena contiene otra cosa, así que durante siete fotogramas se veía
basura hasta que el código nuevo repintaba encima.

Se resolvió anulando ese bloque original, que era redundante.

### La lección más incómoda

A mitad del proyecto descubrí que **mis puntos de ruptura no funcionaban**:
faltaba activar una opción del emulador instrumentado. Una prueba de
control con dos rutinas que se ejecutan con toda seguridad devolvía cero
aciertos en ambas.

Eso significaba que varias conclusiones previas, todas basadas en "cero
aciertos, luego esto no se ejecuta", eran **falsos negativos**. Quedó
apuntado en el diario como norma: *un contador a cero no prueba nada si
antes no has validado que el contador puede subir*.

---

## Capturas

*(adjuntar las imágenes de la carpeta `capturas/`)*

- `01_titulo.png` — Pantalla de título
- `02_seleccion.png` — Selección de escuela en DUELO 2J
- `03_alineacion.png` — Cambio de posición de los jugadores
- `04_presentacion.png` — Presentación de partido
- `04b_presentacion_2p.png` — Presentación del segundo partido
- `04c_partido_final.png` — Presentación del partido final
- `05_misako_corazones.png` — Misako y los corazones (sala del club)
- `06_resultado.png` — Marcador de resultados
- `07_misako_derrota.png` — La reprimenda de Misako tras perder
- `08_campo.png` — Campo de juego
- `09_sala_club.png` — Sala del club
- `10_intro.png` — Escena de introducción
- `11_pizarra_tacticas.png` — Pizarra de tácticas

---

## Descarga y uso

**Parche v2.18** en formatos BPS e IPS.

Se aplica sobre la ROM japonesa original sin cabecera:

| | |
|---|---|
| Tamaño | 524.288 bytes (512 KB) |
| CRC32 | `f49c3a86` |
| MD5 | `ff7a9a6fb74a640f40f10dff53e9cf4d` |
| SHA-1 | `d865b01e58a269400de369fc1fbb3b3e84e1add0` |

ROM resultante:

| | |
|---|---|
| Tamaño | 1.048.576 bytes (1 MB) |
| CRC32 | `90cf46ee` |
| MD5 | `06bff882ae6cf16dc96c9b382e1229cf` |
| SHA-1 | `6d2346ed8e9b635207391ed7443a8c4b4f860222` |

Usa **Flips**, **Lunar IPS** o cualquier parcheador compatible. Se
recomienda el BPS, que verifica que la ROM base sea la correcta.

**No se distribuye la ROM.** Solo el parche.

---

## Estado y limitaciones

La traducción está completa y es jugable de principio a fin. Detalles
conocidos:

- En la pantalla de alineación, la flecha del cursor SÍ/NO aparece un
  instante antes que la pregunta. Cosmético.
- Las zonas de difícil acceso (torneo completo hasta el final, modo VS,
  claves) han recibido menos pruebas. Se agradece cualquier informe.

Probado en Genesis Plus GX. No se ha probado en hardware real; si alguien
lo hace con un flashcart, el informe sería bienvenido.

---

## Aviso legal

Trabajo de aficionados sin ánimo de lucro. *Nekketsu Koukou Dodgeball-bu -
Soccer Hen MD* es propiedad de sus respectivos titulares. Esta traducción
no está autorizada ni respaldada por Technos Japan ni por sus sucesores.
Se distribuye únicamente el parche.
