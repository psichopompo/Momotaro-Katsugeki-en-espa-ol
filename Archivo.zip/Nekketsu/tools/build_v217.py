#!/usr/bin/env python3
"""
v2.17 — no pintar presentación de partido en la intro.

v2.16: ($f806 & $0F)==0 también coincide con la intro del juego
($30/$40…). Vestuario OK (nibble 4/8/C).

Añade $f800==$0C (estado de presentación de encuentro, medido).
Intro/título son $f800=0 u $08.
Base v2.16. Sigue el borrado de 4 filas.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Nekketsu')
BASE = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_16.md'
SALIDA = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_17.md'
MD5_16 = '35c4efb3ed31699f5042e3fbc4d82154'

# cmpi.w #$C,$f800 / bne.s $16 / move.w $f806,d0 / andi #$F / bne.s $0C
# jsr $C4100 / jsr $C4180 / jmp $49E8
HOOK = bytes.fromhex(
    '0c78000cf800'
    '6616'
    '3038f806'
    '0240000f'
    '660c'
    '4eb9000c4100'
    '4eb9000c4180'
    '4ef9000049e8'
)


def main():
    rom = bytearray(BASE.read_bytes())
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_16
    assert rom[0xC41A9] == 4
    assert all(b == 0xFF for b in rom[0xC431C:0xC4324])
    rom[0xC4300:0xC4300 + len(HOOK)] = HOOK
    assert rom[0xC4300:0xC4300 + len(HOOK)] == HOOK
    d = bytes(rom)
    SALIDA.write_bytes(d)
    print('v2.17 OK', len(HOOK))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
