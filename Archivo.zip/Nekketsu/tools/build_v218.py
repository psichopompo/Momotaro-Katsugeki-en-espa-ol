#!/usr/bin/env python3
"""
v2.18 — intro sin tiles de partido; sin parpadeo del rótulo.

1) Hook $C4300: pintar si f806==$20 (1.er partido) O (f852!=0 y
   f806&$F==0) (siguientes). Intro: f852=0 y f806!=$20 → no pinta.
   Vestuario: nibble 4/8/C → no pinta.

2) $8A300: jsr $C4180 cada frame → RTS. Era el parpadeo (medido:
   599 llamadas/presentación, VRAM idéntica sin el jsr).

3) Sigue el borrado de 4 filas (2.14).
Base v2.17.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Nekketsu')
BASE = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_17.md'
SALIDA = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_18.md'
MD5_17 = '1b3afb6270a2f5ee56e71f8e68950e92'

# cmpi.w #$20,$f806 / beq.s do
# tst.w $f852 / beq.s skip
# move.w $f806,d0 / andi #$F / bne.s skip
# do: jsr $C4100 / jsr $C4180
# skip: jmp $49E8
HOOK = bytes.fromhex(
    '0c780020f806'  # 6  cmpi.w #$20,$f806
    '670e'          # 2  beq.s do   (+14 → jsr)
    '4a78f852'      # 4  tst.w $f852
    '670c'          # 2  beq.s skip (+12 → jmp)  wait recalc
    '3038f806'      # 4
    '0240000f'      # 4
    '6606'          # 2  bne skip jsrs only? 
    '4eb9000c4100'  # 6
    '4eb9000c4180'  # 6
    '4ef9000049e8'  # 6
)


def main():
    # Recalc branches properly in comments vs bytes:
    # Layout:
    # C4300: cmpi.w #$20,$f806     6
    # C4306: beq.s do              2   do = first jsr
    # C4308: tst.w $f852           4
    # C430C: beq.s skip            2
    # C430E: move.w $f806,d0       4
    # C4312: andi.w #$F,d0         4
    # C4316: bne.s skip            2
    # C4318: jsr $C4100            6   <-- do
    # C431E: jsr $C4180            6
    # C4324: jmp $49E8             6   <-- skip
    hook = bytes.fromhex(
        '0c780020f806'
        '6710'          # beq do: from C4308 to C4318 = 16 = $10
        '4a78f852'
        '6716'          # beq skip: from C430E to C4324 = 22 = $16
        '3038f806'
        '0240000f'
        '660c'          # bne skip: from C4318 to C4324 = 12 = $0C
        '4eb9000c4100'
        '4eb9000c4180'
        '4ef9000049e8'
    )
    assert len(hook) == 42

    rom = bytearray(BASE.read_bytes())
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_17
    assert rom[0x8A300:0x8A306] == bytes.fromhex('4eb9000c4180')
    assert all(b == 0xFF for b in rom[0xC4324:0xC432A])
    rom[0xC4300:0xC4300 + len(hook)] = hook
    rom[0x8A300:0x8A302] = bytes.fromhex('4e75')
    assert rom[0x8A300:0x8A302] == bytes.fromhex('4e75')
    assert rom[0xC41A9] == 4
    d = bytes(rom)
    SALIDA.write_bytes(d)
    print('v2.18 OK hook', len(hook))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
