#!/usr/bin/env python3
"""
v2.16 — presentación de TODOS los partidos + no pisar vestuario.

v2.15 restauró `cmpi.w #$20,$f806 / bne` (2.8): vestuario OK, pero
C4100 (tiles del partido, índice $f852) sólo corre si $f806==$20
(1.er partido). En el 2.º+ quedan PALSOFT / katakana / SALA DEL CLUB.

v2.14 NOP-eó el bne: carga todos los partidos y pinta rótulos en vestuario.

Solución: C4100+C4180 si ($f806 & $0F)==0  → $20,$30,$40… (presentación
de cada encuentro). $24/$28/$2c (vestuario/descanso/derrota) se saltan.

Y se deja el borrado de 4 filas (2.14) para el kanji de la 5.ª.
Base v2.15.
"""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Nekketsu')
BASE = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_15.md'
SALIDA = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_16.md'
MD5_15 = '0e10e2b8e901c5fdae42d8d1c5f2c529'

# move.w $f806,d0 / andi.w #$F,d0 / bne.s +$0C / jsr $C4100 / jsr $C4180 / jmp $49E8
HOOK = bytes.fromhex(
    '3038f806'
    '0240000f'
    '660c'
    '4eb9000c4100'
    '4eb9000c4180'
    '4ef9000049e8'
)


def main():
    rom = bytearray(BASE.read_bytes())
    assert hashlib.md5(bytes(rom)).hexdigest() == MD5_15
    old = rom[0xC4300:0xC4300 + 26]
    assert old[:6] == bytes.fromhex('0c780020f806')
    assert old[6:8] == bytes.fromhex('660c')
    assert rom[0xC431A:0xC431E] == b'\xff\xff\xff\xff'
    assert rom[0xC41A9] == 3

    rom[0xC4300:0xC4300 + len(HOOK)] = HOOK
    rom[0xC41A9] = 4
    assert rom[0xC4300:0xC4300 + len(HOOK)] == HOOK
    assert rom[0xC41A9] == 4

    d = bytes(rom)
    SALIDA.write_bytes(d)
    print('v2.16 OK hook', len(HOOK))
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))


if __name__ == '__main__':
    main()
