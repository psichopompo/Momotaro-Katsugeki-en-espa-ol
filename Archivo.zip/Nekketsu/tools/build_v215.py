#!/usr/bin/env python3
"""v2.15 — bne f806==$20 restaurado (como v2.8)."""
import hashlib
import zlib
from pathlib import Path

ROOT = Path('/home/user/Nekketsu')
BASE = ROOT / 'in/Nekketsu Soccer MD (ES) v2.14.md'
REF28 = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_8.md'
SALIDA = ROOT / 'rom/Nekketsu_Soccer_MD_ES_v2_15.md'


def main():
    rom = bytearray(BASE.read_bytes())
    v28 = REF28.read_bytes()
    assert hashlib.md5(bytes(rom)).hexdigest() == '74c94caf1beb3395a4966130bc81da04'
    assert rom[0xC4306:0xC4308] == b'\x4e\x71'
    assert v28[0xC4306:0xC4308] == b'\x66\x0c'
    rom[0xC4306:0xC4308] = b'\x66\x0c'
    assert rom[0xC41A9] == 4 and v28[0xC41A9] == 3
    rom[0xC41A9] = 3
    assert rom[0xC4306:0xC4308] == v28[0xC4306:0xC4308]
    assert rom[0xC41A9] == v28[0xC41A9]
    base = BASE.read_bytes()
    assert sum(rom[i] != base[i] for i in range(len(rom))) == 3
    d = bytes(rom)
    SALIDA.parent.mkdir(exist_ok=True)
    SALIDA.write_bytes(d)
    print('v2.15 OK')
    print('MD5   ', hashlib.md5(d).hexdigest())
    print('CRC32 %08X' % (zlib.crc32(d) & 0xFFFFFFFF))
    print(SALIDA)


if __name__ == '__main__':
    main()
