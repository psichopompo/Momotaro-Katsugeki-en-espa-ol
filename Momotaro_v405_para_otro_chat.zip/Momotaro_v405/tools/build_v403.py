#!/usr/bin/env python3
"""build_v403.py — tanda de textos del testeo completo de David (2026-08-30).

Nueve arreglos de texto, todos IN-PLACE (sin repuntar, sin mover nada):

1. T-SOLO  «solo perderás la vida» -> «sólo ...»      (1 byte, tilde)
   Confirmado adverbio: el japonés es `イタズラニ イノチヲ ステルダケダ`
   (itazura ni inochi wo suteru DAKE da) — «dake» = «sólo/solamente».
2. T-QUIZ  «Con el gorro, / ¿qué más puso?» -> «Además del gorro / ¿qué les puso?»
   Original JP: «オジイサンガ カサジゾウニ カブセタノハ カサト ナンダ?»
   (¿Qué le puso el abuelo a los Kasa-Jizo además del sombrero?).
3. T-ERMI  «¡Yo soy el      ermitaño <NOMBRE>!» -> «¡Soy el ermitaño / <NOMBRE>!»
   David: «cambiar la primera línea a "¡Soy el ermitaño" (16) y en la segunda
   sólo el nombre con el signo de cierre». La caja es de 16 columnas.
4. T-OGRO  «...fuera. Dicen que...» -> «...fuera, dicen que...»  (2 bytes)
   Convierte el fragmento «Ese ogro que duerme ahí fuera.» en el tópico de
   «dicen que se hizo enorme». (El «De ese ogro» completo pide +3 bytes y
   repunte: ver PENDIENTES/nota.)
5. T-ARTE  «Parapunte» -> «Paropunte» en la tabla de artes (2×, el katakana es
   ﾊﾟﾛﾌﾟﾝﾃ = pa-ro-pu-n-te) Y el «Ç»: la `p` estaba como byte directo $B0, que
   el motor del premio pinta como Ç (mismo bug que la v391 «JanÇu»).
6. T-ARTE  «Toma: ¡<arte>!» -> «Toma: <arte>.»  (el premio del quiz, $D5F6)
   David: «pongamos "Toma: Paropunte.". Excepcionalmente no usaremos signos de
   exclamación en esa obtención». Quito el «¡» (trozo 1) y el «!» pasa a «.».
7. T-POSADA  la «Ç flotante» de la posada de 1000 ryos = un dakuten $DE huérfano
   La posada 1000 es la entrada t7 de la tabla de tiendas (slot[0] = 0x4880D).
   El japonés era «…イッパク1000$デトマレマス!» (de tomaremasu = «se puede
   hospedar»). Al traducir «Posada: 1000.» quedaron SIN borrar el dakuten «$DE»
   de «デ» y el resto «トマレマス!» (c4 cf da cf bd 21), que en nuestro charset
   se lee «Í…ç…í!». El $DE se pinta como glifo suelto ENCIMA de la línea (es el
   dakuten: norma 383), y por eso David ve la «Ç flotante». Se borran los dos
   restos. Igual en la posada 100 (t8): «Í…ç…í!» sobrante.
8. T-DADOS  «¡Qué lástima! / ¡Hasta la vist» -> «¡Hasta la vista!» entero
   David: al perder en los dados la chica dice «¡Qué lástima! / ¡Hasta la
   vist» (falta «a!») y la línea va varias celdas a la derecha. Causa: entre
   «¡Qué lástima!» (13) y «¡Hasta la vista!» (16) hay 5 espacios en vez de 3;
   los 2 de sobra empujan «¡Hasta la vista!» a la celda 2 de la línea 2 y el
   «a!» se sale (la caja son 16×2). Se quitan los 2 espacios.
"""
import hashlib
import sys
sys.path.insert(0, 'tools')
from charset_oficial import encode

BASE = "roms/momotaro_es_v402.pce"
SAL = "roms/momotaro_es_v403.pce"
MD5_BASE = "38d00547cc4c64f911df8f1ed3cfcfb4"


def main():
    d = bytearray(open(BASE, "rb").read())
    assert hashlib.md5(d).hexdigest() == MD5_BASE, "la base no es la v402"
    orig = bytes(d)

    # ---- 1. T-SOLO: «solo» -> «sólo» (adverbio) ---------------------
    #    «...adelante\nsolo perderás la\nvida...»
    #    «solo» = 's' 'o' + $86('lo ')  ->  «sólo» = 's' 'ó' + $86
    assert d[0x4BD8F:0x4BD92] == bytes([0xB3, 0xAF, 0x86]), \
        "el «solo» no está donde se espera: %s" % d[0x4BD8F:0x4BD92].hex(' ')
    d[0x4BD90] = 0xBE            # 'o' -> 'ó'  (queda «sólo » = 's'+'ó'+$86)

    # ---- 2. T-QUIZ: Q6 del gorro ------------------------------------
    #    bloque en 0x4B2CC: L1(16) + $80 + L2(16)
    assert d[0x4B2CC:0x4B2DC] == (encode("Con el gorro,") +
                                  bytes([0xA0] * 3)), "Q6 L1 no coincide"
    assert d[0x4B2DC] == 0x80, "separador Q6"
    assert d[0x4B2DD:0x4B2ED] == (encode("¿qué más puso?").replace(b"\x5e", b"\xb0") +
                                  bytes([0xA0] * 2)), "Q6 L2 no coincide"
    # nueva L1 «Además del gorro» (16, sin relleno) y L2 «¿qué les puso?» (14)
    l1 = encode("Además del gorro")
    l2 = encode("¿qué les puso?").replace(b"\x5e", b"\xb0")  # 'p' directo $B0
    assert len(l1) == 16 and len(l2) == 14, (len(l1), len(l2))
    d[0x4B2CC:0x4B2DC] = l1
    d[0x4B2DC] = 0x80
    d[0x4B2DD:0x4B2ED] = l2 + bytes([0xA0] * 2)

    # ---- 3. T-ERMI: la primera línea del intro -----------------------
    #    prefijo en 0x4B85D: «¡Yo soy el» + 6 esp + «ermitaño » + $00
    assert d[0x4B85D:0x4B877] == (encode("¡Yo soy el") + bytes([0xA0] * 6) +
                                  encode("ermitaño ") + bytes([0x00])), \
        "prefijo del ermitaño no coincide: %s" % d[0x4B85D:0x4B877].hex(' ')
    nuevo = encode("¡Soy el ermitaño")       # 16 justos
    assert len(nuevo) == 16
    d[0x4B85D:0x4B86D] = nuevo
    d[0x4B86D] = 0x00                         # marcador del nombre, un byte antes
    d[0x4B86E:0x4B877] = bytes([0xA0] * 9)    # limpiar el viejo «ermitaño » + $00
    # el sufijo «!» sigue en 0x4AE32, intacto

    # ---- 4. T-OGRO: «fuera. Dicen» -> «fuera, dicen» -----------------
    #    '. Dicen' = CB 20 44 ... -> ', dicen' = CC 20 A4 ...
    assert d[0x4A204:0x4A20A] == bytes([0xCB, 0x20, 0x44, 0xA9, 0xA3, 0x66]), \
        "el «. Dicen» no está: %s" % d[0x4A204:0x4A20A].hex(' ')
    d[0x4A204] = 0xCC                         # '.' -> ','
    d[0x4A206] = 0xA4                         # 'D' -> 'd'

    # ---- 5. T-ARTE: «Parapunte» -> «Paropunte» + Ç (tabla de artes) ---
    #    tabla $D8CA en 0x4AE84; entradas 6 y 13 = «Parapunte»
    #    bytes: P a r a p u n t e = 50 A1 B2 A1 B0 B5 AE B4 A5
    for off in (0x4AEAA, 0x4AEDB):            # la 'a' -> 'o'
        assert d[off] == 0xA1, "no está la 'a' de Parapunte en 0x%X" % off
        d[off] = 0xAF
    for off in (0x4AEAB, 0x4AEDC):            # la 'p' directa $B0 -> alias $5E
        assert d[off] == 0xB0, "no está la 'p' $B0 en 0x%X" % off
        d[off] = 0x5E

    # ---- 6. T-ARTE: «Toma: ¡<arte>!» -> «Toma: <arte>.» --------------
    #    trozo 1 (repointado en 0x4B80E): «¡Bien hecho!» + «Toma: ¡» + $00
    assert d[0x4B81E:0x4B825] == bytes([0x54, 0xAF, 0xAD, 0xA1, 0xCD, 0x20, 0xCA]), \
        "el «Toma: ¡» no está: %s" % d[0x4B81E:0x4B825].hex(' ')
    assert d[0x4B825] == 0x00, "falta el $00 tras «Toma: ¡»"
    d[0x4B824] = 0x00                         # el «¡» -> terminator (queda «Toma: »)
    d[0x4B825] = 0xA0                         # el $00 huérfano -> relleno
    #    trozo 3 (cierre en 0x4ADF5): «!» -> «.»
    assert d[0x4ADF5] == 0x21, "el «!» de cierre no está en 0x4ADF5"
    d[0x4ADF5] = 0xCB                         # '!' -> '.'

    # ---- 7. T-POSADA: borrar el dakuten $DE y el «トマレマス!» ---------
    #    posada 1000 (t7): «...Posada: 1000.» + 3 esp + $DE + «Í…ç…í!»
    assert d[0x4882D] == 0xDE, "el dakuten $DE no está en 0x4882D"
    assert d[0x4882E:0x48834] == bytes([0xC4, 0xCF, 0xDA, 0xCF, 0xBD, 0x21]), \
        "el «トマレマス!» no está: %s" % d[0x4882E:0x48834].hex(' ')
    d[0x4882D] = 0xA0
    d[0x4882E:0x48834] = bytes([0xA0] * 6)
    #    posada 100 (t8): «...Posada: 100.» + 4 esp + «Í…ç…í!» + « ¡Ganas…»
    assert d[0x48C77:0x48C7D] == bytes([0xC4, 0xCF, 0xDA, 0xCF, 0xBD, 0x21]), \
        "el «トマレマス!» (t8) no está: %s" % d[0x48C77:0x48C7D].hex(' ')
    d[0x48C77:0x48C7D] = bytes([0xA0] * 6)

    # ---- 8. T-DADOS: «¡Hasta la vista!» cortado por sobra de espacios ----
    #    mensaje B (pérdida): «¡Qué lástima!» + 5 esp + «¡Hasta la vista!»
    assert d[0x4AD10:0x4AD1D] == encode("¡Qué lástima!"), \
        "«¡Qué lástima!» no está: %s" % d[0x4AD10:0x4AD1D].hex(' ')
    assert d[0x4AD1D:0x4AD22] == bytes([0xA0] * 5), "no hay 5 espacios"
    assert d[0x4AD22:0x4AD32] == encode("¡Hasta la vista!"), \
        "«¡Hasta la vista!» no está: %s" % d[0x4AD22:0x4AD32].hex(' ')
    d[0x4AD1D:0x4AD34] = (bytes([0xA0] * 3) + encode("¡Hasta la vista!") +
                          bytes([0xA0] * 4))
    #    el mensaje hermano «¡Qué rácano! / ¡Largo de aquí!» NO se toca:
    #    «¡Qué rácano!» son 12 caracteres (no 13), así que sus 4 espacios
    #    rellenan la línea 1 (12+4=16) y «¡Largo de aquí!» ya arranca
    #    alineado a la izquierda en la línea 2. Estaba bien.

    # ---- 9. T-DESPEDIDA: restos japoneses de la despedida de tienda ----
    #    Cinco despedidas encadenadas (tabla 0x10854, punteros t0..t4):
    #    t0 0x48B9E  t1 0x48BC0  t2 0x48BE6  t3 0x48C0B  t4 0x48C31.
    #    El japonés «…ゴザイマスカ / …ヨウデスカ? / デスジャ!» quedó a medias:
    #    la traducción «¡Muchas gracias! / ¿Algo más?» es más corta y dejó la
    #    COLA del kana en el hueco de relleno del final de cada buffer (caen
    #    fuera de la caja 16×2, recortados, pero son basura). Se limpian a $A0.
    #    t1: «…¿Algo más?» + 6 esp + «ザイマスカ» (bb de b2 cf bd b6)
    assert d[0x48BE0:0x48BE6] == bytes([0xBB, 0xDE, 0xB2, 0xCF, 0xBD, 0xB6]), \
        "la cola «ザイマスカ» (t1) no está: %s" % d[0x48BE0:0x48BE6].hex(' ')
    d[0x48BE0:0x48BE6] = bytes([0xA0] * 6)
    #    t2: «…¿Algo más?» + 6 esp + «イマスカ» (de b2 cf bd b6)
    assert d[0x48C06:0x48C0B] == bytes([0xDE, 0xB2, 0xCF, 0xBD, 0xB6]), \
        "la cola «イマスカ» (t2) no está: %s" % d[0x48C06:0x48C0B].hex(' ')
    d[0x48C06:0x48C0B] = bytes([0xA0] * 5)
    #    t3: «…¿Algo más?» + 6 esp + «ウデスカ?» (b3 c3 de bd b6 3f)
    assert d[0x48C2B:0x48C31] == bytes([0xB3, 0xC3, 0xDE, 0xBD, 0xB6, 0x3F]), \
        "la cola «ウデスカ?» (t3) no está: %s" % d[0x48C2B:0x48C31].hex(' ')
    d[0x48C2B:0x48C31] = bytes([0xA0] * 6)
    #    t4: «…¿Algo más?» + 6 esp + «ャ!» (ac 21)
    assert d[0x48C51:0x48C53] == bytes([0xAC, 0x21]), \
        "la cola «ャ!» (t4) no está: %s" % d[0x48C51:0x48C53].hex(' ')
    d[0x48C51:0x48C53] = bytes([0xA0] * 2)

    # ---- comprobaciones -------------------------------------------
    # nada fuera de las zonas
    zonas = [(0x4BD8F, 0x4BD93), (0x4B2CC, 0x4B2EB), (0x4B85D, 0x4B877),
             (0x4A204, 0x4A20A), (0x4AEAA, 0x4AEAC), (0x4AEDB, 0x4AEDD),
             (0x4B824, 0x4B826), (0x4ADF5, 0x4ADF6),
             (0x4882D, 0x48834), (0x48C77, 0x48C7D),
             (0x4AD1D, 0x4AD34),
             (0x48BE0, 0x48BE6), (0x48C06, 0x48C0B),
             (0x48C2B, 0x48C31), (0x48C51, 0x48C53)]
    for i in range(len(d)):
        if d[i] != orig[i]:
            assert any(a <= i < b for a, b in zonas), \
                "byte fuera de zona en 0x%X" % i
    # sin romper el diccionario ni el quiz vecino
    assert d[:0x48000] == orig[:0x48000], "se ha tocado código/bancos bajos"

    open(SAL, "wb").write(d)
    print("%s" % SAL)
    print("  MD5    ", hashlib.md5(d).hexdigest())
    print("  SHA-1  ", hashlib.sha1(bytes(d)).hexdigest())
    import zlib
    print("  CRC32  ", "%08X" % (zlib.crc32(d) & 0xffffffff))


main()
