#!/usr/bin/env python3
"""build_v405.py — arregla los 3 vítores con franjas (Tachán 4-1, Japón cha-chá
5-1, Colorín 6-3) sin tocar al abuelo.

CORRECCIÓN sobre la v404 (retirada) — ver entradas 293-295 del log
--------------------------------------------------------------------
La v404 puso el ADC de $C9EE en #$34 para los bloques $368F<>2 y David la
retiró: «los textos 4 px más abajo de lo que deberían, y una línea de otra
parte asomaba por arriba».

La Y final del texto = $3663 (base, = $16 + ADC) + $10 (cueva $FFC3).

    cueva nueva:  $368F=2  -> $10=6      $368F<>2 -> $10=8   (no cambió vs antigua)
    v393 (original, ADC #$30):  $368F=2 -> $16+0x34 (N5 lo bajó)   $368F<>2 -> $16+0x38 (YA CORRECTO)
    v396 (N5, ADC #$34):        $368F=2 -> $16+0x38 (bien)         $368F<>2 -> $16+0x3C (4 px BAJO, roto por N5)
    v402 (ADC #$32):            $368F=2 -> $16+0x38 (bien)         $368F<>2 -> $16+0x3A (2 px bajo)

El N5 de la v396 debía arreglar SOLO el jefe 1 ($368F=2), pero al cambiar el
ADC globalmente rompió los $368F<>2 (que en la v393 estaban bien). El valor
correcto para $368F<>2 es el ORIGINAL #$30, no #$34 (lo que metí en la v404).

Medido: v393 Tachán línea 1 centrada en fila 135; v402 en 137 (2 px bajo);
v404 en 139 (4 px bajo, = lo que reportó David).

EL FIX (v405)
-------------
ADC condicional en $C9EE según $368F:

    $368F=2   ->  ADC #$32  (igual que la v402: compensa el $10=6 de la cueva)
    $368F<>2  ->  ADC #$30  (el original: con $10=8 da la Y correcta)

JSR desde $C9EE a un stub en espacio libre del banco 0x0B (MPR6).

    ROM 0x169EE  A5 16 18 69 32  ->  20 86 DE EA EA   (JSR $DE86 + 2 NOP)
    stub ROM 0x17E86 (lógico $DE86):
        LDA $368F / CMP #$02 / BNE +6
        LDA $16 / CLC / ADC #$32 / RTS      ($368F=2)
        LDA $16 / CLC / ADC #$30 / RTS      ($368F<>2)

Base: la v403 (los 9 parches de texto). Número nuevo v405.
"""
import hashlib
import sys
import zlib

BASE = "roms/momotaro_es_v403.pce"
SAL = "roms/momotaro_es_v405.pce"
MD5_BASE = "ace5f30b84388469b762fca3da8aff38"

OFF_JSR = 0x169EE            # A5 16 18 69 32  ->  JSR $DE86
OFF_STUB = 0x17E86           # espacio libre (0xFF) en banco 0x0B
STUB_ADDR = 0xDE86           # lógico: MPR6=0x0B -> $C000 + (0x17E86-0x16000)

STUB = bytes.fromhex("ad8f36c902d006a51618693260a51618693060")


def main():
    d = bytearray(open(BASE, "rb").read())
    assert hashlib.md5(d).hexdigest() == MD5_BASE, "la base no es la v403"
    orig = bytes(d)

    # el sitio del parche es el que creo
    assert d[OFF_JSR:OFF_JSR + 5] == bytes.fromhex("a516186932"), \
        "en 0x%X no está el LDA $16 / CLC / ADC #$32: %s" % (
            OFF_JSR, d[OFF_JSR:OFF_JSR + 5].hex(' '))
    assert d[OFF_JSR + 5:OFF_JSR + 15] == bytes.fromhex("8d6336a51769008d6436"), \
        "pisado el STA $3663 / LDA $17 / ADC #$00 / STA $3664"

    # el espacio libre es todo 0xFF
    assert d[OFF_STUB:OFF_STUB + len(STUB)] == bytes([0xFF] * len(STUB)), \
        "el espacio libre en 0x%X no está a 0xFF: %s" % (
            OFF_STUB, d[OFF_STUB:OFF_STUB + len(STUB)].hex(' '))

    # 1. JSR al stub (little-endian) + 2 NOP
    d[OFF_JSR:OFF_JSR + 5] = bytes([0x20]) + STUB_ADDR.to_bytes(2, "little") + \
                             bytes([0xEA, 0xEA])
    # 2. el stub en el espacio libre
    d[OFF_STUB:OFF_STUB + len(STUB)] = STUB

    # nada más se ha tocado
    zonas = [(OFF_JSR, OFF_JSR + 5), (OFF_STUB, OFF_STUB + len(STUB))]
    for i in range(len(d)):
        if d[i] != orig[i]:
            assert any(a <= i < b for a, b in zonas), \
                "byte fuera de zona en 0x%X" % i

    # la cueva $FFC3 y la tabla $9BBD siguen intactas
    assert d[0x1FC3:0x1FD0] == bytes.fromhex("6410ad65362902f002b710ad8f"), \
        "cueva $FFC3 tocada"
    assert d[0x41BBD:0x41BFD] == orig[0x41BBD:0x41BFD], "tabla $9BBD tocada"

    open(SAL, "wb").write(d)
    print(SAL)
    print("  MD5    ", hashlib.md5(d).hexdigest())
    print("  SHA-1  ", hashlib.sha1(d).hexdigest())
    print("  CRC32  ", "%08X" % (zlib.crc32(d) & 0xFFFFFFFF))
    print("  stub en 0x%X (lógico $%04X): %s" % (
        OFF_STUB, STUB_ADDR, STUB.hex(' ')))


main()
