#!/usr/bin/env python3
"""Utilidad IPS: genera un parche (diff) entre dos ROMs y lo reaplica.

Formato IPS:
    "PATCH" + registros + "EOF"
    registro:  offset(3 BE)  size(2 BE)  datos...
    RLE:       offset(3 BE)  0000        runlen(2 BE)  byte

Uso:
    python3 tools/ips.py gen BASE MOD SALIDA        -> crea SALIDA (BASE->MOD)
    python3 tools/ips.py apply BASE PARCHESALIDA OUT -> aplica y escribe OUT
"""
import sys


def gen(base, mod, out):
    b = open(base, "rb").read()
    m = open(mod, "rb").read()
    assert len(b) == len(m), "tamaños distintos"
    recs = []
    i = 0
    n = len(b)
    while i < n:
        if b[i] == m[i]:
            i += 1
            continue
        # detectar run RLE >= 9 bytes
        j = i
        while j < n and m[j] == m[i] and (j == i or b[j] != m[j]):
            j += 1
        run = j - i
        if run >= 9:
            recs.append((i, 0, run, m[i]))
            i = j
            continue
        # run de datos distintos
        j = i
        while j < n and b[j] != m[j]:
            j += 1
        seg = j - i
        # trocear en segmentos de <= 65535
        k = i
        while seg > 0:
            chunk = min(seg, 65535)
            recs.append((k, chunk, chunk, 0))  # marker: datos
            seg -= chunk
            k += chunk
        i = j
    # serializar
    outb = bytearray(b"PATCH")
    for off, size, extra, rbyte in recs:
        if size == 0:
            # RLE
            outb += off.to_bytes(3, "big")
            outb += b"\x00\x00"
            outb += extra.to_bytes(2, "big")
            outb += bytes([rbyte])
        else:
            outb += off.to_bytes(3, "big")
            outb += size.to_bytes(2, "big")
            outb += m[off:off + size]
    outb += b"EOF"
    open(out, "wb").write(outb)
    return len(recs), len(outb)


def apply(base, patch, out):
    b = bytearray(open(base, "rb").read())
    p = open(patch, "rb").read()
    assert p[:5] == b"PATCH", "no es un IPS"
    assert p[-3:] == b"EOF", "sin EOF"
    i = 5
    while i < len(p) - 3:
        off = int.from_bytes(p[i:i+3], "big")
        size = int.from_bytes(p[i+3:i+5], "big")
        i += 5
        if size == 0:
            run = int.from_bytes(p[i:i+2], "big")
            byte = p[i+2]
            i += 3
            b[off:off+run] = bytes([byte]) * run
        else:
            b[off:off+size] = p[i:i+size]
            i += size
    open(out, "wb").write(b)


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "gen":
        r, n = gen(sys.argv[2], sys.argv[3], sys.argv[4])
        print("registros=%d bytes=%d" % (r, n))
    elif cmd == "apply":
        apply(sys.argv[2], sys.argv[3], sys.argv[4])
        print("ok")
    else:
        print(__doc__)
