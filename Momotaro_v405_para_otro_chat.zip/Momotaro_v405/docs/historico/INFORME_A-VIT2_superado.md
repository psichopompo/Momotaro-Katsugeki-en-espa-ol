# A-VIT2 — Los 3 frames de artefactos en los cerezos de los vítores

**Investigación completa (2ª revisión)** · 28 de agosto de 2026 · para David

---

## 0. Resumen ejecutivo

Los **3 frames** de artefacto que se ven al aparecer los cerezos de los
vítores (frames 387, 388 y 389) **no son un fallo del cargador del árbol ni
del TIA**. Son el coste de la apertura del **bocadillo de diálogo** que la
transición de los vítores desencadena, y que en la traducción usa las celdas
anchas del **abuelo** en vez de las compartidas de la japonesa.

Lo que se ve es el **fondo del árbol cargándose tarde**: el cargador del CG
del árbol compite por el tiempo de escritura de VRAM (vblank) con la carga
del bocadillo, y en la v393 va varios frames por detrás de la japonesa.

**David tenía razón: son 3 frames, no 2.** Mi conteo anterior de «2» se basó
solo en el primer tile del árbol y pasó por alto el tercero.

---

## 1. Corrección de un error de método propio

En una tanda anterior afirmé que la VRAM de la japonesa y de la v393 era
«byte a byte idéntica» en los frames 383–395 y que el artefacto «no estaba
en los tiles». **Eso era falso**, y el fallo fue de mi método:

- `PCE.__init__` carga el core con `CDLL(SO)`, y `ctypes` devuelve **el mismo
  handle** para cada instancia (dlopen cachea). Las dos instancias comparten
  el estado global del core.
- [HECHO] `pj.core._handle == pe.core._handle` → `True`.
- [HECHO] Tras crear la segunda instancia (`retro_load_game`), el
  `pj.ram()` pasa a devolver la RAM de la segunda: estaba comparando el core
  **contra sí mismo**.

Método corregido: **una instancia por ejecución**, volcando a disco (RAM,
VRAM, savestate, PNG) y comparando los volcados fuera del emulador.

---

## 2. Medición correcta — 3 frames

[MEDIDO, una instancia por ejecución, desde
`states/Momotarou Katsugeki (Japan) - pre-vitores.state`. Diff de pantalla
completa de la zona del árbol izquierdo (x9-67, y88-140) contra el frame 394
estable.]

| ROM | 387 | 388 | 389 | 390 |
|---|---|---|---|---|
| Japonesa virgen | 0 | 0 | 0 | 0 |
| ES v393 (oficial) | 2174 | 2349 | 44 | 0 |

- **JP limpia desde el 387. ES con artefacto en 387, 388 y 389** (el 389 con
  solo 44 px). **3 frames.**
- [HECHO] En los frames 387–388, el slot del árbol en la v393 contiene
  **basura** (`e403fe011f00070032007e007e00fe00`), que es el «artefacto» que
  se ve. La japonesa conserva el fondo anterior hasta que entra el árbol.

---

## 3. Qué es la rutina implicada

La divergencia está en la rutina `$C8xx` (banco `$0B`, ROM `0x16800+`), que
es la del **bocadillo de diálogo/abuelo**, no de los vítores. La transición
de los vítores abre un bocadillo, y por eso se ejecuta.

Los saltos desviados son **dos parches distintos**, ambos anteriores a la
v334 (el IPS más antiguo que conservamos):

**(a) Bug del rótulo de aldea** (v203/v204, entradas 204–205 del diario):
```
$C8CF  JMP $9A65  →  JMP $DE60
$DE60  LDA $3BBD / BNE +3 / JMP $9A65 / RTS
```
`$3BBD` = frames de vida del rótulo «Aldea de…». Bloquea el **dibujado** del
bocadillo del aldeano mientras el rótulo viva. Decisión de David: que el
diálogo espere al rótulo.

**(b) Bocadillo del abuelo** (reforma del otro chat, v225–v231):
```
$C8D2  JSR $9C32  →  JMP $DE78
$DE78  LDA #$02 / STA $368F / JSR $9C32 / JSR $C8DB / JMP $97EE
$C8D8  JMP $9952  →  JMP $97EE
```

Además, `$C8C2 SBC #$30 → #$21` es el **offset Y del abuelo** (el
`build_v199` lo documenta como `ABUELO_Y`; no tiene que ver con los vítores).

---

## 4. Aislamiento de la causa

[MEDIDO por reversión, solo en `/tmp`, sin tocar la oficial]

**Diff de pantalla (zona árbol, contra el frame 394):**

| Variante | 387 | 388 | 389 |
|---|---|---|---|
| Japonesa virgen | 0 | 0 | 0 |
| ES v393 (oficial) | 2174 | 2349 | 44 |
| Revertir `$C8D2`/`$C8D8` (ruta a) | — | — | — |
| Revertir `$9C5C` (ruta e) | — | — | — |
| Revertir **ambas (a+e)** | **52** | 0 | 0 |

Cada ruta cuesta ~1 frame; juntas, más el estancamiento del cargador, suman
los 3. Revertir ambas recupera 2 de los 3 frames, pero **no todo**: quedan 52
px en el frame 387.

**CG del árbol (VRAM `0x56c0-0x5c20`, bytes distintos del frame final):**

| Frame | JP | ES v393 | revert a+e |
|---|---|---|---|
| 384 | 1118 | 1118 | 1118 |
| 385 | 994 | 1118 | 1145 |
| 386 | 781 | 1118 | 1052 |
| 387 | 0 | 1145 | 0 |
| 388 | 0 | 1052 | 0 |
| 389 | 0 | 0 | 0 |

La v393 **estanca el cargador del árbol durante los frames 385–387** (no
avanza nada) porque las rutas del bocadillo le roban el vblank; luego retoma
en 388–389. Con a+e revertido el estancamiento desaparece, pero en el frame
386 va **271 bytes por detrás** de la japonesa (1052 vs 781), que son
exactamente los 52 px que llegan una trama tarde.

---

## 5. La tercera causa (52 px residual) — no aislada todavía

[HECHO + HIPÓTESIS, con errores propios reconocidos]

Con a+e revertido quedan 52 px en el frame 387 (x48-66, y91-131). Son tiles
del árbol que se pintan **una trama tarde**. En ese frame la VRAM (CG/BAT/SAT)
ya está completa: no es un problema de memoria, es de **timing de vblank**
(las escrituras de esos tiles llegan después del barrido del VDC).

Pruebas para aislarla (ninguna llega a 0):

| Prueba | Resultado |
|---|---|
| NOP `STA $368F` (`$7E7A`) | sin efecto |
| Revertir banco/offset del cargador del árbol (`$3F`→`$02`, `$54`→`$44`) | 39 px, pero cambia todo el perfil 384-386 |
| Revertir `$C8CF JMP $DE60` (rótulo) | sin efecto |
| Revertir `$C8C2 SBC #$21` (offset Y) | sin efecto |

**Corrección de una hipótesis propia equivocada:** supuse que las celdas del
abuelo (`$1C4-$1DD`) eran la tercera causa. Está **refutado**: anular
`STA $368F` no cambia ni los 52 px ni las celdas usadas.

### Corrección sobre `$368F` (entrada 13 del diario)

La 1ª revisión de este informe decía que el trampolín `$DE78` fuerza
`$368F=2` «incondicionalmente» y que por eso el bocadillo de los vítores sale
con las celdas del abuelo. **Eso es incorrecto**, por dos motivos:

1. Leí `$368F` con el offset equivocado (`ram()[0x368F]` en vez de
   `ram()[0x368F-0x2000]`), así que mis lecturas eran basura.
2. Medido bien: **`$368F=02` en JP y ES por igual** (desde el frame 378).
   `$368F` **no** distingue la variante abuelo de la compartida.

Lo que SÍ es [HECHO] es la diferencia de **celdas**: la v393 pinta el
bocadillo de los vítores con celdas del abuelo (`$1C4-$1DD`) y la japonesa
con las compartidas (`$19C-$1BF`). El selector real que provoca esa
diferencia **queda sin localizar**.

---

## 6. Revertir a+e NO es un arreglo limpio

[MEDIDO]

Revertir las dos rutas del bocadillo (a+e) recupera 2 de los 3 frames, pero:

- quedan **52 px** en el frame 387 (una trama), y
- en el frame 392 estable, revertir a+e cambia **220 px** respecto a la v393,
  localizados en la zona del bocadillo (x89-233, y50-69).

Es decir, revertir a+e **altera el bocadillo del abuelo que David diseñó**.
No es un revert «gratis» que solo toque la transición: las rutas son
estructurales para el bocadillo del abuelo.

---

## 7. Qué NO se puede hacer (y por qué)

- **Revertir las dos rutas** quita 2 de los 3 frames, pero cambia el
  bocadillo del abuelo (220 px) y deja 52 px residuales.
- **Revertir solo una** deja más retraso y también toca el abuelo o el
  cargador.
- No hay una forma limpia de quitar los 3 frames sin rehacer la apertura del
  bocadillo para distinguir «es el abuelo» de «no es el abuelo».

---

## 8. Qué queda pendiente

1. **[PENDIENTE]** La **tercera causa** (los 52 px de una trama): contención
   de vblank, causa exacta sin aislar.
2. **[PENDIENTE]** El **selector real** del bocadillo abuelo-vs-compartido
   (no es `$368F`).
3. **[HIPÓTESIS, para David]** Si el bocadillo de los vítores con las celdas
   del abuelo es defecto o intención. Ver capturas `capturas/bug_vitores/A_VIT2_*.png`.
4. **[DECISIÓN de David]** Aceptar los 3 frames y documentarlos, o encargar
   una optimización de la apertura del bocadillo.

---

## 9. Material generado

Capturas individuales (una por ROM/frame, sin rejillas), en
`capturas/bug_vitores/`:

- `A_VIT2_frame387_jp.png` — japonesa, frame 387 (limpia).
- `A_VIT2_frame387_es393.png`, `A_VIT2_frame388_es393.png`,
  `A_VIT2_frame389_es393.png` — los 3 frames de artefacto de la v393.
- `A_VIT2_frame387_rev_ae.png` — con a+e revertido (los 52 px residuales).
- `A_VIT2_frame392_es393.png` y `A_VIT2_frame392_rev_ae.png` — el bocadillo
  estable, para ver la diferencia de 220 px.
- `A_VIT2_cmp_frame389.png` — comparativa del frame 389 (de la tanda anterior).

Detalle técnico completo en `investigation.md`, entradas 13–16.
