# INFORME DE TRASPASO — Momotarou Katsugeki en castellano

**Fecha:** 2026-08-29 · **Estado:** v402 promocionada a **ROM OFICIAL**

Este informe cubre **de la v401 a la v402**: el cierre del último bug
abierto, **N6 (el Jizo mutilado)**. Sustituye a `INFORME_TRASPASO_v401.md`,
que pasa a `docs/historico/` (allí está todo el detalle de la tanda
v393→v401: A-VIT2, A-CASA, N4, N5 y los textos N1/N2/N3).

Si retomas el proyecto sin contexto: lee esto entero, después
`docs/PENDIENTES.md` (registro único de tareas) y `LEEME.md` (normas 12-392).

---

## 1. El proyecto

Traducción al castellano de **Momotarou Katsugeki** (PC Engine, 512 KB, HuCard).

- **Dirige: David** (*Psicopompo*, elotrolado.net). Las decisiones de diseño
  y de maquetación **son suyas**.
- Repo: `https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol`
- ROM base: `Momotarou Katsugeki (Japan).pce`,
  MD5 `ec7358edb3672a8aa8850623eec72a71` — **INTOCABLE**

### La ROM oficial

```
roms/Momotaro Katsugeki (Español).pce
MD5    38d00547cc4c64f911df8f1ed3cfcfb4
SHA-1  4261aa967635efcd1f972b94b18b7fafed98150a
CRC32  3B086A3D           524.288 B
```

Parche: `parches/Momotaro Katsugeki (Español).ips` (contra la virgen,
regenerado en esta tanda: 49.711 B, 2.420 registros). `roms/momotaro_es_v402.pce`
es el mismo fichero. **Round-trip verificado**: el IPS reconstruye la v402
byte a byte desde la japonesa virgen.

---

## 2. Cómo tratar con David

No es opcional. El detalle completo está en `docs/historico/INFORME_TRASPASO_v401.md`,
sección 2. Lo esencial, resumido:

- **Siempre en castellano.** Tutear.
- Reconocer los errores propios **explícitamente**, diciendo qué falló en el
  razonamiento.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- **Una sola pregunta por mensaje**, al final, con `¿` de apertura.
- Capturas individuales, nunca rejillas.
- **Si David contradice el análisis, comprobarlo antes de descartarlo: ha
  tenido razón SIEMPRE.** En esta tanda, **seis veces** (las cinco de la
  v401 más una nueva): el hueco de 4 px de «¡A JUGAR!» era exactamente la
  **entrada 106** del diario, que yo no había mirado hasta que David dijo
  *«mira el log, eso ya nos pasó»*.
- **«Recuerda revisar el log. Tiene que haber información útil.»**
- No sacar una versión por cada cambio mínimo: agrupar.
- **No se genera ROM hasta ver capturas de cómo quedan los cambios.**
- **La verdad es lo que se ve en pantalla, no el hex.**
- **NUNCA partir una palabra.** **No se puede recortar texto: tiene que caber.**

---

## 3. Qué se ha hecho de la v401 a la v402

| Ver | MD5 | Qué |
|---|---|---|
| **v402** | **`38d00547cc4c64f911df8f1ed3cfcfb4`** | **OFICIAL**: N6, el Jizo mutilado, cerrado |

Con esto **no queda ningún bug abierto**. El bug era el último de la lista
de mutilaciones que arrastraba el proyecto.

---

## 4. N6 — el Jizo mutilado (detalle técnico)

### El síntoma

Al inicio de una pantalla aparece el rótulo «COMIENZA EL JUEGO» y, mientras
está en pantalla, el **Jizo** (la estatua de piedra) se dibuja **mutilado**:
le faltan dos sprites. En cuanto el rótulo desaparece, el Jizo se recupera.

### La causa [HECHO, entrada 283]

La **SAT está llena** (64/64 sprites). El rótulo «COMIENZA EL JUEGO» es
nuestro y mide **152 px** frente a los ~96 del `ゲーム スタート` japonés, así
que gasta **30 sprites** (9 de texto + 21 de marco). Con la SAT agotada, al
Jizo le faltan sus sprites `$0C0` y `$102` (la base). No es un límite de
ranuras por scanline: el rótulo y el Jizo están a 26 scanlines de distancia.

### La vía (decidida por David)

Cambiar el texto del rótulo por **«¡A JUGAR!»** (su preferida entre 5
alternativas), que es mucho más corto, para que el rótulo gaste menos
sprites y deje sitio al Jizo.

### Dónde vive el rótulo (y por qué la solución no fue trivial)

El rótulo de la aldea **no se elige por una tabla de índice simple**: lo lee
el código `$DF58`, con dos tablas de 10 índices en banco `$15`:

```
$5B8E  (ROM 0x2FB8E)  ica[10]  = [7,2,3,2,2,5,4,1,0,6]   caja
$5B98  (ROM 0x2FB98)  ita[10]  = [7,2,3,2,2,5,4,1,0,6]   texto
```

El rótulo usa `text_index = 9` → `ica[9]` = caja 6 (176 px) y `ita[9]` =
texto 6 (18 glifos). La entrada 6 la usaba **sólo** «COMIENZA EL JUEGO»,
así que se reaprovecha entera: no se cambia ningún índice, se **repuntan
sus dos punteros**:

- `0x2FBAE` (puntero de caja `[6]`): `0x5DAD` → `0x5812` (caja nueva).
- `0x2FBBE` (puntero de texto `[6]`): `0x5F5E` → `0x5FBF` (lista centrada).

### El texto y los glifos

```
«¡A JUGAR!»  9 glifos: CA 41 20 4A 55 47 41 52 21  (en 0x1F9C4, + 00×8)
glifo «¡»    en 0x3DCB0          glifo «!»    en 0x3DB50
```

«¡A JUGAR!» son **9 glifos = longitud IMPAR**. Y aquí estaba la trampa.

### El hueco de 4 px — el error que ya habíamos cometido (entrada 106)

El fondo blanco del rótulo lo pintan **dos** cosas: los sprites **laterales**
(`$03E8`, blancos hasta `-half+15`) y las **celdas de texto** (que limpian su
CG a blanco). Al centrar un nombre de **longitud impar** el texto se desplaza
+4 px, y entre el lateral (`-half+15`) y el texto (`-half+20`) quedan **4 px
que nadie pinta**: una columna vacía. Con sobrante par no pasa (por eso
«Isla Ogros», 10 glifos, salía limpio).

La primera versión del fix usó la **caja par** de Isla Ogros (112 px, sin
tapón) y David vio la columna vacía de 4 px — la misma de la v138. **Mi
error: elegir la caja por anchura y no por paridad de glifos.**

**El arreglo:** un «tapón» blanco (`$03EC`, patrón 16×16 de índice 4) en
`-half+16`, sólo cuando el sobrante es impar. La caja final es de **112 px**
(12 celdas) **más el tapón**, una lista nueva de 66 B en `0x2F812`. El tapón
va en la lista **inferior** (si va en la superior se come dos letras).

**Norma 394. La caja de un nombre impar no es la misma que la del par de su
misma longitud: la impar lleva tapón. Al acortar un texto hay que elegir la
caja por PARIDAD de glifos, no sólo por anchura.**

### Los errores propios, en cascada

Los tres, corregidos y registrados en el diario (285-286):

1. **Cambié `0x2FB8E`** (caja del rótulo de «Partida»), no `0x2FB97` — había
   leído mal qué índice usa la escena.
2. **Pisé el terminador** de la lista de «Partida» escribiendo la lista
   centrada en `0x2FFBE`; el espacio libre real empieza en `0x2FFBF`.
3. **Usé la caja par** (sin tapón) → la columna de 4 px.

### Verificación [HECHO, emulador con el state real de David]

```
                rótulo              Jizo        hueco de fondo
v401            30 sprites (176 px)  2 (mutilado)  —
fix sin tapón   17 sprites (112 px)  3 (completo)  4 px a la izquierda
fix CON tapón   18 sprites (112 px)  3 (completo)  NINGUNO
```

Tapón medido en SAT: celda `$1F6` en x=88 (dx=-40), entre el lateral (blanco
hasta x=87) y el texto (x≥92). Barrido de píxeles sobre el frame: **0 píxeles
con el color de fondo** dentro del rótulo. Y, lo decisivo, **validado por
David en pantalla**: Jizo completo, «¡A JUGAR!» centrado y sin columna vacía,
y diálogos con «¡…!» correctos.

### Resumen de cambios (v401 → v402, 120 bytes en 10 tramos)

```
0x1F9C4  «¡A JUGAR!» (9 B + relleno)            texto
0x3DCB0  glifo «¡»                               (2 tramos)
0x3DB50  glifo «!»
0x2F812  caja nueva: 112 px + tapón $03EC (66 B)
0x2FBAE  puntero caja[6]   0x5DAD → 0x5812
0x2FFBF  lista de texto centrada, 5 celdas (25 B)
0x2FBBE  puntero texto[6]  0x5F5E → 0x5FBF
```

---

## 5. LO QUE TOCA AHORA

**Ya no queda ningún bug abierto.** El orden pasa a (ver `docs/PENDIENTES.md`,
registro único):

### 1. A-SPR — mutilaciones por exceso de sprites por línea

Casos: el niño aldeano sin cabeza, las bolas del minijuego. **Aviso: parte
de ellas ya existe en la ROM japonesa** — comparar el mismo frame contra la
virgen antes de tocar nada. La medición antigua decía *«bolas mutiladas: peor
línea 56, con 11 sprites; no llega a 16»*, o sea que ahí el límite duro no
era la causa. Rehacer con `tools/vdc_slots.py`.

### 2. A-GRAF — gráficos con texto por traducir. **LOS EDITA DAVID**

Nuestro trabajo: **localizarlos, extraerlos a PNG y pasárselos**, y luego
**reinsertar** lo que devuelva. Nada de editar píxeles por nuestra cuenta.

### 3. Resto de pendientes menores

- **A-NOM**: «Raqueta» en singular. Alternativas de 6 letras: «Nieve»,
  «Calzas», «Zuecos». **Decide David.**
- **2 bloques japoneses del banco `$25`**: `0x4A484` (53 B, el final) y
  `0x4A71F` (154 B, créditos con «HUDSON SOFT»).
- Bug gráfico bajo la cabeza del ogro rosa (final Difícil).
- Tabla `0x24DE` (presentación de enemigos): apunta a offsets japoneses.
- Colas invisibles en las descripciones de objeto.
- Posadero: falta «ogros.».
- Backup RAM `0x1F51E` (674 B, sin revisar).
- 5 mensajes del menú (`0x435E6`, `0x4363D`, `0x4366B`, `0x4369C`, `0x436CC`).

### Testeo acumulado

Sobre la v391: fase completa, todos los aldeanos, tiendas, minijuegos, quiz,
jefe final, cuatro finales, dos pantallas secretas. Sobre la v393: primer
nivel completo. Sobre la v398/v401: bocadillos del abuelo y aldeanos, vítores,
aldeana de Kaguya, tienda, baño. Sobre la **v402**: N6 en pantalla (Jizo
completo, «¡A JUGAR!» centrado). Falta el testeo del juego completo.

---

## 6. El workspace

```
COMO_RETOMAR.md              arranque rápido (leer primero)
Momotaro/
  LEEME.md                   normas 12-392 + estado (a v402)
  investigation.md           diario, 287 entradas
  roms/                      japonesa virgen + oficial v402 + hitos
  parches/                   oficial + 17 hitos (v334…v402)
  states/                    savestates de David + .sav
  capturas/                  N6_jizo_bug_david.png, N6_jizo_fix_david.png, …
  docs/                      PENDIENTES.md (registro único), este informe,
                             PROMPT_METODO.md, MAQUETACION_*, QUIZ.md, …
    historico/               informes de etapas cerradas (v386, v393, v401…)
  tools/                     el toolkit (66 ficheros)
    ips.py                   NUEVO: genera y reaplica parches IPS (round-trip)
    historico/               los build_* de versiones retiradas
```

### El método (`docs/PROMPT_METODO.md`)

Diario en `investigation.md`. **Las hipótesis falsas NO se borran**: se marcan
`[DESCARTADO]` o `[ERROR PROPIO]` y se explica qué falló. Una medición → una
causa → un arreglo → una verificación. Prohibido escribir bytes a ciegas.
Cada versión con MD5/SHA-1/CRC32, asserts con byte esperado y zonas intactas,
IPS contra la virgen con round-trip. `docs/PENDIENTES.md` es el registro
único.

**Lo que más ha costado en esta tanda, en una frase:** no mirar el log. El
hueco de 4 px ya estaba resuelto desde la v138 (entrada 106) y yo lo
reintroduje por no repasar el diario antes de acortar el texto.
