# PENDIENTES — registro único del proyecto

> **Para qué es este fichero.** David: *«Hay que ir apuntando todo aquello
> que siga pendiente, para no olvidarnos. A lo largo del proyecto hemos ido
> mencionando cosas que había que mirar, como mutilaciones en muchos sitios
> y cosas así, que ahora se han olvidado.»*
>
> Regla: **nada se cierra sin que David lo confirme en pantalla.** Cuando se
> cierre, se mueve a la sección «Cerrado» con la versión en que se arregló.
> Cuando aparezca algo nuevo, se añade AQUÍ, no solo en el diario.

Estado a fecha de la **v402 = ROM OFICIAL** (`38d00547cc4c64f911df8f1ed3cfcfb4`).

## ORDEN DE TRABAJO (actualizado 2026-08-30, tras el testeo completo de David)

David jugó de principio a la última fase y trajo una tanda nueva (ver
`## Tanda 2026-08-30`). El orden pasa a:

1. **Textos rotos/que no caben** (ermitaños, arte Parapunte, quiz, aldeanos,
   posada) — los localizo y corrijo yo.
2. **Vítores con franjas** (regresión: «Colorín colorado», «Japón cha-chá»,
   «Tachán fase superada»).
3. **A-GRAF** — gráficos con texto (baños, bienvenida a jefes, GOAL, posadas,
   deguchi, «Banzai! Studio», «medetashi medetashi»). **Los edita David**; mi
   trabajo es localizarlos, extraerlos a PNG y reinsertarlos.
4. **A-SPR** — mutilaciones por exceso de sprites.

Informe vigente: `docs/INFORME_TRASPASO_v402.md`.

## Tanda 2026-08-30 — testeo completo de David (todo abierto)

| # | Qué | Estado |
|---|---|---|
| **T-GRAF1** | Baños femeninos: letrero «oni no yu» (gris, detrás) | Por localizar/extraer |
| **T-GRAF2** | Mensaje de bienvenida antes de los jefes finales | Por localizar |
| **T-GRAF3** | Cartel GOAL (katakana) al final del minijuego | Por localizar |
| **T-GRAF4** | Posada: dos opciones «tomery»/«yameru» | Por localizar |
| **T-GRAF5** | Tienda: rótulo «deguchi» (salida) | Por localizar |
| **T-GRAF6** | Finales Fácil/Normal: «Banzai! Studio» | Por localizar |
| **T-GRAF7** | Final créditos: bocadillo «medetashi medetashi» (めでたしめでたし) | Por localizar/editar (vertical) |
| **T-ERMI** | Ermitaños: «¡Yo soy el / ermitaño XXXX» no caben nombre ni «!» | **CORREGIDO en v403 (prueba).** Línea 1 «¡Soy el ermitaño» (16), línea 2 nombre+«!» (`0x4B85D`). [PENDIENTE] captura de David |
| **T-VIT** | Vítores con franjas negras y píxeles blancos («Colorín colorado», «Japón cha-chá», «Tachán fase superada») | **CORREGIDO en v405 (prueba).** La v404 ponía `ADC #$34` para `$368F<>2` y los dejaba 4 px bajos. El valor correcto es el ORIGINAL `#$30`: en la v393 los `$368F<>2` ya estaban bien, y el N5 global (v396) los rompió. Fix: `ADC` condicional `#$32` (`$368F=2`) / `#$30` (`$368F<>2`) vía stub en `0x17E86`. Ver entradas 293-295. [PENDIENTE] captura de David |
| **T-ARTE** | Al obtener el arte Parapunte sale «ParaÇunte», sin «!» | **CORREGIDO en v403 (prueba).** Dos fallos: (1) el katakana es ﾊﾟﾛﾌﾟﾝﾃ = «Paropunte» (pa-ro-pu-n-te), así que unifico la tabla de artes a «Paropunte» (`0x4AEAA` y `0x4AEDB`, `a`→`o`); (2) la `p` era byte directo `$B0`, que el motor del premio pinta Ç (mismo bug v391 «JanÇu»): `$B0`→`$5E` en `0x4AEAB`/`0x4AEDC`. Y el «!»: el premio (`$D5F6`, 3 trozos `JSR $DD42`) sumaba «Toma: ¡»(7)+nombre(9)+«!»(1)=17 > 16 columnas. Cambio a «Toma: Paropunte.»: quito «¡» (`0x4B824`) y «!»→«.» (`0x4ADF5`). Decisión de David: sin signos de exclamación en esta obtención. [PENDIENTE] confirmar en pantalla que el «.» cabe (columna 16) |
| **T-POSADA** | Posada de 1000 ryos: una «Ç» flotando arriba a la derecha | **CORREGIDO en v403 (prueba).** Causa [HECHO]: la Ç es un **dakuten `$DE` huérfano**. El japonés era «…イッパク1000$デトマレマス!»; al traducir «Posada: 1000.» quedaron sin borrar el `$DE` de «デ» y el «トマレマス!» (c4 cf da cf bd 21 = «Í…ç…í!»). El `$DE` se pinta como glifo suelto ENCIMA de la línea (comportamiento dakuten, norma 383) y por eso «flota». Borrado `$DE` (`0x4882D`) y el «トマレマス!» (`0x4882E-0x48834`) en la posada 1000 (t7) y en la posada 100 (t8, `0x48C77-0x48C7D`). [PENDIENTE] captura de David. Relacionado con A00 (colas invisibles), pero el dakuten SÍ se ve |
| **T-QUIZ** | Pregunta «Con el gorro, / ¿qué más puso?» no se entiende | **CORREGIDO en v403 (prueba).** Línea 1 «Además del gorro» (16), línea 2 «¿qué les puso?». `p` de «puso» como alias `$5E`→`$B0` directo (`0x4B2E2`). [PENDIENTE] captura de David |
| **T-SOLO** | Aldeano: «Si sigues adelante solo perderás la vida…» — ¿tilde en «sólo»? | **CORREGIDO en v403 (prueba).** Es adverbio (`dake` = solamente) → «sólo» (`0x4BD90`). [PENDIENTE] captura de David |
| **T-OGRO** | Aldeano: «Ese ogro que duerme ahí fuera.» no se sostiene | **CORREGIDO en v403 (prueba)** la variante sin «De» (0 B): «…ahí fuera, dicen que…» (`0x4A204`, `.`→`,` y `D`→`d`). [PENDIENTE] decisión de David: repunte completo «De ese ogro…» (+3 B) o se queda así |
| **T-DADOS** | Minijuego de dados: al perder dice «¡Hasta la vist» (sin «a!») y desplazado a la derecha | **CORREGIDO en v403 (prueba).** Causa [HECHO]: entre «¡Qué lástima!» (13) y «¡Hasta la vista!» (16) había 5 espacios en vez de 3; los 2 de sobra empujan la 2.ª línea a la celda 2 y el «a!» se sale de la caja 16×2. Quitados 2 espacios: «¡Hasta la vista!» ocupa exactamente `0x4AD20-0x4AD2F`. [PENDIENTE] captura de David |
| **T-DESPEDIDA** | Restos japoneses en la despedida de tienda (colas de kana con dakuten sueltos) | **CORREGIDO en v403 (prueba).** Las 5 despedidas (t0-t4) de la tabla `0x10854` dejaron la cola del kana en el relleno final de cada buffer: «ザイマスカ» (`0x48BE0`), «イマスカ» (`0x48C06`), «ウデスカ?» (`0x48C2B`) y «ャ!» (`0x48C51`). Limpiadas a `$A0`. Caen fuera de la caja 16×2 (recortadas), así que es higiene, no se veían. [PENDIENTE] confirmar que no se ve nada raro |

> **Falta por recibir:** los `.state` de esta tanda (ermitaños, posada,
> deguchi, vítores, arte Parapunte, quiz). En el workspace sólo llegaron las
> capturas PNG.

## ORDEN ANTERIOR fijado por David (2026-08-28)

1. ~~**A-VIT2**~~ — **CERRADO en la v394** (confirmado por David el 2026-08-29).
2. ~~**A-CASA**~~ — **CERRADO en la v395**, pendiente de que David lo pruebe.
4. **A-SPR** — mutilaciones por exceso de sprites por línea.
5. **A-GRAF** — los gráficos que faltan por traducir. **Los edita David**;
   nuestro trabajo es localizarlos, extraerlos y reinsertarlos.


> **Las v335, v336 y v337 están descartadas y ya BORRADAS** (los finales
> quedaban ilegibles y David ordenó volver a la v334 limpia). La línea
> válida es **v334 → v338**. Todo lo que esas versiones decían haber cerrado
> vuelve a estar ABIERTO más abajo.
>
> Las ROMs intermedias se borraron tras comprobar que sus 33 IPS las
> reproducen byte a byte sobre la japonesa virgen. Se conservan los hitos
> v334, v338, v378, v385 y v386.

---

## A-MJ. Bocadillo negro sin marco en los minijuegos de Momotaro — **CERRADO v388**

| # | Qué | Estado |
|---|---|---|
| **A-MJ** | En los minijuegos donde manejas a Momotaro, el bocadillo sale como un **rectángulo negro sin marco**. | **CERRADO v388. SÍ ERA regresión de la v387** (mi diagnóstico inicial fue erróneo): el gancho `$DFAE` que quité **no era código muerto**, cargaba el marco (`0x4C07`→`$1EC`, `0x4B0F`→`$1F8`, rabillo incluido). La v388 lo restaura y conserva el árbol movido. Diagnóstico anulado: bisección con los 5 hitos → **la v334 ya fallaba igual**, y v386 vs v387 dan imagen idéntica. Causa: el bocadillo se **ensanchó** en la traducción (texto hasta `$1C2` en vez de `$1BC`) y su marco apunta a `$1EC`/`$1EE`, que **son celdas del menú RUN** (bloque C del stream `0x22CA0`, que cubre `$1E0-$1F9`) y contienen relleno sólido, no marco. En la japonesa el marco va en `$1A4`/`$1A6`/`$1A8`/`$1AD`. Mismo patrón que el bocadillo del abuelo (entrada 229). Savestate: `states/minijuego_momotaro.state`. |

---

## A-NOM. «Raqueta» en singular (no cabe «Raquetas») — **decisión de David**

| # | Qué | Estado |
|---|---|---|
| **A-NOM** | El objeto se llama «Raqueta» y no «Raquetas» porque el nombre sólo dispone de **6 letras**. | **Comprobado que no cabe** (entrada 249): tras el nombre viene código propio del objeto y luego la ficha del objeto `$05`, sin un byte libre. Descartados: huecos del banco `$21` (son tablas), reapuntar el campo `$0A` (cada `AC B1` arranca código distinto), correr los bytes (pisa código ajeno). Alternativas de 6 letras: «Nieve», «Calzas», «Zuecos». **Decide David.** |

---

## A-VIT2. Artefactos en la transición de los cerezos — **CERRADO v394, confirmado por David**

| # | Qué | Estado |
|---|---|---|
| **A-VIT2** | Antes de que los cerezos salgan bien se veían 2-3 frames con artefactos. | **CERRADO v394.** Cuadrados blancos y banda de artefactos, fuera. En el último frame quedan 30 px (dos motitas); la propia japonesa tiene 4122 en su frame equivalente: **estamos por debajo del original**. |

**La causa** (entrada 262): el cargador `$DB60` usa una fórmula lineal
(`origen = $5400 + t*32`) y sus listas barren **t = 0..82: OCHENTA Y TRES
tiles** (`0x04400`-`0x04E60`, 2656 B). **La v388 movió al banco `$3F` sólo
los 43 últimos**, los que estaban sucios. Los 40 primeros se quedaron
leyendo `$FF`, y de ahí los cuadrados blancos.

**El arreglo, en dos pasos:**

2. **Remapeo de índices** (lo que lo cierra): medido que el pase 2 reescribe
   TODOS los destinos de los pases 0 y 1, o sea que éstos son sólo la
   animación de aparición. Se cambian sus 40 índices para que lean los tiles
   buenos del pase 2. **40 bytes, cero espacio nuevo.**

**El paso 1 se retiró:** copiar los tiles resultó innecesario (el remapeo da
el mismo resultado) y **rompía el bocadillo de la intro**, porque los `$FF`
de `0x7F800` no son hueco sino CG comprimido. La v394 final cambia **95
bytes**, no 775.

De paso se sacaron de las listas tres cadenas de texto que la traducción
había metido dentro y que el cargador se tragaba como índices de tile
(slots válidos `20/32/43` → `12/28/43`, como la japonesa).

    px de copa mal, por frame
    JP    384:6269  385:5283  386:4113  387:   0
    v393  384:6269  385:6269  386:6269  387:6516  388:7156  389:156
    v394  384:6269  385:6269  386:6269  387:4365  388:1194  389: 30

Capturas: `capturas/bug_vitores/A-VIT2_v394f_{387,388,389}.png`.

**Normas nuevas: 372** (el bloque es todo el rango que barren los índices) y
**373** (si la última pasada reescribe, las intermedias sólo son animación:
repuntar índices en vez de mover datos).

---|---|---|
| **A-VIT2** | Antes de que los cerezos salgan bien se ven 2-3 frames con artefactos. | **CASI CERRADO en la v394.** Los **cuadrados blancos** (lo gordo) han desaparecido: tiles a `$FF` de **20 a 0**. Queda una **banda de artefactos** de 2 frames en la zona media de la copa. |

**La causa** (entrada 262): el cargador `$DB60` usa una fórmula lineal
(`origen = $5400 + t*32`) y sus listas barren **t = 0..82: OCHENTA Y TRES
tiles** (`0x04400`-`0x04E60`). **La v388 movió al banco `$3F` sólo los 43
últimos**, los que estaban sucios. Los 40 primeros se quedaron leyendo `$FF`.

**Lo arreglado en la v394:** copiados los 40 tiles que faltaban a `0x7F400`
desde la ROM japonesa limpia, sin pisar los 459 B de datos de la traducción
que viven ahí (821 bytes escritos, 459 respetados). De paso, sacadas de las
listas tres cadenas de texto que la traducción había metido dentro y que el
cargador se tragaba como índices de tile (slots válidos `20/32/43` → `12/28/43`,
como la japonesa).

**Lo que falta y por qué está bloqueado:** quedan 16 tiles incompletos
(t=0..7 y t=32..39), los que caen sobre esos 459 B. Para cerrarlo hay que
reubicarlos y **no cabe**:

    bloque A (textos de enemigos)  0x7F400-0x7F511   273 B
    bloque B (CG suelto)           0x7F800-0x7F900   256 B
    TOTAL                                            529 B
    hueco libre tras el árbol      0x7FE60-0x80000   416 B
    faltan                                           113 B

Barrida la ROM entera: **no hay ni un hueco de 1024 B**, ni un banco con
menos de 2000 B usados. Reubicar exige partir los dos bloques y repuntar cada
uno con un mecanismo distinto. **Decide David si merece la pena.**

Capturas: `capturas/bug_vitores/A-VIT2_{JP_386,v393_388,v394_388}.png`.

---

## A-RUN4. Submenú con caracteres repetidos (raquetas) — **CERRADO v389**

| # | Qué | Estado |
|---|---|---|
| **A-RUN4** | Al entrar en el submenú de un objeto con la lista scrolleada, salían `a` repetidas y en Mesen el menú se colgaba. | **CERRADO v390 (dos bytes).** `0x430F0` `$00`→`$AC` y el nombre acortado a «Raqueta» (`0x430EF`→`$00`), porque ese byte hacía de terminador del nombre *y* de puntero a la vez. La ficha del objeto `$09` (raquetas) apuntaba a `$B100` (código) en vez de a `$B1AC` (tabla de textos), así que el bucle `$D68C` recorría opcodes como caracteres y nunca hallaba el terminador. **No era de la v385**: ésta sólo lo destapó. Lo resolvió el breakpoint de David sobre `$3B52` en Mesen. Ver entrada 247. |

## A-PPT. Minijuego de piedra, papel o tijera — **CERRADO v393**

| # | Qué | Estado |
|---|---|---|
| **A-PPT** | La presentación del minijuego salía con signos latinos corruptos. | **TRADUCIDO en la v393.** Resultado: «¡Piedra, papel / o tijeras! / ¡Mira allá!» y «¡Iguales! / ¡Mira allá!», la frase completa sin recortar. |

**Cómo se hizo** (entradas 252-259):

- **No era un gráfico.** Es texto en claro por la ruta katakana (`>= $A0`);
  se ve mal el latino porque ocupa el espacio del kana. Lo corrigió David.
- **Motor:** `$C79A`, banco `$08` (ROM `0x1079A`). Hornea 16 celdas
  `$0EC-$0FB`. Ancho medido: **14 columnas**, `charset_oficial` (`p` = `$5E`).
- **Tres líneas con UN byte:** `0x106E3` `LDX #$02` → `#$03`.
- **Los punteros no están en tabla**, sino como inmediatos en el banco `$08`:
  `0x11D1C`/`0x11D20` (mensaje A) y `0x11D27`/`0x11D2B` (mensaje B). Por eso
  se pueden mover por separado.
- **Reparto:** A (38 B) → `0x4B826`, hueco de 55 B; B (22 B) → `0x4B908`.
- Controles: `$00` pausa · `$80` fin de línea · `$FF` fin de mensaje.

**La v392 se retiró: un byte de relleno pisó código** (entrada 260). El
bloque B llegaba hasta `0x4B93C` cuando el código del banco `$25` empieza
**en `0x4B93B`**: el `$A0` convirtió el `LDA $DD` de `$793B` en `LDY #$DD`
y los diálogos de todo el juego perdían una letra en la primera lectura.
La v393 es idéntica con `B_TOPE = 0x4B93B`.

**«¡Mira allá!» no sobra** (entrada 261): en la ROM japonesa los DOS
mensajes llevan «acchi muite hoi» pegado detrás. El juego canta el cántico
de la tirada y el reto de la mirada en un solo bocadillo, igual que el
original. Separarlos exigiría partir los mensajes y añadir una llamada
nueva al motor. Se deja como está.

**CERRADO:** David jugó el primer nivel completo con la v393 —aldeanos,
objetos y minijuegos, ocultos y de tienda— sin ver un solo error.

**Aparte, quedan 3 bloques sin traducir en el banco `$25`:**
`0x4A484` (53 B, el final), `0x4A71F` (154 B, créditos con «HUDSON SOFT»),
`0x4AC44` (71 B, el baño de mujeres).

---

## A-VIT. Artefactos sobre los cerezos de los vítores — **CERRADO v387**

| # | Qué | Estado |
|---|---|---|
| **A-VIT** | Al pasarse el primer jefe aparecen los vítores con cerezos en flor de fondo. **Sobre cada árbol se ve el mismo cuadrado de artefactos.** | **CERRADO v387.** Dos causas: un gancho muerto (`$DFAE`) que guardó datos dentro del bloque del árbol, y el solape entre la fuente del menú (`0x4000-0x4CFF`) y el árbol (`0x4900-0x4E5F`), que **ya existía en la japonesa**. Arreglo: quitar el gancho y mover el árbol al banco `$3F`. Pendiente de que David lo confirme en pantalla. Detalle: Reclamado por David con capturas. Material en `capturas/bug_vitores/`: `en_pantalla.png`, `tilemap_1..4.png`, `tileviewer.png`. Datos del Tilemap Viewer: tiles `$2D0`, `$2CE`, `$2B7`, `$2B9`; columnas 13-16, filas 43-46; **paleta 2**; tilemap 64x64 en `$0000`, 4 bpp. Savestate útil: `states/Vitores.state`. |

> [HIPÓTESIS sin comprobar] Que sea **siempre el mismo cuadrado sobre cada
> árbol** sugiere que la copa referencia celdas de una zona que otra cosa
> reutiliza, igual que le pasaba al bocadillo del abuelo. Medirlo antes de
> darlo por bueno.

---

## A-BOC. Bocadillo del abuelo azul al abrir el menú RUN — **CERRADO v386**

| # | Qué | Estado |
|---|---|---|
| **A-BOC** | Al abrir el menú RUN con el bocadillo del abuelo en pantalla, el bocadillo se volvía un rectángulo azul con líneas rojas, sin marco. Sólo se salvaba el rabillo. | **CERRADO v386.** El cargador de CG del menú (`$D268`, stream en ROM `0x22CA0`) subía **58 celdas** a `$1C0-$1F9` cuando el menú **sólo usa 8**. El bocadillo apaisado vive en `$1C4-$1DD`: las 16 celdas caían dentro. Arreglo: partir el stream en tres bloques ($1C0, $1D0, $1E0) y saltarse las 24 celdas centrales, con cueva en `$DFE1`. Verificado en pantalla y 43 savestates sin regresión. Codec en `tools/cg.py`. |

> **OJO — el diagnóstico de la entrada 228 del diario era FALSO.** Decía que
> «el bocadillo apaisado nunca tuvo marco». Sí lo tiene. Se diagnosticó sobre
> un savestate tomado con el menú ya abierto, es decir, sobre el daño ya
> hecho. Ver norma 354.

---

## A0. URGENTE — abierto en la v326

| # | Qué | Estado |
|---|---|---|
| ~~A0a~~ | ~~El `©` en las preguntas~~ **RESUELTO v327**: eran los alias `$5B/$5D/$5E`. Ahora bytes directos | Los alias `b=$5B` `c=$5D` `p=$5E` salen bien en las OPCIONES y mal en las PREGUNTAS. Descartado: tabla `$BF9B`, tablas de glifos `$9CF3`/`$9CB3`, y `$5C` suelto (hay cero). Sospecha: `$DB4E` empaqueta 2 caracteres por celda VRAM. **Arreglo seguro: bytes directos `$A2 $A3 $B0`** |
| ~~A0b~~ | ~~Cuatro preguntas~~ **RESUELTO v327**: reformuladas y todas a 15 columnas | 13, 19, 31, 36. David propone repartir distinto entre las dos líneas de 16 |

---

## A00. Aparecido en la v333

| # | Qué | Estado |
|---|---|---|
| **A00** | **Texto invisible al final de las celdas** | Tres casos ya: (1) 8 B de japonés en la ranura `$4834` de las posadas, desde la v307 — **limpiado en v333**; (2) « te » tras la Capa — **limpiado en v334**; (3) **colas de traducciones antiguas en casi todas las descripciones de objeto** (`e vida.`, `écnica.`, `liado.`, `cotone`, `s ogro`, `en hi`, `bertad.Cor`, `lejosE`…). No se ven porque el motor corta a 16 columnas, pero están. **Sin limpiar**: no urge, pero conviene antes de cerrar el parche (norma 323) |

---

## A. Traducción pendiente

| # | Qué | Dónde | Estado |
|---|---|---|---|
| A1 | ~~**Quiz del abuelo**~~ | `0x4AEE6`-`0x4B87B` | **HECHO en v324.** 40 preguntas (2x16 col) + 120 opciones (8 col, 7 útiles). Tabla de punteros en `0x11818`. Sin verificar en pantalla |
| A4b | **Cinco mensajes sueltos** del menú (repetido, ver A4) | — | — |
| A4 | **Cinco mensajes sueltos** del menú | `0x435E6`, `0x4363D`, `0x4366B`, `0x4369C`, `0x436CC` | Sin tabla localizada. Comprobar si son repuntables |
| A5 | **Créditos y los 4 finales** | `0x3B800` (largos) y `0x4A484` (corto) | **ABIERTO otra vez.** Inventariados en `docs/MAQUETACION_finales.md`. Lo hecho en v336/v337 **queda anulado**: David lo vio y son «un horror» — palabras partidas, nombres cortados, principio y final del Normal sin traducir. Se rehace desde cero sobre la v338, **con capturas antes de generar ROM** |
| A5b | **Discurso del abuelo a medias** | `0x4A446`-`0x4A4B8` | Traducido hasta `0x4A475`; **52 bytes en japonés que SÍ se ven**. Propuesta lista |
| A6 | **Backup RAM** — errores de guardado | `0x1F51E`, 674 B | Sin tocar |
| A7 | **4 bloques huérfanos** de los vítores | `$40E8 $4112 $4139 $4163` | Forman cadena secuencial. **Sin lector conocido** |
| A8 | Textos en **gráficos** (sprites) | varios | Sin inventariar |
| A9 | **Passwords amigables** vinculados al valor interno | — | Idea de David, sin empezar |

---

## B. Gráficos y mutilaciones

> Esta es la sección que más se ha ido perdiendo. Muchas de estas se
> mencionaron hace decenas de versiones y nunca se cerraron.

| # | Qué | Estado |
|---|---|---|
| B1 | ~~**Casa mutilada en el mapa (Kachiyama)**~~ | **CERRADO v395** (entradas 264-268). Causa: 16/16 ranuras en y=120..127; el borde inferior del rótulo se lleva 10 de las 16. Arreglo: subir el rótulo 8 px en las 3 listas del grupo 5 (mapas 4 y 12) + cueva `$DFDE` que da al rabillo una copia propia, porque su lista `$DF06` es global. 58 bytes. **CONFIRMADO por David en pantalla** |
| B2 | **Pancarta de vítores 4 px alta** | Medido: texto en y=128..151, marco 112..176, descuadre de 4,5 px. **Mismo bloqueo que B1**: la Y sale de código, no de tabla |
| B3 | **Menú RUN en cascada** — tres recuadros escalonados | Rompen el límite de sprites. Idea de David: mostrar solo el recuadro activo. *«lo más difícil que nos queda»* |
| B4 | **Bocadillo que se sale por los lados** | Entrada del diario: *«localizada la cadena, pero no se puede cerrar sin medir en vivo»* |
| B5 | **Flechas de continuar y cursor SÍ/NO** | `$9A5F` y `$9A56` están en VRAM pero **ninguna lista de sprites las incluye**. Nadie las muestra. Abierto |
| B6 | **Celdas sin limpiar en el motor de tienda** | En el bocadillo del abuelo limpia `$9C29`; el de tienda no tiene equivalente o no se llama |
| B7 | Otras mutilaciones vistas de pasada | Sin inventariar. **David las irá anotando en el testeo completo** |

---

## C. Textos a verificar en pantalla

| # | Qué | Riesgo |
|---|---|---|
| ~~C1~~ | ~~«Faltan momos»~~ **RESUELTO v331**: `0x19BFA`, ahora «0 momos» |
| C1b | ~~«Faltan momos» original~~ | Si usa bocadillo de 8 celdas se verá «Faltan m». Alternativas contadas: `Sin momo` (8), `Faltan` (6), `Pocos` (5) |
| C2 | **Mensajes que solo salen provocándolos** | Comer algo que no se come, usar comida, gastar técnica sin momos. Solo se ven jugando |
| C3 | **Nombres de técnica en pantalla** | `Parapunte` son 9 y en japonés cabían 6 celdas visibles |
| C4 | **Vítores restantes** | David ha visto dos de los 19. Ahora centrados |
| C5 | **Dados rehechos** | Estructura corregida en v319, sin verificar en pantalla |
| C6 | **Menú RUN** (v318) | Destinos, `Usar`/`Dejar` y ermitaño, sin verificar |
| C7 | **Rótulos de aldea** (v320) | Deben volver a decir «Aldea ...». Sin verificar |
| C8 | **El quiz entero** (v324) | 40 preguntas y 120 opciones. Sin verificar en pantalla |
| C9 | ~~El «Vuelo.» que sobraba~~ | **NO sobraba.** Era «Soy » + técnica + «...!» concatenados. NOP revertido en v326 |
| C12 | **Bocadillo del ermitaño** (v326) | Debe decir «¡Sin excesos! / ¡Jujú!» y luego «Soy Vuelo.» |
| C14 | **Cierre del quiz** (v327) | «¡Bien hecho!» + técnica, y «¡Aún te falta entrenamiento!» |
| C13 | **Las 14 técnicas del ermitaño** (v326) | Estaban ROTAS desde la v317 (12 de 14). Probar varias, no solo Vuelo |
| C10 | **«Aldea Bambú»** (v324) | Rótulo, mapa, menú RUN y diálogo de la aldeana. Los tres a la vez |
| C11 | ~~¿Se corta «Aldea Issunboshi»?~~ | **CERRADO por David con dos capturas**: «Aldea Kachiyama» (15) y «Aldea Florecer» (14) se ven enteras. El marco es de **anchura variable** (medido: 138 px y 233 px). Mi teoría del límite fijo de 12 era errónea. **Sólo «Aldea Taketori» se cortaba**; con «Aldea Bambú» queda cerrado |

---

## D. Testeo

| # | Qué |
|---|---|
| D1 | **Testeo profundo completo.** David lo hará y anotará lo que aparezca |
| D2 | Comprobar los mundos 6 y 7, que usaban los registros de escena rotos de la v237 |
| D3 | Suavizar mutilaciones heredadas del original donde se pueda |

---

## Cerrado

| Qué | Versión |
|---|---|
| Bug del jefe de Kintaro (tabla de escenas `0x1ED6E`) | v314 |
| Los 19 vítores | v315 |
| Juego de dados + 2 mensajes del ermitaño | v316 |
| 14 nombres de técnica + `¿Te animas?` / `¡Qué rácano!` | v317 |
| Menú RUN: destinos, verbos, línea del ermitaño | v318 |
| Dados rehechos, «poco a.», vítores centrados | v319 |
| Rótulos de aldea revertidos + «Aldea Taketori» | v320 |
| «Ve, Momotaro.» — solape de diálogo con el diccionario | v321 |
| El «texto raro» del ermitaño | v322 |
| El ermitaño con el marcador en su sitio | v323 |
| **El quiz del ermitaño: 40 preguntas y 120 opciones** | v324 |
| **El «Vuelo.» que sobraba (NOP al `JSR $DD42` de `0x117C6`)** | v324 |
| **«Aldea Bambú» en los tres sitios** | v324 |
| P21 reformulada, P35 con `Porra`/`Mazo`, P28 documentada como ryo | v325 |
| Las 9 tiendas, menú SELECT con SALUD, onigiri | v307-v313 |
| Acciones de las 6 artes (`Rodar` `Salto` `Azar` `Vuelo` `Giro` `Oleada`) | tanda anterior |


---

## Anexo — B1 y B2: por qué están bloqueados

Los dos son el mismo problema de fondo: **la SAT no existe como tabla
editable en la ROM**. Se compone en ejecución y se vuelca por DMA a VRAM
`$7F00`. Comprobado:

- La SAT del savestate **no aparece en la RAM** como bloque contiguo
  (buscados sus primeros 32, 16 y 8 bytes: nada).
- Sí coincide byte a byte con `VRAM[0xFE00]`, que es el destino del DMA.
- Las listas estáticas de sprites que sí existen (`0x2FBA2`, 16 listas de
  marco y texto) usan la celda `$708`, **no** las `$1A4`-`$1B5` del rótulo
  del mapa. No es esa lista.
- No hay ningún registro `[48 03 8e]` ni `[4c 03 8e]` en toda la ROM, que
  sería el patrón del rótulo si estuviera en una lista.

### B1 — casa mutilada: dos soluciones ya simuladas

Sobre el savestate real de David:

```
ACTUAL                                 pico=16  pierde 6 px del tejado
tejado (i=32) el primero               pico=16  pierde 6 px del sprite 31
borde inferior 32px -> 16px            pico=14  LIMPIO
mapa (22-34) antes que rótulo (0-21)   pico=16  LIMPIO
```

**Estrechar el borde inferior a 16 px queda descartado**: comprobado que
las dos mitades de cada sprite dibujan (`izq=15/7 px`, `der=7 px`), así que
recortarlos rompería el marco.

Queda **reordenar la SAT**: que los sprites del mapa (22-34) se compongan
antes que los del rótulo (0-21). Cero píxeles visibles perdidos, porque el
descarte cae entonces en el sprite 20, que en esas 6 filas no dibuja nada.

### Lo que falta para desbloquear los dos

Localizar la rutina que compone la SAT. No se puede por barrido de bytes:
hay que **seguir el código** desde el bucle de dibujado del mapa, o que
David ponga un breakpoint de escritura en VRAM `$FE00`.

**Ni B1 ni B2 se tocan hasta tener esa rutina.** Escribir a ciegas en la
zona de sprites es lo que costó la v309 (fondo destrozado) y la v293
(pantalla de título).


---

## A-NUEVOS. Los seis encargos de David del 2026-08-29

Medidos en la entrada 270. **Ninguno tocado todavía.**

| # | Qué | Estado |
|---|---|---|
| ~~**N1**~~ | **Capa: la descripción se corta** en «Los ogros no te » | **MEDIDO.** El texto está entero en la ROM (`0x48A16`, 20 B) pero el bocadillo es **nombre + UNA línea de 16 columnas**: no hay scroll ni segunda línea. Las 19 descripciones caben en 16; la Capa es la única de 20. Alternativas: «Nadie te verá.» (14, propuesta de David), «Ogros no te ven.» (16), «Invisibilidad.» (14). **Decide David** |
| ~~**N2**~~ | **Pantalla oculta del baño sin traducir** | **LOCALIZADA**: ROM `0x4AC44`, 71 B, banco `$25` (ya estaba en la lista de 3 bloques). 4 frases de 16 columnas. Traducción propuesta en la entrada 270 |
| ~~**N3**~~ | **Reflujo de la aldeana de Kaguya** (3 páginas) | Propuesta de David lista. Falta localizar el bloque y ver si las páginas son de longitud fija |
| ~~**N4**~~ | ~~«El perro va / contigo.» 2 px arriba~~ | **CERRADO v398 (17 B + 1).** La vía buena no era `$9BBD` (tabla COMPARTIDA: causó la regresión de los bocadillos de 3 filas) sino la cueva `$FFC3` que **ya existía desde la v234** con el identificador `$368F=2`, como recordó David. Su defecto: usaba la constante `LDA #$04`, que sólo movía el renglón de la mitad baja. Ahora deriva el valor (`LSR`+`INC`+`INC` → 6 y 2) y bajan los dos. Confirmado por David: *«Todo se lee bien, aldeanos incluidos»*. La v397 destapó una regresión en los vítores (también pasan por la cueva, 105 hits) resuelta en la **v398** con un byte: `0x169F2` `ADC #$34`→`#$32`. Normas 384, 385 y 386 |
| ~~**N5**~~ | ~~Vítores del primer nivel 4 px arriba~~ | **CERRADO v396 (UN BYTE), CONFIRMADO POR DAVID. Ya es la ROM OFICIAL.** `ROM 0x169F2`, `ADC #$30` → `#$34` en `$C9EE`. Sistema independiente (celdas `$178..$189`): verificado que no toca ningún diálogo. **Confirmado en pantalla** |
| **N6** | **Jizo mutilado al inicio de una pantalla** | **CERRADO en la v402 (entradas 283-287), confirmado por David en pantalla.** Causa (283): SAT llena, el rótulo «COMIENZA EL JUEGO» gastaba 30 sprites y el Jizo perdía su base (`$102`). Vía (David): acortar a «¡A JUGAR!». La caja NO se elige por tabla de índice sino por **código** (`$DF58`, entradas 102-106): `$5B8E[9]` (caja) y `$5B98[9]` (texto). Fix final: caja nueva de 112 px **con tapón** (¡A JUGAR! = 9 glifos, impar) en `0x2F812`, puntero caja `[6]` `0x2FBAE`→`0x5812`; texto centrado de 5 celdas en `0x2FFBF`, puntero texto `[6]` `0x2FBBE`→`0x5FBF`. Medido: rótulo 30→18 sprites, Jizo completo (3), texto centrado y **0 huecos** (el tapón rellena la columna de 4 px de la entrada 106). Errores propios corregidos: cambié `0x2FB8E` (caja de Partida), pisé el terminador de Partida en `0x2FFBE` y usé la caja par (sin tapón). Norma 394. |

---

## ~~A-BORRA~~. NO EXISTE — ficha retirada (2026-08-29)

David: *«El A-Borra, yo no lo veo por ninguna parte. ¿Tú sí?»* **No.**
Decodificado `0x1F79E` (entrada 272): es el **HAI / IIE** de la password, ya
traducido, y en `0x1F7AA` hay un «¡Guardado!», también traducido. **No hay
ningún «¿borrar los datos?»**. La entrada 293 lo etiquetó mal hace 80
entradas y yo arrastré el error hasta abrirle ficha con prioridad. Norma 381.

Lo que sigue vivo de aquello es **A6: backup RAM** (`0x1F51E`, 674 B), que es
otra cosa y sigue sin revisar.

---

## A-SPR. Mutilaciones por exceso de sprites por línea — **ABIERTO, prioridad 4**

| # | Qué | Estado |
|---|---|---|
| **A-SPR** | Varios elementos salen recortados porque se pasa el límite de sprites por línea del VDC. | **ABIERTO, parcialmente medido.** Casos conocidos: el niño aldeano sin cabeza y las bolas del minijuego (entradas 14232, 15157, 16754). Medido en su día: *«bolas mutiladas: peor línea 56, con 11 sprites; no llega a 16»* → **en ese caso el límite duro no era la causa**, hay que volver a medirlo. |

**Aviso importante:** una parte de estas mutilaciones **ya existe en la ROM
japonesa** (comprobado para varias). Antes de tocar nada, **comparar el mismo
frame contra la virgen**: si la japonesa se mutila igual, no es nuestro y se
cierra como «del original». Sólo se arreglan las que hayamos causado nosotros
o las que David decida.

Emparentado con **B1** y **B2**: los tres dependen de la misma pieza que
falta, la rutina que compone la SAT en ejecución.

---

## A-GRAF. Gráficos con texto por traducir — **ABIERTO, prioridad 5. LOS EDITA DAVID**

| # | Qué | Estado |
|---|---|---|
| **A-GRAF** | Quedan gráficos con texto japonés incrustado (era la ficha **A8**, «sin inventariar»). | **ABIERTO.** David: *«los gráficos que hay que traducir, que no son muchos y lo haré yo.»* |

**Reparto de tareas, dicho por David:** el dibujo lo hace él. Nuestro trabajo
es **localizar cada gráfico, extraerlo a PNG y pasárselo**, y luego
**reinsertar** lo que devuelva. Nada de editar píxeles por nuestra cuenta.

Antes de extraer nada: si el gráfico está comprimido, **escribir su codec y
probar el round-trip primero** (norma 355). Para el CG comprimido ya existe
`tools/cg.py`, verificado.

---

## A000. Aparecido en la v338 (2026-08-24)

| # | Qué | Estado |
|---|---|---|
| ~~A000a~~ | ~~El «!» del password: «¡Introduce el canto de JizoA»~~ | **CERRADO en v338.** No era de la tanda de estos días: lo rompió la **v320** al reescribir el bloque de rótulos empezando un byte antes de la cuenta (`0x1F89C` es del password, no de los rótulos). Verificado en pantalla |
| ~~A000b~~ | ~~3 B muertos en `0x1F8EC`~~ | **CERRADO en v338**: los dejó la v324 al revertir «Taketori»→«Bambú» sin recompactar. Recuperados |
| **A000c** | **Bug gráfico bajo la cabeza del ogro rosa** (final Difícil) | **SIN INVESTIGAR.** Lo reclamó David y sigue pendiente |
| **A000d** | **Tabla `0x24DE`** (presentación de enemigos, 38 entradas de 8 B) | **ABIERTA**: en la v334/v338 sigue apuntando a offsets japoneses → los textos van desfasados. El repunte que hizo la v335 se perdió al descartarla. **Rehacer** |
| **A000e** | **15 `$00` de relleno** en `0x4A476..0x4A483` | **ABIERTA**: abren páginas fantasma (28 terminadores en japonés, 43 en el nuestro). El arreglo de la v337 se perdió |

### Formato acordado con David (no negociable)

- **Nunca partir una palabra.** Si no cabe, la palabra entera baja de línea.
- **Nomenclatura de finales**: Muy difícil / Difícil / Normal / Fácil. No «corto/largo».
- **Presentación de enemigos**: la frase en su línea, el nombre en la suya, y punto final si no acaba en exclamación:

      ¿Cayó sin estallar?
      ¡Ogro Explosivo!

- **Staff en orden occidental** (nombre-apellido) y con inicial si no cabe: `M. Kuya`, `H. Iizuka`.
- Sin abreviaturas. **Momotaro** sin `u` final. **Sólo** con tilde.
- **No se genera ROM hasta ver capturas de cómo quedan los cambios.**


---

## A0000. Cerrado en la v379-v380 (2026-08-26)

| # | Qué | Estado |
|---|---|---|
| ~~A0000a~~ | ~~Vocales acentuadas flacas~~ | **CERRADO v379.** Instaladas las de David en las dos fuentes (diálogo 1bpp y menú 2bpp). De paso se arregló la `Á` del menú (`0x04920`), que estaba corrupta |
| ~~A0000b~~ | ~~Sound Test en kana~~ | **CERRADO v380**: «SALA DE SONIDO», centrado |
| ~~A0000c~~ | ~~Graphics Test en kana~~ | **CERRADO v381**: «GALERÍA DE ARTE», repuntado a `$DE73`, contador `CPX` a 15, centrado (`ST1 #$08`) y borrados los dos dakuten japoneses que quedaban flotando (`LDA #$96` → `#$00`) |
| ~~A5 Muy Difícil~~ | ~~Final Muy Difícil~~ | **CERRADO**: David confirma que va bien (usa las mismas fichas que el Difícil) |

### Abierto, por orden de interés

| # | Qué |
|---|---|
| **A000c** | **Bug gráfico bajo la cabeza del ogro rosa** (final Difícil). Sigue sin investigar |
| **A000d** | Tabla `0x24DE` (presentación de enemigos): apunta a offsets japoneses |
| **A000e** | 15 `$00` de relleno en `0x4A476` que abren páginas fantasma |
| **A00** | Colas invisibles en las descripciones de objeto |
| ~~menú RUN~~ | **CERRADO v383**: las 3 ventanas al centro, sólo la activa visible (marco **y** texto). Resuelve el límite de 19→13 slots por línea |
| ~~bocadillo del abuelo~~ | **CERRADO v384.** Su texto y el del menú RUN se horneaban en las mismas celdas ($1C4-$1DD vs $1C0-$1DB). El menú pasa a usar un solo juego de celdas ($1C0-$1C3/$1D0-$1D3) y deja libre el rango del bocadillo. Ver entradas 221-227 |
| — | Artefactos en las copas de los árboles (pantalla de vítores) |
| — | Texto de vítores 4 px por encima del bocadillo |
| — | Posadero: «¡Buenos días! ¡A por los» — falta «ogros.» |
| — | Abuelo tras el primer jefe: «El perro te acompaña» sin punto final |
| — | Backup RAM (`0x1F51E`), 5 mensajes sueltos del menú (A4) |

### Nota sobre la `Ú` mayúscula

En las pantallas que corren con **`$3BA6=1`** (Sound Test, entre otras) el
código `$C6` no da la `Ú` sino la `ú` minúscula: esa tabla (`$9CB3`) lo
traduce al glifo `$7F`. Arreglarlo exige tocar una entrada compartida y
puede romper otros textos. **Evitar mayúsculas acentuadas en esas zonas.**
