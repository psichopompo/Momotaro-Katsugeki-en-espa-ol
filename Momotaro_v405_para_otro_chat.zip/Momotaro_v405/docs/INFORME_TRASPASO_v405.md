# INFORME DE TRASPASO — Momotarou Katsugeki en castellano

**Fecha:** 2026-08-31 · **Estado:** **v405 = ROM actual de trabajo** (los vítores
aprobados por David; queda un vítor por corregir y el selector de dificultad).

Este informe cubre **de la v401 a la v405**: los 9 textos de la v403, la v404
retirada y la v405 (vítores), más el **vítor pendiente** (cha-chá, bloque 13
vs 12) y el estado de la investigación del **selector de dificultad**.

Sustituye a `INFORME_TRASPASO_v402.md` (que pasa a `docs/historico/`).

Si retomas sin contexto: lee esto entero, después `docs/PENDIENTES.md`
(registro único de tareas) y `LEEME.md` (normas 12-394).

---

## 1. El proyecto

Traducción al castellano de **Momotarou Katsugeki** (PC Engine, 512 KB, HuCard).

- **Dirige: David** (*Psicopompo*, elotrolado.net). Las decisiones de diseño y
  maquetación son suyas.
- Repo: `https://github.com/psichopompo/Momotaro-Katsugeki-en-espa-ol`
- ROM base: `roms/Momotarou Katsugeki (Japan).pce` (virgen) — **INTOCABLE**.
  MD5 `ec7358edb3672a8aa8850623eec72a71`.

### La ROM actual

```
roms/momotaro_es_v405.pce
MD5    f6d4d53d22d54458f126b1e73375ec7e
SHA-1  fd54ee42636a568f519e40760bbfb6e9e5fcfbc1
CRC32  07DD8B3A            524.288 B
```

Parche: `parches/momotaro_v405.ips` (contra la virgen japonesa, regenerado en
esta tanda: 49.740 B, 2.416 registros). **Round-trip verificado**: reconstruye
la v405 byte a byte desde la virgen.

### Cadena de versiones

```
v401 ──► v402 (OFICIAL, N6 Jizo) ──► v403 (9 textos) ──► v404 (RETIRADA) ──► v405 (vítores)
```

`roms/momotaro_es_v402.pce` = la oficial. `momotaro_es_v403.pce` es la base de
la v405. La v404 **ya no existe** (retirada).

---

## 2. Cómo tratar con David

No es opcional. El detalle completo está en `docs/historico/INFORME_TRASPASO_v401.md`,
sección 2. Lo esencial:

- **Siempre en castellano.** Tutear.
- Reconocer los errores propios **explícitamente**.
- Distinguir **[HECHO]** (medido) de **[HIPÓTESIS]**.
- **Una sola pregunta por mensaje**, al final, con `¿` de apertura.
- Capturas individuales, nunca rejillas.
- **Si David contradice el análisis, comprobarlo antes de descartarlo: ha
  tenido razón SIEMPRE.** En esta tanda, **ocho veces** (franjas de v396,
  identificador propio del abuelo `$368F`, baño de 16 columnas, «por todos
  lados.», captura de la página 2, el hueco de 4 px de «¡A JUGAR!», el dato
  «4 px más abajo» que corrigió el signo del fix de la v405, y el state
  `Selector Muy Difícil.state11`, que sí está en MUY DIFÍCIL con el melocotón
  apuntándole — mi lectura de `$3D14=0` estaba mal).
- **«Recuerda revisar el log. Tiene que haber información útil.»**
- **La verdad es lo que se ve en pantalla, no el hex.**
- **NUNCA partir una palabra.** **No se puede recortar texto: tiene que caber.**
- **No dejemos cosas a medias.**
- No sacar una versión por cada cambio mínimo: agrupar.
- **No se genera ROM hasta ver capturas de cómo quedan los cambios.**
- **Comprender antes que modificar; prohibido escribir bytes a ciegas.**
- No bloquear el menú RUN cuando habla el abuelo; no tocar el bocadillo apaisado.
- Traducción: fidelidad y naturalidad, con puntos finales; sin abreviaturas;
  "Momotaro" sin `u` final; "Sólo" con tilde; staff en orden occidental;
  cargos en MAYÚSCULAS; en créditos nombres sin punto y frases con punto;
  finales "Muy difícil / Difícil / Normal / Fácil".

---

## 3. Qué se ha hecho de la v401 a la v405

| Ver | Estado | Qué |
|---|---|---|
| v402 | **OFICIAL** | N6 (Jizo mutilado) cerrado |
| v403 | prueba | **9 arreglos de texto** (ver §4) |
| v404 | **RETIRADA** | vítores: `ADC #$34` para `$368F<>2` (4 px bajos) |
| v405 | **actual** | vítores arreglados de verdad: `ADC` condicional `#$32`/`#$30` |

---

## 4. La v403 — 9 arreglos de texto (tanda del testeo completo de David)

Todos **in-place** (sin repuntar). Base v402. Script `tools/build_v403.py`.
Están **a la espera de captura de David** (no ha validado aún todos en
pantalla). Cada uno con su `assert` de byte esperado:

| # | Código | Qué | Dónde |
|---|---|---|---|
| 1 | T-SOLO | «solo perderás la vida» → «sólo …» (adverbio, `dake`=solamente) | `0x4BD90` `o`→`ó` |
| 2 | T-QUIZ | «Con el gorro, / ¿qué más puso?» → «Además del gorro / ¿qué les puso?» | `0x4B2CC-0x4B2ED` |
| 3 | T-ERMI | «¡Yo soy el ermitaño <NOMBRE>!» → «¡Soy el ermitaño / <NOMBRE>!» | `0x4B85D` |
| 4 | T-OGRO | «…ahí fuera. Dicen que…» → «…fuera, dicen que…» (variante sin «De», 0 B) | `0x4A204` |
| 5 | T-ARTE | «Parapunte» → «Paropunte» (katakana ﾊﾟﾛﾌﾟﾝﾃ = pa-ro-pu-n-te) + la `p` $B0→$5E (el «Ç») | `0x4AEAA/B`, `0x4AEDB/C` |
| 6 | T-ARTE | «Toma: ¡<arte>!» → «Toma: <arte>.» (sin exclamaciones, decisión de David) | `0x4B824`, `0x4ADF5` |
| 7 | T-POSADA | «Ç flotante» = dakuten `$DE` huérfano de «デ»; borrado + cola «トマレマス!» | `0x4882D`, `0x48C77` |
| 8 | T-DADOS | «¡Hasta la vista!» cortado: 2 espacios de sobra empujaban el texto | `0x4AD1D-0x4AD34` |
| 9 | T-DESPEDIDA | restos japoneses en las 5 despedidas de tienda (colas de kana) | `0x48BE0/06/2B/51` |

**Decisión pendiente de David (T-OGRO):** la variante aplicada es «…fuera,
dicen que…» (+0 B). La alternativa «De ese ogro…» pide **+3 B** y repunte.
Sin decidir aún.

---

## 5. La v404 (retirada) y la v405 — los 3 vítores con franjas

### El síntoma

«Colorín colorado», «Japón cha-chá» y «Tachán fase superada» salían con
**franjas negras / píxeles blancos** y el texto desplazado.

### El mecanismo [HECHO, entradas 293-295]

La Y final del texto = `$3663` (= `$16` + ADC en `$C9EE`) + `$10` (cueva `$FFC3`).

- `$368F` **no es** un id de bloque de vítores: es un **id de actor/contexto
  0-3**, escrito desde 4 sitios. El abuelo y tras_jefe comparten `$368F=2`
  **por coincidencia**.
- `$3665` = `X & 3` (columna del carácter); la cueva da `$10` por columna:
  `$368F=2` → `$10=6`; `$368F<>2` → `$10=8`.

### El error de la v404 [ERROR PROPIO]

Asumí que «volver a la v396» era correcto y puse `ADC #$34` para `$368F<>2`.
Pero el N5 de la v396 (ADC `#$30`→`#$34`) era **solo para el jefe 1** y, al
ser global, **rompió los `$368F<>2`** (que en la v393 ya estaban bien). El
valor correcto para `$368F<>2` es el **ORIGINAL `#$30`**.

### El fix v405 (corrige la v404 en UN byte)

`ADC` condicional en `$C9EE` según `$368F`, vía stub:

```
ROM 0x169EE  A5 16 18 69 32  ->  20 86 DE EA EA   (JSR $DE86 + 2 NOP)
stub ROM 0x17E86 (lógico $DE86, banco 0x0B = MPR6):
    LDA $368F / CMP #$02 / BNE +6
    LDA $16 / CLC / ADC #$32 / RTS      ($368F=2)
    LDA $16 / CLC / ADC #$30 / RTS      ($368F<>2)
```

### Validación numérica [HECHO]

Tachán y Colorín vuelven a la v393 (correcto): línea 1 centrada en fila 135.
tras_jefe (`$368F=2`) sin cambios. Regresión abuelo/dados: 0 px en 5 states.

### El vítores pendiente — cha-chá bloque 13 vs 12 [ABIERTO]

David: al terminar la fase **5-1** (Japón cha-chá), ahora sale **«¡Bien hecho,
Momo! / ¡Casi has ganado!» (bloque 13)** en vez de **«Japón, cha-chá» (bloque
12)**. Sospecha: **mapeo fase→bloque desplazado**.

Contexto clave (entrada 294): el state `Japón cha-cha.state` es **post-dibujado**
(`$3663` ya fijado), así que no sirve para ver el fallo; hace falta un state
**pre-dibujado** de la fase 5-1 (David no lo ha proporcionado aún). Cha-chá es
además una escena distinta (celebración con banderola grande, filas 90-177),
no el banner de vítores de Tachán/Colorín.

**Para el otro chat:** hay que encontrar dónde se elige el bloque de texto del
vítor según la fase y ver por qué la 5-1 cae en el bloque 13 (vecino) en vez
del 12. La tabla de bloques de vítores vive en `0x480EA..0x4847D` (entrada
177); el lector es la tabla `$C433` (corrige el viejo inventario falso de
«44 frases»).

---

## 6. El selector de dificultad (investigación en curso — el gran pendiente)

### El síntoma (medido, entrada 296)

- La ventana del selector es de **~7-8 caracteres**.
- «MUY DIFÍCIL» (10) se corta a «MUY DIF»; «NORMAL» (6) sale «NORMA» (sin L);
  «DIFÍCIL» (7) cabe entero. **El corte NO es uniforme**.
- En la **pantalla de CARGA** los nombres sí se ven (esa ventana ya se amplió,
  entrada 91).
- En la **ROM japonesa** el rótulo largo desborda igual: «MUY DIFÍC / IL» con
  el «IL» rompiendo el margen izquierdo de la línea siguiente.

### Lo que se sabe del mecanismo [HECHO, entradas 296-298]

**La fuente.** El texto del selector se dibuja con **sprites**, usando celdas
de VRAM de 16×16 que contienen **2 glifos de 8×8 cada una**. Celdas activas en
el state: `1C0`=«M », `1C1`=«UY», `1C2`=«O », `1C3`=«FI», `1C8`=«CÍ», `1C9`=«LI»,
`1CA`=«N », `1CB`=«RO», `1CC`=«AM» (las letras de MUY DIFÍCIL + NORMAL + FÁCIL).
Los glifos **grandes** (la dificultad seleccionada, debajo del marco) usan otro
rango de celdas (`0x140-0x155`).

**Dos sistemas de texto:**
1. **`$E3EB`** (fís. 0x003EB, MPR7=0x00): intérprete de **registros fijos de
   5 bytes** `[patrón][atributo][control][dx][dy]`, terminador patrón=`$FF`.
   Avanza `$53` de 5 en 5. Calcula celda = base + patrón*2 (base típica `$02C0`,
   `$0340` o `$0380`). Escribe el shadow SAT `$26E0-$28FF`.
2. **Lenguaje de comandos** (d8/d9/dc/dd/de/e2/e3/e4/e6/ec/f0/f1) en las listas
   `$D900/$DF87/$F1BE/$F9DF` (punteros en `$DBF5`, indexados por `$DA90[$3D14]`)
   y `$DBD1` (rótulo). **Su intérprete AÚN NO se ha localizado** (no es `$E3EB`).

**Código del selector** (fís. 0x11A40, MPR0=0x08):
- `$1A49` rótulo fijo → puntero `$DBD1`, base `$02C0`, JMP `$E3EB`.
- `$1A65` opción → `$DBF5[$DA90[$3D14]*2]`, base `$02C0`, JMP `$E3EB`.
- `$1AA4`=UP (`DEC $3D14`), `$1AB2`=DOWN (`INC $3D14`).

**Falsas pistas ya descartadas:** `$DBD1`/`$D900`/`$DF87` no son listas de 5
bytes (son bytecode); el `CMP #$D8` de 0x5F9E5 y 0x0B67D son datos; el state
`Selector Muy Difícil` NO re-ejecuta `$1A40-$1AB2` en reposo (el bucle ocioso
dibuja texto del MENÚ vía `$C73A` → `$E3EB` con puntero `$4B0D`).

**Corrección importante (entrada 298):** `TAM`/`TMA` usan **máscara de bits**,
no índice 0-7: `#$01`=MPR0 … `#$80`=MPR7. `TAM #$04` = **MPR2**, no MPR4.

### Lo que falta para el fix del selector

1. Localizar el **intérprete de comandos** d8/d9 (probablemente el JMP `$E3EB`
   con MPR7≠0x00 apunta a OTRO `$E3EB` de comandos en otro banco), O alcanzar
   el selector en el emulador y trazarlo.
2. Localizar **dónde se limita el ancho por fila** (2 sprites de 32 px = 8
   glifos) y **por qué «NORMAL» pierde la L** (no es corte uniforme).
3. Ampliar la ventana a ~12 caracteres para que quepa «MUY DIFÍCIL» (10).

**Cómo llegar al selector (David):** PULSA BOTÓN RUN → INICIAR → primera
introducción (se salta con botón I o II) → selector. Para ver **MUY DIFÍCIL**
hay que usar un state con el juego terminado en **DIFÍCIL** (ese modo
desbloquea MUY DIFÍCIL). El state `Selector Muy Difícil.state11` **sí está en
el selector con MUY DIFÍCIL desbloqueado y el melocotón apuntándole** (David).
[ERROR PROPIO] mi análisis dio `$3D14=0` (FÁCIL) y «no responde»; David lo
corrigió — hay que reinterpretar qué refleja `$3D14` y cómo se traza ese
state, no dar por buena mi lectura del hex sin comprobar la pantalla.

---

## 7. LO QUE TOCA AHORA

Orden de trabajo (ver `docs/PENDIENTES.md`, registro único):

1. **Vítor cha-chá (bloque 13 vs 12)** — el pendiente que pide David ahora.
2. **Selector de dificultad** (MUY DIFÍCIL) — §6.
3. **Validar en pantalla** los 9 textos de la v403 (capturas de David) + la
   decisión del T-OGRO.
4. **A-SPR** — mutilaciones por exceso de sprites por línea.
5. **A-GRAF** — los 7 gráficos con texto. **Los edita David**; nuestro trabajo
   es localizarlos, extraerlos a PNG y reinsertar (nunca editar píxeles).
   T-GRAF1..7: baños «oni no yu», bienvenida a jefes finales, cartel GOAL,
   posada «tomery/yameru», rótulo «deguchi», «Banzai! Studio», «medetashi
   medetashi».
6. **Passwords originales** con texto fácil, y **texto de borrar partidas**.
7. Resto de pendientes menores (ver PENDIENTES.md): A-NOM «Raqueta», 2 bloques
   japoneses del banco `$25` (`0x4A484`, `0x4A71F`), ogro rosa final Difícil,
   tabla `0x24DE`, colas invisibles, posadero «ogros.», Backup RAM `0x1F51E`,
   5 mensajes del menú (`0x435E6`…`0x436CC`).

**Testeo acumulado:** juego completo en v391; vítores y textos en v403/v405;
pendiente el testeo del juego completo de la v405.

---

## 8. El workspace

```
COMO_RETOMAR.md              arranque rápido (leer primero)
Momotaro/
  LEEME.md                   normas 12-394 + estado
  investigation.md           diario, 298 entradas
  docs/
    PENDIENTES.md            registro único de tareas
    INFORME_TRASPASO_v405.md (este fichero)
    historico/               informes de etapas cerradas (v386, v393, v401, v402…)
    GUIA_PARA_EL_OTRO_CHAT.md  GUION_para_traducir.md  MAQUETACION_*.md  QUIZ.md…
  roms/
    Momotarou Katsugeki (Japan).pce   virgen (INTOCABLE)
    momotaro_es_v405.pce              actual
    momotaro_es_v402.pce / v403.pce   hitos
  parches/
    momotaro_v405.ips                 contra la virgen (round-trip OK)
    Momotaro Katsugeki (Español).ips  = v402 oficial
  states/                     savestates de David (.state/.sav/.mss)
    Selector Muy Difícil.state11, Japón cha-cha.state, Vitores.state,
    Final (Fácil/Normal/Difícil/Muy Difícil).state, ermitaños, posadas, quiz…
  capturas/                   PNG de validación
  tools/                      el toolkit (build_v40x.py, pce.py, dis6280.py,
                              ips.py, sat.py, estados.py, estado.py, render_*.py…)
```

### El método (`docs/PROMPT_METODO.md`)

Diario en `investigation.md`. **Las hipótesis falsas NO se borran**: se marcan
`[DESCARTADO]`/`[ERROR PROPIO]`. Una medición → una causa → un arreglo → una
verificación. Cada versión con MD5/SHA-1/CRC32, asserts de byte esperado y
zonas intactas, IPS contra la virgen con round-trip.

### Herramientas clave para el otro chat

- `tools/pce.py` — arnés de emulación (Beetle PCE/libretro) con **trace**:
  `PCE(rom, trace=True)` expone `watch(pc)`, `watch_write(addr)`, `log_on()`,
  `mpr()`, `regs()`. **Ojo:** el core de trace no carga el state del selector
  (retro_unserialize False); usar el core normal para cargar states.
- `tools/estados.py` — carga savestates RZIP de David.
- `tools/state.py` — vuelca secciones de un savestate (VRAM, SAT, BaseRAM…).
- `tools/dis6280.py` — desensamblador HuC6280 (capstone 65C02 no sirve: lee
  TAM como `nop`).
- `tools/sat.py` — lee la SAT (tabla de sprites) y la VRAM.
- `tools/ips.py` — genera/reaplica parches IPS.
- `tools/fuente_menu.py` — formato de la fuente del MENÚ (8×8, 2 planos,
  ROM 0x4000, `(byte-0x30)*16`).
- `tools/charset_oficial.py` — charset de la traducción (encode).
- `tools/render_bg.py`, `render_sprites.py`, `render_texto.py` — renderizado.

### Mapa de memoria (para no releerlo todo)

- `$E3EB`/`$EE86`/`$E185` en MPR7=0x00 (fís. 0x003EB/0x0E86/0x00185).
- Selector: código en MPR0=0x08 (fís. 0x11A40); tablas `$DA90`/`$DA93`/`$DBF5`
  en MPR6=0x06 (fís. 0x0DA90); listas `$D900`/`$DF87` en 0x0D900/0x0DF87.
- Menú (continuar/guardar): rutina `$C73A` (fís. 0x1A73A), texto en `$4B0D`.
- Textos de la tanda v403: banco 0x04 (fís. 0x48xxx-0x4Bxxx).
- Vítores: `$C9EE` (fís. 0x169EE) + stub en 0x17E86 (lógico `$DE86`).

### Lo que más ha costado en esta tanda, en una frase

Dos lecciones: (1) **no mirar el log** — el hueco de 4 px ya estaba resuelto
desde la v138 y lo reintroduje; (2) **dar por bueno «volver a una versión
vieja» sin comprobar si esa versión era correcta** — el N5 de la v396 solo se
había validado con un jefe, y por eso la v404 salió mal.
